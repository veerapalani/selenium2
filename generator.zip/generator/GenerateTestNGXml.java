package qa.testng.generator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.xml.XmlPackage;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

/*This is a main class which will be called by maven (check pom.xml)*/
/*NOTE: Maven will not pick this class if it is outside src/main/java*/
public class GenerateTestNGXml {

	/**
	 * Getting thread count from Command line if not thread count is specified by
	 * default thread count will be 1.
	 * 
	 * @return
	 */
	public static int getThreadCount() {
		/* reading from cmd line */
		String cmdThreadCount = System.getProperty("threadCount");

		if (cmdThreadCount != null) {
			return Integer.parseInt(cmdThreadCount);
		} else {
			return 1;
		}
	}

	/**
	 * Getting list of Xml Packages from ScriptPackage.txt file
	 * 
	 * @return
	 */
	public static List<XmlPackage> listXmlPackages() {

		String line = null;
		BufferedReader bufferedReader = null;
		List<XmlPackage> listXmlPackages = new ArrayList<XmlPackage>();

		try {

			bufferedReader = new BufferedReader(
					new FileReader("./src/main/java/qa/testng/generator/ScriptPackage.txt"));

			while ((line = bufferedReader.readLine()) != null) {
				listXmlPackages.add(new XmlPackage(line.trim()));
			}

		} catch (Exception e) {

		} finally {
			try {
				bufferedReader.close();
			} catch (Exception e) {

			}

		}

		return listXmlPackages;
	}

	/**
	 * Getting list of include groups
	 * 
	 * @return
	 */
	public static List<String> getListOfIncludeGroup() {
		List<String> listIncludeGroups = new ArrayList<String>();

		String cmdGroups = System.getProperty("testNG.options");

		if (cmdGroups != null) {

			String[] split = cmdGroups.split(",");

			for (String group : split) {
				/* checking with group it contains tilt or not */
				if (group.contains("~")) {
					/* Tilt is used to define group which need to be excluded */
				} else {
					listIncludeGroups.add(group);
				}
			}
		}

		return listIncludeGroups;
	}

	/**
	 * Getting list of exclude groups
	 * 
	 * @return
	 */
	public static List<String> getListOfExcludeGroup() {
		List<String> listExcludeGroups = new ArrayList<String>();

		String cmdGroups = System.getProperty("testNG.options");

		if (cmdGroups != null) {

			String[] split = cmdGroups.split(",");

			for (String group : split) {
				/* checking with group it contains tilt or not */
				if (group.contains("~")) {
					/* removing tilt from group name */
					listExcludeGroups.add(group.replace("~", ""));
				}
			}
		}

		return listExcludeGroups;
	}
	
	/**
	 * Write to file
	 * 
	 * @param filepath
	 * @param writeStr
	 */
	public static void write(String filepath, String writeStr) {

		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(filepath));
			writer.write(writeStr);
			writer.close();

		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}

	}
	

	public static void main(String[] args) {

		System.out.println("!!!! Main class executed !!!!");

		/* Create an instance of XML Suite and assign a name for it. */
		XmlSuite suite = new XmlSuite();
		suite.setName("Suite");

		/* Create an instance of XmlTest and assign a name for it. */
		XmlTest test = new XmlTest(suite);
		test.setName("Test");

		/* setting methods as parallel */

		// test.setParallel("methods");
		test.setParallel(XmlSuite.ParallelMode.METHODS);
		/* setting thread count provided in command line */
		test.setThreadCount(getThreadCount());

		/* adding list of packages to a Test */
		test.setXmlPackages(listXmlPackages());

		/* adding include groups */
		List<String> listIncludeGroups = getListOfIncludeGroup();

		/* adding exclude groups */
		List<String> listExcludeGroups = getListOfExcludeGroup();

		/* adding include group in test (if any) */
		if (listIncludeGroups.size() > 0) {
			test.setIncludedGroups(listIncludeGroups);
		}

		/* adding exclude group in test (if any) */
		if (listExcludeGroups.size() > 0) {
			test.setExcludedGroups(listExcludeGroups);
		}

		String xml = suite.toXml();

		/*
		 * only one tentng.xml will be maintained. testng.xml will be form at run time
		 * and will be triggered from maven (check pom.xml)
		 */
		write("./testng.xml", xml);

	}
}
