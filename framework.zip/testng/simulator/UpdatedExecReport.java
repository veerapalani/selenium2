package qa.testng.simulator;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

public class UpdatedExecReport 
{

	
	private HashMap hm;
	public  HashMap session_tags;
	String session_msg;

	UpdatedExecReport(HashMap hash_map)
	{
		hm =hash_map;
	}
	
	DateFormat df = new SimpleDateFormat("yyyyMMdd");
	Date today = Calendar.getInstance().getTime();
	String reportDate = df.format(today);
	private int cum_qty;
	private int lastshares;
	private int leavesQty;
	
	private int seq;
	int fill_pct=25;
	private double order_price;
	private double last_price;
	private double average_price;
	private String fix_version;
	
	String genSeq()
	{
		int sequence;
		
		if(hm.containsKey(34))
		{
			 sequence = Integer.parseInt((String)hm.get(34));
		
		}
		else
		{
			sequence=1;
		}
	//	System.out.println("Sequence number is: "+sequence );
		
		sequence++;
		
		
		
		return ""+sequence;
		
		
	}
	
	private String generateAppiaHeader(String seq_no)
	{
		
		
		String header;
		
		//23041UNICORN_INT_ORDERS_01FIX_448797
		
		if(hm.containsKey(56))
		{
			
			//System.out.println("value is: "+ hm.get(56));
			header = "23041"+(String)hm.get(56)+"";
		
		}
		else
		{
			header = "23041"+"IB"+"";
		}
		
		if(hm.containsValue("FIX.4.4")||fix_version.equalsIgnoreCase("FIX_44"))
		{
			
			header+="FIX_44";
			fix_version ="FIX_44";
		}
		else if(hm.containsValue("FIX.4.2")||fix_version.equalsIgnoreCase("FIX_42"))
		{
			
			header+="FIX_42";
			fix_version ="FIX_42";
		}
		
		header+="8"+seq_no+"";
		
		return header;
		
		
		
	}
	
	
	private String  genExecId() 
{
	char[] alphas= {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z' };
	String stoid;
	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	Date date = new Date();
	int oid = Integer.parseInt(dateFormat.format(date));
	Random r = new Random();
	int seq = r.nextInt(9999);
	int n1 = r.nextInt(25);
	int n2 = r.nextInt(25);
	int n3 = r.nextInt(25);
	stoid = String.valueOf(alphas[n1])+String.valueOf(alphas[n2])+String.valueOf(alphas[n3])+String.valueOf(seq)+String.valueOf(oid);
	
	return stoid;
		
}
	
	
	public void removeSessionTags()
	{
		if(hm.containsKey(8))
		{
			session_tags.put(8, hm.get(8));
		}
		if(hm.containsKey(9))
		{
			session_tags.put(9,hm.get(9));
		}
		
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
	}
	
	public void generateFills(int v)
	{
		
		//int leavesQty = Integer.parseInt(leaveQty);
		//cum_qty= Integer.parseInt((String)hm.get(14));
		//lastshares= O_Qty - (int)(Math.random()*((O_Qty-cum_qty)));
		//cumQty = cumQty + lastshares;
		//remQty = remQty - lastshares;
		//lastshares = (int) (O_Qty*0.25);
		
		int O_Qty= Integer.parseInt((String)hm.get(38));
		
	//	System.out.println("Order QTY:"+O_Qty);
		
		leavesQty = Integer.parseInt((String)hm.get(151));
		
	//	System.out.println("leaves qty:" + leavesQty);
		
		
		
		if(O_Qty>=leavesQty)
		{
			Random r = new Random();
			
			if(v==1)
			{
				
				lastshares = r.nextInt(leavesQty) + 1;
			}
			else
			{	
				lastshares=leavesQty;
			}
			
		//	System.out.println("Last executed shares: "+lastshares );		
			
			cum_qty = cum_qty + lastshares;
			
			leavesQty= leavesQty - lastshares;
			
			
			
			if(hm.containsKey(44))
			{
				
				String o_px = (String)hm.get(44);
				order_price= Double.parseDouble(o_px);
			}
			else
			{
				
				order_price=50.00;  // later can be connected to mkt data source for feeds.
				
			}
			
			//int order_side = Integer.parseInt((String)hm.get(54)); // Commented out as Short Sell value received is H
			
			String order_side = (String)hm.get(54);
			
			if(order_side.equalsIgnoreCase("1"))
			{
				last_price= order_price - r.nextDouble();
			}
			
			else if(order_side.equalsIgnoreCase("2") || order_side.equalsIgnoreCase("H"))
			{
				
				last_price= order_price + r.nextDouble();
			}
			
					
		//	System.out.println("generated last px: "+last_price);		
			
			
			average_price= Double.parseDouble((String)hm.get(6));
			
			
			if(average_price==0)
			{
				average_price =last_price;
			}
			else
			{
				average_price = (average_price + last_price)*0.5;
			}
			
			
			
			
		}
		
		
		
		
	}
	
	public void generateTradeCorrect()
	{
		
		/*
		 * Trade correct happens only for px and not qty 
		 */
		
		Random r = new Random();
		//int order_side = Integer.parseInt((String)hm.get(54));
		
		String order_side = (String)hm.get(54);
		
		if(order_side.equalsIgnoreCase("1"))
		{
			last_price= last_price - r.nextDouble();
		}
		
		else if(order_side.equalsIgnoreCase("2") || order_side.equalsIgnoreCase("H"))
		{
			
			last_price= last_price  + r.nextDouble();
		}
		
		average_price= Double.parseDouble((String)hm.get(6));
		
		if(average_price==0)
		{
			average_price =last_price;
		}
		else
		{
			average_price = (average_price + last_price)*0.5;
		}
		
		//cum_qty = cum_qty - 50;
		
		//int qty = Integer.parseInt((String)hm.get(38));
		
		//leavesQty = qty - cum_qty;
	
	}
	
	
	void generatePNew()
	{
		
		String Tag34= genSeq();
		
		
		
		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";
			
		}
		
		hm.put(37, reportDate + hm.get(11));
		
		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"IB");
		}
		
		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			hm.put(56,"PPT");
		}
		
		
		hm.put(49, hm.get(99999));
		hm.put(14,"0");
		hm.put(20,"0");
		hm.put(39, "A");
		hm.put(150,"A");
		hm.put(151,hm.get(38));
		hm.put(58,"Pending New");
		hm.put(34,Tag34);
		
		
		String header= generateAppiaHeader(Tag34);
		
		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);
		
		
		
		
		String fix_message="49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"1="+hm.get(1)+""+"37="+hm.get(37)+""+"38="+hm.get(38)+""+"60="+hm.get(60)+""+"15="+hm.get(15)+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"20="+hm.get(20)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";
		
		
		
	}
	
	
}
