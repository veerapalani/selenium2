package qa.testng.simulator;
public class ExecParams {
	
	static int execID= 0;
	static int seq;
	
	int execQty;
	double avgPrice;
	double lastPx;
	int lastQty;
	String lastMkt;
	int cumQty;
	int OrderQty;
	
	
	public static int getExecID() {
		return execID;
	}

	public static void setExecID(int execID) {
		ExecParams.execID = execID;
	}

	public static int getSeq() {
		return seq;
	}

	public static void setSeq(int seq) {
		ExecParams.seq = seq;
	}

	public int getExecQty() {
		return execQty;
	}

	public void setExecQty(int execQty) {
		this.execQty = execQty;
	}

	public double getAvgPrice() {
		return avgPrice;
	}

	public void setAvgPrice(double avgPrice) {
		this.avgPrice = avgPrice;
	}

	public double getLastPx() {
		return lastPx;
	}

	public void setLastPx(double lastPx) {
		this.lastPx = lastPx;
	}

	public int getLastQty() {
		return lastQty;
	}

	public void setLastQty(int lastQty) {
		this.lastQty = lastQty;
	}

	public String getLastMkt() {
		return lastMkt;
	}

	public void setLastMkt(String lastMkt) {
		this.lastMkt = lastMkt;
	}

	public int getCumQty() 
	{
		
		
		return cumQty;
	}

	public void setCumQty(int cumQty) {
		this.cumQty = cumQty;
	}

	
	
	
	public void setOrderQty(String orderQty) 
	{
		OrderQty = Integer.parseInt(orderQty);
	}

	static int genSeqNo(String seq_Num)
	{
		return Integer.parseInt(seq_Num)+1;
	}
	
	static String genExecId()
	{
		
		return null;
	}


	
	

}
