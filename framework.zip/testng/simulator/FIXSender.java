package qa.testng.simulator;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.ibm.mq.jms.MQQueue;

import com.ibm.mq.jms.MQQueueConnection;
import com.ibm.mq.jms.MQQueueConnectionFactory;
import com.ibm.mq.jms.MQQueueSender;
import com.ibm.mq.jms.MQQueueSession;
import com.ibm.msg.client.wmq.WMQConstants;

public class FIXSender 
{
	
	public static  Logger logger = Logger.getLogger(FIXSender.class);
	BytesMessage bytes;
	MQQueueSender sender;
	
	public FIXSender()
	{
		
		try {
			
			
			   MQQueueConnectionFactory cf = new MQQueueConnectionFactory();
			   cf.setHostName("10.152.225.7");
			   cf.setPort(1416);
			     
			   cf.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
			   
			   cf.setQueueManager("APPIAQM");
			   cf.setChannel("APPIA.SVRCONN");
			     
			   MQQueueConnection connection = (MQQueueConnection) cf.createQueueConnection();
			   MQQueueSession session = (MQQueueSession) connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			   MQQueue queue = (MQQueue) session.createQueue("APPIAQ.INT.3.IN"); 
			
			   sender =  (MQQueueSender) session.createSender(queue);
			   
			   bytes = session.createBytesMessage();
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	
	
	public void sendMessage(String msg)
	{
		
		try {
		
						   
			   System.out.println(msg);
			   byte [] b = msg.getBytes();
						
				bytes.writeBytes(b);   
				sender.send(bytes);
				bytes.clearBody();
				System.out.println(bytes);
				logger.info(bytes);
				}
				catch(JMSException jmsex)
				{
					
					jmsex.printStackTrace();
				}
			
		
	}
	  

}
