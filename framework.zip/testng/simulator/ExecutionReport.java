package qa.testng.simulator;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.collections.map.MultiValueMap;

public class ExecutionReport 
{

	private HashMap hm;
	private MultiValueMap mvp;
	public  HashMap session_tags;
	String session_msg;
	private String fix_protol_version;
	private ArrayList<String> repeating_group_message;

	ExecutionReport(HashMap hash_map)
	{
		hm =hash_map;
		fix_protol_version=(String) hm.get(8);
		System.out.println("Fix version to respond is: "+fix_protol_version);
	}

	ExecutionReport(HashMap hash_map, MultiValueMap mul_val_map, ArrayList<String> rep_group_msg)
	{
		hm =hash_map;
		mvp=mul_val_map;
		repeating_group_message=rep_group_msg;

		System.out.println("GRRRRRRR"+repeating_group_message.size());
		fix_protol_version=(String) hm.get(8);
		System.out.println("Fix version to respond is: "+fix_protol_version);

		System.out.println("Multp Map Set: "+mvp.size());
	}




	DateFormat df = new SimpleDateFormat("yyyyMMdd");
	Date today = Calendar.getInstance().getTime();
	String reportDate = df.format(today);
	private double cum_qty;
	private double lastshares;
	private double leavesQty;

	private int seq;
	int fill_pct=25;
	private double order_price;
	private double last_price;
	private double average_price;
	private String fix_version;

	CheckSum cs= new CheckSum();
	private String settlement_date;

	String genSeq()
	{
		int sequence;

		if(hm.containsKey(34))
		{
			sequence = Integer.parseInt((String)hm.get(34));

		}
		else
		{
			sequence=1;
		}
		//	System.out.println("Sequence number is: "+sequence );

		sequence++;



		return ""+sequence;


	}

	private String generateAppiaHeader(String seq_no)
	{


		String header;


		//	header="23041UNICORN_INT_ORDERS_03FIX.4.43134778";

		if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
		{
			header= "23041IBFIX_4208";
		}
		else
		{
			header= "23041UNICORN_INT_ORDERS_03FIX_4408";
		}



		System.out.println("Header value being set is: "+header);

		return header;



	}


	private String  genExecId() 
	{
		char[] alphas= {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y', 'Z' };
		String stoid;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();
		int oid = Integer.parseInt(dateFormat.format(date));
		Random r = new Random();
		int seq = r.nextInt(9999);
		int n1 = r.nextInt(25);
		int n2 = r.nextInt(25);
		int n3 = r.nextInt(25);
		stoid = String.valueOf(alphas[n1])+String.valueOf(alphas[n2])+String.valueOf(alphas[n3])+String.valueOf(seq)+String.valueOf(oid);

		return stoid;

	}


	public void removeSessionTags()
	{
		if(hm.containsKey(8))
		{
			session_tags.put(8, hm.get(8));
		}
		if(hm.containsKey(9))
		{
			session_tags.put(9,hm.get(9));
		}

		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
	}

	public void generateFills(int v)
	{

		double O_Qty= Double.parseDouble((String)hm.get(38));

		leavesQty = Double.parseDouble((String)hm.get(151));

		if(O_Qty>=leavesQty)
		{
			Random r = new Random();

			if(v==1)
			{

				lastshares = r.nextInt((int)leavesQty) + 1;
			}
			else
			{	
				lastshares=leavesQty;
			}

			cum_qty = cum_qty + lastshares;

			leavesQty= leavesQty - lastshares;

			if(hm.containsKey(44))
			{

				String o_px = (String)hm.get(44);
				order_price= Double.parseDouble(o_px);
			}
			else
			{

				order_price=50.00;  

			}

			String order_side = (String)hm.get(54);

			if(order_side!=null) {

				if(order_side.equalsIgnoreCase("1"))
				{
					last_price= order_price - r.nextDouble();
				}

				else if(order_side.equalsIgnoreCase("2") || order_side.equalsIgnoreCase("H"))
				{

					last_price= order_price + r.nextDouble();
				}

			}
			else
			{
				last_price= order_price - r.nextDouble();
			}

			average_price= Double.parseDouble((String)hm.get(6));


			if(average_price==0)
			{
				average_price =last_price;
			}
			else
			{
				average_price = (average_price + last_price)*0.5;
			}


		}




	}

	public void generateTradeCorrect()
	{

		/*
		 * Trade correct happens only for px and not qty as confirmed by Laszlo
		 */

		Random r = new Random();
		//int order_side = Integer.parseInt((String)hm.get(54));

		String order_side = (String)hm.get(54);

		if(order_side.equalsIgnoreCase("1"))
		{
			last_price= last_price - r.nextDouble();
		}

		else if(order_side.equalsIgnoreCase("2") || order_side.equalsIgnoreCase("H"))
		{

			last_price= last_price  + r.nextDouble();
		}

		average_price= Double.parseDouble((String)hm.get(6));

		if(average_price==0)
		{
			average_price =last_price;
		}
		else
		{
			average_price = (average_price + last_price)*0.5;
		}

		//cum_qty = cum_qty - 50;

		//int qty = Integer.parseInt((String)hm.get(38));

		//leavesQty = qty - cum_qty;

	}
	
	
	String QuoteAck()
	{




		String Tag34= genSeq();



		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=S";

		}



		hm.put(37, reportDate + hm.get(11));

		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"CR");
		}

		// Use this as tmp key
		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
			{

				hm.put(56,"IB");
			}
			else
			{
				hm.put(56,"NYSE");
			}
		}
		hm.put(49, hm.get(99999));
		hm.put(14,"0");
		hm.put(20,"0");
		hm.put(39, "A");
		hm.put(150,"A");
		hm.put(151,hm.get(38));
		hm.put(58,"Pending New");
		hm.put(34,Tag34);
		
		hm.put(117,hm.get(131)+"1");
		hm.put(461,"RCSXXX");
		hm.put(62,hm.get(52));
		hm.put(132, "10");
		hm.put(133, "90");
		hm.put(134,"200");
		hm.put(135,"400");

		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);


		//23041CRFIX_44838=FIX.4.49=023735=849=IB56=CR34=352=20191121-14:46:05.8521=094023361X37=OAK0000309619KOFS16338=600660=20191115-10:44:52.67415=USD40=159=054=139=0150=011=2019112100000003373320=055=C63=058=New Order10=218
		
		String delim="";

	//	String fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"1="+hm.get(1)+""+"38="+hm.get(38)+""+"60="+hm.get(60)+""+"15="+hm.get(15)+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";
		
		String fix_message=delim+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+delim+"131="+hm.get(131)+delim+"117="+hm.get(117)+delim+"55="+hm.get(55)+delim+"461="+hm.get(461)+delim+"62="+hm.get(62)+delim+"132="+hm.get(132)+delim+"133="+hm.get(133)+delim+"134="+hm.get(134)+delim+"135="+hm.get(135)+delim+"15="+hm.get(15)+delim;


		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Quote Ack message: "+ fix_message);

		return fix_message;


	
	}


	String generatePNew()
	{



		String Tag34= genSeq();



		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}



		hm.put(37, reportDate + hm.get(11));

		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"CR");
		}

		// Use this as tmp key
		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
			{

				hm.put(56,"IB");
			}
			else
			{
				hm.put(56,"NYSE");
			}
		}
		hm.put(49, hm.get(99999));
		hm.put(14,"0");
		hm.put(20,"0");
		hm.put(39, "A");
		hm.put(150,"A");
		hm.put(151,hm.get(38));
		hm.put(58,"Pending New");
		hm.put(34,Tag34);

		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);


		//23041CRFIX_44838=FIX.4.49=023735=849=IB56=CR34=352=20191121-14:46:05.8521=094023361X37=OAK0000309619KOFS16338=600660=20191115-10:44:52.67415=USD40=159=054=139=0150=011=2019112100000003373320=055=C63=058=New Order10=218


		String fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"1="+hm.get(1)+""+"38="+hm.get(38)+""+"60="+hm.get(60)+""+"15="+hm.get(15)+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";


		if(hm.containsKey(63))
		{
			fix_message+="63="+hm.get(63)+"";
		}

		if(hm.containsKey(64))
		{
			fix_message+="64="+hm.get(64)+"";
		}

		if(hm.containsKey(167))
		{
			fix_message+="167="+hm.get(167)+"";
		}



		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Pending new message: "+ fix_message);

		return fix_message;


	}


	String generateNewAck()
	{
		String Tag34= genSeq();

		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}


		System.out.println(hm.size());


		hm.put(37, reportDate + hm.get(11));

		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"CR");
		}

		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
			{

				hm.put(56,"IB");
			}
			else
			{
				hm.put(56,"NYSE");
			}
		}



		hm.put(49, hm.get(99999));
		hm.put(20,"0");
		hm.put(39, "0");
		hm.put(150,"0");
		hm.put(58,"New Order");
		hm.put(34, Tag34);
		hm.put(6,"0");
		hm.put(37, reportDate + hm.get(11));
		hm.put(17,genExecId());	
		hm.put(151,hm.get(38));

		String header= generateAppiaHeader(Tag34);

		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);
		hm.remove(99999);


		//23041CRFIX_44838=FIX.4.49=023735=849=IB56=CR34=352=20191121-14:46:05.8521=094023361X37=OAK0000309619KOFS16338=600660=20191115-10:44:52.67415=USD40=159=054=139=0150=011=2019112100000003373320=055=C63=058=New Order10=218



		String fix_message=null;

		if(hm.containsValue("MLEG"))
		{
			//			8=FIX.4.29=21235=817=0Q1L005017933=FIRM20=0150=039=037=Q6AVJZZ1BDA640=11=AAA123451XRRR32=031=054=259=0439=15860=20200506-13:35:11.97311=202006180000000000499730=R1462=PRT1167=MLEG55=a03zXX38=60.00000151=6

			fix_message=""+"17="+hm.get(17)+""+"7933=FIRM"+""+"20="+hm.get(20)+""+"150="+hm.get(150)+""+"39="+hm.get(39)+""+"37="+hm.get(37)+""+"40="+hm.get(40)+""+"1="+hm.get(1)+""+"59="+hm.get(59)+""+"439=158"+""+"60="+hm.get(60)+""+"11="+hm.get(11)+""+"9730=R"+""+"1462=PRT1"+""+"167="+hm.get(167)+""+"38="+hm.get(38)+""+"151="+hm.get(151)+""+"555="+hm.get(555)+"";


			Map<Integer, List<String>> mapValues = new HashMap<Integer, List<String>>();
			int repeatingGroupsCount = 0;

			mapValues.putAll(mvp);

			for (Map.Entry<Integer, List<String>> map : mapValues.entrySet()) 
			{
				if (repeatingGroupsCount < map.getValue().size()) 
				{
					repeatingGroupsCount = map.getValue().size();
				}
			}

			System.out.println("Leg Size: "+repeating_group_message.size());


			for (int j = 0; j < repeating_group_message.size(); j++) 
			{

				Map <String,String> tmp_map= new HashMap<>();
				for (Map.Entry<Integer, List<String>> map : mapValues.entrySet()) 
				{
					if (!(map.getValue().size() < j + 1))
					{
						tmp_map.put(""+map.getKey(),map.getValue().get(j).toString());										
					}

				}

				System.out.println("Iterating Leg number: "+j);

				if(tmp_map.containsKey("654") && repeating_group_message.get(j).contains("654="))
				{
					fix_message=fix_message+"654="+tmp_map.get("654")+"";
				}
				if(tmp_map.containsKey("600") && repeating_group_message.get(j).contains("600="))
				{
					fix_message=fix_message+"600="+tmp_map.get("600")+"";
				}
				if(tmp_map.containsKey("608") && repeating_group_message.get(j).contains("608="))
				{
					fix_message=fix_message+"608="+tmp_map.get("608")+"";
				}
				if(tmp_map.containsKey("611") && repeating_group_message.get(j).contains("611="))
				{
					fix_message=fix_message+"611="+tmp_map.get("611")+"";
				}
				if(tmp_map.containsKey("612") && repeating_group_message.get(j).contains("612="))
				{
					fix_message=fix_message+"612="+tmp_map.get("612")+"";
				}
				if(tmp_map.containsKey("623") && repeating_group_message.get(j).contains("623="))
				{
					fix_message=fix_message+"623="+tmp_map.get("623")+"";
				}
				if(tmp_map.containsKey("624") && repeating_group_message.get(j).contains("624="))
				{
					fix_message=fix_message+"624="+tmp_map.get("624")+"";
				}
				if(tmp_map.containsKey("564") && repeating_group_message.get(j).contains("564="))
				{
					fix_message=fix_message+"564="+tmp_map.get("564")+"";
				}

			}


		}
		else
		{
			fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"1="+hm.get(1)+""+"37="+hm.get(37)+""+"38="+hm.get(38)+""+"60="+hm.get(60)+""+"14=0"+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"20="+hm.get(20)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";

			if(hm.containsKey(63))
			{
				fix_message+="63="+hm.get(63)+"";
			}

			if(hm.containsKey(64))
			{
				fix_message+="64="+hm.get(64)+"";
			}

			if(hm.containsKey(167))
			{
				fix_message+="167="+hm.get(167)+"";
			}

		}

		fix_message=session_msg+fix_message;

		//System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value = cs.checksum(fix_message);

		fix_message=fix_message+"10="+value+"";

		fix_message=header+fix_message;

		return fix_message;



	}


	String generateFill(int value)
	{

		String Tag34= genSeq();

		generateFills(value);

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();
		int trade_date = Integer.parseInt(dateFormat.format(date));

		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}


		hm.put(37, reportDate + hm.get(11));
		hm.put(99999,hm.get(56)); // Use this as tmp key
		hm.put(56,hm.get(49));
		hm.put(49, hm.get(99999));
		hm.put(20,"0");

		if(Double.parseDouble((String)hm.get(38))==cum_qty)
		{
			hm.put(39, "2");
			hm.put(150,"2");
			hm.put(58,"Full Fill");
		}
		else if(Double.parseDouble((String)hm.get(38))>cum_qty)
		{
			hm.put(39, "1");
			hm.put(150,"1");
			hm.put(58,"Partial Fill");
		}

		hm.put(34, Tag34);
		hm.put(13,3);
		hm.put(12,"250.0");
		hm.put(14, this.cum_qty);
		hm.put(151,""+this.leavesQty);
		hm.put(32, this.lastshares);
		hm.put(6,""+average_price);
		hm.put(31,this.last_price);
		hm.put(17,genExecId());
		hm.put(75,""+trade_date);
		hm.put(21,"1");

		hm.put(527,hm.get(17).toString());



		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);

		String fix_message=null;
		final char delim = '\u0001';

		if(hm.containsValue("MLEG"))
		{
			//8=FIX.4.29=27935=817=0Q1L005027933=FIRM20=0150=139=137=Q6AVJZZ1CBA240=1527=0Q1L005021=AAA123451XRRR32=30																			31=-3.1554=259=0439=15860=20200506-13:35:11.97311=202006180000000000499730=R382=1														375=255337=CTWO5937=X1462=PRT17694=F442=3167=MLEG
			fix_message=delim+"17="+hm.get(17)+delim+"7933=FIRM"+delim+"20="+hm.get(20)+delim+"150="+hm.get(150)+delim+"39="+hm.get(39)+delim+"37="+hm.get(37)+delim+"40="+hm.get(40)+delim+"527="+hm.get(527)+delim+"1="+hm.get(1)+delim+"32="+hm.get(32)+delim+"31="+hm.get(31)+delim+"59="+hm.get(59)+delim+"439=158"+delim+"60="+hm.get(60)+delim+"11="+hm.get(11)+delim+"9730=R"+delim+"382=1"+delim+"375=CBOE"+delim+"337=CTWO"+delim+"5937=X"+delim+"1462=PRT1"+delim+"7694=F"+delim+"442=3"+delim+"167=MLEG"+delim;

			if(hm.containsKey(44))
			{
				fix_message=fix_message+"44="+hm.get(44)+delim;
			}

			//44=-3.1555=a03zXX38=60151=3014=306=-3.159882=0555=2654=1600=AAPL608=OP611=20200619612=10623=1624=2564=C654=2600=AAPL608=OP611=20200619612=10623=1624=2564=C10=155
			fix_message=fix_message+"55=a03zXX"+delim+"38="+hm.get(38)+delim+"151="+hm.get(151)+delim+"14="+hm.get(14)+delim+"6="+hm.get(6)+delim+"555="+hm.get(555)+delim;

			Map<Integer, List<String>> mapValues = new HashMap<Integer, List<String>>();
			int repeatingGroupsCount = 0;

			mapValues.putAll(mvp);

			for (Map.Entry<Integer, List<String>> map : mapValues.entrySet()) 
			{
				if (repeatingGroupsCount < map.getValue().size()) 
				{
					repeatingGroupsCount = map.getValue().size();
				}
			}


			System.out.println("Leg Size: "+repeating_group_message.size());
			for (int j = 0; j < repeating_group_message.size(); j++) 
			{
				Map <String,String> tmp_map= new HashMap<>();
				for (Map.Entry<Integer, List<String>> map : mapValues.entrySet()) 
				{
					if (!(map.getValue().size() < j + 1))
					{
						tmp_map.put(""+map.getKey(),map.getValue().get(j).toString());										
					}

				}

				System.out.println("Iterating Leg number: "+j);

				if(tmp_map.containsKey("654") && repeating_group_message.get(j).contains("654="))
				{
					fix_message=fix_message+"654="+tmp_map.get("654")+"";
				}
				if(tmp_map.containsKey("600") && repeating_group_message.get(j).contains("600="))
				{
					fix_message=fix_message+"600="+tmp_map.get("600")+"";
				}
				if(tmp_map.containsKey("608") && repeating_group_message.get(j).contains("608="))
				{
					fix_message=fix_message+"608="+tmp_map.get("608")+"";
				}
				if(tmp_map.containsKey("611") && repeating_group_message.get(j).contains("611="))
				{
					fix_message=fix_message+"611="+tmp_map.get("611")+"";
				}
				if(tmp_map.containsKey("612") && repeating_group_message.get(j).contains("612="))
				{
					fix_message=fix_message+"612="+tmp_map.get("612")+"";
				}
				if(tmp_map.containsKey("623") && repeating_group_message.get(j).contains("623="))
				{
					fix_message=fix_message+"623="+tmp_map.get("623")+"";
				}
				if(tmp_map.containsKey("624") && repeating_group_message.get(j).contains("624="))
				{
					fix_message=fix_message+"624="+tmp_map.get("624")+"";
				}
				if(tmp_map.containsKey("564") && repeating_group_message.get(j).contains("564="))
				{
					fix_message=fix_message+"564="+tmp_map.get("564")+"";
				}

				System.out.println("RUNNING LEG NUMBER: "+j);

			}

		}
		else
		{

			//23041CRFIX_44838=FIX.4.49=026435=849=IB56=CR34=352=20191115-10:44:531=BBB111111XRRR37=OAK0000309619KOFS17521=138=60066=20.00000060=20191115-19:31:14.07040=159=054=1151=500614=100039=1150=111=2019112100000003373517=XID0000209619KOFS14620=032=100031=2055=C58=Partial Fill10=223

			fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"52="+hm.get(52)+""+"1="+hm.get(1)+""+"37="+hm.get(37)+""+"21="+hm.get(21)+""+"38="+hm.get(38)+""+"6="+hm.get(6)+""+"60="+hm.get(60)+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"151="+hm.get(151)+""+"14="+hm.get(14)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"17="+hm.get(17)+""+"20="+hm.get(20)+""+"32="+hm.get(32)+""+"31="+hm.get(31)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+""+"76=POST"+"";

			if(hm.containsKey(63))
			{
				fix_message+="63="+hm.get(63)+"";
			}

			if(hm.containsKey(64))
			{
				fix_message+="64="+hm.get(64)+"";
			}

			if(hm.containsKey(75))
			{
				fix_message+="75="+hm.get(75)+"";
			}

			if(hm.containsKey(167))
			{
				fix_message+="167="+hm.get(167)+"";
			}


		}

		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Partial fill message: "+ fix_message);

		return fix_message;

	}


	String generateLegExecutions(int leg_size)
	{

		System.out.println("Generating Execution for Leg: "+leg_size);

		String Tag34= genSeq();

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();
		int trade_date = Integer.parseInt(dateFormat.format(date));

		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}


		hm.put(17,genExecId());

		String header= generateAppiaHeader(Tag34);


		String fix_message=null;
		final char delim = '\u0001';

		if(hm.containsValue("MLEG"))
		{

			//8=FIX.4.29=27935=817=0Q1L007017933=FIRM20=0150=139=137=Q6AVJZZ1CBA240=2527=0Q1L005021=AAA123451XRRR32=3031=-9.2754=259=0439=15860=20200506-13:35:11.973														75=2020050611=202006180000000000499730=R382=1375=255337=CTWO5937=X1462=PRT17694=F442=2
			fix_message=delim+"17="+hm.get(17)+delim+"7933=FIRM"+delim+"150="+hm.get(150)+delim+"39="+hm.get(39)+delim+"37="+hm.get(37)+delim+"40="+hm.get(40)+delim+"527="+hm.get(527)+delim+"1="+hm.get(1)+delim+"32="+hm.get(32)+delim+"31="+hm.get(31)+delim+"59="+hm.get(59)+delim+"439=158"+delim+"60="+hm.get(60)+delim+"75="+hm.get(75)+delim+"11="+hm.get(11)+delim+"9730=R"+delim+"382=1"+delim+"375=CBOE"+delim+"337=CTWO"+delim+"1462=PRT1"+delim+"7694=F"+delim+"442=2"+delim;

			if(hm.containsKey(44))
			{
				fix_message=fix_message+"44="+hm.get(44)+delim;
			}


			//			 /167=OPT14=306=0151=09882=CK55=AAPL

			Map<Integer, List<String>> mapValues = new HashMap<Integer, List<String>>();
			int repeatingGroupsCount = 0;

			mapValues.putAll(mvp);

			for (Map.Entry<Integer, List<String>> map : mapValues.entrySet()) 
			{
				if (repeatingGroupsCount < map.getValue().size()) 
				{
					repeatingGroupsCount = map.getValue().size();
				}
			}


			int j=leg_size;

			System.out.println("Iterating for Leg: "+j);

			Map <String,String> tmp_map= new HashMap<>();
			for (Map.Entry<Integer, List<String>> map : mapValues.entrySet()) 
			{
				if (!(map.getValue().size() < j + 1))
				{
					tmp_map.put(""+map.getKey(),map.getValue().get(j).toString());										
				}

			}
			if(tmp_map.containsKey("608") && repeating_group_message.get(j).contains("608="))
			{
				if(tmp_map.get("608").toString().startsWith("O"))
				{
					fix_message=fix_message+"167=OPT"+"";
				}
				else if(tmp_map.get("608").toString().equalsIgnoreCase("E"))
				{
					fix_message=fix_message+"167=EQ"+"";
				}

			}

			fix_message=fix_message+"14="+hm.get(14)+delim+"6="+hm.get(6)+delim+"151="+hm.get(151)+delim+"9882=CK"+delim+"55="+tmp_map.get("600").toString()+delim;

			//202=10201=1200=202006205=1977=C654=110=25

			if(tmp_map.containsKey("612") && repeating_group_message.get(j).contains("612="))
			{
				fix_message=fix_message+"202="+tmp_map.get("612")+"";
			}
			if(tmp_map.containsKey("608") && repeating_group_message.get(j).contains("608="))
			{
				if(tmp_map.get("608").toString().equalsIgnoreCase("OP"))
				{
					fix_message=fix_message+"201=0"+"";
				}
				else if(tmp_map.get("608").toString().equalsIgnoreCase("OC"))
				{
					fix_message=fix_message+"201=1"+"";
				}

			}				
			if(tmp_map.containsKey("611") && repeating_group_message.get(j).contains("611="))
			{
				char list[]=tmp_map.get("611").toString().toCharArray();

				fix_message=fix_message+"200="+list[0]+list[1]+list[2]+list[3]+list[4]+list[5]+delim;

				fix_message=fix_message+"205="+list[6]+list[7]+delim;	
			}
			if(tmp_map.containsKey("564") && repeating_group_message.get(j).contains("564="))
			{
				fix_message=fix_message+"77="+tmp_map.get("564")+"";
			}

			if(tmp_map.containsKey("654") && repeating_group_message.get(j).contains("654="))
			{
				fix_message=fix_message+"654="+tmp_map.get("654")+"";
			}


		}


		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final fill message: "+ fix_message);

		return fix_message;


	}


	String generateOrderReject()		
	{

		String Tag34= genSeq();



		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}

		System.out.println(hm.size());

		hm.put(37, reportDate + hm.get(11));


		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"CR");
		}

		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
			{

				hm.put(56,"IB");
			}
			else
			{
				hm.put(56,"NYSE");
			}
		}




		hm.put(49, hm.get(99999));


		hm.put(14,"0");
		hm.put(20,"0");
		hm.put(39, "8");
		hm.put(150,"8");
		hm.put(151,"0");
		hm.put(58,"Order Reject");
		hm.put(34,Tag34);
		hm.put(6,"0");
		hm.put(103,"3");
		hm.put(17, genExecId());

		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);


		String fix_message=null;
		if(hm.containsValue("MLEG"))
		{
			//8=FIX.4.29=21235=817=0Q1L005017933=FIRM20=0150=039=037=Q6AVJZZ1BDA640=11=AAA123451XRRR32=031=054=259=0439=15860=20200506-13:35:11.97311=202006180000000000499730=R1462=PRT1167=MLEG55=a03zXX38=60.00000151=6

			fix_message=""+"17="+hm.get(17)+""+"7933=FIRM"+""+"20="+hm.get(20)+""+"150="+hm.get(150)+""+"39="+hm.get(39)+""+"37="+hm.get(37)+""+"40="+hm.get(40)+""+"1="+hm.get(1)+""+"59="+hm.get(59)+""+"439=158"+""+"60="+hm.get(60)+""+"11="+hm.get(11)+""+"9730=R"+""+"1462=PRT1"+""+"167="+hm.get(167)+""+"38="+hm.get(38)+""+"151="+hm.get(151)+""+"555="+hm.get(555)+"";


			Map<Integer, List<String>> mapValues = new HashMap<Integer, List<String>>();
			int repeatingGroupsCount = 0;

			mapValues.putAll(mvp);

			for (Map.Entry<Integer, List<String>> map : mapValues.entrySet()) 
			{
				if (repeatingGroupsCount < map.getValue().size()) 
				{
					repeatingGroupsCount = map.getValue().size();
				}
			}

			System.out.println("Leg Size: "+repeating_group_message.size());


			for (int j = 0; j < repeating_group_message.size(); j++) 
			{

				Map <String,String> tmp_map= new HashMap<>();
				for (Map.Entry<Integer, List<String>> map : mapValues.entrySet()) 
				{
					if (!(map.getValue().size() < j + 1))
					{
						tmp_map.put(""+map.getKey(),map.getValue().get(j).toString());										
					}

				}

				System.out.println("Iterating Leg number: "+j);

				if(tmp_map.containsKey("654") && repeating_group_message.get(j).contains("654="))
				{
					fix_message=fix_message+"654="+tmp_map.get("654")+"";
				}
				if(tmp_map.containsKey("600") && repeating_group_message.get(j).contains("600="))
				{
					fix_message=fix_message+"600="+tmp_map.get("600")+"";
				}
				if(tmp_map.containsKey("608") && repeating_group_message.get(j).contains("608="))
				{
					fix_message=fix_message+"608="+tmp_map.get("608")+"";
				}
				if(tmp_map.containsKey("611") && repeating_group_message.get(j).contains("611="))
				{
					fix_message=fix_message+"611="+tmp_map.get("611")+"";
				}
				if(tmp_map.containsKey("612") && repeating_group_message.get(j).contains("612="))
				{
					fix_message=fix_message+"612="+tmp_map.get("612")+"";
				}
				if(tmp_map.containsKey("623") && repeating_group_message.get(j).contains("623="))
				{
					fix_message=fix_message+"623="+tmp_map.get("623")+"";
				}
				if(tmp_map.containsKey("624") && repeating_group_message.get(j).contains("624="))
				{
					fix_message=fix_message+"624="+tmp_map.get("624")+"";
				}
				if(tmp_map.containsKey("564") && repeating_group_message.get(j).contains("564="))
				{
					fix_message=fix_message+"564="+tmp_map.get("564")+"";
				}

			}
		}
		else
		{

			//23041CRFIX_44838=FIX.4.49=023735=849=IB56=CR34=352=20191121-19:22:34.7401=094023361X37=OAK0000309619KOFS17138=600660=20191121-19:22:34.74015=USD40=159=054=139=8150=8103=111=2019112100000003373420=055=C63=058=Order Reject10=218

			fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"52="+hm.get(52)+""+"1="+hm.get(1)+""+"37="+hm.get(37)+""+"38="+hm.get(38)+""+"60="+hm.get(60)+""+"15="+hm.get(15)+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"103="+hm.get(103)+""+"11="+hm.get(11)+""+"20="+hm.get(20)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";



			if(hm.containsKey(63))
			{
				fix_message+="63="+hm.get(63)+"";
			}

			if(hm.containsKey(64))
			{
				fix_message+="64="+hm.get(64)+"";
			}

			if(hm.containsKey(75))
			{
				fix_message+="75="+hm.get(75)+"";
			}

			if(hm.containsKey(167))
			{
				fix_message+="167="+hm.get(167)+"";
			}
		}


		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Reject message: "+ fix_message);

		return fix_message;

	}


	String generateTradeCorrection()
	{

		String Tag34= genSeq();


		generateTradeCorrect();

		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}



		System.out.println(hm.size());



		hm.put(37, reportDate + hm.get(11));
		hm.put(99999,hm.get(56)); // Use this as tmp key
		hm.put(56,hm.get(49));
		hm.put(49, hm.get(99999));

		hm.put(19,hm.get(17));
		hm.put(14, this.cum_qty);
		hm.put(151,""+this.leavesQty);
		hm.put(6,""+average_price);	
		hm.put(20,"2");
		hm.put(31,""+last_price);
		hm.put(150,"G");
		hm.put(58,"Trade Correction");
		hm.put(34, Tag34);


		String header= generateAppiaHeader(Tag34);

		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);
		hm.remove(99999);



		String fix_msg=hm.toString();



		fix_msg= fix_msg.replaceAll("\\{", "");
		fix_msg= fix_msg.replaceAll("\\}", "");
		fix_msg= fix_msg.replaceAll(", ", "");
		fix_msg= fix_msg.concat("");
		fix_msg= fix_msg.concat("10=245");

		fix_msg=session_msg+""+fix_msg;

		fix_msg=header+fix_msg;

		//	System.out.println("gen message: "+fix_msg);		

		return fix_msg;


	}



	String generatePReplace()
	{



		String Tag34= genSeq();

		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}

		hm.put(37, reportDate + hm.get(11));


		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"CR");
		}

		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
			{

				hm.put(56,"IB");
			}
			else
			{
				hm.put(56,"NYSE");
			}
		}




		hm.put(49, hm.get(99999));




		hm.put(39, "E");
		hm.put(150,"E");
		hm.put(151,hm.get(38));
		hm.put(58,"Pending Replace");
		hm.put(34,Tag34);



		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);



		String fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"52="+hm.get(52)+""+"1="+hm.get(1)+""+"37="+hm.get(37)+""+"38="+hm.get(38)+""+"60="+hm.get(60)+""+"15="+hm.get(15)+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"41="+hm.get(41)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";

		if(hm.containsKey(63))
		{
			fix_message+="63="+hm.get(63)+"";
		}

		if(hm.containsKey(64))
		{
			fix_message+="64="+hm.get(64)+"";
		}

		if(hm.containsKey(75))
		{
			fix_message+="75="+hm.get(75)+"";
		}
		if(hm.containsKey(167))
		{
			fix_message+="167="+hm.get(167)+"";
		}




		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Pending Cancel Replace message: "+ fix_message);

		return fix_message;






		//	String fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+



		//	String fix_msg=hm.toString();


		//	fix_msg= fix_msg.replaceAll("\\{", "");
		//	fix_msg= fix_msg.replaceAll("\\}", "");
		//	fix_msg= fix_msg.replaceAll(", ", "");
		//	fix_msg= fix_msg.concat("");
		//	fix_msg= fix_msg.concat("10=245");

		//	fix_msg=session_msg+""+fix_msg;

		//	fix_msg=header+fix_msg;

		//	System.out.println("gen message: "+fix_msg);		

		//	return fix_msg;
	}




	String generateRplAck()
	{
		String Tag34= genSeq();

		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}



		System.out.println(hm.size());



		hm.put(37, reportDate + hm.get(11));
		hm.put(99999,hm.get(56)); // Use this as tmp key
		hm.put(56,hm.get(49));
		hm.put(49, hm.get(99999));
		hm.put(39, "5");
		hm.put(150,"5");
		hm.put(58,"Order Replaced");
		hm.put(34, Tag34);
		hm.put(20,"0");
		hm.put(32,hm.get(38));



		String header= generateAppiaHeader(Tag34);

		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);
		hm.remove(99999);


		//23041CRFIX_44838=FIX.4.49=023735=849=IB56=CR34=352=20191121-14:46:05.8521=094023361X37=OAK0000309619KOFS16338=600660=20191115-10:44:52.67415=USD40=159=054=139=0150=011=2019112100000003373320=055=C63=058=New Order10=218


		String fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"52="+hm.get(52)+""+"1="+hm.get(1)+""+"32="+hm.get(32)+""+"37="+hm.get(37)+""+"38="+hm.get(38)+""+"60="+hm.get(60)+""+"15="+hm.get(15)+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"41="+hm.get(41)+""+"20="+hm.get(20)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";

		if(hm.containsKey(63))
		{
			fix_message+="63="+hm.get(63)+"";
		}

		if(hm.containsKey(64))
		{
			fix_message+="64="+hm.get(64)+"";
		}

		if(hm.containsKey(75))
		{
			fix_message+="75="+hm.get(75)+"";
		}

		if(hm.containsKey(167))
		{
			fix_message+="167="+hm.get(167)+"";
		}



		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Cancel Replace message: "+ fix_message);

		return fix_message;


		//	String fix_msg=hm.toString();



		//	fix_msg= fix_msg.replaceAll("\\{", "");
		//	fix_msg= fix_msg.replaceAll("\\}", "");
		//	fix_msg= fix_msg.replaceAll(", ", "");
		//	fix_msg= fix_msg.concat("");
		//	fix_msg= fix_msg.concat("10=245");

		//	fix_msg=session_msg+""+fix_msg;

		//	fix_msg=header+fix_msg;

		//	System.out.println("gen message: "+fix_msg);		

		//	return fix_msg;

	}


	String generateTradeCancel()
	{

		String Tag34= genSeq();


		generateTradeCorrect();

		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}



		System.out.println(hm.size());



		hm.put(37, reportDate + hm.get(11));
		hm.put(99999,hm.get(56)); // Use this as tmp key
		hm.put(56,hm.get(49));
		hm.put(49, hm.get(99999));

		hm.put(19,hm.get(17));
		hm.put(14, "0");
		hm.put(151,hm.get(38));
		hm.put(6,"0");	
		hm.put(20,"1");
		hm.put(31,"0");
		hm.put(32,"0");
		hm.put(150,"H");
		hm.put(58,"Trade Cancel");

		String header= generateAppiaHeader(Tag34);

		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);
		hm.remove(99999);




		//	String fix_msg=hm.toString();



		String fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"52="+hm.get(52)+""+"1="+hm.get(1)+""+"37="+hm.get(37)+""+"21="+hm.get(21)+""+"38="+hm.get(38)+""+"6="+hm.get(6)+""+"60="+hm.get(60)+""+"40="+hm.get(40)+""+"59="+hm.get(59)+""+"54="+hm.get(54)+""+"151="+hm.get(151)+""+"14="+hm.get(14)+""+"39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"17="+hm.get(17)+""+"19="+hm.get(19)+""+"20="+hm.get(20)+""+"32="+hm.get(32)+""+"31="+hm.get(31)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+""+"76=POST"+"";

		if(hm.containsKey(63))
		{
			fix_message+="63="+hm.get(63)+"";
		}

		if(hm.containsKey(64))
		{
			fix_message+="64="+hm.get(64)+"";
		}

		if(hm.containsKey(75))
		{
			fix_message+="75="+hm.get(75)+"";
		}

		if(hm.containsKey(167))
		{
			fix_message+="167="+hm.get(167)+"";
		}




		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Trade burst message: "+ fix_message);

		return fix_message;


	}



	String generateOrderCancel()
	{


		String Tag34= genSeq();



		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}


		hm.put(37, reportDate + hm.get(11));

		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"CR");
		}

		// Use this as tmp key
		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
			{

				hm.put(56,"IB");
			}
			else
			{
				hm.put(56,"NYSE");
			}
		}
		hm.put(49, hm.get(99999));
		hm.put(14,"0");
		hm.put(20,"0");
		hm.put(39, "4");
		hm.put(150,"4");
		hm.put(151,hm.get(38));
		hm.put(58,"Order canceled");
		hm.put(34,Tag34);

		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);


		//23041CRFIX_44838=FIX.4.49=023735=849=IB56=CR34=352=20191121-14:46:05.8521=094023361X37=OAK0000309619KOFS16338=600660=20191115-10:44:52.67415=USD40=159=054=139=0150=011=2019112100000003373320=055=C63=058=New Order10=218


		String fix_message=null;

		
			fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"52="+hm.get(52)+"";
			
			if(hm.containsKey(1))
			{
				fix_message+="1="+hm.get(1)+"";
			}
			fix_message+="37="+hm.get(37)+"";
			if(hm.containsKey(38))
			{
				fix_message+="38="+hm.get(38)+"";
			}
			fix_message+="60="+hm.get(60)+"";
			if(hm.containsKey(54))
			{
			fix_message+="54="+hm.get(54)+"";
			}
			fix_message+="39="+hm.get(39)+""+"150="+hm.get(150)+""+"11="+hm.get(11)+""+"41="+hm.get(41)+""+"20="+hm.get(20)+"";
			
			
			if(hm.containsKey(55))
			{
				fix_message=fix_message+"55="+hm.get(55)+"";
			}
			fix_message=fix_message+"58="+hm.get(58)+"";


			if(hm.containsKey(63))
			{
				fix_message+="63="+hm.get(63)+"";
			}

			if(hm.containsKey(64))
			{
				fix_message+="64="+hm.get(64)+"";
			}

			if(hm.containsKey(75))
			{
				fix_message+="75="+hm.get(75)+"";
			}

			if(hm.containsKey(167))
			{
				fix_message+="167="+hm.get(167)+"";
			}

		


		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Cancel  message: "+ fix_message);

		return fix_message;

	}


	String generateOrderCancelReject()
	{

		String Tag34= genSeq();



		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=9";

		}

		//	System.out.println(hm.size());
		//String tmp_seq= (String)hm.get(34);
		//seq = Integer.parseInt(tmp_seq)+1;




		hm.put(37, reportDate + hm.get(11));

		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"CR");
		}

		// Use this as tmp key
		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
			{

				hm.put(56,"IB");
			}
			else
			{
				hm.put(56,"NYSE");
			}
		}
		hm.put(49, hm.get(99999));
		hm.put(14,"0");
		hm.put(20,"0");
		hm.put(39, "8");
		//hm.put(150,"8");
		hm.put(151,hm.get(38));
		hm.put(58,"Order cancel Reject");
		hm.put(34,Tag34);
		hm.put(102,"1");
		hm.put(434, "1");
		hm.put(17, genExecId());

		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);


		//23041CRFIX_44838=FIX.4.49=023735=849=IB56=CR34=352=20191121-14:46:05.8521=094023361X37=OAK0000309619KOFS16338=600660=20191115-10:44:52.67415=USD40=159=054=139=0150=011=2019112100000003373320=055=C63=058=New Order10=218


		String fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"52="+hm.get(52)+""+"1="+hm.get(1)+""+"37="+hm.get(37)+""+"60="+hm.get(60)+""+"39="+hm.get(39)+""+"102="+hm.get(102)+""+"434="+hm.get(434)+""+"11="+hm.get(11)+""+"41="+hm.get(41)+""+"20="+hm.get(20)+""+"17="+hm.get(17)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";


		if(hm.containsKey(63))
		{
			fix_message+="63="+hm.get(63)+"";
		}

		if(hm.containsKey(64))
		{
			fix_message+="64="+hm.get(64)+"";
		}

		if(hm.containsKey(75))
		{
			fix_message+="75="+hm.get(75)+"";
		}

		if(hm.containsKey(167))
		{
			fix_message+="167="+hm.get(167)+"";
		}



		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Cancel  Reject message: "+ fix_message);

		return fix_message;


	}



	String generateOrderReplaceReject()
	{
		String Tag34= genSeq();



		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			System.out.println("am i here????");
			session_msg+=""+"35=9";

		}
		else
		{
			session_msg+=""+"35=9";
		}

		System.out.println("session data: "+session_msg);

		//	System.out.println(hm.size());
		//String tmp_seq= (String)hm.get(34);
		//seq = Integer.parseInt(tmp_seq)+1;




		hm.put(37, reportDate + hm.get(11));

		if(hm.containsKey(56))
		{
			hm.put(99999,hm.get(56));
		}
		else
		{
			hm.put(99999,"CR");
		}

		// Use this as tmp key
		if(hm.containsKey(49))
		{
			hm.put(56,hm.get(49));
		}
		else
		{
			if(fix_protol_version.equalsIgnoreCase("FIX.4.2"))
			{

				hm.put(56,"IB");
			}
			else
			{
				hm.put(56,"NYSE");
			}
		}
		hm.put(49, hm.get(99999));
		hm.put(14,"0");
		hm.put(20,"0");
		hm.put(39, "0");
		//hm.put(150,"8");
		hm.put(151,hm.get(38));
		hm.put(58,"Order Replace Reject");
		hm.put(34,Tag34);
		hm.put(102,"1");	//1 = unknown order
		hm.put(434, "2");	//
		hm.put(17, genExecId());
		hm.put(32,"0");

		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);


		//23041CRFIX_44838=FIX.4.49=023735=849=IB56=CR34=352=20191121-14:46:05.8521=094023361X37=OAK0000309619KOFS16338=600660=20191115-10:44:52.67415=USD40=159=054=139=0150=011=2019112100000003373320=055=C63=058=New Order10=218


		String fix_message=""+"49="+hm.get(49)+""+"56="+hm.get(56)+""+"34="+hm.get(34)+""+"52="+hm.get(52)+""+"1="+hm.get(1)+""+"37="+hm.get(37)+""+"14="+hm.get(14)+""+"32="+hm.get(32)+""+"38="+hm.get(38)+""+"60="+hm.get(60)+""+"54="+hm.get(54)+""+"39="+hm.get(39)+""+"102="+hm.get(102)+""+"434="+hm.get(434)+""+"11="+hm.get(11)+""+"41="+hm.get(41)+""+"20="+hm.get(20)+""+"17="+hm.get(17)+""+"55="+hm.get(55)+""+"58="+hm.get(58)+"";


		if(hm.containsKey(63))
		{
			fix_message+="63="+hm.get(63)+"";
		}

		if(hm.containsKey(64))
		{
			fix_message+="64="+hm.get(64)+"";
		}

		if(hm.containsKey(75))
		{
			fix_message+="75="+hm.get(75)+"";
		}

		if(hm.containsKey(167))
		{
			fix_message+="167="+hm.get(167)+"";
		}



		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Replace Reject message: "+ fix_message);

		return fix_message;

	}


	public void setSettlementDate()
	{

		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		Date currentDate = new Date();
		System.out.println(df.format(currentDate));

		// convert date to calendar
		Calendar c = Calendar.getInstance();
		c.setTime(currentDate);

		// manipulate date
		//  c.add(Calendar.YEAR, 1);
		// c.add(Calendar.MONTH, 1);
		c.add(Calendar.DATE, 3); //same with c.add(Calendar.DAY_OF_MONTH, 1);
		// c.add(Calendar.HOUR, 1);
		// c.add(Calendar.MINUTE, 1);
		//  c.add(Calendar.SECOND, 1);

		// convert calendar to date
		Date currentDatePlusOne = c.getTime();

		settlement_date= df.format(currentDatePlusOne);

		System.out.println("Setting settlement date: "+settlement_date);

	}


	String generateOrderExpiry()
	{


		String Tag34= genSeq();



		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		Date date = new Date();


		int trade_date = Integer.parseInt(dateFormat.format(date));

		if(hm.containsKey(8))
		{
			session_msg="8="+hm.get(8);
		}
		if(hm.containsKey(9))
		{
			session_msg+=""+"9="+hm.get(9);
		}
		if(hm.containsKey(35))
		{
			session_msg+=""+"35=8";

		}




		//System.out.println(hm.size());		
		//String tmp_seq= (String)hm.get(34);
		//seq = Integer.parseInt(tmp_seq)+1;




		hm.put(37, reportDate + hm.get(11));
		hm.put(99999,hm.get(56)); // Use this as tmp key
		hm.put(56,hm.get(49));
		hm.put(49, hm.get(99999));

		hm.put(150,"C");
		hm.put(39,"C");



		hm.put(34, Tag34);
		hm.put(13,3);
		hm.put(12,"250.0");
		hm.put(14, this.cum_qty);
		hm.put(151,""+this.leavesQty);
		hm.put(32, this.lastshares);
		hm.put(6,""+average_price);
		hm.put(31,this.last_price);
		hm.put(17,genExecId());
		hm.put(75,trade_date);
		hm.put(21,"1");



		String header= generateAppiaHeader(Tag34);

		hm.remove(99999);
		hm.remove(8);
		hm.remove(9);
		hm.remove(10);
		hm.remove(35);


		//23041CRFIX_44838=FIX.4.49=026435=849=IB56=CR34=352=20191115-10:44:531=BBB111111XRRR37=OAK0000309619KOFS17521=138=60066=20.00000060=20191115-19:31:14.07040=159=054=1151=500614=100039=1150=111=2019112100000003373517=XID0000209619KOFS14620=032=100031=2055=C58=Partial Fill10=223
		String fix_message;



		try {
			Thread.sleep(200);

			setSettlementDate();

			Thread.sleep(200);
		}
		catch(Exception e)
		{

		}


		fix_message=""+"49=GBI"+""+"52="+hm.get(60)+""+"56=FMC"+""+"1="+hm.get(1)+""+"11="+hm.get(11)+""+"14="+hm.get(14)+""+"17="+hm.get(17)+""+"37="+hm.get(37)+"";

		if(hm.containsKey(38))
		{
			fix_message=fix_message+"38="+hm.get(38)+"";
		}
		else if(hm.containsKey(152))
		{
			fix_message=fix_message+"152="+hm.get(152)+"";
		}

		fix_message=fix_message+"39="+hm.get(39)+""+"41="+hm.get(11)+""+"54="+hm.get(54)+""+"55="+hm.get(55)+""+"60="+hm.get(60)+""+"75="+hm.get(75)+""+"150="+hm.get(150)+""+"151="+hm.get(151)+"";


		fix_message=session_msg+fix_message;

		System.out.println("Generated FIX message prior to checksum: "+fix_message);

		int value_1 = cs.checksum(fix_message);


		fix_message=fix_message+"10="+value_1+"";

		System.out.println("With checksum: "+fix_message);

		fix_message=header+fix_message;

		System.out.println("Final Partial fill message: "+ fix_message);

		return fix_message;



	}
}
