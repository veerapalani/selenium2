package qa.testng.simulator;
import java.nio.charset.Charset;


public class CheckSum {

	
	/**
     * Calculates the checksum for the given data.
     *
     * @param data the data to calculate the checksum on
     * @param isEntireMessage specifies whether the data is an entire message;
     *        if true, and it ends with a checksum field, that checksum
     *        field is excluded from the current checksum calculation
     * @return the calculated checksum
     */
    public static int checksum(byte[] data, boolean isEntireMessage) {
        int sum = 0;
        int len = data.length;
        if (isEntireMessage && data[len - 8] == '\001' && data[len - 7] == '1'
                && data[len - 6] == '0' && data[len - 5] == '=')
            len = len - 7;
        for (int i = 0; i < len; i++) {
            sum += (data[i] & 0xFF);
        }
        return sum & 0xFF; // better than sum % 256 since it avoids overflow issues
    }

    /**
     * Calculates the checksum for the given data.
     *
     * @param charset the charset used in encoding the data
     * @param data the data to calculate the checksum on
     * @param isEntireMessage specifies whether the data is an entire message;
     *        if true, and it ends with a checksum field, that checksum
     *        field is excluded from the current checksum calculation
     * @return the calculated checksum
     */
    public static int checksum(Charset charset, String data, boolean isEntireMessage) {
        if (CharsetSupport.isStringEquivalent(charset)) { // optimization - skip charset encoding
            int sum = 0;
            int end = isEntireMessage ? data.lastIndexOf("\00110=") : -1;
            int len = end > -1 ? end + 1 : data.length();
            for (int i = 0; i < len; i++) {
                sum += data.charAt(i);
            }
            return sum & 0xFF; // better than sum % 256 since it avoids overflow issues
        }
        return checksum(data.getBytes(charset), isEntireMessage);
    }

    /**
     * Calculates the checksum for the given message
     * (excluding existing checksum field, if one exists).
     * The {@link CharsetSupport#setCharset global charset} is used.
     *
     * @param message the message to calculate the checksum on
     * @return the calculated checksum
     */
    public static int checksum(String message) {
        return checksum(CharsetSupport.getCharsetInstance(), message, true);
    }
    
    
    
    
    public static void main(String args[])
    {
    	
    	CheckSum cs= new CheckSum();
    	int value = checksum("8=FIX.4.49=19235=81=ABC123451XABC6=011=2019111300000000000814=015=USD336=STANDARD528=A18=520=022=8150=8151=034=337=201911132019111300000000000838=555539=8103=840=148=EA49=UNICORN_INT_ORDERS_0352=20191113-08:26:30.68554=155=NFLX56=UNICORN_INT_TRADES_03377=N58=Order Reject59=060=20191113-08:26:30.68563=0");
    	System.out.println("value is: "+value);
    }
	
	
}
