package qa.testng.simulator;
import static io.restassured.RestAssured.given;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APIPost {
	
	public static RequestSpecification requestSpecification = given();
	
	
	public String generateAPIResponseBody(String msg, String asset_type)
	{
		System.out.println("Recieved message: "+msg);
		
		
		
		msg=msg.replaceAll("","|");
		
		String tmp[] = null;
		
		if(asset_type.equalsIgnoreCase("METAL"))
		{
			 tmp=msg.split("8=FIX.4.4");
		}
		else if(asset_type.equalsIgnoreCase("MLEG"))
		{
			 tmp=msg.split("8=FIX.4.2");
		}
				
		
		System.out.println("Array size: "+tmp.length);
		
		System.out.println("Part 1: "+tmp[0].toString());
		
		System.out.println("Part 2: "+tmp[1].toString());
		
		msg=tmp[1].toString().replaceAll("\\|\\|","");
		
		if(asset_type.equalsIgnoreCase("METAL"))
		{
			msg="8=FIX.4.4"+msg+"|";
		}
		else if(asset_type.equalsIgnoreCase("MLEG"))
		{
			msg="8=FIX.4.2"+msg+"|";
		}
				
		System.out.println("Post Formatting: "+msg);
		
		String input_source = null,fix_profile=null;
		
		if(asset_type.equalsIgnoreCase("METAL"))
		{
			input_source="GBI";
			fix_profile="FIX_4_4_EXCHANGE_GBI";
		}
		else if(asset_type.equalsIgnoreCase("MLEG"))
		{
			input_source="CBOE";
			fix_profile="FIX_4_2_EXCHANGE_CBOE";
		}
		
		
		String body="{\r\n" + 
				"    \"message\": {\r\n" + 
				"        \"mapping\": {\r\n" + 
				"            \"session\": \"N/A\",\r\n" + 
				"            \"inputSourceName\": \""+input_source+"\",\r\n" + 
				"            \"fixProfile\": \""+fix_profile+"\",\r\n" + 
				"            \"clientNumber\": \"\"\r\n" + 
				"        },\r\n" + 
				"        \"rawMessage\": \""+msg+"\"\r\n" + 
				"    },\r\n" + 
				"    \"delimiter\": \"|\"\r\n" + 
				"}";
		
		System.out.println("Generated response body: "+body);
		
		return body;
		
		
	}
	
	public void postAPIRequest(String url, String body) throws InterruptedException
	{
		
		
		 Response response= requestSpecification.contentType("application/json").header("X-Client-Number","string").body(body).post(url);
         
		 Thread.sleep(1000);
	        
	     System.out.println("****"+ response.body().asString());
	       
	      
	     
		
	}
	
	
	
	public static void main(String args[])
	{
		
		APIPost post= new APIPost();
		
		String ms="23041UNICORN_INT_ORDERS_03FIX_44088=FIX.4.49=36935=849=GBI52=20200414-12:13:45.42756=FMC1=099000501XRRR11=2020041400000000001914=60.017=WSR40722020041437=202004142020041400000000001938=60.0000039=241=2020041400000000001944=50.054=155=GGNAC60=20200414-12:13:45.42764=2020041775=20200414118=3990.0150=F151=0.0377=Y7162=10007164=990.09903=3000.020004=020035=1.1820006=10.0000000010=209";
		
		post.generateAPIResponseBody(ms,"METAL");
	}
	
	

}
