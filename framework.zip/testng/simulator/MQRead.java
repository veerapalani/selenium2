package qa.testng.simulator;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;

import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.log4j.Logger;

import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.ibm.msg.client.jms.JmsFactoryFactory;
import com.ibm.msg.client.wmq.WMQConstants;

public class MQRead {
	
	private static JmsConnectionFactory cf;
	private static Connection connection;
	private static Session session;
	private static MessageConsumer consumer;
	public static final Logger logger = Logger.getLogger(MQRead.class);
	
	
		
	
	public MQRead()
	{
		
		try {
			
			System.setOut(new PrintStream(new FileOutputStream("output.log")));
		} 
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
	}

	public static void main(String a[]) throws JMSException, InterruptedException
	{
		
		
	
		MessageReader mr = new MessageReader();
	
			
	JmsFactoryFactory ff = JmsFactoryFactory.getInstance(WMQConstants.WMQ_PROVIDER);
	
	cf = ff.createConnectionFactory();
	
	cf.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, "APPIAQM");
	

	
	cf.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
	cf.setIntProperty(WMQConstants.WMQ_PORT,1416);
	

	
	cf.setStringProperty(WMQConstants.WMQ_HOST_NAME, "10.152.225.7");
	

	
	cf.setStringProperty(WMQConstants.WMQ_CHANNEL, "APPIA.SVRCONN"); 
	System.out.println("Connection Factory created.");
	connection = cf.createConnection();
	System.out.println("Connection created.");
	session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	System.out.println("Session created.");
	
	
	Destination destination = session.createQueue("APPIAQ.INT.3.OUT");			//APPIAQ.DV1.1.IN APPIAQ.DV1.1.OUT
	
	System.out.println("Destination created: " + destination.toString());
	consumer = session.createConsumer(destination);
	System.out.println("Consumer created.");
	
	consumer.setMessageListener(new MessageListener() 
	{
	public void onMessage(Message msg) 
	{
			try {
				
						
				
				if (msg instanceof BytesMessage) 
				{

				      BytesMessage bytesMessage = (BytesMessage) msg;
				      byte[] data = new byte[(int) bytesMessage.getBodyLength()];
				      bytesMessage.readBytes(data);
				      
				      System.out.println(new String(data));
				      
				      logger.info(new String(data));
				      
					
				      if(new String(data).contains("CID")||new String(data).contains("VOL_WEIGHTED_AVG_PRICE")||new String(data).contains("PRICE_INLINE")||new String(data).contains("VOLUME_INLINE")||new String(data).contains("TAP_INLINE"))
				      {
				    	  
				    	  	  mr.readmessage(new String(data)); 
				    	 
				      }
				      else if(new String(data).contains("EXE")||new String(data).contains("PEN_NEW")||new String(data).contains("PENDING_NEW")||new String(data).contains("NEW_ACK")||new String(data).contains("AOM:#/")||new String(data).contains("URO")||new String(data).contains("REJ")||new String(data).contains("PENDING_CXL")||new String(data).contains("PENDING_RPL")||new String(data).contains("35=CX")||new String(data).contains("35=TXL")||new String(data).contains("PERF")||new String(data).contains("BURST"))
				      {
				    	  
				    
				    	  mr.read_messages(new String(data));
				    
				      }
				      else
				      {
				    	 
				    	  mr.readmessage(new String(data)); 
				     				      
				      }	
				      				
				   
				  } 
				else if (msg instanceof TextMessage) 
				{

				      TextMessage textMessage = (TextMessage) msg;
				      String text = textMessage.getText();
				      System.out.println("Message received {}"+text);
				      
				  
				    
				}
										
			
			} 
		catch (Exception e) {
		System.out.println("Exception caught in onMessage():\n" + e);
		}
			return;
	} 
	}); 
	connection.start();
	Thread.sleep(500000000);
	session.close();

	}

}
