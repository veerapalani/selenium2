package qa.testng.simulator;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.MultiHashMap;
import org.apache.commons.collections.map.MultiValueMap;

public class MessageReader 
{


	static int seq;
	ArrayList  <String> total_msg = new ArrayList<String>();
	ArrayList <String>  formatted_total_msg = new ArrayList<String>();
	
	private String output_message=null;
	private String floor_instruction;
	private String execution_instruction;
	ArrayList<String> keep_executions= new ArrayList<String>();
	Map<Integer, List<String>> map = new HashMap<>();
	List<String> list = new ArrayList<>();
	MultiValueMap  mp = new MultiValueMap();
	APIPost post= new APIPost();
	FIXSender fs = new FIXSender();
	private String m_leg_repeating_group_tags;

	static int genSeqNo()
	{

		int new_Seq = seq+200;
		// System.out.println("initial seq number is" + new_Seq );		commented for Ankur
		return new_Seq;
	}



	public void readmessage(String msg1)
	{

		ArrayList<String> repeating_fix_set=new ArrayList<String>();
		String tmp_buffer []=msg1.split("8=");

		String fix_message= "8="+tmp_buffer[1];

		System.out.println("Parsing FIX message: "+fix_message);

		String tmp_string[] = null;


		if(fix_message.contains("35=AB"))
		{
			System.out.println("This is a M-Leg Order");

			tmp_string=fix_message.split("167=MLEG");

			fix_message=tmp_string[0]+"167=MLEG";

			m_leg_repeating_group_tags=tmp_string[1];

			System.out.println("Repeating group set: "+m_leg_repeating_group_tags);
			
			
			
			
			String splitter[]=m_leg_repeating_group_tags.split("654=");
			
			for(int i=1;i<splitter.length;i++)
			{
				
				repeating_fix_set.add("654="+splitter[i]);
				
			}
			
			for(String s:repeating_fix_set)
			{
				System.out.println(s);
			}
			
			

			String tmp[]=m_leg_repeating_group_tags.split("");
						 
					
			fix_message=fix_message+tmp[0]+"";

			System.out.println("FIX Message minus repeating grp "+fix_message);
			
			
			for(String s:tmp)
			{
				System.out.println("Repeating group Key <> Value: "+s);	

				String tmp_fix_string [] = s.split("=");

				mp.put(tmp_fix_string[0],tmp_fix_string[1]);
				
			}
			
		}



		for(int i=0;i<fix_message.length();i++)
		{
			tmp_string = fix_message.split("");	
		}

		HashMap<Integer,String> hashMap = new HashMap<Integer,String>();



		for(int n=0;n<tmp_string.length;n++)
		{

			System.out.println("Key --> "+tmp_string[n]);	

			String tmp_fix_string [] = tmp_string[n].split("=");

			hashMap.put(Integer.parseInt(tmp_fix_string[0]), tmp_fix_string[1]); 



		}


		ExecutionReport er= new ExecutionReport(hashMap);

		if(hashMap.get(35).contentEquals("AB"))
		{
			System.out.println("Leg size: "+repeating_fix_set.size());
			ExecutionReport er_mleg= new ExecutionReport(hashMap,mp,repeating_fix_set);
			
			
			double qty= Double.parseDouble(hashMap.get(38));
			System.out.println("Qty is: "+qty);
			
			if(qty<300) // Only New order Reject 
			{
				
				try {
					
					Thread.sleep(200);
					
					output_message = er_mleg.generateOrderReject();
	
					String response_body=post.generateAPIResponseBody(output_message,"MLEG");
	
					post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);
	
					System.out.println("Sent API M-LEG Reject to topic");
					
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

			}
					
			
			if(qty>=300) // Only New order Ack 
			{
				
				try {
					
					Thread.sleep(200);
					
					output_message = er_mleg.generateNewAck();
	
					String response_body=post.generateAPIResponseBody(output_message,"MLEG");
	
					post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);
	
					System.out.println("Sent API M-LEG Ack to topic");
					
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

			}
			
			if(qty>=500)
			{
			try {
				
				output_message = er_mleg.generateFill(1);

				String response_body=post.generateAPIResponseBody(output_message,"MLEG");

				post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);

				System.out.println("Sent API M-LEG Ack to topic");
				
			
				for(int i=0;i<repeating_fix_set.size();i++)
				{
					output_message = er_mleg.generateLegExecutions(i);
					
					response_body=post.generateAPIResponseBody(output_message,"MLEG");
	
					post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);
	
					System.out.println("Sent API M-LEG Ack to topic");
				}
			
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
					
			}	
			if(qty>=800)
			{
				
				try {
					
					output_message = er_mleg.generateFill(2);
	
					String response_body=post.generateAPIResponseBody(output_message,"MLEG");
	
					post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);
	
					System.out.println("Sent API M-LEG Ack to topic");
					
				
					for(int i=0;i<repeating_fix_set.size();i++)
					{
						output_message = er_mleg.generateLegExecutions(i);
						
						response_body=post.generateAPIResponseBody(output_message,"MLEG");
		
						post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);
		
						System.out.println("Sent API M-LEG Ack to topic");
					}
				
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				
			}
			
		}
		
		else if(hashMap.get(35).contentEquals("R")) 
		{
			System.out.println("Quote Request");
			
			output_message=er.QuoteAck();

			fs.sendMessage(output_message);

			System.out.println("New Quote Ack generated: "+output_message);
			
		}
		
		else if(hashMap.containsKey(228)|| hashMap.containsKey(423)) 
		{
			System.out.println("Dont do anything as its FI Flow");
					
			
		}
		
		else if(hashMap.get(35).contentEquals("D"))
		{

			if((!hashMap.containsKey(58)) && hashMap.get(40).equalsIgnoreCase("1") && hashMap.get(59).equalsIgnoreCase("0") && (Double.parseDouble(hashMap.get(38))<=100)|| hashMap.get(55).equalsIgnoreCase("PINKX"))
			{

				
				output_message=er.generatePNew();

				fs.sendMessage(output_message);

				System.out.println("New P.New generated: "+output_message);

				output_message = er.generateNewAck();

				fs.sendMessage(output_message);

				System.out.println("New Ack generated: "+output_message);

				try {
					Thread.sleep(500);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				output_message= er.generateFill(2);

				fs.sendMessage(output_message);

				System.out.println("Fills: "+output_message);



			}
			
			else if(hashMap.get(55).matches("[A-B].*")||hashMap.get(55).matches("GSNCC")||hashMap.get(55).matches("[CAD].*")) // Only New order Ack //GGNAC/GSNCC is a metal order
			{

				output_message=er.generatePNew();

				fs.sendMessage(output_message);

				System.out.println("New P.New generated: "+output_message);


				output_message = er.generateNewAck();

				fs.sendMessage(output_message);

				System.out.println("New Ack generated: "+output_message);


			}

			else if(hashMap.get(55).matches("[C-G].*")) // New- Partial Fills upto order qty
			{

				try {
					output_message=er.generatePNew();

					//fs.sendMessage(output_message);

					//System.out.println("New P.New generated: "+output_message);


					output_message = er.generateNewAck();

					fs.sendMessage(output_message);

					//	System.out.println("New Ack generated: "+output_message);

					output_message= er.generateFill(1);

					fs.sendMessage(output_message);



					System.out.println("Fill generated 1: "+output_message);

					Thread.sleep(500);

					output_message= er.generateFill(1);

					fs.sendMessage(output_message);

					System.out.println("Fill generated 2: "+output_message);

					Thread.sleep(500);

					output_message= er.generateFill(2);

					fs.sendMessage(output_message);

					System.out.println("Fill generated 3: "+output_message);

					Thread.sleep(500);


					//	output_message=er.generateOrderExpiry();

					//	fs.sendMessage(output_message);

					//	System.out.println("Order Exp: "+output_message);

				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

			}

			else if(hashMap.get(55).matches("[H-K].*")) // New- and multiple partial Fills
			{

				output_message=er.generatePNew();

				fs.sendMessage(output_message);

				System.out.println("New P.New generated: "+output_message);


				output_message = er.generateNewAck();

				fs.sendMessage(output_message);

				System.out.println("New Ack generated: "+output_message);

				output_message= er.generateFill(1);

				fs.sendMessage(output_message);

				System.out.println("Fill generated 1: "+output_message);

				output_message= er.generateFill(1);

				fs.sendMessage(output_message);

				System.out.println("Fill generated 2: "+output_message);


			}


			else if(hashMap.get(55).matches("[L-M].*")) // New order full fills
			{

				output_message=er.generatePNew();

				fs.sendMessage(output_message);

				System.out.println("New P.New generated: "+output_message);

				output_message = er.generateNewAck();

				fs.sendMessage(output_message);

				System.out.println("New Ack generated: "+output_message);

				try {
					Thread.sleep(500);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				output_message= er.generateFill(2);

				fs.sendMessage(output_message);

				System.out.println("Fills: "+output_message);


			}

			else if(hashMap.get(55).matches("[N-P].*")||hashMap.get(55).matches("[USD].*")) // order reject // hashMap.get(55).matches("[USD].*")) added to support FX USD/CAN curr pair.
			{

				output_message=er.generatePNew();

				//fs.sendMessage(output_message);

				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				output_message=er.generateOrderReject();

				fs.sendMessage(output_message);

				System.out.println("rejected order is: "+output_message);

			}

			else if(hashMap.get(55).matches("[Q-S].*")) // Trade Correct
			{

				output_message=er.generatePNew();

				//	fs.sendMessage(output_message);

				System.out.println("New P.New generated: "+output_message);

				output_message = er.generateNewAck();

				fs.sendMessage(output_message);

				System.out.println("New Ack generated: "+output_message);

				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				output_message= er.generateFill(2);

				fs.sendMessage(output_message);

				System.out.println("Fills: "+output_message);


				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				output_message = er.generateTradeCorrection();

				System.out.println("Trade Correction msg: "+output_message);

				fs.sendMessage(output_message);
			}

			else if(hashMap.get(55).matches("[T-Z].*")) // Trade Cancel
			{

				output_message=er.generatePNew();

				fs.sendMessage(output_message);

				System.out.println("New P.New generated: "+output_message);

				output_message = er.generateNewAck();

				fs.sendMessage(output_message);

				System.out.println("New Ack generated: "+output_message);



				try {
					Thread.sleep(1000);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

			
				output_message= er.generateFill(2);

				fs.sendMessage(output_message);

			


				try {

					Thread.sleep(5000);
				}catch(Exception e)
				{

				}

				output_message = er.generateTradeCancel();

				System.out.println("Trade Cancel msg: "+output_message);

				fs.sendMessage(output_message);



			}

			


		}
		else if(hashMap.get(35).contentEquals("G"))
		{

			FIXSender fs = new FIXSender();

			if(hashMap.get(55).matches("[A].*")||hashMap.get(55).matches("[B-X].*")||hashMap.get(55).matches("[Z].*")) // Only New order Ack
			{

				output_message=er.generatePReplace();

				fs.sendMessage(output_message);

				System.out.println("New P.Rpl generated: "+output_message);

				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				output_message = er.generateRplAck();

				fs.sendMessage(output_message);

				System.out.println("Rpl Ack generated: "+output_message);


			}

			else if(hashMap.get(55).matches("[Y].*")) // Only New order Ack
			{

				//output_message=er.generatePReplace();

				//fs.sendMessage(output_message);

				System.out.println("New P.Rpl generated: "+output_message);

				try {

					Thread.sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				output_message = er.generateOrderReplaceReject();

				fs.sendMessage(output_message);

				System.out.println("Order REPLACE reject generated: "+output_message);


			}



		}

		else if(hashMap.get(35).contentEquals("F"))
		{
			FIXSender fs = new FIXSender();
			
			
			if(hashMap.containsKey(55)) {
			if(hashMap.get(55).matches("[A].*")) // Order cancel Ack
			{


				output_message = er.generateOrderCancel();

				fs.sendMessage(output_message);

				System.out.println("Order cancel generated: "+output_message);


			}

			if(hashMap.get(55).matches("GSNCC"))
			{

				output_message = er.generateOrderCancel();

				fs.sendMessage(output_message);

				System.out.println("Order cancel generated: "+output_message);

				try {
					Thread.sleep(5000);
				}
				catch(Exception e)
				{

				}

				output_message = er.generateOrderExpiry();
				fs.sendMessage(output_message);

				System.out.println(" Generate Order Exp: "+output_message);

			}


			else if(hashMap.get(55).matches("BAC")||hashMap.get(55).matches("GGNOK"))
			{


				output_message = er.generateOrderCancelReject();

				fs.sendMessage(output_message);

				System.out.println("Order cancel reject generated: "+output_message);


			}
			else if(hashMap.get(55).matches("[B-Z].*"))
			{

				output_message = er.generateOrderCancel();

				fs.sendMessage(output_message);

				System.out.println("Order cancel generated: "+output_message);

			}
			}
			else
			{
				output_message = er.generateOrderCancel();

				fs.sendMessage(output_message);

				System.out.println("Order cancel generated: "+output_message);

			}


		}


	}




	public void read_messages(String msg1)
	{

		

		String tmp_buffer []=msg1.split("8=");

		String fix_message= "8="+tmp_buffer[1];

		System.out.println("Parsing FIX message: "+fix_message);

		String tmp_string[] = null;



		for(int i=0;i<fix_message.length();i++)
		{


			tmp_string = fix_message.split("");


		}

		HashMap<Integer,String> hashMap = new HashMap<Integer,String>();


		for(int n=0;n<tmp_string.length;n++)
		{

			System.out.println("Key --> "+tmp_string[n]);	

			String tmp_fix_string [] = tmp_string[n].split("=");

			hashMap.put(Integer.parseInt(tmp_fix_string[0]), tmp_fix_string[1]); //the hashMap will have key=value data for incoming orders // New order, Clx Rpl, Cancel message


			if(tmp_fix_string.length>2)
			{

				System.out.println("Tag 58 value: "+tmp_fix_string[2].toString());

				execution_instruction=tmp_fix_string[2].toString();


			}




		}

		
		ExecutionReportNew er= new ExecutionReportNew(hashMap);
		FIXSender fs = new FIXSender();

		if(hashMap.containsKey(58))
		{

			floor_instruction= hashMap.get(58).toString();

			System.out.println("1 Floor Inst: "+floor_instruction);

			System.out.println("EXEC INST: "+execution_instruction);


			if(execution_instruction!=null)
			{


				System.out.println("adding : "+execution_instruction);
				floor_instruction+=execution_instruction;
				execution_instruction=null; 



			}

			System.out.println("Instruction to ECN: "+floor_instruction.trim());
		}

		else
		{

			System.out.println("Tag 58 value is not present Maybe GBI Order "+ hashMap.get(35));

		}

		if(hashMap.get(35).equalsIgnoreCase("CX"))
		{

			System.out.println("GBI Replace req");



			try {

				if(hashMap.get(55).equalsIgnoreCase("GGNTZ"))
				{


					output_message=er.generateGBIError();
					String response_body=post.generateAPIResponseBody(output_message,"METAL");

					post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);

					System.out.println("Sent API GBI Error Ack into topic");


				}
				else
				{


					output_message=er.generateGBICorrectPAck();

					String response_body=post.generateAPIResponseBody(output_message,"METAL");

					post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);

					System.out.println("Sent API P.Ack into topic");



					output_message=er.generateGBICorrectSAck();


					String response_SAck=post.generateAPIResponseBody(output_message,"METAL");

					post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_SAck);

					System.out.println("Sent API req into topic");
				}



			}
			catch(Exception e)
			{
				e.printStackTrace();
			}


		}
		else if(hashMap.containsKey(228)|| hashMap.containsKey(423)) 
		{
			System.out.println("Dont do anything as its FI Flow");
					
			
		}

		else if(hashMap.get(35).equalsIgnoreCase("D"))
		{

			System.out.println("New order request");

			if(floor_instruction.equalsIgnoreCase("PEN_NEW")||floor_instruction.equalsIgnoreCase("PENDING_NEW"))
			{

				output_message=er.generatePNew();

				fs.sendMessage(output_message);


			}
			else if(floor_instruction.equalsIgnoreCase("NEW_ACK")||floor_instruction.contains("EXE:0@0")||floor_instruction.equalsIgnoreCase("AOM:#/EXE:#0.0")||floor_instruction.equalsIgnoreCase("AOM:#/EXE:#=0.0")||floor_instruction.equalsIgnoreCase("AOM:#/EXE:#0@0"))  //AOM:#/EXE:#=0@0
			{
				output_message=er.generatePNew();

				fs.sendMessage(output_message);

				System.out.println("New P.New generated: "+output_message);


				output_message = er.generateNewAck();

				fs.sendMessage(output_message);

				System.out.println("New Ack generated: "+output_message);

			}
			else if(floor_instruction.contains("EXE:")||floor_instruction.contains("AOM:#/EXE:#"))
			{

				System.out.println("Execution px n qty: "+floor_instruction);



				//60@50.5;60@20.5

				String []exec_commands=floor_instruction.split(";");

				System.out.println("Size of exec comm array: "+exec_commands.length);


				System.out.println("First index: "+exec_commands[0]);



				//EXE:#=60@50.5,60@20.5;URO"

				String fill_inst[]=exec_commands[0].split("[:#]");
				String px_vs_qty[] = null;



				for(int i=0;i<fill_inst.length;i++)
				{
					System.out.println("INDEX: "+fill_inst[i].toString());

				}

				if(floor_instruction.contains("AOM:#/EXE:#")) 
				{

					if(!fill_inst[4].isEmpty())
					{
						System.out.println("Final list: "+fill_inst[4]);

						fill_inst[4]=fill_inst[4].replaceAll("[/]", "");

						px_vs_qty=fill_inst[4].split(",");

					}

				}

				else
				{

					if(!fill_inst[1].isEmpty())
					{
						System.out.println("Final list 1: "+fill_inst[1]);

						px_vs_qty=fill_inst[1].split(",");

					}
					else if(!fill_inst[2].isEmpty())
					{

						System.out.println("Final list 2: "+fill_inst[2]);

						px_vs_qty=fill_inst[2].split(",");
					}
				}

				System.out.println("Total number of executions to be generated: "+px_vs_qty.length);


				output_message=er.generatePNew();

				fs.sendMessage(output_message);

				System.out.println("New P.New generated: "+output_message);


				output_message = er.generateNewAck();

				fs.sendMessage(output_message);

				System.out.println("New Ack generated: "+output_message);


				for(int i=0;i<px_vs_qty.length;i++)
				{

					String exec_qty_px[]=px_vs_qty[i].split("@");

					System.out.println("Execution Qty: "+exec_qty_px[0]);
					System.out.println("Execution Price: "+exec_qty_px[1]);


					output_message= er.generateFill(exec_qty_px[0].trim(), exec_qty_px[1].trim());

					try {
						System.out.println("Running sleep before processing fills");
						Thread.sleep(2000);
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}

					if(hashMap.containsKey(20001))
					{

						try {


							String response_body=post.generateAPIResponseBody(output_message,"METAL");

							post.postAPIRequest("http://eisl-svc.us-east-1.int.unicornzoom.npd.bfsaws.net/kafka/topics/BR.FIX.RECEIVED.ZOOM.INT.INL.WMAP.TOPIC",response_body);

							System.out.println("Sent API req into topic");
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}

					}
					else
					{
						fs.sendMessage(output_message);

						System.out.println("New Fill generated: "+output_message);
					}



					try 
					{
						Thread.sleep(1000);
					}
					catch(Exception e)
					{


					}

				}



			}
			else if(floor_instruction.contains("REJ:")||floor_instruction.contains("AOM:#/REJ:#")||floor_instruction.contains("REJ"))
			{


				System.out.println("Rejecting the order");

				output_message=er.generateOrderReject();
				fs.sendMessage(output_message);

				System.out.println("Order Reject generated: "+output_message);


			}

			if(floor_instruction.contains("URO")||floor_instruction.contains("AOM:#/URO:#"))
			{


				System.out.println("Generating Order Cancel message");


				output_message=er.generateDFD();

				fs.sendMessage(output_message);


				System.out.println("Order Cancel from ECN  generated: "+output_message);

			}

			if(floor_instruction.contains("EXP"))
			{
				try {
					Thread.sleep(2000);}
				catch(Exception e) {

				}

				System.out.println("GBI Order Expiry");

				output_message=er.generateOrderExpiry();

				fs.sendMessage(output_message);

				System.out.println("Sending Order Expiry");



			}

			if(floor_instruction.contains("TXL"))
			{

				System.out.println("Generating Trade Cancel message");

				output_message=er.generateTradeCancel();

				try 
				{
					Thread.sleep(1000);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

				fs.sendMessage(output_message);


				System.out.println("Trade Cancel from ECN  generated: "+output_message);

			}

		





		}

		else if(hashMap.get(35).equalsIgnoreCase("G"))
		{


			System.out.println("Cancel Replace order request");

			if(floor_instruction.equalsIgnoreCase("PEN_RPL")||floor_instruction.equalsIgnoreCase("PENDING_REPLACE"))
			{

				output_message=er.generatePReplace();

				fs.sendMessage(output_message);


				System.out.println("Pending Replace message: "+output_message);


			}

			else if(floor_instruction.equalsIgnoreCase("RPL_ACK")||floor_instruction.equalsIgnoreCase("REPLACE_ACK")||floor_instruction.equalsIgnoreCase("NEW_ACK")||floor_instruction.contains("EXE:0@0")||floor_instruction.contains("AOM:#/EXE:#0.0"))
			{

				output_message=er.generatePReplace();

				fs.sendMessage(output_message);

				System.out.println("Pending Replace message: "+output_message);

				output_message=er.generateRplAck();

				fs.sendMessage(output_message);

				System.out.println("Replace Ack message: "+output_message);

			}
			else if(floor_instruction.equalsIgnoreCase("RPL_REJ")||floor_instruction.equalsIgnoreCase("RPL_REJECT")||floor_instruction.equalsIgnoreCase("REJ"))
			{

				output_message=er.generatePReplace();

				fs.sendMessage(output_message);

				System.out.println(" Pending Replace message: "+output_message);

				output_message=er.generateOrderReplaceReject();

				fs.sendMessage(output_message);

				System.out.println(" Replace Reject message: "+output_message);


			}

			else if(floor_instruction.contains("EXE:")||floor_instruction.contains("AOM:#/EXE:#"))
			{

				System.out.println("Execution px n qty: "+floor_instruction);



				//60@50.5;60@20.5

				String []exec_commands=floor_instruction.split(";");

				System.out.println("Size of exec comm array: "+exec_commands.length);


				System.out.println("First index: "+exec_commands[0]);



				//EXE:#=60@50.5,60@20.5;URO"

				String fill_inst[]=exec_commands[0].split("[:#]");
				String px_vs_qty[] = null;

				System.out.println("check array values"); 

				for(int i=0;i<fill_inst.length;i++)
				{
					System.out.println("INDEX: "+fill_inst[i].toString());

				}


				if(!fill_inst[1].isEmpty())
				{
					System.out.println("Final list: "+fill_inst[1]);

					px_vs_qty=fill_inst[1].split(",");

				}
				else if(!fill_inst[2].isEmpty())
				{

					System.out.println("Final list: "+fill_inst[2]);

					px_vs_qty=fill_inst[2].split(",");
				}

				System.out.println("Total number of executions to be generated: "+px_vs_qty.length);




				output_message=er.generatePReplace();

				fs.sendMessage(output_message);

				System.out.println("New P.Rpl generated: "+output_message);


				output_message = er.generateRplAck();

				fs.sendMessage(output_message);

				System.out.println("Replace Ack generated: "+output_message);


				for(int i=0;i<px_vs_qty.length;i++)
				{

					String exec_qty_px[]=px_vs_qty[i].split("@");

					System.out.println("Execution Qty: "+exec_qty_px[0]);
					System.out.println("Execution Price: "+exec_qty_px[1]);


					output_message= er.generateFill(exec_qty_px[0].trim(), exec_qty_px[1].trim());
					fs.sendMessage(output_message);

					System.out.println("New Fill generated: "+output_message);

					try 
					{
						Thread.sleep(1000);
					}
					catch(Exception e)
					{


					}

				}



			}



		}
		else if(hashMap.get(35).equalsIgnoreCase("F"))
		{



			if(floor_instruction.contains("AOM:#/URO:#")||floor_instruction.contains("NEW_ACK"))
			{

				output_message=er.generateOrderCancel();

				fs.sendMessage(output_message);

				System.out.println(" Cancel Ack message: "+output_message);



			}
			if(hashMap.get(55).equalsIgnoreCase("GSNCC"))
			{
				try {
					Thread.sleep(3000);
				}catch(Exception e) {}

				output_message=er.generateOrderExpiry();

				fs.sendMessage(output_message);

				System.out.println(" Order Exp message: "+output_message);

			}




		}




	}


}
