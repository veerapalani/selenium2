package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1512_CPIdataservice {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int InvalidStatuscode403=403;
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
    String accountIdentifier;
    String month;
    String jsonaccountIdentifier;
	String jsonmonth ;
	String jsonaccountIdentifier23;
	String jsonmonth23;
	String jsonaccountIdentifier21;
	String jsonmonth21;
	String jsonaccountIdentifier20;
	String jsonmonth20;
	
	AggLayerCommon tokengen = new AggLayerCommon();

	
	@Given("generate the bearer token for CPI data service")
	public void generate_the_bearer_token_for_CPI_data_service() throws InterruptedException, IOException, ParseException, JSONException {
	    
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@Given("CPI data service API service is available")
	public void cpi_data_service_API_service_is_available() {
	   
		RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@When("we post the API requests with valid accountIdentifier , month which has {int} working days and amount")
	public void we_post_the_API_requests_with_valid_accountIdentifier_month_which_has_working_days_and_amount(Integer int1) throws IOException, JSONException {
	    
		File f = new File(jsonpath+"AL_1512_22workingdays.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_22workingdays.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonaccountIdentifier =myObject.getString("accountIdentifier");
		   jsonmonth =myObject.getString("month");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
	    }
	}

	@Then("the data is returned back on the response and status code should be {int} for  CPI data service API")
	public void the_data_is_returned_back_on_the_response_and_status_code_should_be_for_CPI_data_service_API(Integer int1) {
	   
		 
		System.out.println("valid responce code for  CPI data service API  "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code for  CPI data service API "+response.getStatusCode() );
	}

	@Then("verify the values of accountIdentifier , month  and amount by GET CPI data service API")
	public void verify_the_values_of_accountIdentifier_month_and_amount_by_GET_CPI_data_service_API() {

		
		RestApiUtils.setBaseURI(Action.getTestData("BaseURI"));
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountIdentifier","00000025");
		queryMap.put("month", "2019-04");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
		
	}

	@Then("validate the accountIdentifier , month  and amount from responce of GET CPI data service API")
	public void verify_the_accountIdentifier_month_and_amount_from_responce_of_GET_CPI_data_service_API() throws JSONException {
	   
		String resultresponce	=response.getBody().asString();
		JSONObject myObject = new JSONObject(resultresponce);
		accountIdentifier =myObject.getString("accountIdentifier");
		month =myObject.getString("month");
		if(!month.isEmpty() && !accountIdentifier.isEmpty()) {
		Assert.assertEquals(month,jsonmonth);
		Assert.assertEquals(accountIdentifier,jsonaccountIdentifier);
		System.out.println("validation PASSED CPI Data Services for  number of working days 22");
		}
		
		else {
			System.out.println("validation FAILED CPI Data Services for  number of working days 22");
		}     
		
	}
	
	@When("we post the API requests with valid accountIdentifier , month which has {int} working days in a month and amount")
	public void we_post_the_API_requests_with_valid_accountIdentifier_month_which_has_working_days_in_a_month_and_amount(Integer int1) throws IOException, JSONException {
	   
		File f = new File(jsonpath+"AL_1512_23workingdays.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_23workingdays.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonaccountIdentifier23 =myObject.getString("accountIdentifier");
		   jsonmonth23 =myObject.getString("month");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
	    }
	}

	@Then("verify the values of accountIdentifier , month  and amount by GET CPI data service API for a month which has {int} working days")
	public void verify_the_values_of_accountIdentifier_month_and_amount_by_GET_CPI_data_service_API_for_a_month_which_has_working_days(Integer int1) {
	   
		RestApiUtils.setBaseURI(Action.getTestData("BaseURI"));
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountIdentifier","00000025");
		queryMap.put("month", "2019-01");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("validate the accountIdentifier , month  and amount from responce of GET CPI data service API for a month which has {int} working days")
	public void validate_the_accountIdentifier_month_and_amount_from_responce_of_GET_CPI_data_service_API_for_a_month_which_has_working_days(Integer int1) throws JSONException {
	 
		
		String resultresponce	=response.getBody().asString();
		JSONObject myObject = new JSONObject(resultresponce);
		accountIdentifier =myObject.getString("accountIdentifier");
		month =myObject.getString("month");
		if(!month.isEmpty() && !accountIdentifier.isEmpty()) {
		Assert.assertEquals(month,jsonmonth23);
		Assert.assertEquals(accountIdentifier,jsonaccountIdentifier23);
		System.out.println("validation PASSED CPI Data Services for  number of working days 23");
		}
		
		else {
			System.out.println("validation FAILED CPI Data Services for  number of working days 23");
		}     
	}
	@When("we post the API requests with valid accountIdentifier , month which has {int} working days in a month")
	public void we_post_the_API_requests_with_valid_accountIdentifier_month_which_has_working_days_in_a_month(Integer int1) throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL_1512_21workingdays.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_21workingdays.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonaccountIdentifier21 =myObject.getString("accountIdentifier");
		   jsonmonth21 =myObject.getString("month");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
	    }
	}

	@Then("verify the values of accountIdentifier , month  and amount GET CPI data service API for a month which has {int} working days")
	public void verify_the_values_of_accountIdentifier_month_and_amount_GET_CPI_data_service_API_for_a_month_which_has_working_days(Integer int1) {
	   
		RestApiUtils.setBaseURI(Action.getTestData("BaseURI"));
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountIdentifier","00000025");
		queryMap.put("month", "2020-02");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
		
	}

	@Then("validate the accountIdentifier , month  and  from responce of GET CPI data service API for a month which has {int} working days")
	public void validate_the_accountIdentifier_month_and_from_responce_of_GET_CPI_data_service_API_for_a_month_which_has_working_days(Integer int1) throws JSONException {
	 
		String resultresponce	=response.getBody().asString();
		JSONObject myObject = new JSONObject(resultresponce);
		accountIdentifier =myObject.getString("accountIdentifier");
		month =myObject.getString("month");
		if(!month.isEmpty() && !accountIdentifier.isEmpty()) {
		Assert.assertEquals(month,jsonmonth21);
		Assert.assertEquals(accountIdentifier,jsonaccountIdentifier21);
		System.out.println("validation PASSED CPI Data Services for  number of working days 21");
		}
		
		else {
			System.out.println("validation FAILED CPI Data Services for  number of working days 21");
		}     
		
	}
	
	@When("we post the requests with valid accountIdentifier,month which has {int} working days in a month")
	public void we_post_the_requests_with_valid_accountIdentifier_month_which_has_working_days_in_a_month(Integer int1) throws IOException, JSONException {
	    
		
		File f = new File(jsonpath+"AL_1512_20workingdays.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_20workingdays.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonaccountIdentifier20 =myObject.getString("accountIdentifier");
		   jsonmonth20 =myObject.getString("month");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
	}
	    }

	@Then("verify the values of accountIdentifier,month  and amount GET CPI data service  for a month which has {int} working days")
	public void verify_the_values_of_accountIdentifier_month_and_amount_GET_CPI_data_service_for_a_month_which_has_working_days(Integer int1) {
	   
		RestApiUtils.setBaseURI(Action.getTestData("BaseURI"));
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountIdentifier","00000025");
		queryMap.put("month", "2019-02");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("validate the accountIdentifier,month  and  from responce of GET CPI data service  for a month which has {int} working days")
	public void validate_the_accountIdentifier_month_and_from_responce_of_GET_CPI_data_service_for_a_month_which_has_working_days(Integer int1) throws JSONException {
	   
		String resultresponce	=response.getBody().asString();
		JSONObject myObject = new JSONObject(resultresponce);
		accountIdentifier =myObject.getString("accountIdentifier");
		month =myObject.getString("month");
		if(!month.isEmpty() && !accountIdentifier.isEmpty()) {
		Assert.assertEquals(month,jsonmonth20);
		Assert.assertEquals(accountIdentifier,jsonaccountIdentifier20);
		System.out.println("validation PASSED CPI Data Services for  number of working days 20");
		}
		
		else {
			System.out.println("validation FAILED CPI Data Services for  number of working days 20");
		}     
		}
	@When("we post the API requests with valid accountIdentifier , invalid month  and amount")
	public void we_post_the_API_requests_with_valid_accountIdentifier_invalid_month_and_amount() throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL_1512_InvalidMonth.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_InvalidMonth.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
	}
	    }

	@Then("returns response with error Bad Request and status code should be {int} for CPI data service API")
	public void returns_response_with_error_Bad_Request_and_status_code_should_be_for_CPI_data_service_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}

	@When("we post the API requests with valid accountIdentifier , month amount")
	public void we_post_the_API_requests_with_valid_accountIdentifier_month_amount() throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL_1512_20workingdays.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_20workingdays.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        String BaseURL	= "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/wapi/cp";
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
	}
	}

	@Then("returns response with error Not Found and status code should be {int} for CPI data service API")
	public void returns_response_with_error_Not_Found_and_status_code_should_be_for_CPI_data_service_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
		
	}
	
	@When("we post the API requests without accountIdentifier , month  and amount")
	public void we_post_the_API_requests_without_accountIdentifier_month_and_amount() throws JSONException, IOException {
	    
		
		File f = new File(jsonpath+"AL_1512_withoutAccountIdentifier.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_withoutAccountIdentifier.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
		
	}
	}
	
	@When("we post the API requests  accountIdentifier , month  and  without amount")
	public void we_post_the_API_requests_accountIdentifier_month_and_without_amount() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_1512_withoutAmount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_withoutAmount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
	    }
	}
	
	@When("we post the API requests with  accountIdentifier ,  without month  and amount")
	public void we_post_the_API_requests_with_accountIdentifier_without_month_and_amount() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_1512_withoutMonth.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1512_withoutMonth.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests for CPI data service API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for  API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API "+response.getBody().asString());
	    }
	}
	
	@Then("returns response with error Forbidden and status code should be {int} for CPI data service API")
	public void returns_response_with_error_Forbidden_and_status_code_should_be_for_CPI_data_service_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode403);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
}
