package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1429_MigrateTaxlotAPIcodetoplutus {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int InvalidStatuscode401=401;
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();

	@Given("generate the bearer token for Taxlot Available API")
	public void generate_the_bearer_token_for_Taxlot_Available_API() throws InterruptedException, IOException, ParseException, JSONException {
	    
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@Given("Taxlot API Available API service is available")
	public void taxlot_API_Available_API_service_is_available() {
		RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	   
	}

	@When("we post the API requests with with valid filterCriteria ACCOUNT")
	public void we_post_the_API_requests_with_with_valid_filterCriteria_ACCOUNT() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}

	@Then("the data is returned back on the response and status code should be {int} for Taxlot Available API")
	public void the_data_is_returned_back_on_the_response_and_status_code_should_be_for_Taxlot_Available_API(Integer int1) {
	 
		System.out.println("valid responce code for Taxlot  Available API  "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code for Taxlot  Available API "+response.getStatusCode() );
	}

	@When("we post the API requests with with valid filterCriteria CLIENT")
	public void we_post_the_API_requests_with_with_valid_filterCriteria_CLIENT() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaCLIENT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaCLIENT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}
	
	@When("we post the API requests with valid filterCriteria RELATIONSHIP")
	public void we_post_the_API_requests_with_valid_filterCriteria_RELATIONSHIP() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaRELATIONSHIP.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaRELATIONSHIP.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
		//	System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
		
	}
	    }
	
	
	@When("we post the API requests with  valid filterCriteria ACCOUNT_GROUP")
	public void we_post_the_API_requests_with_valid_filterCriteria_ACCOUNT_GROUP() throws IOException {
	 
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaACCOUNT_GROUP.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaACCOUNT_GROUP.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	}
	}

	@When("we post the API requests with valid filterCriteria ADVISORY_GROUP")
	public void we_post_the_API_requests_with_valid_filterCriteria_ADVISORY_GROUP() throws IOException {
	    
		
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaADVISORY_GROUP.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaADVISORY_GROUP.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	}
	}
	@When("we post the API requests with  valid filterCriteria ACCOUNT and invalid filterValue")
	public void we_post_the_API_requests_with_valid_filterCriteria_ACCOUNT_and_invalid_filterValue() throws IOException {
	    
		File f = new File(jsonpath+"AL_1429_ACCOUNTandinvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_ACCOUNTandinvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	}
	}

	@Then("returns response with error Not Found and status code should be {int} for Taxlot Available API")
	public void returns_response_with_error_Not_Found_and_status_code_should_be_for_Taxlot_Available_API(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
	@When("we post the API requests with invalid filterCriteria ACCOUN and filterValue")
	public void we_post_the_API_requests_with_invalid_filterCriteria_ACCOUN_and_filterValue() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_invalid filterCriteriaACCOUNandfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_invalid filterCriteriaACCOUNandfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	}
	}

	@Then("returns response with error Bad Request and status code should be {int} for Taxlot Available API")
	public void returns_response_with_error_Bad_Request_and_status_code_should_be_for_Taxlot_Available_API(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
	@When("we post the API requests with valid filterCriteria ACCOUNT and filterValue")
	public void we_post_the_API_requests_with_valid_filterCriteria_ACCOUNT_and_filterValue() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}

	@Then("returns response with error Forbidden and status code should be {int} for Taxlot Available API")
	public void returns_response_with_error_Forbidden_and_status_code_should_be_for_Taxlot_Available_API(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	@When("we post the API requests with valid filterCriteria RELATIONSHIP and invalid filterValue")
	public void we_post_the_API_requests_with_valid_filterCriteria_RELATIONSHIP_and_invalid_filterValue() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_filterCriteriaRELATIONSHIPandinvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_filterCriteriaRELATIONSHIPandinvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
		//	System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}

	@When("we post the API requests with invalid filterCriteria RELATIONSHIP and valid filterValue")
	public void we_post_the_API_requests_with_invalid_filterCriteria_RELATIONSHIP_and_valid_filterValue() throws IOException {
		File f = new File(jsonpath+"AL_1429_invalidfilterCriteriaRELATIONSHIPandvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_invalidfilterCriteriaRELATIONSHIPandvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}
	@When("we post the API requests with invalid filterCriteria CLIENT and valid filterValue")
	public void we_post_the_API_requests_with_invalid_filterCriteria_CLIENT_and_valid_filterValue() throws IOException {
	    
		File f = new File(jsonpath+"AL_1429_invalidfilterCriteriaCLIENTandvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_invalidfilterCriteriaCLIENTandvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}
	
	@When("we post the API requests with valid filterCriteria CLIENT and invalid filterValue")
	public void we_post_the_API_requests_with_valid_filterCriteria_CLIENT_and_invalid_filterValue() throws IOException {
	    
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaCLIENTandinvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaCLIENTandinvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
		//	System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}
	
	@When("we post the API requests with valid filterCriteria ACCOUNT_GROUP and invalid filterValue")
	public void we_post_the_API_requests_with_valid_filterCriteria_ACCOUNT_GROUP_and_invalid_filterValue() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaACCOUNT_GROUPandinvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaACCOUNT_GROUPandinvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
		//	System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}

	@When("we post the API requests with invalid filterCriteria ACCOUNT_GROUP and valid filterValue")
	public void we_post_the_API_requests_with_invalid_filterCriteria_ACCOUNT_GROUP_and_valid_filterValue() throws IOException {
	 
		File f = new File(jsonpath+"AL_1429_invalid filterCriteriaACCOUNT_GROUPandvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_invalid filterCriteriaACCOUNT_GROUPandvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}
	
	@When("we post the API requests with valid filterCriteria ADVISORY_GROUP and invalid filterValue")
	public void we_post_the_API_requests_with_valid_filterCriteria_ADVISORY_GROUP_and_invalid_filterValue() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_validfilterCriteriaADVISORY_GROUPandinvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_validfilterCriteriaADVISORY_GROUPandinvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			//System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}

	@When("we post the API requests with invalid filterCriteria ADVISORY_GROUP and valid filterValue")
	public void we_post_the_API_requests_with_invalid_filterCriteria_ADVISORY_GROUP_and_valid_filterValue() throws IOException {
	   
		File f = new File(jsonpath+"AL_1429_invalidfilterCriteriaADVISORY_GROUPandvalidfilterValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1429_invalidfilterCriteriaADVISORY_GROUPandvalidfilterValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Taxlot  Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Taxlot  Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
		//	System.out.println("Responce json for Taxlot  Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Taxlot  Available API "+response.getBody().asString());
	    }
	}

}
