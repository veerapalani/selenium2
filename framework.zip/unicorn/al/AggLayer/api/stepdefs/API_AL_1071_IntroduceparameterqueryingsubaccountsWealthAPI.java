package qa.unicorn.al.AggLayer.api.stepdefs;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.RestApiUtils;

public class API_AL_1071_IntroduceparameterqueryingsubaccountsWealthAPI {
	
	int InvalidStatuscode =400;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	Response response;
	
	@Given("balances WealthAPI service is active")
	public void balances_WealthAPI_service_is_active() {
		
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
		
		
	}

	@When("user perform GET oprtaion by sending the paramenter such as accountBranch, accountNumber and accountType for balances WealthAPI")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_such_as_accountBranch_accountNumber_and_accountType_for_balances_WealthAPI() {
	    
		RestApiUtils.setBaseURI(Action.getTestData("BalanceBaseURI"));
		RestApiUtils.requestSpecification = RestAssured.given();
		
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountBranch","001");
		queryMap.put("accountNumber", "00005");
		queryMap.put("accountType", "1");
		queryMap.put("includeSubAccounts", "false");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("the response status code should be {int} ok for balances WealthAPI")
	public void the_response_status_code_should_be_ok_for_balances_WealthAPI(Integer int1) {
		System.out.println("valid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
	}

	@Then("user should able to see  response  as per swagger document for balance")
	public void user_should_able_to_see_response_as_per_swagger_document_for_balance() {
		String resultresponce =response.getBody().asString();
		 System.out.println( "valid responce boday"+resultresponce);
	}

	@Given("Position WealthAPI service is active")
	public void position_WealthAPI_service_is_active() {
		
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	   
		//RestApiUtils.setBaseURI(Action.getTestData("PositionBaseURI"));
	}

	@When("user perform GET oprtaion by sending the paramenter such as accountBranch, accountNumber and accountType for Position WealthAPI")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_such_as_accountBranch_accountNumber_and_accountType_for_Position_WealthAPI() {
		RestApiUtils.setBaseURI(Action.getTestData("PositionBaseURI"));
		RestApiUtils.requestSpecification = RestAssured.given();
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountBranch","001");
		queryMap.put("accountNumber", "00004");
		queryMap.put("accountType", "1");
		queryMap.put("includeSubAccounts", "false");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("the response status code should be {int} ok for Position WealthAPI")
	public void the_response_status_code_should_be_ok_for_Position_WealthAPI(Integer int1) {
		System.out.println("valid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
	}

	@Then("user should able to see  response  as per swagger document for Position")
	public void user_should_able_to_see_response_as_per_swagger_document_for_Position() {
		String resultresponce =response.getBody().asString();
		 System.out.println( "valid responce boday"+resultresponce);
	}

	@When("user perform GET oprtaion by sending the paramenter such as invalid accountBranc and with accountNumber,accountType")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_such_as_invalid_accountBranc_and_with_accountNumber_accountType() {
	    
		RestApiUtils.setBaseURI(Action.getTestData("BalanceBaseURI"));
		RestApiUtils.requestSpecification = RestAssured.given();
		Map<String,String> queryMap=new HashMap<String,String>();
		//.put("accountBranch","001");
		queryMap.put("accountNumber", "200");
		queryMap.put("accountType", "1");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("the response status code should be {int} with error Bad Request for balances WealthAPI")
	public void the_response_status_code_should_be_with_error_Bad_Request_for_balances_WealthAPI(Integer int1) {
	  
		System.out.println("invalid responce code1 "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode);
		
	}

	@Then("user should able to see invalid  response with error Bad Request for balances WealthAPI")
	public void user_should_able_to_see_invalid_response_with_error_Bad_Request_for_balances_WealthAPI() {
		String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday for bad Request"+resultresponce);
		 if(resultresponce.contains("Bad Request")) {
			 
			 System.out.println("validation passed");
			 
		 }
		 else {
			 
			 System.out.println("validation failed");
			 
		 }
		
	}

	@When("user perform GET oprtaion by sending the aacount number whichc does not exists in database for balances WealthAPI")
	public void user_perform_GET_oprtaion_by_sending_the_aacount_number_whichc_does_not_exists_in_database_for_balances_WealthAPI() {
	    
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountBranch","001");
		queryMap.put("accountNumber", "2500");
		queryMap.put("accountType", "1");
		
		RestApiUtils.setBaseURI(Action.getTestData("BalanceBaseURI"));
		RestApiUtils.requestSpecification = RestAssured.given();
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
		
	}

	@Then("the response status code should be {int} with error Not Found for balances WealthAPI")
	public void the_response_status_code_should_be_with_error_Not_Found_for_balances_WealthAPI(Integer int1) {
	   
		System.out.println("valid responce code 2"+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
	}

	@Then("user should able to see invalid  response with error Not Found for balances WealthAPI")
	public void user_should_able_to_see_invalid_response_with_error_Not_Found_for_balances_WealthAPI() {
		String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
		 if(resultresponce.contains("NOT_FOUND")) {
			 
			 System.out.println("validation passed");
			 
		 }
		 else {
			 
			 System.out.println("validation failed");
			 
		 }
		
	}

	@Then("the response status code should be {int} with error Bad Request for position WealthAPI")
	public void the_response_status_code_should_be_with_error_Bad_Request_for_position_WealthAPI(Integer int1) {
	 
		System.out.println("invalid responce code3 "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode);
		
	}

	@Then("user should able to see invalid  response with error Bad Request for position WealthAPI")
	public void user_should_able_to_see_invalid_response_with_error_Bad_Request_for_position_WealthAPI() {
	   
		String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
		 if(resultresponce.contains("Bad Request")) {
			 
			 System.out.println("validation passed");
			 
		 }
		 else {
			 
			 System.out.println("validation failed");
			 
		 }
	}

	@When("user perform GET oprtaion by sending the aacount number whichc does not exists in database for position WealthAPI")
	public void user_perform_GET_oprtaion_by_sending_the_aacount_number_whichc_does_not_exists_in_database_for_position_WealthAPI() {
	    
		RestApiUtils.setBaseURI(Action.getTestData("PositionBaseURI"));
		RestApiUtils.requestSpecification = RestAssured.given();
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountBranch","000");
		queryMap.put("accountNumber", "000");
		queryMap.put("accountType", "1");
		queryMap.put("instrumentIdentifier", "B048148");
		queryMap.put("instrumentIdentifierType", "ADP");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("the response status code should be {int} with error Not Found for position WealthAPI")
	public void the_response_status_code_should_be_with_error_Not_Found_for_position_WealthAPI(Integer int1) {
		System.out.println("valid responce code4 "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
	}

	@Then("user should able to see invalid  response with error Not Found for position WealthAPI")
	public void user_should_able_to_see_invalid_response_with_error_Not_Found_for_position_WealthAPI() {
		String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
		 if(resultresponce.contains("NOT_FOUND")) {
			 
			 System.out.println("validation passed");
			 
		 }
		 else {
			 
			 System.out.println("validation failed");
			 
		 }
	}
	
	@When("user perform GET oprtaion by sending the paramenter such as invalid accountBranc and with accountNumber,accountType for position WealthAPI")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_such_as_invalid_accountBranc_and_with_accountNumber_accountType_for_position_WealthAPI() {
		RestApiUtils.setBaseURI(Action.getTestData("PositionBaseURI"));
		RestApiUtils.requestSpecification = RestAssured.given();
		Map<String,String> queryMap=new HashMap<String,String>();
		//queryMap.put("accountBranch","000");
		queryMap.put("accountNumber", "00010");
		queryMap.put("accountType", "1");
		queryMap.put("instrumentIdentifier", "B048148");
		queryMap.put("instrumentIdentifierType", "ADP");
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
		
	}


}
