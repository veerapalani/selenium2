package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2051_CountrycodesAPI {
	
	int InvalidStatuscode401 =401;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	 public String PreconditionScript;
	 public String jsonISOCODE;
	 public String ResponcejsonISOCODE;
	 public String ResponcejsonISOCODE1;
	 
	 AggLayerCommon tokengen = new AggLayerCommon();
	

@Given("generate the bearer token for Country codes API")
public void generate_the_bearer_token_for_Country_codes_API() throws InterruptedException, IOException, ParseException, JSONException {
	tokengen.OpenBeareretokenURL();
	//tokengen.fetchToken();
	Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
}

@When("Currency Country codes API service is available")
public void currency_Country_codes_API_service_is_available() {
    
	 RestApiUtils.requestSpecification=null;
	 RestAssured.baseURI=null;
     RestAssured.basePath="";
}

@When("we post the API requests")
public void we_post_the_API_requests() {
	
	String BaseURL	= Action.getTestData("BaseURI");
    System.out.println("requests Currency ISO CODE value"+BaseURL);
	RestApiUtils.setBaseURI(BaseURL);
	 RestApiUtils.requestSpecification = RestAssured.given();
	 Reporter.addStepLog("Base URI for Currency ISO CODE "+BaseURL);
	 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
	 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
	System.out.println("Responce json Country codes API "+response.getBody().asString());
	Reporter.addStepLog("Responce json Country codes API "+response.getBody().asString());
   
}

@Then("the data is returned back on the response and status code should be {int} for Country codes API")
public void the_data_is_returned_back_on_the_response_and_status_code_should_be_for_Country_codes_API(Integer int1) {
    
	System.out.println("valid responce code   "+response.getStatusCode());
	Assert.assertEquals(response.getStatusCode(), Statuscode);
	Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	
}

@When("we post the API requests with invalid API URL Country name")
public void we_post_the_API_requests_with_invalid_API_URL_Country_name() throws IOException {
	
        
         String BaseURL	= "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/plutusapi/countri";
	    System.out.println("requests Currency_ISO_CODE"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		 RestApiUtils.requestSpecification = RestAssured.given();
		 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
		 
		 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
		System.out.println("Responce json for Country codes "+response.getBody().asString());
		Reporter.addStepLog("Responce json for Country codes "+response.getBody().asString());
    
    
}



@When("we post the API requests without any Country name & ISO CODE")
public void we_post_the_API_requests_without_any_Country_name_ISO_CODE() throws IOException {
   
	File f = new File(jsonpath+"AL2051invalid_Country_name.json");
    if (f.exists()){
        InputStream is = new FileInputStream(jsonpath+"AL2051invalid_Country_name.json");
        String requestJson = IOUtils.toString(is, "UTF-8");
        System.out.println("request json is : "+requestJson);
        Reporter.addStepLog("request json is :"+requestJson);
         String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requests Currency_ISO_CODE"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		 RestApiUtils.requestSpecification = RestAssured.given();
		 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
		 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
		 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
		System.out.println("Responce json for Country codes "+response.getBody().asString());
		Reporter.addStepLog("Responce json for Country codes "+response.getBody().asString());
    }
    
}

@Then("gets response with message BAD_REQUEST and status code should be {int} for invalid Country name")
public void gets_response_with_message_BAD_REQUEST_and_status_code_should_be_for_invalid_Country_name(Integer int1) {
	System.out.println("invalid responce code "+response.getStatusCode());
	Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
	 String resultresponce =response.getBody().asString();
	 System.out.println( "Invalid responce boday"+resultresponce);
}


	
}
