package qa.unicorn.al.AggLayer.api.stepdefs;

import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Action;

public class AggLayerCommon {

	public String genratedtoken;

	public String OpenBeareretokenURL() {
		

		HttpClientUtils.baseUri = Action.getTestData("JWTToken-BaseURI");
		HttpClientUtils.basePath = Action.getTestData("JWTToken-BasePath");
		this.genratedtoken = execute();

		System.out.println("--token: " + genratedtoken);

		return genratedtoken;

	}

	public String genratedtoken() {
		return this.genratedtoken;
	}
	
	public static synchronized String execute() {
		String pfx = Action.getTestData("PFX-CertificatePath");
		String pwd = "123";

		RetriveResponse response = HttpClientUtils.given().setCetificate(pfx, pwd).buildUri()
		.setHeader("subject", Action.getTestData("Subject")).setProxy("10.98.21.24", 8080)
		.executeRequest(MethodType.POST);
		return  String.valueOf(response.getBody().jsonPath("token"));
	}

}
