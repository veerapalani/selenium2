package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2156_getBondAmortizationAccretion_PMR_service {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode401 =401;
	int Statuscode= 200;
	//int InvalidStatuscode403= 403;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("getBondAmortizationAccretionAPI service is active")
	public void getbondamortizationaccretionapi_service_is_active() throws InterruptedException, IOException, ParseException, JSONException {
		RestApiUtils.requestSpecification=null;
	 	 RestAssured.baseURI=null;
	      RestAssured.basePath="";
	      tokengen.OpenBeareretokenURL();
		 	//tokengen.fetchToken();
		 	Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@When("user perform POST operation with parameters for accountfilters , showInvestmentType, includeTaxLots in getBondAmortizationAccretionAPI")
	public void user_perform_POST_operation_with_parameters_for_accountfilters_showInvestmentType_includeTaxLots_in_getBondAmortizationAccretionAPI() throws IOException {
		File f = new File(jsonpath+"AL_2156_IncludeTaxLotsFlags.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_IncludeTaxLotsFlags.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} OK for getBondAmortizationAccretionAPI")
	public void the_response_status_code_should_be_OK_for_getBondAmortizationAccretionAPI(Integer int1) {
		 System.out.println("valid responce code   "+response.getStatusCode());
	  		Assert.assertEquals(response.getStatusCode(), Statuscode);
	  		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}

	@Then("user should able to see response as per swagger document for getBondAmortizationAccretion")
	public void user_should_able_to_see_response_as_per_swagger_document_for_getBondAmortizationAccretion() {
		 System.out.println("valid responce body  "+response.asString());
	  	Reporter.addStepLog("valid responce body  "+response.asString() );
		
	}
	
	@When("user perform POST request by sending the invalid BaseURL in getBondAmortizationAccretion API")
	public void user_perform_POST_request_by_sending_the_invalid_BaseURL_in_getBondAmortizationAccretion_API() throws IOException {
		File f = new File(jsonpath+"AL_2156_IncludeTaxLotsFlags.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_IncludeTaxLotsFlags.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.qa.api.prd.bfsaws.net/plutusapi/taxlots/bondreport/amortiza";
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    }
		
	}

	@Then("the response code {int} for getBondAmortizationAccretionAPI account not found")
	public void the_response_code_for_getBondAmortizationAccretionAPI_account_not_found(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
    	Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
    	 String resultresponce =response.getBody().asString();	
	}

	@When("user perform POST operation by sending invalid account paramenter such as accountBranch, accountNumber")
	public void user_perform_POST_operation_by_sending_invalid_account_paramenter_such_as_accountBranch_accountNumber() throws IOException {
	   
		File f = new File(jsonpath+"AL_2156_InvalidAaccountParameter.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_InvalidAaccountParameter.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    }
	}

	@Then("the response BAD_REQUEST status code {int} for getBondAmortizationAccretionAPI")
	public void the_response_BAD_REQUEST_status_code_for_getBondAmortizationAccretionAPI(Integer int1) {
		
		System.out.println("invalid responce code "+response.getStatusCode());
    	Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
    	 String resultresponce =response.getBody().asString();	   
		
	}

	@When("user perform POST operation by sending invalid paramenter in getBondAmortizationAccretion API")
	public void user_perform_POST_operation_by_sending_invalid_paramenter_in_getBondAmortizationAccretion_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_2156_InvalidUniversalAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_InvalidUniversalAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    }
	}

	@When("user perform POST operation with parameters for accountfilters , showInvestmentType, includeTaxLots, includeMarketDiscount in getBondAmortizationAccretionAPI")
	public void user_perform_POST_operation_with_parameters_for_accountfilters_showInvestmentType_includeTaxLots_includeMarketDiscount_in_getBondAmortizationAccretionAPI() throws IOException {
		File f = new File(jsonpath+"AL_2156_ClosedTaxlot.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_ClosedTaxlot.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    }
		
	}

	@When("user perform POST operation with parameters for accountfilters ,showInvestmentType, SummaryOnly in getBondAmortizationAccretionAPI")
	public void user_perform_POST_operation_with_parameters_for_accountfilters_showInvestmentType_SummaryOnly_in_getBondAmortizationAccretionAPI() throws IOException {
		File f = new File(jsonpath+"AL_2156_SummaryOnly.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_SummaryOnly.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    }
		
	}
	@When("user perform POST operation with parameters for accountfilters , includeTaxLots, includeMarketDiscount  and SortCritieria in getBondAmortizationAccretionAPI")
	public void user_perform_POST_operation_with_parameters_for_accountfilters_includeTaxLots_includeMarketDiscount_and_SortCritieria_in_getBondAmortizationAccretionAPI() throws IOException {
	   
		File f = new File(jsonpath+"AL_2156_GroupByCorporateandMuni.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_GroupByCorporateandMuni.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    }
	}

	@When("user send valid request with correct parameters for getBondAmortizationAccretionAPI")
	public void user_send_valid_request_with_correct_parameters_for_getBondAmortizationAccretionAPI() throws IOException {
		File f = new File(jsonpath+"AL_2156_CorporateBondAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_CorporateBondAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    } 
		
		
	}

	@Then("the DB values should be validated against Postman results for getBondAmortizationAccretionAPI")
	public void the_DB_values_should_be_validated_against_Postman_results_for_getBondAmortizationAccretionAPI() {
	    
		
	}

	@When("user perform POST request with paramenters for groupby accountFilterCriteria, accountFilterValue in getBondAmortizationAccretionAPI for CorporateBond Account")
	public void user_perform_POST_request_with_paramenters_for_groupby_accountFilterCriteria_accountFilterValue_in_getBondAmortizationAccretionAPI_for_CorporateBond_Account() throws IOException {
		File f = new File(jsonpath+"AL_2156_CorporateBondAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_CorporateBondAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    } 
		
	}

	@When("user perform POST request with paramenters for groupby accountFilterCriteria, accountFilterValue in getBondAmortizationAccretionAPI")
	public void user_perform_POST_request_with_paramenters_for_groupby_accountFilterCriteria_accountFilterValue_in_getBondAmortizationAccretionAPI() throws IOException {
		File f = new File(jsonpath+"AL_2156_AltAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2156_AltAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for getBondAmortizationAccretion  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBondAmortizationAccretion  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBondAmortizationAccretion  service"+response.getBody().asString());
	    }
	}
}