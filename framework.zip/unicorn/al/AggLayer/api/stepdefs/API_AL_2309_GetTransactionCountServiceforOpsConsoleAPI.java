package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2309_GetTransactionCountServiceforOpsConsoleAPI {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode401 =401;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	String jsonassetCategory;
    String	ResponcejsonassetCategory;
    
    AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("getTransactionCount API is active")
	public void gettransactioncount_API_is_active() throws InterruptedException, IOException, ParseException, JSONException {
		
		RestApiUtils.requestSpecification=null;
	 	 RestAssured.baseURI=null;
	      RestAssured.basePath="";
	      tokengen.OpenBeareretokenURL();
		 	//tokengen.fetchToken();
		 	Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	   
	}

	@When("user send the request with parameters such as TradeInputDate and AssetCategory As FIXED_INCOME")
	public void user_send_the_request_with_parameters_such_as_TradeInputDate_and_AssetCategory_As_FIXED_INCOME() throws IOException, JSONException {
		
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsFIXED_INCOME.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsFIXED_INCOME.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As FIXED_INCOME "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As FIXED_INCOME"+response.getBody().asString());
	    }
	  
	}

	@Then("the response status code {int} OK should be displayed for GetTransactionCount API")
	public void the_response_status_code_OK_should_be_displayed_for_GetTransactionCount_API(Integer int1) {
	    
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}

	@Then("user should be able to see response as per swagger document GetTransactionCount API")
	public void user_should_be_able_to_see_response_as_per_swagger_document_GetTransactionCount_API() {
	   
		 System.out.println("valid responce   : "+response.asString());
		   Reporter.addStepLog("valid responce  : "+response.asString() );
	}

	@Then("user should validate the AssetClass values for Muni, Corporate, FED, Other values against DB results")
	public void user_should_validate_the_AssetClass_values_for_Muni_Corporate_FED_Other_values_against_DB_results() throws JSONException {
	  
		String resultresponce	=response.getBody().asString();
		JSONObject myObject = new JSONObject(resultresponce);
		ResponcejsonassetCategory=myObject.getString("assetCategory");
		Assert.assertEquals(jsonassetCategory,ResponcejsonassetCategory );
	   Reporter.addStepLog("valid responce code  : "+response.asString() );
	}
	
	@When("user send the request with parameters such as TradeInputDate and AssetCategory As Equities")
	public void user_send_the_request_with_parameters_such_as_TradeInputDate_and_AssetCategory_As_Equities() throws JSONException, IOException {
	 
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsEQUITIES.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsEQUITIES.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As EQUITIES "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As EQUITIES"+response.getBody().asString());
	    }
	}
	
	@When("user send the request with parameters such as TradeInputDate and AssetCategory As Foreign Exchange")
	public void user_send_the_request_with_parameters_such_as_TradeInputDate_and_AssetCategory_As_Foreign_Exchange() throws JSONException, IOException {
	  
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsForeignExchange.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsForeignExchange.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As Foreign Exchange "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As Foreign Exchange"+response.getBody().asString());
	    }
	}
	@When("user send the request with parameters such as TradeInputDate and AssetCategory As Futures")
	public void user_send_the_request_with_parameters_such_as_TradeInputDate_and_AssetCategory_As_Futures() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsFutures.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsFutures.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As Futures "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As Futures"+response.getBody().asString());
	    }
	}
	@When("user send the request with parameters such as TradeInputDate , AssetCategory and Asset Class in API")
	public void user_send_the_request_with_parameters_such_as_TradeInputDate_AssetCategory_and_Asset_Class_in_API() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsEQUITIES.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsEQUITIES.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As EQUITIES "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As EQUITIES"+response.getBody().asString());
	    }
	}
	@When("user send the request with parameters such as TradeInputDate and AssetCategory As Precious Metals")
	public void user_send_the_request_with_parameters_such_as_TradeInputDate_and_AssetCategory_As_Precious_Metals() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsPreciousMetals.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsPreciousMetals.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As Precious Metals "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As Precious Metals"+response.getBody().asString());
	    }
		
}
	@When("user send the request with parameters such as TradeInputDate , AssetCategory and AssetClass in API")
	public void user_send_the_request_with_parameters_such_as_TradeInputDate_AssetCategory_and_AssetClass_in_API() throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsFutures.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsFutures.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As Futures "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As Futures"+response.getBody().asString());
	    }
	}

	@Then("user should be able to see responses for Buy, Sell, Customer, Street, Call, Puts counts as per swagger document")
	public void user_should_be_able_to_see_responses_for_Buy_Sell_Customer_Street_Call_Puts_counts_as_per_swagger_document() throws JSONException {
	   
		String resultresponce	=response.getBody().asString();
		JSONObject myObject = new JSONObject(resultresponce);
		ResponcejsonassetCategory=myObject.getString("assetCategory");
		Assert.assertEquals(jsonassetCategory,ResponcejsonassetCategory );
	   Reporter.addStepLog("valid responce code  : "+response.asString() );
		
	}
	
	@When("user send the request with parameters such as TradeInputDate and AssetCategory As OPTIONS")
	public void user_send_the_request_with_parameters_such_as_TradeInputDate_and_AssetCategory_As_OPTIONS() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsOPTIONS.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsOPTIONS.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As OPTIONS "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As OPTIONS"+response.getBody().asString());
	    }
	}

	@Then("user should validate the AssetClass values for equity option, Flex, Index and others values against DB results")
	public void user_should_validate_the_AssetClass_values_for_equity_option_Flex_Index_and_others_values_against_DB_results() throws JSONException {
	 
		String resultresponce	=response.getBody().asString();
		JSONObject myObject = new JSONObject(resultresponce);
		ResponcejsonassetCategory=myObject.getString("assetCategory");
		Assert.assertEquals(jsonassetCategory,ResponcejsonassetCategory );
	   Reporter.addStepLog("valid responce code  : "+response.asString() );
	}

	@When("user perform POST request by sending the invalid BaseURL in getTransactionCount API")
	public void user_perform_POST_request_by_sending_the_invalid_BaseURL_in_getTransactionCount_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsOPTIONS.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsOPTIONS.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	       String BaseURL	= "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/plutusapi/transactions/co";
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As OPTIONS "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As OPTIONS"+response.getBody().asString());
	    }
	}

	@Then("the response code {int} with status message invalid request should be displayed for getTransactionCount API")
	public void the_response_code_with_status_message_invalid_request_should_be_displayed_for_getTransactionCount_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();	
	}
	
	@When("user perform POST operation with invalid authorization token in getTransactionCount API")
	public void user_perform_POST_operation_with_invalid_authorization_token_in_getTransactionCount_API() throws JSONException, IOException {
		
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsOPTIONS.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsOPTIONS.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			// RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As OPTIONS "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As OPTIONS"+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} Forbidden message for API is displayed getTransactionCount API")
	public void the_response_status_code_should_be_Forbidden_message_for_API_is_displayed_getTransactionCount_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		 String resultresponce =response.getBody().asString();	
	}
	
	@When("user send the request with inavlid parameters such as TradeInputDate and AssetCategory in API")
	public void user_send_the_request_with_inavlid_parameters_such_as_TradeInputDate_and_AssetCategory_in_API() throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL_2309_InvalidEQUITIESINPUT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_InvalidEQUITIESINPUT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As EQUITIES "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As EQUITIES"+response.getBody().asString());
	    }
	}

	@Then("the response BAD_REQUEST and status code {int} should be displayed for getTransactionCount API")
	public void the_response_BAD_REQUEST_and_status_code_should_be_displayed_for_getTransactionCount_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();	
		
	}
	@When("user perform POST request and execute the DB query")
	public void user_perform_POST_request_and_execute_the_DB_query() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_2309_AssetCategoryAsFIXED_INCOME.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2309_AssetCategoryAsFIXED_INCOME.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonassetCategory =myObject.getString("assetCategory");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for GetTransactionCount Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for GetTransactionCount Service with AssetCategory As FIXED_INCOME "+response.getBody().asString());
			Reporter.addStepLog("Responce json for GetTransactionCount Service with AssetCategory As FIXED_INCOME"+response.getBody().asString());
	    }
	}

	@Then("user should validate the Postman response values with DB data result")
	public void user_should_validate_the_Postman_response_values_with_DB_data_result() throws JSONException {
	  
		String resultresponce	=response.getBody().asString();
		JSONObject myObject = new JSONObject(resultresponce);
		ResponcejsonassetCategory=myObject.getString("assetCategory");
		Assert.assertEquals(jsonassetCategory,ResponcejsonassetCategory );
	   Reporter.addStepLog("valid responce code  : "+response.asString() );
	}

}