package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2290_getBalanceSheet_service_PMR_Liabilities {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode401 =401;
	int InvalidStatuscode404 =404;
	
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("The balancesheet API service is active")
	public void the_balancesheet_API_service_is_active() throws InterruptedException, IOException, ParseException, JSONException {
	   
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
		 RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@When("user perform POST operation and does not include flags in request body whose default value is false.")
	public void user_perform_POST_operation_and_does_not_include_flags_in_request_body_whose_default_value_is_false() throws IOException, JSONException {
		File f = new File(jsonpath+"AL_2290_FlagsWhosedefaultValueisFalseGetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_FlagsWhosedefaultValueisFalseGetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	   }

	@Then("response does not displays the flag value and response code is {int} for PMR Liabilities API")
	public void response_does_not_displays_the_flag_value_and_response_code_is_for_PMR_Liabilities_API(Integer int1) throws JSONException {
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
		
		String resultresponce	=response.getBody().asString();
		System.out.println(""+resultresponce.contains("CLIENT"));
		JSONObject myObject = new JSONObject(resultresponce);
	
	}
	
	@When("user perform POST operation and does not inclue flags in request body whose default value is true.")
	public void user_perform_POST_operation_and_does_not_inclue_flags_in_request_body_whose_default_value_is_true() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_2290_FlagsWhosedefaultValueisTrueGetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_FlagsWhosedefaultValueisTrueGetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("response displays the respective flag value with response code {int}")
	public void response_displays_the_respective_flag_value_with_response_code(Integer int1) {
	 
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}
	@When("user perform POST operation by sending multiple values for filterValue field for balancesheet API.")
	public void user_perform_POST_operation_by_sending_multiple_values_for_filterValue_field_for_balancesheet_API() throws JSONException, IOException {
		File f = new File(jsonpath+"AL_2290_multiplefilterValueGetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_multiplefilterValueGetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code is {int} with all account details corresponding to filterValue field for balancesheet API.")
	public void the_response_status_code_is_with_all_account_details_corresponding_to_filterValue_field_for_balancesheet_API(Integer int1) {
	   
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}

	@When("user perform POST operation and flag value is true in request body.")
	public void user_perform_POST_operation_and_flag_value_is_true_in_request_body() throws JSONException, IOException {
		File f = new File(jsonpath+"AL_2290_FlagsWhosedefaultValueisTrueGetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_FlagsWhosedefaultValueisTrueGetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("response body should display the flag value with response code {int}")
	public void response_body_should_display_the_flag_value_with_response_code(Integer int1) {
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}
	
	@When("user perform POST operation with invalid JWT token for balancesheet API")
	public void user_perform_POST_operation_with_invalid_JWT_token_for_balancesheet_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_2290_FlagsWhosedefaultValueisTrueGetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_FlagsWhosedefaultValueisTrueGetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			// RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	    }

	@Then("the response status code should be {int} Forbidden message for balancesheet API")
	public void the_response_status_code_should_be_Forbidden_message_for_balancesheet_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		 String resultresponce =response.getBody().asString();
	}
	@When("user perform POST operation and flag value is false in request body.")
	public void user_perform_POST_operation_and_flag_value_is_false_in_request_body() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_2290_liabilitiesFalse.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_liabilitiesFalse.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("response body should not display the flag value and response code should be {int}")
	public void response_body_should_not_display_the_flag_value_and_response_code_should_be(Integer int1) {
	    
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}
	@When("user perform POST operation for filterCriteria field by entering invalid details.")
	public void user_perform_POST_operation_for_filterCriteria_field_by_entering_invalid_details() throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL_2290_InvalidfilterCriteria.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_InvalidfilterCriteria.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response displays valid error message for BalanceSheet API with error status code {int} BAD_Request")
	public void the_response_displays_valid_error_message_for_BalanceSheet_API_with_error_status_code_BAD_Request(Integer int1) {
	/*	System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();  
	}*/
	}

	@When("user perform POST operation and contain flag value as blank in request body.")
	public void user_perform_POST_operation_and_contain_flag_value_as_blank_in_request_body() throws JSONException, IOException {
	/*	File f = new File(jsonpath+"AL_2290_flagvalueasblank.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_flagvalueasblank.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());*/
	    }
	  
//	}
	@Then("the response displays valid error message {string} for BalanceSheet API with error status code {int} BAD_Request")
	public void the_response_displays_valid_error_message_for_BalanceSheet_API_with_error_status_code_BAD_Request(String string, Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 
		 if(resultresponce.contains("Account not present or no rights for the selected account")) {
			 System.out.println("Validation passed for BalanceSheet API ");
			 Reporter.addStepLog("Validation passed for BalanceSheet API");
		 }
		 else {
			 System.out.println("Validation failed for BalanceSheet API ");
			 Reporter.addStepLog("Validation failed for BalanceSheet API");
		 }
	}
	@When("user perform POST operation for filterValue field by entering blank value.")
	public void user_perform_POST_operation_for_filterValue_field_by_entering_blank_value() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL_2290_filterValuefieldbyenteringblankvalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_filterValuefieldbyenteringblankvalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response displays valid error message for BalanceSheet API.")
	public void the_response_displays_valid_error_message_for_BalanceSheet_API() {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 
		 if(resultresponce.contains("Malformed filterValue")) {
			 System.out.println("Validation passed for BalanceSheet API ");
			 Reporter.addStepLog("Validation passed for BalanceSheet API");
		 }
		 else {
			 System.out.println("Validation failed for BalanceSheet API ");
			 Reporter.addStepLog("Validation failed for BalanceSheet API");
		 }
	}

	@When("user perform POST operation by sending the liabilities flag value true in request body of balancesheet API")
	public void user_perform_POST_operation_by_sending_the_liabilities_flag_value_true_in_request_body_of_balancesheet_API() throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL_2290_liabilitiesflagvaluetrueGetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_liabilitiesflagvaluetrueGetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int}  with respectve liabilities value.")
	public void the_response_status_code_should_be_with_respectve_liabilities_value(Integer int1) {
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		 String resultresponce =response.getBody().asString();
	}

	@When("user perform POST operation on invalid URL for balanceSheet API.")
	public void user_perform_POST_operation_on_invalid_URL_for_balanceSheet_API() throws IOException, JSONException {
	   
		File f = new File(jsonpath+"AL_2290_FlagsWhosedefaultValueisTrueGetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_FlagsWhosedefaultValueisTrueGetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      String  jsonfilterValue =myObject.getString("filterValue");
	      String  jsongroupBy =myObject.getString("groupBy");
	        System.out.println("amount from request json............................. :"+ jsongroupBy);
	        System.out.println("month from request json.............................. :"+ jsonfilterValue);
	        String BaseURL	= "https://api.us-east-1.qa.api.prd.bfsaws.net/plutusapi/balance/balance";
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response displays NOT FOUND message with status code {int} for balanceSheet.")
	public void the_response_displays_NOT_FOUND_message_with_status_code_for_balanceSheet(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 
		 if(resultresponce.contains("Not Found")) {
			 System.out.println("Validation passed for BalanceSheet API ");
			 Reporter.addStepLog("Validation passed for BalanceSheet API");
		 }
		 else {
			 System.out.println("Validation failed for BalanceSheet API ");
			 Reporter.addStepLog("Validation failed for BalanceSheet API");
		 }
	}
	
	@When("user perform POST operation and contain invalid flag value in request body.")
	public void user_perform_POST_operation_and_contain_invalid_flag_value_in_request_body() throws IOException {
	    
		File f = new File(jsonpath+"AL_2290_invalidflagvalueinrequest.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_invalidflagvalueinrequest.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	         String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("response body should display {int} BAD REQUEST for balancesheet API")
	public void response_body_should_display_BAD_REQUEST_for_balancesheet_API(Integer int1) {
		
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 
		 if(resultresponce.contains("BAD REQUEST")) {
			 System.out.println("Validation passed for BalanceSheet API ");
			 Reporter.addStepLog("Validation passed for BalanceSheet API");
		 }
		 else {
			 System.out.println("Validation failed for BalanceSheet API ");
			 Reporter.addStepLog("Validation failed for BalanceSheet API");
		 }
	   
	}

	@When("user perform POST operation with valid value for balancesheet API request.")
	public void user_perform_POST_operation_with_valid_value_for_balancesheet_API_request() throws IOException {
	 
		File f = new File(jsonpath+"AL_2290_liabilitiesflagvaluetrueGetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_liabilitiesflagvaluetrueGetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	         String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response displays status code {int} with correct value as per DB for liability data")
	public void the_response_displays_status_code_with_correct_value_as_per_DB_for_liability_data(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		 String resultresponce =response.getBody().asString();
		
	}
	@When("user perform POST operation for filterValue field by entering invalid details.")
	public void user_perform_POST_operation_for_filterValue_field_by_entering_invalid_details() throws IOException {
	 
		File f = new File(jsonpath+"AL_2290_Invaliddetails.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_Invaliddetails.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	         String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	   
	}
	@When("user perform POST operation for filterValue field by entering valid+invalid values.")
	public void user_perform_POST_operation_for_filterValue_field_by_entering_valid_invalid_values() throws IOException {
		File f = new File(jsonpath+"AL_2290_valid+invalidvalues.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_valid+invalidvalues.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	         String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}
	@When("user perform POST operation for filterValue field by entering duplicate values.")
	public void user_perform_POST_operation_for_filterValue_field_by_entering_duplicate_values() throws IOException {
		File f = new File(jsonpath+"AL_2290_Duplicatevalues.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_Duplicatevalues.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	         String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	    
	}

	@When("user perform POST operation for groupBy field by entering invalid details.")
	public void user_perform_POST_operation_for_groupBy_field_by_entering_invalid_details() throws IOException {
		File f = new File(jsonpath+"AL_2290_Invalidgroupbyfiled.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_Invalidgroupbyfiled.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	         String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
		
	}
	
	@Then("response body should display {int} with invalid message groupBy filed for balancesheet API")
	public void response_body_should_display_with_invalid_message_groupBy_filed_for_balancesheet_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		 String resultresponce =response.getBody().asString();
		 
		 if(resultresponce.contains("not one of the values accepted for Enum class: [WEALTH_WAY_SUBGROUP, NONE, ADVISORY_GROUP, CLIENT, WEALTH_WAY_GROUP, ACCOUNT_GROUP]")) {
			 System.out.println("Validation passed for BalanceSheet API ");
			 Reporter.addStepLog("Validation passed for BalanceSheet API");
		 }
		 else {
			 System.out.println("Validation failed for BalanceSheet API ");
			 Reporter.addStepLog("Validation failed for BalanceSheet API");
		 }
		
	}
	
	@Then("the response displays status code {int} with correct value as per DB for networthsummary data")
	public void the_response_displays_status_code_with_correct_value_as_per_DB_for_networthsummary_data(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
	}

	@When("user perform POST operation for filterCriteria field by entering blank details.")
	public void user_perform_POST_operation_for_filterCriteria_field_by_entering_blank_details() throws IOException {
		
		File f = new File(jsonpath+"AL_2290_BlankfilterCriteria.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_BlankfilterCriteria.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	         String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
		
	   
	}

	@When("user perform POST operation for groupBy field by entering blank details.")
	public void user_perform_POST_operation_for_groupBy_field_by_entering_blank_details() throws IOException {
	   
		File f = new File(jsonpath+"AL_2290_Blankgroupbyfiled.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2290_Blankgroupbyfiled.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	         String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
		
	}

}
