package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2386_WAPI_getAccountSummarybyAmtQtyforOpsConsole {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	int InvalidStatuscode401= 401;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	String jsonassetCategory;
    String	ResponcejsonassetCategory;
    
    AggLayerCommon tokengen = new AggLayerCommon();
    
    @Given("getAccountSummarybyAmtQty API is active")
    public void getaccountsummarybyamtqty_API_is_active() throws InterruptedException, IOException, ParseException, JSONException {
       
    	RestApiUtils.requestSpecification=null;
	 	 RestAssured.baseURI=null;
	      RestAssured.basePath="";
	      tokengen.OpenBeareretokenURL();
		 	//tokengen.fetchToken();
		 	Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
  }

    @When("user perform Post request with parameters such as AccountNumber and TransactionDate in getAccountSummarybyAmtQty API")
    public void user_perform_Post_request_with_parameters_such_as_AccountNumber_and_TransactionDate_in_getAccountSummarybyAmtQty_API() throws IOException {
    	File f = new File(jsonpath+"AL_2386_ALTAccountNumberandTransactionDate.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_ALTAccountNumberandTransactionDate.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }

    @Then("the response status code {int} OK should be displayed for getAccountSummarybyAmtQty API")
    public void the_response_status_code_OK_should_be_displayed_for_getAccountSummarybyAmtQty_API(Integer int1) {
    	 System.out.println("valid responce code   "+response.getStatusCode());
  		Assert.assertEquals(response.getStatusCode(), Statuscode);
  		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
    }

    @Then("user should be able to see response as per swagger document getAccountSummarybyAmtQty API")
    public void user_should_be_able_to_see_response_as_per_swagger_document_getAccountSummarybyAmtQty_API() {
     
    	System.out.println("valid responce code   "+response.asString());
    	Reporter.addStepLog("valid responce code  "+response.asString() );
    }
    @When("user perform Post request with valid parameters such as error account and AsOfDate in getAccountSummarybyAmtQty  API")
    public void user_perform_Post_request_with_valid_parameters_such_as_error_account_and_AsOfDate_in_getAccountSummarybyAmtQty_API() throws IOException {
       
    	File f = new File(jsonpath+"AL_2386_ValidAccountNumberandinvalidAccountNumber.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_ValidAccountNumberandinvalidAccountNumber.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
        }
    
    @When("user perform Post request with valid parameters such as suspense account and AsOfDate in getAccountSummarybyAmtQty  API")
    public void user_perform_Post_request_with_valid_parameters_such_as_suspense_account_and_AsOfDate_in_getAccountSummarybyAmtQty_API() throws IOException {
     
    	File f = new File(jsonpath+"AL_2386_suspenseAccountNumberandTransactionDate.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_suspenseAccountNumberandTransactionDate.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }

   

    

    @When("user send valid request with correct parameters")
    public void user_send_valid_request_with_correct_parameters() throws IOException {
       
    	File f = new File(jsonpath+"AL_2386_AccountNumberandTransactionDate.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_AccountNumberandTransactionDate.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    	
    }

    @Then("the DB values should be validated against Postman results for getAccountSummarybyAmtQty API")
    public void the_DB_values_should_be_validated_against_Postman_results_for_getAccountSummarybyAmtQty_API() {
    	System.out.println("valid responce code   "+response.asString());
    	Reporter.addStepLog("valid responce code  "+response.asString() );
    }
    @When("user perform Post request with parameters for AccountFilter as not a suspense\\/error account in getAccountSummarybyAmtQty  API")
    public void user_perform_Post_request_with_parameters_for_AccountFilter_as_not_a_suspense_error_account_in_getAccountSummarybyAmtQty_API() throws IOException {
        
    	File f = new File(jsonpath+"AL_2386_SuspenseAccountNumberand.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_SuspenseAccountNumberand.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }
    @When("user perform POST request by sending the invalid BaseURL in getAccountSummarybyAmtQty  API")
    public void user_perform_POST_request_by_sending_the_invalid_BaseURL_in_getAccountSummarybyAmtQty_API() throws IOException {
        
    	File f = new File(jsonpath+"AL_2386_AccountNumberandTransactionDate.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_AccountNumberandTransactionDate.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.qa.api.prd.bfsaws.net/plutusapi/transaction/cash-amount";
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }

    @Then("the response code {int} with status account not found is displayed for getAccountSummarybyAmtQty  API")
    public void the_response_code_with_status_account_not_found_is_displayed_for_getAccountSummarybyAmtQty_API(Integer int1) {
    
    	System.out.println("invalid responce code "+response.getStatusCode());
    	Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
    	 String resultresponce =response.getBody().asString();	
    	 
    }
    

    @When("user perform POST operation with invalid authorization token in for getAccountSummarybyAmtQty API request")
    public void user_perform_POST_operation_with_invalid_authorization_token_in_for_getAccountSummarybyAmtQty_API_request() throws IOException {
        
    	File f = new File(jsonpath+"AL_2386_AccountNumberandTransactionDate.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_AccountNumberandTransactionDate.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			// RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }

    @Then("the response status code should be {int} Forbidden message for  getAccountSummarybyAmtQtyAPI is displayed")
    public void the_response_status_code_should_be_Forbidden_message_for_getAccountSummarybyAmtQtyAPI_is_displayed(Integer int1) {
    	System.out.println("invalid responce code "+response.getStatusCode());
    	Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
    	 String resultresponce =response.getBody().asString();	
    	 if(resultresponce.contains("\"status\": 403,\r\n" + 
    	 		"    \"error\": \"Forbidden\",\r\n" + 
    	 		"    \"message\": \"Access Denied\",")) {
    		 System.out.println("Validation passed ");
    		 Reporter.addStepLog("Validation passed");
    	 }
    	 else {
    		 System.out.println("Validation failed ");
    		 Reporter.addStepLog("Validation failed");
    	 }
       
    }
    @When("user send the request with invalid parameters in AccountNumber or AsOfDate")
    public void user_send_the_request_with_invalid_parameters_in_AccountNumber_or_AsOfDate() throws IOException {
    	File f = new File(jsonpath+"AL_2386_InvalidAccountNumber.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_InvalidAccountNumber.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }

    @Then("the response BAD_REQUEST and status code {int} should be displayed for getAccountSummarybyAmtQty API")
    public void the_response_BAD_REQUEST_and_status_code_should_be_displayed_for_getAccountSummarybyAmtQty_API(Integer int1) {
    	System.out.println("invalid responce code "+response.getStatusCode());
    	Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
    	 String resultresponce =response.getBody().asString();	
    	 if(resultresponce.contains("Malformed filterValue")) {
    		 System.out.println("Validation passed ");
    		 Reporter.addStepLog("Validation passed ");
    	 }
    	 else {
    		 System.out.println("Validation failed ");
    		 Reporter.addStepLog("Validation failed ");
    	 }
    }
    
    @When("user perform POST request with valid parameters for Account and TransactionDate in getAccountSummarybyAmtQty  API")
    public void user_perform_POST_request_with_valid_parameters_for_Account_and_TransactionDate_in_getAccountSummarybyAmtQty_API() throws IOException {
       
    	File f = new File(jsonpath+"AL_2386_DebitandCreditCashtransactions.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_DebitandCreditCashtransactions.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }

    @When("user perform Post request with valid parameters such as AccountNumber and TransactionDate getAccountSummarybyAmtQty")
    public void user_perform_Post_request_with_valid_parameters_such_as_AccountNumber_and_TransactionDate_getAccountSummarybyAmtQty() throws IOException {
       
    	File f = new File(jsonpath+"AL_2386_UNIVERSALACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_UNIVERSALACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }

    @When("user perform Post request with valid parameters such as AccountNumbers and TransactionDate in getAccountSummarybyAmtQty API")
    public void user_perform_Post_request_with_valid_parameters_such_as_AccountNumbers_and_TransactionDate_in_getAccountSummarybyAmtQty_API() throws IOException {
       
    	File f = new File(jsonpath+"AL_2386_SuspenseandErrorAccounts.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2386_SuspenseandErrorAccounts.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getAccountSummarybyAmtQty  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getAccountSummarybyAmtQty  service"+response.getBody().asString());
	    }
    }

}