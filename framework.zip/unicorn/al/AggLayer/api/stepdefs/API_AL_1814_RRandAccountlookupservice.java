package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1814_RRandAccountlookupservice {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	Response response;
	//Beareretokenpage tokengen = new Beareretokenpage();
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	String Responcejsonamount;
    String Responcejsonmonth;
    String jsonamount;
	String jsonmonth ;
	
	AggLayerCommon tokengen = new AggLayerCommon();

	@Given("table BrRegisteredRep_mapping API URL with data table contains data")
	public void table_BrRegisteredRep_mapping_API_URL_with_data_table_contains_data() {
		 RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@Given("generate the bearer token for Account look up service")
	public void generate_the_bearer_token_for_Account_look_up_service() throws InterruptedException, IOException, ParseException, JSONException {
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@When("we send the API requests with BrRegisteredRep code mapping value")
	public void we_send_the_API_requests_with_BrRegisteredRep_code_mapping_value() throws IOException {
	   
		File f = new File(jsonpath+"AL1814_validBrRegisteredRepcode.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1814_validBrRegisteredRepcode.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
		//	System.out.println("Responce json for BrRegisteredRepcode "+response.getBody().asString());
			//Reporter.addStepLog("Responce json for BrRegisteredRepcode "+response.getBody().asString());
	    }
	}

	@Then("the data is returned back on the response and status code should be {int} for Account look up service")
	public void the_data_is_returned_back_on_the_response_and_status_code_should_be_for_Account_look_up_service(Integer int1) {
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}
	
	@When("we send the API requests with invalid BrRegisteredRep code mapping value")
	public void we_send_the_API_requests_with_invalid_BrRegisteredRep_code_mapping_value() throws IOException {
	    
		File f = new File(jsonpath+"AL1814_invalidBrRegisteredRepcode.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1814_invalidBrRegisteredRepcode.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for BrRegisteredRepcode.................... "+response.getBody().asString());
			Reporter.addStepLog("Responce json for BrRegisteredRepcode .................................. "+response.getBody().asString());
	    }
	}

	@Then("gets response with message BAD_REQUEST and status code should be {int} for Account look up service")
	public void gets_response_with_message_BAD_REQUEST_and_status_code_should_be_for_Account_look_up_service(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
	}
	
	@When("we send the API requests without BrRegisteredRep code mapping value")
	public void we_send_the_API_requests_without_BrRegisteredRep_code_mapping_value() throws IOException {
	   
		File f = new File(jsonpath+"AL1814_withoutBrRegisteredRepcode.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1814_withoutBrRegisteredRepcode.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for BrRegisteredRepcode "+response.getBody().asString());
			Reporter.addStepLog("Responce json for BrRegisteredRepcode "+response.getBody().asString());
	    }
	}
	
	@When("we send the API requests without BrRegisteredRep code mapping value for in valid Baseurl")
	public void we_send_the_API_requests_without_BrRegisteredRep_code_mapping_value_for_in_valid_Baseurl() throws IOException {
	   
		File f = new File(jsonpath+"AL1814_withoutBrRegisteredRepcode.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1814_withoutBrRegisteredRepcode.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/plutusapi/rr-mapping/by-rr-cod";
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for BrRegisteredRepcode "+response.getBody().asString());
			Reporter.addStepLog("Responce json for BrRegisteredRepcode "+response.getBody().asString());
	    }
	}

	@Then("gets response with message NOT_FOUND and status code should be {int} for Account look up service")
	public void gets_response_with_message_NOT_FOUND_and_status_code_should_be_for_Account_look_up_service(Integer int1) {
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
	}
	
}
