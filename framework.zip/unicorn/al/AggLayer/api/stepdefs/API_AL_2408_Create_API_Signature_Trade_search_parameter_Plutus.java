package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2408_Create_API_Signature_Trade_search_parameter_Plutus {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	int InvalidStatuscode401= 401;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();
	
	String jsonassetCategory;
    String	ResponcejsonassetCategory;
    
    @When("user perform POST operation by sending the tradesearch data values in request body of tradesearch API.")
    public void user_perform_POST_operation_by_sending_the_tradesearch_data_values_in_request_body_of_tradesearch_API() throws IOException {
        
    	File f = new File(jsonpath+"AL_2408_tradesearchsinglefiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2408_tradesearchsinglefiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for trade search  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for trade search  service"+response.getBody().asString());
	    }
    }

    @Then("the response status code should be {int}  with respectve trade data.")
    public void the_response_status_code_should_be_with_respectve_trade_data(Integer int1) {
       
    	 System.out.println("valid responce code   "+response.getStatusCode());
 		Assert.assertEquals(response.getStatusCode(), Statuscode);
 		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
    }

    @Given("tradesearch API service is active")
    public void tradesearch_API_service_is_active() throws InterruptedException, IOException, ParseException, JSONException {
    	
    	RestApiUtils.requestSpecification=null;
	 	 RestAssured.baseURI=null;
	      RestAssured.basePath="";
	      tokengen.OpenBeareretokenURL();
		 	//tokengen.fetchToken();
		 	Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
       
    }

    @When("user perform POST operation by sending multiple values for filterValue field for tradesearch API.")
    public void user_perform_POST_operation_by_sending_multiple_values_for_filterValue_field_for_tradesearch_API() throws IOException {
      
    	File f = new File(jsonpath+"AL_2408_tradesearchmultiplefiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2408_tradesearchmultiplefiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for trade search  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for trade search  service"+response.getBody().asString());
	    }
    }

    @Then("the response status code is {int} with all account details corresponding to filterValue field for tradesearch API.")
    public void the_response_status_code_is_with_all_account_details_corresponding_to_filterValue_field_for_tradesearch_API(Integer int1) {
       
    	 System.out.println("valid responce code   "+response.getStatusCode());
 		Assert.assertEquals(response.getStatusCode(), Statuscode);
 		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
    	
    }
    @When("user perform POST operation for tradeDateFrom field by entering blank details.")
    public void user_perform_POST_operation_for_tradeDateFrom_field_by_entering_blank_details() throws IOException {
        
    	File f = new File(jsonpath+"AL_2408_tradesearchtradeDateFromfieldblank.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2408_tradesearchtradeDateFromfieldblank.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for trade search  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for trade search  service"+response.getBody().asString());
	    }
    }

    @Then("the response displays BAD_REQUEST with status code {int} for tradesearch API")
    public void the_response_displays_BAD_REQUEST_with_status_code_for_tradesearch_API(Integer int1) {
       
    	System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();	
		 if(resultresponce.contains("default message [must not be null]]")) {
			 System.out.println("Validation passed for trade search  service ");
			 Reporter.addStepLog("Validation passed for trade search  service");
		 }
		 else {
			 System.out.println("Validation failed for trade search  service ");
			 Reporter.addStepLog("Validation failed for trade search  service");
		 }
    }

   
    @When("user perform POST operation on invalid URL for tradesearch API.")
    public void user_perform_POST_operation_on_invalid_URL_for_tradesearch_API() throws IOException {
    	File f = new File(jsonpath+"AL_2408_tradesearchmultiplefiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2408_tradesearchmultiplefiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.qa.api.prd.bfsaws.net/plutusapi/transactions/tra";
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for trade search  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for trade search  service"+response.getBody().asString());
	    }
    }

    @Then("the response displays NOT FOUND message with status code {int} for tradesearch.")
    public void the_response_displays_NOT_FOUND_message_with_status_code_for_tradesearch(Integer int1) {
      
    	System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();	
		 if(resultresponce.contains("Not Found")) {
			 System.out.println("Validation passed for trade search service ");
			 Reporter.addStepLog("Validation passed for trade search  service");
		 }
		 else {
			 System.out.println("Validation failed for trade search  service ");
			 Reporter.addStepLog("Validation failed for trade search  service");
		 }
    }
    @When("user perform POST operation for fieldValue field by entering invalid details.")
    public void user_perform_POST_operation_for_fieldValue_field_by_entering_invalid_details() throws IOException {
     
    	File f = new File(jsonpath+"AL_2408_tradesearchinvalidfieldValue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2408_tradesearchinvalidfieldValue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");;
		    System.out.println("requests BaseURL for trade search  Service "+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for trade search  service "+response.getBody().asString());
			Reporter.addStepLog("Responce json for trade search  service"+response.getBody().asString());
	    }
    }

    @Then("the response displays BAD_REQUEST with status code {int}  and Malformed fieldValue for tradesearch API")
    public void the_response_displays_BAD_REQUEST_with_status_code_and_Malformed_fieldValue_for_tradesearch_API(Integer int1) {
        
    	System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();	
		 if(resultresponce.contains("\"Account not present or no rights for the selected account")) {
			 System.out.println("Validation passed for trade search  service ");
			 Reporter.addStepLog("Validation passed for trade search  service");
		 }
		 else {
			 System.out.println("Validation failed for trade search  service ");
			 Reporter.addStepLog("Validation failed for trade search  service");
		 }
    	
    }
    

    @When("user perform POST operation for fieldCriteria field by entering invalid details.")
    public void user_perform_POST_operation_for_fieldCriteria_field_by_entering_invalid_details() {
       
    }
    @When("user perform POST operation with invalid JWT token for tradesearch API.")
    public void user_perform_POST_operation_with_invalid_JWT_token_for_tradesearch_API() {
        
    }

    @Then("the response status code should be {int} Forbidden message for tradesearch API")
    public void the_response_status_code_should_be_Forbidden_message_for_tradesearch_API(Integer int1) {
        
    }

    @When("user perform POST operation for filterValue field by entering duplicate values for tradesearch API")
    public void user_perform_POST_operation_for_filterValue_field_by_entering_duplicate_values_for_tradesearch_API() {
       
    }



@Then("the response displays BAD_REQUEST with status code {int}  and Malformed filterCriteria for tradesearch API")
public void the_response_displays_BAD_REQUEST_with_status_code_and_Malformed_filterCriteria_for_tradesearch_API(Integer int1) {
    // Write code here that turns the phrase above into concrete actions
    throw new cucumber.api.PendingException();
}

@When("user perform POST operation for tradeDateFrom field by entering invalid details.")
public void user_perform_POST_operation_for_tradeDateFrom_field_by_entering_invalid_details() {
    // Write code here that turns the phrase above into concrete actions
    throw new cucumber.api.PendingException();
}

@Then("the response displays BAD_REQUEST with status code {int}  with error message Cannot deserialize value of type `java.time.ZonedDateTime` from String for tradesearch API")
public void the_response_displays_BAD_REQUEST_with_status_code_with_error_message_Cannot_deserialize_value_of_type_java_time_ZonedDateTime_from_String_for_tradesearch_API(Integer int1) {
    // Write code here that turns the phrase above into concrete actions
    throw new cucumber.api.PendingException();
}
    	
}