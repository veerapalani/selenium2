package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1678_getBalanceSheet_service_PMR_Asset_and_OutsideAsset {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("balances getBalanceSheetAPI service is active")
	public void balances_getBalanceSheetAPI_service_is_active() throws InterruptedException, IOException, ParseException, JSONException {
		
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
		 RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	    
	}

	@When("user perform POST operation by sending the parameters such as Asset, OutsideAsset, totalAmount and BalanceAmount for balances getBalanceSheetAPI")
	public void user_perform_POST_operation_by_sending_the_parameters_such_as_Asset_OutsideAsset_totalAmount_and_BalanceAmount_for_balances_getBalanceSheetAPI() throws IOException {
	   
		File f = new File(jsonpath+"AL_1678_getBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_getBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
		
	}

	@Then("the response status code should be {int} ok for balances getBalanceSheetAPI")
	public void the_response_status_code_should_be_ok_for_balances_getBalanceSheetAPI(Integer int1) {
	 
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}

	@Then("user should able to see  response  as per swagger document for getBalanceSheet service")
	public void user_should_able_to_see_response_as_per_swagger_document_for_balancedata_getBalanceSheet_service() {
		
		String resultresponce	=response.getBody().asString();
		System.out.println("valid json responce body"+resultresponce);
		Reporter.addStepLog("valid responce code  "+resultresponce );
	    
	}

	@When("user perform POST operation by sending invalid parameters for getBalanceSheetAPI")
	public void user_perform_POST_operation_by_sending_invalid_parameters_for_getBalanceSheetAPI() throws IOException {
	    
		File f = new File(jsonpath+"AL_1678_invalid_parameters_getBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_invalid_parameters_getBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response BAD_REQUEST and status code should be {int} for balances getBalanceSheetAPI")
	public void the_response_BAD_REQUEST_and_status_code_should_be_for_balances_getBalanceSheetAPI(Integer int1) {
	 
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
		
	}
	
	@When("user perform POST operation by sending the parameters such as OutsideAccountsource , includeNetworth for getBalanceSheet API")
	public void user_perform_POST_operation_by_sending_the_parameters_such_as_OutsideAccountsource_includeNetworth_for_getBalanceSheet_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_1678_AccountgetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_AccountgetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
		
	}
	
	@When("user perform POST operation by sending invalid URL universalAccount parameter for getBalanceSheetAPI")
	public void user_perform_POST_operation_by_sending_invalid_URL_universalAccount_parameter_for_getBalanceSheetAPI() throws IOException {
	    
		File f = new File(jsonpath+"AL_1678_AccountgetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_AccountgetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.qa.api.prd.bfsaws.net/plutusapi/balance/balanceshee";
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} not found for balances getBalanceSheetAPI")
	public void the_response_status_code_should_be_not_found_for_balances_getBalanceSheetAPI(Integer int1) {
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}

	@When("user perform POST operation by sending the parameters such as OutsideAsset, totalAmount and BalanceAmount for balances getBalanceSheetAPI")
	public void user_perform_POST_operation_by_sending_the_parameters_such_as_OutsideAsset_totalAmount_and_BalanceAmount_for_balances_getBalanceSheetAPI() throws IOException {
	    
		File f = new File(jsonpath+"AL_1678_UNIVERSALACCOUNTgetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_UNIVERSALACCOUNTgetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	=  Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	    
	    
	}
	
	@When("user perform POST operation by sending invalid parameters for getBalanceSheetAPI with wrong universalAccount data")
	public void user_perform_POST_operation_by_sending_invalid_parameters_for_getBalanceSheetAPI_with_wrong_universalAccount_data() throws IOException {
		File f = new File(jsonpath+"AL_1678_InvalidUNIVERSALACCOUNTgetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_InvalidUNIVERSALACCOUNTgetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	=  Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}
	
	@When("user perform POST operation by sending the parameters such as OutsideAccountsource , ACCOUNT_GROUP,includeNetworth for getBalanceSheet API")
	public void user_perform_POST_operation_by_sending_the_parameters_such_as_OutsideAccountsource_ACCOUNT_GROUP_includeNetworth_for_getBalanceSheet_API() throws IOException {
	  
		File f = new File(jsonpath+"AL_1678_validAccountGroupgetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_validAccountGroupgetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	=  Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}
	
	@When("user perform POST operation with invalid authorization token in API request for getBalanceSheetAPI service")
	public void user_perform_POST_operation_with_invalid_authorization_token_in_API_request_for_getBalanceSheetAPI_service() throws IOException {
	   
		File f = new File(jsonpath+"AL_1678_validAccountGroupgetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_validAccountGroupgetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	=  Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			// RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} Forbidden message for getBalanceSheet API")
	public void the_response_status_code_should_be_Forbidden_message_for_getBalanceSheet_API(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
		 Reporter.addStepLog("Invalid responce boday"+resultresponce);
	}
	
	@When("user perform POST operation by sending the parameters such as OutsideAccountsource , CLIENT ,includeNetworth for getBalanceSheet API")
	public void user_perform_POST_operation_by_sending_the_parameters_such_as_OutsideAccountsource_CLIENT_includeNetworth_for_getBalanceSheet_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_1678_ClientgetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_ClientgetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
		
	}
	
	@When("user perform POST operation by sending invalid parameters filter criteria for balances getBalanceSheetAPI")
	public void user_perform_POST_operation_by_sending_invalid_parameters_filter_criteria_for_balances_getBalanceSheetAPI() throws IOException {
	    
		File f = new File(jsonpath+"AL_1678_InvalidFiltercriteriagetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_InvalidFiltercriteriagetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    } 
		
	}
		
	@When("user perform POST operation by sending invalid account parameter and invalid API URL for balances getBalanceSheetAPI")
	public void user_perform_POST_operation_by_sending_invalid_account_parameter_and_invalid_API_URL_for_balances_getBalanceSheetAPI() throws IOException {
	    
		File f = new File(jsonpath+"AL_1678_AccountgetBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_AccountgetBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.qa.api.prd.bfsaws.net/plutusapi/balance/balanceshee";
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}
	
	@When("user perform POST operation by sending invalid altAccount and and invalid API URL for balances getBalanceSheetAPI")
	public void user_perform_POST_operation_by_sending_invalid_altAccount_and_and_invalid_API_URL_for_balances_getBalanceSheetAPI() throws IOException {
	  
		File f = new File(jsonpath+"AL_1678_invalidaltAccountInvalidURLBalanceSheetAPI.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1678_invalidaltAccountInvalidURLBalanceSheetAPI.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.qa.api.prd.bfsaws.net/plutusapi/balance/balanceshee";
		    System.out.println("requests getBalanceSheetAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for getBalanceSheetAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for getBalanceSheetAPI "+response.getBody().asString());
	    }
	}
	
}
