package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2793_Include_New_Attributes_POST_transactions {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode401 =401;
    int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("\\/Transactions service is Active")
	public void transactions_service_is_Active() throws InterruptedException, IOException, ParseException, JSONException {
	   
		RestApiUtils.requestSpecification=null;
	 	   RestAssured.baseURI=null;
	       RestAssured.basePath="";
	       tokengen.OpenBeareretokenURL();
		   //tokengen.fetchToken();
		   Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@When("user perform POST request with valid Parameters in \\/Transactions api")
	public void user_perform_POST_request_with_valid_Parameters_in_Transactions_api() throws IOException {
	 
		File f = new File(jsonpath+"AL_2793_Transactions.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2793_Transactions.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        System.out.println("Big bulllllllllllllllllllll"+BaseURL);
	        RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Transctions"+response.getBody().asString());
			Reporter.addStepLog("Responce json for Transctions"+response.getBody().asString());
	    } 
	}

	@Then("the response status code {int} OK should be displayed for Transactions api")
	public void the_response_status_code_OK_should_be_displayed_for_Transactions_api(Integer int1) {
	 
		System.out.println("valid responce code   "+response.getStatusCode());
 		Assert.assertEquals(response.getStatusCode(), Statuscode);
		
	}

	@Then("user should be able to see response as per swagger document for Transactions api")
	public void user_should_be_able_to_see_response_as_per_swagger_document_for_Transactions_api() {
	  
		System.out.println("valid responce code   "+response.asString());
	}

}
