package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1553_EnhancementRRMappingAPI {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int InvalidStatuscode401=401;
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();

	
	@Given("generate the bearer token for Enhanced RR maping API")
	public void generate_the_bearer_token_for_Enhanced_RR_maping_API() throws InterruptedException, IOException, ParseException, JSONException {
	   
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@Given("Enhanced RR mapping API service is available")
	public void enhanced_RR_mapping_API_service_is_available() {
	  
		 RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@When("we post the API requests with by-branch-code mapping value")
	public void we_post_the_API_requests_with_by_branch_code_mapping_value() throws IOException {
	   
		File f = new File(jsonpath+"AL1553_by-branch-code.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1553_by-branch-code.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests with rr code mapping value"+BaseURL);
			String BasePath=Action.getTestData("by-branch-code");
			System.out.println("requests with rr code mapping value"+BasePath);
			RestApiUtils.setBaseURI(BaseURL+BasePath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for by_RR_code "+BaseURL+BasePath);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for by_RR_code "+response.getBody().asString());
			Reporter.addStepLog("Responce json for by_RR_code "+response.getBody().asString());
	    }
	}

	@Then("the data is returned back on the response and status code should be {int} for Enhanced RR mapping API")
	public void the_data_is_returned_back_on_the_response_and_status_code_should_be_for_Enhanced_RR_mapping_API(Integer int1) {
	    
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}
	
	@When("we post the API requests with by-ubs-rep-code mapping value")
	public void we_post_the_API_requests_with_by_ubs_rep_code_mapping_value() throws IOException {
	 
		File f = new File(jsonpath+"AL1553_by-ubs-rep-code.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1553_by-ubs-rep-code.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests with rr code mapping value"+BaseURL);
			String BasePath=Action.getTestData("by-ubs-rep-code");
			System.out.println("requests with rr code mapping value"+BasePath);
			RestApiUtils.setBaseURI(BaseURL+BasePath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for by_RR_code "+BaseURL+BasePath);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for by_RR_code "+response.getBody().asString());
			Reporter.addStepLog("Responce json for by_RR_code "+response.getBody().asString());
	}
	    }
	@Then("invalid response and status code should be {int} for Enhanced RR mapping API")
	public void invalid_response_and_status_code_should_be_for_Enhanced_RR_mapping_API(Integer int1) {
	    
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}
	@When("User performs post API requests with with invalid by-branch-code api url")
	public void user_performs_post_API_requests_with_with_invalid_by_branch_code_api_url() throws IOException {
	   
		File f = new File(jsonpath+"AL1553_by-branch-code.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1553_by-branch-code.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/plutusapi/rr-mapping/";
		    System.out.println("requests with rr code mapping value"+BaseURL);
			String BasePath=Action.getTestData("by-branch-code");
			System.out.println("requests with rr code mapping value"+BasePath);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for by_RR_code "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for by_RR_code "+response.getBody().asString());
		
			Reporter.addStepLog("Responce json for by_RR_code "+response.getBody().asString());
	    }
	}

	@Then("gets response with message Not Found and status code should be {int} for Enhanced RR api url")
	public void gets_response_with_message_Not_Found_and_status_code_should_be_for_Enhanced_RR_api_url(Integer int1) {
	   
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}

	@When("User performs post API requests with with invalid by-ubs-rep-cod code api url")
	public void user_performs_post_API_requests_with_with_invalid_by_ubs_rep_cod_code_api_url() throws IOException {
	   
		File f = new File(jsonpath+"AL1553_by-ubs-rep-code.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1553_by-ubs-rep-code.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/plutusapi/rr-mapping/";
		    System.out.println("requests with rr code mapping value"+BaseURL);
			String BasePath=Action.getTestData("by-ubs-rep-code");
			System.out.println("requests with rr code mapping value"+BasePath);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for by_RR_code "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for by_RR_code "+response.getBody().asString());
			Reporter.addStepLog("Responce json for by_RR_code "+response.getBody().asString());
	}
	}
	
	@When("user performs API requests with invalid by-ubs-rep-code mapping value")
	public void user_performs_API_requests_with_invalid_by_ubs_rep_code_mapping_value() throws IOException {
	  
		File f = new File(jsonpath+"AL1553_by-ubs-rep-invalid_code.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1553_by-ubs-rep-invalid_code.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests with rr code mapping value"+BaseURL);
			String BasePath=Action.getTestData("by-ubs-rep-code");
			System.out.println("requests with rr code mapping value"+BasePath);
			RestApiUtils.setBaseURI(BaseURL+BasePath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for by_RR_code "+BaseURL+BasePath);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for by_RR_code "+response.getBody().asString());
			Reporter.addStepLog("Responce json for by_RR_code "+response.getBody().asString());
	}
	}

	@Then("gets response with message BAD_REQUEST and status code should be {int} for Enhanced RR mapping value")
	public void gets_response_with_message_BAD_REQUEST_and_status_code_should_be_for_Enhanced_RR_mapping_value(Integer int1) {
	    
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}

	@When("user performs API requests with invalid by-branch-code mapping value")
	public void user_performs_API_requests_with_invalid_by_branch_code_mapping_value() throws IOException {
	    
		File f = new File(jsonpath+"AL1553_by-branch-invalid_code.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL1553_by-branch-invalid_code.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests with rr code mapping value"+BaseURL);
			String BasePath=Action.getTestData("by-branch-code");
			System.out.println("requests with rr code mapping value"+BasePath);
			RestApiUtils.setBaseURI(BaseURL+BasePath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for by_RR_code "+BaseURL+BasePath);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for by_RR_code "+response.getBody().asString());
			Reporter.addStepLog("Responce json for by_RR_code "+response.getBody().asString());
	    }
		
	}

}
