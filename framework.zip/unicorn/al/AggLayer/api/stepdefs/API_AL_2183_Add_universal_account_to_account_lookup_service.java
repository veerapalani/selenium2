package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2183_Add_universal_account_to_account_lookup_service {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode401 =401;
	int InvalidStatuscode404 =404;
	
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("account info API service is active")
	public void account_info_API_service_is_active() throws InterruptedException, IOException, ParseException, JSONException {
	   
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
		 RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
		
	}

	@When("user perform POST operation by sending single value for filterValue field in account info API")
	public void user_perform_POST_operation_by_sending_single_value_for_filterValue_field_in_account_info_API() throws IOException {
	 
		File f = new File(jsonpath+"AL_2183_Account_SingleFiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_Account_SingleFiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Info");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code is {int} with account detail corresponding to filterValue field of account info API")
	public void the_response_status_code_is_with_account_detail_corresponding_to_filterValue_field_of_account_info_API(Integer int1) {
	   
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
		String resultresponce	=response.getBody().asString();
		System.out.println("valid json responce body"+resultresponce);
		Reporter.addStepLog("valid responce code  "+resultresponce );
	}
	
	@When("user perform POST operation by sending single value for filterValue field in  UBS account info API")
	public void user_perform_POST_operation_by_sending_single_value_for_filterValue_field_in_UBS_account_info_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_2183_UBSAccount_SingleFiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_UBSAccount_SingleFiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Info");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
	}
	
	@When("user perform GET operation by sending invalid request parameter ACCOUNT for account info API")
	public void user_perform_GET_operation_by_sending_invalid_request_parameter_ACCOUNT_for_account_info_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_2183_InvalidBRAccount_SingleFiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_InvalidBRAccount_SingleFiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Info");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} BAD_REQUEST for account info API")
	public void the_response_status_code_should_be_BAD_REQUEST_for_account_info_API(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	@When("user perform POST operation by sending valid request parameter ACCOUNT for account info API")
	public void user_perform_POST_operation_by_sending_valid_request_parameter_ACCOUNT_for_account_info_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_2183_validBRAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_validBRAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Info");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} OK for account info API")
	public void the_response_status_code_should_be_OK_for_account_info_API(Integer int1) {
	 
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}
	
	@When("user perform POST operation by sending valid request parameter ALTACCOUNT for account info API")
	public void user_perform_POST_operation_by_sending_valid_request_parameter_ALTACCOUNT_for_account_info_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_2183_validUBSAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_validUBSAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Info");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
	}
	
	@When("user perform POST operation by sending invalid request parameter ALTACCOUNT for account info API")
	public void user_perform_POST_operation_by_sending_invalid_request_parameter_ALTACCOUNT_for_account_info_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_2183_invalidUBSAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_invalidUBSAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Info");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
		
	}
	
	@When("user perform POST operation with invalid account info API URL")
	public void user_perform_POST_operation_with_invalid_account_info_API_URL() throws IOException {
		
		File f = new File(jsonpath+"AL_2183_validBRAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_validBRAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= "Inf";
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
		
	}
	    

	@Then("the response status code should be {int} Not_Found message for account info API")
	public void the_response_status_code_should_be_Not_Found_message_for_account_info_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
	@When("user perform POST operation with invalid authorization token for account info API")
	public void user_perform_POST_operation_with_invalid_authorization_token_for_account_info_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_2183_validBRAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_validBRAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Info");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			// RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
	}
	
	@When("user perform POST operation with invalid authorization token for UBS account info API")
	public void user_perform_POST_operation_with_invalid_authorization_token_for_UBS_account_info_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_2183_validUBSAccount.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_validUBSAccount.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Info");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			// RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_infoAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_infoAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} Forbidden message for account info API")
	public void the_response_status_code_should_be_Forbidden_message_for_account_info_API(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
		
	}
	
	@Given("account lookup API service is active")
	public void account_lookup_API_service_is_active() throws InterruptedException, IOException, ParseException, JSONException {
	 
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
		 RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@When("user perform POST operation by sending multiple values for filterValue field in account lookup API")
	public void user_perform_POST_operation_by_sending_multiple_values_for_filterValue_field_in_account_lookup_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_2183_Account_lookup_MultipleFiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_Account_lookup_MultipleFiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Lookup");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_lookupAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_lookupAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code is {int} with account detail corresponding to filterValue field of account lookup API")
	public void the_response_status_code_is_with_account_detail_corresponding_to_filterValue_field_of_account_lookup_API(Integer int1) {
	    
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
		String resultresponce	=response.getBody().asString();
		System.out.println("valid json responce body"+resultresponce);
		Reporter.addStepLog("valid responce code  "+resultresponce );
	}
	
	@When("user perform POST operation with invalid account lookup API URL")
	public void user_perform_POST_operation_with_invalid_account_lookup_API_URL() throws IOException {
	   
		File f = new File(jsonpath+"AL_2183_Account_lookup_MultipleFiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_Account_lookup_MultipleFiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= "LookUP";
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_lookupAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_lookupAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} Not_Found message for account lookup API")
	public void the_response_status_code_should_be_Not_Found_message_for_account_lookup_API(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
	@When("user perform POST operation by sending invalid request parameter for account lookup API")
	public void user_perform_POST_operation_by_sending_invalid_request_parameter_for_account_lookup_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_2183_InvalidAccount_lookup_MultipleFiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_InvalidAccount_lookup_MultipleFiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Lookup");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_lookupAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_lookupAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} BAD_REQUEST for account lookup API")
	public void the_response_status_code_should_be_BAD_REQUEST_for_account_lookup_API(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
	@When("user perform POST operation with invalid authorization token for account lookup API")
	public void user_perform_POST_operation_with_invalid_authorization_token_for_account_lookup_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_2183_Account_lookup_MultipleFiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_Account_lookup_MultipleFiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= "LookUP";
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			// RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_lookupAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_lookupAPI "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} Forbidden message for account lookup API")
	public void the_response_status_code_should_be_Forbidden_message_for_account_lookup_API(Integer int1) {
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
	@When("user perform POST operation by sending valid value for ALTACCOUNT of account lookup API")
	public void user_perform_POST_operation_by_sending_valid_value_for_ALTACCOUNT_of_account_lookup_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_2183_ALTAccount_lookup_MultipleFiltervalue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_ALTAccount_lookup_MultipleFiltervalue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Lookup");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_lookupAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_lookupAPI "+response.getBody().asString());
	    }
		
	}

	@Then("the response status code should be {int} OK for account lookup API")
	public void the_response_status_code_should_be_OK_for_account_lookup_API(Integer int1) {
	    
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
		String resultresponce	=response.getBody().asString();
		System.out.println("valid json responce body"+resultresponce);
		Reporter.addStepLog("valid responce code  "+resultresponce );
		
	}
	
	@When("user perform POST operation by sending valid value for UNIVERSALACCOUNT of account lookup API")
	public void user_perform_POST_operation_by_sending_valid_value_for_UNIVERSALACCOUNT_of_account_lookup_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_2183_Account_lookup_UNIVERSALACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_Account_lookup_UNIVERSALACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Lookup");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_lookupAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_lookupAPI "+response.getBody().asString());
	    }
	}
	
	@When("user perform POST operation by sending valid value ACCOUNT of account lookup API")
	public void user_perform_POST_operation_by_sending_valid_value_ACCOUNT_of_account_lookup_API() throws IOException {
	    
		
		File f = new File(jsonpath+"AL_2183_Account_lookup_ACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_2183_Account_lookup_ACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
	        String BasPath	= Action.getTestData("Lookup");
		    System.out.println("requests Account_infoAPI"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL+BasPath);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Account_lookupAPI "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Account_lookupAPI "+response.getBody().asString());
	    }
	}
	
	

}
