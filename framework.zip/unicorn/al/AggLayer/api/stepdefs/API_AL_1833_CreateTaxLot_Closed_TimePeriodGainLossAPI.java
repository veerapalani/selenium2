package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1833_CreateTaxLot_Closed_TimePeriodGainLossAPI {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int InvalidStatuscode401 =401;
	int Statuscode= 200;
	
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("getGainLoss API is active")
	public void getgainloss_API_is_active() throws Throwable, IOException, ParseException, JSONException {
		 RestApiUtils.requestSpecification=null;
	 	 RestAssured.baseURI=null;
	      RestAssured.basePath="";
	      tokengen.OpenBeareretokenURL();
		 	//tokengen.fetchToken();
		 	Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@When("user send the request with parameters for SummaryOnly as SUMMARY , DETAILS  in API")
	public void user_send_the_request_with_parameters_for_SummaryOnly_as_SUMMARY_DETAILS_in_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_1833_SummaryOnlyasTrue.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_SummaryOnlyasTrue.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}

	@Then("the response status code {int} OK should be displayed for getGainLoss API")
	public void the_response_status_code_OK_should_be_displayed_for_getGainLoss_API(Integer int1) {
	   
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
	}

	@Then("user should be able to see response as per swagger document")
	public void user_should_be_able_to_see_response_as_per_swagger_document() {
	   
		 System.out.println("valid responce code  : "+response.asString());
		   Reporter.addStepLog("valid responce code  : "+response.asString() );
	}
	@When("user send the request with parameters such as account, frequencytype, searchdate and taxJurisdiction in API")
	public void user_send_the_request_with_parameters_such_as_account_frequencytype_searchdate_and_taxJurisdiction_in_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_1833_ValidInputs.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_ValidInputs.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	@When("user send the request with parameters for Taxjurisdiction as Puerto Rico in API")
	public void user_send_the_request_with_parameters_for_Taxjurisdiction_as_Puerto_Rico_in_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_1833_Taxjurisdiction_as_Puerto_Rico.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_Taxjurisdiction_as_Puerto_Rico.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	@When("user send the request with parameters for Taxjurisdiction as United State in API")
	public void user_send_the_request_with_parameters_for_Taxjurisdiction_as_United_State_in_API() throws IOException {
	 
		File f = new File(jsonpath+"AL_1833_Taxjurisdiction_as_United_State.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_Taxjurisdiction_as_United_State.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	@When("user send the request with valid parameters such as account, FilterCriteria and filterValue in API")
	public void user_send_the_request_with_valid_parameters_such_as_account_FilterCriteria_and_filterValue_in_API() throws IOException {
		File f = new File(jsonpath+"AL_1833_WithValid_UNIVERSALACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_WithValid_UNIVERSALACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	@When("user send the request with valid parameters such as ALTACCOUNT, FilterCriteria and filterValue in API")
	public void user_send_the_request_with_valid_parameters_such_as_ALTACCOUNT_FilterCriteria_and_filterValue_in_API() throws IOException {
	    
		File f = new File(jsonpath+"AL_1833_WithValid_ALTACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_WithValid_ALTACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	@When("user send the request with valid parameters such as ACCOUNT, FilterCriteria and filterValue in API")
	public void user_send_the_request_with_valid_parameters_such_as_ACCOUNT_FilterCriteria_and_filterValue_in_API() throws IOException {
		File f = new File(jsonpath+"AL_1833_WithValid_ACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_WithValid_ACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	@When("user perform POST request by sending the invalid BaseURL in getGainLoss API")
	public void user_perform_POST_request_by_sending_the_invalid_BaseURL_in_getGainLoss_API() throws IOException {
		File f = new File(jsonpath+"AL_1833_WithValid_ACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_WithValid_ACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/plutusapi/taxlots/closed/timeperi";
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}

	@Then("the response code {int} with status not found is displayed for getGainLoss API")
	public void the_response_code_with_status_not_found_is_displayed_for_getGainLoss_API(Integer int1) {
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
	}
	@When("user perform POST operation with invalid authorization token for getGainLoss API")
	public void user_perform_POST_operation_with_invalid_authorization_token_for_getGainLoss_API() throws IOException {
		File f = new File(jsonpath+"AL_1833_WithValid_ACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_WithValid_ACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			// RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be {int} Forbidden message for API is displayed")
	public void the_response_status_code_should_be_Forbidden_message_for_API_is_displayed(Integer int1) {
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		 String resultresponce =response.getBody().asString();
	}
	
	@When("user send the request with invalid parameters in filterCriteria and filterValue")
	public void user_send_the_request_with_invalid_parameters_in_filterCriteria_and_filterValue() throws IOException {
	 
		
		File f = new File(jsonpath+"AL_1833_WithInValid_ACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_WithInValid_ACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}

	@Then("the response BAD_REQUEST and status code {int} should be displayed")
	public void the_response_BAD_REQUEST_and_status_code_should_be_displayed(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();	
	}
	@When("user send the request with parameters for frequencyType as MONTHLY in API")
	public void user_send_the_request_with_parameters_for_frequencyType_as_MONTHLY_in_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_1833_frequencyType_as_MONTHLY.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_frequencyType_as_MONTHLY.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	
	@When("user send the request with parameters for frequencyType as YEARLY in API")
	public void user_send_the_request_with_parameters_for_frequencyType_as_YEARLY_in_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_1833_frequencyType_as_YEARLY.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_frequencyType_as_YEARLY.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	@When("user send the request with parameters for frequencyType as QUATERLY in API")
	public void user_send_the_request_with_parameters_for_frequencyType_as_QUATERLY_in_API() throws IOException {
	   
		File f = new File(jsonpath+"AL_1833_frequencyType_as_QUATERLY.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_frequencyType_as_QUATERLY.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	}
	
	@When("user perform POST request for Taxjurisdiction as United State in API with UNIVERSALACCOUNT")
	public void user_perform_POST_request_for_Taxjurisdiction_as_United_State_in_API_with_UNIVERSALACCOUNT() throws IOException {
		
		File f = new File(jsonpath+"AL_1833_Taxjurisdiction_as_United_State_with_UNIVERSALACCOUNT.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1833_Taxjurisdiction_as_United_State_with_UNIVERSALACCOUNT.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests BrRegisteredRepcode"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for SummaryOnly as SUMMARY , DETAILS  in API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for SummaryOnly as SUMMARY , DETAILS  in APIe "+response.getBody().asString());
	    }
	   
	}
}