package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1302_MigrateTransactionAPIcodetoplutuscodebase {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int InvalidStatuscode401=401;
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();

	
	@Given("generate the bearer token for Transaction API")
	public void generate_the_bearer_token_for_Transaction_API() throws InterruptedException, IOException, ParseException, JSONException {
	 
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@Given("Transaction API service is available")
	public void transaction_API_service_is_available() {
	    
		RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@When("we post the API requests with valid accountIds and securityNumbers")
	public void we_post_the_API_requests_with_valid_accountIds_and_securityNumbers() throws IOException {
	    
		File f = new File(jsonpath+"AL_1302_validaccountIdsandsecurityNumbers.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1302_validaccountIdsandsecurityNumbers.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Transaction API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Transaction API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Transaction API "+response.getBody().asString());
	    }
	}

	@Then("the data is returned back on the response and status code should be {int} for Transaction API")
	public void the_data_is_returned_back_on_the_response_and_status_code_should_be_for_Transaction_API(Integer int1) {
	   
		System.out.println("valid responce code for Transaction API  "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code for Transaction API "+response.getStatusCode() );
		
	}
	
	@When("we post the API requests with invalid accountIds and securityNumbers")
	public void we_post_the_API_requests_with_invalid_accountIds_and_securityNumbers() throws IOException {
		File f = new File(jsonpath+"AL_1302_invalidaccountIdsandsecurityNumbers.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1302_invalidaccountIdsandsecurityNumbers.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Transaction API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Transaction API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Transaction API "+response.getBody().asString()); 
	}
	}
	@Then("gets response with message Not Found and status code should be {int} for Transaction API")
	public void gets_response_with_message_Not_Found_and_status_code_should_be_for_Transaction_API(Integer int1) {
	   
		System.out.println("valid responce code for Transaction API  "+response.getStatusCode());
		//Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		Reporter.addStepLog("valid responce code for Transaction API "+response.getStatusCode() );
	}
	
	@When("we post the API requests with valid accountIds and invalid securityNumbers")
	public void we_post_the_API_requests_with_valid_accountIds_and_invalid_securityNumbers() throws IOException {
	   
		File f = new File(jsonpath+"AL_1302_validaccountIdsandinvalidsecurityNumbers.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1302_validaccountIdsandinvalidsecurityNumbers.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Transaction API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Transaction API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Transaction API "+response.getBody().asString());
	}
	}
	@When("we post the API requests with valid accountIds and valid securityNumbers")
	public void we_post_the_API_requests_with_valid_accountIds_and_valid_securityNumbers() throws IOException {
		File f = new File(jsonpath+"AL_1302_validaccountIdsandsecurityNumbers.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1302_validaccountIdsandsecurityNumbers.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.dev.apidev1.npd.bfsaws.net/plutusapi/transactio";
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Transaction API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Transaction API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Transaction API "+response.getBody().asString());
	    }
	}
	
	@When("we post the API requests with valid multiple accountIds and securityNumbers")
	public void we_post_the_API_requests_with_valid_multiple_accountIds_and_securityNumbers() throws IOException {
		File f = new File(jsonpath+"AL_1302_validmultipleaccountIds.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1302_validmultipleaccountIds.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Transaction API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Transaction API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Transaction API "+response.getBody().asString());
		
	}
	}

	@Then("gets response with message Bad Request and status code should be {int} for Transaction API")
	public void gets_response_with_message_Bad_Request_and_status_code_should_be_for_Transaction_API(Integer int1) {
		System.out.println("valid responce code for Transaction API  "+response.getStatusCode());
		//Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		Reporter.addStepLog("valid responce code for Transaction API "+response.getStatusCode() );
	}

	@When("we post the API requests with valid accountIds and securityNumbers with invalid entryDateFrom")
	public void we_post_the_API_requests_with_valid_accountIds_and_securityNumbers_with_invalid_entryDateFrom() throws IOException {
		File f = new File(jsonpath+"AL_1302_validmultipleaccountIds.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1302_invalidentryDateFrom.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Transaction API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Transaction API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Transaction API "+response.getBody().asString());
		
	}
	}
	

	@When("we post the API requests with valid accountIds and securityNumbers with invalid entryDateTo")
	public void we_post_the_API_requests_with_valid_accountIds_and_securityNumbers_with_invalid_entryDateTo() throws IOException {
		File f = new File(jsonpath+"AL_1302_invalidentryDateTo.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1302_invalidentryDateTo.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Transaction API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Transaction API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Transaction API "+response.getBody().asString());
		
	}
	}

	@Then("returns response with error Forbidden and status code should be {int} for Transaction API")
	public void returns_response_with_error_Forbidden_and_status_code_should_be_for_Transaction_API(Integer int1) {
		System.out.println("valid responce code for Transaction API  "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		Reporter.addStepLog("valid responce code for Transaction API "+response.getStatusCode() );
	}
}
