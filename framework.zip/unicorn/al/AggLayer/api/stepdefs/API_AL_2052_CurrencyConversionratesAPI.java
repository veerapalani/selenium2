package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_2052_CurrencyConversionratesAPI {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	 public String PreconditionScript;
	 public String jsonISOCODE;
	 public String ResponcejsonISOCODE;
	 public String ResponcejsonISOCODE1;
	 String SQLpath = Action.getTestData("ETLQuries");
	 
	 AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("generate the bearer token for Currency Conversion rates API")
	public void generate_the_bearer_token_for_Currency_Conversion_rates_API() throws InterruptedException, IOException, ParseException, JSONException {
	    
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@When("Currency Conversion rates API service is available")
	public void currency_Conversion_rates_API_service_is_available() {
	   
		 RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@Then("we run Pre-condition scripts")
	public void we_run_Pre_condition_scripts() throws FileNotFoundException {
	   
		/*File file=new File(SQLpath+"PreconditionScript.txt");
        @SuppressWarnings("resource")
		Scanner sc=new Scanner(file);
        while(sc.hasNextLine()){
        	PreconditionScript=sc.nextLine();
        	 }
	   
	    Connection conn = null;
        try {
        	Class.forName("org.postgresql.Driver");  
        	conn = DriverManager.getConnection(Action.getTestData("DBURL"),Action.getTestData("DBUsername"), Action.getTestData("DBPassword"));
           System.out.println("Connected to the PostgreSQL server successfully.");
           Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);           
           ResultSet rs = stmt.executeQuery(PreconditionScript); 
          
            	rs.close();
                stmt.close(); 
               }
        
                catch (SQLException e) {
                    System.out.println(e.getMessage());
                } catch (ClassNotFoundException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}*/
	}

	@Then("we post the API requests without any Currency ISO CODE")
	public void we_post_the_API_requests_without_any_Currency_ISO_CODE() throws JSONException, InterruptedException, IOException, ParseException {
		
		//tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests Currency ISO CODE value"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Currency ISO CODE "+BaseURL);
			 RestApiUtils.requestSpecification.contentType("application/json");
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
	    	 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json Currency ISO CODE "+response.getBody().asString());
			Reporter.addStepLog("Responce json Currency ISO CODE "+response.getBody().asString());
	    }
	   
	

	@Then("the data is returned back on the response and status code should be {int} for Currency ISO CODE")
	public void the_data_is_returned_back_on_the_response_and_status_code_should_be_for_Currency_ISO_CODE(Integer int1) {
	   
		System.out.println("valid responce code   "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code  "+response.getStatusCode() );
		
	}
	
	@Then("we post the API requests with any Currency ISO CODE")
	public void we_post_the_API_requests_with_any_Currency_ISO_CODE() throws IOException, JSONException {
	 
		File f = new File(jsonpath+"AL2052_Currency_ISO_CODE.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL2052_Currency_ISO_CODE.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	       // jsonISOCODE =myObject.getString("isoCodes");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests Currency_ISO_CODE"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Currency_ISO_CODE "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Currency_ISO_CODE "+response.getBody().asString());
	    }
	}

	@Then("we validate the respective Currency ISO CODE matches")
	public void we_validate_the_respective_Currency_ISO_CODE_matches() throws JSONException {
	    
		String resultresponce	=response.getBody().asString();
		System.out.println("........................................................."+resultresponce);
		JSONObject myObject = new JSONObject(resultresponce);
	  //  ResponcejsonISOCODE=myObject.getString("currencyRates");
	    
	
	   
	    
	   
	}
	
	@Then("we post the API requests with Multiple Currency ISO CODE")
	public void we_post_the_API_requests_with_Multiple_Currency_ISO_CODE() throws JSONException, IOException {
	  
		
		File f = new File(jsonpath+"AL2052_Multiple_Currency_ISO_CODE.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL2052_Multiple_Currency_ISO_CODE.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	      //  jsonISOCODE =myObject.getString("isoCodes");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests Currency_ISO_CODE"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Currency_ISO_CODE "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Currency_ISO_CODE "+response.getBody().asString());
	    }
	}
	
	@Then("we validate the respective  Multiple Currency ISO CODE matches")
	public void we_validate_the_respective_Multiple_Currency_ISO_CODE_matches() throws JSONException {
	   
		
		String resultresponce	=response.getBody().asString();
		System.out.println("........................................................."+resultresponce);
		JSONObject myObject = new JSONObject(resultresponce);
	    ResponcejsonISOCODE=myObject.getString("currencyRates");
	    
	  String Resultsresponceisocode= ResponcejsonISOCODE.toString();
	    
	    System.out.println("........................................................."+Resultsresponceisocode);
	    
	    if(Resultsresponceisocode.contains(jsonISOCODE)) {
	    	
	    	System.out.println("validation for Currency ISO CODE matches and validation passed  ");
	    }
	    else {
	    	
	    	System.out.println("validation for Currency ISO CODE  doesnt matches and validation failed");
	    }
	    
	}
	
	@Then("we post the API requests with invalid {int} digit Currency ISO CODE")
	public void we_post_the_API_requests_with_invalid_digit_Currency_ISO_CODE(Integer int1) throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL2052invaliddigit_Currency_ISO_CODE.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL2052invaliddigit_Currency_ISO_CODE.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonISOCODE =myObject.getString("isoCodes");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests Currency_ISO_CODE"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Currency_ISO_CODE "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Currency_ISO_CODE "+response.getBody().asString());
	    }
	}

	@Then("gets response with message BAD_REQUEST and status code should be {int} for Currency ISO CODE")
	public void gets_response_with_message_BAD_REQUEST_and_status_code_should_be_for_Currency_ISO_CODE(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
	@Then("we post the API requests with invalid Four digit Currency ISO CODE")
	public void we_post_the_API_requests_with_invalid_Four_digit_Currency_ISO_CODE() throws JSONException, IOException {
	   
		File f = new File(jsonpath+"AL2052invalid-Four_digit_Currency_ISO_CODE.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL2052invalid-Four_digit_Currency_ISO_CODE.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        JSONObject myObject = new JSONObject(requestJson);
	        jsonISOCODE =myObject.getString("isoCodes");
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requests Currency_ISO_CODE"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Currency_ISO_CODE "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Currency_ISO_CODE "+response.getBody().asString());
	    }
	}
	
	@Then("we post the API requests with invalid API URL Currency ISO CODE")
	public void we_post_the_API_requests_with_invalid_API_URL_Currency_ISO_CODE() throws JSONException, IOException {
	    
		File f = new File(jsonpath+"AL2052invalid-Four_digit_Currency_ISO_CODE.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL2052invalid-Four_digit_Currency_ISO_CODE.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        
	        String BaseURL	= "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/plutusapi/currencies/rate";
		    System.out.println("requests Currency_ISO_CODE"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Currency_ISO_CODE "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Currency_ISO_CODE "+response.getBody().asString());
	    }
	}

	@Then("gets response with message NOT_FOUND and status code should be {int} for Currency ISO COD")
	public void gets_response_with_message_NOT_FOUND_and_status_code_should_be_for_Currency_ISO_COD(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
}
