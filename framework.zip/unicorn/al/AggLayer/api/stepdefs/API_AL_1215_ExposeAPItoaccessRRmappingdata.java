package qa.unicorn.al.AggLayer.api.stepdefs;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.RestApiUtils;

public class API_AL_1215_ExposeAPItoaccessRRmappingdata {
	
	int InvalidStatuscode =400;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	Response response;
	
	 

	@Given("table rr_mapping API URL with data table contains data")
	public void table_rr_mapping_API_URL_with_data_table_contains_data() {
	  
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
		
	}

	@When("we send the API requests with rr code mapping value")
	public void we_send_the_API_requests_with_rr_code_mapping_value() {
	  
		
	    String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requests with rr code mapping value"+BaseURL);
		String BasePath=Action.getTestData("by-rr-code");
		System.out.println("requests with rr code mapping value"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................1"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
	}

	@Then("the data is returned back on the response and status code should be {int}")
	public void the_data_is_returned_back_on_the_response_and_status_code_should_be(Integer int1) {
	   
		System.out.println("valid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		
	}
	
	@Given("table rr_mapping API URL with data table contains latest data")
	public void table_rr_mapping_API_URL_with_data_table_contains_latest_data() {
	    
		//String BaseURL	= Action.getTestData("BaseURI");
	}

	@When("send the API requests with rr latest code mapping value")
	public void send_the_API_requests_with_rr_latest_code_mapping_value() {
	   
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-rr-code_latest");
		System.out.println("valid url string ....................................2"+BaseURL+BasePath);
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
		
	}
	
	@When("we send the API requests with invalid rr code mapping value")
	public void we_send_the_API_requests_with_invalid_rr_code_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-rr-code_invalid");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................3"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}

	@Then("gets response with message BAD_REQUEST and status code should be {int}")
	public void gets_response_with_message_BAD_REQUEST_and_status_code_should_be(Integer int1) {
	   
		    System.out.println("invalid responce code "+response.getStatusCode());
			Assert.assertEquals(response.getStatusCode(), InvalidStatuscode);
			 String resultresponce =response.getBody().asString();
			 System.out.println( "Invalid responce boday"+resultresponce);
			 if(resultresponce.contains("BAD_REQUEST")) {
				 
				 System.out.println("validation passed");
				 
			 }
			 else {
				 
				 System.out.println("validation failed");
				 
			 }
		
	}
	
	@When("we send the API requests with no rr code mapping value")
	public void we_send_the_API_requests_with_no_rr_code_mapping_value() {
		
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("No-rr-code");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................4"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	    
	}

	@Then("gets response with message Not Found and status code should be {int}")
	public void gets_response_with_message_Not_Found_and_status_code_should_be(Integer int1) {
	   
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
		 if(resultresponce.contains("Not Found")) {
			 
			 System.out.println("validation passed");
			 
		 }
		 else {
			 
			 System.out.println("validation failed");
			 
		 }
		
		
	}
	
	@When("we send the API requests with invalid latest rr code mapping value")
	public void we_send_the_API_requests_with_invalid_latest_rr_code_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("invalid-latest-rr-code");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................5"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	
	}
	
	@When("we send the API requests with no latest rr code mapping value")
	public void we_send_the_API_requests_with_no_latest_rr_code_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("No-latest-rr-code");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................6"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		

		
	}
	
	@When("send the API requests with faCode mapping value")
	public void send_the_API_requests_with_faCode_mapping_value() {
		
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    
		String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-fa-code");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................7"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	    
		
	}
	
	@When("send the API requests with invalid fa code mapping value")
	public void send_the_API_requests_with_invalid_fa_code_mapping_value() {
	   
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-fa-code_invalid");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................8"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}

	@When("send the API requests with no fa code mapping value")
	public void send_the_API_requests_with_no_fa_code_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-No-fa-code");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................9"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
		
	}
	
	@When("send the API requests with rr latest facode mapping value")
	public void send_the_API_requests_with_rr_latest_facode_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-fa-code_latest");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................10"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}

	@When("send the API requests with invalid latest facode mapping value")
	public void send_the_API_requests_with_invalid_latest_facode_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-fa-code_latest_invalid");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................11"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}

	@When("send the API requests with no latest facode mapping value")
	public void send_the_API_requests_with_no_latest_facode_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-fa-code_latest_No");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................12"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}
	
	@When("send the API requests with universalId mapping value")
	public void send_the_API_requests_with_universalId_mapping_value() {
		
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-univ-id");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................13"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
		
	}

	@When("send the API requests with invalid universalId mapping value")
	public void send_the_API_requests_with_invalid_universalId_mapping_value() {
	   
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-univ-id_invalid");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................14"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}

	@When("send the API requests with no universalId mapping value")
	public void send_the_API_requests_with_no_universalId_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-univ-id_No");
		System.out.println("valid url string ....................................15"+BaseURL+BasePath);
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}
	
	@When("send the API requests with latest universalId mapping value")
	public void send_the_API_requests_with_latest_universalId_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-univ-id_latest");
		System.out.println("valid url string ....................................16"+BaseURL+BasePath);
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}

	@When("send the API requests with invalid latest universalId mapping value")
	public void send_the_API_requests_with_invalid_latest_universalId_mapping_value() {
	    
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-univ-id_invalid_latest");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................17"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}

	@When("send the API requests with no latest universalId mapping value")
	public void send_the_API_requests_with_no_latest_universalId_mapping_value() {
		
		RestApiUtils.requestSpecification=null;
		RestAssured.baseURI=null;
		RestAssured.basePath="";
	    String BaseURL	= Action.getTestData("BaseURI");
		String BasePath=Action.getTestData("by-univ-id_No_latest");
		RestApiUtils.setBaseURI(BaseURL+BasePath);
		System.out.println("valid url string ....................................18"+BaseURL+BasePath);
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(BaseURL+BasePath);
		
	}


}
