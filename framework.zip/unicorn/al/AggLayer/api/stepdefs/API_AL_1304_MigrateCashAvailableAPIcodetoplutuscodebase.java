package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1304_MigrateCashAvailableAPIcodetoplutuscodebase {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode404 =404;
	int InvalidStatuscode401=401;
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();

	
	@Given("generate the bearer token for Cash Available API")
	public void generate_the_bearer_token_for_Cash_Available_API() throws InterruptedException, IOException, ParseException, JSONException {
	    
		tokengen.OpenBeareretokenURL();
		//tokengen.fetchToken();
		Reporter.addStepLog("bearere token"+tokengen.genratedtoken);
	}

	@Given("Cash Available API service is available")
	public void cash_Available_API_service_is_available() {
	    
		RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@When("we post the API requests with with valid accountIdentifier and CurrencyCode")
	public void we_post_the_API_requests_with_with_valid_accountIdentifier_and_CurrencyCode() throws IOException {
	    
		File f = new File(jsonpath+"AL_1304_validaccountIdentifierandCurrencyCodeforcashavilableapi.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1304_validaccountIdentifierandCurrencyCodeforcashavilableapi.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Cash Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Cash Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Cash Available API "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Cash Available API "+response.getBody().asString());
	    }
	}

	@Then("the data is returned back on the response and status code should be {int} for Cash Available API")
	public void the_data_is_returned_back_on_the_response_and_status_code_should_be_for_Cash_Available_API(Integer int1) {
		System.out.println("valid responce code for Cash Available API  "+response.getStatusCode());
	   Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code for Cash Available API "+response.getStatusCode() );
	}
	
	@When("user performs POST operations  by sending the paramenter such as valid accountIdentifier and invalid CurrencyCode")
	public void user_performs_POST_operations_by_sending_the_paramenter_such_as_valid_accountIdentifier_and_invalid_CurrencyCode() throws IOException {
	    
		File f = new File(jsonpath+"AL_1304_validaccountIdentifierandinvalidCurrencyCodeforcashavilableapi.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1304_validaccountIdentifierandinvalidCurrencyCodeforcashavilableapi.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Cash Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Cash Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Cash Available API with invalid currencycode"+response.getBody().asString());
			Reporter.addStepLog("Responce json for Cash Available API with invalid currencycode "+response.getBody().asString());
	    }
	}

	@Then("the response status code should be  {string} for Cash Available API")
	public void the_response_status_code_should_be_for_Cash_Available_API(String string) {
	 
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	@When("user performs POST operations  by sending the paramenter such as invalid accountIdentifier and valid CurrencyCode")
	public void user_performs_POST_operations_by_sending_the_paramenter_such_as_invalid_accountIdentifier_and_valid_CurrencyCode() throws IOException {
		File f = new File(jsonpath+"AL_1304_invalidaccountIdentifierandvalidCurrencyCodeforcashavilableapi.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1304_invalidaccountIdentifierandvalidCurrencyCodeforcashavilableapi.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= "https://api.us-east-1.dev.apidev1.npd.bfsaws.net/plutusapi/balance/cash-availabl";
		    System.out.println("requestsfor Cash Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Cash Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Cash Available API with valid currencycode and inavlid accountidentifier"+response.getBody().asString());
			Reporter.addStepLog("Responce json for Cash Available API with valid currencycode and inavlid accountidentifier"+response.getBody().asString());
	    }  
	}

	@Then("the response status code should be  {int} for Cash Available API")
	public void the_response_status_code_should_be_for_Cash_Available_API(Integer int1) {
	    
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
	
	@When("user performs POST operations  by sending the paramenter such as  valid CurrencyCode")
	public void user_performs_POST_operations_by_sending_the_paramenter_such_as_valid_CurrencyCode() throws IOException {
	   
		File f = new File(jsonpath+"AL_1304_validCurrencyCodeforcashavilableapi.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1304_validCurrencyCodeforcashavilableapi.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Cash Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Cash Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Cash Available API with valid currencycode "+response.getBody().asString());
			Reporter.addStepLog("Responce json for Cash Available API with valid currencycode "+response.getBody().asString());
	    }  
	}

	@When("user performs POST operations  by sending the paramenter such as valid accountIdentifier")
	public void user_performs_POST_operations_by_sending_the_paramenter_such_as_valid_accountIdentifier() throws IOException {
		File f = new File(jsonpath+"AL_1304_validaccountIdentifierforcashavilableapi.json");
	    if (f.exists()){
	        InputStream is = new FileInputStream(jsonpath+"AL_1304_validaccountIdentifierforcashavilableapi.json");
	        String requestJson = IOUtils.toString(is, "UTF-8");
	        System.out.println("request json is : "+requestJson);
	        Reporter.addStepLog("request json is :"+requestJson);
	        String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Cash Available API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			 RestApiUtils.requestSpecification = RestAssured.given();
			 Reporter.addStepLog("Base URI for Cash Available API "+BaseURL);
			 RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization", "Bearer " + tokengen.genratedtoken);
			 RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			 response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			System.out.println("Responce json for Cash Available API with vlid accountidentifier"+response.getBody().asString());
			Reporter.addStepLog("Responce json for Cash Available API with vlid accountidentifier"+response.getBody().asString());
	    }  
	}
	
	@Then("status code should be {int} for Cash Available API")
	public void status_code_should_be_for_Cash_Available_API(Integer int1) {
		System.out.println("invalid responce code "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode401);
		 String resultresponce =response.getBody().asString();
		 System.out.println( "Invalid responce boday"+resultresponce);
	}
}
