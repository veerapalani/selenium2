package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;

public class API_AL_1915_DeleteCPIrecordsandvalidateamounts {

	int InvalidStatuscode400 = 400;
	int InvalidStatuscode404 = 404;
	int InvalidStatuscode401 = 401;
	int Statuscode = 200;
	Response response;
	String jsonpath = "src/test/resources/te/al/AggLayer/json/";
	String Responcejsonamount;
	String Responcejsonmonth;
	String jsonamount;
	String jsonmonth;
	// Beareretokenpage tokengen = new Beareretokenpage();

	AggLayerCommon tokengen = new AggLayerCommon();

	@Given("CPI Delete service API service is available")
	public void cpi_Delete_service_API_service_is_available()
			throws InterruptedException, IOException, ParseException, JSONException {

		RestApiUtils.requestSpecification = null;
		RestAssured.baseURI = null;
		RestAssured.basePath = "";
		tokengen.OpenBeareretokenURL();
		// tokengen.fetchToken();

		Reporter.addStepLog("bearere token" + tokengen.genratedtoken);
	}

	@When("we post the  delete API requests with valid month which has {int} working days and amount")
	public void we_post_the_delete_API_requests_with_valid_month_which_has_working_days_and_amount(Integer int1)
			throws JSONException, IOException {

		File f = new File(jsonpath + "AL_1786_31workingdays.json");
		if (f.exists()) {
			InputStream is = new FileInputStream(jsonpath + "AL_1786_31workingdays.json");
			String requestJson = IOUtils.toString(is, "UTF-8");
			System.out.println("request json is : " + requestJson);
			Reporter.addStepLog("request json is :" + requestJson);
			JSONObject myObject = new JSONObject(requestJson);
			String BaseURL = Action.getTestData("BaseURI");
			System.out.println("requests for CPI data service API" + BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			RestApiUtils.requestSpecification = RestAssured.given();
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			Reporter.addStepLog("Base URI for  API " + BaseURL);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			String BaseURL1 = Action.getTestData("BaseURI");
			String BasePath = Action.getTestData("BasePath");
			System.out.println("requests for CPI data service API" + BaseURL);
			RestApiUtils.setBaseURI(BaseURL1 + BasePath);
			RestApiUtils.requestSpecification = RestAssured.given();
			Reporter.addStepLog("Base URI for  API " + BaseURL1 + BasePath);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification,
					RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API " + response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API " + response.getBody().asString());
		}

	}

	@Then("the json response returned back and status code should be {int} for  CPI Delete service API")
	public void the_json_response_returned_back_and_status_code_should_be_for_CPI_Delete_service_API(Integer int1) {
		System.out.println("valid responce code for  CPI data service API  " + response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code for  CPI data service API " + response.getStatusCode());
	}

	@Then("verify  the deleted data from GET CPI service API")
	public void verify_the_deleted_data_from_GET_CPI_service_API() {
		RestApiUtils.setBaseURI(Action.getTestData("BaseURI"));
		Map<String, String> queryMap = new HashMap<String, String>();
		queryMap.put("month", "2020-01");
		response = RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI, queryMap);
	}

	@Then("the Data is returned back on the json response with error message NOT FOUND  and status code should be {int} for  CPI Delete service API")
	public void the_Data_is_returned_back_on_the_json_response_with_error_message_NOT_FOUND_and_status_code_should_be_for_CPI_Delete_service_API(
			Integer int1) {

		System.out.println("invalid responce code " + response.getStatusCode());
		// Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		String resultresponce = response.getBody().asString();
		System.out.println("Invalid responce boday" + resultresponce);
	}

	@When("we post delete API requests with valid month which has {int} working days and amount")
	public void we_post_delete_API_requests_with_valid_month_which_has_working_days_and_amount(Integer int1)
			throws JSONException, IOException {

		File f = new File(jsonpath + "AL_1786_30workingdays.json");
		if (f.exists()) {
			InputStream is = new FileInputStream(jsonpath + "AL_1786_30workingdays.json");
			String requestJson = IOUtils.toString(is, "UTF-8");
			System.out.println("request json is : " + requestJson);
			Reporter.addStepLog("request json is :" + requestJson);
			JSONObject myObject = new JSONObject(requestJson);
			String BaseURL = Action.getTestData("BaseURI");
			System.out.println("requests for CPI data service API" + BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			RestApiUtils.requestSpecification = RestAssured.given();
			Reporter.addStepLog("Base URI for  API " + BaseURL);
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			// RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification,
			// RestAssured.baseURI);
			String BaseURL1 = Action.getTestData("BaseURI");
			String BasePath = Action.getTestData("BasePath");
			System.out.println("requests for CPI data service API" + BaseURL);
			RestApiUtils.setBaseURI(BaseURL1 + BasePath);
			RestApiUtils.requestSpecification = RestAssured.given();
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			Reporter.addStepLog("Base URI for  API " + BaseURL1 + BasePath);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification,
					RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API " + response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API " + response.getBody().asString());

		}
	}

	@Then("verify  the deleted data from GET CPI service API for {int} working days")
	public void verify_the_deleted_data_from_GET_CPI_service_API_for_working_days(Integer int1) {
		RestApiUtils.setBaseURI(Action.getTestData("BaseURI"));
		Map<String, String> queryMap = new HashMap<String, String>();
		queryMap.put("month", "2020-04");
		response = RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI, queryMap);

	}

	@When("we post delete API requests with valid month which has {int} working days")
	public void we_post_delete_API_requests_with_valid_month_which_has_working_days(Integer int1)
			throws JSONException, IOException {
		File f = new File(jsonpath + "AL_1786_28workingdays.json");
		if (f.exists()) {
			InputStream is = new FileInputStream(jsonpath + "AL_1786_28workingdays.json");
			String requestJson = IOUtils.toString(is, "UTF-8");
			System.out.println("request json is : " + requestJson);
			Reporter.addStepLog("request json is :" + requestJson);
			JSONObject myObject = new JSONObject(requestJson);
			String BaseURL = Action.getTestData("BaseURI");
			System.out.println("requests for CPI data service API" + BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			RestApiUtils.requestSpecification = RestAssured.given();
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			Reporter.addStepLog("Base URI for  API " + BaseURL);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			String BaseURL1 = Action.getTestData("BaseURI");
			String BasePath = Action.getTestData("BasePath");
			System.out.println("requests for CPI data service API" + BaseURL);
			RestApiUtils.setBaseURI(BaseURL1 + BasePath);
			RestApiUtils.requestSpecification = RestAssured.given();
			Reporter.addStepLog("Base URI for  API " + BaseURL1 + BasePath);
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification,
					RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API " + response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API " + response.getBody().asString());
		}
	}

	@Then("verify the deleted data from GET CPI API for {int} working days")
	public void verify_the_deleted_data_from_GET_CPI_API_for_working_days(Integer int1) {
		RestApiUtils.setBaseURI(Action.getTestData("BaseURI"));
		Map<String, String> queryMap = new HashMap<String, String>();
		queryMap.put("month", "2019-02");
		response = RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI, queryMap);
	}

	@When("we post delete API requests with valid month which has {int} working days and Amount")
	public void we_post_delete_API_requests_with_valid_month_which_has_working_days_and_Amount(Integer int1)
			throws JSONException, IOException {

		File f = new File(jsonpath + "AL_1786_29workingdays.json");
		if (f.exists()) {
			InputStream is = new FileInputStream(jsonpath + "AL_1786_29workingdays.json");
			String requestJson = IOUtils.toString(is, "UTF-8");
			System.out.println("request json is : " + requestJson);
			Reporter.addStepLog("request json is :" + requestJson);
			JSONObject myObject = new JSONObject(requestJson);
			String BaseURL = Action.getTestData("BaseURI");
			System.out.println("requests for CPI data service API" + BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
			RestApiUtils.requestSpecification = RestAssured.given();
			Reporter.addStepLog("Base URI for  API " + BaseURL);
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification, RestAssured.baseURI);
			String BaseURL1 = Action.getTestData("BaseURI");
			String BasePath = Action.getTestData("BasePath");
			System.out.println("requests for CPI data service API" + BaseURL);
			RestApiUtils.setBaseURI(BaseURL1 + BasePath);
			RestApiUtils.requestSpecification = RestAssured.given();
			Reporter.addStepLog("Base URI for  API " + BaseURL1 + BasePath);
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification,
					RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API " + response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API " + response.getBody().asString());
		}
	}

	@Then("verify  the deleted data using GET CPI service API for {int} days")
	public void verify_the_deleted_data_using_GET_CPI_service_API_for_days(Integer int1) {
		RestApiUtils.setBaseURI(Action.getTestData("BaseURI"));
		Map<String, String> queryMap = new HashMap<String, String>();
		queryMap.put("month", "2020-02");
		response = RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI, queryMap);
	}

	@When("we post the API  CPI Delete requests with invalid month  and amount")
	public void we_post_the_API_CPI_Delete_requests_with_invalid_month_and_amount() throws JSONException, IOException {

		File f = new File(jsonpath + "AL_1915_invalidmonth.json");
		if (f.exists()) {
			InputStream is = new FileInputStream(jsonpath + "AL_1915_invalidmonth.json");
			String requestJson = IOUtils.toString(is, "UTF-8");
			System.out.println("request json is : " + requestJson);
			Reporter.addStepLog("request json is :" + requestJson);
			JSONObject myObject = new JSONObject(requestJson);
			String BaseURL1 = Action.getTestData("BaseURI");
			String BasePath = Action.getTestData("BasePath");
			System.out.println("requests for CPI data service API" + BaseURL1);
			RestApiUtils.setBaseURI(BaseURL1 + BasePath);
			RestApiUtils.requestSpecification = RestAssured.given();
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			Reporter.addStepLog("Base URI for  API " + BaseURL1 + BasePath);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification,
					RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API " + response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API " + response.getBody().asString());
		}
	}

	@Then("returns response with error Bad Request and status code should be {int} for CPI Delete service API")
	public void returns_response_with_error_Bad_Request_and_status_code_should_be_for_CPI_Delete_service_API(
			Integer int1) {

		System.out.println("invalid responce code " + response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		String resultresponce = response.getBody().asString();
		System.out.println("Invalid responce boday" + resultresponce);
	}

	@When("we post the API  CPI Delete requests with invalid amount")
	public void we_post_the_API_CPI_Delete_requests_with_invalid_amount() throws JSONException, IOException {

		File f = new File(jsonpath + "AL_1915_invalidamount.json");
		if (f.exists()) {
			InputStream is = new FileInputStream(jsonpath + "AL_1915_invalidamount.json");
			String requestJson = IOUtils.toString(is, "UTF-8");
			System.out.println("request json is : " + requestJson);
			Reporter.addStepLog("request json is :" + requestJson);
			JSONObject myObject = new JSONObject(requestJson);
			String BaseURL1 = Action.getTestData("BaseURI");
			String BasePath = Action.getTestData("BasePath");
			System.out.println("requests for CPI data service API" + BaseURL1);
			RestApiUtils.setBaseURI(BaseURL1 + BasePath);
			RestApiUtils.requestSpecification = RestAssured.given();
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			Reporter.addStepLog("Base URI for  API " + BaseURL1 + BasePath);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification,
					RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API " + response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API " + response.getBody().asString());
		}

	}

	@When("we post the API  CPI Delete requests with invalid API URL")
	public void we_post_the_API_CPI_Delete_requests_with_invalid_API_URL() throws JSONException, IOException {

		File f = new File(jsonpath + "AL_1915_invalidamount.json");
		if (f.exists()) {
			InputStream is = new FileInputStream(jsonpath + "AL_1915_invalidamount.json");
			String requestJson = IOUtils.toString(is, "UTF-8");
			System.out.println("request json is : " + requestJson);
			Reporter.addStepLog("request json is :" + requestJson);
			JSONObject myObject = new JSONObject(requestJson);
			String BaseURL1 = "https://api.us-east-1.dev.apiqa.npd.bfsaws.net/wapi/cpi/delete";
			System.out.println("requests for CPI data service API" + BaseURL1);
			RestApiUtils.setBaseURI(BaseURL1);
			RestApiUtils.requestSpecification = RestAssured.given();
			RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Authorization",
					"Bearer " + tokengen.genratedtoken);
			System.out.println("Base URI for  API BaseURL1 " + RestAssured.baseURI);
			Reporter.addStepLog("Base URI for  API BaseURL1 " + BaseURL1);
			RestApiUtils.requestSpecification.contentType("application/json").body(requestJson);
			response = RestApiUtils.postRequestwithrelaxedhttpvalidation(RestApiUtils.requestSpecification,
					RestAssured.baseURI);
			System.out.println("Responce json for  CPI data service API " + response.getBody().asString());
			Reporter.addStepLog("Responce json for CPI data service API " + response.getBody().asString());
		}
	}

}
