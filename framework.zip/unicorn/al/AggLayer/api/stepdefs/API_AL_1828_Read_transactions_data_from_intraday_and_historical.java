package qa.unicorn.al.AggLayer.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.al.AggLayer.webui.pages.Beareretokenpage;

public class API_AL_1828_Read_transactions_data_from_intraday_and_historical {
	
	int InvalidStatuscode400 =400;
	int InvalidStatuscode401 =401;
	int InvalidStatuscode404 =404;
	int Statuscode= 200;
	Response response;
	String jsonpath ="src/test/resources/te/al/AggLayer/json/";
	//Beareretokenpage tokengen = new Beareretokenpage();
	
	AggLayerCommon tokengen = new AggLayerCommon();
	
	@Given("Transaction api is service active")
	public void transaction_api_is_service_active() {
	   
		RestApiUtils.requestSpecification=null;
		 RestAssured.baseURI=null;
	     RestAssured.basePath="";
	}

	@When("user perform GET oprtaion by sending the paramenter as accountBranch, accountNumber transactionType")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_as_accountBranch_accountNumber_transactionType() {
	 
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountBranch","098");
		queryMap.put("accountNumber", "20080");
		queryMap.put("transactionType","TRD");
		 String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
	 response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("The response status code should be {int} ok for Transaction API")
	public void the_response_status_code_should_be_ok_for_Transaction_API(Integer int1) {
		System.out.println("valid responce code for Transaction API  "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), Statuscode);
		Reporter.addStepLog("valid responce code for Transaction API "+response.getStatusCode() );
	}

	@Then("user should able to see valid json response for Transaction API")
	public void user_should_able_to_see_valid_json_response_for_Transaction_API() {
	   System.out.println("valid responce code  : "+response.asString());
	   Reporter.addStepLog("valid responce code  : "+response.asString() );
	}
	
	@When("user perform GET oprtaion by sending the paramenter as accountBranch,accountNumber ,transactionType and instrumentIdentifier")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_as_accountBranch_accountNumber_transactionType_and_instrumentIdentifier() {
	   
		Map<String,String> queryMap=new HashMap<String,String>();
		queryMap.put("accountBranch","098");
		queryMap.put("accountNumber", "20080");
		queryMap.put("transactionType","TRD");
		//queryMap.put("instrumentIdentifier","W009635");
		String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requestsfor Transaction API"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@When("User perform GET oprtaion by sending the paramenter with invalid instrumentIdentifierType")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_with_invalid_instrumentIdentifierType() {
	 
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountBranch","XYZ");
		queryMap.put("accountNumber", "12342");
		queryMap.put("transactionType","TRD");
		queryMap.put("instrumentIdentifier","W0095");
		String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requestsfor Transaction API"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("The response status code should be {int} with error {string} for Transaction API")
	public void the_response_status_code_should_be_with_error_for_Transaction_API(Integer int1, String string) {
		System.out.println("invalid responce code for Transaction API  "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		Reporter.addStepLog("invalid responce code for Transaction API "+response.getStatusCode() );
	}

	@Then("User should able to see invalid  response with error {string} for Transaction API")
	public void user_should_able_to_see_invalid_response_with_error_for_Transaction_API(String string) {
		System.out.println("invalid responce  for Transaction API  "+response.asString());
		Reporter.addStepLog("invalid responce  for Transaction API  "+response.asString() );
	}

	@When("User perform GET oprtaion by sending the paramenter with invalid transactionType")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_with_invalid_transactionType() {
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountBranch","XYZ");
		queryMap.put("accountNumber", "12342");
		queryMap.put("transactionType","TR");
		queryMap.put("instrumentIdentifier","W009635");
		String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requestsfor Transaction API"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}
	@When("User perform GET oprtaion by sending the paramenter as with valid accountBranch, accountNumber and execluding transactionType")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_as_with_valid_accountBranch_accountNumber_and_execluding_transactionType() {
	    
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountBranch","XYZ");
		queryMap.put("accountNumber", "12342");
		queryMap.put("instrumentIdentifier","W009635");
		String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requestsfor Transaction API"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@Then("The response status code should be {int} with error Bad Request for Transaction API")
	public void the_response_status_code_should_be_with_error_Bad_Request_for_Transaction_API(Integer int1) {
	 
		System.out.println("invalid responce code for Transaction API  "+response.getStatusCode());
		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode400);
		Reporter.addStepLog("invalid responce code for Transaction API "+response.getStatusCode() );
	}

	@Then("User should able to see invalid  response with error Bad Request for Transaction API")
	public void user_should_able_to_see_invalid_response_with_error_Bad_Request_for_Transaction_API() {
	   
		System.out.println("invalid responce  for Transaction API  "+response.asString());
		Reporter.addStepLog("invalid responce  for Transaction API  "+response.asString() );
	}

	@When("user perform GET oprtaion by sending the paramenter as with valid accountBranch, accountNumber and execluding instrumentIdentifier")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_as_with_valid_accountBranch_accountNumber_and_execluding_instrumentIdentifier() {
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountBranch","XYZ");
		queryMap.put("accountNumber", "12342");
		queryMap.put("transactionType","TR");
	    String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requestsfor Transaction API"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
		
	}
	
	@When("User perform GET oprtaion by sending the paramenter as with valid accountBranch, transactionType and execluding accountNumber")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_as_with_valid_accountBranch_transactionType_and_execluding_accountNumber() {
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountBranch","XYZ");
		queryMap.put("transactionType","TRD");
		 String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
	 response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@When("user perform GET oprtaion by sending the paramenter as with valid accountBranch, transactionType and invalid accountNumber")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_as_with_valid_accountBranch_transactionType_and_invalid_accountNumber() {
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountBranch","XYZ");
		queryMap.put("accountNumber", "1234");
		queryMap.put("transactionType","TRD");
		 String BaseURL	= Action.getTestData("BaseURI");
		    System.out.println("requestsfor Transaction API"+BaseURL);
			RestApiUtils.setBaseURI(BaseURL);
	 response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}
	@When("User perform GET oprtaion by sending the paramenter as with valid accountNumber, transactionType and invalid accountBranch")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_as_with_valid_accountNumber_transactionType_and_invalid_accountBranch() {
	  
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountBranch","XY");
		queryMap.put("accountNumber", "12342");
		queryMap.put("transactionType","TRD");
		queryMap.put("instrumentIdentifier","W009635");
		String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requestsfor Transaction API"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}

	@When("User perform GET oprtaion by sending the paramenter as with valid accountNumber, transactionType and execluding accountBranch")
	public void user_perform_GET_oprtaion_by_sending_the_paramenter_as_with_valid_accountNumber_transactionType_and_execluding_accountBranch() {
	   
		Map<String,String> queryMap=new HashMap<String,String>();
	    queryMap.put("accountNumber", "12342");
		queryMap.put("transactionType","TRD");
		queryMap.put("instrumentIdentifier","W009635");
		String BaseURL	= Action.getTestData("BaseURI");
	    System.out.println("requestsfor Transaction API"+BaseURL);
		RestApiUtils.setBaseURI(BaseURL);
		response =RestApiUtils.getRequestwithQueryParamRelaxedHttpsValidation(RestAssured.baseURI,queryMap);
	}
	
}