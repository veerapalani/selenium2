package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.utils.Reporter;

public class HousePriceFileValidationUSM1649StepDef {
	String filePath;
	
	@Given("user has House Price File and the layout file")
	public void user_has_House_Price_File_and_the_layout_file() {
		filePath = "./src/test/resources/ad/securitymaster/api/excel/BGGG.PHPT.C003 (1).HP(+0).log";

	}
	@When("user check Security {string}should be avaailable in House Price File")
	public void user_check_Security_should_be_avaailable_in_House_Price_File(String msdId) {
		String  line;
		Boolean isAvailable=false;
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			while ((line = br.readLine()) != null) {
				if(line.contains(msdId)) {
					isAvailable =true;
					Reporter.addStepLog(" Security : "+ " <strong> "+ msdId + " </strong>");
					Reporter.addStepLog(" Data of the Security : "+ " <strong> "+ line + " </strong>");
				}
				
			}
			Assert.assertTrue(isAvailable, "Security Not Available");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}


	@Then("For Security {string} all the attributes should be as per layout")
	public void for_Security_all_the_attributes_should_be_as_per_layout(String msdId) {
		
		String  line;
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			while ((line = br.readLine()) != null) {
				if(line.contains(msdId)) {
					String	Base_Segment_ID	=	line.substring(0,2);
					Reporter.addStepLog(" Base Segment ID :"+ "<strong>"+Base_Segment_ID+ "</strong>");
					
					String	Base_Segment_Length	=	line.substring(10,14);	
					Reporter.addStepLog(" Base Segment Length :"+ "<strong>"+Base_Segment_Length+ "</strong>");
					
					String	Client_Number	=	line.substring(16,19);
					Reporter.addStepLog(" Client Number :"+ "<strong>"+Client_Number+ "</strong>");
					
					
					String	Branch_Number	=	line.substring(19,22);
					Reporter.addStepLog(" Branch Number :"+ "<strong>"+Branch_Number+ "</strong>");
					
					
					String	Base_Account_Number	=	line.substring(22,27);	
					Reporter.addStepLog(" Base Account Number :"+ "<strong>"+Base_Account_Number+ "</strong>");
					
					
					String	Account_Type	=	line.substring(27,28);	
					Reporter.addStepLog(" Account_Type :"+ "<strong>"+Account_Type+ "</strong>");
					
					
					String	Check_Digit	=	line.substring(28,29);
					Reporter.addStepLog(" Check Digit :"+ "<strong>"+Check_Digit+ "</strong>");
					
					
					
					String	Account_Currency	=	line.substring(29,32);	
					Reporter.addStepLog(" Account Currency :"+ "<strong>"+Account_Currency+ "</strong>");
					
					
					String	Transaction_Category	=	line.substring(48,49);
					Reporter.addStepLog(" Transaction Category :"+ "<strong>"+Transaction_Category+ "</strong>");
					
					
					String	Transaction_Type	=	line.substring(49,52);	
					Reporter.addStepLog(" Transaction Type :"+ "<strong>"+Transaction_Type+ "</strong>");
					
					
					String	Debit_Credit_Code	=	line.substring(53,55);	
					Reporter.addStepLog(" Debit Credit Code :"+ "<strong>"+Debit_Credit_Code+ "</strong>");
					
					
					
					String	Batch_Code	=	line.substring(208,210);
					Reporter.addStepLog(" Batch Code :"+ "<strong>"+Batch_Code+ "</strong>");
					
					
					String	Price_Code	=	line.substring(221,222);
					Reporter.addStepLog(" Price Code :"+ "<strong>"+Price_Code+ "</strong>");
					
					
					String	Dollar_Format	=	line.substring(222,223);	
					Reporter.addStepLog(" Dollar Format :"+ "<strong>"+Dollar_Format+ "</strong>");
					
					
					
					String	Price	=	line.substring(222,239);	
					Reporter.addStepLog(" Price :"+ "<strong>"+Price+ "</strong>");
					
					
					
					String	Security_Identifier_Code 	=	line.substring(293,294);	
					Reporter.addStepLog(" Security Identifier Code :"+ "<strong>"+Security_Identifier_Code+ "</strong>");
					
					
					String	Security_ID_Number	=	line.substring(294,309);
					Reporter.addStepLog(" Security ID_Number :"+ "<strong>"+Security_ID_Number+ "</strong>");
					
					
					
					String	House_Price_Indicator	=	line.substring(339,340);	
					Reporter.addStepLog(" House Price Indicator :"+ "<strong>"+House_Price_Indicator+ "</strong>");
					
					
					String	Multi_Purpose_Spin_Code	=	line.substring(389,390);	
					Reporter.addStepLog(" Multi Purpose Spin Code :"+ "<strong>"+Multi_Purpose_Spin_Code+ "</strong>");
					
					
					String	Base_Segment_Delimiter	=	line.substring(698,700);	
					Reporter.addStepLog(" Base Segment_Delimiter :"+ "<strong>"+Base_Segment_Delimiter+ "</strong>");
					
				
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
