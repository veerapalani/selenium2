package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class USM2991StepDef {

	String api_response;
	boolean isArray = false;
	boolean isObject = false;
	public static String APIresponse;
	public static String msdid;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	public List<String> listofSecurity = new ArrayList<String>();
	String key;
	String attributeNo;
	String prdb_Attribute;
	String prdbAttribute_Value;
	String EISLAttribute;
	String EISLAttributeValue;
	String EISLMapping;
	Map<String, List<String>> hashmap = new HashMap<String, List<String>>();
	List<String> listOfattribute;

	@Given("user has Base URL {string} and Base path {string}")
	public void user_has_Base_URL_and_Base_path(String baseURI, String basePATH) {
		HttpClientUtils.baseUri = baseURI;
		HttpClientUtils.basePath = basePATH;
		Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
		Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");

	}

	@Given("user set Query Parameters {string} as {string} and  {string} as {string}")
	public void user_set_Query_Parameters_as_and_as(String querParm1, String qValue, String querParm2, String qValue2) {

		response = HttpClientUtils.given().buildUri().setQueryParameter(querParm1, qValue)
				.setQueryParameter(querParm2, qValue2).setCetificate("D:\\Users\\GuptaVi\\ALL\\server (1).pfx", "")
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		key = qValue;

	}

	@When("user create a request and make a get method call for attribute {string}")
	public void user_create_a_request_and_make_a_get_method_call_for_attribute(String attrNo) {

		attributeNo = attrNo;

	}

	@Then("user receive {int} and list of security in response for {string}")
	public void user_receive_and_list_of_security_in_response_for(Integer int1, String prdbAttribute) {

		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");

		String api_response = response.getBody().asString();

		//String msdidPath = "$.[0].EntityId";
		msdid = null;
		
		String attributeName,attributeValue = null;
		boolean attributeFound = false;

		try {
			
			List<Map<String, Object>> result = com.jayway.jsonpath.JsonPath.read(api_response, "$.*");
			
			for (Map<String, Object> map : result) {
				
		        for (String name : map.keySet())  
		        { 
		            // search  for value 
		            String attribute = (String) map.get("EntityId"); 
		            @SuppressWarnings("unchecked")
					LinkedHashMap<String, Object> valuesArray = (LinkedHashMap<String, Object>) map.get("Values"); 
		            if(valuesArray.containsKey("pwSecurityIdentifier")) {
		            	attributeFound = true;
		            }
		            else {
		            	Reporter.addStepLog("pwSecurityIdentifier not found \t" + "EntityId = " + attribute + ", Value = " + valuesArray);
		            	 System.out.println("pwSecurityIdentifier not found \t" + "EntityId = " + attribute + ", Value = " + valuesArray); 
		     		    
		            }
		            
		               } 
			}


		
			
			
			
		} catch (Exception e) {
			
		}

		Assert.assertEquals(attributeFound, true, "Attribute not found");

	}

	@Given("user create another request URL by set Path Parameter {string} as {string} in request url")
	public void user_set_Path_Parameter_as_in_request_url(String pathParam, String msdidPar) {
		response = HttpClientUtils.given().setPathParameter("entityId", msdid).buildUri()
				.setCetificate("D:\\Users\\GuptaVi\\ALL\\server (1).pfx", "").setProxy("10.98.21.23", 8080)
				.executeRequest(MethodType.GET);
		api_response = response.getBody().asString();
		Reporter.addStepLog("Endpoint :" + "<strong>" + msdid + "</strong>");

	}



	public static String fixedLengthString(String string, int length) {
		return String.format("%1$" + length + "s", string);
	}

}
