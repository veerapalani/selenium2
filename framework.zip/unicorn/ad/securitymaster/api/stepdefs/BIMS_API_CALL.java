package qa.unicorn.ad.securitymaster.api.stepdefs;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class BIMS_API_CALL {
	public static RetriveResponse response;
	public static RequestBuilder requestBuilder;
	public static String BIMS_API_response;
	public int statuscode;
	public static String MSD_Id;
	// utility methods to setURL

	public static void setURL(String baseURI, String basePATH) throws IOException {
		HttpClientUtils.baseUri = baseURI;
		HttpClientUtils.basePath = basePATH;
		Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
		Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");
	}

	// utility methods to makeGetAPICall
	public static RetriveResponse getResponse(String queryPram, String value) {
		response = HttpClientUtils.given().buildUri().setQueryParameter(queryPram, value)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
		return response;
	}

	// utility methods to make GetEntity APICall
	public static RetriveResponse getEntityResponse(String queryPram, String value) {
		response = HttpClientUtils.given().setPathParameter(queryPram, value).buildUri()
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.23", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
		return response;
	}

	// utility methods to get Respose Code
	public static int getStatusCode(RetriveResponse response) {
		return response.getStatusCode();
	}

	// utility methods to get Respose body
	public static String getResponseBody(RetriveResponse response) {
		return response.getBody().asString();
	}
	
	
	public static Object getGRSattributeValue(String GRSattribute, String GRSpath) {
			String EISLPATH = "$." + GRSpath;
			boolean attributeFound = false;
			String attributeName = null;
			Object attributeValue = null;
			try {
				Object item = com.jayway.jsonpath.JsonPath.read(BIMS_API_response, EISLPATH);
				if (item instanceof net.minidev.json.JSONArray) {
					String EISLPATH2 = EISLPATH + "[*]";
					List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(BIMS_API_response, EISLPATH2);
					for (Map<String, String> map : result) {
						for (Map.Entry<String, String> entry : map.entrySet()) {
							attributeName = entry.getKey();
							if (attributeName.equals(GRSattribute)) {
								attributeFound = true;
								attributeValue = entry.getValue();
								break;
							}
						}
					}

				} else if (item instanceof LinkedHashMap) {
					// It's an object
					LinkedHashMap<String, String> map = com.jayway.jsonpath.JsonPath.read(BIMS_API_response, EISLPATH);
					if (map.containsKey(GRSattribute)) {
						attributeValue = map.get(GRSattribute);
						attributeFound = true;
					}

				} else {
					// It's something else, like a string or number
					EISLPATH = EISLPATH + "." + GRSattribute;
					attributeValue = com.jayway.jsonpath.JsonPath.read(BIMS_API_response, EISLPATH);
					if (attributeValue != null) {
						attributeFound = true;
					}
				}

				assertEquals(attributeFound, true, ""+GRSattribute+ "Not found");
				
				if (attributeFound) {
					Reporter.addStepLog("<b>" + "Attribute Name " + "</b>" + GRSattribute);
					Reporter.addStepLog("<b>" + "Attribute Value : " + "</b>" + attributeValue);
					Reporter.addStepLog("<b>" + "Attribute Found" + "</b>");
				} else {
					Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");

				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			return attributeValue;
		}
	
	

	public static String searchString = "";
	  public static List<IndexWrapper> findIndexesForKeyword(String keyword) {
	        String regex = "\\b"+keyword+"\\b";
	        Pattern pattern = Pattern.compile(regex);
	        Matcher matcher = pattern.matcher(searchString);
	        List<IndexWrapper> wrappers = new ArrayList<IndexWrapper>();
	 
	        while(matcher.find() == true){
	            int end = matcher.end();
	            int start = matcher.start();
	            IndexWrapper wrapper = new IndexWrapper(start, end);
	            wrappers.add(wrapper);
	        }
	        return wrappers;
		
	}
	  
	  public static void main(String[] args) {
	        List<IndexWrapper> indexes = findIndexesForKeyword("be");
	        System.out.println("Indexes found "+indexes.size() +" keyword found at index : "+indexes.get(0).getStart());
	   
	  }
	  
	  public static String getMSD_IdFromFTS(String querParm1, String qValue, String querParm2, String qValue2) {
		  response = HttpClientUtils.given().buildUri().setQueryParameter(querParm1, qValue)
					.setQueryParameter(querParm2, qValue2)
					.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
					.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		  	String firstAPIresponse = response.getBody().asString();
		  	String msdidPath = "$.[0].EntityId";
		  	MSD_Id = null;
			try {
				MSD_Id = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, msdidPath);
			} catch (Exception e) {
				System.out.println(e.getMessage()+"MSD_Id not found");
			}
		  
		  return MSD_Id;
	  }

	


}
