package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class AssetClassSecurity {
	String api_response;
	boolean isArray = false;
	boolean isObject = false;
	public static String APIresponse;
	public static String msdid;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	public List<String> listofSecurity = new ArrayList<String>();
	String key;
	String attributeNo;
	String prdb_Attribute;
	String prdbAttribute_Value;
	String EISLAttribute;
	String EISLAttributeValue;
	String EISLMapping;
	Map<String, List<String>> hashmap = new HashMap<String , List<String>>();
	List<String> listOfattribute;
	
	
@Given("user has Base URL {string} and Base path {string} to create request URL")
public void user_has_Base_URL_and_Base_path_to_create_request_URL(String baseURI, String basePATH) {
	HttpClientUtils.baseUri = baseURI;
	HttpClientUtils.basePath = basePATH;
	Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
	Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");


}

@Given("user set Path Parameter {string} as {string} in request url for {string}")
public void user_set_Path_Parameter_as_in_request_url_for(String string, String msdid, String assestClass) {
}

@When("user make a get request method call for {string} and {string}>")
public void user_make_a_get_request_method_call_for_and(String msdid, String no) {
	//.setCetificate("D:\\Users\\GuptaVi\\ALL\\server (1).pfx", "") for QA
	response = HttpClientUtils.given()
			.setPathParameter("entityId", msdid).buildUri()
			.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
			.setProxy("10.98.21.23", 8080)
			.setAcceptType("application/json")
			.executeRequest(MethodType.GET);
	
	api_response = response.getBody().asString();
	
	Reporter.addStepLog("Endpoint :"+"<strong>" + msdid +"</strong>");

	
}

@Then("user should recieve {int} as response code for {string}")
public void user_should_recieve_as_response_code_for(Integer int1, String string)
{
	int statusCode = response.getStatusCode();
	Reporter.addStepLog("StatusCode :"+"<strong>"+statusCode+"</strong>");
	Assert.assertEquals(statusCode, 200, "Status code returned");
}


}
