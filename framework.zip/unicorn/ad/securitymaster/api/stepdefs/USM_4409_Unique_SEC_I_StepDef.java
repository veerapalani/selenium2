package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class USM_4409_Unique_SEC_I_StepDef {
	
	String APIresponse;
	JsonPath jsonresponse;
	String msdid;
	String vendorID;
	String pwSecId2;
	String pwSecIdnentifier;
	RetriveResponse response;
	String HttpbaseURI;
	String HttpbasePATH;
	Integer MSD_IDcount;
	String vendorId;

	
	@Given("BIMS API Base URL  {string} and Base path {string}")
	public void bims_API_Base_URL_and_Base_path(String baseURI, String basePATH) {
		HttpClientUtils.baseUri = baseURI;
		HttpClientUtils.basePath = basePATH;
		Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
		Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");
	

	}

	@SuppressWarnings("unchecked")
	@When("User make call to find service by making post request with pwSecurityIdentifier as payload {string}")
	public void user_make_call_to_find_service_by_making_post_request_with_pwSecurityIdentifier_as_payload(String pwsecId) {

		pwSecIdnentifier = pwsecId;
		JSONObject json = new JSONObject();
		json.put("pwSecurityIdentifier", pwsecId);  
		String jsonbody = json.toJSONString();
	       response = HttpClientUtils.given().setBody(jsonbody)
			.buildUri()
			.setCetificate("D:\\Users\\GuptaVi\\ALL\\br_localhost_pass_123.pfx", "123")   //for dev
			.setHeader("Content-type", "application/json")
			.setProxy("10.98.21.24", 8080)
			.executeRequest(MethodType.POST);
	       Reporter.addStepLog("pwSecurityIdentifier : "+"<b>"+ pwSecIdnentifier+  "</b>" );
			
			

	}
	
	@When("User make call to find service by making post request with vendor_Id as payload {string}")
	public void user_make_call_to_find_service_by_making_post_request_with_vendor_Id_as_payload(String vendorID) {

		vendorId = vendorID;
		JSONObject json = new JSONObject();
		json.put("VENDOR_ID", vendorID);  
		String jsonbody = json.toJSONString();
	       response = HttpClientUtils.given().setBody(jsonbody)
			.buildUri()
			.setCetificate("D:\\Users\\GuptaVi\\ALL\\br_localhost_pass_123.pfx", "123")   //for dev
			.setHeader("Content-type", "application/json")
			.setProxy("10.98.21.24", 8080)
			.executeRequest(MethodType.POST);
	       Reporter.addStepLog("vendorId : "+"<b>"+ vendorID+  "</b>" );
			

	}

	

@Then("user check that response is ok and response code is {int} for {string}")
public void user_check_that_response_is_ok_and_response_code_is_for(Integer int1, String pwSecIdnent) {
	
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :"+"<strong>"+statusCode+"</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");		
		String firstAPIresponse = response.getBody().asString();
		
		String msdCountPath = "$.[*]";
		
		
		String msdidPath = "$.[0].EntityId";
		String vendorIDPath = "$.[0].Values.VENDOR_ID";
		msdid = null;
		
		try {
			msdid = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, msdidPath);
			vendorID = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, vendorIDPath);
			List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, msdCountPath);
			MSD_IDcount =  result.size();
			
		} catch (Exception e) {
			String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
			try {
				
				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
				Date dateobj = new Date();
	            FileWriter writer = new FileWriter(path, true);
	            BufferedWriter bufferedWriter = new BufferedWriter(writer);
	            bufferedWriter.write(df.format(dateobj)+"\t"  + "  MSDID not found For :   " + pwSecIdnent);
	            bufferedWriter.newLine();
	            bufferedWriter.close();
	        } catch (IOException ee) {
	            ee.printStackTrace();
	        }
		}
		
		Reporter.addStepLog("ADP_ID/MSDID :"+"<strong>" + msdid +"</strong>");
		Reporter.addStepLog("PRO_I/VENDOR_ID :"+"<strong>" + vendorID +"</strong>");
		Reporter.addStepLog("SEC_I/pwSecurityIdentifier :"+"<strong>" + pwSecIdnent +"</strong>");

	}
	
	@Then("user verify that only one security is linked to SEC_I  {string}")
	public void user_verify_that_only_one_security_is_linked_to_SEC_I(String pwsecId) {
		Reporter.addStepLog("No of Security linked to pwSecurityIdentifier : "+"<b>"+ "   \t"+MSD_IDcount+  "</b>" );
		Reporter.addStepLog("No of Security linked to pwSecurityIdentifier : "+"<b>"+ " \t "+MSD_IDcount+  "</b>" );
		if(MSD_IDcount>1) {
			Assert.assertEquals(true, false, "More than One Security is linked to "+pwsecId);
		}
		MSD_IDcount= 0;

	}


}
