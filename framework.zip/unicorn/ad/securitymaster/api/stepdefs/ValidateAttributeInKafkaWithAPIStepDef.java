package qa.unicorn.ad.securitymaster.api.stepdefs;

import static org.testng.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class ValidateAttributeInKafkaWithAPIStepDef {
	
	
	JsonPath jsonresponse;
	String API_attributeValue;
	String Kafka_attributeValue;
	String location;
	RetriveResponse response;

	Process p = null;
	final String kafkaPath = "D:\\Users\\GuptaVi\\kafka_2.13-2.4.0\\bin\\windows";
	
	boolean DataHubAvailableInFile = false;
	
	@Given("Swagger QA URL and kafaka QA environment and list of security")
	public void swagger_QA_URL_and_kafaka_QA_environment_and_list_of_security() {
		Reporter.addStepLog("baseUri : "+"<b>"+ "https://ppapp.pp.gtoqa.bfsaws.net/Peter_Unicorn"+  "</b>" );
		Reporter.addStepLog("basePath : "+"<b>"+ "/Entity/GetSnapshot/{entityId}"+  "</b>" );
	}
	
	@When("user connects to Swagger API with QA URL and {string}  as current endpoint")
	public void user_connects_to_Swagger_API_with_QA_URL_and_as_current_endpoint(String msdid) 
	{


		HttpClientUtils.baseUri = "https://ppapp.pp.gtoqa.bfsaws.net/Peter_Unicorn";
		HttpClientUtils.basePath = "/Entity/GetSnapshot/{entityId}";
		
		response = HttpClientUtils.given()
		.setPathParameter("entityId", msdid)
		.setCetificate("D:\\Users\\GuptaVi\\ALL\\br_localhost_pass_123.pfx", "123")
		.setProxy("10.98.21.24", 8080)
		.executeRequest(MethodType.GET);

		int status = response.getStatusCode();
		String body = response.getBody().asString();
	
		jsonresponse = new JsonPath(body);
		
		Reporter.addStepLog("Endpoint (entityId) :<b>" + msdid+"</b>");
		
		Reporter.addStepLog("<strong>API Response : </strong>" + body);
		
		System.out.println(status);
		System.out.println(body);
		
	
		
	}

	@Then("user should get the response {int} and json response data")
	public void user_should_get_the_response_and_json_response_data(Integer int1) {

		int status = response.getStatusCode();
		System.out.println(status);
		String statusLine = response.getStatusLine();
		Reporter.addStepLog("statusLine :"+ "<strong>"+statusLine + "</strong>");
		Reporter.addStepLog("<b>API Response Status  :</b> "+ status );
	}
	
	@Then("user sholud get the {string} at {string} in BIMS API")
	public void user_sholud_get_the_at_in_BIMS_API(String attribute, String attrlocation) {
		
		
		 String keypath = attrlocation+"."+attribute;
		 API_attributeValue = jsonresponse.get(keypath);
		 
		 Reporter.addStepLog("Attribute :<b>"+attribute+"</b>");
		 Reporter.addStepLog("Value : <b>"+API_attributeValue+"</b>");

	}

	@Then("user run Kafka Notification Hub topic command in cmd and check for {string} with {string} in Kafka Notification Hub.")
	public void user_run_Kafka_Notification_Hub_topic_command_in_cmd_and_check_for_with_in_Kafka_Notification_Hub(String msdid, String status) {
		 
			String command = "kafka-console-consumer.bat --bootstrap-server " + '"'
					+ "qa-bk1.kafka.wmap.broadridge.com:19092,qa-bk2.kafka.wmap.broadridge.com:19092,qa-bk3.kafka.wmap.broadridge.com:19092"
					+ '"'
					+ " --topic BR.INSTRUMENTS.FINANCIALINSTRUMENT.SECURITYMASTER.EVENTS.QA.OUT.WMAP.TOPIC --from-beginning --consumer.config "
					+ '"' + "NHub.properties" + '"';

			Reporter.addStepLog("<strong>"+" Kafka Notification Hub topic command :" + "</strong>" + command);

			String FilePath = "./src/test/resources/ad/securitymaster/api/kafkaLog/topic-NotificationHub.log";


			File file = new File(FilePath);
			if (file.exists()) {
				file.delete();
			}
			try {
				file.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			try {
				
					ProcessBuilder processBuilder = new ProcessBuilder();
					processBuilder.command("cmd.exe", "/c", command);
					processBuilder.directory(new File(kafkaPath));
					processBuilder.redirectOutput(new File(FilePath));
					Process process = processBuilder.start();
					Thread.sleep(25000);
					process.destroy();
					if (process.isAlive()) {
						process.destroyForcibly();
					}
					

				

				ArrayList<String> messageArray = new ArrayList<String>();
				String  line;
				boolean securityAvailable = false;
				
				try (BufferedReader br = new BufferedReader(new FileReader(FilePath))) {
					while ((line = br.readLine()) != null) {
						if (line.contains(msdid)) {
							
							if(line.contains("u0022")) {
								line = line.replaceAll("u0022","");//replaces all occurrences of "is" to "was"  
								line = line.replace("\"", "'");
								
							}
							
							messageArray.add(line);
							securityAvailable = true;
						}
					}
				}

				if (securityAvailable) {
					int len = messageArray.size();
					String lastLine = messageArray.get(len - 1);
					String updateStatement = "UPDATED SECURITY WITH MSD CODE:";
					String addStatement = "ADDED NEW SECURITY WITH MSD CODE";
					System.out.println("messageArray last line --\n" + lastLine);
					
					 switch (status) {
						case "updated":
							if (lastLine.contains(updateStatement)) {
								System.out.println("Security is found updated ..");
								Reporter.addStepLog(" Kafaka Notification Meassage Line :"+ "<strong>"+lastLine+"</strong>");
								
								Reporter.addStepLog(" Status :"+ "<strong>"+updateStatement+" " +msdid+ "</strong>");
								
							}
							else {
								System.out.println("Security not found in Notification HuB ");
								Reporter.addStepLog(" Status :"+ "<strong>Security not found in Notification HuB </strong>");
	}
							break;
						case "added":

							if (lastLine.contains(addStatement)) {
								System.out.println("Security is found Added ..");
								Reporter.addStepLog(" Status :"+ "<strong>"+addStatement +" " +msdid+ "</strong>");

								}
							else {
								System.out.println("Security not found"
										+ " in Notification HuB  ..");
								Reporter.addStepLog(" Status :"+ "<strong>Security not found in Notification HuB </strong>");
							
							}
							
							break;
					 }
							

				} else {
					System.out.println("Security not found"
							+ " in Notification HuB  ..");
					Reporter.addStepLog("<strong> Security not found in Notification Hub</strong>");
				}

				
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	 
	}

	@Then("user run Kafka Data Hub topic command for {string} and get the {string} at {string}")
	public void user_run_Kafka_Data_Hub_topic_command_for_and_get_the_at(String msdid, String attribute, String attrlocation) {
			String command = "kafka-console-consumer.bat --bootstrap-server " + '"'
					+ "qa-bk1.kafka.wmap.broadridge.com:19092,qa-bk2.kafka.wmap.broadridge.com:19092,qa-bk3.kafka.wmap.broadridge.com:19092"
					+ '"'
					+ " --topic BR.INSTRUMENTS.FINANCIALINSTRUMENT.SECURITYMASTER.DATA.QA.OUT.WMAP.TOPIC --from-beginning --consumer.config "
					+ '"' + "NHub.properties" + '"';

			String FilePath = "./src/test/resources/ad/securitymaster/api/kafkaLog/topic-DataHub.log";

			Reporter.addStepLog( "<strong> Kafka Data Hub topic command  :  </strong>"+command);


			File file = new File(FilePath);
			if (file.exists()) {
				file.delete();
			}
			try {
				file.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			try {

				if (!DataHubAvailableInFile) {
					
					System.out.println("Commad is ---" + "\n" + command);
					
					ProcessBuilder processBuilder = new ProcessBuilder();
					processBuilder.command("cmd.exe", "/c", command);
					processBuilder.directory(new File(kafkaPath));
					processBuilder.redirectOutput(new File(FilePath));
					Process process = processBuilder.start();
					Thread.sleep(50000);
					process.destroy();
					if (process.isAlive()) {
						process.destroyForcibly();
					}
					DataHubAvailableInFile =true;

					
				}


				Reporter.addStepLog(" Kafaka DATA Hub Notification ID :"+ "<strong>"+msdid+"</strong>");
				
				boolean isFound = false;
				
				String line,eventValue;
				JSONParser parser = new JSONParser();
				 
				try (BufferedReader br = new BufferedReader(new FileReader(FilePath))) {
					while ((line = br.readLine()) != null) {
						if (line.contains(msdid)) {
							isFound = true;
							Reporter.addStepLog(" Kafaka DATA Hub Meassage Line :"+ "<strong>"+line+"</strong>");
							
						      try {
								JSONObject kafakaMsgJson = (JSONObject) parser.parse(line);
								   eventValue = (String) kafakaMsgJson.get("event");
								   
								   if(eventValue.contains("u0022")) {
									   
								   
								   eventValue = eventValue.replaceAll("u0022","");//replaces all occurrences of "is" to "was"  
								   
								   eventValue = eventValue.replace("\"", "'");
								   
								   System.out.println(eventValue);
								   }
								   
								   String keypath = "$."+attrlocation;
								   
								   LinkedHashMap<String,String >map =
										  com.jayway.jsonpath.JsonPath.read(eventValue, keypath);
								   
								   if (map.containsKey(attribute)) {
									   
									   Kafka_attributeValue = map.get(attribute);
									   System.out.println("Long Line is ....        " + Kafka_attributeValue);
									//  API_attributeValue = jsonresponse.get("CustomFields.Additional.Common.LongName"); 
								  // System.out.println(API_attributeValue);
								   Reporter.addStepLog(" Kafaka DATA Hub Attribute updated :"+ "<strong>"+attrlocation+"</strong>");
								   Reporter.addStepLog(" Kafaka DATA Hub Value :"+ "<strong>"+Kafka_attributeValue+"</strong>");
									
								   
								   } else {
									   Reporter.addStepLog("<b>Notification Id not found in Kafaka DATA Hub </b>");
										
								    }
								 
							} catch (ParseException e) {
								e.printStackTrace();
							}
							
							
						}
					}
				}
				
       if(!isFound) {
    	   Reporter.addStepLog("<b>Notification Id not found in Kafaka DATA Hub </b>");
				 assertEquals(isFound, true);
    	   
       }


			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		
	    
	}

	@Then("user match updated Kafka attribute value wih API upadted attribute value")
	public void user_match_updated_Kafka_attribute_value_wih_API_upadted_attribute_value() {
		System.out.println("Actual data i.e kafak updated field "+ API_attributeValue);
		System.out.println("Expected data , APi updated field " + Kafka_attributeValue);
		Reporter.addStepLog(" Actual data ( in kafka ) :"+ "<strong>"+API_attributeValue + "</strong>");
		Reporter.addStepLog(" Expected data (in  API ) :"+ "<strong>"+Kafka_attributeValue + "</strong>");
	
		assertEquals(API_attributeValue, Kafka_attributeValue);
	}


}
