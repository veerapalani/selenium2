package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.util.regex.Pattern;

public class USM_5258 {
	public static void main(String[] args) {
		String s1 = "AbBaCca";
		String s2 = "bac";
		System.out.println(Pattern.compile(Pattern.quote(s2), Pattern.CASE_INSENSITIVE).matcher(s1).find()
);	}
	
	

}
