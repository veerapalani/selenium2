package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;

public class CAPSHourlyfileUSM3065 {

	String styleId, vendorid, hierarchyCode, pwSecI;
	String styleidentifierfile, stylecodefile, brAssetClassIdfile, brAssetClassCodefile, assetClassIdfile,
			assetClassCodefile, assetSubClassIdfile, assetSubClassCodefile;
	String styleidentifierEISL, stylecodeEISL, brAssetClassIdEISL, brAssetClassCodeEISL, assetClassIdEISL,
			assetClassCodeEISL, assetSubClassIdEISL, assetSubClassCodeEISL, vendoridEISL, hierarchyCodeEISL, pwSecIEISL;
	String styleidentifierPRDB, stylecodePRDB, brAssetClassIdPRDB, brAssetClassCodePRDB, assetClassIdPRDB,
			assetClassCodePRDB, assetSubClassIdPRDB, assetSubClassCodePRDB, vendoridPRDB, hierarchyCodePRDB, pwSecIPRDB;
	String msdid;
	int poststatus, getstatus;
	JsonPath jsonPostresponse, jsonGetresponse;

	@Given("^user extracts style identifier code for PRO_I: '(.+)' from CAPS hourly file$")
    public void user_extracts_style_identifier_code_for_proi_from_caps_hourly_file(String proi)
			throws FileNotFoundException {

		String folderpath = "D:\\Users\\KhandareM\\Broadridge\\Security Master\\MCR 6\\Sprint 37\\USM-3065\\HourlyFiles";
		
		File folder = new File(folderpath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;
			try {
				while ((line = br.readLine()) != null) {
					if (line.startsWith(proi)) {
						String filename = file.getName();

						vendorid = line.substring(0, 10);
						styleId = line.substring(24, 28);
						hierarchyCode = line.substring(16, 20);
						pwSecI = line.substring(10, 16);

						Reporter.addStepLog("<b> CAPS hourly file details: </b>");
						Reporter.addStepLog("<b> File Name: </b> " + filename);
						Reporter.addStepLog("<b> Product Identifier: </b> " + vendorid);
						Reporter.addStepLog("<b> Style Identifier: </b> " + styleId);
						break;
					}
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@When("^user retrives security classification attributes from Trade Hierarchy file using style identifier code$")
    public void user_retrives_security_classification_attributes_from_trade_hierarchy_file_using_style_identifier_code()
			throws FileNotFoundException {

		String filepath = "D:\\Users\\KhandareM\\Broadridge\\Security Master\\MCR 6\\Sprint 37\\USM-3065\\ID\\WMAP.UBS.KARS.TradHierachyRef.20201225.txt";
				
		FileReader fr = new FileReader(filepath);
		BufferedReader br = new BufferedReader(fr);

		String line;
		try {
			while ((line = br.readLine()) != null) {
				if (line.startsWith(styleId)) {

					styleidentifierfile = line.substring(0, 4);
					stylecodefile = line.substring(63, 69).replaceAll("\\s+", "");
					brAssetClassIdfile = line.substring(69, 73);
					brAssetClassCodefile = line.substring(132, 138).replaceAll("\\s+", "");
					assetClassIdfile = line.substring(138, 142);
					assetClassCodefile = line.substring(201, 207).replaceAll("\\s+", "");
					assetSubClassIdfile = line.substring(207, 211);
					assetSubClassCodefile = line.substring(270, 276).replaceAll("\\s+", "");

					Reporter.addStepLog("<b> Security Classification Attributes from CAPS file are : </b> ");
					Reporter.addStepLog("<b> Product Identifier: </b> " + vendorid);
					Reporter.addStepLog("<b> Security Identifier: </b> " + pwSecI);
					Reporter.addStepLog("<b> Style Identifier: </b> " + styleidentifierfile);
					Reporter.addStepLog("<b> Style Code: </b> " + stylecodefile);
					Reporter.addStepLog("<b> Broad Asset Class Identifier: </b> " + brAssetClassIdfile);
					Reporter.addStepLog("<b> Broad Asset Class Code: </b> " + brAssetClassCodefile);
					Reporter.addStepLog("<b> Asset Class Identifier: </b> " + assetClassIdfile);
					Reporter.addStepLog("<b> Asset Class Code: </b> " + assetClassCodefile);
					Reporter.addStepLog("<b> Asset sub-Class Identifier: </b> " + assetSubClassIdfile);
					Reporter.addStepLog("<b> Asset sub-Class Code: </b> " + assetSubClassCodefile);
					Reporter.addStepLog("<b> Hierarchy Code: </b> " + hierarchyCode);
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@And("^user makes POST request using product identifier retrieved from CAPS hourly file$")
    public void user_makes_post_request_using_product_identifier_retrieved_from_caps_hourly_file() {

		String requestjson = "{\"VENDOR_ID\": \"" + vendorid + "\"}";

		String baseUri = Action.getTestData("Entity-BaseURI");
		RestApiUtils.setBaseURI(baseUri);
		String basePath = Action.getTestData("FindEntity-BasePath");
		RestApiUtils.setBasePath(basePath);

		RestApiUtils.requestSpecification = RestAssured.given();
		RestApiUtils.requestSpecification.contentType("application/json");
		RestApiUtils.requestSpecification.body(requestjson);
		Response postresponse = RestApiUtils.requestSpecification.post();

		poststatus = postresponse.getStatusCode();
		String postresponseBody = postresponse.getBody().asString();
		jsonPostresponse = new JsonPath(postresponseBody);

		Reporter.addStepLog("<b>Base URI is set as: </b>" + baseUri);
		Reporter.addStepLog("<b>Base path is set as: </b>" + basePath);
		Reporter.addStepLog("<b>Request JSON: </b> " + requestjson);
		Reporter.addStepLog("<b>HTTP Method Executed: </b>Post");
		
	}
	
	 @Then("^user verifies the reponse code is '200' and extracts MSD_ID from reponse$")
	 public void user_verifies_the_reponse_code_is_200_and_extracts_msdid_from_reponse(){
		
		Assert.assertEquals(poststatus, 200, "Incorrect Response code");
		Reporter.addStepLog("<b>Status Code:</b>" + poststatus);

		msdid = jsonPostresponse.getString("EntityId[0]");
		Reporter.addStepLog("<b>MSD_ID: </b>" + msdid);
		
	}

	 @When("^user makes a GET request using MSD_ID extracted from the POST response$")
	 public void user_makes_a_get_request_using_msdid_extracted_from_the_post_response() {

		String baseUri = Action.getTestData("Entity-BaseURI");
		RestApiUtils.setBaseURI(baseUri);
		String basePath = Action.getTestData("GetSnappshot-BasePath");
		RestApiUtils.setBasePath(basePath);

		RestApiUtils.requestSpecification = RestAssured.given();
		RestApiUtils.requestSpecification.pathParam("externalId", msdid);

		Response getresponse = RestApiUtils.requestSpecification.get();
		getstatus = getresponse.getStatusCode();
		String getresponseBody = getresponse.getBody().asString();
		jsonGetresponse = getresponse.jsonPath();

		Reporter.addStepLog("<b>Base URI is set as: </b>" + baseUri);
		Reporter.addStepLog("<b>Base path is set as: </b>" + basePath);

	}
	
	 @Then("^the reponse code should be '200' for GET request$")
	 public void the_reponse_code_should_be_200_for_get_request() {
		
		Assert.assertEquals(getstatus, 200, "Incorrect Response code");
		Reporter.addStepLog("<b>Status Code: </b>" + getstatus);
		
	}
	
	 @And("^retrives the value of security classification attributes from PRDB table \"([^\"]*)\"$")
	    public void retrives_the_value_of_security_classification_attributes_from_prdb_table_something(String tablename) {
		
		String prdbPath = "CustomFields.UBS_PRDB.KART3900";
		Reporter.addStepLog("<b> PRDB Path of attributes: </b> " + prdbPath);
		
		styleidentifierPRDB = jsonGetresponse.getString(prdbPath + ".ISY_ID[0]");
		stylecodePRDB = jsonGetresponse.getString(prdbPath + ".ISY_NUMC_CD[0]");
		brAssetClassIdPRDB = jsonGetresponse.getString(prdbPath + ".BROD_ACL_ID[0]");
		brAssetClassCodePRDB = jsonGetresponse.getString(prdbPath + ".BROD_ACL_NUMC_CD[0]");
		assetClassIdPRDB = jsonGetresponse.getString(prdbPath + ".ACL_ID[0]");
		assetClassCodePRDB = jsonGetresponse.getString(prdbPath + ".ACL_NUMC_CD[0]");
		assetSubClassIdPRDB = jsonGetresponse.getString(prdbPath + ".AST_SUB_CLAS_ID[0]");
		assetSubClassCodePRDB = jsonGetresponse.getString(prdbPath + ".AST_SUB_CLAS_NUMC_CD[0]");
		vendoridPRDB = jsonGetresponse.getString(prdbPath + ".TRAD_HIER_PRO_I[0]");
		pwSecIPRDB = jsonGetresponse.getString(prdbPath + ".TRAD_HIER_SEC_NB[0]");
		hierarchyCodePRDB = jsonGetresponse.getString(prdbPath + ".TRAD_HIER_CODE[0]");
		
		Reporter.addStepLog("<b>Values of Security Classification Attributes from table " + tablename + " are: </b> ");
		
		Reporter.addStepLog("---------------------------------------------------------------------------------------------------------" );
		Reporter.addStepLog("<b> Product Identifier (TRAD_HIER_PRO_I): </b> " + vendoridPRDB);
		Reporter.addStepLog("<b> Security Identifier (TRAD_HIER_SEC_NB): </b> " + pwSecIPRDB);
		Reporter.addStepLog("<b> Style Identifier (ISY_ID): </b> " + styleidentifierPRDB);
		Reporter.addStepLog("<b> Style Code (ISY_NUMC_CD): </b> " + stylecodePRDB);
		Reporter.addStepLog("<b> Broad Asset Class Identifier (BROD_ACL_ID): </b> " + brAssetClassIdPRDB);
		Reporter.addStepLog("<b> Broad Asset Class Code (BROD_ACL_NUMC_CD): </b> " + brAssetClassCodePRDB);
		Reporter.addStepLog("<b> Asset Class Identifier (ACL_ID): </b> " + assetClassIdPRDB);
		Reporter.addStepLog("<b> Asset Class Code (ACL_NUMC_CD): </b> " + assetClassCodePRDB);
		Reporter.addStepLog("<b> Asset sub-Class Identifier (AST_SUB_CLAS_ID): </b> " + assetSubClassIdPRDB);
		Reporter.addStepLog("<b> Asset sub-Class Code (AST_SUB_CLAS_NUMC_CD): </b> " + assetSubClassCodePRDB);
		Reporter.addStepLog("<b> Hierarchy Code (TRAD_HIER_CODE): </b> " + hierarchyCodePRDB);
	}

	 @And("^verifies the EISL values for corresponding security classification attributes$")
	    public void verifies_the_eisl_values_for_corresponding_security_classification_attributes(){

		String eislPath = "CustomFields.clientDefined.assetClassification";
		Reporter.addStepLog("<b> EISL Path of attributes: </b> " + eislPath);

		styleidentifierEISL = jsonGetresponse.getString(eislPath + ".styleIdentifier[0]");
		stylecodeEISL = jsonGetresponse.getString(eislPath + ".styleCode[0]");
		brAssetClassIdEISL = jsonGetresponse.getString(eislPath + ".broadAssetClassIdentifier[0]");
		brAssetClassCodeEISL = jsonGetresponse.getString(eislPath + ".broadAssetClassCode[0]");
		assetClassIdEISL = jsonGetresponse.getString(eislPath + ".assetClassIdentifier[0]");
		assetClassCodeEISL = jsonGetresponse.getString(eislPath + ".assetClassCode[0]");
		assetSubClassIdEISL = jsonGetresponse.getString(eislPath + ".assetSubClassIdentifier[0]");
		assetSubClassCodeEISL = jsonGetresponse.getString(eislPath + ".assetSubClassCode[0]");
		vendoridEISL = jsonGetresponse.getString(eislPath + ".productIdentifier[0]");
		pwSecIEISL = jsonGetresponse.getString(eislPath + ".pwSecurityIdentifier[0]");
		hierarchyCodeEISL = jsonGetresponse.getString(eislPath + ".hierarchyCode[0]");

		Reporter.addStepLog("<b> Values of Security Classification Attributes as per EISL Ontology are : </b> ");
		
		Reporter.addStepLog("---------------------------------------------------------------------------------------------------------" );
		Reporter.addStepLog("<b> Product Identifier (productIdentifier): </b> " + vendoridEISL);
		Reporter.addStepLog("<b> Security Identifier (pwSecurityIdentifier): </b> " + pwSecIEISL);
		Reporter.addStepLog("<b> Style Identifier (styleIdentifier): </b> " + styleidentifierEISL);
		Reporter.addStepLog("<b> Style Code (styleCode): </b> " + stylecodeEISL);
		Reporter.addStepLog("<b> Broad Asset Class Identifier (broadAssetClassIdentifier): </b> " + brAssetClassIdEISL);
		Reporter.addStepLog("<b> Broad Asset Class Code (broadAssetClassCode): </b> " + brAssetClassCodeEISL);
		Reporter.addStepLog("<b> Asset Class Identifier (assetClassIdentifier): </b> " + assetClassIdEISL);
		Reporter.addStepLog("<b> Asset Class Code (assetClassCode): </b> " + assetClassCodeEISL);
		Reporter.addStepLog("<b> Asset sub-Class Identifier (assetSubClassIdentifier): </b> " + assetSubClassIdEISL);
		Reporter.addStepLog("<b> Asset sub-Class Code (assetSubClassCode): </b> " + assetSubClassCodeEISL);
		Reporter.addStepLog("<b> Hierarchy Code (hierarchyCode): </b> " + hierarchyCodeEISL);
		
		Assert.assertEquals(vendoridPRDB, vendoridEISL, "Product Identifier value is not matching between File & API ");
		Assert.assertEquals(pwSecIPRDB, pwSecIEISL, "Security Identifier value is not matching between File & API ");
		Assert.assertEquals(styleidentifierPRDB, styleidentifierEISL, "Style Identifier value is not matching between File & API ");
		Assert.assertEquals(stylecodePRDB, stylecodeEISL, "Style Code value is not matching between File & API ");
		Assert.assertEquals(brAssetClassIdPRDB, brAssetClassIdEISL, "Broad Asset Class Identifier value is not matching between File & API ");
		Assert.assertEquals(brAssetClassCodePRDB, brAssetClassCodeEISL,
				"Broad Asset Class Code value is not matching between File & API ");
		Assert.assertEquals(assetClassIdPRDB, assetClassIdEISL,
				"Asset Class Identifier value is not matching between File & API ");
		Assert.assertEquals(assetClassCodePRDB, assetClassCodeEISL,
				"Asset Class Code value is not matching between File & API ");
		Assert.assertEquals(assetSubClassIdPRDB, assetSubClassIdEISL,
				"Asset sub-Class Identifier value is not matching between File & API ");
		Assert.assertEquals(assetSubClassCodePRDB, assetSubClassCodeEISL,
				"Asset sub-Class Code value is not matching between File & API ");
		Assert.assertEquals(hierarchyCodePRDB, hierarchyCodeEISL,
				"Hierarchy Code value is not matching between File & API ");
		Reporter.addStepLog(
				"<b style='color:green'> PRDB and EISL Values are matching!!</b>");

	}

	 @And("^performs data comparison between API reponse and Trade Hierarchy file$")
	    public void performs_data_comparison_between_api_reponse_and_trade_hierarchy_file()  {

		Assert.assertEquals(vendoridPRDB, vendorid, "Product Identifier value is not matching between File & API ");
		Assert.assertEquals(pwSecIPRDB, pwSecI, "Security Identifier value is not matching between File & API ");
		Assert.assertEquals(styleidentifierPRDB, styleidentifierfile,
				"Style Identifier value is not matching between File & API ");
		Assert.assertEquals(stylecodePRDB, stylecodefile, "Style Code value is not matching between File & API ");
		Assert.assertEquals(brAssetClassIdPRDB, brAssetClassIdfile,
				"Broad Asset Class Identifier value is not matching between File & API ");
		Assert.assertEquals(brAssetClassCodePRDB, brAssetClassCodefile,
				"Broad Asset Class Code value is not matching between File & API ");
		Assert.assertEquals(assetClassIdPRDB, assetClassIdfile,
				"Asset Class Identifier value is not matching between File & API ");
		Assert.assertEquals(assetClassCodePRDB, assetClassCodefile,
				"Asset Class Code value is not matching between File & API ");
		Assert.assertEquals(assetSubClassIdPRDB, assetSubClassIdfile,
				"Asset sub-Class Identifier value is not matching between File & API ");
		Assert.assertEquals(assetSubClassCodePRDB, assetSubClassCodefile,
				"Asset sub-Class Code value is not matching between File & API ");
		Assert.assertEquals(hierarchyCodePRDB, hierarchyCode,
				"Hierarchy Code value is not matching between File & API ");
		Reporter.addStepLog("PRDB values are matching with data from file! ");
		Reporter.addStepLog("<b style='color:green'> Data from CAPS file has been successfully loaded to BIMS DataBase!!</b>");

	}

}
