package qa.unicorn.ad.securitymaster.api.stepdefs;

import org.testng.Assert;

import io.cucumber.java.en.And;
import io.restassured.path.json.JsonPath;
import qa.framework.utils.Reporter;

public class USM4420 {
	String prdbFirstDate, prdbCurrCode,prdbRate,prdbIssueDate,prdbMatDate,prdbStateCode,prdbIssuePrice,prdbDRSCode;
	String prdbCODCode,prdbDepositCode,prdbPledgeCode,prdbSEGRCode,prdbWRCode,prdbFrozenCode,prdbFFCode,prdbFCTRQ;
	String bimsFirstDate, bimsCurrCode,bimsRate,bimsIssueDate,bimsMatDate,bimsStateCode,bimsIssuePrice,bimsDRSCode;
	String bimsCODCode,bimsDepositCode,bimsPledgeCode,bimsSEGRCode,bimsWRCode,bimsFrozenCode,bimsFFCode,bimsFCTRQ;
	
	JsonPath jsonresponse = ValidatePRDBandEISLAttributeStepdef.jsonresponse;
	
	@And("^user verifies the values of UBS fields$")
    public void user_verifies_the_values_of_ubs_fields() {		
		
		prdbFirstDate = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT0100.PFR_FRST_D");
		prdbCurrCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT0100.PRO_PVAL_CUR_C");
		prdbRate = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT0100.PFR_P");
		prdbIssueDate = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT0100.PRO_ISS_D");
		prdbMatDate = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT0100.PRO_MAT_D");
		prdbStateCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT0100.PRO_ISS_ST_C");
		prdbIssuePrice = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT0400.PRO_OID_PX_A");
		prdbDRSCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT1600[0].PRO_DTC_DRS_C");
		prdbCODCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT1600[0].PRO_DTC_CHL_COD_C");
		prdbDepositCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT1600[0].PRO_CHL_DEP_C");
		prdbPledgeCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT1600[0].PRO_CHL_PLG_C");
		prdbSEGRCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT1600[0].PRO_CHL_SEGR_C");
		prdbWRCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT1600[0].PRO_CHL_WR_XFR_C");
		prdbFrozenCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT1600[0].PRO_FRZN_C");
		prdbFFCode = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT1600[0].PRO_CHL_FF_C");
		prdbFCTRQ = jsonresponse.getString("CustomFields.UBS_PRDB.PDBT3600.PFA_PRINC_FCTR_Q");
		
		Reporter.addStepLog("<b> UBS PRDB Fields value are: </b>");
		Reporter.addStepLog("----------------------------------------------" );
		
		Reporter.addStepLog("<b> PRODUCT FEATURE RATE FIRST DATE-</b> PFR_FRST_D: " + prdbFirstDate);
		Reporter.addStepLog("<b> PRODUCT PAR VALUE CURRENCY CODE-</b> PRO_PVAL_CUR_C: " + prdbCurrCode);
		Reporter.addStepLog("<b> PRODUCT FEATURE RATE PERCENT-</b> PFR_P: " + prdbRate);
		Reporter.addStepLog("<b> PRODUCT ISSUE DATE-</b> PRO_ISS_D: " + prdbIssueDate);
		Reporter.addStepLog("<b> PRODUCT MATURITY DATE-</b> PRO_MAT_D: " + prdbMatDate);
		Reporter.addStepLog("<b> PRODUCT ISSUE STATE CODE-</b> PRO_ISS_ST_C: " + prdbStateCode);
		Reporter.addStepLog("<b> PRODUCT ORIGINAL ISSUE DISCOUNT PRICE AMOUNT-</b> PRO_OID_PX_A: " + prdbIssuePrice);
		Reporter.addStepLog("<b> PRODUCT DEPOSITORY REGISTRATION SYSTEM CODE-</b> PRO_DTC_DRS_C: " + prdbDRSCode);
		Reporter.addStepLog("<b> PRODUCT DEPOSITORY CASH ON DELIVERY CODE-</b> PRO_DTC_CHL_COD_C: " + prdbCODCode);
		Reporter.addStepLog("<b> PRODUCT CHILL DEPOSIT CODE-</b> PRO_CHL_DEP_C: " + prdbDepositCode);
		Reporter.addStepLog("<b> PRODUCT CHILL PLEDGE CODE-</b> PRO_CHL_PLG_C: " + prdbPledgeCode);
		Reporter.addStepLog("<b> PRODUCT CHILL SEGREGATION CODE-</b> PRO_CHL_SEGR_C: " + prdbSEGRCode);
		Reporter.addStepLog("<b> PRODUCT CHILL WITHDRAWAL TRANSFER CODE-</b> PRO_CHL_WR_XFR_C: " + prdbWRCode);
		Reporter.addStepLog("<b> PRODUCT FROZEN CODE-</b> PRO_FRZN_C: " + prdbFrozenCode);
		Reporter.addStepLog("<b> PRODUCT CHILL FEDERAL FUNDS CODE-</b> PRO_CHL_FF_C: " + prdbFFCode);
		Reporter.addStepLog("<b> PRODUCT FEATURE PRINCIPAL FACTOR QUANTITY-</b> PFA_PRINC_FCTR_Q: " + prdbFCTRQ);
	}
	
	
	@And("^verifies the GRS mapping and values of EISL attributes$")
    public void verifies_the_grs_mapping_and_values_of_eisl_attributes() {
		
		bimsFirstDate = jsonresponse.getString("bondInfo.IssueDatedDate");
		bimsCurrCode = jsonresponse.getString("Currency.CurrencyIsoCode");
		bimsRate = jsonresponse.getString("bondInfo.Coupon.Rate");
		bimsIssueDate = jsonresponse.getString("bondInfo.IssueIssDate");
		bimsMatDate = jsonresponse.getString("bondInfo.IssueMaturityDate");
		bimsStateCode = jsonresponse.getString("AuxCountry.State.code");
		bimsIssuePrice = jsonresponse.getString("bondInfo.IssuePrice");
		bimsDRSCode = jsonresponse.getString("CustomFields.Settle.Parameters.IsBookEntryDRSEligible");
		bimsCODCode = jsonresponse.getString("CustomFields.Settle.Parameters.IsCODEligible");
		bimsDepositCode = jsonresponse.getString("CustomFields.Settle.Parameters.IsDepositEligible");
		bimsPledgeCode = jsonresponse.getString("CustomFields.Settle.Parameters.IsPledgeEligible");
		bimsSEGRCode = jsonresponse.getString("CustomFields.Settle.Parameters.IsSegregationEligible");
		bimsWRCode = jsonresponse.getString("CustomFields.Settle.Parameters.IsWTEligible");
		bimsFrozenCode = jsonresponse.getString("CustomFields.Settle.Parameters.IsFrozenForDepository");
		bimsFFCode = jsonresponse.getString("CustomFields.Settle.Parameters.IsSameDateFundEligible");
		bimsFCTRQ = jsonresponse.getString("bondInfo.FactorSchedules");
		
		
		Reporter.addStepLog("<b> BIMS Fields value are: </b>");
		Reporter.addStepLog("----------------------------------------------" );
		
		Reporter.addStepLog("<b> PRODUCT FEATURE RATE FIRST DATE-</b> IssueDatedDate: " + bimsIssueDate);
		Reporter.addStepLog("<b> PRODUCT PAR VALUE CURRENCY CODE-</b> CurrencyIsoCode: " + bimsCurrCode);
		Reporter.addStepLog("<b> PRODUCT FEATURE RATE PERCENT-</b> Coupon.Rate: " + bimsRate);
		Reporter.addStepLog("<b> PRODUCT ISSUE DATE-</b> IssueIssDate: " + bimsIssueDate);
		Reporter.addStepLog("<b> PRODUCT MATURITY DATE-</b> IssueMaturityDate: " + bimsMatDate);
		Reporter.addStepLog("<b> PRODUCT ISSUE STATE CODE-</b> State.code: " + bimsStateCode);
		Reporter.addStepLog("<b> PRODUCT ORIGINAL ISSUE DISCOUNT PRICE AMOUNT-</b> IssuePrice: " + bimsIssuePrice);
		Reporter.addStepLog("<b> PRODUCT DEPOSITORY REGISTRATION SYSTEM CODE-</b> IsBookEntryDRSEligible: " + bimsDRSCode);
		Reporter.addStepLog("<b> PRODUCT DEPOSITORY CASH ON DELIVERY CODE-</b> IsCODEligible: " + bimsCODCode);
		Reporter.addStepLog("<b> PRODUCT CHILL DEPOSIT CODE-</b> IsDepositEligible: " + bimsDepositCode);
		Reporter.addStepLog("<b> PRODUCT CHILL PLEDGE CODE-</b> IsPledgeEligible: " + bimsPledgeCode);
		Reporter.addStepLog("<b> PRODUCT CHILL SEGREGATION CODE-</b> IsSegregationEligible: " + bimsSEGRCode);
		Reporter.addStepLog("<b> PRODUCT CHILL WITHDRAWAL TRANSFER CODE-</b> IsWTEligible: " + bimsWRCode);
		Reporter.addStepLog("<b> PRODUCT FROZEN CODE-</b> IsFrozenForDepository: " + bimsFrozenCode);
		Reporter.addStepLog("<b> PRODUCT CHILL FEDERAL FUNDS CODE-</b> IsSameDateFundEligible: " + bimsFFCode);
		Reporter.addStepLog("<b> PRODUCT FEATURE PRINCIPAL FACTOR QUANTITY-</b> FactorSchedules: " + bimsFCTRQ);				
		
	}
	
	@And("^performs a comparison between PRDB and EISL attributes values$")
    public void performs_a_comparison_between_prdb_and_eisl_attributes_values() {
		
		Assert.assertEquals(bimsFirstDate, prdbFirstDate,"BIMS Product Feature First Date value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Feature First Date value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsCurrCode, prdbCurrCode,"BIMS Currency Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Currency Code value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsRate, prdbRate,"BIMS Product Feature Rate value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Feature Rate value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsIssueDate, prdbIssueDate,"BIMS Issue Date value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Issue Date value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsMatDate, prdbMatDate,"BIMS Maturity Date value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Maturity Date value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsStateCode, prdbStateCode,"BIMS State Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS State Code value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsIssuePrice, prdbIssuePrice,"BIMS Issue Price value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Issue Price value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsDRSCode, prdbDRSCode,"BIMS Product Direct Registration System Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Direct Registration System Code value is matching with UBS PRDB value");
		
		Assert.assertEquals(bimsCODCode, prdbCODCode,"BIMS Product Cash on Delivery Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Cash on Delivery Code value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsDepositCode, prdbDepositCode,"BIMS Product Deposit Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Deposit Code value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsPledgeCode, prdbPledgeCode,"BIMS Product Pledge Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Pledge Code value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsSEGRCode, prdbSEGRCode,"BIMS Product Segregation Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Segregation Code value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsWRCode, prdbWRCode,"BIMS Product Withdrawal Transfer Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Withdrawal Transfer Code value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsFrozenCode, prdbFrozenCode,"BIMS Product Frozen Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Frozen Code value is matching with UBS PRDB value ");
		
		Assert.assertEquals(bimsFFCode, prdbFFCode,"BIMS Product Federal Funds Code value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Federal Funds Code value is matching with UBS PRDB value");
		
		Assert.assertEquals(bimsFCTRQ, prdbFCTRQ,"BIMS Product Factor Schedules value is not matching with UBS PRDB value");
//		Reporter.addStepLog("BIMS Product Factor Schedules value is matching with UBS PRDB value");
		
		Reporter.addStepLog("<b>BIMS values are matching with UBS PRDB fields! </b>");
		Reporter.addStepLog("<b style='color:green'> The mapping of 16 Overlay attributes is changed from MSD to PRDB !!</b>");
		
	}

}
