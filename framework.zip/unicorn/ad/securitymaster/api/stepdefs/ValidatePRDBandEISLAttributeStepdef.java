package qa.unicorn.ad.securitymaster.api.stepdefs;

/****  @author Vikram & Mansi    ****/


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.CommonAPISteps;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;

public class ValidatePRDBandEISLAttributeStepdef {

	RetriveResponse response;
	static String responseBody;
	String statusLine;
	static JsonPath jsonresponse;
	String EISLPATH;
	Object prdbAttributeValue;
	Object eislAttributeValue;
	String prdbattribute;
	static String prdbPath;
	Boolean isArray = false;
	int status;
	String env = SQLDriver.getEnvironment();

	@Given("^User connects to Base Swagger URL$")
	public void user_connects_to_base_swagger_url() {

		String baseUri = Action.getTestData("Entity-BaseURI");
		RestApiUtils.setBaseURI(baseUri);
		String basePath = Action.getTestData("GetSnappshot-BasePath");
		RestApiUtils.setBasePath(basePath);
		RestApiUtils.requestSpecification = RestAssured.given();

		Reporter.addStepLog("<b>Base URI is set as: </b>" + baseUri);
		Reporter.addStepLog("<b>Base path is set as: </b>" + basePath);
	}

	@When("^User sets Path Parameter \"([^\"]*)\" as (.+) to make a GET request$")
	public void user_sets_path_parameter_something_as_to_make_a_get_request(String strArg1, String msdid) {

		RestApiUtils.requestSpecification.pathParam(strArg1, msdid);
		Response response = RestApiUtils.requestSpecification.get();
		status = response.getStatusCode();
		responseBody = response.getBody().asString();
		jsonresponse = new JsonPath(responseBody);

		Reporter.addStepLog("<b>Parameter Type: </b>Path");
		Reporter.addStepLog("<b>Parameter Name: </b>" + strArg1);
		Reporter.addStepLog("<b>Parameter Value: </b>" + msdid);
		Reporter.addStepLog("<b>HTTP Method Executed: </b>Get");
	}

	@Then("^User should verify the response code$")
	public void user_should_verify_the_response_code() {

		Assert.assertEquals(status, 200, "Incorrect Response code");
		Reporter.addStepLog("<b>Status Code: </b>" + status);
//		 Reporter.addStepLog("<b>Response: </b>"+responseBody);	

/*****************For printing Response as html link***********************************************/

//		 CommonAPISteps link = new CommonAPISteps();
//			if (responseBody.length() > 0) {
//			String fileName = link.responseFile(responseBody);			
//			String html="<lable><font color=#1E90FF>Click on link to see Response</font></lable>"+
//			"<a href=\""+fileName+"\" target=\"_blank\" style=\"float:right\"><img src=\"core-image-hyper-link.png\" style=\"background-color:aliceblue\"></a>";
//			
//			Reporter.addStepLog(html);			
//			}
	}

	@And("^verify whether the MSD updated value for CUSIP:'(.+)' is available in API response$")
	public void verify_whether_the_msd_updated_value_for_cusip_is_available_in_api_response(String expectedcusip) {

		String actualCUSIP = jsonresponse.getString("Id.CUSIP");
		Reporter.addStepLog("<b>Expected value of CUSIP: </b>" + expectedcusip);
		Reporter.addStepLog("<b>Actual value of CUSIP: </b>" + actualCUSIP);
		Assert.assertEquals(actualCUSIP, expectedcusip, "MSD updates are not reflected for CUSIP");
		Reporter.addStepLog("<b>MSD updates are reflected for CUSIP in BIMS API !!</b>");
	}

	@And("^verify whether the MSD updated value for ISIN:'(.+)' is available in API response$")
	public void verify_whether_the_msd_updated_value_for_isin_is_available_in_api_response(String expectedisin) {

		String actualISIN = jsonresponse.getString("Id.ISIN");
		Reporter.addStepLog("<b>Expected value of ISIN: </b>" + expectedisin);
		Reporter.addStepLog("<b>Actual value of ISIN: </b>" + actualISIN);
		Assert.assertEquals(actualISIN, expectedisin, "MSD updates are not reflected for ISIN");
		Reporter.addStepLog("<b>MSD updates are reflected for ISIN in BIMS API !!</b>");
	}

	@And("^User should check whether PRDB Attribute (.+) is available in (.+) table in response$")
	public void user_should_check_whether_prdb_attribute_is_available_in_table_in_response(String prdbattribute, String prdbtable) {

//************** setting path for PRDB Values
		prdbPath = "CustomFields.UBS_PRDB." + prdbtable;

//********************* setting path for EISL values
		switch (prdbtable) {
		case "PDBT0100":
			EISLPATH = "CustomFields.clientDefined.productInfo";
			isArray = false;
			break;
		case "PDBT6900":
			EISLPATH = "CustomFields.clientDefined.productInfo";
			isArray = true;
			break;
		case "PDBT0130":
			EISLPATH = "CustomFields.clientDefined.exchangeTradedFund";
			isArray = true;
			break;
		case "PDBT0140":
			EISLPATH = "CustomFields.clientDefined.regulation871m";
			isArray = true;
			break;
		case "PDBT0200":
			EISLPATH = "CustomFields.clientDefined.description";
			isArray = true;
			break;
		case "PDBT0300":
			EISLPATH = "CustomFields.clientDefined.productStatus";
			isArray = true;
			break;
		case "PDBT0400":
			EISLPATH = "CustomFields.clientDefined.newIssue";
			isArray = true;
			break;
		case "PDBT0700":
			EISLPATH = "CustomFields.clientDefined.productUnderlying";
			isArray = true;
			break;
		case "PDBT0810":
			EISLPATH = "CustomFields.clientDefined.taxStatus";
			isArray = true;
			break;
		case "PDBT0900":
			EISLPATH = "CustomFields.clientDefined.fxStructuredProduct";
			isArray = true;
			break;
		case "PDBT0910":
			EISLPATH = "CustomFields.clientDefined.fxStructuredProductOptions";
			isArray = true;
			break;
		case "PDBT1000":
			EISLPATH = "CustomFields.clientDefined.index";
			isArray = true;
			break;
		case "PDBT1300":
			EISLPATH = "CustomFields.clientDefined.agentService";
			isArray = true;
			break;
		case "PDBT1500":
			EISLPATH = "CustomFields.clientDefined.depository";
			isArray = true;
			break;
		case "PDBT1700":
			EISLPATH = "CustomFields.clientDefined.marketplace";
			isArray = true;
			break;
		case "PDBT1800":
			EISLPATH = "CustomFields.clientDefined.clearanceMechanism";
			isArray = true;
			break;
		case "PDBT2000":
			EISLPATH = "CustomFields.clientDefined.alternateIdentifier";
			isArray = true;
			break;
		case "PDBT2200":
			EISLPATH = "CustomFields.clientDefined.guarantee";
			isArray = true;
			break;
		case "PDBT2300":
			EISLPATH = "CustomFields.clientDefined.productRestriction";
			isArray = true;
			break;
		case "PDBT2400":
			EISLPATH = "CustomFields.clientDefined.productApproval";
			isArray = true;
			break;
		case "PDBT2500":
			EISLPATH = "CustomFields.clientDefined.creditRating";
			isArray = true;
			break;
		case "PDBT2600":
			EISLPATH = "CustomFields.clientDefined.productCreditRating";
			isArray = true;
			break;
		case "PDBT2800":
			EISLPATH = "CustomFields.clientDefined.industry";
			isArray = true;
			break;
		case "PDBT3400":
			EISLPATH = "CustomFields.clientDefined.collateralizedDebt";
			isArray = false;
			break;
		case "PDBT4200":
			EISLPATH = "CustomFields.clientDefined.schedulePeriod";
			isArray = false;
			break;
		case "PDBT4400":
			EISLPATH = "CustomFields.clientDefined.audit";
			isArray = true;
			break;
		case "PDBT4600":
			EISLPATH = "CustomFields.clientDefined.backbridge";
			isArray = true;
			break;
		case "PDBT5000":
			EISLPATH = "CustomFields.clientDefined.involvedParty";
			isArray = true;
			break;
		case "PDBT5100":
			EISLPATH = "CustomFields.clientDefined.involvedPartyAlternateIdentifer";
			isArray = true;
			break;
		case "PDBT6000":
			EISLPATH = "CustomFields.clientDefined.conversion";
			isArray = true;
			break;
		case "PDBT6100":
			EISLPATH = "CustomFields.clientDefined.conversionDelivery";
			isArray = true;
			break;
		case "PDBT7200":
			EISLPATH = "CustomFields.clientDefined.backbridge";
			isArray = true;
			break;
		case "PDBT7300":
			EISLPATH = "CustomFields.clientDefined.backbridge";
			isArray = true;
			break;
		case "PDBT9400":
			EISLPATH = "CustomFields.clientDefined.structuredProduct";
			isArray = true;
			break;
		case "PDBT9430":
			EISLPATH = "CustomFields.clientDefined.underlyingProduct";
			isArray = true;
			break;
		}

		// if PRDB Attribute is inside an array
		if (isArray) {
			List<HashMap<String, Object>> getMapList = jsonresponse.getList(prdbPath);
			getMapList.stream().forEach(mapsData -> {
				mapsData.entrySet().forEach(mapData -> {
					if (mapData.getKey().contentEquals(prdbattribute)) {
						prdbAttributeValue = mapData.getValue();
					}
				});
			});

			HashMap<String, Object> prdbTableAttributeMap = getMapList.get(0);
			prdbAttributeValue = prdbTableAttributeMap.get(prdbattribute);
			Reporter.addStepLog("<strong> PRDB Attribute: </strong>" + prdbattribute
					+ "<strong> is available in PRDB Table:</strong>" + prdbtable + "<strong> with value as: </strong>"
					+ prdbAttributeValue);
		}

		// if PRDB Attribute is inside an object
		else {
			HashMap<String, Object> prdbTableAttributeMap = jsonresponse.get(prdbPath);
			prdbAttributeValue = prdbTableAttributeMap.get(prdbattribute);
			Reporter.addStepLog("<strong> PRDB Attribute: </strong>" + prdbattribute
					+ "<strong> is available in PRDB Table:</strong>" + prdbtable + "<strong> with value as: </strong>"
					+ prdbAttributeValue);
		}
	}

	@And("^User should verify that PRDB attribute is renamed as EISL Ontology: (.+)$")
	public void user_should_verify_that_prdb_attribute_is_renamed_as_eisl_ontology(String eislontology) {

		// if EISL Attribute is inside an array
		if (isArray) {

			List<HashMap<String, Object>> getMapList = jsonresponse.getList(EISLPATH);
			List<Map<String, Object>> eislMapList = getMapList.stream()
						.filter(hashmap -> hashmap.containsKey(eislontology)).collect(Collectors.toList());

				for (int i = 0; i < eislMapList.size(); i++) {
					Map<String, Object> eislMap = eislMapList.get(i);
					if (eislMap.get(eislontology).equals(prdbAttributeValue)) {
						eislAttributeValue = eislMap.get(eislontology);
					}
				}
			
			Reporter.addStepLog("<strong> Expeced EISL Attribute Value: </strong>" + eislAttributeValue);
			Reporter.addStepLog("<strong> Actual PRDB Attribute Value:  </strong>" + prdbAttributeValue);

			Assert.assertEquals(prdbAttributeValue, eislAttributeValue,
					"UBS Specific PRDB Attribute is not renamed as per EISL Ontology");
			Reporter.addStepLog("<strong> UBS Specific PRDB Attribute is renamed as per EISL Ontology</strong>");
		}

		// if EISL Attribute is inside an object
		else {
			HashMap<String, Object> eislMap = jsonresponse.get(EISLPATH);
			eislAttributeValue = eislMap.get(eislontology);

			Reporter.addStepLog("<strong>Expeced EISL Attribute Value: </strong>" + eislAttributeValue);
			Reporter.addStepLog("<strong>Actual PRDB Attribute Value:  </strong>" + prdbAttributeValue);

			Assert.assertEquals(prdbAttributeValue, eislAttributeValue,
					"UBS Specific PRDB Attribute is not renamed as per EISL Ontology");
			Reporter.addStepLog("<strong> UBS Specific PRDB Attribute is renamed as per EISL Ontology</strong>");
		}
	}

	@And("^GRS Path for PRDB Attribue (.+) should be (.+)$")
	public void grs_path_for_prdb_attribue_should_be(String prdbattribute, String grspath) {

		String newPrdbPath = prdbPath + "." + prdbattribute;

		Reporter.addStepLog("<b>Actual GRS Path: </b>" + newPrdbPath);
		Reporter.addStepLog("<b>Expected GRS Path: </b>" + grspath);

		Assert.assertEquals(newPrdbPath, grspath, "Attribute is not available at mentioned location");
		Reporter.addStepLog("<b>PRDB Attribute is available at the expected GRS Path </b>");
	}

}
