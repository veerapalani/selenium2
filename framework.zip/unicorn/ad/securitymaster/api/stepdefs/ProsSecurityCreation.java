package qa.unicorn.ad.securitymaster.api.stepdefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import qa.framework.utils.CommonAPISteps;
import qa.framework.utils.JsonEasyWay;
import qa.framework.utils.Reporter;
import qa.framework.utils.StringUtility;

public class ProsSecurityCreation {

	
	public static String isin;
	public static String externalId;

	@And("user add unique {int} digit CUSIP CINS value")
	public void user_add_unique_something_digit_cusip_cins_value(int numberOfDigits) throws Throwable {
		String cusip = String.valueOf(StringUtility.randomnumbers(0, 9, numberOfDigits));
		CommonAPISteps.requestJson = CommonAPISteps.requestJson.replace("@CUSIP_CINS", cusip);
		
	}

	@And("user add unique {int} digit 'ISIN' value")
	public void user_add_unique_something_digit_isin_value(int numberOfDigits) throws Throwable {
		isin = String.valueOf(StringUtility.randomnumbers(0, 9, numberOfDigits));
		CommonAPISteps.requestJson = CommonAPISteps.requestJson.replace("@ISIN", isin);

	}

	@And("if 'Message Type' is 'I' user remove remove 'MSD ID' else add {int} digit unique value")
	public void if_message_type_is_i_user_remove_remove_msd_id_else_add_something_digit_unique_value(int numberOfDigits)
			throws Throwable {
		
		JsonEasyWay jsonEasyWay = new JsonEasyWay();
		String messageType = jsonEasyWay.getAttributeValue(CommonAPISteps.requestJson, "MessageType", -1);
		
		if(messageType.equalsIgnoreCase("i")) {
			CommonAPISteps.requestJson = CommonAPISteps.requestJson.replace("\"MSD_ID\":\"@MSD_ID\",", "");
		}
		
	}
	
	@When("^user extract 'External Id' from respone json$")
    public void user_extract_external_id_from_respone_json() throws Throwable {
        externalId = CommonAPISteps.response.getBody().asString();
        Reporter.addStepLog("<strong>External Id:</strong> "+externalId);
    }

}
