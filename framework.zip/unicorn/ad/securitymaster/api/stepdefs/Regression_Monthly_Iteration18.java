package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class Regression_Monthly_Iteration18 {
	boolean isObject = false;
	public static String APIresponse;
	public static String msdid;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	public static String key;
	public static String attributeNo;
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Date dateobj = new Date();
	public static boolean flagGRS = false;


@Given("user has acess to BIMS FTS service Base URL {string} and Base path {string}")
public void user_has_acess_to_BIMS_FTS_service_Base_URL_and_Base_path(String baseURI,
		String basePATH) {
	HttpClientUtils.baseUri = baseURI;
	HttpClientUtils.basePath = basePATH;
	Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
	Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");
}

@Given("user set Query Parameter {string} as {string} and  {string} as {string} for request URL")
public void user_set_Query_Parameter_as_and_as_for_request_URL(String querParm1, String qValue, String querParm2, String qValue2) {
	response = HttpClientUtils.given().buildUri().setQueryParameter(querParm1, qValue)
			.setQueryParameter(querParm2, qValue2)
			.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
			.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
	key = qValue;
}

@When("user make a get method call for attribute {string} for FTS search")
public void user_make_a_get_method_call_for_attribute_for_FTS_search(String attrNo) {
	attributeNo = attrNo;
}

@Then("user receive Sucess and repose code {int} from FTS service")
public void user_receive_Sucess_and_repose_code_from_FTS_service(Integer int1) {

	int statusCode = response.getStatusCode();
	Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
	Assert.assertEquals(statusCode, 200, "Status code returned");

	APIresponse = response.getBody().asString();
	Reporter.addStepLog("Response Body :" + "<strong>" + APIresponse +
 "</strong>");
	
	validateNoResponse();


}
private static void validateNoResponse() {
	if (APIresponse.length() > 4) {

		String msdidPath = "$.[0].EntityId";
		msdid = null;
		flagGRS = true;

		try {
			msdid = com.jayway.jsonpath.JsonPath.read(APIresponse, msdidPath);

		} catch (Exception ee) {
		}

		String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
		try {

			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Date dateobj = new Date();
			FileWriter writer = new FileWriter(path, true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attributeNo, 3)
					+ fixedLengthString(key, 102) + "  Attribute is found and Not deleted from GRS   :  \t "
					+ "\t MSD_ID : \t" + fixedLengthString(msdid, 10));
			bufferedWriter.newLine();
			bufferedWriter.close();
		} catch (IOException ee) {
			ee.printStackTrace();
		}

		Assert.assertEquals(false, true, "No Record/Response should be found as attributes is deleted but Records/Response found : Test Failed ");
}
	

}

public static String fixedLengthString(String string, int length) {
	return String.format("%1$" + length + "s", string);
}

}
