package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import io.cucumber.java.en.And;
import qa.framework.utils.CommonAPISteps;
import qa.framework.utils.Reporter;


public class FullLoadDeltaFileValidation {
	
	String fileResponse;
	String apiResponse;

	@And("^user validates the payload in \"([^\"]*)\" named \"([^\"]*)\" for security (.+)$")
    public void user_validates_the_payload_in_file_named_filename_for_security(String filetype, String filename, String msdid) throws FileNotFoundException {

		String filepath = "./src/test/resources/ad/securitymaster/api/deltaFiles/"+filename;

		FileReader fr = new FileReader(filepath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		try {
			while ((line = br.readLine()) != null) {
				if (line.contains(msdid)) {
					fileResponse = line;
					Reporter.addStepLog("<b>Record is available in the file for security</b> "+ msdid );				
				} 
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
//		Reporter.addStepLog("<b>Response</b> "+ fileResponse );

	}
		
	
	@And("^user performs comparison between \"([^\"]*)\" named \"([^\"]*)\" and API response$")
    public void user_performs_comparison_between_file_named_filename_and_api_response(String filetype, String filename) {
		
		apiResponse = ValidatePRDBandEISLAttributeStepdef.responseBody;
		
		JSONAssert.assertEquals(apiResponse, fileResponse, JSONCompareMode.LENIENT);
		Reporter.addStepLog("<b style='color:green'> File record is matching with API response !!</b>");
		
	}

}
