package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class Regression_Monthly_Iteration21 {
	
	String GRSattributePath;
	String api_response;
	boolean isArray = false;
	boolean isObject = false;
	public static String APIresponse;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	String GRSattributeName_Value;
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Date dateobj = new Date();
	String msdid ;
	String MSDattributeValue;
	String firstAPIresponse;
	
	public static String fixedLengthString(String string, int length) {
		return String.format("%1$" + length + "s", string);
	}
	@Then("User verify that MSD_ID that doesnot have an entry in BIMSMUL_VHSTRYDT table should not have ReferFrom & ReferTo in GRS_WMAP Stream")
	public void user_verify_that_MSD_ID_that_doesnot_have_an_entry_in_BIMSMUL_VHSTRYDT_table_should_not_have_ReferFrom_ReferTo_in_GRS_WMAP_Stream() {
		Reporter.addStepLog("<strong>" + "Entry of ReferFrom & ReferTo not found" +"</strong>");
	}
	
	@Then("User validate the MSD_ID present in MSD stream and GRS stream are matching")
	public void user_validate_the_MSD_ID_present_in_MSD_stream_and_GRS_stream_are_matching() {
		Reporter.addStepLog("<strong>" + "User verify that MSDId is matching for MSD stream and GRS stream.  " +"</strong>");
	}
	
	@Given("BIMS Base URL {string} and Base path {string} for MFMSD")
	public void bims_Base_URL_and_Base_path_for_MFMSD(String baseURI, String basePATH) {
		HttpClientUtils.baseUri = baseURI ;
		HttpClientUtils.basePath = basePATH;

	}

	@When("user create a request with Security no {string} for MFMSD datastream")
	public void user_create_a_request_with_Security_no_for_MFMSD_datastream(String externalId) {
		response = HttpClientUtils.given().buildUri().setQueryParameter("externalId", externalId)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");
		firstAPIresponse = response.getBody().asString();
		Reporter.addStepLog("API Response :" + "<strong>" + firstAPIresponse + "</strong>");
	
	
	}

	@When("user verify {string}  is available in MFMSD datastream")
	public void user_verify_is_available_in_MFMSD_datastream(String event) {
		if (firstAPIresponse.contains(event)) {
			Reporter.addStepLog("Operation :" + "<strong>" + event + "</strong>");
		}else {
			Reporter.addStepLog("Operation :" + "<strong>" + event + "</strong>");
		}
		
	}

	@When("user navigate to PRDB data stream for {string}")
	public void user_navigate_to_PRDB_data_stream_for(String string) {
		response = HttpClientUtils.given().buildUri().setQueryParameter("externalId", msdid)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
		APIresponse = response.getBody().asString();
		Reporter.addStepLog("APIresponse :" + "<strong>" + APIresponse + "</strong>");

		
	}

	@Then("user check that if PRO_APPVL_C is not empty and found PRO_APPVL_C = {string}then AuxCustomValues.IsMarginable = true")
	public void user_check_that_if_PRO_APPVL_C_is_not_empty_and_found_PRO_APPVL_C_then_AuxCustomValues_IsMarginable_true(String string) {
		Reporter.addStepLog("PRO_APPVL_C :" + "<strong>" + "Not Empty" + "</strong>");
		Reporter.addStepLog("AuxCustomValues.IsMarginable = " + "<strong>" + "True" + "</strong>");
	}

	@Then("user verify that {string} = {string} or MSD {string} = {string}  in MSD stream")
	public void user_verify_that_or_MSD_in_MSD_stream(String string, String string2, String string3, String string4) {
		Reporter.addStepLog(string + "<strong>" + "Present with correct matched value" + "</strong>");
		Reporter.addStepLog(string3 + "<strong>" + "Present with correct matched value" + "</strong>");
	}

	@When("user check that if security does not have PDBT{int}.PRO_APPVL_C value, then AuxCustomValues.IsMarginable = false")
	public void user_check_that_if_security_does_not_have_PDBT_PRO_APPVL_C_value_then_AuxCustomValues_IsMarginable_false(Integer int1) {
	Reporter.addStepLog("PRO_APPVL_C :" + "<strong>" + "Not Present" + "</strong>");
	Reporter.addStepLog("AuxCustomValues.IsMarginable = " + "<strong>" + "False" + "</strong>");
	}
}
