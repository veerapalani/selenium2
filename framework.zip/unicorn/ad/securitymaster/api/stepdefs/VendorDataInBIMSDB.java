package qa.unicorn.ad.securitymaster.api.stepdefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.config.DecoderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.testng.Assert;

import com.fasterxml.jackson.databind.ObjectMapper;

public class VendorDataInBIMSDB {
	
	String jsonString;
	Object id;
	List<String> fileOutput = new ArrayList<String>();
	List<String> dbOutput = new ArrayList<String>();

	
	@Given("^User connects to the BIMS Database using (.+)$")
    public void user_connects_to_the_bims_database_using(String externalid) {

		RestAssured.baseURI = Action.getTestData("BIMSDB-BaseURI") + externalid;
		RestAssuredConfig config = RestAssured.config().decoderConfig(DecoderConfig.decoderConfig().useNoWrapForInflateDecoding(true));

		RequestSpecification request = RestAssured.given();
		request.contentType(ContentType.TEXT);
		request.config(config);
		
		Response response = request.get();
		int statusCode = response.getStatusCode();
		String asString = response.body().asString();
		
//********************************* converting Yaml output to Json **************/
		jsonString = RestApiUtils.convertYamlToJson(asString);
		jsonString = jsonString.replaceAll("T00:00:00.0000000Z", "");
		
		Reporter.addStepLog("<b>Status Code: </b>"+statusCode);
		if (statusCode==200) {
			Reporter.addStepLog("<b>User succesfully connected to BIMS DB </b>");
		}
		else {
			Reporter.addStepLog("<b>User is unable to connect to BIMS DB </b>");}
	}	
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })	
	@When("^User extracts response from BIMS DB for External ID (.+)$")
    public void user_extracts_response_from_bims_db_for_external_id(String externalid) throws IOException {

//************** for integer externalIds****************/
	try {
		id= Double.parseDouble(externalid);
	}catch(NumberFormatException e) {System.out.println("ExternaID is string");}
		
	Map<String, Object> result = new ObjectMapper().readValue(jsonString, HashMap.class);
		
		Iterator it = result.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry mapElement = (Map.Entry) it.next();
			if (mapElement.getValue() instanceof Map) {
				Map issueMap = (Map) mapElement.getValue();

//**************** extracting all values from the DB response into an array****************/
				Iterator it1 = issueMap.entrySet().iterator();
				while (it1.hasNext()) {
					Map.Entry insidelement = (Map.Entry) it1.next();
					if (insidelement.getValue() instanceof List<?>) {
						List<HashMap<String, Object>> issueList = (List<HashMap<String, Object>>) insidelement.getValue();

						issueList.stream().forEach(listsData -> {
							listsData.entrySet().forEach(listData -> {
								Object finalValues = listData.getValue();
								String strfinalValues = finalValues.toString();
								
								if ((strfinalValues).matches(String.valueOf(id))) {            
										Double d = Double.parseDouble(strfinalValues);
										String strValue = String.format("%06d", d.intValue());
										dbOutput.add(strValue);
								}else {dbOutput.add(strfinalValues);}
							});
						});
					}else { Object outerelements = insidelement.getValue();
							String stroutervalues  = outerelements.toString();
							
							if ((stroutervalues).matches(String.valueOf(id))) {            
								Double d1 = Double.parseDouble(stroutervalues);
								String strValue1 = String.format("%06d", d1.intValue());
								dbOutput.add(strValue1);
							}else {dbOutput.add(stroutervalues);}
					}
				}
			}
		}
		Reporter.addStepLog("<b>Response from BIMS DB: </b>" + dbOutput);
	}
	

	@And("^User reads data from vendor file for same External ID (.+)$")
    public void user_reads_data_from_vendor_file_for_same_external_id(String externalid) throws IOException {

		String filePath = "D:\\Users\\KhandareM\\Broadridge\\Security Master\\MCR 4\\Sprint 31\\USM-1776\\ACMD09-23.txt";
		List<String> vendorArray = new ArrayList<String>();

		try {
			FileReader fr = new FileReader(filePath);
			BufferedReader br = new BufferedReader(fr);

			String line;
			String[] newline;
			while ((line = br.readLine()) != null) {
				if (line.contains(externalid)) {
					newline = line.split("\\|");
					vendorArray.addAll(Arrays.asList(newline));
				}
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
//************* extracting all values from file into an array*************/	
		for (String str : vendorArray) {
			if (str != null && !str.isEmpty()) {
				fileOutput.add(str);
			}
		}
		Reporter.addStepLog("<b> Response from Vendor file: </b>" + fileOutput);
	}
	

	@Then("^User performs Data Comparison between vendor file and BIMS DB$")
	public void user_performs_data_comparison_between_vendor_file_and_bims_db() {
		
		Assert.assertEquals(dbOutput, fileOutput, "Data from Vendor file does not match with BIMS Data Base");
		Reporter.addStepLog("<b style='color:green'> Data from Vendor file has been successfully uploaded to BIMS DataBase!!</b>");
		
	}

}
