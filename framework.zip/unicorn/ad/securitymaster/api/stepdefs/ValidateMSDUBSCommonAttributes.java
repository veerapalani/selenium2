package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.testng.Assert;

import io.cucumber.java.en.And;
import io.restassured.path.json.JsonPath;
import qa.framework.utils.Reporter;

public class ValidateMSDUBSCommonAttributes {
	String msdVendorId, bimsVendorId;

	@And("^API response should contain \"([^\"]*)\" as per the Cross Reference File for Security (.+)$")
	public void api_response_should_contain_something_as_per_the_cross_reference_file_for_security(String strArg1,
			String msdid) throws IOException {

		
//************ Getting Vendor ID from BIMS API response ************/
		
		JsonPath jsonresponse = ValidatePRDBandEISLAttributeStepdef.jsonresponse;
		bimsVendorId = jsonresponse.getString("Id.VENDOR_ID");


//************ Getting Vendor ID from MSD Cross Reference File ************/		
		
		String filePath = "./src/test/resources/ad/securitymaster/api/otherFiles/BIOS.BIMS.QA.OUT.PRDB.MATCHED.CNV.G0001V00.txt";

		try {
			FileReader fr = new FileReader(filePath);
			BufferedReader br = new BufferedReader(fr);

			String line;
			while ((line = br.readLine()) != null) {
				if (line.contains(msdid)) {
					msdVendorId = line.substring(8, 18);				
				}
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		Reporter.addStepLog("<b> Actual Value of Vendor ID from BIMS API: </b>" + bimsVendorId);
		Reporter.addStepLog("<b> Expected Value of Vendor ID from MSD Cross Reference file: </b>" + msdVendorId);

		Assert.assertEquals(bimsVendorId, msdVendorId,"Vendor ID from BIMS API response is not matching with Cross Reference file");
		Reporter.addStepLog("<b>Value of Vendor ID from BIMS API is matching with Cross Refernce File from MSD </b>");

	}

}
