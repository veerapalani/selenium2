package qa.unicorn.ad.securitymaster.api.stepdefs;

// *** @author Mansi *****/

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.utils.Reporter;

public class ValidateFISLOCfileLayout {
	
	int timestamplength, orderCount;
	String line, header;
	String headerRecordId, recordVersion, recordSeqno, applicationId, deliveryBundle;
	String orderRecordId, orderRecordVer, schema, ischema, chschema, providerId, deliveryType;
	ArrayList<String> orderArray = new ArrayList<String>();
	ArrayList<String> errorArray = new ArrayList<String>();
	
	
	@Given("^User has \"([^\"]*)\" Shopping file$")
    public void user_has_something_shopping_file(String strArg1) throws FileNotFoundException {
		
		String filepath="D:\\Users\\KhandareM\\Broadridge\\Security Master\\MCR 4\\Sprint 25\\USM-1710\\FISLOC\\FISLOC.txt";
		
		FileReader fr = new FileReader(filepath);
		BufferedReader br = new BufferedReader(fr);
		
		try {
			while((line = br.readLine())!=null){
			        if (line.startsWith("H")) {
			        	header = line;
			        }else if (line.startsWith("B")) {
			        	 orderArray.add(line);
			        }else errorArray.add(line);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		orderCount = orderArray.size();
	}	
	
	
//	************************************* Header Records***********************************************/
	
	@When("^user checks the hardcoded value of 'RECORD ID' in header record$")
    public void user_checks_the_hardcoded_value_of_record_id_in_header_record() {
		
		headerRecordId = header.substring(0, 4);
		Reporter.addStepLog("<b> Expected Record ID:</b> HEA1");
		Assert.assertEquals(headerRecordId, "HEA1", " Header Record ID is not in proper format");
		Reporter.addStepLog("<b> Actual Hardcoded value of Header Record ID is:  </b>" +headerRecordId);
	}
	
	@Then("^length of 'RECORD ID' should be '4'$")
    public void length_of_record_id_should_be_4() {
		
		int recordIdlength = headerRecordId.length();
		Assert.assertEquals(recordIdlength, 4, "Length of Header Record is not matching");
		Reporter.addStepLog("<b> Data length of Header Record ID is:  </b>" +recordIdlength);
	}
	
	@When("^user checks the hardcoded value of 'RECORD VERSION' in header record$")
	public void user_checks_the_hardcoded_value_of_record_version_in_header_record() {
		
		recordVersion = header.substring(4, 6);
		Reporter.addStepLog("<b> Expected Record Version:</b> 01");
		Assert.assertEquals(recordVersion, "01", "Record Version is not in proper format");
		Reporter.addStepLog("<b> Actual Hardcoded value of Record Version is:  </b>" +recordVersion);
	}
	
	@Then("^length of 'RECORD VERSION' should be '2'$")
    public void length_of_record_version_should_be_2() {
		
		int recordVerlength = recordVersion.length();
		Assert.assertEquals(recordVerlength, 2, "Length of Record Version is not matching");
		Reporter.addStepLog("<b> Data length of Header Record Version is:  </b>" +recordVerlength);
	}
	
	@When("^user checks the hardcoded value of 'RECORD SEQUENCE NUMBER' in header record$")
    public void user_checks_the_hardcoded_value_of_record_sequence_number_in_header_record() {
		
		recordSeqno = header.substring(6, 8);
		Reporter.addStepLog("<b> Expected Record Sequence number:</b> 01");
		Assert.assertEquals(recordSeqno, "01", "Record Sequence number is not in proper format");
		Reporter.addStepLog("<b> Actual Hardcoded value of Record Sequence number is:  </b>" +recordSeqno);
	}
	
	@Then("^length of 'RECORD SEQUENCE NUMBER' should be '2'$")
    public void length_of_record_sequence_number_should_be_2() {
		
		int recordSeqlength = recordSeqno.length();
		Assert.assertEquals(recordSeqlength, 2, "Length of Record Sequence number is not matching");
		Reporter.addStepLog("<b> Data length of Record Sequence number is:  </b>" +recordSeqlength);
	}
	
	@When("^user checks the hardcoded value of 'APPLICATION ID' in header record$")
    public void user_checks_the_hardcoded_value_of_application_id_in_header_record() {
		
		applicationId = header.substring(8, 11);
		Reporter.addStepLog("<b> Expected Application ID:</b> IUS");
		Assert.assertEquals(applicationId, "IUS", "Application ID is not in proper format");
		Reporter.addStepLog("<b> Actual Hardcoded value of Application ID is:  </b>" +applicationId);
	}
	
	@Then("^length of 'APPLICATION ID' should be '3'$")
    public void length_of_application_id_should_be_3() {
		
		int appIdlength = applicationId.length();
		Assert.assertEquals(appIdlength, 3, "Length of Application ID is not matching");
		Reporter.addStepLog("<b> Data length of Application ID is:  </b>" +appIdlength);
	}
	
	@When("^user checks the hardcoded value of 'DELIVERY BUNDLE' in header record$")
    public void user_checks_the_hardcoded_value_of_delivery_bundle_in_header_record() {
		
		deliveryBundle = header.substring(11, 13);	
		Reporter.addStepLog("<b> Expected Delivery Bundle:</b> 01");
		Assert.assertEquals(deliveryBundle, "01", "Delivery Bundle is not in proper format");
		Reporter.addStepLog("<b> Actual Hardcoded value of Delivery Bundle is:  </b>" +deliveryBundle);
	}
	
	@Then("^length of 'DELIVERY BUNDLE' should be '2'$")
    public void length_of_delivery_bundle_should_be_2() {
		
		int deliveryBundlelength = deliveryBundle.length();
		Assert.assertEquals(deliveryBundlelength, 2, "Length of Delivery Bundle is not matching");
		Reporter.addStepLog("<b> Data length of Delivery Bundle is:  </b>" +deliveryBundlelength);
	}
	
	@When("^user checks the starting position of 'SYSTEM_TIMESTAMP' (.+) in header record$")
    public void user_checks_the_starting_position_of_systemtimestamp_in_header_record(String timestamp) {
		
		timestamplength = timestamp.length();
		int startIndexTimestamp = (header.indexOf(timestamp))+1;
		Reporter.addStepLog("<b> Expected starting position of Timestamp:  </b> 186");
		Assert.assertEquals(startIndexTimestamp, 186, "Starting position is not matching");
		Reporter.addStepLog("<b> Actual starting position of Timestamp:  </b>" +startIndexTimestamp );
	}
	
	@Then("^length of 'SYSTEM TIMESTAMP' should be '19'$")
    public void length_of_system_timestamp_should_be_19() {
	
		Assert.assertEquals(timestamplength, 19, "Length of Timestamp is not matching");
		Reporter.addStepLog("<b> Data length of Timestamp is:  </b>" +timestamplength);
	}
	
	
	//********************************* Order Records ************************************/
	
	@When("^user checks the hardcoded value of 'ORDER RECORD ID' in Order record$")
    public void user_checks_the_hardcoded_value_of_order_record_id_in_order_record() {
	
		Reporter.addStepLog("<b> Total number of Order Records:  </b>" +orderCount);
		Reporter.addStepLog("<b> Expected Record ID for all Order records:</b> BESN");
		
		for (String str : orderArray) {
			orderRecordId = str.substring(0, 4);
			Assert.assertEquals(orderRecordId, "BESN", "Order Record ID is not in proper format");
		}
		Reporter.addStepLog("<b> Actual Hardcoded value of Order Record ID for all records is:  </b>" +orderRecordId);
	}
	
	@Then("^length of 'ORDER RECORD ID' should be '4'$")
    public void length_of_order_record_id_should_be_4() {
		
		int orderRecIdlength = orderRecordId.length();
		Assert.assertEquals(orderRecIdlength, 4, "Length of Order Record is not matching");
		Reporter.addStepLog("<b> Data length of Order Record ID for all records is:  </b>" +orderRecIdlength);	
	}
	
	@When("^user checks the hardcoded value of 'ORDER RECORD VERSION' in Order record$")
    public void user_checks_the_hardcoded_value_of_order_record_version_in_order_record() {
		
		Reporter.addStepLog("<b> Total number of Order Records:  </b>" +orderCount);
		Reporter.addStepLog("<b> Expected Record Version for all records:</b> 01");
		
		for (String str : orderArray) {
			orderRecordVer = str.substring(4, 6);
			Assert.assertEquals(orderRecordVer, "01", " Order Record Version is not in proper format");
		}
		Reporter.addStepLog("<b> Actual Hardcoded value of Order Record Version for all records is:  </b>" +orderRecordVer);
	}
	
	@Then("^length of 'ORDER RECORD VERSION' should be '2'$")
    public void length_of_order_record_version_should_be_2() {
		
		int orderRecVerlength = orderRecordVer.length();
		Assert.assertEquals(orderRecVerlength, 2, "Length of Order Record Version is not matching");
		Reporter.addStepLog("<b> Data length of Order Record Version for all records is:  </b>" +orderRecVerlength);	
	}
	
	@When("^user checks the hardcoded value of 'SCHEMA' in Order record$")
    public void user_checks_the_hardcoded_value_of_schema_in_order_record() {
		
		int ischemacount = 0;
		int chschemacount = 0;
		String space = "            ";
		
		Reporter.addStepLog("<b> Total number of Order Records:  </b>" +orderCount);
		Reporter.addStepLog("<b> Expected Schema should be: </b> 'I-      ' if ISIN IS NOT NULL or 'CH      ' in case ISIN IS NULL");
		
		for (String str : orderArray) {
			schema = str.substring(6, 14);
			String isin = str.substring(14, 26);
			
			if (isin.contentEquals(space))  {
				chschema= schema;
				Assert.assertEquals(chschema, "CH      ", " Order Schema is not in proper format");
				chschemacount++;
			} else  {
				ischema= schema;
				Assert.assertEquals(ischema, "I-      ", " Order Schema is not in proper format");
				ischemacount++;
			}
		} 
		Reporter.addStepLog("<b>Number of order records where ISIN is not null:  </b>"+ischemacount);
		Reporter.addStepLog("<b>Schema for </b>"+ischemacount + "<b> not null order records is : </b>" + '"'+ ischema +'"');
		Reporter.addStepLog("<b>Number of order records where ISIN is null:  </b>"+chschemacount);
		Reporter.addStepLog("<b>Schema for </b>"+chschemacount + "<b> null order records is : </b>" + '"' + chschema +'"' );
	}
	
	@Then("^'SCHEMA' data length should be '8'$")
    public void schema_data_length_should_be_8() {
		
		int schemalength = schema.length();
		Assert.assertEquals(schemalength, 8, "Length of schema is not matching");
		Reporter.addStepLog("<b> Data length of Schema is:  </b>" +schemalength);	
	}
	
	@When("^user checks the hardcoded value of 'PROVIDER ID' in Order record$")
    public void user_checks_the_hardcoded_value_of_provider_id_in_order_record() {
		
		Reporter.addStepLog("<b> Total number of Order Records:  </b>" +orderCount);
		Reporter.addStepLog("<b> Expected Provider ID for all records:</b> 0001");
		
		for (String str : orderArray) {
			providerId = str.substring(30, 34);
			Assert.assertEquals(providerId, "0001", " Provider ID is not in proper format");
		}
		Reporter.addStepLog("<b> Actual Hardcoded value of Provider ID for all records is:  </b>" + providerId);
	}
	
	@Then("^length of 'PROVIDER ID' should be '4'$")
    public void length_of_provider_id_should_be_4() {
		
		int providerIdlength = providerId.length();
		Assert.assertEquals(providerIdlength, 4, "Length of Provider ID is not matching");
		Reporter.addStepLog("<b> Data length of Provider ID for all records is:  </b>" +providerIdlength);	
	}
	
	@When("^user checks the hardcoded value of 'DELIVERY TYPE' in Order record$")
    public void user_checks_the_hardcoded_value_of_delivery_type_order_record() {
		
		int newSecCount = 0;
		int oldSecCount = 0;
		String newDeliveryTyp = null, oldDeliveryTyp = null;
		Reporter.addStepLog("<b> Total number of Order Records:  </b>" +orderCount);
		Reporter.addStepLog("<b> Expected Delivery Type should be: </b> '1' representing New security or '2' representing Old Security");
		
		for (String str : orderArray) {
			deliveryType = str.substring(34, 35);
			if (deliveryType.matches("1")) {
				newDeliveryTyp = deliveryType;
				newSecCount++;
			}else {
					oldDeliveryTyp = deliveryType;
					Assert.assertEquals(oldDeliveryTyp,"2", "Delivery Type is not in proper format");
					oldSecCount++; 
			}
		} 
		Reporter.addStepLog("<b>Number of order records where Security is new or not present in previous day's file:  </b>"+newSecCount);
		Reporter.addStepLog("<b>Actual value of Delivery Type for new Securities is: </b>"+ newDeliveryTyp);
		Reporter.addStepLog("<b>Number of order records where Security is present in previous day's file:  </b>"+oldSecCount);
		Reporter.addStepLog("<b>Actual value of Delivery Type for old Securities is: </b>"+ oldDeliveryTyp);
	}
	
	@Then("^length of 'DELIVERY TYPE' should be '1'$")
    public void length_of_delivery_type_should_be_1() {
		
		int deliveryTyplength = deliveryType.length();
		Assert.assertEquals(deliveryTyplength, 1, "Length of Delivery Type is not matching");
		Reporter.addStepLog("<b> Data length of Delivery Type for all records is:  </b>" +deliveryTyplength);	
	}
	
	
}
