package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Sheet;


import qa.framework.utils.ExcelUtil;

public class GenericUtilForSecurityMaster {
	String tablename = null;

	@SuppressWarnings("null")

	/// to check the timestamp valid or not
	public  String isTimeStampValid(String inputString) {
		System.out.println(inputString);
		SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSSSSS");
		System.out.println(format.getTimeInstance());
		try {
			//format.setLenient(false);
			format.parse(inputString);
			

			return "true";
		} catch (ParseException e) {
			return "false";
		}
	}

	// to clean an excel
	public void cleanSheet(Sheet sheet) {
		int numberOfRows = sheet.getPhysicalNumberOfRows();

		if (numberOfRows > 0) {
			for (int i = sheet.getFirstRowNum(); i <= sheet.getLastRowNum(); i++) {
				if (sheet.getRow(i) != null) {
					sheet.removeRow(sheet.getRow(i));
				} else {
					System.out.println("Info: clean sheet='" + sheet.getSheetName() + "' ... skip line: " + i);
				}
			}
		} else {
			System.out.println("Info: clean sheet='" + sheet.getSheetName() + "' ... is empty");
		}
	}

	// Get map value for excel data with 1st column as key and next colums as its
	// value
	public static Map<Object, List<Object>> getMapforKeyValpairExceldata(String pathmapfilename) {
		Map<Object, List<Object>> mapattrGRS = new HashMap<Object, List<Object>>();
		//Map<Object, List<Object>> securityAttrbtlist = new HashMap<Object, List<Object>>();
		ExcelUtil.setExcelFile(pathmapfilename, "Sheet1");
		System.out.println("set excel" + pathmapfilename);

		int rowcnt = ExcelUtil.getRowCount();
		System.out.println("row count:" + rowcnt);
		for (int i = 1; i < rowcnt; i++) {
			List<Object> grsfield = new ArrayList<Object>();
			Object field1 = ExcelUtil.getCellData(i, 0);
			System.out.println(ExcelUtil.getCellData(i, 1));
			System.out.println(field1);
			for (int j = 1; j < ExcelUtil.getCellCount(i); j++) {
				System.out.println("row:" + i + "column no:" + j);
				grsfield.add(ExcelUtil.getCellData(i, j));

			}
			System.out.println(grsfield);
			mapattrGRS.put(field1, grsfield);
			System.out.println("grs:" + mapattrGRS.size() + mapattrGRS);

		}
		ExcelUtil.closeWorkBook();
		System.out.println("grs:" + mapattrGRS.size() + mapattrGRS);
		return mapattrGRS;
	}

	public static String pathsplittilltablename(String pathjson) {
		String tablename;
		String result = new String();
		System.out.println(pathjson);
		String arrpath[] = new String[2];
		arrpath = pathjson.replace('.', ':').split(":");
		// System.out.println(arrpath[0]+arrpath[1]+arrpath[2]+arrpath[3]+"0123");
		try {
			System.out.println(arrpath[0]);

			StringBuilder target = new StringBuilder();

			for (int i = 0; i < arrpath.length - 1; i++) {
				target.append(arrpath[i]);
				if (i < arrpath.length - 2) {
					target.append(":");
				}
				if (i == arrpath.length - 2) {
					tablename = arrpath[i];
					System.out.println("table name:" + tablename);

				}
			}
			result = "$." + target.toString().replace(':', '.');
			System.out.println(target + "---" + result);

		} catch (Exception e) {
			System.out.println("try--" + e);
		}
		System.out.println("---" + result);
		return result;
	}

	public static String execCmdSync(String cmd[]) throws java.io.IOException, InterruptedException {

		// RLog.i(TAG, "Running command:", cmd);

		Runtime rt = Runtime.getRuntime();
		Process proc = rt.exec(cmd);

		// String[] commands = {"system.exe", "-get t"};

		BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
		BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

		StringBuffer stdOut = new StringBuffer();
		StringBuffer errOut = new StringBuffer();

		// Read the output from the command:
		System.out.println("Here is the standard output of the command:\n");
		String s = null;
		while ((s = stdInput.readLine()) != null) {
			System.out.println(s);
			stdOut.append(s);
		}

		// Read any errors from the attempted command:
		System.out.println("Here is the standard error of the command (if any):\n");
		while ((s = stdError.readLine()) != null) {
			System.out.println(s);
			errOut.append(s);
		}

		return stdOut.toString();
	}

}
