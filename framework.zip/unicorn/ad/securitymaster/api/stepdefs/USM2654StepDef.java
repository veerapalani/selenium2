package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class USM2654StepDef {
	
	String api_response;
	boolean isArray = false;
	boolean isObject = false;
	public static String APIresponse;
	public static String MSDID;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	public List<String> listofSecurity = new ArrayList<String>();
	String queryParameter;
	String attributeNo;
	String prdb_Attribute;
	String prdbAttribute_Value;
	
	
	

@Given("user has BIMS QA API Base URL {string} and Base path {string}")
public void user_has_acess_to_BIMS_API_and_user_create_a_request_for_Base_URL_and_Base_path(String baseURI, String basePATH) {
	HttpClientUtils.baseUri = baseURI;
	HttpClientUtils.basePath = basePATH;
	Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
	Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");
	
}

@Given("user create request url and set Path Parameter {string} as {string}")
public void user_set_Path_Parameter_as_in_request_url(String pathParam, String msdid) {
	MSDID = msdid;
	response = HttpClientUtils.given()
			.setPathParameter("entityId", msdid).buildUri()
			.setCetificate("D:\\Users\\GuptaVi\\ALL\\server (1).pfx", "")
			.setProxy("10.98.21.23", 8080)
			.setAcceptType("application/json")
			.executeRequest(MethodType.GET);
	
	api_response = response.getBody().asString();
	Reporter.addStepLog("Endpoint :"+"<strong>" + msdid +"</strong>");


}

@When("user sends a get request using {string}as end point for Qa URL")
public void user_make_a_get_request_method_call_for(String msdid) {

	
	
}

@Then("user verfy that response code  is {int} for attribute {string} PRDB_Attribute {string}")
public void user_verfy_that_response_code_is_for_attribute_PRDB_Attribute(Integer int1, String attrbuteNo, String attribute) {
	int statusCode = response.getStatusCode();
	
	if(statusCode != 200) {
		String path = "./src/test/resources/ad/securitymaster/api/responsejson/PRU-failed.log";
		try {
			
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Date dateobj = new Date();
			
            FileWriter writer = new FileWriter(path, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
 
            bufferedWriter.write(df.format(dateobj) +"\t" +attrbuteNo  +" \t"+attribute+"\t  MSDID "+ MSDID + "  NO response for the Security  :  ");
            bufferedWriter.newLine();
            bufferedWriter.close();
        } catch (IOException ee) {
            ee.printStackTrace();
        }
		
	}
	Reporter.addStepLog("StatusCode :"+"<strong>"+statusCode+"</strong>");
	Assert.assertEquals(statusCode, 200, "Status code returned");
	
}


@Then("User verify that PRDB Attribute {string} is available in {string} table in API response for {string}")
public void user_verify_that_PRDB_Attribute_is_available_in_table_in_API_response_for(String prdbAttribute,String prdbtable, String atributeNo) {

	boolean attributeFound = false;
		String attributeName = null;Object attributeValue=null;
		String prdbPath = "$.CustomFields.UBS_PRDB." + prdbtable;

		
		try {
			Object item = com.jayway.jsonpath.JsonPath.read(api_response, prdbPath);
		
		if (item instanceof net.minidev.json.JSONArray) {
			// It's an array
			
			String prdbPath2 = prdbPath + "[*]";
			
			List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(api_response, prdbPath2);
			
			for (Map<String, String> map : result) {
				for (Map.Entry<String, String> entry : map.entrySet()) {
					attributeName = entry.getKey();
					
					if (attributeName.equals(prdbAttribute)) {
						attributeFound = true;
						attributeValue = entry.getValue();
					}
				}
			}


		} else if (item instanceof LinkedHashMap) {
			// It's an object
			LinkedHashMap<String, Object> map = com.jayway.jsonpath.JsonPath.read(api_response, prdbPath);
			if (map.containsKey(prdbAttribute)) {
				attributeFound = true;
				attributeValue = map.get(prdbAttribute);
			}

		} else {
			// It's something else, like a string or number
			prdbPath = prdbPath + "." + prdbAttribute;
			attributeValue = com.jayway.jsonpath.JsonPath.read(api_response, prdbPath);
			if(attributeValue !=null) {
				attributeFound =true;
			}
		}
		
		
		
		
		prdb_Attribute = prdbAttribute;
		prdbAttribute_Value = (String) attributeValue.toString();
		
		if (attributeFound) {
			Reporter.addStepLog("<b>" + "Attribute Name " + "</b>" +prdbAttribute);
			Reporter.addStepLog("<b>" + "Attribute Value : " + "</b>" +attributeValue);
			Reporter.addStepLog("<b>" + "Attribute Found" + "</b>");
			Reporter.addStepLog("<b>" + "Path " + "</b>"+ prdbPath);
			}
			 else {
					Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");
					String path = "./src/test/resources/ad/securitymaster/api/responsejson/PRU-failed.log";
					try {
						
						DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
						Date dateobj = new Date();
						
			            FileWriter writer = new FileWriter(path, true);
			            BufferedWriter bufferedWriter = new BufferedWriter(writer);
			 
			            bufferedWriter.write(df.format(dateobj) +"\t"   +" MSDID "+ MSDID +"\tatributeNo : \t "+atributeNo+ "  PRDB Attribute not Found :  "+prdbtable + "  "+ "prdbAttributeName : " + " " +prdbAttribute);
			            bufferedWriter.newLine();
			            bufferedWriter.close();
			        } catch (IOException ee) {
			            ee.printStackTrace();
			        }
			 }
		
		} catch (Exception e) {
			Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");
			String path = "./src/test/resources/ad/securitymaster/api/responsejson/PRU-failed.log";
			try {
				
				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
				Date dateobj = new Date();
				
	            FileWriter writer = new FileWriter(path, true);
	            BufferedWriter bufferedWriter = new BufferedWriter(writer);
	 
	            bufferedWriter.write(df.format(dateobj) +"\t"  +" MSDID "+ MSDID +"\t atributeNo : \t "+atributeNo+ "  PRDB Attribute not Found :  "+prdbtable + "  "+ "prdbAttributeName : " + " " +prdbAttribute);
	            bufferedWriter.newLine();
	            bufferedWriter.close();
	        } catch (IOException ee) {
	            ee.printStackTrace();
	        }
	 }
			
		    
			Assert.assertEquals(attributeFound, true, "Attribute not found");
	

}


@Then("User verify that EISL Attribute {string} is mapped as {string} in api respose for {string} and {string} and {string}")
public void user_verify_that_EISL_Attribute_is_mapped_as_in_api_respose_for_and_and(String EISL_attribute, String EISL_Path, String attributeNo, String PRDB_Table, String PRDB_Attribute) {
	
	boolean attributeFound = false;
	String EISLPATH = "$."+EISL_Path;
	String attributeName = null;Object attributeValue=null;
	try {
	Object item = com.jayway.jsonpath.JsonPath.read(api_response, EISLPATH);
			
	if (item instanceof net.minidev.json.JSONArray) {
		// It's an array
		
		isArray = true;
		
		String EISLPATH2 = EISLPATH + "[*]";
		
		List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(api_response, EISLPATH2);
	//	System.out.println("result " + result);
		for (Map<String, String> map : result) {
			for (Map.Entry<String, String> entry : map.entrySet()) {
				attributeName = entry.getKey();
				
				if (attributeName.equals(EISL_attribute)) {
					attributeFound = true;
					attributeValue = entry.getValue();
				}
			}
		}


	} else if (item instanceof LinkedHashMap) {
		// It's an object
		LinkedHashMap<String, String> map = com.jayway.jsonpath.JsonPath.read(api_response, EISLPATH);
		if (map.containsKey(EISL_attribute)) {
			attributeValue = map.get(EISL_attribute);
			attributeFound = true;

		}

	} else {
		// It's something else, like a string or number
		EISLPATH = EISLPATH + "." + EISL_attribute;
		attributeValue = com.jayway.jsonpath.JsonPath.read(api_response, EISLPATH);
		if(attributeValue !=null) {
			attributeFound =true;
		}
	}


	
	
	if (attributeFound) {
		Reporter.addStepLog("<b>" + "Attribute Name " + "</b>" +EISL_attribute);
		Reporter.addStepLog("<b>" + "Attribute Value : " + "</b>" +attributeValue);
		Reporter.addStepLog("<b>" + "Attribute Found" + "</b>");
		Reporter.addStepLog("<b>" + "Path " + "</b>"+ EISLPATH);
		
		String filepath2 ="./src/test/resources/ad/securitymaster/api/responsejson/PRU-passed.log";
		
		try {
			
						
	        FileWriter writer = new FileWriter(filepath2, true);
	        BufferedWriter bufferedWriter = new BufferedWriter(writer);
	        bufferedWriter.write("Pass  : MSDID  "+ MSDID +"  attributeNo  :  "+attributeNo +"   \t   "+ PRDB_Table +"\t "+ fixedLengthString(PRDB_Attribute,35)  +"\t  " +fixedLengthString(EISL_attribute,35)+fixedLengthString(attributeValue.toString(),40));
	        bufferedWriter.newLine();
	        bufferedWriter.close();
	    } catch (IOException ee) {
	        ee.printStackTrace();
	    }
		
		
		}
		 else {
				Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");
				String path = "./src/test/resources/ad/securitymaster/api/responsejson/PRU-failed.log";
				try {
					
					DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
					Date dateobj = new Date();
					
					
		            FileWriter writer = new FileWriter(path, true);
		            BufferedWriter bufferedWriter = new BufferedWriter(writer);
		 
		            bufferedWriter.write(df.format(dateobj)+"\t"  +" MSDID "+ MSDID +"\t"+"AttributeNo  \t"+attributeNo +"   \t   "+ PRDB_Table +"\t "+ fixedLengthString(PRDB_Attribute,35) + "  EISL Attribute not Found :    "+ "\t" + " "+fixedLengthString(EISL_attribute,35));
		            bufferedWriter.newLine();
		            bufferedWriter.close();
		        } catch (IOException ee) {
		            ee.printStackTrace();
		        }
		 }
	
	
		
	
	} catch (Exception e) {
		Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");
		String path = "./src/test/resources/ad/securitymaster/api/responsejson/PRU-failed.log";
		try {
			
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Date dateobj = new Date();

			FileWriter writer = new FileWriter(path, true);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
 
            bufferedWriter.write(df.format(dateobj)+"  MSDID    "+ MSDID +"\t attributeNo : \t "+attributeNo +"   \t   "+ PRDB_Table +"\t "+ fixedLengthString(PRDB_Attribute,35) +  "\t  EISL Attribute not Found :  " + "\t  "+ fixedLengthString(EISL_attribute,40));
            bufferedWriter.newLine();
            bufferedWriter.close();
        } catch (IOException ee) {
            ee.printStackTrace();
        }
 }
		Assert.assertEquals(attributeFound, true, "Attribute not found");
	
		MSDID = null;
			
}


























public static String fixedLengthString(String string, int length) {
    return String.format("%1$"+length+ "s", string);
}
	

}
