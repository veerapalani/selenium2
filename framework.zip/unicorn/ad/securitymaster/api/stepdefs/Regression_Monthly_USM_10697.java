package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class Regression_Monthly_USM_10697 {
	
	String GRSattributePath;
	String api_response;
	boolean isArray = false;
	boolean isObject = false;
	public static String APIresponse;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	String GRSattributeName_Value;
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Date dateobj = new Date();
	String msdid ;
	String MSDattributeValue;
	
	public static String fixedLengthString(String string, int length) {
		return String.format("%1$" + length + "s", string);
	}
	
	@Given("user has acess BIMS izhora GRS_WMAP  stream URL {string} and Base path {string}")
	public void user_has_acess_BIMS_izhora_GRS_WMAP_stream_URL_and_Base_path(String baseURI, String basePATH) {
		HttpClientUtils.baseUri = baseURI ;
		HttpClientUtils.basePath = basePATH;
	}

	@Given("user set Query Parameter {string} as {string} for GRS_WMAP stream")
	public void user_set_Query_Parameter_as_for_GRS_WMAP_stream(String string, String externalId) {
		response = HttpClientUtils.given().buildUri().setQueryParameter("externalId", externalId)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");
		String firstAPIresponse = response.getBody().asString();
		System.out.println(firstAPIresponse);
	}

	@When("user search for the query for GRS_WMAP stream")
	public void user_search_for_the_query_for_GRS_WMAP_stream() {
	}

	@Then("user should recieve Sucess and repose code {int} from Izhora")
	public void user_should_recieve_Sucess_and_repose_code_from_Izhora(Integer int1) {
	}

	@Then("user fetch the value of {string} and {string} and that should be {string}")
	public void user_fetch_the_value_of_and_and_that_should_be(String string, String string2, String string3) {
	}

	//MSD Stream
	
	@Given("user has acess BIMS izhora MSD URL {string} and Base path {string}")
	public void user_has_acess_BIMS_izhora_MSD_URL_and_Base_path(String baseURI, String basePATH) {
		HttpClientUtils.baseUri = baseURI ;
		HttpClientUtils.basePath = basePATH;
	}

	@Given("user set Query Parameter {string} as {string} for MSD stream")
	public void user_set_Query_Parameter_as_for_MSD_stream(String string, String externalId) {
		response = HttpClientUtils.given().buildUri().setQueryParameter("externalId", externalId)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");
		String firstAPIresponse = response.getBody().asString();
		System.out.println(firstAPIresponse);
	}

	@When("user search for the query for MSD stream")
	public void user_search_for_the_query_for_MSD_stream() {
		
	}



}
