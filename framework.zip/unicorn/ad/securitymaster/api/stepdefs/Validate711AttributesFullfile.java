package qa.unicorn.ad.securitymaster.api.stepdefs;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;

public class Validate711AttributesFullfile {	

	boolean testflag = false;
	File[] listOfFiles;
	List<String> listofrecords = new ArrayList<String>();;
	String filename;
	
	@Given("^user has access to Full load file named \"([^\"]*)\"$")
    public void user_has_access_to_full_load_file_named_something(String filename) {
		
		String folderpath = "D:\\Users\\KhandareM\\BIMS_FullLoad_AllData_10-21-2020\\out";
		File folder = new File(folderpath);
		listOfFiles = folder.listFiles();
		
		Reporter.addStepLog("<b> User is able to access to Full load file named: "+ filename + "</b>" );
	}
	
	
	@When("^user verifies whether the \"([^\"]*)\" attributes are available in file$")
    public void user_verifies_whether_the_something_attributes_are_available_in_file(String attributetype) throws FileNotFoundException {
		
		String excelFilePath = "./src/test/resources/ad/securitymaster/api/excel/Full load file Validation Sheet.xlsx";
		String sheetName = attributetype;
		
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		List<Object> attributeList = exlObj.getColumnData(sheet, 0, "PRDB Attributes");
		
		for(int i = 0; i < attributeList.size(); i++) {
			String attributename = (String)(attributeList.get(i));
			
			for (File file : listOfFiles) {
				BufferedReader br = new BufferedReader(new FileReader(file));
				String line,linelist;
				try {
					while ((line = br.readLine()) != null) {
						if (line.contains(attributename)) {
							linelist = line;
							filename = file.getName();
							listofrecords.addAll(Arrays.asList(linelist));
							break;										
						} 
					}
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}	
			}
			
			if (listofrecords.size()>0) {
				testflag = true;
				exlObj.setCellData(sheet, i+1, 1, "TRUE");
			}
			else exlObj.setCellData(sheet, i+1, 1, "FALSE");	
				
			Assert.assertEquals("Attributes is not present in Full load file", true, testflag);
			Reporter.addStepLog("<b>File '"+ filename + "' contains Attribute '" + attributename + "'! </b>");		
		}	
		
	}
	
	
	@When("^user verifies whether the \"([^\"]*)\" attribute: '(.+)' is available in file$")
    public void user_verifies_whether_the_something_attribute_is_available_in_file(String attributetype, String attributename) throws FileNotFoundException {
		
		
		for (File file : listOfFiles) {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line,linelist;
			try {
				while ((line = br.readLine()) != null) {
					if (line.contains(attributename)) {
						linelist = line;
						filename = file.getName();
						listofrecords.addAll(Arrays.asList(linelist));
						break;										
					} 
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
		
		if (listofrecords.size()>0)
			testflag = true;
		Assert.assertEquals("Attributes is not present in Full load file", true, testflag);
		Reporter.addStepLog("<b>File '"+ filename + "' contains Attribute '" + attributename + "'! </b>");
		
	}
	
	
	@Then("^\"([^\"]*)\" attribute should be available in file named \"([^\"]*)\"$")
    public void something_attribute_should_be_available_in_file_named_something(String attributetype, String filename) {
		
		Reporter.addStepLog("<b style='color:green'> All "+ attributetype + " attributes are available in " + filename+ " Fullload file !!! </b>" );
	}
	
	

}
