package qa.unicorn.ad.securitymaster.api.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;

@SuppressWarnings("deprecation")
public class GRSAttributesCheck {

	String outExlFilePath = "./target/cucumber-reports/Spark/";
	String inExlFilePath = "./src/test/resources/ad/securitymaster/api/excel/";
	String sheetName = "191- Attributes";
	String serviceURI = "https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Peter_Wmap/v1/Entity/";
	String serviceName = "FullTextSearch";
	Response response;
	Map<String, String> parametersMap = new HashMap<String, String>();

	SoftAssert sa = null;

	List<String> sameMSD_ID = new ArrayList<String>();

	@Given("^input (.+) is available at desired location$")
	public void input_is_available_at_desired_location(String filename) throws Throwable {
		inExlFilePath = inExlFilePath + filename;
		outExlFilePath = outExlFilePath + filename;
		File file;

		file = new File(inExlFilePath);

		if (!file.exists()) {
			Reporter.addStepLog("FILE NOT FOUND at: " + inExlFilePath);
			assertTrue(false, "FILE NOT FOUND!!");
		} else
			Reporter.addStepLog("<b>File found at </b>" + inExlFilePath);
	}

	@And("^User is connected to SM BaseURI$")
	public void user_is_connected_to_sm_baseuri() throws Throwable {
		RestApiUtils.requestSpecification = null;
		RestAssured.baseURI = null;
		RestAssured.basePath = "";

		RestApiUtils.setBaseURI(serviceURI + serviceName);

		RestApiUtils.requestSpecification = RestAssured.given();

		/* Logging in report */
		Reporter.addStepLog("Working on <b style=\"color:green\">" + serviceName + "</b>");
		Reporter.addStepLog("<b>Base URI:</b>" + serviceURI);

	}

	@When("^User takes paths data from that file and store MSD_ID from MSD & PRDB stream in file$")
	public void user_takes_paths_data_from_that_file_and_store_msdid_from_msd_prdb_stream_in_file() throws Throwable {
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, inExlFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);

		int totalRows = exlObj.getRowCount(sheet);
		int currentRow = 1;
		String path;

		/* Copying file from excel folder to target folder for reports */
		FileManager.copy(inExlFilePath, outExlFilePath);

		while (currentRow < totalRows) {

			path = exlObj.getStringCellData(sheet, currentRow, 0);

			SendGETRequest(path);

			String VENDOR_ID = response.body().jsonPath().getString("Values.VENDOR_ID[0]");
			String MSD_ID = response.body().jsonPath().getString("Values.MSD_ID[0]");

			System.out.println(VENDOR_ID);
			System.out.println(MSD_ID);

			GetMSDIDFromStreamAndStoreInFile("PRDB", VENDOR_ID, currentRow);

			GetMSDIDFromStreamAndStoreInFile("MSD", MSD_ID, currentRow);

			currentRow++;

		}
	}

	@And("^compare the MSD_ID from MSD stream and PRDB stream$")
	public void compare_the_msdid_from_msd_stream_and_prdb_stream() throws Throwable {

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, outExlFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int totalRows = exlObj.getRowCount(sheet);
		int currentRow = 1;

		String path = null, msdID_MSD_STREAM = null, msdID_PRDB_STREAM = null, Result = null;

		while (currentRow < totalRows) {
			path = exlObj.getStringCellData(sheet, currentRow, 0);
			msdID_MSD_STREAM = exlObj.getStringCellData(sheet, currentRow, 1);
			msdID_PRDB_STREAM = exlObj.getStringCellData(sheet, currentRow, 2);

			/* Checking for N/A */
			if (msdID_MSD_STREAM.equals("N/A") || msdID_PRDB_STREAM.equals("N/A")) {
				if (msdID_MSD_STREAM.equals("N/A")) {
					Result = "Security Not Found in MSD stream";
				}
				if (msdID_PRDB_STREAM.equals("N/A")) {
					Result = "Security Not Found in PRDB stream";
				}
				
				/* if both are N/A */
				if (msdID_MSD_STREAM.equals("N/A") && msdID_PRDB_STREAM.equals("N/A")) {
					Result = "Security Not Found in both PRDB & MSD streams";
				}
			}

			/* if both or anyone is not N/A, validating and storing in output file */
			else {
				if (msdID_MSD_STREAM.equals(msdID_PRDB_STREAM)) {

					sameMSD_ID.add(path);
					Result = "TRUE";

				} else
					Result = "FALSE";
			}

			exlObj.setCellData(sheet, currentRow, 3, Result);
			currentRow++;

		}
		Reporter.addStepLog(
				"<b>Report: </b><a href = \"191_GRS_Attributes.xlsx\" target=\"_blank\" > Click Here to View Detailed Report</a>");
		if (sameMSD_ID.size() > 0) {

			Reporter.addStepLog(
					"</br><b style=\"color:red\">Found Same MSD_ID in both streams for below paths: - </b>");
			Reporter.addStepLog(sameMSD_ID + "");

			Assert.assertTrue(false, "Found same MSD_ID in both streams.");
		}

	}

	public void SendGETRequest(String path) {
		parametersMap.put("query", path);

		// GET request
		RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Content-Type", "application/json");
		try {
			response = RestApiUtils.GETRequestwithFormParam(serviceURI + serviceName, parametersMap);
		} catch (Exception e) {
			Reporter.addStepLog("<b style=\"color:red\">Could not get any response from API.</b>");
			Assert.assertTrue(false, "Connection Error");
		}

		parametersMap.clear();
	}

	void GetMSDIDFromStreamAndStoreInFile(String stream, String id, int row) throws IOException {

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, outExlFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);

		String MSD_ID_STREAM = "";
		String uri = "https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Izhora/" + stream
				+ "/Web/Events?from=9183098&pageSize=1&externalId=" + id;

		Document doc = Jsoup.connect(uri).get();

		Elements MSD_ID_ELE = doc.getElementsByClass("table table-sm table-condensed table-striped");

		Iterator<Element> headers = MSD_ID_ELE.select("th").iterator();
		Iterator<Element> values = MSD_ID_ELE.select("td").iterator();

		/* Getting MSD_ID from respective stream */
		while (headers.hasNext() && values.hasNext()) {
			Element header = headers.next();

			if (header.text().equals("MSD_ID")) {
				System.out.println("MSD_ID_INDEX: " + header.elementSiblingIndex());
				MSD_ID_STREAM = doc
						.select("body > div > div.container-fluid > table > tbody > tr:nth-child(2) > td:nth-child("
								+ (header.elementSiblingIndex() + 1) + ")")
						.toString();
				break;
			}
		}

		MSD_ID_STREAM = MSD_ID_STREAM.replace("<td>", "");
		MSD_ID_STREAM = MSD_ID_STREAM.replace("</td>", "");

		/* Writing values in report file, if not found then "N/A" */

		switch (stream) {
		case "PRDB": {
			if (MSD_ID_STREAM.length() > 0) {
				exlObj.setCellData(sheet, row, 2, MSD_ID_STREAM);
			} else
				exlObj.setCellData(sheet, row, 2, "N/A");

		}

		case "MSD": {
			if (MSD_ID_STREAM.length() > 0) {
				exlObj.setCellData(sheet, row, 1, MSD_ID_STREAM);
			} else
				exlObj.setCellData(sheet, row, 1, "N/A");
		}

		default: {
			// Assert.assertTrue(false, "Something went wrong, please check
			// GetMSDIDFromStreamAndStoreInFile() function.");

		}
		}

	}

}
