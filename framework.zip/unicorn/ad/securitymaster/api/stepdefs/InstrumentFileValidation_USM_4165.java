package qa.unicorn.ad.securitymaster.api.stepdefs;

import static org.testng.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.Assert;

import com.google.common.hash.BloomFilter;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;

public class InstrumentFileValidation_USM_4165 {
	int status;
	String API_Response;
	JSONObject pwjson = new JSONObject();
	int BR_delte_recordCount = 0;
	int UBS_delte_recordCount = 0;
	String filepath = "D:\\Users\\GuptaVi\\Documents\\InstrumentDeltaFiles\\";
	String deltaFileBR;
	String deltaFileUBS;
	

	@Given("user has access to the both instrument delta files {string} and {string}")
	public void user_has_access_to_the_both_instrument_delta_files_and(String string1, String string2) {
		 deltaFileUBS=string1;
		 deltaFileBR=string2;
	}
		 
		 
	@When("user check the securityid {string} in BIMS-deltafile {string}")
	public void user_check_the_securityid_in_BIMS_deltafile(String msdId, String fileName) {		
	 String  line;
	 boolean flag = false;
	 String filepath = "D:\\Users\\GuptaVi\\Documents\\BIMS-Delta-files\\"+fileName;
		try (BufferedReader br = new BufferedReader(new FileReader(filepath))) {
			while ((line = br.readLine()) != null) {
				if (line.contains(msdId)) {
					flag = true;
					Reporter.addStepLog("<b>MSD_ID update: </b> ");
					Reporter.addStepLog("<b>"  + line+ "</b> ");
				}
			}
			
			if (!flag) {
				Assert.assertEquals(flag, true, "Security not found");
			}
			
			
			
		} catch (Exception e) {
			Assert.assertEquals(flag, true, e.getMessage());
			
		}
	

	}
	
	
//	int count = 0;
//	String  line;
//	int CUSIP = 0;
//	int ISIN  = 0;
//	int	SEDOL = 0;
//	int	SYMBOL  = 0;
//	int	VENDOR_ID  = 0;
//	int	MSD_ID = 0;
//	int CINS = 0;
//	System.out.println(filepath+deltaFileBR);
//	try (BufferedReader br = new BufferedReader(new FileReader(filepath+deltaFileBR))) {
//		
//		while ((line = br.readLine()) != null) {
////			count++;
////			if (line.contains("CUSIP")) {
////				CUSIP++;
////			}
////			if (line.contains("ISIN")) {
////				ISIN++;
////			}
////			if (line.contains("SEDOL")) {
////				SEDOL++;
////			}
////			if (line.contains("SYMBOL")) {
////				SYMBOL++;
////			}
////			if (line.contains("MSD_ID")) {
////				MSD_ID++;
////			}
////			if (line.contains("VENDOR_ID")) {
////				VENDOR_ID++;
////
////			}
//			if (line.contains("J002905")) {
//				
//				Reporter.addStepLog("<b>MSD_ID update: </b> " + line);
//			}
//
//			
//		}
//		
//	} catch (Exception e) {
//		System.out.println(filepath+deltaFileBR);
//	}
//	System.out.println(filepath+deltaFileBR);
//	BR_delte_recordCount=count;
//	System.out.println(filepath+deltaFileBR);
//	 Reporter.addStepLog("<b>BR-delta-file Record count: </b> " + BR_delte_recordCount);	
//	 Reporter.addStepLog("<b>CUSIP count: </b> " + CUSIP);
//	 Reporter.addStepLog("<b>ISIN count: </b> " + ISIN);
//	 Reporter.addStepLog("<b>SEDOL count: </b> " + SEDOL);
//	 Reporter.addStepLog("<b>SYMBOL count: </b> " + SYMBOL);
//	 Reporter.addStepLog("<b>MSD_ID count: </b> " + MSD_ID);

@Given("user check the record count of UBS-instrument-Delta-file")
public void user_check_the_record_count_of_UBS_instrument_Delta_file() {
	int count = 0;
	String  line;
	int CUSIP = 0;
	int ISIN  = 0;
	int	SEDOL = 0;
	int	SYMBOL  = 0;
	int	VENDOR_ID  = 0;
	int	MSD_ID = 0;
	int CINS = 0;
	
	
	try (BufferedReader br = new BufferedReader(new FileReader(filepath+deltaFileUBS))) {
		while ((line = br.readLine()) != null) {
			count++;
			if (line.contains("CUSIP")) {
				CUSIP++;
			}
			if (line.contains("ISIN")) {
				ISIN++;
			}
			if (line.contains("SEDOL")) {
				SEDOL++;
			}
			if (line.contains("SYMBOL")) {
				SYMBOL++;
			}
			if (line.contains("MSD_ID")) {
				MSD_ID++;
			}
			if (line.contains("VENDOR_ID")) {
				VENDOR_ID++;

			}
			if (line.contains("CINS")) {

			}

		}
		
	} catch (Exception e) {
		
	}
	UBS_delte_recordCount = count;
	 Reporter.addStepLog("<b>UBS-delta-file Record count: </b> " + count);
	 
	 Reporter.addStepLog("<b>CUSIP count: </b> " + CUSIP);
	 Reporter.addStepLog("<b>ISIN count: </b> " + ISIN);
	 Reporter.addStepLog("<b>SEDOL count: </b> " + SEDOL);
	 Reporter.addStepLog("<b>SYMBOL count: </b> " + SYMBOL);
	 Reporter.addStepLog("<b>MSD_ID count: </b> " + MSD_ID);
			
}

@Given("user check both record count should be matched")
public void user_check_both_record_count_should_be_matched() {
	assertEquals(UBS_delte_recordCount, BR_delte_recordCount,"Both count not matched");
}

@SuppressWarnings("unchecked")
@Given("user validate each record of UBS-delta-file with BIMS CustomProjection API should match.")
public void user_validate_each_record_of_UBS_delta_file_with_BIMS_CustomProjection_API_should_match() throws ParseException, FileNotFoundException, IOException {
	String  line;
	String pwSecurityId = null;
	int count = 0;
	try (BufferedReader br = new BufferedReader(new FileReader("D:\\Users\\GuptaVi\\Documents\\testAPI.json"))) {
		while ((line = br.readLine()) != null) {
			count++;
			Reporter.addStepLog("<b>Record: </b><br> " + line);
			
			String pwsecuritypath = "$.CustomFields.clientDefined.backbridge[0].pwSecurityIdentifier";

			try {
				pwSecurityId = com.jayway.jsonpath.JsonPath.read(line, pwsecuritypath);
				pwjson.put("pwSecurityIdentifier", pwSecurityId); 
				String jsonbody = pwjson.toJSONString();
				pwjson.remove("pwSecurityIdentifier");
				
			    RestAssured.baseURI="https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Peter_Wmap";
			    RestAssured.basePath="/v1/Entity/Find";
			    RequestSpecification request2 = RestAssured.given();
			    request2.header("Content-Type","application/json");
			    request2.body(jsonbody);
			    Response response2 = request2.post();
			    String getEntity_API_response = response2.body().asString();
				String msdidPath = "$.[0].EntityId";
				String msdid = null;
				
				try {
					msdid = com.jayway.jsonpath.JsonPath.read(getEntity_API_response, msdidPath);
					String jsondata = FileManager.getFileManagerObj().readFile("D:\\Users\\GuptaVi\\Documents\\BIMS.SecMaster.Instrument.DeltaExtract.UBS.20210506");
				    RestAssured.baseURI="https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Peter_Wmap";
				    RestAssured.basePath="/v1/Entity/GetCustomProjectionBatch";
				    RequestSpecification request = RestAssured.given();
				    request.queryParam("id", msdid);
				    request.header("Content-Type","application/json");
				    request.body(jsondata);
				    Response response = request.post();
				    String customBatchAPI_response = response.body().asString();
				    customBatchAPI_response =  customBatchAPI_response.substring( 1, customBatchAPI_response.length() - 1 ) ;
				    
				    Reporter.addStepLog("<b>Security ID : </b> " + msdid);
					Reporter.addStepLog("<b>status: </b> " + response.getStatusCode());
					Reporter.addStepLog("<b>getCustomProjectionBatch API Response: </b><br>" +customBatchAPI_response);
					
					
					try {
						JSONAssert.assertEquals(customBatchAPI_response, line, JSONCompareMode.STRICT);
						Reporter.addStepLog("<b>Results : </b> " + "<b style='color:green'> Matched </b>");	
					} catch (AssertionError ae) {
						 Reporter.addStepLog("<b>Results : </b> " +"<b style='color:red'> Not Matched </b>");		 

					}
					
					
				} catch (Exception e) {
					e.getMessage();
				
				}
				
				
			} catch (Exception e) {
				
			}
		}
	}
	
}




}
