package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import io.cucumber.java.en.Given;
import qa.framework.utils.Reporter;

public class UBS_Instrument_Delta_File_Validation {
	String filePath = "./src/test/resources/ad/securitymaster/api/responsejson/BIMS.SecMaster.Instrument.DeltaExtract.20210915";

	@Given("user varify the record of the delta file")
	public void user_varify_the_record_of_the_delta_file() {
		Reporter.addStepLog("BIMS.SecMaster.Instrument.DeltaExtract.");
	}

	
	
	@Given("UBS instrument Delta file {string}")
	public void ubs_instrument_Delta_file(String string) {
		String line;
		int count = 0;
		int msdIdCount = 0;
		int VendorIdCount = 0;
		int cusipCount = 0;
		int isinCount = 0;
		int sedolCount = 0;
		int secICount = 0;
		int KEYERROR = 0;

		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			while ((line = br.readLine()) != null ) {
				

				if(msdIdCount<50)
				{
					Reporter.addStepLog(line);
				}
				if (line.contains("MSD_ID")) {
					msdIdCount++;
				}
				if (line.contains("VENDOR_ID")) {
					VendorIdCount++;
				}
				if (line.contains("CUSIP")) {
					cusipCount++;
				}
				if (line.contains("ISIN")) {
					isinCount++;
				}
				if (line.contains("SEDOL")) {
					sedolCount++;
				}
				if (line.contains("pwSecurityIdentifier")) {
					secICount++;
				}
				
				if (line.contains("Not found") ) {
					KEYERROR++;
				}
				

				
				count++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Reporter.addStepLog("Total Record count \t"+count);
		Reporter.addStepLog("MSD_ID    	Count  \t"+msdIdCount);
		Reporter.addStepLog("VENDOR_ID 	Count  \t"+VendorIdCount);
		Reporter.addStepLog("CUSIP     	Count \t"+cusipCount);
		Reporter.addStepLog("ISIN      	Count  \t"+isinCount);
		Reporter.addStepLog("SEDOL     	Count  \t"+sedolCount);
		Reporter.addStepLog("pwSecurityIdentifier Count  \t"+secICount);
		Reporter.addStepLog("KEYERROR Count  \t"+KEYERROR);
		
		

	}
	
	
	
	static String convertYamlToJson(String yaml) throws JsonParseException, JsonMappingException, IOException {
	    ObjectMapper yamlReader = new ObjectMapper(new YAMLFactory());
	    Object obj = yamlReader.readValue(yaml, Object.class);

	    ObjectMapper jsonWriter = new ObjectMapper();
	    return jsonWriter.writeValueAsString(obj);
	}

	
	

		
	
}
