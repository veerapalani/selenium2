package qa.unicorn.ad.securitymaster.api.stepdefs;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;

public class BillingSymbolUSM2465 {
	Response postresponse,getresponse;
	String postresponseBody,getresponseBody;
	String msdid;
	String billingsymbol;
	int poststatus,getstatus;
	JsonPath jsonPostresponse,jsonGetresponse;
	String env = SQLDriver.getEnvironment();

	@Given("^user connects to Base Swagger URL to make a POST request$")
	public void user_connects_to_base_swagger_url_to_make_a_post_request() {
		
		String baseUri = Action.getTestData("Entity-BaseURI");
		RestApiUtils.setBaseURI(baseUri);		
		String basePath = Action.getTestData("FindEntity-BasePath");
		RestApiUtils.setBasePath(basePath);
					
		Reporter.addStepLog("<b>Base URI is set as: </b>" + baseUri);
		Reporter.addStepLog("<b>Base path is set as: </b>" + basePath);
	}
	
	
	@When("^user sends (.+) to execute POST request$")
    public void user_sends_to_execute_post_request(String requestjson) {
		
		RestApiUtils.requestSpecification = RestAssured.given();
		RestApiUtils.requestSpecification.contentType("application/json");
		RestApiUtils.requestSpecification.body(requestjson);
		postresponse = RestApiUtils.requestSpecification.post();
		
		poststatus = postresponse.getStatusCode();
		postresponseBody = postresponse.getBody().asString();
		jsonPostresponse = new JsonPath(postresponseBody);

		Reporter.addStepLog("<b>Request JSON: </b> " + requestjson);
		Reporter.addStepLog("<b>HTTP Method Executed: </b>Post");		
	}
	
	@Then("^user verifies the reponse code is '200' for POST request$")
    public void user_verifies_the_reponse_code_is_200_for_post_request() {
		
		Assert.assertEquals(poststatus, 200, "Incorrect Response code");
		Reporter.addStepLog("<b>Status Code:</b>"+poststatus);
//		Reporter.addStepLog("<b>Response: </b>"+postresponseBody);	
		 
	}
	
	 @And("^user extracts MSD_ID from response$")
	 public void user_extracts_msdid_from_response() {
		 
		 msdid= jsonPostresponse.getString("EntityId");
		 msdid= msdid.substring(1, 8);
		 Reporter.addStepLog("<b>MSD_ID: </b>"+msdid);
	 }
	 
	 @Given("^User connects to Base Swagger URL to make a GET request$")
	 public void user_connects_to_base_swagger_url_to_make_a_get_request() {
		 
		 String baseUri = Action.getTestData("Entity-BaseURI");
		 RestApiUtils.setBaseURI(baseUri);
		 String basePath = Action.getTestData("GetSnappshot-BasePath");
		 RestApiUtils.setBasePath(basePath);
		 RestApiUtils.requestSpecification = RestAssured.given();

		 Reporter.addStepLog("<b>Base URI is set as: </b>" + baseUri);
		 Reporter.addStepLog("<b>Base path is set as: </b>" + basePath);
		 
	 }
	 
	 
	 @When("^user makes a GET resquest using the extracted MSD_ID$")
	 public void user_makes_a_get_resquest_using_the_extracted_msdid() {
		 
		 RestApiUtils.requestSpecification.pathParam("externalId", msdid);
		 getresponse = RestApiUtils.requestSpecification.get();
		 getstatus = getresponse.getStatusCode();
		 getresponseBody = getresponse.getBody().asString();
		 jsonGetresponse = new JsonPath(getresponseBody);
		 	
		 Reporter.addStepLog("<b>Parameter Type: </b>Path");
		 Reporter.addStepLog("<b>Parameter Name: </b>externalId");
		 Reporter.addStepLog("<b>Parameter Value: </b>"+msdid);
		 Reporter.addStepLog("<b>HTTP Method Executed: </b>Get"); 		 
	 }
	 
	 @Then("^user verifies the reponse code is '200' for GET request$")
	 public void user_verifies_the_reponse_code_is_200_for_get_request() {
		 
		 Assert.assertEquals(getstatus, 200, "Incorrect Response code");
		 Reporter.addStepLog("<b>Status Code: </b>"+getstatus);
//		 Reporter.addStepLog("<b>GET Request Response:</b>"+getresponseBody);
					
	 }
	 
	 @And("^user verifies if 'Billing Symbol' field is availble in API$")
	 public void user_verifies_if_billing_symbol_field_is_availble_in_api() {
		 
		 String billingsymbolpath = "CustomFields.clientDefined.backbridge";
		 billingsymbol = jsonGetresponse.getString(billingsymbolpath+"[0].billingSymbol");
		 
		 Assert.assertNotNull(billingsymbol, "Billing Symbol is not available");
		 Reporter.addStepLog("<b>Billing Symbol EISL Mapping: </b>"+billingsymbolpath);
		 Reporter.addStepLog("<b>Billing Symbol Value: </b>"+billingsymbol);
		 Reporter.addStepLog("<b style='color:green'> Billing Symbol field is available in API!! </b>");		 
	 }

}
