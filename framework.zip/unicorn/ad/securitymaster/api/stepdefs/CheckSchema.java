package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class CheckSchema {
	public static String firstAPIresponse;
	public static String msdid;
	public static RetriveResponse response;
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Date dateobj = new Date();

	
	@Then("user verify the count of attribute {string} in FTS searchCount API.")
	public void user_verify_the_count_of_attribute_in_FTS_searchCount_API(String qValue) {
		HttpClientUtils.baseUri = "https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Peter_Wmap";
		HttpClientUtils.basePath = "/v1/Entity/FullTextSearchCount";

		response = HttpClientUtils.given().buildUri().setQueryParameter("query", qValue)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		firstAPIresponse = response.getBody().asString();
		Reporter.addStepLog("Count :" + "<strong>" + firstAPIresponse + "</strong>");
		String path = "./src/test/resources/ad/securitymaster/api/responsejson/PRU-passed.log";
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Date dateobj = new Date();
			FileWriter writer = new FileWriter(path, true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(df.format(dateobj) + "\t count \t" +firstAPIresponse +fixedLengthString(qValue, 50));
			bufferedWriter.newLine();
			bufferedWriter.close();
		} catch (IOException ee) {
			
			ee.printStackTrace();
		}
	
	}
	

	public static String fixedLengthString(String string, int length) {
		return String.format("%1$" + length + "s", string);
	}

	@Given("user has access to BIMS QA URL")
	public void user_has_access_to_BIMS_QA_URL() {
	}

	@Given("user has acess to BIMS Schema API Base URL {string} and Base path {string}")
	public void user_has_acess_to_BIMS_Schema_API_Base_URL_and_Base_path(String baseURI, String basePATH) {
		HttpClientUtils.baseUri = baseURI;
		HttpClientUtils.basePath = basePATH;
		Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
		Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");
	}

	@Given("user make get rquest call to BIMS Schema API")
	public void user_make_get_rquest_call_to_BIMS_Schema_API() {

		response = HttpClientUtils.given().buildUri()
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		firstAPIresponse = response.getBody().asString();
		String path = "./src/test/resources/ad/securitymaster/api/responsejson/passed.log";
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Date dateobj = new Date();
			FileWriter writer = new FileWriter(path, true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(df.format(dateobj) + "\t" + "Count \t"+firstAPIresponse);
			bufferedWriter.newLine();
			bufferedWriter.close();
		} catch (IOException ee) {
			
			ee.printStackTrace();
		}

	}

	@When("user should receive {int} response code.")
	public void user_should_receive_response_code(Integer int1) {
	}

	
	@Then("user verify that {string} is removed from schema using {string}.")
	public void user_verify_that_is_removed_from_schema_using(String attribute, String GRSMapping) {
		boolean attributeFound = true;
		String attributeName = null;
		Object attributeValue = null;
		String GRSpath = "$." + GRSMapping;

		try {
			Object item = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, GRSpath);

			if (item instanceof net.minidev.json.JSONArray) {
				String GRSpath2 = GRSpath + "[*]";
				List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, GRSpath2);
				for (Map<String, String> map : result) {
					for (Map.Entry<String, String> entry : map.entrySet()) {
						attributeName = entry.getKey();
						if (attributeName.equals(attribute)) {
							attributeFound = true;
							attributeValue = entry.getValue();
							break;
						}
					}
					if (attributeFound == true) {
						break;
					}
				}

			} else if (item instanceof LinkedHashMap) {
				LinkedHashMap<String, Object> map = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, GRSpath);
				if (map.containsKey(attribute)) {
					attributeFound = true;
					attributeValue = map.get(attribute);
				}

			} else {
				attributeValue = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, GRSpath);
				if (attributeValue != null) {
					attributeFound = true;
				}
			}
			if (attributeFound) {
				Reporter.addStepLog("<b> Status :" +GRSMapping+ "\t Attribute Not Removed from Schema \t " + "</b>"+ attributeValue);
				String path2 = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
				try {

					DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
					Date dateobj = new Date();
					FileWriter writer = new FileWriter(path2, true);
					BufferedWriter bufferedWriter = new BufferedWriter(writer);
					bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attribute, 50)
							+ "\t Found in Schema Hence Test failed");
					bufferedWriter.newLine();
					bufferedWriter.close();
				} catch (IOException ee) {
					ee.printStackTrace();
				}

			} else {
				
				attributeFound = false;
				String path = "./src/test/resources/ad/securitymaster/api/responsejson/passed.log";
				Reporter.addStepLog("<b>" +"Attribute name: " +GRSMapping  + "</b>" + "<b> Status :" + "Removed from Schema" + "</b>");
				try {
					DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
					Date dateobj = new Date();
					FileWriter writer = new FileWriter(path, true);
					BufferedWriter bufferedWriter = new BufferedWriter(writer);
					bufferedWriter.write(df.format(dateobj) + "\t" + fixedLengthString(attribute, 50) + "\t Not Found in Schema, Hence Test passed");
					bufferedWriter.newLine();
					bufferedWriter.close();
				} catch (IOException ee) {
					
					ee.printStackTrace();
				}
			}

		} catch (Exception e) {
			attributeFound = false;
			String path = "./src/test/resources/ad/securitymaster/api/responsejson/passed.log";
			Reporter.addStepLog("Attribute name: "+ "<b>" +GRSMapping  + "</b>" + " , Status :" +  "<b> Removed from Schema </b>");
			try {
				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
				Date dateobj = new Date();
				FileWriter writer = new FileWriter(path, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);
				bufferedWriter.write(df.format(dateobj) + "\t" + fixedLengthString(attribute, 50) + "\t Not Found in Schema, Hence Test passed");
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				
				ee.printStackTrace();
			}
		}

		Assert.assertEquals(attributeFound, false, "Attribute found an not removed from Schema");

	}

	@Then("user verify the data type of {string} and its GRS mapping as  {string} is {string}.")
	public void user_verify_the_data_type_of_and_its_GRS_mapping_as_is(String attribute, String GRSMapping,String datatype) {
		String attributeName = null;
		Object attributeValue = null;
		String GRSpath = "$." + GRSMapping;

		try {
			Object item = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, GRSpath);
			if (item instanceof net.minidev.json.JSONArray) {
				String GRSpath2 = GRSpath + "[*]";
				List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, GRSpath2);
				for (Map<String, String> map : result) {
					for (Map.Entry<String, String> entry : map.entrySet()) {
						attributeName = entry.getKey();
						if (attributeName.equals(attribute)) {
							attributeValue = entry.getValue();
							break;
						}
					}
				}

			} else if (item instanceof LinkedHashMap) {
				LinkedHashMap<String, Object> map = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, GRSpath);
				attributeValue = map.get("dataType");
				
				for (Entry<String, Object> entry : map.entrySet()) {
					attributeName = entry.getKey();
					if (attributeName.contains("dataType")) {
						attributeValue = entry.getValue();
						break;
					}
				}
				
			}
			else {
				// It's something else, like a string or number
				attributeValue = item;
				}
		} 
			catch (Exception e) {
			e.printStackTrace();
		}

		Reporter.addStepLog("datatype :" + "<strong>" + attributeValue + "</strong>");
		//Assert.assertEquals(attributeValue, datatype, "Data type not matched");
		
		String path = "./src/test/resources/ad/securitymaster/api/responsejson/passed.log";
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Date dateobj = new Date();
			FileWriter writer = new FileWriter(path, true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(df.format(dateobj) + "\t" + fixedLengthString(GRSMapping, 90) + "\t "+fixedLengthString(attributeValue.toString(), 90));
			bufferedWriter.newLine();
			bufferedWriter.close();
		} catch (IOException ee) {
			
			ee.printStackTrace();
		}
		

	

	}
	
}
