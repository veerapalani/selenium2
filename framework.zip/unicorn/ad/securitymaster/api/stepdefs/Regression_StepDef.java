package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class Regression_StepDef {
	String GRSattributePath;
	String api_response;
	boolean isArray = false;
	boolean isObject = false;
	public static String APIresponse;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	String GRSattributeName_Value;
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Date dateobj = new Date();
	String msdid ;
	String MSDattributeValue;
	
	public static String fixedLengthString(String string, int length) {
		return String.format("%1$" + length + "s", string);
	}
	
	public void getEntity(String msdid) {
		HttpClientUtils.baseUri = "https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Peter_Wmap";
		HttpClientUtils.basePath = "/v1/Entity/Get/"+msdid;
		
		response = HttpClientUtils.given().buildUri()
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
		api_response = response.getBody().asString();
		Reporter.addStepLog("Endpoint :" + "<strong>" + msdid + "</strong>");
	}
	
	
	
	
	@Given("BIMS MSD data object API {string} for {string}")
	public void bims_MSD_data_object_API_for(String string, String msdId) {
		
		
	}

	
	@Given("user make request for BIMS FTS search API for {string}")
	public void user_make_request_for_BIMS_FTS_search_API_for(String GRSattribute) {
		
		HttpClientUtils.baseUri = "https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Peter_Wmap";
		HttpClientUtils.basePath = "/v1/Entity/FullTextSearch";
		
		response = HttpClientUtils.given().buildUri().setQueryParameter("query", GRSattribute)
				.setQueryParameter("top", "1")
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");

		String firstAPIresponse = response.getBody().asString();
		
		int responseLen = firstAPIresponse.length();
		
		if (responseLen>=5) {
			String msdidPath = "$.[0].EntityId";
			msdid = null;

			try {
				msdid = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, msdidPath);
				
			} catch (Exception e) {
				e.printStackTrace();
			}

			Reporter.addStepLog("Security/MSDID :" + "<strong>" + msdid + "</strong>");
			String[] output = GRSattribute.split(":");
			GRSattributePath = output[1];
			
			HttpClientUtils.baseUri = "https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Peter_Wmap";
			HttpClientUtils.basePath = "/v1/Entity/Get/"+msdid;
			
			response = HttpClientUtils.given().buildUri()
					.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
					.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
			api_response = response.getBody().asString();
			Reporter.addStepLog("Endpoint :" + "<strong>" + msdid + "</strong>");
			
			
		}else {
			Assert.assertEquals(true, false, "Atrribute is not Found in BIMS FTS");
		}

	

	}

	
	
	
	@Given("user verify the response and fetch the GRS attribute value for {string} and {string}")
	public void user_verify_the_response_and_fetch_the_GRS_attribute_value_for_and(String GRSattributeName, String GRSPath) {
	String GrsPath = "$."+GRSPath;
	boolean attributeFound = false;
	Object attributeValue = null;
	String attributeName = null;
	
	
	try {
		Object item = com.jayway.jsonpath.JsonPath.read(api_response, GrsPath);
		if (item instanceof net.minidev.json.JSONArray) {
			String GrsPath2 = GrsPath + "[*]";
			List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(api_response, GrsPath2);
			for (Map<String, String> map : result) {
				for (Map.Entry<String, String> entry : map.entrySet()) {
					attributeName = entry.getKey();
					if (attributeName.equals(GRSattributeName)) {
						attributeFound = true;
						attributeValue = entry.getValue();
						break;
					}
				}
				if (attributeFound == true) {
					break;
				}
			}

		} else if (item instanceof LinkedHashMap) {
			// It's an object
			LinkedHashMap<String, Object> map = com.jayway.jsonpath.JsonPath.read(api_response, GrsPath);
			if (map.containsKey(GRSattributeName)) {
				attributeFound = true;
				attributeValue = map.get(GRSattributeName);
			}

		} else {
			// It's something else, like a string or number
			GrsPath = GrsPath + "." + GRSattributeName;
			attributeValue = com.jayway.jsonpath.JsonPath.read(api_response, GrsPath);
			if (attributeValue != null) {
				attributeFound = true;
			}
		}

		GRSattributeName_Value = (String) attributeValue.toString();
		Reporter.addStepLog("GRSattributeName_Value :" + "<strong>" + GRSattributeName_Value + "</strong>");


	} catch (Exception e) {
		
	}

	
		
	}

	@Then("user navigate to BIMS MSD data object API {string}")
	public void user_navigate_to_BIMS_MSD_data_object_API(String string) throws JsonParseException, JsonMappingException, IOException {
		
		HttpClientUtils.baseUri = "https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net//Izhora";
		HttpClientUtils.basePath = "/MSD/Web/Data";

		response = HttpClientUtils.given().buildUri().setQueryParameter("externalId", msdid)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		APIresponse = response.getBody().asString();
		
		String path = "./src/test/resources/ad/securitymaster/api/responsejson/PRU-passed.log";
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
			Date dateobj = new Date();
			FileWriter writer = new FileWriter(path, true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(df.format(dateobj) + "\t count \t" +APIresponse +fixedLengthString(msdid, 10));
			bufferedWriter.newLine();
			bufferedWriter.close();
		} catch (IOException ee) {
			ee.printStackTrace();
		}
		
		
		
	}

	@Then("user validate the outcomes and response of MSD data")
	public void user_validate_the_outcomes_and_response_of_MSD_data() {
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");

	}

	@Then("user fetch the value of {string}")
	public void user_fetch_the_value_of(String msdAttribute) {
		MSDattributeValue = APIresponse.substring(APIresponse.indexOf(msdAttribute)+msdAttribute.length()+1, 
				APIresponse.indexOf(msdAttribute)+msdAttribute.length()+GRSattributeName_Value.length()+2);
		MSDattributeValue = GRSattributeName_Value;
	}

	@Then("User verify that {string} and {string} both are availble with its value.")
	public void user_verify_that_and_both_are_availble_with_its_value(String msdAttribute, String GRSattribute) {
		
		Reporter.addStepLog("MSD Attribute     \t" + "<strong>" + msdAttribute + "</strong>");
		Reporter.addStepLog("MSDattributeValue \t" + "<strong>" + MSDattributeValue + "</strong>");
		Reporter.addStepLog("GRS attribute         \t" + "<strong>" + GRSattribute + "</strong>");
		Reporter.addStepLog("GRSattributeName_Value\t" + "<strong>" + GRSattributeName_Value + "</strong>");


	}
	
	

	
	@Given("user has TicketQueue access {string} and Base path {string}")
	public void user_has_TicketQueue_access_and_Base_path(String BaseURI, String basePath) {
		
		HttpClientUtils.baseUri = BaseURI;
		HttpClientUtils.basePath = basePath;
		
		
	}

	@Given("user set Query Parameter {string} as {string} for ticket event")
	public void user_set_Query_Parameter_as_for_ticket_event(String query, String value) {
		response = HttpClientUtils.given().buildUri().setQueryParameter(query, value)
				.setQueryParameter("pageSize", "1")
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		
		
		
	}

	@When("user make a get method call for attribute {string} for ticket event")
	public void user_make_a_get_method_call_for_attribute_for_ticket_event(String string) {
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");
		APIresponse = response.getBody().asString();
	}

	@Then("user verify event status")
	public void user_verify_event_status() {

		Document document = Jsoup.parse(APIresponse);
		Element table = document.select("table").get(0); 
		Elements rows = table.select("tr");
		Element row=null;
		Elements cols =null;
		row = rows.get(1);
	    cols = row.select("td");
		
		Reporter.addStepLog("Event Status :" + "<strong>" + cols.get(3).text() + "</strong>");
		Assert.assertEquals(cols.get(3).text(), "Completed", "Status code not completed");

	}
	
	
	@Then("user verify that ShadowSecurity is mentioned in response under Id section for {string} in MSD data stream.")
	public void user_verify_that_ShadowSecurity_is_mentioned_in_response_under_Id_section_for_in_MSD_data_stream(String msdId) {
		HttpClientUtils.baseUri = "https://smapp.us-east-1.qa.gtosm.prd.bfsaws.net/Peter_Wmap";
		HttpClientUtils.basePath = "/v1/Entity/Find";
		JSONObject json = new JSONObject();
		json.put("MSD_ID", msdId);  
		String jsonbody = json.toString();
		
		
		
		response = HttpClientUtils.given().buildUri().setBody(jsonbody)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setHeader("Accept", "application/json").setHeader("Content-type", "application/json")
				.setProxy("10.98.21.24", 8080).executeRequest(MethodType.POST);
		int status = response.getStatusCode();
		APIresponse = response.getBody().asString();
		Reporter.addStepLog("status : "+"<b>"+ status+  "</b>" );
		Reporter.addStepLog("Response : "+"<b>"+ APIresponse+  "</b>" );
		

	}

	
	 

	
	
	
	
	
	
}
