package qa.unicorn.ad.securitymaster.api.stepdefs;


import java.io.File;

import org.apache.commons.io.FileUtils;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.Reporter;

public class ValidateDeltaFilesStepDef {
	
	String filePath = "./src/test/resources/ad/securitymaster/api/deltaFiles/";

@Given("user has Deltafiles that was genrated by BIMS on three consecutive days")
public void user_has_Deltafiles_that_was_genrated_by_BIMS_on_three_consecutive_days() {
    // Write code here that turns the phrase above into concrete actions
}

@Then("^user compare \"([^\"]*)\" with \"([^\"]*)\" and get delta record$")
public void user_compare_something_with_something_and_get_delta_record(String deltafile1, String deltafile2) throws Throwable {
	try {
		
		Reporter.addStepLog("Previous Deltafile : "+"<b>"+ deltafile1 +  "</b>" );
		Reporter.addStepLog("Current Deltafile : "+"<b>"+ deltafile2 +  "</b>" );
		

	String deltafilePrev = filePath+deltafile1;
	String deltafileCurr = filePath+deltafile2;
	

	String expectedJson = FileUtils.readFileToString(new File(deltafilePrev));
	String actualJson = FileUtils.readFileToString(new File(deltafileCurr));

	/*
	 * comparing two json 
	 * JSONCompareMode.STRICT:
	
	JSONAssert.assertEquals("Expected Json: " +"\n\t\n"+ expectedJson + "\n\n Actual Json: " + "\n\n"+actualJson, expectedJson,
			actualJson, JSONCompareMode.STRICT);
	 */
	
	
	
	try {
		JSONAssert.assertEquals( expectedJson,actualJson, JSONCompareMode.STRICT);
		
	} catch (AssertionError ae) {
		Reporter.addStepLog(" DATA mismatch found at following location  : JSON Attribute at Location ---ExpectedValue and Actual value ");
		
		String errorMessage = ae.getMessage();
		
		String[] errorMessages = errorMessage.split(";");
		
		
		for (String errMsg : errorMessages) {
			Reporter.addStepLog("<b>"+ errMsg +  "</b>" );
			
		}
		
	   
	}
	
	

} catch (Exception e) {
	ExceptionHandler.handleException(e);
}


}




}
