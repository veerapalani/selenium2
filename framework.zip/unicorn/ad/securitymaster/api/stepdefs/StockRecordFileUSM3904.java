package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import qa.framework.utils.Reporter;

public class StockRecordFileUSM3904 {
	String filePath, adpid;
	static File[] listOfFiles;
	List<String> adplist = new ArrayList<String>();
	
	@Given("^user has access to Stock record file named \"([^\"]*)\"$")
    public void user_has_access_to_stock_record_file_named_something(String filename) {
		
		String folderpath = "D:\\Users\\KhandareM\\BIMS_FullLoad\\out";
		File folder = new File(folderpath);
		listOfFiles = folder.listFiles();
		
		Reporter.addStepLog("<b> User is able to access to Stock record file named: "+ filename + "</b>" );
			
	}
	
	@When("^user verifies records having Type 1 as Held Securities$")
    public void user_verifies_records_having_type_1_as_held_securities() throws FileNotFoundException {
		
		int count=0;
		
		for (File file : listOfFiles) {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;
			try {
				while ((line = br.readLine()) != null) {
					String type = line.substring(58, 59);
					if (type.contentEquals("1")) {
						adpid = line.substring(60, 67);
						adplist.add(adpid);
						count++;						
					} 
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}	
			
		}
		
		Reporter.addStepLog("Total Held securities available in this file are: <b>" + count++ + "</b>");
		
	}
	
	
	@Then("^user saves the list of Held Securities$")
    public void user_saves_the_list_of_held_securities() {
		
		String path = "D:\\Users\\KhandareM\\Broadridge\\Security Master\\MCR 6\\Sprint 43\\USM-3904\\Output0326.log" ;
		
		BufferedWriter wr = null;
        try {     
        
            wr = new BufferedWriter(new FileWriter(path));
            for (String var : adplist) {
            	wr.write(var);
                wr.newLine();
            }
            wr.close();
		
        } catch (IOException ee) {
            ee.printStackTrace();
        }
        
        Reporter.addStepLog("<b style='color:green'> All Held Securities are stored in file 'Output0326.log' !! </b>" );		
	}
	
	
	
//	##################################################################################################
	
	@Given("^user has access to \"([^\"]*)\" file named \"([^\"]*)\" and its splitted part (.+)$")
    public void user_has_access_to_stock_file_named_something_and_its_splitted_part(String stock, String Stockname, String filepartname) {
		
		filePath = "D:\\Users\\KhandareM\\BIMS_FullLoad\\out\\"+filepartname;
		Reporter.addStepLog("<b>Reading part '"+filepartname+"'  of Stock record file '" + Stockname + "'</b>");
		
	}
	
	@When("^user extracts records having Type 1 as Held Securities$")
    public void user_extracts_records_having_type_1_as_held_securities() throws FileNotFoundException {
		
		int count=0;
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line;
		try {
			while ((line = br.readLine()) != null) {
				String type = line.substring(58, 59);
				if (type.contentEquals("1")) {
					adpid = line.substring(60, 67);
					adplist.add(adpid);
					count++;
					
				} 
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
		Reporter.addStepLog("Total Held securities available in this file part are: <b>" + count++ + "</b>");
	}

	
	@Then("^user validates the list of Held Securities from file (.+)$")
    public void user_validates_the_list_of_held_securities_from_file(String filename) {
		
		String path = "D:\\Users\\KhandareM\\Broadridge\\Security Master\\MCR 6\\Sprint 43\\USM-3904\\" + filename+".log" ;
		
		BufferedWriter wr = null;
        try {
        	
//        	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
//			Date dateobj = new Date();
        
            wr = new BufferedWriter(new FileWriter(path));
            for (String var : adplist) {
//                wr.write(df.format(dateobj)+"\t"  + "Held Securties are: "+var);
            	wr.write(var);
                wr.newLine();
            }
            wr.close();
		
        } catch (IOException ee) {
            ee.printStackTrace();
        }
        
        Reporter.addStepLog("<b style='color:green'> All Held Securities are stored in file "+ filename + ".log !! </b>" );
		
	}
	
}
	
	
	


