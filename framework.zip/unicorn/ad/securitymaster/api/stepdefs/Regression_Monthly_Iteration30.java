package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regression_Monthly_Iteration30 {
	public static String searchString = "don’t be evil.being evil is bad";
	  public static List<IndexWrapper> findIndexesForKeyword(String keyword) {
	        String regex = "\\b"+keyword+"\\b";
	        Pattern pattern = Pattern.compile(regex);
	        Matcher matcher = pattern.matcher(searchString);
	 
	        List<IndexWrapper> wrappers = new ArrayList<IndexWrapper>();
	 
	        while(matcher.find() == true){
	            int end = matcher.end();
	            int start = matcher.start();
	            IndexWrapper wrapper = new IndexWrapper(start, end);
	            wrappers.add(wrapper);
	        }
	        return wrappers;
		
	}
	  
	  public static void main(String[] args) {
	        List<IndexWrapper> indexes = findIndexesForKeyword("be");
	        System.out.println("Indexes found "+indexes.size() +" keyword found at index : "+indexes.get(0).getStart());
	   
	  }
}
	

	