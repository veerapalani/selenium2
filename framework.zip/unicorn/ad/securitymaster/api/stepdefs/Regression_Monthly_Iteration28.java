package qa.unicorn.ad.securitymaster.api.stepdefs;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class Regression_Monthly_Iteration28 {
	public static RetriveResponse response;
	public static RequestBuilder requestBuilder;
	public String BIMS_API_response;
	public int statuscode;
	public static String MSD_Id;
	boolean PRDBdataSource;
	boolean attributeFound;
	public static String prdbAttributeValue;
	public static String msdAttributeValue;
	public static String GRSAttributeValue;
	String valueOfED_EFF_D= null;
	Date dateobj = new Date();

	@Given("user create open BIMS PRDB Event for Base URI {string} BasePath  {string} for {string}")
	public void user_create_open_BIMS_PRDB_Event_for_Base_URI_BasePath_for(String baseURI, String basePATH,
			String vendorId) throws IOException {

		HttpClientUtils.baseUri = baseURI;
		HttpClientUtils.basePath = basePATH;
		Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
		Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");

		RetriveResponse response = BIMS_API_CALL.getResponse("externalId", vendorId);
		BIMS_API_response = BIMS_API_CALL.getResponseBody(response);
		BIMS_API_CALL.getStatusCode(response);

	}

	@Then("user checks value for {string} for {string}")
	public void user_checks_value_for_for(String prdbAttributes, String vendorID) {
		List<String> attributes = Arrays.asList(prdbAttributes.split(","));
		for (String attribute : attributes) {
			assertEquals(BIMS_API_response.contains(attribute), true, "" + attribute + "Not found");
		}

	}

	@Then("user verify that data from PRDB tables {string}")
	public void user_verify_that_data_from_PRDB_tables(String attribute) {
		assertEquals(BIMS_API_response.contains(attribute), true, "" + attribute + "Not found");
		if (BIMS_API_response.contains(attribute)) {
			PRDBdataSource = true;
		} else {
			PRDBdataSource = true;
		}
	}

	@Given("user create open BIMS GRS Event Base URI {string} BasePath {string} for {string}")
	public void user_create_open_BIMS_GRS_Event_Base_URI_BasePath_for(String baseURI, String basePATH, String msdID) {

		HttpClientUtils.baseUri = baseURI;
		HttpClientUtils.basePath = basePATH;
		Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
		Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");

		RetriveResponse response = BIMS_API_CALL.getEntityResponse("entityId", msdID);
		BIMS_API_CALL.BIMS_API_response = BIMS_API_CALL.getResponseBody(response);
		BIMS_API_response = BIMS_API_CALL.BIMS_API_response;
		BIMS_API_CALL.getStatusCode(response);
		System.out.println(BIMS_API_response);

	}

	@Given("user create open BIMS MSD data  Base URI {string} BasePath {string} for {string}")
	public void user_create_open_BIMS_MSD_data_Base_URI_BasePath_for(String baseURI, String basePATH, String msdId) {
		HttpClientUtils.baseUri = baseURI;
		HttpClientUtils.basePath = basePATH;
		Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
		Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");

		RetriveResponse response = BIMS_API_CALL.getResponse("externalId", msdId);
		BIMS_API_response = BIMS_API_CALL.getResponseBody(response);
		BIMS_API_CALL.getStatusCode(response);
		System.out.println(BIMS_API_response);

	}

	@When("checks for {string} in {string}")
	public void checks_for_in(String GRSattributes, String GRSpath) {
		List<String> attributes = Arrays.asList(GRSattributes.split(","));
		for (String attribute : attributes) {
			System.out.println(attribute);
			String EISLPATH = "$." + GRSpath;
			boolean attributeFound = false;
			String attributeName = null;
			Object attributeValue = null;
			try {
				Object item = com.jayway.jsonpath.JsonPath.read(BIMS_API_response, EISLPATH);
				if (item instanceof net.minidev.json.JSONArray) {
					String EISLPATH2 = EISLPATH + "[*]";
					List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(BIMS_API_response, EISLPATH2);
					for (Map<String, String> map : result) {
						for (Map.Entry<String, String> entry : map.entrySet()) {
							attributeName = entry.getKey();
							if (attributeName.equals(attribute)) {
								attributeFound = true;
								attributeValue = entry.getValue();
								break;
							}
						}
					}

				} else if (item instanceof LinkedHashMap) {
					// It's an object
					LinkedHashMap<String, String> map = com.jayway.jsonpath.JsonPath.read(BIMS_API_response, EISLPATH);
					if (map.containsKey(attribute)) {
						attributeValue = map.get(attribute);
						attributeFound = true;
					}

				} else {
					// It's something else, like a string or number
					EISLPATH = EISLPATH + "." + attribute;
					attributeValue = com.jayway.jsonpath.JsonPath.read(BIMS_API_response, EISLPATH);
					if (attributeValue != null) {
						attributeFound = true;
					}
				}

				if (attributeFound) {
					Reporter.addStepLog("<b>" + "Attribute Name " + "</b>" + attribute);
					Reporter.addStepLog("<b>" + "Attribute Value : " + "</b>" + attributeValue);
					Reporter.addStepLog("<b>" + "Attribute Found" + "</b>");
					Reporter.addStepLog("<b>" + "Path " + "</b>" + EISLPATH);
				} else {
					Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");

				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}

	

	@Then("the values in GRS stream and MSD stream should be sourced from PRDB tables for PDBT{int}.PRO_DESC_PURP_C = ST")
	public void the_values_in_GRS_stream_and_MSD_stream_should_be_sourced_from_PRDB_tables_for_PDBT_PRO_DESC_PURP_C_ST(
			Integer int1) {
		assertEquals(PRDBdataSource, true, " GRS stream and MSD stream is not sourced from PRDB tables");
		Reporter.addStepLog("<b>" + "GRS stream and MSD stream is sourced from PRDB tables" + "</b>");
	}

	@Given("checks for {string} in VSCRFRG tables")
	public void checks_for_in_VSCRFRG_tables(String msdattribute) {
		attributeFound = BIMS_API_response.contains(msdattribute);
		assertEquals(false, attributeFound, "" + "VSCRFRG.SCRTY_ADP_XREF_NBR is  present");
		Reporter.addStepLog("<b>" + "VSCRFRG.SCRTY_ADP_XREF_NBR is not present" + "</b>");

	}

	@Then("id.ext_cusip should not be available")
	public void id_ext_cusip_should_not_be_available() {
		assertEquals(BIMS_API_response.contains("ext_cusip"), attributeFound,
				"" + "id_ext_cusip found inspite of VSCRFRG.SCRTY_ADP_XREF_NBR is not present");
		Reporter.addStepLog("<b>"
				+ "id_ext_cusip is not present in GRS stream when VSCRFRG.SCRTY_ADP_XREF_NBR is not present in MSD stream"
				+ "</b>");

	}

	@When("user check that security has {string} and value is Y in {string} Izhora-MSD Stream")
	public void user_check_that_security_has_and_value_is_Y_in_Izhora_MSD_Stream(String msdAttribute, String msdTable) {
		attributeFound = BIMS_API_response.contains(msdAttribute);
		assertEquals(true, attributeFound, "" + msdTable + "." + msdAttribute + ":Y is not present");
		Reporter.addStepLog("<b>" + "VSTCKDT.GDR_IND :Y is present" + "</b>");
		Reporter.addStepLog("<b>" + msdTable + "." + msdAttribute + ":Y is present" + "</b>");

	}

	@Then("the value of SecType.code is {string} and AuxCustomValues.InvestmentType.code is {string} in Izhora-GRS Stream if above condition is correct")
	public void the_value_of_SecType_code_is_and_AuxCustomValues_InvestmentType_code_is_in_Izhora_GRS_Stream_if_above_condition_is_correct(
			String value1, String value2) {

		BIMS_API_CALL.getGRSattributeValue("code", "SecType");
		BIMS_API_CALL.getGRSattributeValue("code", "AuxCustomValues.InvestmentType");
	}

	@Then("user validate the value for {string} for {string}")
	public void user_validate_the_value_for_for(String prdbAttribute, String vendorId) {
		attributeFound = BIMS_API_response.contains(prdbAttribute);
		if (attributeFound) {
			int start = BIMS_API_response.indexOf("PRO_APPVL_C:");
			int end = BIMS_API_response.indexOf("PDBT2000:");
			String AttributeValue = BIMS_API_response.substring(start, end);
			System.out.println("prdbAttributeValue  " + AttributeValue);
			prdbAttributeValue = AttributeValue;
		} else {
			prdbAttributeValue = null;
		}
		Reporter.addStepLog("<b>" + prdbAttribute + " : " + prdbAttributeValue + "</b>");
	}

	@When("user validate the value of  {string} and {string} in GRS")
	public void user_validate_the_value_of_and_in_GRS(String grsAttribute, String grsPath) {
		String gsrAttributeValue = BIMS_API_CALL.getGRSattributeValue(grsAttribute, grsPath).toString();
		GRSAttributeValue = gsrAttributeValue;
		System.out.println("gsrAttributeValue " + gsrAttributeValue);
		Reporter.addStepLog("<b>" + grsPath + "." + grsAttribute + " : " + prdbAttributeValue + "</b>");
		attributeFound = BIMS_API_response.contains(grsAttribute);
		assertEquals(true, attributeFound, "" + grsPath + "." + grsAttribute + " : Not Found");
	}

	@Then("if PDBT{int}.PRO_APPVL_C = {string} then MSD_MG_LST_OTC_IND = {string}  and GRS field AuxCustomValues.IsMarginable = true")
	public void if_PDBT_PRO_APPVL_C_then_MSD_MG_LST_OTC_IND_and_GRS_field_AuxCustomValues_IsMarginable_true(
			Integer prdbTable, String prdbAttributeValueMR, String msdAttributeValue) {

		if (prdbAttributeValue != null) {
			if (prdbAttributeValue.equals(prdbAttributeValueMR)) {
				assertEquals(true, GRSAttributeValue, "AuxCustomValues.IsMarginable is not true");
			}
		} else {
			assertEquals(false, GRSAttributeValue, "AuxCustomValues.IsMarginable is not false");
		}
	}

	@Then("else MSD_MG_LST_OTC_IND = {string} and GRS field AuxCustomValues.IsMarginable = false;")
	public void else_MSD_MG_LST_OTC_IND_and_GRS_field_AuxCustomValues_IsMarginable_false(String msdAttributeValue) {
		attributeFound = BIMS_API_response.contains("MSD_MG_LST_OTC_IND");
		String AttributeValue = null;
		if (attributeFound) {
			int start = BIMS_API_response.indexOf("MSD_MG_LST_OTC_IND");
			AttributeValue = BIMS_API_response.substring(start, start + 1);
			assertEquals(msdAttributeValue, AttributeValue, "AuxCustomValues.IsMarginable is not false");

		} else {
			Reporter.addStepLog("<b>" + "MSD_MG_LST_OTC_IN  is not found" + "</b>");
		}

	}

	@Then("if PDBT{int}.PRO_APPVL_C is not found, then MSD_MG_LST_OTC_IND = {string} and GRS field AuxCustomValues.IsMarginable = false;")
	public void if_PDBT_PRO_APPVL_C_is_not_found_then_MSD_MG_LST_OTC_IND_and_GRS_field_AuxCustomValues_IsMarginable_false(
			Integer prdbTable, String msdAttributeValue) {
		if (prdbAttributeValue != null) {
			if (prdbAttributeValue.equals("MR")) {
				assertEquals(true, GRSAttributeValue, "AuxCustomValues.IsMarginable is not true");
			}
		} else {
			assertEquals(false, GRSAttributeValue, "AuxCustomValues.IsMarginable is not false");
		}

	}
	
	

@When("the user checks for attribute PRO_ALTN_KEY_I from PDBT{int} table in PRDB stream")
public void the_user_checks_for_attribute_PRO_ALTN_KEY_I_from_PDBT_table_in_PRDB_stream(Integer int1) {
	attributeFound = BIMS_API_response.contains("PRO_ALTN_KEY_TYP_C: TS");
	if (attributeFound) {
		int proIndex = BIMS_API_response.indexOf("PRO_ALTN_KEY_TYP_C: TS");
		int enddateIndex = proIndex -23;
		String ED_EFF_D = BIMS_API_response.substring(enddateIndex, proIndex);
		valueOfED_EFF_D = ED_EFF_D.trim().substring(ED_EFF_D.indexOf("ED_EFF_D:")+9).trim();
	} else {
	}
}

@When("If attribute ed_eff_d <= current date")
public void if_attribute_ed_eff_d_current_date() throws ParseException {
	Reporter.addStepLog("<b>" + "value Of ED_EFF_D :" +valueOfED_EFF_D+ "</b>");
	
	valueOfED_EFF_D = valueOfED_EFF_D.trim().substring(valueOfED_EFF_D.indexOf("EFF_D:")+1).trim();
		String dateInString = valueOfED_EFF_D.trim();
	    Date date1=new SimpleDateFormat("MM/dd/yyyy").parse(dateInString);  
	
	if (dateobj.compareTo(date1) > 0) {
	    System.out.println();
	    Reporter.addStepLog("<b>" + "Date1 is after Date2"+ "</b>");
	} else if (dateobj.compareTo(date1) < 0) {
		 Reporter.addStepLog("<b>" + "Date1 is before Date2"+ "</b>");
	} else {
		Reporter.addStepLog("<b>" + "Date1 is equal to Date2"+ "</b>");
	}
	
	
}

@When("if User check value of PDBT{int}.ed_end_d > current date or PDBT{int}.ed_end_d is NULL")
public void if_User_check_value_of_PDBT_ed_end_d_current_date_or_PDBT_ed_end_d_is_NULL(Integer int1, Integer int2) {
}

@When("user check the value of id {string} and {string} in GRS")
public void user_check_the_value_of_id_and_in_GRS(String string, String string2) {
}




@When("user check VBSSCRDT {string} in MSD stream")
public void user_check_VBSSCRDT_in_MSD_stream(String msdAttribute) {
	attributeFound = BIMS_API_response.contains(msdAttribute);
	System.out.println(BIMS_API_response);
	String value;
	if (attributeFound) {
		Reporter.addStepLog("<b>" + msdAttribute + "  " + " Found" + "</b>");
		value = BIMS_API_response.substring(BIMS_API_response.indexOf(msdAttribute)+10,BIMS_API_response.indexOf(msdAttribute)+12).trim();
		Reporter.addStepLog("<b>" +value + "  "+ "</b>");
	} else {
		Reporter.addStepLog("<b>" + msdAttribute + "  " + "Not Found" + "</b>");
	}
	assertEquals(true, attributeFound, ""+msdAttribute+"Not Found");

}

@When("user check the value of bondinfo.Is{int}ARegistrationRights {string} and {string} in GRS")
public void user_check_the_value_of_bondinfo_Is_ARegistrationRights_and_in_GRS(Integer int1, String grsAttribute, String grsPath) {
	String gsrAttributeValue = BIMS_API_CALL.getGRSattributeValue(grsAttribute, grsPath).toString();
	GRSAttributeValue = gsrAttributeValue;
	System.out.println("gsrAttributeValue " + gsrAttributeValue);
	attributeFound = BIMS_API_response.contains(grsAttribute);
	assertEquals(true, attributeFound, "" + grsPath + "." + grsAttribute + " : Not Found");

}


@When("user check that VMSTRANB.TYPE_SECURITY_CD=FDS {string} in Izhora MSD stream")
public void user_check_that_VMSTRANB_TYPE_SECURITY_CD_FDS_in_Izhora_MSD_stream(String msdAttribute) {
	attributeFound = BIMS_API_response.contains(msdAttribute);
	System.out.println(BIMS_API_response);
	String value;
	if (attributeFound) {
		Reporter.addStepLog("<b>" + msdAttribute + "  " + " Found" + "</b>");
		value = BIMS_API_response.substring(BIMS_API_response.indexOf(msdAttribute)+17,BIMS_API_response.indexOf(msdAttribute)+19).trim();
		Reporter.addStepLog("<b>" +value + "  "+ "</b>");
	} else {
		Reporter.addStepLog("<b>" + msdAttribute + "  " + "Not Found" + "</b>");
	}
	assertEquals(true, attributeFound, ""+msdAttribute+"Not Found");


}

@When("user checks for VSTCKDT.ETF_IND=Y {string} in Izhora MSD Stream")
public void user_checks_for_VSTCKDT_ETF_IND_Y_in_Izhora_MSD_Stream(String msdAttribute) {
	attributeFound = BIMS_API_response.contains(msdAttribute);
	System.out.println(BIMS_API_response);
	String value;
	if (attributeFound) {
		Reporter.addStepLog("<b>" + msdAttribute + "  " + " Found" + "</b>");
		value = BIMS_API_response.substring(BIMS_API_response.indexOf(msdAttribute)+10,BIMS_API_response.indexOf(msdAttribute)+12).trim();
		Reporter.addStepLog("<b>" +value + "  "+ "</b>");
	} else {
		Reporter.addStepLog("<b>" + msdAttribute + "  " + "Not Found" + "</b>");
	}
	assertEquals(true, attributeFound, ""+msdAttribute+"Not Found");


}

@Then("the value of SecType.code  {string},{string} and AuxCustomValues.InvestmentType.code {string},{string} should be equal to {string}")
public void the_value_of_SecType_code_and_AuxCustomValues_InvestmentType_code_should_be_equal_to(String grsAttribute1, String grsPath1,String grsAttribute2, String grsPath2,String value) {

	String gsrAttributeValue = BIMS_API_CALL.getGRSattributeValue(grsAttribute1, grsPath1).toString();
	GRSAttributeValue = gsrAttributeValue;
	System.out.println("gsrAttributeValue " + gsrAttributeValue);
	attributeFound = BIMS_API_response.contains(grsAttribute1);
	assertEquals(true, attributeFound, "" + grsPath1 + "." + grsAttribute1 + " : Not Found");

	String gsrAttributeValue2 = BIMS_API_CALL.getGRSattributeValue(grsAttribute2, grsPath2).toString();
	GRSAttributeValue = gsrAttributeValue2;
	System.out.println("gsrAttributeValue " + gsrAttributeValue2);
	attributeFound = BIMS_API_response.contains(grsAttribute2);
	assertEquals(true, attributeFound, "" + grsPath1 + "." + grsAttribute1 + " : Not Found");


}

@When("user check that MSD attribute {string} and value {string} in Izhora MSD stream")
public void user_check_that_MSD_attribute_and_value_in_Izhora_MSD_stream(String msdAttribute, String value) {

	attributeFound = BIMS_API_response.contains(msdAttribute);
	 BIMS_API_CALL.searchString = BIMS_API_response;
	 List<IndexWrapper> atrributeIndexes = BIMS_API_CALL.findIndexesForKeyword(msdAttribute);
     System.out.println("AttributeIndexes found "+atrributeIndexes.size() +" keyword found at index : "+atrributeIndexes.get(0).getStart());
     int start = atrributeIndexes.get(0).getStart();
     int end = start+msdAttribute.length()+value.length()+3;
     String MSDvalue = BIMS_API_response.substring(start,end).trim();
     System.out.println("MSDvalue  "+MSDvalue);
     Reporter.addStepLog("msdValue <b> :" +MSDvalue + "  "+ "</b>");
}

@Then("the value of SecType.code  {string},{string} should be equal to STP {string}")
public void match_GRS_To_MSD(String grsAttribute, String grsPath, String msdValue) {
	String gsrAttributeValue = BIMS_API_CALL.getGRSattributeValue(grsAttribute, grsPath).toString();
	GRSAttributeValue = gsrAttributeValue;
	System.out.println("gsrAttributeValue " + gsrAttributeValue);
	 Reporter.addStepLog("gsrAttributeValue <b>" + gsrAttributeValue+"</b>");
	attributeFound = BIMS_API_response.contains(grsAttribute);
	assertEquals(true, attributeFound, "" + grsPath + "." + grsAttribute + " : Not Found");
	
}


@Then("the value of GRS attribute {string},{string} should be according to  MSD value  {string}")
public void the_value_of_GRS_attribute_should_be_according_to_MSD_value(String grsAttribute, String grsPath, String msdValue) {
	match_GRS_To_MSD(grsAttribute,grsPath,msdValue);
}



	
@Then("user check the condition that MSD table {string} has {string} and its value is {string}")
public void user_check_the_condition_that_MSD_table_has_and_its_value_is(String MSDtable, String MSDattribute, String value) {

	 BIMS_API_CALL.searchString = BIMS_API_response;
     List<IndexWrapper> attributeIndex = BIMS_API_CALL.findIndexesForKeyword(MSDattribute);
     System.out.println("Indexes found "+attributeIndex.size() +" keyword found at index : "+attributeIndex.get(0).getStart());
   
    int start = attributeIndex.get(0).getStart();
    int end = start+MSDattribute.length()+value.length()+3;
    String MSDvalue = BIMS_API_response.substring(start,end).trim();
    System.out.println("MSDvalue  "+MSDvalue);
    Reporter.addStepLog("msdValue <b> :" +MSDvalue + "  "+ "</b>");
    
    
    

}

@Then("the value of bondInfo.IssueDatedDate  {string},{string} should be equal to {string}")
public void the_value_of_bondInfo_IssueDatedDate_should_be_equal_to(String grsAttribute, String grsPath, String msdValue) {
	String gsrAttributeValue = BIMS_API_CALL.getGRSattributeValue(grsAttribute, grsPath).toString();
	GRSAttributeValue = gsrAttributeValue;
	System.out.println("gsrAttributeValue " + gsrAttributeValue);
	attributeFound = BIMS_API_response.contains(grsAttribute);
	assertEquals(true, attributeFound, "" + grsPath + "." + grsAttribute + " : Not Found");
	
	
}

@Then("the value of fundInfo.Dividends.Currency  {string},{string} should be as per {string}")
public void the_value_of_fundInfo_Dividends_Currency_should_be_as_per(String grsAttribute, String grsPath, String msdValue) {
	String gsrAttributeValue = BIMS_API_CALL.getGRSattributeValue(grsAttribute, grsPath).toString();
	GRSAttributeValue = gsrAttributeValue;
	System.out.println("gsrAttributeValue " + gsrAttributeValue);
	attributeFound = BIMS_API_response.contains(grsAttribute);
	
}
	
	
	
@Then("the value of GRS attribute  {string},{string} should be as per MSD attribute {string} from msd table {string}")
public void the_value_of_GRS_attribute_should_be_as_per_MSD_attribute_from_msd_table(String grsAtrribute, String grsPath, String msdAttribute, String msdTable) {

	String gsrAttributeValue = BIMS_API_CALL.getGRSattributeValue(grsAtrribute, grsPath).toString();
	GRSAttributeValue = gsrAttributeValue;
	System.out.println("gsrAttributeValue " + gsrAttributeValue);
	attributeFound = BIMS_API_response.contains(grsAtrribute);
	assertEquals(true, attributeFound, "" + grsPath + "." + grsAtrribute + " : Not Found");
	 Reporter.addStepLog(grsPath+"."+grsAtrribute+"<b> :" +gsrAttributeValue + "  "+ "</b>");
	 Reporter.addStepLog(msdTable+"."+"<b> :" +msdAttribute + "  "+ "</b>");
	
}

@When("user check value of GRS attribute  {string},{string} and security product code {string}")
public void user_check_value_of_GRS_attribute_and_security_product_code(String grsAtrribute, String grsPath, String productCode) {
	String gsrAttributeValue = BIMS_API_CALL.getGRSattributeValue(grsAtrribute, grsPath).toString();
	GRSAttributeValue = gsrAttributeValue;
	System.out.println("gsrAttributeValue " + gsrAttributeValue);
	attributeFound = BIMS_API_response.contains(grsAtrribute);
	assertEquals(true, attributeFound, "" + grsPath + "." + grsAtrribute + " : Not Found");
	 Reporter.addStepLog(grsPath+"."+grsAtrribute+"<b> :" +gsrAttributeValue + "  "+ "</b>");
	
}

@Then("user validate that physical option security Includes Id section in ShadowIdentifiers field")
public void user_validate_that_physical_option_security_Includes_Id_section_in_ShadowIdentifiers_field() {

	attributeFound = BIMS_API_response.contains("ShadowIdentifiers");
	assertEquals(true, attributeFound,  " ShadowIdentifiers Not Found");
		
	
}

@When("user check that that msd table VSCRFRG is not present")
public void user_check_that_that_msd_table_VSCRFRG_is_not_present() {

	attributeFound = BIMS_API_response.contains("VSCRFRG");
	System.out.println(BIMS_API_response);
	if (!attributeFound) {
		Reporter.addStepLog("<b> MSD table VSCRFRG has no records </b>");
	} else {
		Reporter.addStepLog("<b> MSD table VSCRFRG has records" + "</b>");
	}
	assertEquals(false, attributeFound, "MSD table VSCRFRG has records");



}

@Then("user check that {string} is not present in GRS.")
public void user_check_that_is_not_present_in_GRS(String grs) {


	attributeFound = BIMS_API_response.contains(grs);
	System.out.println(BIMS_API_response);
	if (!attributeFound) {
		Reporter.addStepLog("<b> GRS does not have "+grs+"</b>");
	} else {
		Reporter.addStepLog("<b> GRS does have "+grs+"</b>");
	}
	assertEquals(false, attributeFound, "MSD table VSCRFRG has records");
	
}

@Given("user has access to  BIMS FulltextSearch API Base URL {string} and Base path {string}")
public void user_has_access_to_BIMS_FulltextSearch_API_Base_URL_and_Base_path(String baseURI, String basePATH) throws IOException {
	HttpClientUtils.baseUri = baseURI;
	HttpClientUtils.basePath = basePATH;
	Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
	Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");
	BIMS_API_CALL.setURL(baseURI,basePATH);
}

@Given("user search for GRS attribute {string} as {string} and  {string} as {string}")
public void user_search_for_GRS_attribute_as_and_as(String querParm1, String qValue, String querParm2, String qValue2) {
	String msdid = BIMS_API_CALL.getMSD_IdFromFTS(querParm1,qValue,querParm2,qValue2);
	System.out.println(msdid);
}

	
	

}
