package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;
import qa.framework.utils.Reporter;


public class NonUBSClientDataValidationUSM3042Stepdef {
	
	boolean testflag = false;
	File[] listOfFiles;
	List<String> listofrecords = new ArrayList<String>();;
	String filename;
	String folderpath = "D:\\Users\\GuptaVi\\Desktop\\USM-3042\\out_1\\out";
	
	
  
  @Given("user has access to Full-load file named {string}")
  public void user_has_access_to_Full_load_file_named(String filename) {
		
	//	Reporter.addStepLog("<b> User is able to access to Full load file named: "+ filename + "</b>" );
	

  }

  @When("user search that {string} and {string} attributes  is available for the security in file")
  public void user_search_that_and_attributes_is_available_for_the_security_in_file(String attribute_1, String attribute_2) {
	//  Reporter.addStepLog("<b>  "+ attribute_1 +" "+attribute_2 + "</b>" );
		

  }

  @Then("{string} and {string} should be available in file named {string}")
  public void and_should_be_available_in_file_named(String string, String string2, String string3) throws FileNotFoundException {

	  File folder = new File(folderpath);
		listOfFiles = folder.listFiles();
		
		for (File file : listOfFiles) {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;	filename = file.getName();
			Reporter.addStepLog("<b>File "+ filename  + "</b>");		
			
			int i =1;String msd_id =null;
			try {
				while ((line = br.readLine()) != null) {
					Reporter.addStepLog("<b>"+ "line No "+i++  + "</b>");
					if(line.contains("PRO_I") && line.contains("SEC_I")) {
						testflag = true;
						  
					  }else {
						  testflag = false;
					  }
					
							try {
								msd_id  = (String)com.jayway.jsonpath.JsonPath.read(line, "$.Id.MSD_ID");
							
							 
						} catch (Exception e) {
							e.printStackTrace();
						}
					
					 if(testflag==true) {
						 Reporter.addStepLog(" For MSD_ID   "+ "<strong>"+msd_id+"</strong>"+"   PRO_I and SEC_I found in file  .");
							
					 }
					 else {
						 Reporter.addStepLog(" For MSD_ID   "+ "<strong>"+msd_id+"</strong>"+"   PRO_I or SEC_I not found in file  .");
							
					 }
					 Assert.assertEquals("PRO_I and SEC_I is not found in file for  " +msd_id ,true, testflag);	
					 
						 
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}	
		}
		
		
		
	
  

  }
  
  
  
  
  
}
