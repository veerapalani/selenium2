package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.util.List;
import java.util.Map;

import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class ValidateAttributeOfPRDBandEISLStepDef {
	
	String APIresponse;
	String msdid;
	RetriveResponse response;
	String HttpbaseURI;
	String HttpbasePATH;
	
	@Given("QA API Base URL {string} and Base path {string}")
	public void qa_API_Base_URL_and_Base_path(String baseURI, String basePATH) {   
		   HttpClientUtils.baseUri = baseURI;
			HttpClientUtils.basePath = basePATH;
			
			Reporter.addStepLog("baseUri : "+"<b>"+ baseURI+  "</b>" );
		    Reporter.addStepLog("basePath : "+"<b>"+ basePATH+  "</b>" );
		   
	}

	@When("user send get request to QA API with {string}  as current endpoint")
	public void user_send_get_request_to_QA_API_with_as_current_endpoint(String msdid) {
		
		response = HttpClientUtils.given()
				.setPathParameter("entityId", msdid)
				.setCetificate("D:\\Users\\GuptaVi\\ALL\\server (1).pfx", "")
				.setProxy("10.98.21.23", 8080)
				.executeRequest(MethodType.GET);
		
		APIresponse = response.getBody().asString();
		
		Reporter.addStepLog("Endpoint :"+"<strong>" + msdid +"</strong>");

	}

	@Then("user should get success and response code  {int}")
	public void user_should_get_success_and_response_code(Integer int1) {
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :"+"<strong>"+statusCode+"</strong>");
		Reporter.addStepLog("<strong>Response:</strong>");
	
		Reporter.addStepLog(APIresponse);
		
		
		// Assert that correct status code is returned.
		Assert.assertEquals(statusCode, 200, "Status code returned");
	
	}

	@Then("User searches for the field {string} under the table {string}")
	public void user_searches_for_the_field_under_the_table(String prdbAttribute, String prdbtable) {
		
		String prdbPath = "$."+"CustomFields.UBS_PRDB.PDBT0600[*]";
		  List<String> prdbPathList =  com.jayway.jsonpath.JsonPath.read(APIresponse, prdbPath);
		 
		 Reporter.addStepLog("<strong>Attributes under PDBT0600: "+"</strong>");
		  Reporter.addStepLog(prdbPathList.toString());
		  
		  
		  List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(APIresponse, prdbPath);
		  boolean attributeFound = false;
		  
			for(Map<String, String> map:result) {

			    for (Map.Entry<String, String> entry : map.entrySet()) {
			        String key = entry.getKey();
			        Object value = entry.getValue();
			        
			        if(key.equals(prdbAttribute)) {
			        	attributeFound = true;
					    //    Reporter.addStepLog("<b>"+key +":"+value+"</b>");
					    	
			        }
			       
			    }
			
			}
			
			if(attributeFound) {
				 Reporter.addStepLog("<b>"+"Attribute Found"+"</b>");
			    	
			}else {
				 Reporter.addStepLog("<b>"+"Attribute not Found"+"</b>");
				    
			}
			
			
			Assert.assertEquals(attributeFound , true , "Attribute not found");
			
		
	}

	@Then("User validate that corresponding mapped attribute {string} is present inside backbridgeDescription")
	public void user_validate_that_corresponding_mapped_attribute_is_present_inside_backbridgeDescription(String eislAttribute) {
		String EISL_path = "$.CustomFields.clientDefined.backbridgeDescription[*]";
		List<String> attrlist =  com.jayway.jsonpath.JsonPath.read(APIresponse,EISL_path);
		 Reporter.addStepLog("<strong>Fields from GRS custom fields to EISL ontology : </strong>");
		 Reporter.addStepLog( attrlist.toString());
				
		
		  
		  List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(APIresponse, EISL_path);
	
		  boolean attributeFound = false;
			for(Map<String, String> map:result) {

			    for (Map.Entry<String, String> entry : map.entrySet()) {
			        String key = entry.getKey();
			        Object value = entry.getValue();
			        
			        if(key.equals(eislAttribute)) {
			        	attributeFound = true;
			        //	Reporter.addStepLog(key +":"+value);
				    	
			        }
			       
			    }
			
			}
			if(attributeFound) {
				 Reporter.addStepLog("<b>Attribute Found</b>");
			    	
			}else {
				 Reporter.addStepLog("<b>Attribute not Found </b>");
				    
			}
			Assert.assertEquals(attributeFound , true , "Attribute not found");
	
	}
	
	
	@Then("User searches and validate that field {string} is present under the table {string}")
	public void user_searches_and_validate_that_field_is_present_under_the_table(String prdbAttribute, String prdbTable) {

		  String prdbPath = "$."+"CustomFields.UBS_PRDB.PDBT0600[*]";
		  List<String> prdbPathList =  com.jayway.jsonpath.JsonPath.read(APIresponse, prdbPath);
		  
		  Reporter.addStepLog("<strong>PRDB attributes under PDBT0600 :</strong>");
		  Reporter.addStepLog(prdbPathList.toString());
			
		  
		  
		  List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(APIresponse, prdbPath);
	
		  boolean attributeFound = false;
			for(Map<String, String> map:result) {

			    for (Map.Entry<String, String> entry : map.entrySet()) {
			        String key = entry.getKey();
			        Object value = entry.getValue();
			        
			        if(key.equals(prdbAttribute)) {
			        	attributeFound = true;
			       //	Reporter.addStepLog(key +":"+value);
			        }
			       
			    }
			
			}
			
			if(attributeFound) {
				 Reporter.addStepLog("<b>Attribute Found</b>");
			    	
			}else {
				 Reporter.addStepLog("<b>Attribute not Found</b>");
				    
			}
			Assert.assertEquals(attributeFound, true, "Attribute not found");
			
		
		
		
	}
	
	
	//ValidateSecurityInBIMSreceivedFrom MSD_USM1563.feature
	//UAT
			@Then("user validate the attribute {string} as {string} at loction {string} by checking its value that contains {string}  in BIMS API") 
			public void user_validate_the_attribute_as_at_loction_by_checking_its_value_that_contains_in_BIMS_API(String attribute,String status, String attributePath, String text) {
		
			boolean textPresent = false;
		  String attrPath= "$."+attributePath;
		  String attributeValue =  com.jayway.jsonpath.JsonPath.read(APIresponse, attrPath);
		  Reporter.addStepLog("<b>"+attribute+"</b>" +" : "+attributeValue);
		  
		  if(attributeValue.contains(text)) {
			  textPresent = true;
		  }
		  else {
			  textPresent = false;
		  }
		  
		  Assert.assertEquals(textPresent, true, "Attribute not found");
			
		
	}
	

}
