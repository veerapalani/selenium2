package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.ArrayList;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.restassured.path.json.JsonPath;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;


public class ValidteKafkaNHandDATAHUBStepDef {
	
	String APIresponse;
	JsonPath jsonresponse;

	Process p = null;
	final String kafkaPath = "D:\\Users\\GuptaVi\\kafka_2.13-2.4.0\\bin\\windows";
	boolean NHnDataAvailableInFile = false;
	boolean DataHubAvailableInFile = false;

	
	@Given("^user connects to Base Swagger QA URL with (.+) as current endpoint$")
	public void user_connects_to_base_swagger_qa_url_with_as_current_endpoint(String msdid)
			throws KeyStoreException, FileNotFoundException, IOException, NoSuchAlgorithmException,
			CertificateException, KeyManagementException, UnrecoverableKeyException {


		HttpClientUtils.baseUri = "https://ppapp.pp.gtoqa.bfsaws.net/Peter_Unicorn";
		HttpClientUtils.basePath = "/Entity/GetSnapshot/{entityId}";
		
		RetriveResponse response = HttpClientUtils.given()
		.setPathParameter("entityId", msdid)
		.setCetificate("D:\\Users\\GuptaVi\\ALL\\br_localhost_pass_123.pfx", "123")
		.setProxy("10.98.21.24", 8080)
		.executeRequest(MethodType.GET);

		int status = response.getStatusCode();
		String APIresponse = response.getBody().asString();
	
		jsonresponse = new JsonPath(APIresponse);
		
		Reporter.addStepLog("<strong>API Response : </strong>" + APIresponse);
		
		System.out.println(status);

		System.out.println("Swagger API Response for MSID...  "+msdid);
		System.out.println(APIresponse);
		jsonresponse = new JsonPath(APIresponse);
		Reporter.addStepLog("API response : "+"<b>"+ APIresponse+  "</b>" );
	} 
	
	
	
	 
	 @And("Validates {string} notification on NOTIFICATION HUB published by BIMS")
	 public void validates_notification_on_NOTIFICATION_HUB_published_by_BIMS(String msdid) {
		 System.out.println("Checking  NOTIFICATION HUB for "+msdid);   

			String command = "kafka-console-consumer.bat --bootstrap-server " + '"'
					+ "qa-bk1.kafka.wmap.broadridge.com:19092,qa-bk2.kafka.wmap.broadridge.com:19092,qa-bk3.kafka.wmap.broadridge.com:19092"
					+ '"'
					+ " --topic BR.INSTRUMENTS.FINANCIALINSTRUMENT.SECURITYMASTER.EVENTS.QA.OUT.WMAP.TOPIC --from-beginning --consumer.config "
					+ '"' + "NHub.properties" + '"';

			

			String FilePath = "./src/test/resources/ad/securitymaster/api/kafkaLog/topic-NotificationHub.log";


			File file = new File(FilePath);
			if (file.exists()) {
				file.delete();
			}
			try {
				file.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			try {
				
				if (!NHnDataAvailableInFile) {
					
					System.out.println("Commad is ---" + "\n" + command);
					
					ProcessBuilder processBuilder = new ProcessBuilder();
					processBuilder.command("cmd.exe", "/c", command);
					processBuilder.directory(new File(kafkaPath));
					processBuilder.redirectOutput(new File(FilePath));
					Process process = processBuilder.start();
					Thread.sleep(20000);
					process.destroy();
					if (process.isAlive()) {
						process.destroyForcibly();
					}
					NHnDataAvailableInFile =true;
					
				}


				ArrayList<String> messageArray = new ArrayList<String>();
				String  line;
				boolean securityAvailable = false;
				
				try (BufferedReader br = new BufferedReader(new FileReader(FilePath))) {
					while ((line = br.readLine()) != null) {
						if (line.contains(msdid)) {
							messageArray.add(line);
							securityAvailable = true;
						}
					}
				}


				if (securityAvailable) {
					int len = messageArray.size();
					String lastLine = messageArray.get(len - 1);
					String checkUpdate = "UPDATED SECURITY WITH MSD CODE:";
					System.out.println("messageArray last line --\n" + lastLine);
					if (lastLine.contains(checkUpdate)) {
						System.out.println("Security is found updated ..");
						Reporter.addStepLog("<strong> Security is found updated </strong>");
					}else {
						System.out.println("Security is found Added ..");
						Reporter.addStepLog("<strong> A New Security is Added </strong>");
					}
					

				} else {
					System.out.println("Security not found"
							+ " in Notification HuB  ..");
					Reporter.addStepLog("<strong> Security not found in Notification Hub</strong>");
				}

				
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		
		 
		 
		 
	 }

	 

	 @And("^Validates (.+) data on DATA HUB published by BIMS$")
	    public void validate_data_on_data_hub_published_by_bims(String msdid) throws Throwable {
		 System.out.println("Checking data_hub for MSDID  "+msdid);

			String command = "kafka-console-consumer.bat --bootstrap-server " + '"'
					+ "qa-bk1.kafka.wmap.broadridge.com:19092,qa-bk2.kafka.wmap.broadridge.com:19092,qa-bk3.kafka.wmap.broadridge.com:19092"
					+ '"'
					+ " --topic BR.INSTRUMENTS.FINANCIALINSTRUMENT.SECURITYMASTER.DATA.QA.OUT.WMAP.TOPIC --from-beginning --consumer.config "
					+ '"' + "NHub.properties" + '"';

			String FilePath = "./src/test/resources/ad/securitymaster/api/kafkaLog/topic-DataHub.log";


			File file = new File(FilePath);
			if (file.exists()) {
				file.delete();
			}
			try {
				file.createNewFile();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

			try {

				if (!DataHubAvailableInFile) {
					
					System.out.println("Commad is ---" + "\n" + command);
					
					ProcessBuilder processBuilder = new ProcessBuilder();
					processBuilder.command("cmd.exe", "/c", command);
					processBuilder.directory(new File(kafkaPath));
					processBuilder.redirectOutput(new File(FilePath));
					Process process = processBuilder.start();
					Thread.sleep(40000);
					process.destroy();
					if (process.isAlive()) {
						process.destroyForcibly();
					}
					DataHubAvailableInFile =true;

					
				}


				ArrayList<String> listOfsecurity = new ArrayList<String>();

				String line;
				boolean securityAvailable = false;
				 JSONParser parser = new JSONParser();

				try (BufferedReader br = new BufferedReader(new FileReader(FilePath))) {
					while ((line = br.readLine()) != null) {
						if (line.contains(msdid)) {
						      JSONObject kafakaMsgJson = (JSONObject) parser.parse(line);
						      String eventValue = (String) kafakaMsgJson.get("event");
								if (eventValue.contains("MSD_ID")) {
									String msdidKafaka = com.jayway.jsonpath.JsonPath.read(eventValue, "$.Id.MSD_ID");
									if (msdidKafaka.equals(msdid)) {
										listOfsecurity.add(line);
										securityAvailable = true;
									}

								}
							
						}
					}
				}
				
				System.out.println("List of Security inside datahub with " +msdid);
				System.out.println(listOfsecurity);

				if (securityAvailable) {
					int len = listOfsecurity.size();
					String last = listOfsecurity.get(len - 1);
					System.out.println("lastest security is ...\n" + last);

					last = last.replace("\\", "");
					int lastIndOfEvent = last.lastIndexOf("\"event\"");
					line = last.substring(lastIndOfEvent).replace("\"event\":\"", "");
					
					Reporter.addStepLog("<strong> lastest Added/updated Security inside datahub   </strong>"+line);
					 
					System.out.println("DataHub Payload..\n"
							+ line);
					System.out.println("API response is ..\n"+APIresponse);
					System.out.println("comparing these two result");
					if (APIresponse.equals(line)) {
						System.out.println("Equal");
						Reporter.addStepLog("<strong>Both API Response and Kafka payload inside datahubB are EQUAL</strong>");
					} else {
						System.out.println("Not Equal");
						Reporter.addStepLog("<strong>Both API Response and Kafka payload inside datahubB are not EQUAL</strong>");
						
					}

				} else {
					System.out.println("No security Found in DATA Hub");
					Reporter.addStepLog("<strong>Security not found in DATA Hub</strong>");
					
				}


			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		
		 
	    }

	
	

}
