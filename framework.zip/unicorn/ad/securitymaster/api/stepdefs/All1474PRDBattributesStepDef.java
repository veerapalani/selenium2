package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.testng.Assert;

import com.jayway.jsonpath.PathNotFoundException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class All1474PRDBattributesStepDef {

	String api_response;
	boolean isArray = false;
	boolean isObject = false;
	public static String APIresponse;
	public static String msdid;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	public List<String> listofSecurity = new ArrayList<String>();
	String key;
	String attributeNo;
	String prdb_Attribute;
	String prdbAttribute_Value;
	String EISLAttribute;
	String EISLAttributeValue;
	String EISLMapping;
	String PRDBTABLE;
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Date dateobj = new Date();
	String vendorId = "";

	Map<String, List<String>> hashmap = new HashMap<String, List<String>>();
	List<String> listOfattribute;
	
	@When("user make a get method call for attribute {string} and other")
	public void user_make_a_get_method_call_for_attribute_and_other(String string) {
		
	}

	@Given("user has acess to BIMS API and user create a request for Base URL {string} and Base path {string}")
	public void user_has_acess_to_BIMS_API_and_user_create_a_request_for_Base_URL_and_Base_path(String baseURI,
			String basePATH) {
		HttpClientUtils.baseUri = baseURI;
		HttpClientUtils.basePath = basePATH;
		Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
		Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");

	}

	@Given("user set Query Parameter {string} as {string} and  {string} as {string}")
	public void user_set_Query_Parameter_as_and_as(String querParm1, String qValue, String querParm2, String qValue2) {

		// .setCetificate("D:\\Users\\GuptaVi\\ALL\\br_localhost_pass_123.pfx", "123")
		// .setCetificate("D:\\Users\\GuptaVi\\ALL\\server (1).pfx", "") for QA
		// .setProxy("10.98.21.24", 8080)

		response = HttpClientUtils.given().buildUri().setQueryParameter(querParm1, qValue)
				.setQueryParameter(querParm2, qValue2)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		key = qValue;
	}

	@When("user make a get method call for attribute {string}")
	public void user_make_a_get_method_call_for_attribute(String attrNo) {

		// System.out.println(response.getStatusLine());
		attributeNo = attrNo;

	}

	@Then("user receive Sucess and repose code {int}")
	public void user_receive_Sucess_and_repose_code(Integer int1) {
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		// Assert.assertEquals(statusCode, 200, "Status code returned");

		String firstAPIresponse = response.getBody().asString();
		Reporter.addStepLog("Response Body :" + "<strong>" + firstAPIresponse + "</strong>");

//		if(firstAPIresponse.length()>4)
//			{
//			
//			String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
//			try {
//
//				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
//				Date dateobj = new Date();
//				FileWriter writer = new FileWriter(path, true);
//				BufferedWriter bufferedWriter = new BufferedWriter(writer);
//				bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attributeNo, 3)+  fixedLengthString(key,102)
//						+ "  Not  found   :  \t "
//						 );
//				bufferedWriter.newLine();
//				bufferedWriter.close();
//			} catch (IOException ee) {
//				ee.printStackTrace();
//			}
//
//			Assert.assertEquals(false, true);
//			}
		
	}

	@Then("user receive {int} and msdid in response for {string}")
	public void user_receive_and_msdid_in_response_for(Integer int1, String prdbAttribute) {

		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");

		String firstAPIresponse = response.getBody().asString();

		String msdidPath = "$.[0].EntityId";
		msdid = null;

		try {
			msdid = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, msdidPath);
			
			//Added for check
			String path = "./src/test/resources/ad/securitymaster/api/responsejson/passed.log";
			try {

				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
				Date dateobj = new Date();
				FileWriter writer = new FileWriter(path, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);
				bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attributeNo, 3)+  fixedLengthString(key,102)
				+ "\t MSD_ID : \t" + fixedLengthString(msdid, 12) + "  found   :  \t "
						 );
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				ee.printStackTrace();
			}

			
			
		} catch (Exception e) {
			String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
			try {

				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
				Date dateobj = new Date();

				FileWriter writer = new FileWriter(path, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attributeNo, 4)
						+ "\t MSD_ID : \t" + fixedLengthString(msdid, 12) + "  MSDID  not  found   :  \t "
						+ fixedLengthString(key, 200));
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				ee.printStackTrace();
			}
		}

		Reporter.addStepLog("Security/MSDID :" + "<strong>" + msdid + "</strong>");

	}

	@Given("user set Path Parameter {string} as {string} in request url")
	public void user_set_Path_Parameter_as_in_request_url(String pathParam, String msdidPar) {

		response = HttpClientUtils.given().setPathParameter("entityId", msdid).buildUri()
				.setCetificate(".\\\\src\\\\test\\\\resources\\\\ad\\\\securitymaster\\\\api\\\\otherFiles\\\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.23", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
		api_response = response.getBody().asString();
		Reporter.addStepLog("Endpoint :" + "<strong>" + msdid + "</strong>");

	}

	@When("user make a get request method call for {string}")
	public void user_make_a_get_request_method_call_for(String msdid) {
	}

	@Then("user should recieve {int} as response code")
	public void user_should_recieve_as_response_code(Integer int1) {
		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");

	}

	@Then("User verify that PRDB Attribute {string} is available in {string} table in response")
	public void user_verify_that_PRDB_Attribute_is_available_in_table_in_response(String prdbAttribute,
			String prdbtable) {

		PRDBTABLE = prdbtable;
		boolean attributeFound = false;
		String attributeName = null;
		Object attributeValue = null;
		String prdbPath = "$.CustomFields.UBS_PRDB." + prdbtable;

		try {
			Object item = com.jayway.jsonpath.JsonPath.read(api_response, prdbPath);

			if (item instanceof net.minidev.json.JSONArray) {

				String prdbPath2 = prdbPath + "[*]";

				List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(api_response, prdbPath2);

				for (Map<String, String> map : result) {
					for (Map.Entry<String, String> entry : map.entrySet()) {
						attributeName = entry.getKey();

						if (attributeName.equals(prdbAttribute)) {
							attributeFound = true;
							attributeValue = entry.getValue();
							break;
						}
					}
					if (attributeFound == true) {
						break;
					}
				}

			} else if (item instanceof LinkedHashMap) {
				// It's an object
				LinkedHashMap<String, Object> map = com.jayway.jsonpath.JsonPath.read(api_response, prdbPath);
				if (map.containsKey(prdbAttribute)) {
					attributeFound = true;
					attributeValue = map.get(prdbAttribute);
				}

			} else {
				// It's something else, like a string or number
				prdbPath = prdbPath + "." + prdbAttribute;
				attributeValue = com.jayway.jsonpath.JsonPath.read(api_response, prdbPath);
				if (attributeValue != null) {
					attributeFound = true;
				}
			}

			prdb_Attribute = prdbAttribute;
			prdbAttribute_Value = (String) attributeValue.toString();

			if (attributeFound) {
				Reporter.addStepLog("<b>" + "Attribute Name " + "</b>" + prdbAttribute);
				Reporter.addStepLog("<b>" + "Attribute Value : " + "</b>" + attributeValue);
				Reporter.addStepLog("<b>" + "Attribute Found" + "</b>");
				Reporter.addStepLog("<b>" + "Path " + "</b>" + prdbPath);

				// Added for USM-2765 Passed cases in passed.log Report
				/*
				 * String path = "./src/test/resources/ad/securitymaster/api/responsejson/passed.log";
				 *  try {
				 * 
				 * DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss"); Date dateobj = new
				 * Date();
				 * 
				 * FileWriter writer = new FileWriter(path, true); BufferedWriter bufferedWriter
				 * = new BufferedWriter(writer);
				 * 
				 * bufferedWriter.write(df.format(dateobj) +"\t" +" MSDID "+ msdid
				 * +"\t atributeNo : \t "+fixedLengthString(attributeNo,7)+ "  \t  "+prdbtable +
				 * "  "+ "prdbAttributeName : " + " " +fixedLengthString(prdbAttribute,30) +
				 * "\t    Value  : \t " +fixedLengthString(attributeValue.toString(),40));
				 * bufferedWriter.newLine(); bufferedWriter.close(); } catch (IOException ee) {
				 * ee.printStackTrace(); }
				 * 
				 */
			} else {
				Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");
				String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
				try {

					FileWriter writer = new FileWriter(path, true);
					BufferedWriter bufferedWriter = new BufferedWriter(writer);

					bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : "
							+ fixedLengthString(attributeNo, 4) + "\t MSD_ID : \t" + fixedLengthString(msdid, 12)
							+ "  PRDB Attribute not Found : \t  " + prdbtable + "  " + "prdbAttributeName : " + " "
							+ fixedLengthString(prdbAttribute, 40) + "\t" + fixedLengthString(key, 100));
					bufferedWriter.newLine();
					bufferedWriter.close();
				} catch (IOException ee) {
					ee.printStackTrace();
				}
			}

		} catch (Exception e) {
			Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");
			String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
			try {
				FileWriter writer = new FileWriter(path, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attributeNo, 4)
						+ "\t MSD_ID : \t" + msdid + "  PRDB Attribute not Found : \t " + prdbtable + "  "
						+ "prdbAttributeName : " + " " + fixedLengthString(prdbAttribute, 40) + "\t"
						+ fixedLengthString(key, 100));
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				ee.printStackTrace();
			}
		}

		Assert.assertEquals(attributeFound, true, "Attribute not found");
	}

	@Then("User verify that PRDB attribute {string} from table {string} is mapped named as {string} EISL Attribute by schema  {string}")
	public void user_verify_that_PRDB_attribute_from_table_is_mapped_named_as_EISL_Attribute_by_schema(
			String PRDB_attribute, String PRDB_table, String EISL_attribute, String EISL_Path) {

		boolean attributeFound = false;
		String EISLPATH = "$." + EISL_Path;
		String attributeName = null;
		Object attributeValue = null;
		try {
			Object item = com.jayway.jsonpath.JsonPath.read(api_response, EISLPATH);

			if (item instanceof net.minidev.json.JSONArray) {
				isArray = true;
				String EISLPATH2 = EISLPATH + "[*]";
				List<Map<String, String>> result = com.jayway.jsonpath.JsonPath.read(api_response, EISLPATH2);
				for (Map<String, String> map : result) {
					for (Map.Entry<String, String> entry : map.entrySet()) {
						attributeName = entry.getKey();

						if (attributeName.equals(EISL_attribute)) {
							attributeFound = true;
							attributeValue = entry.getValue();
							break;
						}
					}
				}

			} else if (item instanceof LinkedHashMap) {
				// It's an object
				LinkedHashMap<String, String> map = com.jayway.jsonpath.JsonPath.read(api_response, EISLPATH);
				if (map.containsKey(EISL_attribute)) {
					attributeValue = map.get(EISL_attribute);
					attributeFound = true;

				}

			} else {
				// It's something else, like a string or number
				EISLPATH = EISLPATH + "." + EISL_attribute;
				attributeValue = com.jayway.jsonpath.JsonPath.read(api_response, EISLPATH);
				if (attributeValue != null) {
					attributeFound = true;
				}
			}

			if (attributeFound) {
				Reporter.addStepLog("<b>" + "Attribute Name " + "</b>" + EISL_attribute);
				Reporter.addStepLog("<b>" + "Attribute Value : " + "</b>" + attributeValue);
				Reporter.addStepLog("<b>" + "Attribute Found" + "</b>");
				Reporter.addStepLog("<b>" + "Path " + "</b>" + EISLPATH);
			} else {
				Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");
				String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
				try {

					FileWriter writer = new FileWriter(path, true);
					BufferedWriter bufferedWriter = new BufferedWriter(writer);

					bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  :"
							+ fixedLengthString(attributeNo, 6) + "\t" + "  MSDID  " + fixedLengthString(msdid, 12)
							+ "  EISL Attribute not Found :  " + "   \t  " + "EISL_Attribute  : " + " "
							+ fixedLengthString(EISL_attribute, 40) + "         " + fixedLengthString(key, 100));
					bufferedWriter.newLine();
					bufferedWriter.close();
				} catch (IOException ee) {
					ee.printStackTrace();
				}
			}

			String filepath = "./src/test/resources/ad/securitymaster/api/responsejson/passed.log";

			try {

				FileWriter writer = new FileWriter(filepath, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				bufferedWriter.write("Attribute no  : " + fixedLengthString(attributeNo, 4) + "\t MSD_ID : \t"
						+ fixedLengthString(msdid, 12) + "  :  " + PRDB_table + "   \t   "
						+ fixedLengthString(prdb_Attribute, 40) + "\t" + fixedLengthString(prdbAttribute_Value, 40)
						+ "   \t   " + "   EISLAttribute :   " + fixedLengthString(EISL_attribute, 40) + "   \t"
						+ fixedLengthString(attributeValue.toString(), 40) + fixedLengthString(key, 120));
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				ee.printStackTrace();
			}

		} catch (PathNotFoundException e) {
			try {
				String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
				FileWriter writer = new FileWriter(path, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				bufferedWriter.write("Array Attribute  :Path is incorrect  \t" + fixedLengthString(attributeNo, 4)
						+ "\t" + fixedLengthString(msdid, 12) + "  :  " + PRDB_table + "   \t   "
						+ fixedLengthString(prdb_Attribute, 40) + "\t" + fixedLengthString(prdbAttribute_Value, 50)
						+ "   \t   " + "   EISLAttribute :   " + fixedLengthString(EISL_attribute, 40) + "   \t"
						+ fixedLengthString(attributeValue.toString(), 40) + fixedLengthString(key, 120));
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				ee.printStackTrace();
			}

		}

		catch (Exception e) {
			Reporter.addStepLog("<b>" + "Attribute not Found" + "</b>");
			String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
			try {

				FileWriter writer = new FileWriter(path, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attributeNo, 4)
						+ "\t MSD_ID : \t" + msdid + "  EISL Attribute not Found :  " + PRDB_table + "  "
						+ "EISL_Attribute :" + " " + fixedLengthString(EISL_attribute, 40));
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				ee.printStackTrace();
			}
		}

		EISLAttribute = EISL_attribute;
		EISLAttributeValue = attributeValue.toString();
		EISLMapping = EISLPATH;

		Assert.assertEquals(attributeFound, true, "Attribute not found");

		msdid = null;

	}

	@Then("User verify {string} EISL Attribute by schema  {string}")
	public void user_verify_EISL_Attribute_by_schema(String EISL_attribute, String EISL_Path) {
		boolean attributeFound = Pattern.compile(Pattern.quote(EISL_attribute), Pattern.CASE_INSENSITIVE)
				.matcher(api_response).find();
		if (attributeFound) {
			Reporter.addStepLog("<b>" + "Attribute Name " + "</b>" + EISL_attribute);
			Reporter.addStepLog("<b>" + "Attribute Value : " + "</b>" + prdbAttribute_Value);
			Reporter.addStepLog("<b>" + "Attribute Found" + "</b>");
			Reporter.addStepLog("<b>" + "Path " + "</b>" + EISL_Path);

			String filepath = "./src/test/resources/ad/securitymaster/api/responsejson/passed.log";

			try {

				FileWriter writer = new FileWriter(filepath, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);
				bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attributeNo, 4)
						+ "\t MSD_ID : \t" + fixedLengthString(msdid, 12) + "\t  PRDB TABLE :  " + PRDBTABLE
						+ "\t PRDB-Attribute-Name :  " + fixedLengthString(prdb_Attribute, 30)
						+ "\t   PRDB-Attribute-Value :" + fixedLengthString(prdbAttribute_Value, 40)
						+ "\t BIMS Mapping  :" + "   \t   " + "   \t   " + "   EISLAttribute :   "
						+ fixedLengthString(EISL_attribute, 40) + "\t EISL Attribute Value :"
						+ fixedLengthString(prdbAttribute_Value.toString(), 40) + fixedLengthString(EISL_Path, 120));
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				ee.printStackTrace();
			}

		} else {

			Reporter.addStepLog("<b>" + "EISL Attribute not Found in BIMS" + "</b>");
			String path = "./src/test/resources/ad/securitymaster/api/responsejson/failedCase.log";
			try {

				FileWriter writer = new FileWriter(path, true);
				BufferedWriter bufferedWriter = new BufferedWriter(writer);

				bufferedWriter.write(df.format(dateobj) + "\t" + "Attribute no  : " + fixedLengthString(attributeNo, 4)
						+ "\t MSD_ID : \t" + msdid + "  EISL Attribute not Found :  " + PRDBTABLE + "  "
						+ "EISL_Attribute :" + " " + fixedLengthString(EISL_attribute, 40) + "\t"
						+ fixedLengthString(EISL_Path, 120));
				bufferedWriter.newLine();
				bufferedWriter.close();
			} catch (IOException ee) {
				ee.printStackTrace();
			}

			Assert.assertEquals(attributeFound, true, "EISL Attribute not found");

		}
	}

	public static String fixedLengthString(String string, int length) {
		return String.format("%1$" + length + "s", string);
	}

	// GRS Stream

	@Given("user set Query Parameter MSDID as {string} in GRS stream search")
	public void user_set_Query_Parameter_MSDID_as_in_GRS_stream_search(String msd) {

		response = HttpClientUtils.given().buildUri().setQueryParameter("externalId", msd)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

	}

	@When("user hit the find button to search event")
	public void user_hit_the_find_button_to_search_event() {

		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");
		String firstAPIresponse = response.getBody().asString();
		Reporter.addStepLog("Response Body :" + "<strong>" + firstAPIresponse + "</strong>");

	}

	// PRDB stream

	@Given("user set Query Parameter {string} as {string}")
	public void user_set_Query_Parameter_as(String querParm1, String qValue) {

		response = HttpClientUtils.given().buildUri().setQueryParameter(querParm1, vendorId)
				.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
				.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

		Reporter.addStepLog("QueryParameter1 :" + "<strong>" + querParm1 + "</strong> and ");
		Reporter.addStepLog("Value :" + "<strong>" + vendorId + "</strong>");
		key = qValue;

	}

	@Then("user fetch VendorId from FTS API response and naviagte to PRDB stream")
	public void user_fetch_VendorId_from_FTS_API_response_and_naviagte_to_PRDB_stream() {
		String firstAPIresponse = response.getBody().asString();
		try {
			vendorId = com.jayway.jsonpath.JsonPath.read(firstAPIresponse, "$.[0].Values.VENDOR_ID");

		} catch (Exception e) {

		}
		Reporter.addStepLog("vendorId :" + "<strong>" + vendorId + "</strong>");

	}

	@Then("user receive prdb event table")
	public void user_receive_prdb_event_table() {

		int statusCode = response.getStatusCode();
		Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
		Assert.assertEquals(statusCode, 200, "Status code returned");
		String firstAPIresponse = response.getBody().asString();
		Reporter.addStepLog("Response Body :" + "<strong>" + firstAPIresponse + "</strong>");

	}

}
