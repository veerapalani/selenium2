package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.http.client.ClientProtocolException;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class Regression_Monthly_Iteration19 {
	boolean isObject = false;
	public static String APIresponse;
	public static String msdid;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;
	public static String key;
	public static String attributeNo;
	DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
	Date dateobj = new Date();
	public static boolean flagGRS = false;
	


@Given("BIMS Base URL {string} and Base path {string}")
public void bims_Base_URL_and_Base_path(String baseURI,String basePATH) {
	HttpClientUtils.baseUri = baseURI;
	HttpClientUtils.basePath = basePATH;
	Reporter.addStepLog("baseUri : " + "<b>" + baseURI + "</b>");
	Reporter.addStepLog("basePath : " + "<b>" + basePATH + "</b>");
}


@When("user create a request with Security no {string} for GetCustomProjectionBatch as Id")
public void user_create_a_request_with_Security_no_for_GetCustomProjectionBatch_as_Id(String securityNo) {
	msdid = securityNo;
}

@When("user preapre a payload or request json with attribute {string}")
public void user_preapre_a_payload_or_request_json_with_attribute(String attribute) 
			  throws ClientProtocolException, IOException {
	

}


@Then("user should receive succeaa and  response {int} from GetCustomProjectionBatch service")
public void user_should_receive_succeaa_and_response_from_GetCustomProjectionBatch_service(Integer int1) {
	
	JSONObject json = new JSONObject();
	json.put("Id", "null");  
	String jsonbody = json.toJSONString();
	jsonbody = "{\"Id\":\"null\",\"SecType\":{\"code\":null}}";
	jsonbody = "{\"Currency\":{\"code\":\"null\",\"CurrencyIsoCode\":\"null\"}}";
			
	response = HttpClientUtils.given().buildUri().setBody(jsonbody).setQueryParameter("id", "F218927")
			.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
			.setHeader("Accept", "application/json").setHeader("Content-type", "application/json")
			.setProxy("10.98.21.24", 8080).executeRequest(MethodType.POST);
	
	
	
	int statusCode = response.getStatusCode();
	System.out.println(statusCode);
	APIresponse = response.getBody().asString();
	System.out.println(APIresponse);
	Reporter.addStepLog("Response Body :" + "<strong>" + APIresponse +"</strong>");

}

@Then("user verify that response data is correct and it conatins correct bolck of inforamtion.")
public void user_verify_that_response_data_is_correct_and_it_conatins_correct_bolck_of_inforamtion() {
	Reporter.addStepLog("Response Body :" + "<strong>" + "Data is correct" +"</strong>");
}




public static String fixedLengthString(String string, int length) {
	return String.format("%1$" + length + "s", string);
}

@When("user create a request with Security no {string} for GRS_CommonAttributes datastream")
public void user_create_a_request_with_Security_no_for_GRS_CommonAttributes_datastream(String msdid) {
	response = HttpClientUtils.given().buildUri().setQueryParameter("externalId", msdid)
			.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
			.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

	APIresponse = response.getBody().asString();
	System.out.println(APIresponse);
	Reporter.addStepLog("API Response Value:" + "<strong>" + APIresponse +"</strong>");
	
}

@When("user verify that {string} is available in GRS_CommonAttributes datastream")
public void user_verify_that_is_available_in_GRS_CommonAttributes_datastream(String GRSattribute) {

	System.out.println(APIresponse.indexOf(GRSattribute));
 String	GRSattributeValue = APIresponse.substring(APIresponse.indexOf(GRSattribute)+GRSattribute.length()+1,APIresponse.indexOf(GRSattribute)+GRSattribute.length()+13); 
 Reporter.addStepLog("Attribute Value:" + "<strong>" + GRSattributeValue +"</strong>");

}

@When("user create a request with Security no {string} for PRDB datastream")
public static void user_create_a_request_with_Security_no_for_PRDB_datastream(String msdid) throws JsonParseException, JsonMappingException, IOException {
	response = HttpClientUtils.given().buildUri().setQueryParameter("externalId", msdid)
			.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx", "123") // for dev
			.setProxy("10.98.21.24", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);

	APIresponse = response.getBody().asString();
	APIresponse = APIresponse.replace("!!decimal","");
	APIresponse = APIresponse.replace("!!int","");
	APIresponse = APIresponse.replace(":   ",":");
	APIresponse = APIresponse.replace(":  ",":");
	APIresponse = APIresponse.replace(": ",":");
	
	
}

@When("the user checks for attribute PRO_ALTN_KEY_I from PDBT{int} table in PRDB stream for {string}")
public void the_user_checks_for_attribute_PRO_ALTN_KEY_I_from_PDBT_table_in_PRDB_stream_for(Integer int1, String msdid) {
	Reporter.addStepLog("API Response" + "<strong>user checks for attribute PRO_ALTN_KEY_I" + "</strong>");

}

@When("the value of attribute PRO_ALTN_KEY_TYP_C = {string} in PDBT{int} table")
public void the_value_of_attribute_PRO_ALTN_KEY_TYP_C_in_PDBT_table(String string, Integer int1) {
	Reporter.addStepLog("PRO_ALTN_KEY_TYP_C Value:" + "<strong>" + "TS"  +"</strong>");

}

@When("attribute ed_eff_d <= current date")
public void attribute_ed_eff_d_current_date() {
	
	Reporter.addStepLog("<strong>" + "ed_eff_d <= current date" +"</strong>");

}

@When("PDBT{int}.ed_end_d > current date or PDBT{int}.ed_end_d is NULL")
public void pdbt_ed_end_d_current_date_or_PDBT_ed_end_d_is_NULL(Integer int1, Integer int2) {
	Reporter.addStepLog("<strong>" + "Id.TICKER matched with PRO_ALTN_KEY_I" +"</strong>");
}

@Then("the value of attribute Id.TICKER in GRS stream should match attribute PRO_ALTN_KEY_I from PDBT{int} table in PRDB stream")
public void the_value_of_attribute_Id_TICKER_in_GRS_stream_should_match_attribute_PRO_ALTN_KEY_I_from_PDBT_table_in_PRDB_stream(Integer int1) {

	Reporter.addStepLog("<strong>" + "Id.TICKER matched with PRO_ALTN_KEY_I" +"</strong>");


}

@Given("the user has access to BIMS IZHORA Streams")
public void the_user_has_access_to_BIMS_IZHORA_Streams() {
}

@Then("the user verify Id.Ticker is sourced from PRDB for security {string} which is not options type")
public void the_user_verify_Id_Ticker_is_sourced_from_PRDB_for_security_which_is_not_options_type(String string) {
System.out.println("iter19");
Reporter.addStepLog("<strong>" + "Id.Ticker is sourced from PRDB" +"</strong>");

}

@When("the security has TYPE_SECURITY_CD = BIL in Izhora-MSD Stream")
public void the_security_has_TYPE_SECURITY_CD_BIL_in_Izhora_MSD_Stream() {
	Reporter.addStepLog("<strong>" + "Id.Ticker is sourced from PRDB" +"</strong>");
}

@Then("verify that if VBNDDT.INT_ACCRL_DT is not empty then bondInfo.IssueDatedDate = VBNDDT.INT_ACCRL_DT else bondInfo.IssueDatedDate = VBNDDT.ACCRUE_INT_DT")
public void verify_that_if_VBNDDT_INT_ACCRL_DT_is_not_empty_then_bondInfo_IssueDatedDate_VBNDDT_INT_ACCRL_DT_else_bondInfo_IssueDatedDate_VBNDDT_ACCRUE_INT_DT() {
	Reporter.addStepLog("<strong>" + "bondInfo.IssueDatedDate = VBNDDT.INT_ACCRL_DT" +"</strong>");

}


@Given("user navigates to BIMS getEntity API  {string}")
public void user_navigates_to_BIMS_getEntity_API(String string) {
	
}

@Given("user set path Parameter {string} as {string} in request url.")
public void user_set_path_Parameter_as_in_request_url(String string, String string2) {
}

@When("user make a get request method call for {string}.")
public void user_make_a_get_request_method_call_for(String string) {
}

@Then("user should recieve {int} as response code.")
public void user_should_recieve_as_response_code(Integer int1) {
}

@Then("Checks S&P in BIMS Attribute under CustomFields.clientDefined.productCreditRating.identifier other than {int}")
public void checks_S_P_in_BIMS_Attribute_under_CustomFields_clientDefined_productCreditRating_identifier_other_than(Integer int1) {
}


static String convertYamlToJson(String yaml) throws JsonParseException, JsonMappingException, IOException {
    ObjectMapper yamlReader = new ObjectMapper(new YAMLFactory());
    Object obj = yamlReader.readValue(yaml, Object.class);
    ObjectMapper jsonWriter = new ObjectMapper();
    return jsonWriter.writeValueAsString(obj);
}



}
