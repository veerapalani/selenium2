package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RemoveReferenceAttribute {
	
	public static void main(String[] args) throws Exception {
		
		
		String allFFFile = "./src/test/resources/ad/securitymaster/api/responsejson/PRDB-ALL-FF.log";
		String refFile = "./src/test/resources/ad/securitymaster/api/responsejson/refTable.log";
		String finalPRDBFile = "./src/test/resources/ad/securitymaster/api/responsejson/PRDB1400.log";
				
		
		File inputFile = new File(allFFFile);
		File comparetoRefFile = new File(refFile);
		File finalFile = new File(finalPRDBFile);
		
		
		   Path file_path1 = Paths.get("./src/test/resources/ad/securitymaster/api/responsejson", "PRDB-ALL-FF.log");
		   Path file_path2 = Paths.get("./src/test/resources/ad/securitymaster/api/responsejson", "refTable.log");

		   List<String> fileContent = new ArrayList<>(Files.readAllLines(file_path1, StandardCharsets.UTF_8));
		   
		List<String> refFileContent = new ArrayList<>(Files.readAllLines(file_path2, StandardCharsets.UTF_8));

		
	
		for (int i = 0; i < refFileContent.size(); i++) {
			String refAtttibute = refFileContent.get(i);
			
			try {
				for (int j = 0; i < fileContent.size(); j++) {
				    if (fileContent.get(j).contains(refAtttibute)) {
				        fileContent.set(j, "# MSD Comman attribute");
				        break;
				    }
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				try {
					
					
		            FileWriter writer = new FileWriter(finalPRDBFile, true);
		            BufferedWriter bufferedWriter = new BufferedWriter(writer);
		 
		            bufferedWriter.write("MSD Atttibute :  "+refAtttibute +" "+e.getMessage());
		            bufferedWriter.newLine();
		            bufferedWriter.close();
		        } catch (IOException ee) {
		            ee.printStackTrace();
		        }
				
			}
		}
		
		
		

		Files.write(file_path1, fileContent, StandardCharsets.UTF_8);
		
		
	}
	

	
	
	

}
