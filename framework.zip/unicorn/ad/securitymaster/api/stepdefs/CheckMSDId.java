package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class CheckMSDId {
	
	
	public static String APIresponse;
	public static RetriveResponse response;
	public static String HttpbaseURI;
	public static String HttpbasePATH;
	public static RequestBuilder requestBuilder;

	boolean testflag = false;
	File[] listOfFiles;
	List<String> listofrecords = new ArrayList<String>();;
	String filename;
	LinkedHashMap<String, String> msdMap = new LinkedHashMap<String, String>();
	
	
	@Given("user has access to GRS_Archive excel file named {string}.")
	public void user_has_access_to_GRS_Archive_excel_file_named(String string) throws FileNotFoundException {
		
		String excelFilePath = "./src/test/resources/ad/securitymaster/api/excel/Archived_GRS_2021-12-08T16_06_52.xlsx";
		try
        {
            FileInputStream file = new FileInputStream(new File(excelFilePath));
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            XSSFSheet sheet = workbook.getSheetAt(0);
            
            for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
            	Row  row = sheet.getRow(rowIndex);
            	  if (row != null) {
            	    Cell cell = row.getCell(2);
            	    if (cell != null) {
            	    	String msdId = getCellValueAsString(cell,cell.getCellType());
                        msdMap.put(msdId, "Not");
            	    }
            	  }
            	}
            
        }
	catch (Exception e) {
		// TODO: handle exception
	}
	}
		   
		   
					
	
		

private static String getCellValueAsString(Cell cell, CellType cellType)
{
    switch (cellType)
    {
        case NUMERIC:
        	int result = (int)cell.getNumericCellValue();
            return String.valueOf(result);
        case BOOLEAN:
            return String.valueOf(cell.getBooleanCellValue());
        case FORMULA:
            return getCellValueAsString(cell, cell.getCachedFormulaResultType());
        case STRING:
            return cell.getStringCellValue();
        default:
            return cell.getStringCellValue();
    }
}




@Given("user has acess to BIMS getEntity API having Base URL {string} and Base path {string}")
public void user_has_acess_to_BIMS_getEntity_API_having_Base_URL_and_Base_path(String baseUri, String basePath) {
	HttpClientUtils.baseUri = baseUri;
	HttpClientUtils.basePath = basePath;
}

@Given("user set path Parameter {string} as {string} in request url")
public void user_set_path_Parameter_as_in_request_url(String querParam, String value) {
}



	
private String getAPIResponse(String msdID) {

	response = HttpClientUtils.given().setPathParameter("entityId", msdID).buildUri()
			.setCetificate(".\\src\\test\\resources\\ad\\securitymaster\\api\\otherFiles\\br_localhost_pass_123.pfx",
					"123") // for dev
			.setProxy("10.98.21.23", 8080).setAcceptType("application/json").executeRequest(MethodType.GET);
	int statusCode = response.getStatusCode();
	Reporter.addStepLog("QueryParameter1 :" + "<strong>" + "entityId" + "</strong>" + "\t and \t " + " Value :"
			+ "<strong>" + msdID + "</strong>");
	Reporter.addStepLog("StatusCode :" + "<strong>" + statusCode + "</strong>");
	return statusCode + "";

}

	@When("user pick up a security and make a get API call for {string}.")
	public void user_pick_up_a_security_and_make_a_get_API_call_for(String querParm1) {
		
		 for (String msdId : msdMap.keySet())
	        {
	          String value =   getAPIResponse(msdId);
	            msdMap.put(msdId, value);
	        }

		
	
	}

	@Then("user verify that response code should be {int} means security not found.")
	public void user_verify_that_response_code_should_be_means_security_not_found(Integer int1) {
		
	}


}
