package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import junit.framework.Assert;
import qa.framework.utils.Reporter;

public class USM_3272_3550_StepDef {

	boolean testflag = true;
	String filePath = "D:\\Users\\GuptaVi\\Documents\\ExtractFile-MSD\\out";
	
	@Given("user has access to MSD Extention file and splitted file as {string}")
	public void user_has_access_to_MSD_Extention_file_and_splitted_file_as(String filename) {
		filePath = filePath + "\\" + filename;
		Reporter.addStepLog("<b>File " + filename + "</b>");

	}

	@Then("user verify in file that line containg MSDBCCL data  has value as {string}  for coloum {string}.")
	public void user_verify_in_file_that_line_containg_MSDBCCL_data_has_value_as_for_coloum(String attribute,
			String value) {

		String line;
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String msd_id = null;
			while ((line = br.readLine()) != null) {
				try {
					msd_id = line.substring(135, 142);
					if (line.contains("MSDBCCL")) {
						String BIMS_CLASS_TYPE_CD_value = line.substring(158, 161);
						if(BIMS_CLASS_TYPE_CD_value.equals("EDC")) {
							Reporter.addStepLog(" For MSD_ID   " + "<strong>" + msd_id + "</strong>"
									+ "   Value of BIMS_CLASS_TYPE_CD attribute is " + "<b> EDC </b> found under column BIMS_CLASS_TYPE_CD in file  .");
							

						} else {
							testflag = false;
							Assert.assertEquals(
									"Value of BIMS_CLASS_TYPE_CD attribute is EDC found in file Checked for  "
											+ msd_id,
									true, testflag);
							
							
						}
					}

				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
