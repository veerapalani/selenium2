package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.JSONException;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;

import io.cucumber.java.en.And;
import qa.framework.utils.CommonAPISteps;
import qa.framework.utils.Reporter;


public class FullLoadFileValidation {
	
	String fileResponse;
	String apiResponse;

	@And("^user validates the payload in full load file for security (.+)$")
	public void user_validates_the_payload_in_full_load_file_for_security(String msdid) throws FileNotFoundException {

		String filepath = "D:\\Users\\KhandareM\\Broadridge\\Security Master\\MCR 4\\Sprint 29\\USM-2133\\BIMS_FullLoad_AllData_09-16-2020\\BIMS_FullLoad_AllData_09-16-2020.json";

		FileReader fr = new FileReader(filepath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		try {
			while ((line = br.readLine()) != null) {
				if (line.contains(msdid)) {
					fileResponse = line;
					Reporter.addStepLog("<b>Record is available in the Full load file for security</b> "+ msdid );				
				} 
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		CommonAPISteps link = new CommonAPISteps();
		if (fileResponse.length() > 0) {
		String fileName = link.responseFile(fileResponse);			
		String html="<lable><font color=#1E90FF>Click on link to see Response</font></lable>"+
		"<a href=\""+fileName+"\" target=\"_blank\" style=\"float:right\"><img src=\"core-image-hyper-link.png\" style=\"background-color:aliceblue\"></a>";
			
		Reporter.addStepLog(html);			
		}
	}
	
	
	@And("^user performs comparison between full load file and API response$")
    public void user_performs_comparison_between_full_load_file_and_api_response() throws JSONException {
		
		apiResponse = ValidatePRDBandEISLAttributeStepdef.responseBody;
		
		JSONAssert.assertEquals(apiResponse, fileResponse, JSONCompareMode.LENIENT);
		Reporter.addStepLog("<b>Full Load File record is matching with API response </b>");
		
	}

}
