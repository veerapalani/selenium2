package qa.unicorn.ad.securitymaster.api.stepdefs;

import java.util.List;

import org.json.simple.JSONObject;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Reporter;

public class MultiplevaluesIdentifierSearch {
	String APIresponse;
	JsonPath jsonresponse;
	String msdid;
	String vendorID;
	String pwSecId2;
	String pwSecIdnentifier;
	RetriveResponse response;
	String HttpbaseURI;
	String HttpbasePATH;

	
	@Given("API Base URL {string} and Base path {string}")
	public void api_Base_URL_and_Base_path(String baseURI, String basePATH) {
	   
		HttpbaseURI = baseURI;
		HttpbasePATH = basePATH;
			}

	@When("user send post request with json data as pwSecurityIdentifier with value {string}")
	public void user_send_post_request_with_json_data_as_pwSecurityIdentifier_with_value(String pwsecId) {
		
		pwSecIdnentifier = pwsecId;
		JSONObject json = new JSONObject();
		json.put("pwSecurityIdentifier", pwsecId);  
		String jsonbody = json.toJSONString();
				
		HttpClientUtils.baseUri = HttpbaseURI;
		HttpClientUtils.basePath = HttpbasePATH;
		response = HttpClientUtils.given().setBody(jsonbody)
				.setCetificate("D:\\Users\\GuptaVi\\ALL\\br_localhost_pass_123.pfx", "123")
				.setHeader("Accept", "application/json").setHeader("Content-type", "application/json")
				.setProxy("10.98.21.24", 8080).executeRequest(MethodType.POST);
		
		Reporter.addStepLog("pwSecurityIdentifier : "+"<b>"+ pwSecIdnentifier+  "</b>" );

	}

	@Then("user should get response {int}")
	public void user_should_get_response(Integer int1) {
		int status = response.getStatusCode();
		APIresponse = response.getBody().asString();
		Reporter.addStepLog("status : "+"<b>"+ status+  "</b>" );
		Reporter.addStepLog("Response : "+"<b>"+ APIresponse+  "</b>" );
	
	}

	@Then("user should get {string} and {string} attribute value in response body")
	public void user_should_get_and_attribute_value_in_response_body(String string, String string2) {
		
		msdid = "$.[0].EntityId";
	    vendorID = "$.[0].Values.VENDOR_ID";
		
		msdid = com.jayway.jsonpath.JsonPath.read(APIresponse, msdid);
		   
		   System.out.println(msdid);
		   Reporter.addStepLog("MSD_ID : "+"<b>"+ msdid+  "</b>" );
		   
		   vendorID = com.jayway.jsonpath.JsonPath.read(APIresponse, vendorID);
		   
		   System.out.println(vendorID);
		   Reporter.addStepLog("VENDOR_ID : "+"<b>"+ vendorID+  "</b>" );
		   
		   
	}
	
	@Then("user compare msdid from respnse with expected msdid as value {string}")
	public void user_compare_msdid_from_respnse_with_expected_msdid_as_value(String expectedMsdid) {
		
		Reporter.addStepLog("Actual MSD_ID : "+"<b>"+ msdid+  "</b>" );
		Reporter.addStepLog("Expected MSD_ID : "+"<b>"+ expectedMsdid +  "</b>" );
		
	}
	
	@Then("user compare venderID from resonse with expected vendorId value {string}")
	public void user_compare_venderID_from_resonse_with_expected_vendorId_value(String expectedVandorID) {
		  Reporter.addStepLog("VENDOR_ID : "+"<b>"+ vendorID+  "</b>" );
		 Reporter.addStepLog("Expected VENDOR_ID : "+"<b>"+ expectedVandorID+  "</b>" );
		
	}

	@Then("user create another request for Base URL {string} and Base path {string}")
	public void user_craete_a_request_for_Base_URL_and_Base_path(String baseuri, String basepath) {   
		   HttpClientUtils.baseUri = baseuri;
			HttpClientUtils.basePath = basepath;
			
			response = HttpClientUtils.given()
			.setPathParameter("entityId", msdid)
			.setCetificate("D:\\Users\\GuptaVi\\ALL\\br_localhost_pass_123.pfx", "123")
			.setProxy("10.98.21.24", 8080)
			.executeRequest(MethodType.GET);
			
			Reporter.addStepLog("baseUri : "+"<b>"+ baseuri+  "</b>" );
			Reporter.addStepLog("basePath : "+"<b>"+ basepath+  "</b>" );

			
			
			
		   
	}

	@Then("user send get request and should  receive response {int}")
	public void user_send_get_request_and_should_receive_response(Integer int1) {

		int status = response.getStatusCode();
		APIresponse = response.getBody().asString();
		
		Reporter.addStepLog("Endpoint (entityId) :<b>" + msdid+"</b>");
		
		Reporter.addStepLog("<strong>API Response : </strong>" + APIresponse);
		
		System.out.println(APIresponse);
	}

	@Then("response body should contain pwSecurityIdentifier value and venderId value")
	public void user_should_get_pwSecurityIdentifier_value_and_venderId_value() {
		String pwses1 = "$.clientDefined.backbridge.pwSecurityIdentifier ";
		String msdid = "$.[0].EntityId";
		String vendorID = "$.Id.VENDOR_ID";
		
		
		List<String> pwdSecIdslist =  com.jayway.jsonpath.JsonPath.read(APIresponse, "$.CustomFields.clientDefined.backbridge[*].pwSecurityIdentifier");
		 System.out.println("pwdSecIds: " + pwdSecIdslist.toString()); 
		  
		  Reporter.addStepLog("List of pwSecurityIdentifiers : "+"<b>"+ pwdSecIdslist.toString()+  "</b>" );
		  
		  if(pwdSecIdslist.contains(pwSecIdnentifier)) {
			  Reporter.addStepLog("Found pwSecurityIdentifiers : "+"<b> Yes </b>" );
			  for(String str:pwdSecIdslist) {
				  if(str.equals(pwSecIdnentifier)) {
					  pwSecId2 = str;
					  Reporter.addStepLog("pwSecurityIdentifier value : "+"<b>"+str+"</b>" );  
				  }
				  
			  }
		  }
		  else {
			  Reporter.addStepLog("Found pwSecurityIdentifiers : "+"<b> No </b>" );
		  }
		  
		  
		   
		   

		  vendorID =  com.jayway.jsonpath.JsonPath.read(APIresponse, vendorID);
		  System.out.println("vendorID: " + vendorID); 
		  Reporter.addStepLog("VENDOR_ID : "+"<b>"+ vendorID+  "</b>" );
		   
		   

		  
	}

	@Then("user compare api response pwSecurityIdentifier value as actual value with given pwSecurityIdentifier as expected value")
	public void user_compare_api_response_pwSecurityIdentifier_value_as_actual_value_with_given_pwSecurityIdentifier_as_expected_value() {
		Reporter.addStepLog("Actual pwSecIdnentifier : "+"<b>"+ pwSecId2+  "</b>" );
		Reporter.addStepLog("Expected pwSecIdnentifier : "+"<b>"+ pwSecIdnentifier +  "</b>" );
	}

	@Then("user compare api response venderId value  as actual value with {string} as expected value")
	public void user_compare_api_response_venderId_value_as_actual_value_with_as_expected_value(String vendorid) {    // Write code here that turns the phrase above into concrete actions
		Reporter.addStepLog("Actual VENDOR_ID : "+"<b>"+ vendorid+  "</b>" );
		Reporter.addStepLog("Expected VENDOR_ID: "+"<b>"+ vendorID +  "</b>" );
	}
	
	
	
	
	
	
	
}
