package qa.unicorn.ad.securitymaster.api.stepdefs;

import static net.javacrumbs.jsonunit.JsonAssert.assertJsonEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;

import com.jayway.jsonpath.JsonPath;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.utils.RestApiUtils;

@SuppressWarnings("deprecation")

public class ValidateBIMSPRDBAttributes {

	String APIresponse;
	int InvalidStatuscode = 400;
	int InvalidStatuscode404 = 404;
	int Statuscode = 200;
	Response response;

	GenericUtilForSecurityMaster utilUSM = new GenericUtilForSecurityMaster();
	BufferedReader stdInput;
	BufferedReader stdError;
	String contentsofile;
	String attribute;
	String grsjsonpathval;
	Object actualValue = null;
	public List<String> listsecurity = new ArrayList<String>();
	public Map<Object, List<Object>> mapattrGRS = new HashMap<Object, List<Object>>();
	public Map<Object, List<Object>> securityAttrbtlist = new HashMap<Object, List<Object>>();
	Date d = new Date();
	public static boolean fileCreated = false;

	String headerNamesExcel[] = { "Attribute_Name", "GRS_MAPPED_PATH", "SecurityID", "APIattributeResponseValue",
			"DataType", "Comment" };

	String excelFilePath;
	String securityListEXLfile;
	String qaAutmnValidnExcelShtPath;
	String apicurllnk = "curl -X GET \"https://ppapp.pp.gtoqa.bfsaws.net/Peter_Unicorn/Entity/GetSnapshot/{VENDOR_ID/MSD_ID}\" -H \"Accept: application/json\" -H \"Content-Type: application/json\"  -k --cert D:\\RaghuH\\usm275\\client_localhost.pem:123456";
	String outputdata[] = new String[10];
	String dbKey1 = "CurlCommandAPILink";
	String featureIDs = "AD_SM_API_ExposeBimsPrdbAttributes";
	int rowcount;
	int cellcount;
	File file;
	String[] command = new String[3];
	String deletfilecmd = "d: && cd D:\\RaghuH\\Sprint13JSON && del output2.json";
	Process proc;

	@Given("^the security list file \"([^\"]*)\" attribute name (.+) and curl API \"([^\"]*)\" command and OutPutFile \"([^\"]*)\"$")
	public void the_security_list_file_something_attribute_name_and_curl_api_something_command_and_outputfile_something(
			String securityIdfname, String attributename, String dbKey, String outputValidationFileName)
			throws Throwable {

		String curdir = System.getProperty("user.dir");
		System.out.println(curdir);
		excelFilePath = curdir + "\\src\\test\\resources\\ad\\securitymaster\\api\\excel\\";
		System.out.println(securityIdfname + attributename + dbKey);
		qaAutmnValidnExcelShtPath = excelFilePath + outputValidationFileName;
		securityListEXLfile = excelFilePath + securityIdfname;
		outputdata[0] = attributename;
		// String apicurllnk = Action.getTestData(dbKey);
//			 List<DBRowTO> data = SQLDriver.getData(featureIDs);
//			 String apicurllnk = Action.getValue(dbKey, data);
		// String columnName="SecurityIDS";

		System.out.println("path of security excel file--PATH-----" + securityListEXLfile);

		ExcelUtils objExlUtils = new ExcelUtils(ExcelOperation.LOAD, securityListEXLfile);
		XSSFSheet sheet1 = objExlUtils.getSheet("Sheet1");
		rowcount = objExlUtils.getRowCount(sheet1);
		System.out.println("excel path security:" + securityListEXLfile);
		System.out.println("rowcount:-----------" + rowcount);
		for (int row = 1; row < rowcount; row++) {
			String var = objExlUtils.getStringCellData(sheet1, row, 0);
			// ExcelUtil.getStringCellData(row, 0);
			listsecurity.add(var);
			System.out.println(var);
		}

		objExlUtils.closeWorkBook();

	}

//When user open API url link with "{VENDOR_ID/MSD_ID}" as parameter and user checks API response with <GRS_MAP_Field>
	@When("^user open API url link with \"([^\"]*)\" as parameter and user checks API response with (.+)$")
	public void user_open_api_url_link_with_something_as_parameter_and_user_checks_api_response_with(String msdidstr,
			String grsmapfield) throws Throwable {
		System.out.println("Step2");
		String cmnd3;
		String tablepath;
		outputdata[1] = grsmapfield;
		System.out.println(msdidstr + "------" + grsmapfield);
		grsjsonpathval = "$." + grsmapfield.replace(':', '.');
		tablepath = GenericUtilForSecurityMaster.pathsplittilltablename(grsmapfield);
		System.out.println(tablepath + "------" + grsjsonpathval);

		for (String secrty : listsecurity) {
			int length1;
			String updatedcmd = apicurllnk.replace(msdidstr, secrty);
			System.out.println("after change" + updatedcmd);
			cmnd3 = "c: && cd C:\\Program Files\\Git\\mingw64\\bin && " + updatedcmd;
			System.out.println("====" + cmnd3);
			command[0] = "cmd";
			command[1] = "/c";
			command[2] = cmnd3;
			proc = Runtime.getRuntime().exec(command);
			stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));

			stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

			// Read the output from the command:
			System.out.println("Here is the standard output of the command:\n");
			try {
				boolean isarray;
				contentsofile = stdInput.readLine();

				System.out.println("============1234" + contentsofile);
				try {
					List<Object> result = JsonPath.read(contentsofile, tablepath + "[*]." + outputdata[0]);
					length1 = result.size();
					System.out.println(length1);
					// length1 = JsonPath.read(contentsofile,tablepath + ".length()");
				} catch (Exception e) {
					System.out.println(e);
					length1 = 0;
				}
				System.out.println("length of table array" + length1);
				if (length1 == 0) {
					actualValue = JsonPath.read(contentsofile, grsjsonpathval);
				}

				else {
					List<Object> result = JsonPath.read(contentsofile, tablepath + "[*]." + outputdata[0]);
					System.out.println(result);
					String setofvalues = null;
					int i = 0;
					for (Object obj : result) {
						if (i == 0) {
							setofvalues = "Value-" + i + obj.toString() + "  ";
						} else {
							setofvalues = setofvalues + "Value" + i + "=" + obj.toString() + "  ";
						}

						i++;
						if (!obj.toString().isEmpty()) {
							actualValue = obj.toString();
							break;
						}
					}

					System.out.println("value:" + actualValue);
				}

				System.out.println("============1234" + contentsofile);

			}

			catch (Exception e) {
				System.out.println("try- cattch block--2" + e);
			}

			System.out.println("============1234" + contentsofile);
			System.out.println(actualValue);
			outputdata[2] = secrty;
			outputdata[3] = String.valueOf(actualValue);

			if (actualValue != null) {
				System.out.println("inside break condition--");
				break;
			}
			System.out.println("Step3");

		}
	}

	@Then("^check BIMS GRS field should be available in API response body$")
	public void check_bims_grs_field_should_be_available_in_api_response_body() throws Throwable {
		try {
			System.out.println("actual vaue is---==" + actualValue);
			String reportMsg = "verified for " + actualValue.toString();
			System.out.println(reportMsg);
			// Reporter.addStepLog(reportMsg);
			Assert.assertNotNull(actualValue,
					actualValue + "error: BIMS field contains value its should not be null---");
		} catch (Exception e) {
			System.out.println(e);
		}

		System.out.println("Step4");

	}

	@And("^check BIMS GRS field in API response should be checked for valid data length and data type (.+) and (.+)$")
	public void check_bims_grs_field_in_api_response_should_be_checked_for_valid_data_length_and_data_type_and(
			String datatype, String datalength) throws Throwable {
		ExcelUtils objExlUtls = null;
		int actdatalen = -1;
		if (actualValue == null) {
			outputdata[5] = "FAIL";
			outputdata[4] = datatype;

		} else {
			actdatalen = actualValue.toString().length();

			outputdata[4] = datatype;
			if (actdatalen <= Integer.parseInt(datalength)) {
				outputdata[5] = "PASS";
			} else {
				outputdata[5] = "FAIL";
			}
		}

		// Write data into excel outputfile in 6 headers columns
		// 1.Attributename 2.GRS Mapping 3.SecurityID(MSD_ID/VENDOR_ID)
		// 4.APIResponsedata 5.DataType 6.Comment

		System.out.println(qaAutmnValidnExcelShtPath);
		if (fileCreated == false) {
			objExlUtls = new ExcelUtils(ExcelOperation.CREATE, qaAutmnValidnExcelShtPath);
			objExlUtls.createSheet("Sheet1");
			fileCreated = true;
		} else {
			objExlUtls = new ExcelUtils(ExcelOperation.LOAD, qaAutmnValidnExcelShtPath);
		}
		XSSFSheet sheet = objExlUtls.getSheet("Sheet1");

//		XSSFWorkbook wb = ExcelUtil.setExcelFile(qaAutmnValidnExcelShtPath);
//		XSSFSheet sheet = ExcelUtil.setSheet("Sheet1");

		for (int cellnum = 0; cellnum < headerNamesExcel.length; cellnum++) {
			objExlUtls.setCellData(sheet, 0, cellnum, headerNamesExcel[cellnum]);
			// ExcelUtil.setCellData(0, cellnum, headerNamesExcel[cellnum]);
		}
		rowcount = objExlUtls.getRowCount(sheet);
		System.out.println("row count of validation excel sheet---" + rowcount);
		cellcount = objExlUtls.getCellCount(sheet, 0);
		System.out.println("row count:" + rowcount + "  column coount " + cellcount);
		for (int cellnum = 0; cellnum < cellcount; cellnum++) {
			objExlUtls.setCellData(sheet, rowcount, cellnum, outputdata[cellnum]);
		}
		System.out.println(outputdata[0] + " Attribute " + " Data is written into file");
		if (datatype.equalsIgnoreCase("TIMESTAMP")) {
			String result = utilUSM.isTimeStampValid(actualValue.toString());
			System.out.println(result);
			Assert.assertTrue(result.equalsIgnoreCase("true"), "Error-- The Given TimeStamp" + actualValue.toString()
					+ " is not matching with standard Timestamp yyyy-MM-dd HH:mm:ss.SSSSSS ");
		} else {
			Assert.assertTrue(actdatalen <= Integer.parseInt(datalength),
					"ERROR:The Datalength of BIMS field is more than specifiedin API  response is more");
		}
		objExlUtls.closeWorkBook();

	}

	@Given("^user has Swagger BIMS API link 'APILink' and 'BIMS GRS MAP' file \"([^\"]*)\"$")
	public void user_has_swagger_bims_api_link_apilink_and_bims_grs_map_file_something(String strArg1)
			throws Throwable {

		RestApiUtils.requestSpecification = null;
		RestAssured.baseURI = "http://10.140.201.221:49700/";
		RestAssured.basePath = "Peter_Unicorn/";
		System.out.println("1");
	}

	@When("^user opens API url Link with Valid msdId (.+) as parameter and user checks API response$")
	public void user_opens_api_url_link_with_valid_msdid_as_parameter_and_user_checks_api_response(String validmsdid)
			throws Throwable {

		String endpoint = "Entity/GetSnapshot/" + validmsdid;
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(endpoint);
		System.out.println("2" + response.asString());
	}

	@Then("^the data is populated with Api response code should be '200'$")
	public void the_data_is_populated_with_api_response_code_should_be_200() throws Throwable {
		Assert.assertEquals(response.getStatusCode(), Statuscode);

	}

	@When("^user opens API url Link with Invalid msdId (.+) as parameter and user checks API response$")
	public void user_opens_api_url_link_with_invalid_msdid_as_parameter_and_user_checks_api_response(
			String invalidmsdid) throws Throwable {

		String endpoint = "Entity/GetSnapshot/" + invalidmsdid;
		response = RestApiUtils.getRequestWithRelaxedHttpsValidation(endpoint);
		System.out.println("2" + response.asString());
	}

	@Then("^the data is not populated and Api response code should be '404'$")
	public void the_data_is_not_populated_and_api_response_code_should_be_404() throws Throwable {

		Assert.assertEquals(response.getStatusCode(), InvalidStatuscode404);
		// Reporter.addStepLog("The input Security MSDID is Invalid !! ");
		// Reporter.addStepLog("Status :"+response.statusLine());

	}

}
