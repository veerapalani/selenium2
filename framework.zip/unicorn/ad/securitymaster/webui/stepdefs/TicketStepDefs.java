package qa.unicorn.ad.securitymaster.webui.stepdefs;

import io.cucumber.java.en.And;
import qa.framework.assertions.AssertLogger;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.securitymaster.api.stepdefs.ProsSecurityCreation;
import qa.unicorn.ad.securitymaster.webui.pages.AD_SM_TKT_HomePage;

public class TicketStepDefs {

	AD_SM_TKT_HomePage objTicketHomePage = new AD_SM_TKT_HomePage();

	@And("^user open Ticket application$")
	public void user_open_ticket_application() throws Throwable {
		objTicketHomePage.open();
	}

	@And("^user verifies 'Status' as \"([^\"]*)\" on Ticket application$")
	public void user_verifies_status_as_something_on_ticket_application(String expectedStatus) throws Throwable {
		String actualStatus = objTicketHomePage.getStatus(ProsSecurityCreation.externalId);
		AssertLogger.assertEquals(actualStatus, expectedStatus, "Failure 'Status' didn't match !!");
	}

	@And("^user verfifies 'ISIN'value on Ticket application$")
	public void user_verfifies_isinvalue_on_ticket_application() throws Throwable {
		String actualISIN = objTicketHomePage.getISIN(ProsSecurityCreation.externalId);

		Reporter.addScreenCapture();
		
		AssertLogger.assertEquals(actualISIN, ProsSecurityCreation.isin, "Failure 'ISIN' didn't match !!");
		
		
	}

}
