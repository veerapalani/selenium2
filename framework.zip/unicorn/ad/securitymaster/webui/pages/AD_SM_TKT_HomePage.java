package qa.unicorn.ad.securitymaster.webui.pages;

import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class AD_SM_TKT_HomePage {
	
	List<DBRowTO> listElements = SQLDriver.getEleObjData("AD_SM_TKT_HomePage");
	Action action = new Action(listElements);

	public void open() {
		String url = Action.getTestData("Ticket-URL");
		action.openURL(url);
	}

	public String getStatus(String externalID) {
		String statusXpath = Action.getValue("Status", listElements);
		statusXpath = statusXpath.replace("${externalId}", externalID);
		WebElement eleStatus = action.getElement("xpath", statusXpath);

		action.scrollToElement(eleStatus);

		return action.getText(eleStatus);
	}

	public String getISIN(String externalID) {
		String isinXpath = Action.getValue("ISIN", listElements);
		isinXpath = isinXpath.replace("${externalId}", externalID);
		return action.getText(action.getElement("xpath", isinXpath));
	}

}
