package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class DSListUtilScr {

	private Screen screen;
	private Field DsnameLevelField; 
	
	DSListUtilScr(){
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
					.id(31884)
					.label("screen31884").build());
			
			
			DsnameLevelField = screen
							.describe(Field.class, new FieldDescription.Builder()
							.attachedText("Dsname Level")
							.id(664)
							.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
public DataSetListOpenModeScr enter(String dsname) {
		
		try {

			LeanftAction.sync(screen);
			LeanftAction.setText(DsnameLevelField, dsname);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new DataSetListOpenModeScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	
		
	}


}
