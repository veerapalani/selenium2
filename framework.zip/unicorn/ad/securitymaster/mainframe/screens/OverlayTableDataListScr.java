package qa.unicorn.ad.securitymaster.mainframe.screens;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class OverlayTableDataListScr {
	


	private Screen screen;
	private Field textField;
	private Field scrollField;
	private Field commandField;
	String rightScreenText;
	
	public OverlayTableDataListScr() {
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
							.label("screen18340").build());
			
			
			textField = screen
					.describe(Field.class, new FieldDescription.Builder()
							.id(241)
							.isProtected(true).build());
			scrollField = screen
					.describe(Field.class, new FieldDescription.Builder()
							.attachedText("Scroll")
							.id(1756)
							.isProtected(false).build());
			commandField = screen
					.describe(Field.class, new FieldDescription.Builder()
							.attachedText("Command")
							.id(1695)
							.isProtected(false).build());
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	
	/*----------------------------METHODS-----------------------------------------------*/
	
	/**
	 * 
	 * @param username
	 * @param password
	 * @return 
	 */
	
	public void selectScroll(String scrollText) {
		try {

			LeanftAction.sync(screen);
			LeanftAction.setText(scrollField, scrollText);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
	}
	
	
	public LinkedHashMap<String, String> findSecurityDetail(String security,LinkedHashMap<String, ArrayList<String>> layoutHashmap) {
		
		try {
			  String leftScreenText=null;
			  String firstscreen = null;
			  
			    int lineCount = 0;
				while (lineCount<34) {
					LeanftAction.sync(screen);
					leftScreenText = LeanftAction.getText(textField);
					if (leftScreenText.contains(security)) {
						System.out.println(security + "  found"+"\n");
						firstscreen = leftScreenText;
						break;
					}
					
					LeanftAction.sendTeKeys(screen, Keys.PF8);
					lineCount = lineCount+17;
				}
				
				//List of secrity 
				ArrayList<String> securitylist = new ArrayList<String>();
				firstscreen = firstscreen.substring(80);
				String[] msdArray = firstscreen.split("BIMSIOC ADD");
				for (int k = 1; k < msdArray.length;k++) 
				{
					System.out.println(msdArray[k]);
					String securityno = msdArray[k].trim().substring(0,7);
					String table = msdArray[k].trim().substring(12,17);
					String securityTable = securityno+table;
					securitylist.add(securityTable);
					
				}
				
				ArrayList<String> securitydata = new ArrayList<String>();
				Thread.sleep(4000);
				LeanftAction.setText(scrollField, "153");
				LeanftAction.sendTeKeys(screen, Keys.PF11);
				Thread.sleep(4000);
				leftScreenText = textField.getText();
				Thread.sleep(4000);
				LeanftAction.sendTeKeys(screen, Keys.PF10);
				Thread.sleep(3000);
				LeanftAction.setText(scrollField, "PAGE");
				Thread.sleep(3000);
				

				LinkedHashMap<String, String> hm = new LinkedHashMap();
				
				String data = leftScreenText.substring(80);
				String[] arr = data.split(" 00020003");
				for (int k = 0; k < arr.length-1;k++) 
				{
					
					String keyName = securitylist.get(k);
					String value = arr[k+1];
					hm.put(keyName,value);
					System.out.println(keyName);
					System.out.println(value);
					
				}
				
				
					  
			  return null;
			 

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	}


	

}
