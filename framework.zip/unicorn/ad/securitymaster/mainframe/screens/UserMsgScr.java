package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class UserMsgScr {
	private Screen screen;
	private Field textField;
	
	public UserMsgScr() {

		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(5980)
					.index(0)
					.label("screen5980").build());
			
			
			textField = screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field326")
					.id(326)
					.index(0)
					.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	
		
	}
	
	
public MenuUtilityISPFopScr enter() {
		
		try {

			LeanftAction.sync(screen);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new MenuUtilityISPFopScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	}

}
