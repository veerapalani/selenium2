package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class SPUFIDataSetScrBack {

	private Screen screen;
	SPUFIDataSetScrBack(){
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
							.id(12153)
							.label("SP").build());
			
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	
		
	
		
	}
	


public DB2PrimaryOpsScr goBack() {
	
	try {
		
		LeanftAction.sync(screen);
		LeanftAction.sendTeKeys(screen, Keys.PF3);
		return new DB2PrimaryOpsScr();

	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
	
	return null;
}




}
