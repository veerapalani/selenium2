package qa.unicorn.ad.securitymaster.mainframe.screens;

import java.util.List;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class BFSApplicationScreen {


	private Screen screen;
	private Field commandField;
	
	List<DBRowTO> listEleEMSPScr = SQLDriver.getEleObjData("FR_MF_EMSP01Scr");

	/**
	 * Building terminal Home screen
	 * 
	 * @param tewindow
	 */
	public BFSApplicationScreen() {

		try {
			screen = FR_MF_MainframeWindow.getTeWindow().describe(Screen.class, new ScreenDescription.Builder()
					.label("EMSP01 Applica").build());
			
			commandField = screen.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field1682(protected)")
					.id(1682)
					.isProtected(true).build());

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		
	}

	
	/*----------------------------METHODS-----------------------------------------------*/

	public boolean isBFSApplicationScreenExists(int timeInSeconds) {
		try {

			return LeanftAction.isExists(screen, timeInSeconds);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return false;
	}

	/**
	 * Selecting application
	 * 
	 * @param option
	 * @return QCICSBTSLoginScr
	 */
	public BFSApplicationLoinScr selectApplication(String option,String enumKeys) {

		try {

			/* waiting for terminal home screen */
			LeanftAction.sync(screen);

			/* selecting option */
			LeanftAction.setText(commandField, option);

			LeanftAction.sendTeKeys(screen, enumKeys);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return new BFSApplicationLoinScr();

	}

	/**
	 * Return Log off terminal
	 * 
	 * @return CO_LEG_MRG_TeLoginScr
	 */
	public BFSApplicationScreen logoff() {
		try {

			/* waiting for terminal home screen */
			LeanftAction.sync(screen);

			LeanftAction.setText(commandField, "logoff");

			LeanftAction.sendTeKeys(screen, Keys.ENTER);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return new BFSApplicationScreen();
	}



}
