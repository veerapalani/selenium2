package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class SPUFISQlinputScr {
	private Screen screen;
	private Field command;
	private Field sqlField;
	private Field sqllineNoField;
	private Field sqllineNo2Field;
	
	SPUFISQlinputScr(){

		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
							.id(16607)
							.label("screen16607").build());
			
			
			command = screen
						.describe(Field.class, new FieldDescription.Builder()
							.attachedText("Command")
							.id(1695)
							.isProtected(false).build());
			
			sqlField = screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field329")
					.id(329)
					.isProtected(false).build());
			
			sqllineNoField = screen
					.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field322")
					.id(322)
					.isProtected(false).build());
			
			sqllineNo2Field = 	screen.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field409")
					.id(409)
					.isProtected(false).build());
			
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	
	}
	
	
public SPUFISQlOutPut enterCommand(String comm) {
		
		try {

			
			
			command =  screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("Command")
					.id(1695)
					.isProtected(false).build());
			LeanftAction.sync(screen);
			LeanftAction.setText(command, comm);
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			return new SPUFISQlOutPut();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	
		
	}

public void runSql(String msd,String tbl) {
	
	//String sqlline = "Select * from "+tbl+ " where secutity no  = "+msd; 
	String sqlline1 = "SELECT * FROM DB2Q."+tbl ;
	String sqlline2 = "WHERE SECURITY_ADP_NBR = '" +msd+"'";
	try {
		
		sqlField = screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field329")
					.id(329)
					.isProtected(false).build());
		sqllineNo2Field = 	screen.describe(Field.class, new FieldDescription.Builder()
				.attachedText("field409")
				.id(409)
				.isProtected(false).build());
		
		LeanftAction.setText(sqlField, sqlline1);
		LeanftAction.setText(sqllineNo2Field, sqlline2);
		
		
		
	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
	
	
	try {
		LeanftAction.sync(screen);
		LeanftAction.setText(sqlField, "");
		LeanftAction.setText(sqlField, sqlline1);
		LeanftAction.setText(sqllineNo2Field, sqlline2);
		
		
		
	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
}



public void runSql(String attribute, String table, String msdid) {
	
	//String sqlline = "Select * from "+tbl+ " where secutity no  = "+msd; 
	String sqlline1 = "SELECT "+attribute+ " FROM DB2Q."+table ;
	String sqlline2 = "WHERE SECURITY_ADP_NBR = '" +msdid+"'";
	try {
	
		sqlField = screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field329")
					.id(329)
					.isProtected(false).build());
		sqllineNo2Field = 	screen.describe(Field.class, new FieldDescription.Builder()
				.attachedText("field409")
				.id(409)
				.isProtected(false).build());
		
		LeanftAction.setText(sqlField, sqlline1);
		LeanftAction.setText(sqllineNo2Field, sqlline2);
		
		
		
	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
}

public void runSqlDev(String msd,String tbl) {
	
	//String sqlline = "Select * from "+tbl+ " where secutity no  = "+msd; 
	String sqlline2 = "SELECT * FROM DB2T."+tbl+" WHERE SECURITY_ADP_NBR = '" +msd+"'";
	try {
		LeanftAction.sync(screen);
		LeanftAction.setText(sqlField, "");
		LeanftAction.setText(sqlField, sqlline2);
		
	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
}

public void increaseSqlLine() {
	
	try {
		screen =	FR_MF_MainframeWindow.getTeWindow().describe(Screen.class, new ScreenDescription.Builder()
				.label("screen17187").build());
		
		
		sqllineNoField = screen.describe(Field.class, new FieldDescription.Builder()
				.attachedText("field322")
				.id(322)
				.isProtected(false).build());
		sqlField = screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field329")
					.id(329)
					.isProtected(false).build());
			
			
		sqllineNo2Field = 	screen.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field409")
					.id(409)
					.isProtected(false).build());
		
	//	LeanftAction.setText(sqllineNoField, "i9");
	//	LeanftAction.sendTeKeys(screen, Keys.ENTER);
		

		
		
	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
}

}
