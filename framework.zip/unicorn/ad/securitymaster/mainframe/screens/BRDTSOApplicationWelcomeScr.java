package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class BRDTSOApplicationWelcomeScr {

	private Screen screen;
	private Field fldWelcomeMsg;

	//List<DBRowTO> listEleApplicationWelcomeScr = SQLDriver.getEleObjData("CO_LEG_MRG_ApplicationWelcomeScr");

	public BRDTSOApplicationWelcomeScr() {
		try {
			/* [important] screen should be initialize first then fields in it */
			screen = FR_MF_MainframeWindow.getTeWindow().describe(Screen.class,
					new ScreenDescription.Builder().label(new RegExpProperty("WELCOME.*")).build());

			Field userField = screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("User")
					.id(1316)
					.isProtected(false).build());
					
			Field passwordField = screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("Password")
					.id(1396)
					.isProtected(false).build());
					
			
			
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	public String getWelcomeMsg() {

		String msg = null;

		try {

			/* sync */
			LeanftAction.sync(screen);

			msg = LeanftAction.getText(fldWelcomeMsg);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return msg;

	}

	public void sendTeKeys(String enumKeys) {
		try {

			/* sync */
			LeanftAction.sync(screen);

			LeanftAction.sendTeKeys(screen, enumKeys);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	public BRDTSOApplicationWelcomeScr clearScr() {
		try {

			/* sync */
			LeanftAction.sync(screen);

			/* clear screen */
			LeanftAction.sendTeKeys(screen, Keys.CLEAR);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return new BRDTSOApplicationWelcomeScr();
	}

}
