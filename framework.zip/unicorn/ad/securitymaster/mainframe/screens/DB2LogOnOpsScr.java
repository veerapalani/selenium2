package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class DB2LogOnOpsScr {
	private Screen screen;
	private Field optionField;
	
	
	DB2LogOnOpsScr(){
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
							.id(13082)
							.label("-----------------------  DB2L").build());
			
			
			optionField = screen
					.describe(Field.class, new FieldDescription.Builder()
					.attachedText("OPTION")
					.id(1695)
					.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	public DB2SubSystemScr chooseOption(String optionfield) {
		

		
		try {

			LeanftAction.sync(screen);
			LeanftAction.setText(optionField, optionfield);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new DB2SubSystemScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	
		
	}
	
	public MenuUtilityISPFopScr goBack() {
		
		try {
			
			LeanftAction.sync(screen);
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			return new MenuUtilityISPFopScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	}
	
}
