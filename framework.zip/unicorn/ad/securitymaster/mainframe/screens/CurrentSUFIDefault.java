package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class CurrentSUFIDefault {

	private Screen screen;
	private Field command;
	CurrentSUFIDefault(){

		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
						.describe(Screen.class, new ScreenDescription.Builder()
							.id(13432)
							.label("CU").build());;
			
			
			command = screen
						.describe(Field.class, new FieldDescription.Builder()
							.attachedText("field87")
							.id(87)
							.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	
	}
	
	
public SPUFISQlinputScr enter() {
		
		try {

			LeanftAction.sync(screen);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new SPUFISQlinputScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	
		
	}


}
