package qa.unicorn.ad.securitymaster.mainframe.screens;

import java.util.List;

import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.Action;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class BFSApplicationLoinScr {
	


	private Screen screen;
	private Field fldUsername;
	private Field fldPassword;
	
	List<DBRowTO> listEleApplicationLoginScr = SQLDriver.getEleObjData("FR_MF_ApplicationLoginScr");

	public BFSApplicationLoinScr() {
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow().describe(Screen.class, new ScreenDescription.Builder().label(new RegExpProperty("screen.*")).build());
			
			fldUsername = screen.describe(Field.class,
					new FieldDescription.Builder().attachedText(Action.getValue("atcTxtUsername", listEleApplicationLoginScr)).id(Integer.parseInt(Action.getValue("idUsername", listEleApplicationLoginScr))).build());
			
			fldPassword = screen.describe(Field.class,
					new FieldDescription.Builder().attachedText(Action.getValue("atcTxtPassword", listEleApplicationLoginScr)).id(Integer.parseInt(Action.getValue("idPassword", listEleApplicationLoginScr))).build());
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	
	/*----------------------------METHODS-----------------------------------------------*/
	
	/**
	 * 
	 * @param username
	 * @param password
	 * @return 
	 */
	public BFSApplicationLoinScr loginToApplication(String username, String password) {
		
		try {

			/*waiting for the screen*/
			LeanftAction.sync(screen);
			
			/*enter username*/
			LeanftAction.setText(fldUsername, username);
			
			/*enter password*/
			LeanftAction.setText(fldPassword, password);
			
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new BFSApplicationLoinScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	}



}
