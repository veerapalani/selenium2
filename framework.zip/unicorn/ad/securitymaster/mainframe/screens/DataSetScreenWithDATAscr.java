package qa.unicorn.ad.securitymaster.mainframe.screens;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class DataSetScreenWithDATAscr {

	private Screen screen;
	private Field textField;
	private Field scrollField;
	String rightScreenText;
	
	public DataSetScreenWithDATAscr() {
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
							.label("screen18340").build());
			
			
			textField = screen
					.describe(Field.class, new FieldDescription.Builder()
							.id(241)
							.isProtected(true).build());
			scrollField = screen
					.describe(Field.class, new FieldDescription.Builder()
							.attachedText("Scroll")
							.id(1756)
							.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	
	/*----------------------------METHODS-----------------------------------------------*/
	
	/**
	 * 
	 * @param username
	 * @param password
	 * @return 
	 */
	
	public void selectScroll(String scrollText) {

		

		
		try {

			LeanftAction.sync(screen);
			LeanftAction.setText(scrollField, scrollText);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
	}
	
	
	public LinkedHashMap<String, List<String>> findSecurityDetail(String security) {
		
		try {
			  String leftScreenText=null;
			  String s1,s2,s3;
			  s1 = screen.getText();
			  
			  String firstscreen = null,SecondScreen=null,thirdScreen=null,fourthScreen = null;
			  
			    int lineCount = 0;
				while (lineCount<34000) {
					LeanftAction.sync(screen);
					leftScreenText = LeanftAction.getText(textField);
					if (leftScreenText.contains(security)) {
						System.out.println(security + "  found"+"\n");
						firstscreen = leftScreenText;
					//	  System.out.println("Security Screen-text is ");
					//	  System.out.println(firstscreen);
						LeanftAction.sendTeKeys(screen, Keys.PF7);
						LeanftAction.sync(screen);
						LeanftAction.sendTeKeys(screen, Keys.PF11);
						SecondScreen = textField.getText();
						  
						  
						  LeanftAction.sendTeKeys(screen, Keys.PF11);
						  thirdScreen = textField.getText();
							  
							  LeanftAction.sendTeKeys(screen, Keys.PF11);
							  fourthScreen = textField.getText();
								  
						rightScreenText = LeanftAction.getText(textField);
						break;
					}
					
					LeanftAction.sendTeKeys(screen, Keys.PF8);
					lineCount = lineCount+17;
				}
				
				
				LinkedHashMap<String, List<String>> mainframeataMap = new LinkedHashMap();
				
				List<String> mainframedatasetValuesInArray = new ArrayList<String>();
				
				
				//Collect data from first scrren Security and client no and put them in array
				
				ArrayList<String> securitArray = new ArrayList<String>();
				ArrayList<String> clientnoArray = new ArrayList<String>();
				
				String[] arr = firstscreen.substring(80).split("                                  ........................");
				for (int i = 0; i < arr.length;i++) 
				{
					//System.out.println(arr[i]);
					String securit = arr[i].substring(11,18);
					String clientno = arr[i].substring(18,22);
					
					securitArray.add(securit);
					clientnoArray.add(clientno);
				}
			  
			  System.out.println(securitArray);
			  System.out.println(clientnoArray);
			  
			  
			  String[] thirdArr = thirdScreen.substring(80).split("....................                                   ");
				ArrayList<String> sec2 = new ArrayList<String>();
				ArrayList<String> tblArr = new ArrayList<String>();
				ArrayList<String> prdbArr = new ArrayList<String>();
				
				ArrayList<String> securityAndTableArry = new ArrayList<String>();
				
				for (int i = 1; i < thirdArr.length; i++) {
					
					String s = thirdArr[i];
					String securitno  = s.substring(0, 7);
					String tablename = s.substring(11, 18);
					String securityAndTablforKey = s.substring(0, 7) + s.substring(11, 18);
					String prdbattr1 = s.substring(23, 25);
					sec2.add(securitno);
					tblArr.add(tablename);
					prdbArr.add(prdbattr1);
					securityAndTableArry.add(securityAndTablforKey);
					
				}
			 
				String[] fourthScrArr = fourthScreen.substring(80).split("                                                  ");
				
				ArrayList<String> fourtArray = new ArrayList<String>();			
					for (int i = 0; i < fourthScrArr.length;i++) {
										String text = fourthScrArr[i].trim();
										fourtArray.add(text);
					}
			  
				 
				  for (int i = 0; i < securitArray.size(); i++) {
					  List<String> mainframedatasetValues = new ArrayList<String>();
					  mainframedatasetValues.add(securitArray.get(i));
					  mainframedatasetValues.add(clientnoArray.get(i));
					  mainframedatasetValues.add(sec2.get(i));  //this for add timestamp but not present
					  mainframedatasetValues.add(tblArr.get(i)); //this for update timestamp but not present
					  mainframedatasetValues.add(prdbArr.get(i));
					  mainframedatasetValues.add(fourtArray.get(i));
					  mainframeataMap.put(securityAndTableArry.get(i),mainframedatasetValues);
					
				}
			  
				/*
				 * for (Entry<String, List<String>> entry : mainframeataMap.entrySet()) { String
				 * key = entry.getKey(); System.out.println(key); List<String> value =
				 * entry.getValue(); System.out.println(value);
				 * 
				 * for(String aString : value){ System.out.println("key : " + key + " value : "
				 * + aString); }
				 * 
				 * }
				 */
			  
			  
			  
			  return mainframeataMap;
			 

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	}



}
