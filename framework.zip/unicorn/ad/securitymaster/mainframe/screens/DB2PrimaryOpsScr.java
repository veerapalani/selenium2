package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class DB2PrimaryOpsScr {
	private Screen screen;
	private Field commandField;
	
	DB2PrimaryOpsScr(){


		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
						.describe(Screen.class, new ScreenDescription.Builder()
							.id(8920)
							.label("D").build());
			
			
			commandField = screen
						.describe(Field.class, new FieldDescription.Builder()
							.attachedText("COMMAND")
							.id(95)
							.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	
		
	
		
	}
	
public SPUFIDataSetScr command(String command) {
		
		try {

			LeanftAction.sync(screen);
			LeanftAction.setText(commandField, command);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new SPUFIDataSetScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	
		
	}

public DB2LogOnOpsScr goBack() {
	
	try {
		
		LeanftAction.sendTeKeys(screen, Keys.PF3);
		LeanftAction.sendTeKeys(screen, Keys.PF3);
		LeanftAction.sendTeKeys(screen, Keys.PF3);
		return new DB2LogOnOpsScr();

	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
	
	return null;
}

}
