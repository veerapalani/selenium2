package qa.unicorn.ad.securitymaster.mainframe.screens;

public class DB2PrimaryOpsScrBack {
	
}
