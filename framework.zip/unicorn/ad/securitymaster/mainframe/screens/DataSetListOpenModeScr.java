package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class DataSetListOpenModeScr {


	private Screen screen;
	private Field DSmode; 
	
	DataSetListOpenModeScr(){
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
							.id(23707)
							.label("screen23707").build());
			
			
			DSmode = screen
					.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field482")
					.id(482)
					.index(0)
					.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
public DataSetScreenWithDATAscr dsOpenMode(String browse) {
		
		try {

			LeanftAction.sync(screen);
			LeanftAction.setText(DSmode, browse);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new DataSetScreenWithDATAscr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
		
	}

public OverlayTableDataListScr OpenMode(String browse) {
	
	try {

		LeanftAction.sync(screen);
		LeanftAction.setText(DSmode, browse);
		LeanftAction.sendTeKeys(screen, Keys.ENTER);
		
		return new OverlayTableDataListScr();

	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
	
	return null;
	
}






}
