package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class MenuUtilityISPFopScr {
	private Screen screen;
	private Field optionField;
	
	MenuUtilityISPFopScr(){
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
							.label("screen20528").build());
			
			
			optionField = screen
					.describe(Field.class, new FieldDescription.Builder()
							.attachedText("Option")
							.id(1694)
							.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	
public DB2LogOnOpsScr chooseOption(String optionfield) {
		
		try {

			LeanftAction.sync(screen);
			LeanftAction.setText(optionField, optionfield);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new DB2LogOnOpsScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	}
	

public DSListUtilScr OptionUtiliynDSList(String optionfield) {
	
	try {

		LeanftAction.sync(screen);
		LeanftAction.setText(optionField, optionfield);
		LeanftAction.sendTeKeys(screen, Keys.ENTER);
		
		return new DSListUtilScr();

	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
	
	return null;
}


}
