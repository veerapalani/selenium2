package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class TSOELoginSc {

	


	private Screen screen;
	private Field fldPassword;
	

	public TSOELoginSc() {
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
					.describe(Screen.class, new ScreenDescription.Builder()
							.id(12838)
							.label("-----------------------------").build());
			
			
			fldPassword = screen
					.describe(Field.class, new FieldDescription.Builder()
							.attachedText("Password")
							.id(580)
							.isProtected(false).build());
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	
	/*----------------------------METHODS-----------------------------------------------*/
	
	/**
	 * 
	 * @param username
	 * @param password
	 * @return 
	 */
	public UserMsgScr loginToApplication(String password) {
		
		try {

			/*waiting for the screen*/
			LeanftAction.sync(screen);
			
			/*enter password*/
			LeanftAction.setText(fldPassword, password);
			
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new UserMsgScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	}





}
