package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class SPUFISQlOutPut {
	

	private Screen screen;
	private Field text;
	private Field CommandField;
	
	SPUFISQlOutPut(){

		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(18340)
					.label("screen18340").build());
			
			
			text = screen
						.describe(Field.class, new FieldDescription.Builder()
							.id(241)
							.isProtected(true).build());
			
			CommandField= screen.describe(Field.class, new FieldDescription.Builder()
					.attachedText("Command")
					.id(1695)
					.isProtected(false).build());
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	
	}
	
	public String getOutput() {
		
		String s = null;
		try {
			LeanftAction.sync(screen);
			s = text.getText();
		} catch (GeneralLeanFtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
		
	}
	
	
public String getRightput() {
		
		String s = null;
		
		try {
			LeanftAction.sync(screen);
			LeanftAction.sendTeKeys(screen, Keys.PF11);
			LeanftAction.sendTeKeys(screen, Keys.PF11);
			s= LeanftAction.getText(text);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
		
	}



public DB2PrimaryOpsScr goBack() {
	
	try {
		
		LeanftAction.sync(screen);
		LeanftAction.sendTeKeys(screen, Keys.PF3);
		LeanftAction.sendTeKeys(screen, Keys.PF3);
		LeanftAction.sendTeKeys(screen, Keys.PF3);
		LeanftAction.sendTeKeys(screen, Keys.PF3);

		return new DB2PrimaryOpsScr();

	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
	
	return null;
}







}
