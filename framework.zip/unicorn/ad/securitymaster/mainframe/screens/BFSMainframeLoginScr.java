package qa.unicorn.ad.securitymaster.mainframe.screens;

import java.util.List;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class BFSMainframeLoginScr {

	
	private Screen screen;
	private Field fldUserName;
	private Field fldPassword;

	
	List<DBRowTO> listEleMainframeLoginScr = SQLDriver.getEleObjData("FR_MF_MainframeLoginScr");
	
	/**
	 * Using constructor to initialize screen and fields;
	 * 
	 * @param tewindow
	 */
	public BFSMainframeLoginScr() {
		try {
			
			screen = FR_MF_MainframeWindow.getTeWindow().describe(Screen.class, new ScreenDescription.Builder()
					.id(14397)
					.label("screen14397").build());
			
			fldPassword = screen.describe(Field.class, new FieldDescription.Builder()
					.attachedText("Password")
					.id(1396)
					.isProtected(false).build());
			
			fldUserName = screen.describe(Field.class, new FieldDescription.Builder()
					.attachedText("User")
					.id(1316)
					.text("").build());
		} catch (Exception e) {
			ExceptionHandler.handleException(e);

		}

	}

	
	/*----------------------------METHODS-----------------------------------------------*/
	
	/**
	 * 
	 * @author BathriYo
	 * @return boolean
	 */
	public boolean isTerminalLoginScrExists(int timeInSeconds) {

		try {
			
			return LeanftAction.isExists(screen,timeInSeconds);
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		return false;
	}
	
	/**
	 * Login to terminal
	 * @author BathriYo
	 * @param username
	 * @param password
	 * @return 
	 */
	public BFSApplicationScreen loginToTerminal(String username, String password) {
		try {
			
			LeanftAction.setText(fldUserName, username);
			LeanftAction.setText(fldPassword, password);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new BFSApplicationScreen();
			
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	}

}
