package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class SPUFIDataSetScr {
	private Screen screen;
	private Field datasetInputname;
	private Field datasetOutputname;
	private Field commandField;
	SPUFIDataSetScr(){
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(11221)
					.label("SP").build());
			
			
			datasetInputname = screen
						.describe(Field.class, new FieldDescription.Builder()
							.attachedText("DATA SET NAME")
							.id(349)
							.index(0)
							.isProtected(false)
							.text("'TBVIGUP.SPUFI.INPUT2(SQL1)'").build());
			
			
			
			datasetOutputname = screen
				.describe(Field.class, new FieldDescription.Builder()
					.attachedText("DATA SET NAME")
					.id(749)
					.index(1)
					.isProtected(false)
					.text("'TBVIGUP.SPUFI.OUTPUT3'").build());
			
			
				commandField = 	screen.describe(Field.class, new FieldDescription.Builder()
					.attachedText("field87")
					.id(87)
					.isProtected(false).build());
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	
		
	
		
	}
	
	
public CurrentSUFIDefault enter() {
		
		try {

			LeanftAction.sync(screen);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new CurrentSUFIDefault();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	
		
	}

public DB2PrimaryOpsScr goBack() {
	
	try {
		
		LeanftAction.sync(screen);
		LeanftAction.sendTeKeys(screen, Keys.PF3);
		return new DB2PrimaryOpsScr();

	} catch(Exception e) {
		ExceptionHandler.handleException(e);
	}
	
	return null;
}


}
