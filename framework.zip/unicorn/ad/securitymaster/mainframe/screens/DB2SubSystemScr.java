package qa.unicorn.ad.securitymaster.mainframe.screens;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class DB2SubSystemScr {
	private Screen screen;
	private Field dB2SubsystemIDField;
	
	DB2SubSystemScr(){
		
		try {
			screen = FR_MF_MainframeWindow.getTeWindow()
						.describe(Screen.class, new ScreenDescription.Builder()
							.id(17805)
							.label("-----------------------------").build());
			
			
			dB2SubsystemIDField = screen
					.describe(Field.class, new FieldDescription.Builder()
							.attachedText("DB2 Subsystem ID")
							.id(1397)
							.isProtected(false).build());
			
		
		
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
public DB2SubSysSelctScr enterDBsubSysId(String dbSubSysId) {
		
		try {

			LeanftAction.sync(screen);
			LeanftAction.setText(dB2SubsystemIDField, dbSubSysId);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);
			
			return new DB2SubSysSelctScr();

		} catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
	
		
	}
}
