package qa.unicorn.ad.securitymaster.mainframe.stepdefs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.testng.Assert;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.mainframe.FR_MF_EMSP01Scr;
import qa.framework.mainframe.FR_MF_MainframeLoginScr;
import qa.framework.mainframe.FR_MF_MainframeWelcomeScr;
import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.APIResponseStatusCode;
import qa.framework.utils.Action;
import qa.framework.utils.LeanftAction;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.securitymaster.mainframe.screens.CurrentSUFIDefault;
import qa.unicorn.ad.securitymaster.mainframe.screens.DB2LogOnOpsScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DB2PrimaryOpsScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DB2SubSysSelctScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DB2SubSystemScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DSListUtilScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DataSetListOpenModeScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DataSetScreenWithDATAscr;
import qa.unicorn.ad.securitymaster.mainframe.screens.MenuUtilityISPFopScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.SPUFIDataSetScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.SPUFISQlOutPut;
import qa.unicorn.ad.securitymaster.mainframe.screens.SPUFISQlinputScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.TSOELoginSc;
import qa.unicorn.ad.securitymaster.mainframe.screens.UserMsgScr;

public class ValidateMSDFileWithDB2 {
	
	SPUFIDataSetScr spufidataset;
	MenuUtilityISPFopScr ispfoperation ;
	SPUFISQlOutPut spufioutput;
	DSListUtilScr dslistScreen;
	DataSetListOpenModeScr dsmode;
	DataSetScreenWithDATAscr datascreen;
	
	
	List<String> DSarraylistbccf =  new ArrayList<String>();;
	List<String> DSarraylistbccl =  new ArrayList<String>();
	List<String> DSarraylistbcsd =  new ArrayList<String>();
	
	List<String> dBarraylistbccf =  new ArrayList<String>();
	List<String> dBarraylistbccl =  new ArrayList<String>();
	List<String> dBarraylistbcsd =  new ArrayList<String>();

	
	
	String userid;
	String userpassword;
	HashMap<String, List<String>> tabledataMap;
	LinkedHashMap<String, List<String>> mainframeataMap;
	
	FR_MF_MainframeWelcomeScr objTerminalWelcomScr;
	FR_MF_MainframeLoginScr login;
	FR_MF_EMSP01Scr objTerminalEMSP01Scr;
	TSOELoginSc tsologinScr;
	UserMsgScr usermsgSc ;
	DB2PrimaryOpsScr db2prOpsscr;
	DB2LogOnOpsScr dblogonopsscr;
	
	
	
	@Given("MSD extract file {string} and user access to database")
	public void msd_extract_file_and_user_access_to_database(String string) {
		System.out.println("Given MSD extract file {string} and user access to database");
		Reporter.addStepLog("extract file"+string);
	}

	@When("user navigates to mainframe mocha console and enter {string} command")
	public void user_navigates_to_mainframe_mocha_console_and_enter_command(String string) {
	System.out.println("when  user navigates to mainframe mocha console and enter");
	

	FR_MF_MainframeWelcomeScr objTerminalWelcomScr = new FR_MF_MainframeWelcomeScr();
	objTerminalWelcomScr.navigateToTerminalLoginScr("netvac");
	Reporter.addStepLog("when  user navigates to mainframe mocha console and enter"+string);
	
	
	/* Login to terminal */
	FR_MF_MainframeLoginScr login = new FR_MF_MainframeLoginScr();

	
	userid = Action.getTestData("ad_sm_mf_user");
	userpassword = Action.getTestData("ad_sm_mf_pass");

	login.loginToTerminal(userid,userpassword);
	
	
	Reporter.addStepLog("user login to terminal with userid and password");
	
	
	

	/* Selecting application from Terminal home screen */
	FR_MF_EMSP01Scr objTerminalEMSP01Scr = new FR_MF_EMSP01Scr();
	objTerminalEMSP01Scr.selectApplication("5", Keys.ENTER);
	
	Reporter.addStepLog("user select application DTSO by entering 5 ");
	
	}

	@Then("user login to TSO with valid credential")
	public void user_login_to_TSO_with_valid_credential() {
		System.out.println("user login to TSO with valid credential");
		TSOELoginSc tsologinScr = new TSOELoginSc();
		UserMsgScr usermsgSc =	tsologinScr.loginToApplication(userpassword);
		ispfoperation = usermsgSc.enter();
	}

	@Then("user go to SPUFI file screen")
	public void user_go_to_SPUFI_file_screen() {
		System.out.println("user go to SPUFI file screen");
		dblogonopsscr = ispfoperation.chooseOption("A");
		DB2SubSystemScr db2subsysScr= dblogonopsscr.chooseOption("B");
		DB2SubSysSelctScr db2subsysSelctScr= db2subsysScr.enterDBsubSysId("DB2Q");
		db2prOpsscr = db2subsysSelctScr.enter();
		spufidataset = db2prOpsscr.command("1");
		Reporter.addStepLog("user enter command 1 for SPUFI ");
	}

	
	@Then("user run sql command in spufi for {string} and {string}")
	public void user_run_sql_command_in_spufi_for_and(String msdid, String tablename) {

		System.out.println("user run sql command in spufi");
		CurrentSUFIDefault crp = spufidataset.enter();
		SPUFISQlinputScr spufiInp = crp.enter();
		spufiInp.runSql(msdid,tablename);
		spufioutput = spufiInp.enterCommand(";;;");
		Reporter.addStepLog("user run sql command in spufi");
		
	
	}

	@Then("user get output of sql {string} from db {string}")
	public void user_get_output_of_sql_from_db(String msdid, String table) {

		System.out.println("user get output of sql");
		
		String sqloutput = spufioutput.getOutput();
		String SPUFIoutputtext = sqloutput.substring(480);
		String s1 = SPUFIoutputtext.substring(0, 88);
		
		
		
		String righttbldata = spufioutput.getRightput();
		String coldata = righttbldata.substring(480);
		System.out.println(coldata);
		String maindata = coldata.substring(0, 68);
		System.out.println(maindata);
		
		if(sqloutput.length()>1360 && sqloutput.contains(msdid)) {
			System.out.println("Data found in DB");
			Reporter.addStepLog("Data found in DB");
			
			 switch (table) {
				case "MSDBCCF":
					
					String security = s1.substring(0, 7);
					String clientNo = s1.substring(18, 22);
					String addTmp = s1.substring(30, 56);
					String update = s1.substring(58, 80) +maindata.substring(0, 4);
					String primeSecID = maindata.substring(7, 16);
					String secondSecId = maindata.substring(25, 31);
					String prodCd = maindata.substring(44, 48);
					System.out.println(security);
					System.out.println(clientNo);
					System.out.println(addTmp);
					System.out.println(update);
					System.out.println(primeSecID);
					System.out.println(secondSecId);
					System.out.println(prodCd);
					
					List<String> arraylistbccf = new ArrayList<String>();
					
					arraylistbccf.add(security);
					arraylistbccf.add(clientNo);
			//		arraylistbccf.add(addTmp);
			//		arraylistbccf.add(update);
					arraylistbccf.add(primeSecID);
					arraylistbccf.add(secondSecId);
					arraylistbccf.add(prodCd);
					
					dBarraylistbccf = arraylistbccf;
					
					Reporter.addStepLog("<strong> Table MSDBCCF Data found in DB2 is </strong> "+dBarraylistbccf);
					
					break;
				case "MSDBCCL":
					String SECURITY_ADP_NBR,CLIENT_NBR,BIMS_CLASS_TYPE_CD,ADDED_TMSTP,UPDT_TMSTP,BIMS_PROD_LVL1_CD,BIMS_PROD_LVL2_CD;
					SECURITY_ADP_NBR = s1.substring(0, 7);
					CLIENT_NBR = s1.substring(18, 22);
					BIMS_CLASS_TYPE_CD = s1.substring(30, 34);
					ADDED_TMSTP = s1.substring(51, 76);
					BIMS_CLASS_TYPE_CD = s1.substring(30, 34);
					UPDT_TMSTP =  maindata.substring(0, 24);
					BIMS_PROD_LVL1_CD = maindata.substring(26, 29);
					BIMS_PROD_LVL2_CD = maindata.substring(45, 47);
					
					System.out.println(SECURITY_ADP_NBR);
					System.out.println(CLIENT_NBR);
					System.out.println(BIMS_CLASS_TYPE_CD);
					System.out.println(ADDED_TMSTP);
					System.out.println(BIMS_PROD_LVL1_CD);
					System.out.println(BIMS_PROD_LVL2_CD);
					
					List<String> arraylistbccl = new ArrayList<String>();
					
					arraylistbccl.add(SECURITY_ADP_NBR);
					arraylistbccl.add(CLIENT_NBR);
				//	arraylistbccl.add(ADDED_TMSTP);
					arraylistbccl.add(BIMS_CLASS_TYPE_CD);
					arraylistbccl.add(BIMS_PROD_LVL1_CD);
					arraylistbccl.add(BIMS_PROD_LVL2_CD);
					
					
					dBarraylistbccl = arraylistbccl;
					Reporter.addStepLog("<strong> Table MSDBCCL Data found in DB2 is </strong> "+dBarraylistbccl);
					
					
					
					break;
				case "MSDBCSD":
					String BIMS_DESC_TYPE_CD , BIMS_DESC_ROW_NBR    ,ADDED_, UPDT_, BIMS_SEC_DESC_TXT    ;
					SECURITY_ADP_NBR = s1.substring(0, 7);
					CLIENT_NBR = s1.substring(18, 22);
					BIMS_CLASS_TYPE_CD = s1.substring(30, 32);
					BIMS_DESC_ROW_NBR = s1.substring(65, 66);
					ADDED_TMSTP = s1.substring(68, 75)+maindata.substring(0, 14);
					UPDT_TMSTP =  maindata.substring(16, 42);
					BIMS_SEC_DESC_TXT = maindata.substring(44);
					
					System.out.println(SECURITY_ADP_NBR);
					System.out.println(CLIENT_NBR);
					System.out.println(BIMS_CLASS_TYPE_CD);
					System.out.println(BIMS_DESC_ROW_NBR);
					System.out.println(ADDED_TMSTP);
					System.out.println(UPDT_TMSTP);
					System.out.println(BIMS_SEC_DESC_TXT);
					

					List<String> arraylistbcsd = new ArrayList<String>();
					
					arraylistbcsd.add(SECURITY_ADP_NBR);
					arraylistbcsd.add(CLIENT_NBR);
					arraylistbcsd.add(BIMS_CLASS_TYPE_CD);
				//	arraylistbcsd.add(ADDED_TMSTP);
				//	arraylistbcsd.add(UPDT_TMSTP);
					arraylistbcsd.add(BIMS_SEC_DESC_TXT);
					
					
					dBarraylistbcsd = arraylistbcsd;
					Reporter.addStepLog("<strong> Table MSDBCSD Data found in DB2 is  </strong>"+dBarraylistbcsd);
					
					
					break;
		}
			 }
		else {

			System.out.println("Data not found in DB");
			Reporter.addStepLog("<strong> Data not found in DB </strong>");
			
		
		}

	

			
		

	
	}

	@Then("user jump to ISPF mainUtility screen")
	public void user_jump_to_ISPF_mainUtility_screen() {
		System.out.println("user jump to ISPF mainUtility screen");
		
		try {
			Screen screen = 
						FR_MF_MainframeWindow.getTeWindow()
						.describe(Screen.class, new ScreenDescription.Builder()
							.id(18340)
							.label("screen18340").build());
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(12153)
					.label("SP").build());
			
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(8920)
					.label("D").build());
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(17805)
					.label("-----------------------------").build());
			
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(13082)
					.label("-----------------------  DB2L").build());
			
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(20528)
					.label("screen20528").build());
			
			
		} catch (GeneralLeanFtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
	}

	@Then("user enter {double} option and press enter")
	public void user_enter_option_and_press_enter(Double double1) {
	   System.out.println("user enter {double} option and press enter");
	   dslistScreen = ispfoperation.OptionUtiliynDSList("3.4");
	   Reporter.addStepLog("user enter 3.4 for datalist utility");
		 
	}

	@Then("user enter fm option in front of the file {string} and press enter")
	public void user_enter_fm_option_in_front_of_the_file_and_press_enter(String dslistfileName) {
		System.out.println("user enter fm option in front of the file {string} and press enter");
		dsmode = dslistScreen.enter(dslistfileName);
		Reporter.addStepLog("user enter datalist file name");
		
		 
	}

	@Then("user  selects the option {int} and press enter")
	public void user_selects_the_option_and_press_enter(Integer int1) {
		System.out.println("user  selects the option {int} and press enter");
		datascreen = dsmode.dsOpenMode("b");
		
	}

	
	@Then("user getMSD file data for {string} and {string}")
	public void user_getMSD_file_data_for_and(String msdid, String tablename) {
		System.out.println("user getMSD file data");
		datascreen.selectScroll("PAGE");
		mainframeataMap = datascreen.findSecurityDetail(msdid);
		String key = msdid+tablename;
		mainframeataMap.get(key);
		
		 switch (tablename) {
			case "MSDBCCF":
				List<String> arraylistbccf = mainframeataMap.get(key);
				String last = arraylistbccf.get(arraylistbccf.size()-1);
				
				String Secondlast = arraylistbccf.get(arraylistbccf.size()-2);
				
				String primeSecId = Secondlast.substring(1)+last.substring(0,8);
				String secdSecId = last.substring(8,14);
				String prodCd = last.substring(18,22);
				
				arraylistbccf.remove(arraylistbccf.size()-1);
				arraylistbccf.remove(arraylistbccf.size()-2);
				arraylistbccf.add(primeSecId);
				arraylistbccf.add(secdSecId);
				arraylistbccf.add(prodCd);
				
				arraylistbccf.remove(3);
				arraylistbccf.remove(2);
				
				System.out.println(arraylistbccf);
				
				DSarraylistbccf = arraylistbccf;
				
				Reporter.addStepLog("<strong>user getMSD file data  </strong>"+DSarraylistbccf);
				
				break;
			case "MSDBCCL":
				List<String> arraylistbccl = mainframeataMap.get(key);
				String SECURITY_ADP_NBR = arraylistbccl.get(0);
				String CLIENT_NBR = arraylistbccl.get(1);
				String lastTXT = arraylistbccl.get(arraylistbccl.size()-1);
				String SecondlastTXT = arraylistbccl.get(arraylistbccl.size()-2);
				arraylistbccl.remove(arraylistbccl.size()-1);
				arraylistbccl.remove(arraylistbccl.size()-2);
				
				int len = lastTXT.length();
				String BIMS_PROD_LVL1_CD,BIMS_PROD_LVL2_CD;
				
				String bimsCLASS_TYPE_CD = SecondlastTXT+lastTXT.substring(0,1);
				arraylistbccl.add(bimsCLASS_TYPE_CD);
				if(len>8) {
					 BIMS_PROD_LVL1_CD  = lastTXT.substring(8,10);
					 arraylistbccl.add(BIMS_PROD_LVL1_CD);
					
				}
				if(len >19) {
					 BIMS_PROD_LVL2_CD  = lastTXT.substring(18,20);
					 arraylistbccl.add(BIMS_PROD_LVL2_CD);
				}
				
				arraylistbccl.remove(3);
				arraylistbccl.remove(2);
				
				System.out.println(arraylistbccl);
				
				DSarraylistbccl = arraylistbccl ;
				
				Reporter.addStepLog("<strong> user getMSD file data  </strong>"+DSarraylistbccl);
				
				break;
			case "MSDBCSD":
				List<String> arraylistbcsd = mainframeataMap.get(key);
				
					String BIMS_SEC_DESC_TXT = arraylistbcsd.get(arraylistbcsd.size()-1).substring(4);
					arraylistbcsd.remove(arraylistbcsd.size()-1);
					arraylistbcsd.add(BIMS_SEC_DESC_TXT);
					
					arraylistbcsd.remove(3);
					arraylistbcsd.remove(2);
					System.out.println(arraylistbcsd);
					
					DSarraylistbcsd = arraylistbcsd;
					
					Reporter.addStepLog("<strong> user getMSD file data  </strong>"+DSarraylistbcsd);
				break;
		 }
	}

	@Then("user match data wih sqldata for {string} and {string}")
	public void user_match_data_wih_sqldata_for_and(String msdid, String tablename) {
		System.out.println("user match data wih sqldata");
		
		switch (tablename) {
		case "MSDBCCF":
			for (int i = 0; i < 5; i++) {
				System.out.println("MSD-Attribute");
				System.out.println(DSarraylistbccf.get(i));
				System.out.println("DB-Attribute");
				System.out.println(dBarraylistbccf.get(i));
				Reporter.addStepLog("<strong>Actual value i.e MSD-Attribute value  </strong>"+DSarraylistbccf.get(i));
				Reporter.addStepLog("<strong> Expected value i.e  DB-Attributee value  </strong>"+DSarraylistbccf.get(i));
				Assert.assertEquals(DSarraylistbccf.get(i).trim(),dBarraylistbccf.get(i).trim());
			}
			break;
		case "MSDBCCL":
			for (int i = 0; i < 5; i++) {
				System.out.println("MSD-Attribute");
				System.out.println(DSarraylistbccl.get(i));
				System.out.println("DB-Attribute");
				System.out.println(dBarraylistbccl.get(i));
				Reporter.addStepLog("<strong>Actual value i.e MSD-Attribute value   </strong>"+DSarraylistbccl.get(i));
				Reporter.addStepLog("<strong> Expected value i.e  DB-Attributee value </strong>"+dBarraylistbccl.get(i));
				Assert.assertEquals(DSarraylistbccl.get(i).trim(),dBarraylistbccl.get(i).trim());
			}
			break;
		case "MSDBCSD":
			for (int i = 0; i < 4; i++) {
				
				System.out.println("MSD-Attribute");
				System.out.println(DSarraylistbcsd.get(i).trim());
				System.out.println("DB-Attribute");
				System.out.println(dBarraylistbcsd.get(i).trim());
				Reporter.addStepLog("<strong>Actual value i.e MSD-Attribute value  </strong>"+DSarraylistbcsd.get(i));
				Reporter.addStepLog("<strong>Expected value i.e  DB-Attributee value  </strong>"+dBarraylistbcsd.get(i));
				Assert.assertEquals(DSarraylistbcsd.get(i).trim(),dBarraylistbcsd.get(i).trim());
			}
			break;

		}

	}

}
