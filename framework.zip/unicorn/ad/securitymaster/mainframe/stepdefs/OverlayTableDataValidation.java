package qa.unicorn.ad.securitymaster.mainframe.stepdefs;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.mainframe.FR_MF_EMSP01Scr;
import qa.framework.mainframe.FR_MF_MainframeLoginScr;
import qa.framework.mainframe.FR_MF_MainframeWelcomeScr;
import qa.framework.mainframe.FR_MF_MainframeWindow;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.LeanftAction;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.securitymaster.mainframe.screens.CurrentSUFIDefault;
import qa.unicorn.ad.securitymaster.mainframe.screens.DB2LogOnOpsScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DB2PrimaryOpsScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DB2SubSysSelctScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DB2SubSystemScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DSListUtilScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.DataSetListOpenModeScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.MenuUtilityISPFopScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.OverlayTableDataListScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.SPUFIDataSetScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.SPUFISQlOutPut;
import qa.unicorn.ad.securitymaster.mainframe.screens.SPUFISQlinputScr;
import qa.unicorn.ad.securitymaster.mainframe.screens.TSOELoginSc;
import qa.unicorn.ad.securitymaster.mainframe.screens.UserMsgScr;

public class OverlayTableDataValidation {

	String fullExcelFilePath = null;
	ExcelUtils objExcel = null;
	XSSFSheet sheet = null;
	int rowNum = 0;
	
	

	FR_MF_MainframeWelcomeScr objTerminalWelcomScr;
	FR_MF_MainframeLoginScr login;
	FR_MF_EMSP01Scr objTerminalEMSP01Scr;
	TSOELoginSc tsologinScr;
	UserMsgScr usermsgSc ;
	DB2PrimaryOpsScr db2prOpsscr;
	DB2LogOnOpsScr dblogonopsscr;
	SPUFIDataSetScr spufidataset;
	MenuUtilityISPFopScr ispfoperation ;
	SPUFISQlOutPut spufioutput;
	DSListUtilScr dslistScreen;
	DataSetListOpenModeScr dsmode;
	OverlayTableDataListScr datascreen;
	
	String userid;
	String userpassword;
	
	
	LinkedHashMap<String, ArrayList<String>> layoutHashmap;
	String postion;
	String len;
	
	ArrayList<String> msddSarrayList ;
	ArrayList<String> msdDBList ;
	
	@Given("MSD data set file {string} and layout file {string} and {string}")
	public void msd_data_set_file_and_layout_file_and(String dataset, String excelfile, String sheetname) {
		//layoutHashmap = getLayoutDATAFromExcel(excelfile,sheetname);
		
	}
	
	@When("user open mainframe mocha console and enter {string} command")
	public void user_open_mainframe_mocha_console_and_enter_command(String string) {
		System.out.println("when  user navigates to mainframe mocha console and enter");
		

		FR_MF_MainframeWelcomeScr objTerminalWelcomScr = new FR_MF_MainframeWelcomeScr();
		objTerminalWelcomScr.navigateToTerminalLoginScr("netvac");
		Reporter.addStepLog("when  user navigates to mainframe mocha console and enter"+string);
		
		
		/* Login to terminal */
		FR_MF_MainframeLoginScr login = new FR_MF_MainframeLoginScr();

		
		 userid = Action.getTestData("ad_sm_mf_user");
		 userpassword = Action.getTestData("ad_sm_mf_pass");

		login.loginToTerminal(userid,userpassword);
		
		
		Reporter.addStepLog("user login to terminal with userid and password");
		
		
		

		/* Selecting application from Terminal home screen */
		FR_MF_EMSP01Scr objTerminalEMSP01Scr = new FR_MF_EMSP01Scr();
		objTerminalEMSP01Scr.selectApplication("5", Keys.ENTER);
		
		Reporter.addStepLog("user select application DTSO by entering 5 ");
		
		}

	@Then("user login to TSO with valid credentials")
	public void user_login_to_TSO_with_valid_credentials() {
		System.out.println("user login to TSO with valid credential");
		TSOELoginSc tsologinScr = new TSOELoginSc();
		UserMsgScr usermsgSc =	tsologinScr.loginToApplication(userpassword);
		ispfoperation = usermsgSc.enter();
	}
	
	
	@Then("user navigate to SPUFI file screen and select {string}")
	public void user_navigate_to_SPUFI_file_screen_and_select(String db) {

		System.out.println("user go to SPUFI file screen");
		dblogonopsscr = ispfoperation.chooseOption("A");
		DB2SubSystemScr db2subsysScr= dblogonopsscr.chooseOption("B");
		DB2SubSysSelctScr db2subsysSelctScr= db2subsysScr.enterDBsubSysId(db);
		db2prOpsscr = db2subsysSelctScr.enterDB2T();
		spufidataset = db2prOpsscr.command("1");
		Reporter.addStepLog("user enter command 1 for SPUFI ");
	
	}
	
	@Then("user run sql command for {string} and {string}")
	public void user_run_sql_command_for_and(String msdid, String tablename) {


		System.out.println("user run sql command in spufi");
		CurrentSUFIDefault crp = spufidataset.enter();
		SPUFISQlinputScr spufiInp = crp.enter();
		spufiInp.increaseSqlLine();
		spufiInp.runSqlDev(msdid,tablename);
		spufioutput = spufiInp.enterCommand(";;;");
		Reporter.addStepLog("user run sql command in spufi");
		
	
	
	}
	
	@Then("user get output of sql {string} from table {string} in db")
	public void user_get_output_of_sql_from_table_in_db(String msdid, String table) throws Exception {
		System.out.println("user get output of sql");
		
		String sqloutput = spufioutput.getOutput();
		String SPUFIoutputtext = sqloutput.substring(480);
		String s1 = SPUFIoutputtext.substring(0, 88);
		
		Thread.sleep(2000);
		
		String righttbldata = spufioutput.getRightput();
		String coldata = righttbldata.substring(480);
		System.out.println(coldata);
		String maindata = coldata.substring(0, 68);
		System.out.println(maindata);
		
		Thread.sleep(2000);
		
		String sqloutput2 = spufioutput.getOutput();
		System.out.println(sqloutput2);
		String coldata2 = sqloutput2.substring(480);
		System.out.println("Last Screen");
		System.out.println("DATA is "+coldata2.trim());
		
		if(sqloutput.length()>1360 && sqloutput.contains(msdid)) {
			System.out.println("Data found in DB");
			Reporter.addStepLog("Data found in DB");
			
			 switch (table) {
				case "MSDBOFV":
					System.out.println("abc");
					String PART_NBR = s1.substring(0,5);
					String client_no = s1.substring(10,14);
					String security_no = s1.substring(27,34);
					String type_rate_cd = s1.substring(45,47);
					String rate_bond_dt = s1.substring(59,69);
					String bond_rt1 = s1.substring(73,80);
					String bond_rt2 = coldata.substring(0,16);
					String bond_rt = bond_rt1+bond_rt2;
					String type_input = coldata.substring(23,26);
					String feature_freq = s1.substring(31,33);
					String rdmpt_partial = coldata.substring(58,60);
					String section_bond = coldata.substring(67,69);
					String call_rate_type = coldata2.trim().substring(0,1);
					ArrayList<String> bofvArray = new ArrayList<String>();
					bofvArray.add(security_no);
					bofvArray.add(PART_NBR);
					bofvArray.add(type_rate_cd);
					bofvArray.add(rate_bond_dt);
					bofvArray.add(bond_rt);
					bofvArray.add(type_input);
					bofvArray.add(feature_freq);
					bofvArray.add(rdmpt_partial);
					bofvArray.add(section_bond);
					bofvArray.add(call_rate_type);
					System.out.println(bofvArray);
					msdDBList = bofvArray;
					break;
					
				case "MSDCOTB":
					PART_NBR = s1.substring(0,5);
					client_no = s1.substring(10,14);
					security_no = s1.substring(27,34);
					String CVRSN_EXP_DT  = s1.substring(45,55);
					String CVRSN_EXER_CD  = s1.substring(59,63);
					String CVRSN_EXER_SEC_ID  = s1.substring(74,80)+ coldata.substring(0,6);
					String CVRSN_EXER_CNCY_CD  = coldata.substring(13,16);
					String CVRSN_RT   = coldata.substring(33,56);
					String CVRSN_PRC_AMT  = coldata.substring(59,80)+coldata2.substring(0,1);
					String CVRSN_EXER_SEC_CD  = coldata2.substring(3,4);
					String CVRSN_EXER_EXCH_RT  = coldata2.substring(22,45);
					String CVRSN_EXER_RT_CD  = coldata2.substring(47,48);
					String CVRSN_EXER_PRC_CD  = coldata2.substring(65,66);
					ArrayList<String> COBTArray = new ArrayList<String>();
					COBTArray.add(security_no);
					COBTArray.add(PART_NBR);
					COBTArray.add(client_no);
					COBTArray.add(CVRSN_EXP_DT);
					COBTArray.add(CVRSN_EXER_CD);
					COBTArray.add(CVRSN_EXER_SEC_ID);
					COBTArray.add(CVRSN_EXER_CNCY_CD);
					COBTArray.add(CVRSN_RT);
					COBTArray.add(CVRSN_PRC_AMT);
					COBTArray.add(CVRSN_EXER_SEC_CD);
					COBTArray.add(CVRSN_EXER_EXCH_RT);
					COBTArray.add(CVRSN_EXER_RT_CD);
					COBTArray.add(CVRSN_EXER_PRC_CD);
					
					System.out.println(COBTArray);
					msdDBList = COBTArray;
					break;
					
					
				case "MSDPOIN":
					PART_NBR = s1.substring(0,5);
					client_no = s1.substring(10,14);
					security_no = s1.substring(27,34);
					String PRFRD_TYPE_CD = s1.substring(45,55);
					String NBR_DAY_PAY_CD = s1.substring(60,64);
					String INTEREST_PAY_CD = s1.substring(76, 78);
					
					String MATURITY_DT = coldata.substring(13,23);
					String COUPON_FIRST_DT = coldata.substring(26, 36);
					String DATE_COUPON_CD = coldata.substring(43, 47);
					String PRD_LONG_SHORT_CD = coldata.substring(59, 60);
					String ACCRUE_INT_DT = coldata.substring(78, 80);
					
					String INTEREST_RT = coldata2.substring(13, 36);
					String CHNG_RATE_CD = coldata2.substring(38, 39);
					String NMNL_AMT = coldata2.substring(52, 75);
					String NMNL_CRNCY_CD = coldata2.substring(77, 80);
					
					Thread.sleep(2000);
					
					String righttbldata2 = spufioutput.getRightput();
					String coldata3 = righttbldata2.substring(480);
					coldata3= coldata3.substring(0, 84);
					System.out.println(coldata3);
					
					
					String NMNL_MRKR_CD = coldata3.substring(12, 15);
					String CL_NOTICE_DAYS_NBR = coldata3.substring(42, 44);
					ArrayList<String> POINArray = new ArrayList<String>();
					POINArray.add(PART_NBR);
					POINArray.add(client_no);
					POINArray.add(security_no);
					POINArray.add(PRFRD_TYPE_CD);
					POINArray.add(NBR_DAY_PAY_CD);
					POINArray.add(INTEREST_PAY_CD);
					POINArray.add(MATURITY_DT);
					POINArray.add(COUPON_FIRST_DT);
					POINArray.add(DATE_COUPON_CD);
					POINArray.add(PRD_LONG_SHORT_CD);
					POINArray.add(ACCRUE_INT_DT);
					
				
					POINArray.add(INTEREST_RT);
					POINArray.add(CHNG_RATE_CD);
					POINArray.add(NMNL_AMT);
					POINArray.add(NMNL_CRNCY_CD);
					POINArray.add(NMNL_MRKR_CD);
					POINArray.add(CL_NOTICE_DAYS_NBR);

					System.out.println(POINArray);
					msdDBList = POINArray;
					break;
					
				case "MSDBOCD":
					PART_NBR = s1.substring(0,5);
					client_no = s1.substring(10,14);
					String CALL_SCHDL_DT  = s1.substring(27,37);
					security_no = s1.substring(42,50);
					String CALL_SCHDL_AMT  = s1.substring(60,80)+coldata.trim().substring(0);
					ArrayList<String> BOCDArray = new ArrayList<String>();
					BOCDArray.add(PART_NBR);
					BOCDArray.add(client_no);
					BOCDArray.add(security_no);
					BOCDArray.add(CALL_SCHDL_DT);
					BOCDArray.add(CALL_SCHDL_AMT);
					System.out.println(BOCDArray);
					msdDBList = BOCDArray;
					break;
					
				case "MSDLOCR":
					PART_NBR = s1.substring(0,5);
					client_no = s1.substring(10,14);
					security_no = s1.substring(27,34);
					
					String LOC_TYPE_CD = s1.substring(45,48);
					String  LOC_EXPRTN_DT = s1.substring(58,68);
					String	LOC_BANK_NM  = s1.substring(73,80)+coldata.trim().substring(0,44);
					
					ArrayList<String> LOCRArray = new ArrayList<String>();
					LOCRArray.add(PART_NBR);
					LOCRArray.add(client_no);
					LOCRArray.add(security_no);
					LOCRArray.add(LOC_TYPE_CD);
					LOCRArray.add(LOC_EXPRTN_DT);
					LOCRArray.add(LOC_BANK_NM);
					System.out.println(LOCRArray);
					msdDBList = LOCRArray;
					break;
					
				case "MSDPOSH":
					PART_NBR = s1.substring(0,5);
					client_no = s1.substring(10,14);
					security_no = s1.substring(27,34);
					String PUT_SCHDL_DT = s1.substring(45,55);
					String	PUT_SCHDL_AMT  = s1.substring(59,80)+coldata.trim().substring(0,2);
					
					ArrayList<String> POSHArray = new ArrayList<String>();
					POSHArray.add(PART_NBR);
					POSHArray.add(client_no);
					POSHArray.add(security_no);
					POSHArray.add(PUT_SCHDL_DT);
					POSHArray.add(PUT_SCHDL_AMT);
					System.out.println(POSHArray);
					msdDBList = POSHArray;
					break;
					
				case "MSDSODT":
					PART_NBR = s1.substring(0,5);
					client_no = s1.substring(10,14);
					security_no = s1.substring(26,34);
					String RATE_DT  = s1.substring(45,45);
					INTEREST_RT = s1.substring(56,66);
					MATURITY_DT = s1.substring(57,80);
					
					ArrayList<String> SODTArray = new ArrayList<String>();
					SODTArray.add(PART_NBR);
					SODTArray.add(client_no);
					SODTArray.add(security_no);
					SODTArray.add(RATE_DT);
					SODTArray.add(INTEREST_RT);
					SODTArray.add(MATURITY_DT);
					System.out.println(SODTArray);
					msdDBList = SODTArray;
					break;
					
					
					
					
					
				case "MSDMSOL":
					s1 = SPUFIoutputtext.substring(81, 160);
					PART_NBR = s1.substring(0,5);
					client_no = s1.substring(10,14);
					security_no = s1.substring(26,34);
					String R144A_IND  = s1.substring(45,46);
					String	ISSUE_DT  = s1.substring(56,66);
					MATURITY_DT = s1.substring(68,78);
					
					ArrayList<String> MOSLArray = new ArrayList<String>();
					MOSLArray.add(PART_NBR);
					MOSLArray.add(client_no);
					MOSLArray.add(security_no);
					MOSLArray.add(R144A_IND);
					MOSLArray.add(ISSUE_DT);
					MOSLArray.add(MATURITY_DT);
					System.out.println(MOSLArray);
					msdDBList = MOSLArray;
					break;
					
					
					
					
					
					
					
					
					
			 }
		}
		
	}

	@Then("user naviagte back to ISPF mainUtility screen")
	public void user_naviagte_back_to_ISPF_mainUtility_screen() {

		System.out.println("user jump to ISPF mainUtility screen");
		
		try {
			Screen screen = 
						FR_MF_MainframeWindow.getTeWindow()
						.describe(Screen.class, new ScreenDescription.Builder()
							.id(18340)
							.label("screen18340").build());
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(12153)
					.label("SP").build());
			
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(8920)
					.label("D").build());
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(17805)
					.label("-----------------------------").build());
			
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(13082)
					.label("-----------------------  DB2L").build());
			
			LeanftAction.sendTeKeys(screen, Keys.PF3);
			
			screen = FR_MF_MainframeWindow.getTeWindow()
				.describe(Screen.class, new ScreenDescription.Builder()
					.id(20528)
					.label("screen20528").build());
			
			
		} catch (GeneralLeanFtException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		
	
		
	}
	
	
	

	@Then("user enter {double} option for datalist Utility and press enter")
	public void user_enter_option_for_datalist_Utility_and_press_enter(Double double1) {
		   System.out.println("user enter {double} option and press enter");
		   dslistScreen = ispfoperation.OptionUtiliynDSList("3.4");
		   Reporter.addStepLog("user enter 3.4 for datalist utility");
			 
		}

	@Then("user enter dataset file {string} and press enter")
	public void user_enter_dataset_file_and_press_enter(String dslistfileName) {
		System.out.println("user enter fm option in front of the file {string} and press enter");
		dsmode = dslistScreen.enter(dslistfileName);
		Reporter.addStepLog("user enter datalist file name");
		
		 
	}

	@Then("user open dataset in {string} mode and press enter")
	public void user_open_dataset_in_mode_and_press_enter(String string) {
		System.out.println("user  selects the option {int} and press enter");
		datascreen = dsmode.OpenMode("b");
		datascreen.selectScroll("PAGE");
		
		
	}

	@Then("user collect expected data from datalist for {string} and {string}")
	public void user_collect_expected_data_from_datalist_for_and(String msdid, String table) throws IOException {
		 LinkedHashMap<String, String> hm = datascreen.findSecurityDetail(msdid, layoutHashmap);
		 String searchkey = msdid+"+"+table.substring(3);

			System.out.println("Data found in DB");
			Reporter.addStepLog("Data found in DB");
			
			String curdir = System.getProperty("user.dir");
			String 	textfile = curdir + "\\src\\test\\resources\\ad\\securitymaster\\api\\responsejson\\USM-1663-ExtractFile-Data.txt";
			
			String  line;
			
			try (BufferedReader br = new BufferedReader(new FileReader(textfile))) {
				while ((line = br.readLine()) != null) {
					System.out.println(line);
					
					 String tablename = line.substring(146,153);
					 System.out.println(tablename);
					 
					 if(line.contains(tablename)) {
						 
						 
						 switch (tablename) {
							case "MSDBOFV":

								String PART_NBR = line.substring(154, 158);
								String client_no = line.substring(158, 162);
								String security_no = line.substring(135, 142);

								String type_rate_cd = line.substring(162, 164);
								String rate_bond_dt = line.substring(164, 174);
								String bond_rt = line.substring(174, 199);
								String type_input = line.substring(199, 200);
								String feature_freq = line.substring(202, 204);
								String rdmpt_partial = line.substring(207, 208);
								String section_bond = line.substring(208, 210);
								String call_rate_type = line.substring(210, 211);
								ArrayList<String> bofvArray = new ArrayList<String>();
								bofvArray.add(security_no);
								bofvArray.add(PART_NBR);
								bofvArray.add(type_rate_cd);
								bofvArray.add(rate_bond_dt);
								bofvArray.add(bond_rt);
								bofvArray.add(type_input);
								bofvArray.add(feature_freq);
								bofvArray.add(rdmpt_partial);
								bofvArray.add(section_bond);
								bofvArray.add(call_rate_type);
								System.out.println(bofvArray);
								
								msddSarrayList = bofvArray;
								break;
								
							case "MSDCOTB":
								PART_NBR = line.substring(154,158);
								client_no = line.substring(158,162);
								security_no = line.substring(135,142);
								
								String CVRSN_EXP_DT  = line.substring(162,172);
								String CVRSN_EXER_CD  = line.substring(172,176);
								String CVRSN_EXER_SEC_ID  = line.substring(176,188);
								String CVRSN_EXER_CNCY_CD  = line.substring(188,191);
								String CVRSN_RT   = line.substring(191,216);
								String CVRSN_PRC_AMT  =line.substring(216,241);
								String CVRSN_EXER_SEC_CD  = line.substring(241,242);
								String CVRSN_EXER_EXCH_RT  =  line.substring(242,267);
								String CVRSN_EXER_RT_CD  = line.substring(267,268);
								String CVRSN_EXER_PRC_CD  = line.substring(268,269);
								ArrayList<String> COBTArray = new ArrayList<String>();
								COBTArray.add(security_no);
								COBTArray.add(PART_NBR);
								COBTArray.add(client_no);
								COBTArray.add(CVRSN_EXP_DT);
								COBTArray.add(CVRSN_EXER_CD);
								COBTArray.add(CVRSN_EXER_SEC_ID);
								COBTArray.add(CVRSN_EXER_CNCY_CD);
								COBTArray.add(CVRSN_RT);
								COBTArray.add(CVRSN_PRC_AMT);
								COBTArray.add(CVRSN_EXER_SEC_CD);
								COBTArray.add(CVRSN_EXER_EXCH_RT);
								COBTArray.add(CVRSN_EXER_RT_CD);
								COBTArray.add(CVRSN_EXER_PRC_CD);
								
								System.out.println(COBTArray);
								msddSarrayList = COBTArray;
								break;
								
								
							case "MSDPOIN":
							
								PART_NBR = line.substring(154,158);
								client_no = line.substring(158,162);
								security_no = line.substring(135,142);
								
								String PRFRD_TYPE_CD = line.substring(162,172);
								String NBR_DAY_PAY_CD = line.substring(172,174);
								String INTEREST_PAY_CD = line.substring(176,179);
								
								String MATURITY_DT = line.substring(179,189);
								String COUPON_FIRST_DT = line.substring(190,200);
								String DATE_COUPON_CD =  line.substring(201,205);
								String PRD_LONG_SHORT_CD = line.substring(205,206);
								String ACCRUE_INT_DT = line.substring(190,200);
								
								String INTEREST_RT =  line.substring(218,243);
								String CHNG_RATE_CD = line.substring(243,244);
								String NMNL_AMT =   line.substring(244,269);
								String NMNL_CRNCY_CD =  line.substring(269,272);
							
								
								String NMNL_MRKR_CD = line.substring(272,274);
								String CL_NOTICE_DAYS_NBR = line.substring(275,279);
								ArrayList<String> POINArray = new ArrayList<String>();
								POINArray.add(PART_NBR);
								POINArray.add(client_no);
								POINArray.add(security_no);
								POINArray.add(PRFRD_TYPE_CD);
								POINArray.add(NBR_DAY_PAY_CD);
								POINArray.add(INTEREST_PAY_CD);
								POINArray.add(MATURITY_DT);
								POINArray.add(COUPON_FIRST_DT);
								POINArray.add(DATE_COUPON_CD);
								POINArray.add(PRD_LONG_SHORT_CD);
								POINArray.add(ACCRUE_INT_DT);
								
							
								POINArray.add(INTEREST_RT);
								POINArray.add(CHNG_RATE_CD);
								POINArray.add(NMNL_AMT);
								POINArray.add(NMNL_CRNCY_CD);
								POINArray.add(NMNL_MRKR_CD);
								POINArray.add(CL_NOTICE_DAYS_NBR);

								System.out.println(POINArray);
								
								msddSarrayList = POINArray;
								break;
								
							case "MSDBOCD":
								PART_NBR = line.substring(154,158);
								client_no = line.substring(158,162);
								security_no = line.substring(135,142);
								String CALL_SCHDL_DT  = line.substring(162,172);
								String CALL_SCHDL_AMT  = line.substring(172,197);
								ArrayList<String> BOCDArray = new ArrayList<String>();
								BOCDArray.add(PART_NBR);
								BOCDArray.add(client_no);
								BOCDArray.add(security_no);
								BOCDArray.add(CALL_SCHDL_DT);
								BOCDArray.add(CALL_SCHDL_AMT);
								System.out.println(BOCDArray);
								msddSarrayList = BOCDArray;
								break;
								
							case "MSDLOCR":
								PART_NBR = line.substring(154,158);
								client_no = line.substring(158,162);
								security_no = line.substring(135,142);
								
								String LOC_TYPE_CD = line.substring(162,165);
								String  LOC_EXPRTN_DT = line.substring(165,176);
								String	LOC_BANK_NM  = line.substring(176,227);
								ArrayList<String> LOCRArray = new ArrayList<String>();
								LOCRArray.add(PART_NBR);
								LOCRArray.add(client_no);
								LOCRArray.add(security_no);
								LOCRArray.add(LOC_TYPE_CD);
								LOCRArray.add(LOC_EXPRTN_DT);
								LOCRArray.add(LOC_BANK_NM);
								System.out.println(LOCRArray);
								msddSarrayList = LOCRArray;
								break;
								
							case "MSDPOSH":
								PART_NBR = line.substring(154,158);
								client_no = line.substring(158,162);
								security_no = line.substring(135,142);
								String PUT_SCHDL_DT =line.substring(162,172);
								String	PUT_SCHDL_AMT  = line.substring(172,197);
								
								ArrayList<String> POSHArray = new ArrayList<String>();
								POSHArray.add(PART_NBR);
								POSHArray.add(client_no);
								POSHArray.add(security_no);
								POSHArray.add(PUT_SCHDL_DT);
								POSHArray.add(PUT_SCHDL_AMT);
								System.out.println(POSHArray);
								break;
								
							case "MSDSODT":
								PART_NBR = line.substring(154,158);
								client_no = line.substring(158,162);
								security_no = line.substring(135,142);
								String RATE_DT  = line.substring(162,172);
								INTEREST_RT =line.substring(172,197);
								
								ArrayList<String> SODTArray = new ArrayList<String>();
								SODTArray.add(PART_NBR);
								SODTArray.add(client_no);
								SODTArray.add(security_no);
								SODTArray.add(RATE_DT);
								SODTArray.add(INTEREST_RT);
								System.out.println(SODTArray);
								break;
								
								
							case "MSDMSOL":
								PART_NBR = line.substring(154,158);
								client_no = line.substring(158,162);
								security_no = line.substring(135,142);
								String R144A_IND  = line.substring(164,165);
								String	ISSUE_DT  = line.substring(176,187);
								MATURITY_DT =  line.substring(176,187);
								
								ArrayList<String> MOSLArray = new ArrayList<String>();
								MOSLArray.add(PART_NBR);
								MOSLArray.add(client_no);
								MOSLArray.add(security_no);
								MOSLArray.add(R144A_IND);
								MOSLArray.add(ISSUE_DT);
								MOSLArray.add(MATURITY_DT);
								System.out.println(MOSLArray);
								msddSarrayList = MOSLArray;
								break;
								
								
						 }
						
						 
					 }
					
					
				}
			}

		
		
		
	}
	
	@Then("user match expected data from dataset wih actual data from sqldata for {string} and {string}")
	public void user_match_expected_data_from_dataset_wih_actual_data_from_sqldata_for_and(String string, String string2) {
		System.out.println("MSD File - data  \n"+msddSarrayList);
		System.out.println("DB -data : "+msdDBList);
	}
	
	

	
	
	private static LinkedHashMap<String, ArrayList<String>> getLayoutDATAFromExcel(String fileName,String sheetname) {
		String curdir = System.getProperty("user.dir");
		String 	excelFilePath = curdir + "\\src\\test\\resources\\ad\\securitymaster\\api\\excel\\" +fileName;
		ExcelUtils objExlUtils = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		
		XSSFSheet sheet1 = objExlUtils.getSheet(sheetname);
		
		int rowcount = sheet1.getLastRowNum();
		
	//	int rowcount = objExlUtils.getRowCount(sheet1);
		LinkedHashMap<String, ArrayList<String>> hm = new LinkedHashMap<String, ArrayList<String>>();
		
		for (int row = 2; row < rowcount; row++) {
			try {
				String	keyproperty = objExlUtils.getStringCellData(sheet1, row, 6);
				String	postion = objExlUtils.getStringCellData(sheet1, row, 7);
				String	proplength = objExlUtils.getStringCellData(sheet1, row, 8);
				String	value = objExlUtils.getStringCellData(sheet1, row, 9);
				ArrayList<String> array = new ArrayList<String>();
				
				int len = keyproperty.length();
				if(len>1) {
					array.add(postion);
					array.add(proplength);
					array.add(value);
					hm.put(keyproperty,array);
					
				}
				
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		objExlUtils.closeWorkBook();
		return hm;
		
	}
	
	
	
	@Given("DB name {string} and attibute {string}  to validte for {string}")
	public void db_name_and_attibute_to_validte_for(String string, String string2, String string3) {
	}
	
	@Then("user navigate to SPUFI file screen and for QA env select {string}")
	public void user_navigate_to_SPUFI_file_screen_and_for_QA_env_select(String db) {
		System.out.println("user go to SPUFI file screen");
		dblogonopsscr = ispfoperation.chooseOption("A");
		DB2SubSystemScr db2subsysScr= dblogonopsscr.chooseOption("B");
		DB2SubSysSelctScr db2subsysSelctScr= db2subsysScr.enterDBsubSysId("DB2Q");
		db2prOpsscr = db2subsysSelctScr.enter();
		spufidataset = db2prOpsscr.command("1");
		Reporter.addStepLog("user enter command 1 for SPUFI ");
	}

	@Then("user queries to find the value of attribute {string} in table {string} for {string}")
	public void user_queries_to_find_the_value_of_attribute_in_table_for(String attribute, String table, String msdid) {
		System.out.println("user run sql command in spufi");
		CurrentSUFIDefault crp = spufidataset.enter();
		SPUFISQlinputScr spufiInp = crp.enter();
		spufiInp.increaseSqlLine();
		
		spufiInp.runSql(attribute,table,msdid);
		spufioutput = spufiInp.enterCommand(";;;");
		System.out.println(spufioutput);
		Reporter.addStepLog("user run sql command in spufi");
	}

	@Then("the field data value {string} should be equal to {string}")
	public void the_field_data_value_should_be_equal_to(String string, String string2) {
	}


}
