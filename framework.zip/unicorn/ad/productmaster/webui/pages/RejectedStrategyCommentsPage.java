package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;

public class RejectedStrategyCommentsPage {

	Action action;
	public RejectedStrategyCommentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element, Highlight;
	int loopCount;
	
	public boolean isUserOnCommentsPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Add Comments")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
		
	}

	public String getCommentTypeValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getCommentValue() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getcountofComments() {
		List<WebElement> Elements = action.getElements("Type");
		if(Elements.size() > 0) {
			List<WebElement> Elements2 = action.getElements("Comments Count");
			return Elements2.size()-1;
		}else {
			return 0;
		}
	}

	public ArrayList<String> getithCommentInfo(int i) {
		ArrayList<String> comment = new ArrayList<String>();
		Element = action.getElementByFormatingXpath("Comment Record", i+1);
		action.highligthElement(Element);
		ArrayList<WebElement> Elements = (ArrayList<WebElement>) action.getElementsFromParentElement(Element, "Common Tag for Comment Values");
		String value = "";
		for (int j = 0; j < Elements.size()-1; j++) {
			
			value = Elements.get(j).getText();
			comment.add(value);
			
		}
		
		return comment;
	}

	public void selectCommentsType(String comType) {
		
		Element = (WebElement) action.fluentWaitForJSWebElement("drpDwnCommentType");
				//(WebElement) action.getElementByJavascript("drpDwnCommentType");
		Element.click();
		Highlight = (WebElement) action.getElementByJavascript("CommenttypeKey");
				//(WebElement) action.getElementByJavascript("CommenttypeKey");
		Highlight = Highlight.findElement(By.linkText(comType));
		/*
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(comType)) {
				Highlight = E;
				break;
			}
		}
		*/
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}
	
	public void enterCommentsComment(String com) {
			WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtCommentsComment");
			loopCount = 0;
			do {
				ele.click();
				myClear(ele);
				action.doubleClick(ele);
				action.sendKeys(ele, com);
			} while (!(getCommentCommentValue().equals(com)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	
	private String getCommentCommentValue() {
		Element = action.waitForJSWebElement("Comments Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}

	public void clickOnAddCommentsButton() {
		
		action.fluentWaitWebElement("AddCommentsButton").click();
		
	}
	
	public void clickOnAddAnotherComment() {
		Element = action.fluentWaitWebElement("Add Another Comment");
		Element.click();
		
		
	}

	public void deleteComment() {
		List<WebElement> elements = action.getElements("Delete Comments");
		
		elements.get(elements.size()-1).click();
		action.pause(1000);
		isUserOnCommentsPage();
		
	}

	public void refreshThePage() {
		action.refresh();
	}
}
