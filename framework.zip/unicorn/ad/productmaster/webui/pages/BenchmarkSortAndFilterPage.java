package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class BenchmarkSortAndFilterPage {

	Action action;
	WebElement Element, myElement;

	public BenchmarkSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchBenchmarkValue(String BenchmarkSearchValue) {
		// action.pause(100);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitForJSWebElement("GlobalSearchvalueForBenchmark");
		// action.pause(2000);
		Element.click();
		Element.clear();
		// action.pause(100);
		action.sendKeys(Element, BenchmarkSearchValue);

		action.waitForPageLoad();
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("Search Icon in Search TextBox");
		action.moveToElement(ele);
		action.highligthElement(ele);
		action.waitForPageLoad();
		action.jsClick(ele);
		/*
		 * //action.pause(500); int i = 0;
		 * 
		 * while (i < 5) { action.sendKeys(Keys.ENTER); i++; }
		 * 
		 */

	}

	public void clickOnSeeAllResultsForBenchmarkLayout() {
		// action.pause(1000);
		action.waitForJSWebElement("Search Results List");
		// action.scrollToBottom();
		Element = (WebElement) action.waitForJSWebElement("SeeAllResultBenchmarkLayout");
		// Element.click();
		action.doubleClick(Element);

	}

	public void verifyTheSearchedResultInAllTabForBenchmark() {
		// action.pause(1000);
		Element = (WebElement) action.fluentWaitForJSWebElement("AllTabBenchmark");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void verifyAndClickBenchmarkTab() {

		// action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("BenchmarkTab");
		action.highligthElement(Element);
		Element.isDisplayed();
		// action.pause(2000);
		Element.click();
		action.pause(2000);
	}

	public String verifyTheGridCountBeforeApplyFilterAndSortCondition() {
		action.pause(5000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterGlobalSearchForBenchmark");
		// action.pause(5000);
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		// action.pause(1000);
		myElement = (WebElement) action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void verifySearchedGridViewDisplay() {
		// action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("GridViewBenchmark");
		Element.isDisplayed();
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		myElement = element;
		// action.pause(2000);
		action.moveToElement(element);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		myElement = element;
		// action.pause(2000);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		myElement = element;
		// action.pause(2000);
		action.highligthElement(myElement);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void clickOnSortIcon(WebElement element) {
		myElement = element;
		// action.pause(2000);
		Element.click();
	}

	public String verifyTheSortCoumnPropertyTypeASC() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("AscSortOrder");
		// action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDESC() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("DescSortOrder");
		// action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDefault() {
		action.pause(3000);
		Element = (WebElement) action.getElement("DefaultSortOrder");
		// action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		myElement = element;
		// action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.jsClick(myElement);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		myElement = element;
		// action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void clickOnFilterCondition() {
		// action.pause(1000);
		Element = (WebElement) action.fluentWaitWebElement("FilterCondition");
		action.click(Element);
	}

	public String verifyTheBenchmarkGridCountAfterApplyFilterConditionOnTab() {
		action.pause(5000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTabForBenchmark");
		// action.pause(2000);
		return action.getText(Element);
	}

	public void clickOnFilterConditionForBenchmarkGridView(WebElement element) {
		myElement = element;
		// action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}
	
	public void enterFilterValue(String FilterValue) {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("FilterValue");
		Element.click();
		// action.pause(1000);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForBenchmarkGridView() {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheBenchmarkGridCountAfterScroll() {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterCondition");
		// action.pause(2000);
		String gridAllData = action.getAttribute(Element, "aria-rowcount");
		return gridAllData;
	}

	public void clickOnApplyFilterIconForBenchmarkGridViewForReset() {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForBenchmarkGridViewForCancel() {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnFilterDateConditionForBenchmarkGridView(WebElement element) {
		myElement = element;
		// action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}

	public WebElement findElementByJs(String js) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("js", js);
		action.highligthElement(Element);
		return Element;
	}

	public WebElement getDynamicElementFromShadowRoot(String javaScript) {
		return myElement = (WebElement) action.executeJavaScript(javaScript);
	}

	public Integer getBenchmarkCount() {
		Element = (WebElement) action.getElementByJavascript("BenchmarkTab");
		String count = Element.getText().split(" ")[1];
		System.out.println(Element.getText());
		System.out.println(Element.getText().split(" ")[1]);
		System.out.println(count.substring(1, count.length() - 1));
		return Integer.parseInt(count.substring(1, count.length() - 1));
	}

	public void clickOnBenchmarkExport() {
		// action.pause(2000);
		Element = action.fluentWaitWebElement("Benchmark Export Button");
		action.moveToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
		// action.pause(12000);
	}

	public boolean verifyTooltipOfBenchmarkExport() {
		// action.pause(2000);
		Element = action.fluentWaitWebElement("Benchmark Export Button");
		action.moveToElement(Element);
		Element = action.fluentWaitWebElement("Benchmark Export Tooltip");
		action.highligthElement(Element);
		return Element.isDisplayed();
	}

	public String getTextWithLabel(String label) {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", label);
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public boolean verifyUserisOnViewBenchmarkPage() {
		Element = action.fluentWaitWebElement("View Benchmark");
		action.highligthElement(Element);
		return Element.isDisplayed();
	}

	public boolean verifyTooltipOfBenchmarkPrint() {
		// action.pause(2000);
		Element = action.fluentWaitWebElement("Benchmark Print Button");
		action.moveToElement(Element);
		Element = action.fluentWaitWebElement("Benchmark Print Tooltip");
		action.highligthElement(Element);
		return Element.isDisplayed();
	}

	public void clickOnBenchmarkPrint() {
		// action.pause(2000);
		Element = action.fluentWaitWebElement("Benchmark Print Button");
		action.moveToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
	}

	public String getTextfromGridforRow(String value) {
		myElement = action.getElementByFormatingXpath("Grid Common Row value", value);
		// action.scrollToElement(myElement);
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String getTextforBenchmarkDescription() {
		myElement = action.fluentWaitWebElement("Grid Benchmark Description");
		action.highligthElement(myElement);
		return myElement.getText();
	}

}
