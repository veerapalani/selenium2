package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class UpdateManagerEnterManagerDetailsPage {

	Action action;

	public UpdateManagerEnterManagerDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	WebElement Element, Highlight;

	public void myClear(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		js.executeScript("arguments[0].value='';", element);
	}

	public void sendKeysWithCheck(WebElement element, String value) {
		try {
			action.sendKeys(element, value);
			while (true) {
				Thread.sleep(500);
				if (!(element.getAttribute("value").trim().equalsIgnoreCase(value))) {
					myClear(element);
					// action.clear(element);
					action.sendKeys(element, value);
				} else {
					System.out.println("Input :" + element.getAttribute("value"));
					break;
				}
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	public void clearWebField(WebElement Element) {
		while (!Element.getAttribute("value").equals("")) {
			Element.sendKeys(Keys.BACK_SPACE);
		}
	}

	public boolean isUserOnEnterManagerDetailsPage() {

		Element = (WebElement) action.waitForJSWebElement("Header");
		if (Element.getText().equals("Enter Manager Details")) {
			action.highligthElement(Element);
			Reporter.addCompleteScreenCapture();
			return true;
		}
		return false;

	}

	public void enterManagerName(String managerName) {

		Element = (WebElement) action.fluentWaitForJSWebElement("Manager Name");
		action.highligthElement(Element);
		Element.click();
		// clearWebField(Element);
		sendKeysWithCheck(Element, managerName);

		// Element.clear();
		// Element.sendKeys(managerName);
		/*
		 * // using attribute id to wait for Value from excel to go to UI Highlight =
		 * action.getElementByFormatingXpath("Common Attribute Value", "managerName");
		 * PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), managerName,
		 * Highlight);
		 */

	}

	public void enterfirmName(String firmName) {

		Element = (WebElement) action.fluentWaitForJSWebElement("Firm Name");
		action.highligthElement(Element);
		Element.click();
		// Element.clear();
		// clearWebField(Element);
		sendKeysWithCheck(Element, firmName);
		// Element.sendKeys(firmName);
		/*
		 * // using attribute id to wait for Value from excel to go to UI Highlight =
		 * action.getElementByFormatingXpath("Common Attribute Value", "firmName");
		 * PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), firmName,
		 * Highlight);
		 */

	}

	public void enterfirmWebsite(String firmWebsite) {

		Element = (WebElement) action.fluentWaitForJSWebElement("Firm Website");
		action.highligthElement(Element);
		Element.click();
		// Element.clear();
		// clearWebField(Element);
		sendKeysWithCheck(Element, firmWebsite);
		// Element.sendKeys(firmWebsite);
		/*
		 * // using attribute id to wait for Value from excel to go to UI Highlight =
		 * action.getElementByFormatingXpath("Common Attribute Value", "firmWebsite");
		 * PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), firmWebsite,
		 * Highlight);
		 */

	}

	public void entervestmarkManagerName(String vestmarkManagerName) {

		Element = (WebElement) action.fluentWaitForJSWebElement("Vestmark Manager Name");
		action.highligthElement(Element);
		Element.click();
		// Element.clear();
		// clearWebField(Element);
		// Element.sendKeys(vestmarkManagerName);
		sendKeysWithCheck(Element, vestmarkManagerName);
		/*
		 * // using attribute id to wait for Value from excel to go to UI Highlight =
		 * action.getElementByFormatingXpath("Common Attribute Value", "vestmarkName");
		 * PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(),
		 * vestmarkManagerName, Highlight);
		 */

	}

	public void entertaxPayerIdentificationNumber(String taxPayerIdentificationNumber) {

		Element = (WebElement) action.fluentWaitForJSWebElement("Tax Payer Identification Number");
		action.highligthElement(Element);
		Element.click();
		// Element.clear();
		// clearWebField(Element);
		// Element.sendKeys(taxPayerIdentificationNumber);
		sendKeysWithCheck(Element, taxPayerIdentificationNumber);
		/*
		 * // using attribute id to wait for Value from excel to go to UI Highlight =
		 * action.getElementByFormatingXpath("Common Attribute Value",
		 * "taxpayerIdentificationNo");
		 * PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(),
		 * taxPayerIdentificationNumber, Highlight);
		 */

	}

	public void enterlargeTraderID(String largeTraderID) {

		Element = (WebElement) action.fluentWaitForJSWebElement("Large Trader ID");
		action.highligthElement(Element);
		Element.click();
		// Element.clear();
		// clearWebField(Element);
		// Element.sendKeys(largeTraderID);
		sendKeysWithCheck(Element, largeTraderID);
		/*
		 * // using attribute id to wait for Value from excel to go to UI Highlight =
		 * action.getElementByFormatingXpath("Common Attribute Value", "largeTraderId");
		 * PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(),
		 * largeTraderID, Highlight);
		 */

	}

	public void enterdtccID(String dtccID) {

		Element = (WebElement) action.fluentWaitForJSWebElement("DTCC ID");
		action.highligthElement(Element);
		Element.click();
		// Element.clear();
		// clearWebField(Element);
		// Element.sendKeys(dtccID);
		sendKeysWithCheck(Element, dtccID);
		/*
		 * // using attribute id to wait for Value from excel to go to UI Highlight =
		 * action.getElementByFormatingXpath("Common Attribute Value", "dtccId");
		 * PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), dtccID,
		 * Highlight);
		 */

	}

	public void enterfourEyeCheckOverride(String fourEyeCheckOverride) {

		switch (fourEyeCheckOverride.trim().toLowerCase()) {
		case "yes":
			Element = action.getElementByFormatingXpath("Eye Check Over Ride", "Yes");
			action.highligthElement(Element);
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Eye Check Over Ride", "No");
			action.highligthElement(Element);
			Element.click();
			break;

		default:
			break;
		}

	}

	public void enterubsSubsudiary(String ubsSubsudiary) {

		Element = action.waitForJSWebElement("UBS Subsidiary");
		action.highligthElement(Element);
		action.click(Element);
		Highlight = (WebElement) action.fluentWaitForJSWebElement("UBS Subsidiary Dropdown List");
		Highlight = Highlight.findElement(By.linkText(ubsSubsudiary));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);

	}

	public void clickOnNext() {

		Element = action.fluentWaitWebElement("Next");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		Element.click();

	}

	public String getManagerNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "Manager Name");

		return Element.getAttribute("value");
	}

	public String getFirmNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "Firm Name");

		return Element.getAttribute("value");
	}

	public String getFirmWebsiteValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "Firm Website");

		return Element.getAttribute("value");
	}

	public String getVestmarkManagerNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "Vestmark Name");

		return Element.getAttribute("value");
	}

	public String getTaxPayerIdentificationNumberValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label",
				"Taxpayer Identification Number");

		return Element.getAttribute("value");
	}

	public String getLargeTraderIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "Large Trader ID");

		return Element.getAttribute("value");
	}

	public String getdtccIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "DTCC ID");

		return Element.getAttribute("value");
	}

	public String getStatusValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "Status");

		return Element.getAttribute("value");
	}

	public String get4EyeCheckOverrideValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "4 Eye Check Override");

		return Element.getAttribute("value");
	}

	public String getUBSSubsidiaryValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", "UBS Subsidiary");

		return Element.getAttribute("value");
	}

	public boolean isTextFieldEditable(String label) {

		Element = action.getElementByFormatingXpath("Common Attribute Value by Label", label);
		Element.click();
		Element.clear();
		Element.sendKeys("isEditable");
		if (Element.getAttribute("value").equals("isEditable"))
			return true;

		return false;
	}

	public boolean isDropdownValuesDisplayedInUI(List<String> list) {

		String[] dropdownValues = list.get(1).split(",");
		Element = action.waitForJSWebElement(list.get(0));
		action.click(Element);
		Highlight = (WebElement) action.fluentWaitForJSWebElement("UBS Subsidiary Dropdown List");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any dropdown");
		int i = 0;
		int count = 0;
		for (WebElement webElement : li) {

			if (webElement.getText().equals(dropdownValues[i]))
				count++;
			i++;
		}
		if (count == dropdownValues.length)
			return true;

		return false;
	}

	public boolean isUserabletoSelectYesorNoInUI(String label) {

		switch (label) {
		case "4 Eye Check Override":
			Element = action.getElementByFormatingXpath("Eye Check Over Ride", "Yes");
			action.pause(1000);
			Assert.assertTrue(get4EyeCheckOverrideValue().equals("Yes"),
					"User is able to select Radio button value for " + label + " as Yes");
			Element = action.getElementByFormatingXpath("Eye Check Over Ride", "No");
			action.pause(1000);
			Assert.assertTrue(get4EyeCheckOverrideValue().equals("Yes"),
					"User is able to select Radio button value for " + label + " as No");
			break;

		default:
			break;
		}

		return true;
	}

	public boolean isMessageDisplayedinUI(String message) {

		if (action.getPageSource().contains(message))
			return true;

		return false;
	}

	public void clickOnReset() {
		Element = action.fluentWaitWebElement("Reset");
		Element.click();

	}

	public boolean isPregressBarDisplayed() {

		Element = action.fluentWaitWebElement("Progress Bar");
		if (Element.isDisplayed())
			return true;

		return false;
	}

}
