package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdateManagerConfirmationPage {

	Action action;

	public UpdateManagerConfirmationPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	WebElement Element, Highlight;

	public boolean isUserOnConfirmationPage() {
		Element = (WebElement) action.waitForJSWebElement("Header");
		if (Element.getText().equals("Confirmation")) {
			Reporter.addCompleteScreenCapture();
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void verifyManagerUpdateSuccessfulMesssage() throws InterruptedException {
		WebElement ele = action.getElement("Manager Update Successful Messsage");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		Thread.sleep(1000);
	}

	public void verifyManagerID() throws InterruptedException {
		WebElement ele = action.getElement("Manager ID");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		Thread.sleep(1000);
	}

	public boolean isManagerUpdatedSuccessfully() {

		Element = (WebElement) action.fluentWaitForJSWebElement("Confirmation Tick Mark");
		if (Element.isDisplayed())
			return true;

		return false;
	}

	public String getManagerCode() {
		Element = action.fluentWaitWebElement("Manager Code");
		return Element.getText();
	}

	public void clickOnDoneButton() {
		Element = action.fluentWaitWebElement("Done");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		Element.click();
	}

	public String getManagerId() {
		Element = action.getElement("Manager ID");
		action.highligthElement(Element);
		String strategyInfo = Element.getText();
		System.out.println("Manager Id-01: "+strategyInfo);
		//strategyInfo = strategyInfo.replace("|", ";");
    	String message[] = strategyInfo.split("#");
    	System.out.println("Manager Id-02: "+message[0]);
    	System.out.println("Manager Id-03: "+message[1]);
    	return message[1].trim();
	}
}
