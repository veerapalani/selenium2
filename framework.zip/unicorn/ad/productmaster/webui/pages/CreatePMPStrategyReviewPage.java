package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;

import com.ibm.db2.jcc.am.la;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class CreatePMPStrategyReviewPage {

	Action action;
	public CreatePMPStrategyReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	WebElement Element,Highlight;
	public void clickOnSubmit() {
		action.scrollToBottom();
		action.getElement("Submit").click();
		
	}
	public void selectCheckBox() {
		action.pause(1000);
		action.scrollToBottom();
		Element = (WebElement) action.getElementByJavascript("Agreement Checkbox");
		Element.click();
		
	}
	public String getBenchmarkithValuefromUI(int j) {
		
		ArrayList<String> primarybenchmark = getPrimaryBenchmarksValue();
		
		return primarybenchmark.get(j).split("-#-")[2].trim();
		
	}
	public Float getPercentageithValuefromUI(int j) {
		
		ArrayList<String> primarybenchmark = getPrimaryBenchmarksValue();
		
		return Float.parseFloat(primarybenchmark.get(j).split("-#-")[3].trim());
	}
	
	public ArrayList<String> getPrimaryBenchmarksValue() {

		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		String primaryBenchmark = "";
		List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0), "Benchmarks List common tag");
		ArrayList<String> tempData = new ArrayList<String>();
		//String primaryBenchmark = "";
		int size  = Elements.size();
		int count = 0;
		DecimalFormat ds = new DecimalFormat(".00");
		for (int i = 0; i < size/3; i++) {
			primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName-#-@percentage";
			primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
			if(Elements.get(count).getText().equals("—")) {
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count+1).getText());
				primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Float.parseFloat(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
			}else if (Elements.get(count+1).getText().equals("—")) {
				if(primaryBenchmark.contains("@benchmarkCategory")) {
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
					primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Float.parseFloat(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
				}else {
					Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
				}
				
			}
			tempData.add(primaryBenchmark);
			//data = data+primaryBenchmark+":";
			count = count + 3;
			
		}
		/*
		 * if(tempData.size() > 1) { Collections.sort(tempData); primaryBenchmark = "";
		 * for (String G : tempData) { primaryBenchmark = primaryBenchmark+G+":"; } }
		 * tempData.clear();
		 */
		
		return tempData;
		
	}
	public void clickOnBenchmarkEditLink() {
		
		List<WebElement> WebElements = action.getElements("Edit Links common class");
		WebElements.get(1).click();
		
	}
	public void clickOnPrevious() {
		
		Element = action.getElement("PREVIOUS");
		Element.click();
		
	}
	public boolean isUserOnReviewPage() {
		
		Element = action.waitForJSWebElement("Header");
		if(action.getText(Element).equalsIgnoreCase("Review & Attestation")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	public boolean isSubmitButtonDisabled() {
		
		Element = action.getElement("Submit");
		action.moveToElement(Element);
		if(Element.getAttribute("disabled").equals("true"))
			return true;
		return false;
	}
	public boolean isLableDisabled(String label) {
		Element = action.getElementByFormatingXpath("Attribute Header", label);
		if(Element.getAttribute("disabled").equals("false"))
			return false;
		return true;
	}
	public String getcommonattributevalue(String label) {
		Element = action.getElementByFormatingXpath("Common Attribute Value", label);
		return Element.getText();
	}
	
	public String getBenchmarkValues(int i) {
		List<WebElement> values = action.getElements("Benchmark Values");
		action.scrollToElement(values.get(i));
		action.highligthElement(values.get(i));
		return values.get(i).getText();
	}
}
