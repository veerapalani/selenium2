package qa.unicorn.ad.productmaster.webui.pages;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
public class CreateBenchmarkFlyoutPage {

	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public  CreateBenchmarkFlyoutPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	public void verifyheaderinbenchmarkflyout() {
myElement = action.getElement("Create New Benchmark Header");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}
	public WebElement getHorizontalLineElement() {
		myElement = action.getElement("Headers");
		return myElement;
	}
	public void clickOncontinuebutton() throws Throwable{
		myElement = action.getElement("Continue Button");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	
	public void editdecriptionfieldincreatebenchmarkflyoutscreen() throws Throwable{
		Thread.sleep(4000);
		myElement = (WebElement) action.getElementByJavascript("edittxtBenchmarkDescription");
		action.highligthElement(myElement);
		
		action.sendKeys(myElement, "test");
		  
	}
	public void clickOncancelbutton() throws Throwable{
		myElement = action.getElement("Cancel Button");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public String giveCssValuehere(WebElement element, String attribute) {
		return element.getCssValue(attribute);
			}
	public void verifyElementsoncreatebenchmarkflyout(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	public void verifyElementsoncreatebenchmarkflyoutpage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	
	public Boolean validatingErrorMessage(String key, String expError) {
		Boolean flag = false;
		String actError = action.getElement("LessthanminBenchmarkDescription").getText();
		Reporter.addStepLog("Actual Message: "+actError);
		Reporter.addStepLog("Expected Message: "+expError);
		if(actError.equals(expError)) {
			flag = true;
		}

		return flag;
	}
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	public void verifystatusfieldoncreatebenchmarkflyout() {
		myElement = (WebElement) action.getElementByJavascript("Statusfield");
		action.highligthElement(myElement);
		Assert.assertFalse(action.isEnabled(myElement));
		Reporter.addScreenCapture();
	}
	public List<WebElement> findElementsByDynamicXpath(String xpath){
		Element element = new Element(WebDriverManager.getDriver());
		return element.getElements("xpath", xpath);
	}
}
