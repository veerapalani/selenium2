package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;

public class CreatenewFAPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement, Element;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	String expMsg = "https://pm.uat.wmap.broadridge.com/pmui/#/smaDualMac/add";
	public static String benchmarkName1, LargeTraderId1 = null;

	public CreatenewFAPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void clickOnFAinwizard() {

		// Element =(WebElement) action.fluentWaitForJSWebElement("FAMenu1");
		WebElement dropelement = (WebElement) action.fluentWaitForJSWebElement("FAMenu1");

		action.highligthElement(dropelement);
		action.jsClick(dropelement);
	}

	public void clickOncreatebutton() throws Throwable {
		action.scrollByPixel(Integer.toString(700));
		// action.pause(700);
		WebElement myElement = action.fluentWaitWebElement("CreateButton");
		action.highligthElement(myElement);
		action.click(myElement);

	}
}
