package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class ETFSortAndFilterPage {

	Action action;
	WebElement Element, myElement;

	public ETFSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchETFValue(String ETFSearchValue) {
		// Action.pause(2000);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitForJSWebElement("Global Search value ETF");
		Element.click();
		Element.clear();
		// Action.pause(2000);
		action.sendKeys(Element, ETFSearchValue);
		// Action.pause(5000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}
	}

	public void verifyETFTab() {
		// Action.pause(5000);
		Element = (WebElement) action.fluentWaitForJSWebElement("Next Arrow");
		while (Element.isDisplayed()) {

			// System.out.println("Inside While loop");
			// Element = (WebElement) action.fluentWaitForJSWebElement("Next Arrow");
			action.highligthElement(Element);
			Element.click();
			action.pause(2000);

		}
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("ETF Tab");
		// Action.pause(2000);
		action.highligthElement(Element);
		Element.isDisplayed();
		action.pause(2000);
		Element.click();
		action.pause(2000);
	}

	public String verifyTheMFGridCountAfterApplyFilterConditionOnTabForETF() {
		action.pause(4000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTabForETF");
		return action.getText(Element);
	}

}
