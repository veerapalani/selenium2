package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateManagerReviewPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();

	public CreateManagerReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void clickOnSubmitButton() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement)action.getElement("Submit Button"));
		action.captureEntireScreen();
		action.click((WebElement)action.getElement("Submit Button"));
	}

	public void verifyBackLink() {
		myElement = (WebElement)action.getElement("Back Link");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void clickOnPreviousButton() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement)action.getElement("Previous Button"));
		action.captureEntireScreen();
		action.click((WebElement)action.getElement("Previous Button"));
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public void verifyElementsoncreatemanagerreviewpage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void clickOnSaveAsdraftbuttoninCreateManagerReviewPage() {
		action.scrollByPixel("380");
		myElement = action.getElement("SaveAsDraftButtoninReviewPage");
		action.highligthElement(myElement);
		action.click(myElement);
		Reporter.addScreenCapture();
	}

	public void verifyTextInElement(String text, WebElement element) {
		Assert.assertEquals(element.getText(), text);
		action.highligthElement(element);
	}

	public void verifyreviewheader() {
		myElement = (WebElement)action.getElement("Review Header");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void clickOnBackLink() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement)action.getElement("Back Link"));
		action.captureEntireScreen();
		action.click((WebElement)action.getElement("Back Link"));
	}

	public String getcommonattributevalue(String label) {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", label);
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public void getcommonContactvalue() {
		listOfElements = action.getElements("Common Contacts Value");
		for(WebElement ele: listOfElements) {
			action.highligthElement(ele);
		}
	}
}
