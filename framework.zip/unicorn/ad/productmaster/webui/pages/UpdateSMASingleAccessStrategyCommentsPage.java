package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class UpdateSMASingleAccessStrategyCommentsPage {

	Action action;
	public UpdateSMASingleAccessStrategyCommentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element;
	public boolean isUserOnCommentsPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Comments")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	
	public void clickOnNext() {
		
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("NEXT");
				//action.waitForJSWebElement("NEXT");
		
		Element.click();
	}
	
}
