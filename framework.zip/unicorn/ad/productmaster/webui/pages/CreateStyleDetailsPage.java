package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.AssertJUnit.assertFalse;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;

import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;

public class CreateStyleDetailsPage {
	Action action;
	String token1;
	WebElement Element = null;
	WebDriver driver = null;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();

	public CreateStyleDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void isUserOnCreateStyleEnterInvestmentStyleDetailsPage() throws InterruptedException {
		Thread.sleep(3000);
		WebElement eisdelement = (WebElement) action.getElementByJavascript("Enter Style Details Header");
		action.moveToElement(eisdelement);
		action.highligthElement(eisdelement);
		Thread.sleep(3000);
		Reporter.addScreenCapture();
	}

	public void enterInvestmentStyleName(String investmentStyleName) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Investment Style Name");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		action.sendKeys(ele, investmentStyleName);
	}

	public void enterRiskCategory() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Risk Category");
		Thread.sleep(1000);
		action.scrollByPixel("24");
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Risk Category Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterBaseTemplate() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Base Template");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Base Template Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterFeeScheduleType(String piv_Y, String piv_N) throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(piv_Y);
		Boolean flag2 = Boolean.parseBoolean(piv_N);
		if (flag1 == false) {
			WebElement ele = (WebElement) action.getElementByJavascript("PIV Style N");
			Thread.sleep(1000);
			action.doubleClick(ele);
			action.highligthElement(ele);
			Thread.sleep(2000);
			Reporter.addScreenCapture();
			System.out.println("Ele is Selected = " + ele.isSelected());
			if (ele.isSelected() == flag1) {
				WebElement ele1 = (WebElement) action.getElementByJavascript("Fee Schedule Type");
				action.highligthElement(ele1);
				ele1.click();
				Thread.sleep(2000);
				WebElement ele2 = (WebElement) action.getElementByJavascript("Fee Schedule Type Data");
				action.highligthElement(ele2);
				ele2.click();
				Thread.sleep(1000);
			}
		} else {
			WebElement ele3 = (WebElement) action.getElementByJavascript("PIV Style Y");
			Thread.sleep(1000);
			ele3.click();
			action.highligthElement(ele3);
			Thread.sleep(2000);
			Reporter.addScreenCapture();
			System.out.println("Ele is Selected = " + ele3.isSelected());
			if (ele3.isSelected() == flag2) {
				WebElement ele4 = (WebElement) action.getElementByJavascript("Fee Schedule Type");
				action.highligthElement(ele4);
				assertFalse(ele4.isEnabled());
				Thread.sleep(1000);
			}
		}
	}

	public void enterStyleCategory() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Style Category");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Style Category Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void clickOnStyleCategoryDropdownbox() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Style Category");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
	}

	public List<WebElement> getElementsFromShadowRoot(String elementKey) {
		listOfElements = (List<WebElement>) action.getElementByJavascript(elementKey);
		return listOfElements;
	}

	public void verifyTextInListOfElements(String text, List<WebElement> list1) {

		for (int i = 0; i < list1.size(); i++) {
			list.add(list1.get(i).getText());
		}
		for (int i = 0; i < list.size(); i++) {
//			Reporter.addStepLog("checking with "+list.get(i));
			if (list.get(i).contains(text)) {
				action.highligthElement(list1.get(i));
				Assert.assertTrue(true);
				return;
			}
		}
		// Assert.assertTrue(false);
	}

	public void enterBalancedAllocation() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Balanced Allocation");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Balanced Allocation Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterComparativeUniverse() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Comparative Universe");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Universe Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterGeographicIndicator() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Geographic Indicator");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Geographic Indicator Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterMarketCap() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Market Cap");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Market Cap Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterHomeOfficeComments(String hocomments) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Home Office Comments");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		action.sendKeys(ele, hocomments);
		Thread.sleep(1000);
	}

	public void clickOnNextButton1() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Next Button 1");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(3000);
		ele.click();
		Thread.sleep(3000);
	}

	public void clickOnNextButton3() throws InterruptedException {
		WebElement ele = action.getElement("Next Button 3");
		action.moveToElement(ele);
		// action.highligthElement(ele);
		Thread.sleep(3000);
		action.doubleClick(ele);
		Thread.sleep(3000);
	}

	public void isUserOnBenchmarkandAssetClassificationHeaderPage() throws InterruptedException {
		Thread.sleep(1000);
		WebElement eisdelement = (WebElement) action
				.getElementByJavascript("Benchmark and Asset Classification Header");
		action.highligthElement(eisdelement);
		Thread.sleep(1000);
		Reporter.addScreenCapture();
	}

	public void enterBundledAssetClassification() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Bundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Bundled Asset Classification Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterSingleUnbundledAssetClassification() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Unbundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele2);
		ele2.click();
		ele2.clear();
		action.sendKeys(ele2, "100.00");
		Thread.sleep(1000);
	}

	public void enterMultipleUnbundledAssetClassification() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Unbundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele2);
		ele2.click();
		ele2.clear();
		action.sendKeys(ele2, "70.00");
		Thread.sleep(1000);
		WebElement ele3 = (WebElement) action.getElement("Add New Asset Classification");
		action.highligthElement(ele3);
		ele3.click();
		Thread.sleep(1000);
		WebElement ele4 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification2");
		action.highligthElement(ele4);
		ele4.click();
		Thread.sleep(1000);
		WebElement ele5 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data2");
		action.highligthElement(ele5);
		ele5.click();
		Thread.sleep(1000);
		WebElement ele6 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage2");
		action.highligthElement(ele6);
		ele6.click();
		ele6.clear();
		action.sendKeys(ele6, "30.00");
		Thread.sleep(1000);
	}

	public void enterSingleComparativeBenchmark(String sb_1, String cb_2) throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			ele.click();
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom");
			Thread.sleep(3000);
			action.highligthElement(ele);
			ele.click();
			Thread.sleep(1000);
			WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
			ele1.click();
			action.highligthElement(ele1);
			Thread.sleep(1000);
			WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
			action.highligthElement(ele2);
			ele2.click();
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			action.sendKeys(ele3, "100.00");
			Thread.sleep(1000);
		}
	}

	public void enterMultipleComparativeBenchmark(String sb_1, String cb_2) throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			ele.click();
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom");
			Thread.sleep(3000);
			action.highligthElement(ele);
			ele.click();
			Thread.sleep(1000);
			WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
			ele1.click();
			action.highligthElement(ele1);
			Thread.sleep(1000);
			WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
			action.highligthElement(ele2);
			ele2.click();
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			action.sendKeys(ele3, "80.00");
			Thread.sleep(1000);
			WebElement ele4 = (WebElement) action.getElement("Add New Benchmark");
			action.highligthElement(ele4);
			ele4.click();
			Thread.sleep(1000);
			WebElement ele5 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data2");
			action.highligthElement(ele5);
			ele5.click();
			Thread.sleep(1000);
			WebElement ele6 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark2");
			action.highligthElement(ele6);
			ele6.click();
			Thread.sleep(1000);
			WebElement ele7 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage2");
			action.highligthElement(ele7);
			ele7.click();
			ele7.clear();
			action.sendKeys(ele7, "20.00");
			Thread.sleep(1000);
		}
	}

	public void clickOnNextButton2() throws InterruptedException {
		WebElement ele = action.getElement("Next Button 3");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(3000);
		action.click(ele);
		/*
		 * Thread.sleep(1000); action.click(ele); Thread.sleep(3000);
		 */
	}
	/*
	 * Style Comparative Benchmark Custom Style Comparative Benchmark Custom Data
	 * Style Comparative Benchmark Custom Benchmark Style Comparative Benchmark
	 * Custom Percentage
	 */

	public void clickOnPreviousButton1() throws InterruptedException {
		WebElement ele = action.getElement("Previous Button 1");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(3000);
		ele.click();
		Thread.sleep(3000);
	}

	public void clickOnCancelButton1() throws InterruptedException {
		WebElement ele = action.getElement("Cancel Button 1");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(3000);
		ele.click();
		Thread.sleep(3000);
	}

	public void enterSingleComparativeBenchmarkWithoutBenchmarkName(String sb_1, String cb_2)
			throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			ele.click();
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom");
			Thread.sleep(3000);
			action.highligthElement(ele);
			ele.click();
			Thread.sleep(1000);

			/*
			 * WebElement ele1 = (WebElement)
			 * action.getElementByJavascript("Comparative Benchmark Custom Data");
			 * ele1.click(); action.highligthElement(ele1); Thread.sleep(1000); WebElement
			 * ele2 = (WebElement)
			 * action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
			 * action.highligthElement(ele2); ele2.click();
			 */
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			action.sendKeys(ele3, "100.00");
			Thread.sleep(1000);
		}
	}

	public void compareBenchmarkError1(String benchmarkError1) throws InterruptedException {
		WebElement ele = action.getElement("Create Style Benchmark Error1");
		System.out.println(ele.getText());
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(benchmarkError1);
		AssertJUnit.assertTrue(ele.getText().contains(benchmarkError1));
	}

	public void compareBenchmarkError2(String benchmarkError2) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Create Style Benchmark Error2");
		System.out.println(ele.getText());
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(benchmarkError2);
		AssertJUnit.assertTrue(ele.getText().contains(benchmarkError2));
	}

	public void enterMultipleComparativeBenchmarkWithDuplicateBenchmarkNames(String sb_1, String cb_2)
			throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			ele.click();
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom");
			Thread.sleep(3000);
			action.highligthElement(ele);
			ele.click();
			Thread.sleep(1000);
			WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
			ele1.click();
			action.highligthElement(ele1);
			Thread.sleep(1000);
			WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
			action.highligthElement(ele2);
			ele2.click();
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			action.sendKeys(ele3, "50.00");
			Thread.sleep(1000);
			WebElement ele4 = (WebElement) action.getElement("Add New Benchmark");
			action.highligthElement(ele4);
			ele4.click();
			Thread.sleep(1000);
			WebElement ele5 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data2");
			action.highligthElement(ele5);
			ele5.click();
			Thread.sleep(1000);
			WebElement ele6 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Duplicate Data");
			action.highligthElement(ele6);
			ele6.click();
			Thread.sleep(1000);
			WebElement ele7 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage2");
			action.highligthElement(ele7);
			ele7.click();
			ele7.clear();
			action.sendKeys(ele7, "40.00");
			Thread.sleep(1000);
		}
	}

	public void compareBenchmarkError3(String benchmarkError3) throws InterruptedException {
		WebElement ele = action.getElement("Create Style Benchmark Error3");
		System.out.println(ele.getText());
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(benchmarkError3);
		AssertJUnit.assertTrue(ele.getText().contains(benchmarkError3));
	}

	public void clickOnSaveDraftButton() throws InterruptedException {
		WebElement ele = action.getElement("Save Draft Button");
		action.highligthElement(ele);
		Thread.sleep(3000);
		action.doubleClick(ele);
		Thread.sleep(3000);
	}

	public void clickOnDraftCancelButton() throws InterruptedException {
		WebElement ele = action.getElement("Draft Cancel Button");
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(3000);
		action.doubleClick(ele);
		Thread.sleep(3000);
	}

	public void clickOnDraftSaveButton() throws InterruptedException {
		WebElement ele = action.getElement("Draft Save Button");
		action.highligthElement(ele);
		Thread.sleep(3000);
		action.doubleClick(ele);
		Thread.sleep(5000);
	}

	public void enterdraftName(String draftName) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Style Draft Name");
		Thread.sleep(2000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		action.sendKeys(ele, draftName);
		Reporter.addScreenCapture();
	}

	public void acceptAlertMessage() throws InterruptedException {
		Alert alt = WebDriverManager.getDriver().switchTo().alert();
		String actualmsg = alt.getText();
		System.out.println(actualmsg);
		Reporter.addStepLog(actualmsg);
		alt.accept();
	}

	public void verifySaveASDraftButton() throws InterruptedException {
		WebElement ele = action.getElement("Save Draft Button");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.isDisplayed(ele);
		Thread.sleep(3000);
	}

	public void verifySaveASDraftHeader(String Saveasadraftheader) throws InterruptedException {
		WebElement ele = action.getElement("Save as a draft header");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(3000);
	}

	public void verifyDraftNameHeader(String draftNameheader) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Draft Name header");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(3000);
	}

	public void verifySaveASDraftHeaderBenchmarkPage(String saveasadraftheader2) throws InterruptedException {
		WebElement ele = action.getElement("Save as a draft header2");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(3000);
	}

	public void verifyDraftNameHeaderBenchmarkPage(String draftNameheader2) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Draft Name header2");
		// return
		// document.querySelector('brml-input[id="provideDraftName"]').shadowRoot.querySelector("wf-tooltip>div>wf-tooltip>label")
		action.moveToElement(ele);
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(3000);
	}

	public void enterdraftNameBenchmarkPage(String draftName2) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Style Draft Name2");//// *[@id="provideDraftName"]
		Thread.sleep(2000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		action.sendKeys(ele, draftName2);
		Reporter.addScreenCapture();
	}

	public void clickOnDraftSaveButtonBenchmarkPage() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Draft Save Button2");
		action.highligthElement(ele);
		Thread.sleep(3000);
		action.doubleClick(ele);
		Thread.sleep(5000);
	}
	/*
	 * public void verifyDraftNameHeaderBenchmarkPage(String draftNameheader2)
	 * throws InterruptedException { WebElement ele = (WebElement)
	 * action.getElementByJavascript("Draft Name header");
	 * action.moveToElement(ele); action.highligthElement(ele);
	 * Reporter.addScreenCapture(); Thread.sleep(3000);
	 * 
	 * }
	 * 
	 * public void enterdraftNameBenchmarkPage(String draftName2) throws
	 * InterruptedException { List<WebElement> ele =
	 * action.fluentWaitWebElements("Style Draft Name2"); Thread.sleep(2000);
	 * ele.get(1).click(); action.highligthElement(ele.get(1)); Thread.sleep(1000);
	 * action.sendKeys(ele.get(1), draftName2); Reporter.addScreenCapture(); }
	 */

	public void verifyResetButton() throws InterruptedException {
		WebElement ele = action.getElement("Reset Button");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.isDisplayed(ele);
		Thread.sleep(3000);
	}

	public void clickOnResetButton() throws InterruptedException {
		WebElement ele = action.getElement("Reset Button");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		Thread.sleep(3000);
		action.doubleClick(ele);
		Thread.sleep(3000);
		Reporter.addCompleteScreenCapture();
		Thread.sleep(3000);
	}

	public void verifySaveDraftButtonIsHidden() throws InterruptedException {
		action.scrollToBottom();
		Reporter.addCompleteScreenCapture();
		List<WebElement> ele = action.getElements("Save Draft Button");
		if (ele.size() > 0) {
			Assert.fail("Save As Draft Button is present on UI");
		} else {
			Reporter.addStepLog("Save As Draft Button is not present in given page");
		}
	}

	public void enterSingleComparativeBenchmarkWithoutBenchmarkNameAndPercentage(String sb_1, String cb_2)
			throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			ele.click();
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom");
			Thread.sleep(3000);
			action.highligthElement(ele);
			action.jsClick(ele);
			Thread.sleep(1000);
		}
	}

	public void compareBenchmarkError4(String benchmarkError4) throws InterruptedException {
		WebElement ele = action.getElement("Create Style Benchmark Error4");
		System.out.println(ele.getText());
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(benchmarkError4);
		AssertJUnit.assertTrue(ele.getText().contains(benchmarkError4));
	}

	public void verifyUnbundledNodeIdDisplayedInDescOrder() {
		WebElement ele = (WebElement) action
				.getElementByJavascript("Verify CreateFlow UnbundledNodeId DisplayedIn DescOrder");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyCustomBenchmarksDisplayedInDescOrder() {
		WebElement ele = (WebElement) action
				.getElementByJavascript("Verify CreateFlow CustomBenchmarks DisplayedIn DescOrder");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyStyleBenchmarkbasedOnSelectedBundledNodeID() throws InterruptedException, SQLException {
		String eleText, eleBenchmarkText, SQLquery11;
		ResultSet rs11;
		WebElement ele = (WebElement) action.getElementByJavascript("Bundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Bundled Asset Classification Data");
		action.highligthElement(ele1);
		eleText = ele1.getText().substring(0, ele1.getText().indexOf('-'));
		System.out.println("eleText= " + eleText);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Style Benchmark View Details Link");
		action.highligthElement(ele2);
		ele2.click();
		Thread.sleep(3000);
		WebElement ele3 = (WebElement) action.getElementByJavascript("Verify Popup Benchmark Header");
		action.highligthElement(ele3);
		Thread.sleep(2000);
		WebElement ele4 = (WebElement) action.getElementByJavascript("Verify Bundled based Style Benchmark Name");
		action.highligthElement(ele4);
		eleBenchmarkText = ele4.getText();
		System.out.println("eleBenchmarkText= " + eleBenchmarkText);
		Thread.sleep(2000);
		Reporter.addCompleteScreenCapture();
		pmdb.DBConnectionStart();
		SQLquery11 = "select b.benchmark_name from benchmark b join node_id_benchmark nib on b.benchmark_id=nib.benchmark_id where nib.style_node_id=(select ac.style_node_id from asset_classification ac where ac.style_name='"
				+ eleText + "'limit 1) and nib.effective_to_date is null";
		System.out.println("SQLquery11= " + SQLquery11);
		rs11 = DBManager.executeSelectQuery(SQLquery11);
		while (rs11.next()) {
			token1 = rs11.getString(1);
			if (rs11.wasNull()) {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1.equalsIgnoreCase(eleBenchmarkText)) {
			Assert.assertTrue(token1.equalsIgnoreCase(eleBenchmarkText));
			Reporter.addStepLog("UI Value= " + eleBenchmarkText);
			Reporter.addStepLog("DB Value= " + token1);
			Reporter.addStepLog(
					"UI and DB values of  populated style default benchmark matches with the selected bundled node id on PMUI");
		} else {
			Reporter.addStepLog("UI Value= " + eleBenchmarkText);
			Reporter.addStepLog("DB Value= " + token1);
			Reporter.addStepLog(
					"UI and DB values of populated style default benchmark doesnot with the selected bundled node id on PMUI");
		}
	}
}
