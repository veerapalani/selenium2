package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateStyleReviewPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement, myElement1, myElement2;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	WebElement Element;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();

	public CreateStyleReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));

	}
	public String getTextfromGridforRow(String value) {
		myElement = action.getElementByFormatingXpath("Grid Common Row value", value);
		action.moveToElement(myElement);
		return myElement.getText();
	}
	
	public void clickOnPrintButton() {
		Action.pause(2000);
		Element = action.fluentWaitWebElement("Print Button");
		action.moveToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
		
	}
	public void verifyElementinCreateStyleReviewPage(String elementKey) {
		myElement = action.getElement(elementKey);
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void verifyAttributesinCreateStyleReviewPage() {
		myElement = action.getElement("Back Link");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		action.click(myElement);
		Reporter.addScreenCapture();
	}

	public void verifytimestampinCreateStyleReviewPage() {
		myElement = action.getElement("Timestamp");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public void verifyButtonsinCreateStyleReviewPage() throws InterruptedException {
		myElement = action.getElement("Previous Button_Review page");
		action.highligthElement(myElement);
		action.click(myElement);
		Reporter.addScreenCapture();
	}

	public void clickOntheelementsoncreatestylereviewpage(String elementKey) throws Throwable {
		myElement = action.getElement(elementKey);
		action.highligthElement(myElement);
		action.click(myElement);

	}

	public void verifyWebElementinCreateStyleReviewPage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void verifyreviewheaderinCreateStyleReviewPage() throws InterruptedException {
		Thread.sleep(1000);
		myElement = (WebElement) action.getElementByJavascript("Review Header");
		action.moveToElement(myElement);
		Thread.sleep(1000);
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		// action.click(myElement);
		Reporter.addScreenCapture();
	}

	public void verifyreviewpagedetailsinCreateStyleReviewPage() throws InterruptedException {
		Thread.sleep(1000);
		myElement1 = (WebElement) action.getElementByJavascript("Reviewpage InvestmentStyleDetails Header");
		Thread.sleep(1000);
		action.highligthElement(myElement1);
		Assert.assertTrue(action.isDisplayed(myElement1));
		Thread.sleep(1000);
		myElement2 = (WebElement) action.getElementByJavascript("Reviewpage BenchmarkandAssetClassification Header");
		Thread.sleep(1000);
		action.moveToElement(myElement2);
		action.highligthElement(myElement2);
		Assert.assertTrue(action.isDisplayed(myElement2));
		Reporter.addCompleteScreenCapture();
	}

	public void verifysubmitButtoninCreateStyleReviewPage() throws InterruptedException {
		Thread.sleep(2000);
		myElement = action.getElement("Submit Button");
		action.moveToElement(myElement);
		Thread.sleep(2000);
		action.scrollToBottom();
		action.highligthElement(myElement);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		action.click(myElement);

	}

	public void clickOnPreviousButton2InReviewPage() throws InterruptedException {
		WebElement ele = action.getElement("Previous Button 2");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(3000);
		ele.click();
		Reporter.addCompleteScreenCapture();
		Thread.sleep(3000);

	}

	public void verifyUnbundledNodeIdDisplayedInDescOrder() {
		myElement1 = (WebElement) action.getElementByJavascript("Verify UnbundledNodeId DisplayedIn DescOrder");
		action.highligthElement(myElement1);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyCreateFlowUnbundledNodeIdDisplayedInDescOrder() {
		myElement1 = (WebElement) action
				.getElementByJavascript("Verify CreateFlow UnbundledNodeId DisplayedIn DescOrder");
		action.highligthElement(myElement1);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyCustomBenchmarksDisplayedInDescOrder() {
		myElement1 = (WebElement) action.getElementByJavascript("Verify CustomBenchmarks DisplayedIn DescOrder");
		action.highligthElement(myElement1);
		Reporter.addCompleteScreenCapture();
	}
}
