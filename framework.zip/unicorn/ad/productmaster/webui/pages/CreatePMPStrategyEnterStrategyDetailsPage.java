package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.Assert.assertTrue;

import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class CreatePMPStrategyEnterStrategyDetailsPage {

	Action action;
	Boolean flag;
	WebElement Element,Highlight;
	int loopCount;
	
	public CreatePMPStrategyEnterStrategyDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	public boolean isUserOnCreateStrategyWizardPage() {
		flag = false;
		
		Element = action.waitForJSWebElement("Create Strategy Header");
		if(Element.getText().equals("Create Strategy")) {
			flag = true;
		    action.highligthElement(Element);
		}
		
		return flag;
	}
	
	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void clickOnPMPRadioButton() {
		
		//Accessing a Radio Button
		((WebElement) action.fluentWaitForJSWebElement("PMP button")).click();
		
	}
	public void enterStrategyName(String strategyName) {
		Element =(WebElement) action.fluentWaitForJSWebElement("Add Strategy Name");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, strategyName);
		} while (!(getStrategyNameValueFromLandingPage().equals(strategyName)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}
	private String getStrategyNameValueFromLandingPage() {
		Element = action.waitForJSWebElement("Add Strategy Name Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}
	public String getStrategyName() {
		Element = action.waitForJSWebElement("Strategy Name Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}
	public void clickOnCreateButton() {
		
		Element = action.fluentWaitWebElement("CREATE");
		Element.click();
		
	}
	public boolean isUserOnEnterStrategyDetailsPage() {
		flag = false;
		Element = action.waitForJSWebElement("Enter Strategy Details Header");
		if(Element.getText().equals("Enter Strategy Details")) {
			flag = true;
		    action.highligthElement(Element);
		}
		
		return flag;
		
		
	}
	public void enterInvestmentStyleName(String investmentStyleName) {
		
		Element = (WebElement) action.fluentWaitForJSWebElement("Investment Style");
		action.click(Element);
		Highlight = (WebElement) action.getElementByJavascript("Investment Style Value");
		Highlight = Highlight.findElement(By.linkText(investmentStyleName));
		/*
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(investmentStyleName)) {
				Highlight = E;
				break;
			}
		}
		*/
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
	}
	public void selectFARadioButton() {
		Element = (WebElement) action.fluentWaitForJSWebElement("FA");
		Element.click();
		
	}
	public void selectFATeamRadioButton() {
		Element = (WebElement) action.fluentWaitForJSWebElement("FA TEAM");
		Element.click();
		
	}
	public void enterFaName(String faAndFaTeamName, String fatype) {
		action.pause(3000);
		Element = (WebElement) action.getElementByFormatingXpath("FA AND FATEAM NAME", fatype);
		action.click(Element);
		action.pause(1000);
		Highlight = (WebElement) action.getElementByFormatingXpath("FA AND FATEAM NAME Value", fatype);
		switch (fatype) {
		case "fa":
			Highlight = Highlight.findElement(By.linkText(faAndFaTeamName));
			break;
		case "faTeam":
			
			//Highlight = Highlight.findElement(By.xpath("//p[text(), '"+faAndFaTeamName+"']"));
			
			List<WebElement> list = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
			for (WebElement E : list) {
				List<WebElement> list2 = action.getElementsFromParentElement(E, "FA Team Value");
				if(list2.size() > 0) {
					if(list2.get(0).getText().equalsIgnoreCase(faAndFaTeamName)) {
						System.out.println(list2.get(0).getText());
						Highlight = E;
							
							break;
					}
				}
			}
		
			
			//Highlight = Highlight.findElement(By.linkText(faAndFaTeamName));
			break;
		default:
			break;
		}
		
		/*
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(faAndFaTeamName)) {
				Highlight = E;
				break;
			}
		}
		*/
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
	}
	public void enterFaSegment(String faSegment, String typeofuser) {
		if(typeofuser.contains("HO")) {
			
			Element = (WebElement) action.fluentWaitForJSWebElement("PMP Title");
			action.click(Element);
			Highlight = (WebElement) action.getElementByJavascript("PMP Title Dropdown List");
			Highlight = Highlight.findElement(By.linkText(faSegment));
			/*
			List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
			
			for(WebElement E : li) {
				if(E.getText().equalsIgnoreCase(faSegment)) {
					Highlight = E;
					break;
				}
			}
			*/
			action.scrollToElement(Highlight);
			action.highligthElement(Highlight);
			action.click(Highlight);
		}
		
		
	}
	public String getFaSegmentValue() {
		Element = action.fluentWaitWebElement("PMP Title Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}
	public void enterMarginEligible(String marginEligible) {
		if(marginEligible.equalsIgnoreCase("yes")) {
			Element= (WebElement) action.fluentWaitForJSWebElement("Margin Eligible");
			Element.click();
		}
		
	}
	public void enterStructuredProductsStrategy(String structuredProductsStrategy) {
		structuredProductsStrategy = structuredProductsStrategy.toLowerCase().trim();
		switch (structuredProductsStrategy) {
		case "yes":
			Element= (WebElement) action.fluentWaitForJSWebElement("Structured Products Strategy Yes");
			Element.click();
			break;
		case "no":
			Element= (WebElement) action.fluentWaitForJSWebElement("Structured Products Strategy No");
			Element.click();
			break;
		case "not defined":
			Element= (WebElement) action.fluentWaitForJSWebElement("Structured Products Strategy Not Defined");
			Element.click();
			break;

		default:
			break;
		}
		
	}
	public void enterConcentratedStrategyIndicator(String concentratedStrategyIndicator) {
		concentratedStrategyIndicator = concentratedStrategyIndicator.toLowerCase().trim();
		switch (concentratedStrategyIndicator) {
		case "yes":
			Element= (WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator Yes");
			Element.click();
			break;
		case "no":
			Element= (WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator No");
			Element.click();
			break;
		case "not defined":
			Element= (WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator Not Defined");
			Element.click();
			break;

		default:
			break;
		}
		
	}
	public void enterShortTermMaturity(String shortTermMaturity) {
		shortTermMaturity = shortTermMaturity.toLowerCase().trim();
		switch (shortTermMaturity) {
		case "yes":
			Element= (WebElement) action.fluentWaitForJSWebElement("Short Term Maturity Yes");
			Element.click();
			break;
		case "no":
			Element= (WebElement) action.fluentWaitForJSWebElement("Short Term Maturity No");
			Element.click();
			break;
		case "not defined":
			Element= (WebElement) action.fluentWaitForJSWebElement("Short Term Maturity Not Defined");
			Element.click();
			break;

		default:
			break;
		}
		
	}
	public void enterHedgeCoreIndicator(String hedgeCoreIndicator) {
		hedgeCoreIndicator = hedgeCoreIndicator.toLowerCase().trim();
		switch (hedgeCoreIndicator) {
		case "yes":
			Element= (WebElement) action.fluentWaitForJSWebElement("Hedge Core Indicator Yes");
			Element.click();
			break;
		case "no":
			Element= (WebElement) action.fluentWaitForJSWebElement("Hedge Core Indicator No");
			Element.click();
			break;
		case "not defined":
			Element= (WebElement) action.fluentWaitForJSWebElement("Hedge Core Indicator Not Defined");
			Element.click();
			break;

		default:
			break;
		}
		
	}
	public void enterSustainableInvestmentStrategy(String sustainableInvestmentStrategy) {
		sustainableInvestmentStrategy = sustainableInvestmentStrategy.toLowerCase().trim();
		switch (sustainableInvestmentStrategy) {
		case "yes":
			Element= (WebElement) action.fluentWaitForJSWebElement("Sustainable Investment Strategy Yes");
			Element.click();
			break;
		case "no":
			Element= (WebElement) action.fluentWaitForJSWebElement("Sustainable Investment Strategy No");
			Element.click();
			break;
		case "not defined":
			Element= (WebElement) action.fluentWaitForJSWebElement("Sustainable Investment Strategy Not Defined");
			Element.click();
			break;

		default:
			break;
		}
		
	}
	public void enterAlternativeStrategy(String alternativeStrategy) {
		alternativeStrategy = alternativeStrategy.toLowerCase().trim();
		switch (alternativeStrategy) {
		case "yes":
			Element= (WebElement) action.fluentWaitForJSWebElement("Alternatives Strategy Yes");
			Element.click();
			break;
		case "no":
			Element= (WebElement) action.fluentWaitForJSWebElement("Alternatives Strategy No");
			Element.click();
			break;
		case "not defined":
			Element= (WebElement) action.fluentWaitForJSWebElement("Alternatives Strategy Not Defined");
			Element.click();
			break;

		default:
			break;
		}
		
	}
	public void enterNonPmpApprovedTeamEmails(String nonPmpApprovedTeamEmails) {
		Element =(WebElement) action.fluentWaitForJSWebElement("Non PMP Approved Email");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, nonPmpApprovedTeamEmails);
		} while (!(getNonPMPApprovedTeamMemberEmailsValue().equals(nonPmpApprovedTeamEmails)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}
	public void enterDvpKeyTrustTemplate(String dvpKeyTrustTemplate) {
		
		Element = (WebElement) action.fluentWaitForJSWebElement("DVP/Key Trust Template");
		action.click(Element);
		Highlight = (WebElement) action.getElementByJavascript("DVP/Key Trust Template Value");
		Highlight = Highlight.findElement(By.linkText(dvpKeyTrustTemplate));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
	}
	public void enterHideStrategy(String hideStrategy) {//texttobepresented
		
		if(hideStrategy.equalsIgnoreCase("yes")) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Hide Strategy");
		Element.click();
		}
		
	}
	public void enterStrategyNameBU(String strategyName) {
		Element = (WebElement) action.getElement("xpath", "//brml-input[@id='strategyName']");
		loopCount = 0;
		do {
			
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, strategyName);
		} while (!getStrategyName().equals(strategyName) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}
	public void clickOnNext() {
		Element = action.waitForJSWebElement("Next");
		action.scrollToElement(Element);
		Element.click();
		
	}
	public void enterstrategyTier(String strategyTier) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Strategy Tier");
		action.click(Element);
		Highlight =(WebElement) action.fluentWaitForJSWebElement("Strategy Tier Value");
		Highlight = Highlight.findElement(By.linkText(strategyTier));
		/*
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(strategyTier)) {
				Highlight = E;
				break;
			}
		}
		*/
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
	}
	public void enterdisplayStrategyCompositeOnAdvisoryFrontEnd(String displayStrategyCompositeOnAdvisoryFrontEnd) {
		if(displayStrategyCompositeOnAdvisoryFrontEnd.equalsIgnoreCase("yes")) {
			Element =(WebElement) action.fluentWaitForJSWebElement("Display Strategy Composite");
			Element.click();
			}
		
	}
	public String getStrategyTierValue() {
		Element = action.fluentWaitWebElement("Strategy Tier Attribute Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}
	public boolean istheAttributeHeaderVisible(String label) {
		Element = action.getElementByFormatingXpath("Common Attribute Header", label);
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
	
		return false;
	}
	public String checkFAorFATeamRadiobuttonselected() {
		
		Element = action.getElement("Common component for FA Selection Radio Buttons");
		return Element.getAttribute("label");
	}
	
	public String checkforchangedFAorFATeamRadiobuttonselected() {
		
		Element = action.getElement("FA");
		Highlight = action.getElement("FA TEAM");
		if(Element.getAttribute("class").contains("checked")) {
			return "FA";
			}
		else if(Highlight.getAttribute("class").contains("checked")) {
			return "FA Team";
			}
			
		return "none";
	}
	
	public String getInvestmentStyleNameValue() {
		
		Element = action.getElement("Investment Style UI Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		data = action.getElementByFormatingXpath("Investment Style Name", data).getAttribute("name");
		return data;
	}
	public String getFANameValue() {
		switch (checkFAorFATeamRadiobuttonselected()) {
		case "FA":
			return getFAValue("fa");
			
		case "FA Team":
			return "isEmpty";
			
		default:
			break;
		}
		return null;
	}
	public String getFAValue(String data) {
		List<WebElement> elements = null;
		switch (data) {
		case "fa":
			elements = action.getElements("FA Name");
			break;
		case "faTeam":
			elements = action.getElements("FA Team Name");
			break;

		default:
			break;
		}
		if(elements.size() > 0) {
			return elements.get(0).getAttribute("name");
		}else {
			return "";
		}	
	}
	public String getFATeamNameValue() {
		switch (checkFAorFATeamRadiobuttonselected()) {
		case "FA":
			return "isEmpty";
			
		case "FA Team":
			return getFAValue("faTeam");
			
		default:
			break;
		}
		return null;
	}
	public String getMarginEligibleValue() {

		Element = (WebElement) action.getElementByJavascript("Margin Eligible Value");
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "Yes";
		}else {
			return "No";
		}
	}
	public String getStructuredProductsStrategyValue() {
		
		Element = action.getElement("Structured Products Strategy Value");
		
		switch (Element.getAttribute("value")) {
		case "true":
			
			return "Yes";
		case "false":
			
			return "No";
		case "null":
	
			return "Not Defined";

		default:
			break;
		}
		return null;
	}
	public String getConcentratedStrategyIndicator() {
		Element = action.getElement("Concentrated Strategy Indicator Value");
		
		switch (Element.getAttribute("value")) {
		case "true":
			
			return "Yes";
		case "false":
			
			return "No";
		case "null":
	
			return "Not Defined";

		default:
			break;
		}
		return null;
	}
	public String getShortTermMaturityValue() {
		Element = action.getElement("Short Term Maturity Value");
		
		switch (Element.getAttribute("value")) {
		case "true":
			
			return "Yes";
		case "false":
			
			return "No";
		case "null":
	
			return "Not Defined";

		default:
			break;
		}
		return null;
	}
	public String getHedgeCoreIndicatorValue() {
		Element = action.getElement("Hedge Core Indicator Value");
		
		switch (Element.getAttribute("value")) {
		case "true":
			
			return "Yes";
		case "false":
			
			return "No";
		case "null":
	
			return "Not Defined";

		default:
			break;
		}
		return null;
	}
	public String getSustainableInvestmentStrategyValue() {
		Element = action.getElement("Sustainable Investment Strategy Value");
		
		switch (Element.getAttribute("value")) {
		case "true":
			
			return "Yes";
		case "false":
			
			return "No";
		case "null":
	
			return "Not Defined";

		default:
			break;
		}
		return null;
	}
	
	
	public void editingstrategydetails() throws InterruptedException 
	{
		Thread.sleep(5000);
		WebElement ele = (WebElement) action.getElementByJavascript("editstrategy");
		Thread.sleep(5000);
		//action.highligthElement(ele);
		//Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}
	public String getAlternativesStrategyValue() {
		Element = action.getElement("Alternatives Strategy Value");
		
		switch (Element.getAttribute("value")) {
		case "true":
			
			return "Yes";
		case "false":
			
			return "No";
		case "null":
	
			return "Not Defined";

		default:
			break;
		}
		return null;
	}
	public String getNonPMPApprovedTeamMemberEmailsValue() {
		
		Element = action.getElement("Non PMP Approved Email Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
		
	}
	public String getDVPKeyTrustTemplate() {
		Element = action.getElement("DVP/Key Trust Template UI Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		data = action.getElementByFormatingXpath("DVP/Key Trust Template Name", data).getAttribute("name");
		return data;
	}
	public String getHideStrategyValue() {
		
		Element = (WebElement) action.getElementByJavascript("Hide Strategy Value");
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "Yes";
		}else {
			return "No";
		}
	}
	public void clickOnResetButton() {
		Element = action.getElement("RESET");
		Element.click();
		
	}
	public String getattributeValuebylabel(String label) {
		
		Element = action.getElementByFormatingXpath("Common Attribute Header", label);
		
		return Element.getAttribute("value");
	}
	public boolean isProgramheaderVisible(String program) {
		Element = action.getElementByFormatingXpath("Program Header", program);
		if(Element.isDisplayed())
			return true;
		return false;
	}
	public boolean error(String experror) {
		flag = false;
		action.pause(2000);
		String[] expErrorlist = experror.split("-");
		/*
		 * if(experror.contains("-")) { expErrorlist = experror.split("-"); } else
		 * expErrorlist[0] = experror;
		 */
		
				
		for(String S:expErrorlist) {
			switch (S) {
			case "Add Strategy Name must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Add Strategy Name");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: "+Element.getText());
				Reporter.addStepLog("Expected Message: "+S);
				flag=true;
				break;
			case "Select Program must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Select Program");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: "+Element.getText());
				Reporter.addStepLog("Expected Message: "+S);
				flag=true;
				break;

			default:
				Reporter.addStepLog("Expected Message: "+S);
				Reporter.addStepLog("Expected Error Message is invalid ");
				flag = false;
				break;
			}
			if(flag == false)
				break;
		}
		
		return flag;
		
	}
	public int getFATeamDropdownCount(String fatype) {
		
		Element = (WebElement) action.getElementByFormatingXpath("FA AND FATEAM NAME", fatype);
		action.click(Element);
		action.pause(3000);
		Highlight = (WebElement) action.getElementByFormatingXpath("FA AND FATEAM NAME Value", fatype);
		List<WebElement> list = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
				
		return list.size()-2;
	}
	
	public void clickonnext() throws InterruptedException {
		Thread.sleep(2000);
		WebElement ele = (WebElement) action.getElementByJavascript("Next Button");
		Thread.sleep(3000);
		action.scrollToElement(ele);
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(6000);
	}
	
 public void attest()  throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele = (WebElement) action.getElementByJavascript("Attestation");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(6000);
	 
 }
 
 public void submission() throws InterruptedException {
		//Thread.sleep(7000);
		WebElement ele = (WebElement) action.getElementByJavascript("Submission_end");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(8000);
 }
 public void highlightthechanges() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Highlight strategy name");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(2000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Highlight Investment style");
		action.scrollToElement(ele1);
		action.highligthElement(ele1);
		Thread.sleep(2000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Highlight FA");
		action.scrollToElement(ele2);
		action.highligthElement(ele2);
		Thread.sleep(2000);
	
		
		
	 
 }
 public void closure() throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Next page navigate");
		action.scrollToElement(ele2);
		action.highligthElement(ele2);
		Thread.sleep(6000);
 }

	public void CheckingPMPTitle() {
		// TODO Auto-generated method stub
		Element = action.fluentWaitWebElement("PMP Title_PMP");
		Assert.assertTrue(action.isDisplayed(Element));
	}
	
public void strategydate() throws InterruptedException{
	Thread.sleep(4000);
	WebElement ele2 = (WebElement) action.getElementByJavascript("Strategy date");
	action.scrollToElement(ele2);
	action.highligthElement(ele2);
	Thread.sleep(6000);
	
}
	
}

