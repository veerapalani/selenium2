package qa.unicorn.ad.productmaster.webui.pages;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;

public class CreateSMADualBenchmarkPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement,Highlight;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	String expMsg = "https://pm.uat.wmap.broadridge.com/pmui/#/smaDualMac/add";
	Boolean flag;
	String mandatorydetails, sheetName = "";
	int rowIndex;
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMADualStrategy.xlsx";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	public CreateSMADualBenchmarkPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void clickOnNextButtononBenchmarkPage() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement) action.getElementByJavascript("NextButton_SMADualbenchmark"));
		action.captureEntireScreen();
		action.click((WebElement) action.getElementByJavascript("NextButton_SMADualbenchmark"));
	}

	public void enterSingleUnbundledAssetClassification() throws InterruptedException {
		// {
		// action.fluentWaitWebElement("Unbundled Asset Classification_Dual");
		// WebElement ele = (WebElement) action.getElementByJavascript("Unbundled Asset
		// Classification_Dual");
		// Thread.sleep(1000);
		// ele.click();
		// action.highligthElement(ele);
		///// Thread.sleep(1000);

		WebElement ele = (WebElement) action.getElementByJavascript("Unbundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data_Dual");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage_Dual");
		action.highligthElement(ele2);
		ele2.click();
		ele2.clear();
		action.sendKeys(ele2, "100.00");
		Thread.sleep(1000);
	}

	public void enterMultipleComparativeBenchmark(String sb_1, String cb_2) throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			ele.click();
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom_Dual");
			Thread.sleep(3000);
			action.highligthElement(ele);
			ele.click();
			Thread.sleep(1000);
			WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data_Dual");
			ele1.click();
			action.highligthElement(ele1);
			Thread.sleep(1000);
			WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark_Dual");
			action.highligthElement(ele2);
			ele2.click();
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action
					.getElementByJavascript("Comparative Benchmark Custom Percentage_Dual");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			action.sendKeys(ele3, "80.00");
			Thread.sleep(1000);
			WebElement ele4 = (WebElement) action.getElement("Add New Benchmark");
			action.highligthElement(ele4);
			ele4.click();
			Thread.sleep(1000);
			WebElement ele5 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data2_Dual");
			action.highligthElement(ele5);
			ele5.click();
			Thread.sleep(1000);
			WebElement ele6 = (WebElement) action
					.getElementByJavascript("Comparative Benchmark Custom Benchmark2_Dual");
			action.highligthElement(ele6);
			ele6.click();
			Thread.sleep(1000);
			WebElement ele7 = (WebElement) action
					.getElementByJavascript("Comparative Benchmark Custom Percentage2_Dual");
			action.highligthElement(ele7);
			ele7.click();
			ele7.clear();
			action.sendKeys(ele7, "20.00");
			Thread.sleep(2000);
			WebElement ele41 = (WebElement) action.getElementByJavascript("Comparative Benchmark Reason_Dual");
			action.highligthElement(ele41);
			action.sendKeys(ele41, "test benchmark reason goes here");
			Thread.sleep(2000);
		}
	}

	public void enterSingleComparativeBenchmark(String sb_1, String cb_2) throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style_Dual");
			Thread.sleep(2000);
			action.highligthElement(ele);
			ele.click();
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom_Dual");
			Thread.sleep(3000);
			action.highligthElement(ele);
			ele.click();
			Thread.sleep(1000);
			WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data_Dual");
			ele1.click();
			action.highligthElement(ele1);
			Thread.sleep(1000);
			WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark_Dual");
			action.highligthElement(ele2);
			ele2.click();
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action
					.getElementByJavascript("Comparative Benchmark Custom Percentage_Dual");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			action.sendKeys(ele3, "100.00");
			Thread.sleep(1000);
			WebElement ele4 = (WebElement) action.getElementByJavascript("Comparative Benchmark Reason_Dual");
			action.highligthElement(ele4);
			action.sendKeys(ele4, "test benchmark reason goes here");
			Thread.sleep(1000);
		}
	}

	public boolean isDvpKeyTrustTemplateVisible() {
		flag = false;
		action.fluentWaitForJSWebElement("Dvp Key Trust Template");
		myElement = action.getElement("Dvp Key Trust Template");
		if (myElement.isDisplayed()) {
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			flag = true;
		}
		return flag;
	}

	public boolean isUserOnBenchmarkPage() {
		flag = false;
		myElement = action.waitForJSWebElement("Benchmark Header");
		if (myElement.getText().contains("Benchmark")) {
			flag = true;
			action.highligthElement(myElement);
		}
		return flag;
	}

	public void clickOnAddNewAssetClassification() {
		myElement = action.fluentWaitWebElement("Add New Asset Classification");
		if (myElement.isDisplayed()) {
			action.highligthElement(myElement);
			action.click(myElement);
		}
	}
	
	public void enterUnbundledNodeId(String replace, String replace2, String string) {
		//action.waitForJSWebElement("Asset Classification Text");
		//String locatorValue = "return document.querySelector('brml-select#ddlBenchmarkunBundledNode-"+assetNumber+"').shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')";
		myElement = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
		myElement.click();
		//locatorValue = "return document.querySelector('brml-select#ddlBenchmarkunBundledNode-"+assetNumber+"').shadowRoot.querySelector('wf-dropdown ul')";
		Highlight = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace2), 10);
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		for(WebElement E: li) {
			if(E.getText().equalsIgnoreCase(string)) {
				Highlight = E;
				break;
			}
		}
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterUnbundledNodeIdPercentage(String replace, String string) {
		myElement = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
		myElement.click();
		myElement.clear();
		myElement.sendKeys(string);
		myElement = (WebElement)action.getElementByJavascript("Bundled Node Id");
		myElement.click();
	}
	
	public String getUnbundledithValuefromUI(int j) {
		String benchmarkValue = action.getElementByFormatingXpath("Unbundled Node Id From UI", j).getAttribute("value");
		
		myElement = action.getElementByFormatingXpath("Unbundled Node Id Value From UI", benchmarkValue);
		
		return myElement.getAttribute("name");
	}

	public Float getUnbundledPercentageithValuefromUI(int j) {
		myElement = action.getElementByFormatingXpath("Unbundled Node Id Percentage Value From UI", j);
		return Float.parseFloat(myElement.getAttribute("value"));
	}

	public boolean isUnbundledNodeidMandatory() {
		myElement = action.waitForJSWebElement("Unbundled Node Id Mandatory");
		if(myElement.isDisplayed()) {
			action.highligthElement(myElement);
			return true;
		}
		return false;
	}

	public String getBenchmarkithValuefromUI(int i) {
		String benchmarkValue = action.getElementByFormatingXpath("Benchmark From UI", i).getAttribute("value");
		myElement = action.getElementByFormatingXpath("Benchmark Value From UI", benchmarkValue);
		return myElement.getAttribute("name");
	}

	public Float getPercentageithValuefromUI(int i) {
		myElement = action.getElementByFormatingXpath("Percentage Value From UI", i);
		return Float.parseFloat(myElement.getAttribute("value"));
	}

	public void selectCustom() {
		action.fluentWaitWebElement("Asset Classification Text");
		action.scrollToBottom();
		myElement = action.fluentWaitWebElement("Custom");
		myElement.click();
	}
	
	public void enterCustomBenchmark(String replace, String replace2, String string, String benchmarkCategory) {
		if(benchmarkCategory.equalsIgnoreCase("Custom")) {
			myElement = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
			//Element = action.waitForJSWebElement("Investment Style");
			action.click(myElement);
			Highlight = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace2), 10);
			//List<WebElement> li2 = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
			Highlight = Highlight.findElement(By.linkText(string));
			/*
			 * //System.out.println(li2.size()); for(WebElement G : li2) {
			 * //System.out.println(G.getText()); if(G.getText().equalsIgnoreCase(string)) {
			 * Highlight = G; break; } }
			 */
			action.scrollToElement(Highlight);
			action.highligthElement(Highlight);
			action.click(Highlight);
		}
	}

	public void enterCustomBenchmarkPercentage(String replace, String string, String benchmarkCategory) {
		if(benchmarkCategory.equalsIgnoreCase("Custom")) {
			myElement = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
			//(WebElement) action.getElementByJavascript("Percentage");
			myElement.click();
			myElement.clear();
			myElement.sendKeys(string);
			myElement = (WebElement)action.fluentWaitForJSWebElement("Bundled Node Id");
			myElement.click();
		}
	}

	public void addNewBenchmark() {
		myElement = action.waitForJSWebElement("Add New Benchmark");
		myElement.click();
	}
	
	public void enterCustomBenchmarkReason(String customBenchmarkReason) {
		myElement = (WebElement)action.fluentWaitForJSWebElement("Custom Benchmark Reason");
		myElement.click();
		myElement.sendKeys(customBenchmarkReason);
	}
	
	public void clickOnViewDetails() {
		action.waitForJSWebElement("Asset Classification Text");
		action.scrollToBottom();
		myElement = action.fluentWaitWebElement("View Details");
		myElement.click();
	}
	
	public boolean isDefaultValueAutopopulated(String mandatorydetails2) throws SQLException {
		//The below changes to store values in format followed in Excel
		action.waitForJSWebElement("Name");
		myElement = action.getElement("Prepopulated PMP Default");
		String PMPDefaultValue = myElement.getText();
		String Data = "ForExcelValidation - " + PMPDefaultValue;
		myElement = action.getElement("Prepopulated PMP Default Percentage");
		String PMPDefaultValuePercentage = myElement.getText();
		PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length() - 1);
		DecimalFormat df = new DecimalFormat(".00");
		String SQLquery;
		sheetName = "Query";
		sheet = exlObj.getSheet(sheetName);
		SQLquery = (String)exlObj.getCellData(sheet, 1, 1);
		String labelname = (String)exlObj.getCellData(sheet, 1, 2);
		if(mandatorydetails2.contains("Test")) {
			sheetName = "Test";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails2);
		exlObj.setCellData(sheet, rowIndex, 46, Data);
		exlObj.setCellData(sheet, rowIndex, 47, df.format(Double.parseDouble(PMPDefaultValuePercentage)));
		pmdb.DBConnectionStart();
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails2);
		String investmentStyleName = (String)exlObj.getCellData(sheet, rowIndex, 2);
		SQLquery = SQLquery.replace("@data", "'" + investmentStyleName + "'");
		ResultSet rs;
		rs = DBManager.executeSelectQuery(SQLquery);
		String dbDataIterator = null;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
		}
		//pmdb.DBConnectionClose();
		exlObj.closeWorkBook();
		if(dbDataIterator.equals(PMPDefaultValue)) {
			return true;
		}
		return false;
	}
	
	public void clickOnCrossIcon() {
		List<WebElement> Element = (List<WebElement>)action.getElements("Cross Icon");
		Element.get(0).click();
		action.pause(3000);
	}
}
