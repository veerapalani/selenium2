package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class CreateFAActualDocLinkPage {
	Action action;
	WebElement myElement, Element;

	public CreateFAActualDocLinkPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void selectDocumentType() throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("drpDwnDocumentType1"));
		action.click((WebElement) action.fluentWaitForJSWebElement("DocumenttypeKey"));
	}

	public void enterDocumentLink() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDocLink");
		action.highligthElement(ele);
		action.sendKeys(ele, "https://www.google.com" + RandomStringUtils.randomAlphabetic(5));
	}

	public void enterDocumentComment() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDocComment");
		action.highligthElement(ele);
		action.sendKeys(ele, "12345creatingsmadualdocuments");
	}

	public void clickOnAddDocumentLinkButton() throws InterruptedException {
		WebElement ele = action.fluentWaitWebElement("AddDocumentLinkButton");
		action.highligthElement(ele);
		action.click(ele);
	}

	public void clickOnNextButton() throws InterruptedException {
		action.pause(2000);
		myElement = action.fluentWaitWebElement("NextButtonFADocPage");
		action.highligthElement(myElement);
		action.click(myElement);
		action.pause(2000);
		Reporter.addScreenCapture();
	}

	public void clickOnDeleteButton() throws InterruptedException {
		action.highligthElement(action.fluentWaitWebElement("deleteButton"));
		action.jsClick(action.fluentWaitWebElement("deleteButton"));
	}

	public void clickOnAddAnotherDocumentLinkButton() throws InterruptedException {
		WebElement ele = action.fluentWaitWebElement("Add Another Document Link");
		action.highligthElement(ele);
		action.click(ele);
	}

	public String getDocumentLinktext() throws InterruptedException {
		action.highligthElement(action.fluentWaitWebElement("documentLinkText"));
		return action.getElement("documentLinkText").getText();
	}

	public boolean isDocumentPresent() {
		return action.isPresent("documentLinkText");
	}

	public boolean isDeleteButtonPresent() {
		return action.isPresent("deleteButton");
	}

	public int getCountOfDeleteButtons() {
		List<WebElement> elements = action.fluentWaitWebElements("deleteButton");
		return elements.size();
	}

	public void deleteDocumentsIfPresent() throws InterruptedException {
		int size = getCountOfDeleteButtons();
		// System.out.println("size:"+size);
		if (size > 0) {
			for (int i = 0; i < size; i++) {
				clickOnDeleteButton();
			}
			clickOnAddAnotherDocumentLinkButton();
		}
	}

	public void clickonpreviousbuttonindocumentlinkspage() {
		myElement = action.fluentWaitWebElement("Previous Button");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public void validateDocLinksFields() {
		myElement = action.fluentWaitWebElement("typeText");
		action.highligthElement(myElement);
		Assert.assertTrue(myElement.getText().equalsIgnoreCase("Business Card"));
		myElement = action.fluentWaitWebElement("documentLinkText");
		action.highligthElement(myElement);
		Assert.assertTrue(myElement.getText().contains("GOOGLE"));
		myElement = action.fluentWaitWebElement("commentText");
		action.highligthElement(myElement);
		Assert.assertTrue(myElement.getText().equalsIgnoreCase("12345creatingsmadualdocuments"));
	}

}
