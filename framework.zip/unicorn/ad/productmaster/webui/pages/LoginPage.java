package qa.unicorn.ad.productmaster.webui.pages;

import java.util.Calendar;

import qa.framework.utils.Reporter;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;

public class LoginPage {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_LoginPage"));
	String username;
	String password;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	

public void launch_PM_URL() {
		
		action.openURL(SSOLoginPage.URL);
		Reporter.addStepLog("User has Launched PM URL Successfully");
	}

public void enter_PM_login_Details(String userk, String passk) {
	
//	username = Action.getTestData(userk);
//	password = Action.getTestData(passk);
	
	action.sendKeys(action.getElement("usernameBox"), userk);
	action.sendKeys(action.getElement("passwordBox"), passk);
	
	
}
public void enterUniqueLoginDetails(String userk, String passk) {
	
//	username = Action.getTestData(userk);
//	password = Action.getTestData(passk);
	Long time = Calendar.getInstance().getTimeInMillis();
	
	userk =userk + time; 
	action.sendKeys(action.getElement("usernameBox"), userk);
	action.sendKeys(action.getElement("passwordBox"), passk);
	
	
}

public void click_On_Login() throws InterruptedException {
	
	//action.moveToElement(action.getElement("login_btn_PM"));
	action.jsClick(action.getElement("login_btn_PM"));
	//action.click(action.getElement("login_btn_PM"));
	
}
}
