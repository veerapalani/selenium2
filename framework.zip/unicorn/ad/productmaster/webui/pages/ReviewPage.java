package qa.unicorn.ad.productmaster.webui.pages;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class ReviewPage {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateBenchmarkPage"));

	public Boolean isUserOnReviewPage(String entity) {
		Boolean flag = false;
		String expURL = "https://pm.dev.bpsuspm.npd.bfsaws.net/pmui/#/"+entity+"/review";
		String actURL = action.getCurrentURL();
		if (actURL.equalsIgnoreCase(expURL)) {
			flag = true;
		}
		return flag;
	}
}
