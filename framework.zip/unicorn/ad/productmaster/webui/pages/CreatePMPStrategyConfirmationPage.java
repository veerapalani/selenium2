package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class CreatePMPStrategyConfirmationPage {

	Action action;
	WebElement Element;
	
	public CreatePMPStrategyConfirmationPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public boolean isUserOnConfirmatioPage() {
		
		Element = action.waitForJSWebElement("Confirmation Message");
		action.pause(5000);
		//Element = action.getElement("xpath", "//h3[contains(text(),'Your Strategy Creation Has Been Submitt')]");
		if(action.getText(Element).contains("Your Strategy Creation Has Been Submitted")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	public String getStrategyName() {
		//Element = action.getElement("FOACode");
		Element = action.getElement("tagname", "h6");
		String strategyInfo = Element.getText();
		strategyInfo = strategyInfo.replace("|", ";");
    	String message[] = strategyInfo.split(";");
    	return message[0].trim();
	}
	
	public String getStrategyCode() {
		//Element = action.getElement("FOACode");
		Element = action.getElement("tagname", "h6");
		String strategyInfo = Element.getText();
		strategyInfo = strategyInfo.replace("|", ";");
    	String message[] = strategyInfo.split(";");
    	return message[2].trim();
	}
	
	public boolean isStrategyCreatedSuccessfully() {
		
		Element = (WebElement) action.fluentWaitForJSWebElement("Confirmation Tick Mark");
		//(WebElement) action.fluentWaitForJSWebElement("Confirmation Tick Mark");

		if(Element.isDisplayed()) {
			return true;
		}

		return false;
	}

	public boolean isBranchUserOnConfirmationPage(String confirmationmessage) {
		
		Assert.assertTrue(isConfirmationHeaderDisplayed());
		action.pause(5000);
		Element = action.waitForJSWebElement("Common Confirmation message");
		if(action.getText(Element).contains(confirmationmessage)) {
			return true;
		}
		return false;
	}

	public boolean isConfirmationHeaderDisplayed() {
		Element = action.waitForJSWebElement("Header");
		if(action.getText(Element).contains("Confirmation")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void clickOnProductMasterLink() {
		
		Element = action.getElement("Product Master Link");
		Element.click();
		
	}
	
}
