package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;

public class UpdateFADocumentsPage {
	
	Action action;
	public UpdateFADocumentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element,Highlight;
	Boolean flag;
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
	String sheetName = "";
	String FAIDorFAName,fromValue,toValue,faId,completeSqlQuery = null;
	String documentType,documentLink,documentComment = "";
	XSSFSheet sheet;
	SoftAssert sftAst = new SoftAssert();
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	int rowIndex;
	int loopCount;
	
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	public void verifyElementsOnDocumentsDetailsPage(List<String> entity) {
		/*
		Element = entity;
		action.scrollToElement(entity);
		action.highligthElement(Element);
		Assert.assertTrue(action.isDisplayed(Element));
		*/
		for (String Elements : entity) {

			Element = action.getElementByFormatingXpath("Common Page Entity Header", Elements);
			action.highligthElement(Element);
			action.scrollToElement(Element);
			Assert.assertTrue(action.isDisplayed(Element));
		}
	}
	
	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void clickonnextbutton() {
		
		Element = action.fluentWaitWebElement("NEXT");
		action.highligthElement(Element);
		Element.click();
		//action.getElement("NEXT").click();
	}
	
	public boolean isUserOnDocumentsPage() {
		Element = (WebElement) action.waitForJSWebElement("Header");
		if(Element.getText().equals("Enter Document Links")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	
	public void clickOnNext() {
		action.scrollToBottom();
		
		action.fluentWaitWebElement("NEXT").click();
		
	}

	public void selectDocumentType(String documentType) {
		Element = (WebElement) action.fluentWaitForJSWebElement("drpDwnDocumentType");
		Element.click();
		Highlight = (WebElement) action.getElementByJavascript("DocumenttypeKey");
		Highlight = Highlight.findElement(By.linkText(documentType));
		/*
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(documentType)) {
				Highlight = E;
				break;
			}
		}
		*/
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}
	
	public void enterDocumentLink(String documentLink) {
		
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDocLink");
		loopCount = 0;
		do {
			ele.click();
			myClear(ele);
			action.doubleClick(ele);
			action.sendKeys(ele, documentLink);
		} while (!(getDocumentLinkValueFromUI().equals(documentLink)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}
	
	private String getDocumentLinkValueFromUI() {
		Element = action.waitForJSWebElement("Document Link Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}
	
	public void enterDocumentComment(String documentComment) {
		
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDocComment");
		loopCount = 0;
		do {
			ele.click();
			myClear(ele);
			action.doubleClick(ele);
			action.sendKeys(ele, documentComment);
		} while (!(getDocumentCommentValueFromUI().equals(documentComment)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}
	
	private String getDocumentCommentValueFromUI() {
		Element = action.waitForJSWebElement("Document Comment Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}

	public void clickOnAddDocumentLinkButton() {
	
		action.fluentWaitWebElement("AddDocumentLinkButton").click();
		action.pause(1000);
		isUserOnDocumentsPage();
	
	}

	public boolean checkIfAddAnotherDocumentLinkDisplayed() {
		Boolean flag = true;
		
		Element = action.fluentWaitWebElement("Document Card to identify button displayed");
		List<WebElement> elements = Element.findElements(By.xpath("./*"));
		
		for (WebElement webElement : elements) {
			if(webElement.getTagName().contains("brml-form"))
				flag = false;
		}
		
		return flag;
	}
	public void clickOnAddAnotherDocument() {
		
		 
		
		//List<WebElement> elements = action.fluentWaitWebElements("AddDocumentLinkButton");
		
		if(checkIfAddAnotherDocumentLinkDisplayed()) {
			
			Element = action.fluentWaitWebElement("Add Another Document Link");
			Element.click();
			action.pause(1000);
			isUserOnDocumentsPage();
		}else {
			Reporter.addStepLog("No Add Another Document Link is displayed in UI");
		
		}
	}
	
	
	public void clickOnPrevious() {
		
		action.scrollToBottom();
		action.fluentWaitWebElement("PREVIOUS").click();
		
	}

	public int getcountofDocuments() {
		
		List<WebElement> Elements = action.getElements("Type");
		if(Elements.size() > 0) {
			List<WebElement> Elements2 = action.getElements("Documents Count");
			return Elements2.size()-1;
		}else {
			return 0;
		}
		
	}

	public ArrayList<String> getithDocumentInfo(int i) {
		
		ArrayList<String> document = new ArrayList<String>();
		Element = action.getElementByFormatingXpath("Document Record", i+1);
		action.highligthElement(Element);
		ArrayList<WebElement> Elements = (ArrayList<WebElement>) action.getElementsFromParentElement(Element, "Common Tag for Document Values");
		String value = "";
		for (int j = 0; j < Elements.size()-1; j++) {
			
			value = Elements.get(j).getText();
			
			//deleting the extra charaters from get text
			if(j == 2) {
				
				value = value.substring(0, value.length()-15).trim();
				
			}
			document.add(value);
		}
		
		return document;
	}

	public void clickOnDocumentType() {
		
		Element = (WebElement) action.fluentWaitForJSWebElement("drpDwnDocumentType");
		Element.click();
		
	}

	public boolean isValueDisplayedinTypeDropdown(String dropDownValue) {
		Highlight = (WebElement) action.getElementByJavascript("DocumenttypeKey");
		//Highlight = Highlight.findElement(By.linkText(documentType));
		
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(dropDownValue)) {
				Highlight = E;
				return true;
			}
		}
		return false;
	}

	//Code data in heidisql is not implemented for below 
	private String requiredDocumentValue(int i) {
		/*
		 *  Document Type		--> i=0
			Document Link		--> i=1
			Document Comment	--> i=2
			
		*/
		Element = action.fluentWaitWebElement("Document Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element, "Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";
		
		
		for (WebElement E : documentValues) {
			if(E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
				}
			
		}
		int documents = documentValuesData.size()/3;
		
		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i+3;
		}
		
		if(documents > 1) {
			Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue+G+",";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
		}
		tempData.clear();
		
		return requiredDocumentValue;
	}
	
	public String getDocumentTypeValue() {
		
		return requiredDocumentValue(0);
	}


	public String getDocumentLinkValue() {
		return requiredDocumentValue(1);
	}

	public String getDocumentCommentValue() {
		return requiredDocumentValue(2);
	}

	public void deleteDocument() {
		List<WebElement> elements = action.getElements("Delete Documents");
		
		elements.get(elements.size()-1).click();
		action.pause(1000);
		isUserOnDocumentsPage();
		
	}

	public ArrayList<String> getDropdownValuesDisplayedInUI(String dropdownName) {
		String replacedata = "";
		
		ArrayList<String> tempData = new ArrayList<String>();
		
		String uiIterator = "testNull";
		
		switch (dropdownName) {
		case "Type":
			replacedata = "documentType";
			break;
		default:
			break;
		}
		
		Highlight = action.getElementByFormatingXpath("Common Dropdown List", replacedata);
		List<WebElement> dropdownValuesFromUI = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
			for (WebElement E : dropdownValuesFromUI) {
				
				uiIterator = E.getText();
				tempData.add(uiIterator);
			}
			//to handle Zero records from DB 
    		if(uiIterator.equalsIgnoreCase("testnull")) {
    			uiIterator = "isEmpty";
    			tempData.add(uiIterator);
    		}
    		//to handle multiple values for same column
    		if(tempData.size() > 1) {
    			Collections.sort(tempData);
    		}
		
		
		
		return tempData;
	}

	public boolean areDocumentsAvailableinUI() {
		
		List<WebElement> elements = action.getElements("Delete Documents");
		
		if(elements.size() > 0)
			return true;
		else
			return false;
	}

	public void clickOnBackLink() {
		
		action.navigateBackward();
		
	}

	public void clickOnReset() {
		
		Element = action.fluentWaitWebElement("Reset");
		action.moveToElement(Element);
		Element.click();
		isUserOnDocumentsPage();
		
	}

	public String getDocumentTypeValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Type");
		return Element.getAttribute("value");
	}

	public String getDocumentLinkValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Document Link");
		return Element.getAttribute("value");
	}

	public String getDocumentCommentValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Comment");
		return Element.getAttribute("value");
	}

	public boolean error(String errormessage) {
		flag = false;
		action.pause(2000);
		String[] expErrorlist = errormessage.split("-");
		/*
		 * if(experror.contains("-")) { expErrorlist = experror.split("-"); } else
		 * expErrorlist[0] = experror;
		 */
		
				
		for(String S:expErrorlist) {
			switch (S) {
			case "Type must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Type");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: "+Element.getText());
				Reporter.addStepLog("Expected Message: "+S);
				flag=true;
				break;
			case "Document Link must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Document Link");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: "+Element.getText());
				Reporter.addStepLog("Expected Message: "+S);
				flag=true;
				break;
			case "Comment must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Comment");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: "+Element.getText());
				Reporter.addStepLog("Expected Message: "+S);
				flag=true;
				break;
			default:
				Reporter.addStepLog("Expected Message: "+S);
				Reporter.addStepLog("Expected Error Message is invalid ");
				flag = false;
				break;
			}
			if(flag == false)
				break;
		}
		
		return flag;
		
	}

	public void clickOnPreviousButton() {
		
		Element = action.fluentWaitWebElement("PREVIOUS");
		Element.click();
		
	}

	public void updateExistingDocumentComment(int i) {
		
		String comment = RandomStringUtils.randomAlphabetic(10);
		Element = action.getElementByFormatingXpath("Document Comment Button", i+1);
		action.moveToElement(Element);
		action.pause(1000);
		
		Element = action.getElementByFormatingXpath("Document Comment Label", i);
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		Element = action.getElementByFormatingXpath("Document Comment Text Area", i);
		action.moveToElement(Element);
		Element.click();
		Element.clear();
		Element.sendKeys(comment);
		
		List<WebElement> elements = action.getElements("Document Comment Save");
		action.scrollToElement(elements.get(i));
		elements.get(i).click();
		
		Element = (WebElement) action.waitForJSWebElement("Header");
		action.moveToElement(Element);
		
		action.refresh();
		isUserOnDocumentsPage();
	}
	
	public void verifyAttributeValuesofEnterDocumentLinkswithDb(String mandatorydetails,String auditType,String attributeName) throws SQLException {
		
			if (mandatorydetails.contains("Test")) {
				sheetName = "Test";
				rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
				FAIDorFAName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 2); 
			}
   		String tName = Thread.currentThread().getName();
   		
   		pmdb.DBConnectionStart();
		ResultSet result = DBManager.executeSelectQuery("select fa_id from financial_advisor where fa_code='"+FAIDorFAName+"'");
		while(result.next())
		{
			faId = result.getString(1);
			System.out.println(faId);
		}
		
		completeSqlQuery = "select attribute_from_value,attribute_to_value from application_audit where audit_group_id in (select audit_group_id from application_audit where " + 
  		        "attribute_name='DOCUMENT_LINK' and entity_id ='"+faId+"' order by created_on desc limit 1) and audit_type='"+auditType+"' and attribute_name='"+attributeName+"'";
		
		ResultSet allResultMain = DBManager.executeSelectQuery(completeSqlQuery);
		while(allResultMain.next())
		{
			fromValue = allResultMain.getString("attribute_from_value");
			toValue= allResultMain.getString("attribute_to_value");
		}
		if(auditType.equals("ADD")) {
	   		synchronized (tName) {
				rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
				documentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 33);
				documentLink = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 34);
				documentComment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 35);
			}
		switch(attributeName) 
		{
			case "document_type":
					Assert.assertTrue(fromValue==null);
					Assert.assertTrue(toValue.equals(documentType));
				  break;
			case "document_description":
				Assert.assertTrue(fromValue==null);
				Assert.assertTrue(toValue.equals(documentComment));
				  break;
			case "document_link":
				Assert.assertTrue(fromValue==null);
				Assert.assertTrue(toValue.equals(documentLink));
				  break;
		} 
		}
		if(auditType.equals("DELETE")) {
			synchronized (tName) {
				rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails)+3;
				documentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 33);
				documentLink = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 34);
				documentComment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 35);
			}
			switch(attributeName) 
			{
				case "document_type":
						Assert.assertTrue(toValue==null);
						Assert.assertTrue(fromValue.equalsIgnoreCase(documentType));
					  break;
				case "document_description":
					Assert.assertTrue(toValue==null);
					Assert.assertTrue(fromValue.equalsIgnoreCase(documentComment));
					  break;
				case "document_link":
					Assert.assertTrue(toValue==null);
					Assert.assertTrue(fromValue.equalsIgnoreCase(documentLink));
					  break;
			} 
			}
	}


}
