package qa.unicorn.ad.productmaster.webui.pages;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.stepdefs.RejectedStrategyViewStepDef;

public class RejectedStrategyBenchmarkPage {

	Action action;
	public RejectedStrategyBenchmarkPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	WebElement Element,Element2,Highlight;
	String PMPDefaultValue;
	String PMPDefaultValuePercentage;
	int loopCount;
	
	public boolean isUserOnBenchmarkPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Benchmark")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void myClear(WebElement element){        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public String getPrimaryBenchmarkValue() {
		String PMPDefaultValue,PMPDefaultValuePercentage;
		String CustomBenchmarkValue, CustomBenchamrkPercentage;
		DecimalFormat df = new DecimalFormat(".00");
		String primaryBenchmark = "@benchmarkCategory-#-@benchmarkName--#-@percentage";
		String pmpDefaultRadio = ((WebElement) action.fluentWaitForJSWebElement("PMP Default")).getAttribute("class");
		String customRadio =((WebElement) action.fluentWaitForJSWebElement("Custom")).getAttribute("class");
		ArrayList<String> tempData = new ArrayList<String>();
		if(pmpDefaultRadio == null && customRadio == null) {
			Reporter.addStepLog("Both PMP Default and Custom Benchamrks are not selected");
		}else {
			if(pmpDefaultRadio.equals("checked")){
				action.fluentWaitWebElement("View Details").click();
				//primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
				action.pause(1000);
				List<WebElement> Elements = action.getElements("Name");
				
				if(Elements.isEmpty()) {
					Elements.clear();
					tempData.clear();
					
					Element = action.getElement("xpath", "//th[contains(text(),'Benchmark Description')]/parent::tr/parent::tbody/following-sibling::tr/child::td[3]");
					Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
					Element = action.getElement("xpath", "//th[contains(text(),'Percentage')]/parent::tr/parent::tbody/following-sibling::tr/child::td[4]");
					List<WebElement> Elements2 = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
					
					for (int i = 0; i < Elements.size(); i++) {
						primaryBenchmark = "@benchmarkCategory-#-@benchmarkName--#-@percentage";
						primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
						
						PMPDefaultValue = Elements.get(i).getText();
						PMPDefaultValuePercentage = Elements2.get(i).getText().substring(0, Elements2.get(i).getText().length()-1);
						PMPDefaultValuePercentage = df.format(Double.parseDouble(PMPDefaultValuePercentage));
						
						primaryBenchmark = primaryBenchmark.replace("@benchmarkName", PMPDefaultValue);
						primaryBenchmark = primaryBenchmark.replace("@percentage", PMPDefaultValuePercentage);
						tempData.add(primaryBenchmark);	
					}
					if(tempData.size() > 1) {
						//Collections.sort(tempData);
						primaryBenchmark = "";
						for (String G : tempData) {
							primaryBenchmark = primaryBenchmark+G+":";
						}	
					}
					tempData.clear();
					clickOnCrossIcon();
				}else {
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
				Element = action.getElement("Prepopulated PMP Default");
				PMPDefaultValue = Element.getText();
				Element = action.getElement("Prepopulated PMP Default Percentage");
				PMPDefaultValuePercentage = Element.getText();
				PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length()-1);
				PMPDefaultValuePercentage = df.format(Double.parseDouble(PMPDefaultValuePercentage));
				
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", PMPDefaultValue);
				primaryBenchmark = primaryBenchmark.replace("@percentage", PMPDefaultValuePercentage);
				
				clickOnCrossIcon();
				}
				
				
			}else if(customRadio.equals("checked")){
				Element = action.getElement("Custom Benchmarks count");
				List<WebElement> Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
				String value;
				String[] values = null;
				for (int i = 0; i < Elements.size(); i++) {
					primaryBenchmark = "@benchmarkCategory-#-@benchmarkName--#-@percentage";
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
					
					
					Element = action.getElementByFormatingXpath("Custom Benchmark Variable Path", i);
					value = Element.getAttribute("value");
					Element = action.getElementByFormatingXpath("Custom Benchmark Value", value);
					CustomBenchmarkValue = Element.getAttribute("name");
					values = CustomBenchmarkValue.split(" - ", 2);
					CustomBenchamrkPercentage = action.getElementByFormatingXpath("Custom Benchmark Percentage Value", i).getAttribute("value");
					
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", values[1]);
					primaryBenchmark = primaryBenchmark.replace("@percentage", CustomBenchamrkPercentage);
					tempData.add(primaryBenchmark);	
				}
				if(tempData.size() > 1) {
					//Collections.sort(tempData);
					primaryBenchmark = "";
					for (String G : tempData) {
						primaryBenchmark = primaryBenchmark+G+":";
					}	
				}
				tempData.clear();	
			}
			
			
			
		}
		return primaryBenchmark;
	}
	
	public void clickOnCrossIcon() {
		List<WebElement> Element =(List<WebElement>) action.getElements("Cross Icon");
		Element.get(0).click();
		
		action.pause(3000);
		
	}

	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
		
	}

	public String getBenchmarkCategoryValue() {
		String pmpDefaultRadio = ((WebElement) action.fluentWaitForJSWebElement("PMP Default")).getAttribute("class");
		String customRadio =((WebElement) action.fluentWaitForJSWebElement("Custom")).getAttribute("class");
		if(pmpDefaultRadio == null && customRadio == null) {
			Reporter.addStepLog("Both PMP Default and Custom Benchamrks are not selected");
		}else {
			if(pmpDefaultRadio.equals("checked")){
				return "Default";
			}else if(customRadio.equals("checked")){
				return "Custom";
			}
		}
		return "isEmpty";
	}

	public String getBenchmarkNameValue() {
		action.pause(2000);
		String PMPDefaultValue,PMPDefaultValuePercentage;
		String CustomBenchmarkValue, CustomBenchamrkPercentage;
		DecimalFormat df = new DecimalFormat(".00");
		String primaryBenchmarkName = "@benchmarkCategory-#-@benchmarkName--#-@percentage";
		String pmpDefaultRadio = ((WebElement) action.fluentWaitForJSWebElement("PMP Default")).getAttribute("class");
		String customRadio =((WebElement) action.fluentWaitForJSWebElement("Custom")).getAttribute("class");
		ArrayList<String> tempData = new ArrayList<String>();
		if(pmpDefaultRadio == null && customRadio == null) {
			Reporter.addStepLog("Both PMP Default and Custom Benchamrks are not selected");
		}else {
			if(pmpDefaultRadio.equals("checked")){
				action.fluentWaitWebElement("View Details").click();
				//primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
				action.pause(1000);
				List<WebElement> Elements = action.getElements("Name");
				
				if(Elements.isEmpty()) {
					Elements.clear();
					tempData.clear();
					
					Element = action.getElement("xpath", "//th[contains(text(),'Benchmark Description')]/parent::tr/parent::tbody/following-sibling::tr/child::td[3]");
					Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
					Element = action.getElement("xpath", "//th[contains(text(),'Percentage')]/parent::tr/parent::tbody/following-sibling::tr/child::td[4]");
					List<WebElement> Elements2 = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
					
					for (int i = 0; i < Elements.size(); i++) {
						PMPDefaultValue = Elements.get(i).getText();
						primaryBenchmarkName = PMPDefaultValue;
						tempData.add(primaryBenchmarkName);	
					}
					if(tempData.size() > 1) {
						//Collections.sort(tempData);
						primaryBenchmarkName = "";
						for (String G : tempData) {
							primaryBenchmarkName = primaryBenchmarkName+G+",";
						}
						primaryBenchmarkName = primaryBenchmarkName.substring(0, primaryBenchmarkName.length()-1);
					}
					tempData.clear();
					clickOnCrossIcon();
				}else {
				
				Element = action.getElement("Prepopulated PMP Default");
				primaryBenchmarkName = Element.getText();
				
				clickOnCrossIcon();
				}
				
				
			}else if(customRadio.equals("checked")){
				Element = action.getElement("Custom Benchmarks count");
				List<WebElement> Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
				String value;
				String[] values = null;
				for (int i = 0; i < Elements.size(); i++) {
					
					Element = action.getElementByFormatingXpath("Custom Benchmark Variable Path", i);
					value = Element.getAttribute("value");
					Element = action.getElementByFormatingXpath("Custom Benchmark Value", value);
					CustomBenchmarkValue = Element.getAttribute("name");
					values = CustomBenchmarkValue.split(" - ", 2);
					CustomBenchamrkPercentage = action.getElementByFormatingXpath("Custom Benchmark Percentage Value", i).getAttribute("value");
					
					primaryBenchmarkName = values[1];
					
					tempData.add(primaryBenchmarkName);	
				}
				if(tempData.size() > 1) {
					//Collections.sort(tempData);
					primaryBenchmarkName = "";
					for (String G : tempData) {
						primaryBenchmarkName = primaryBenchmarkName+G+",";
					}
					primaryBenchmarkName = primaryBenchmarkName.substring(0, primaryBenchmarkName.length()-1);
				}
				tempData.clear();	
			}
			
			
			
		}
		return primaryBenchmarkName;
	}

	public String getPercentageValue() {
		String PMPDefaultValue,PMPDefaultValuePercentage = "";
		String CustomBenchmarkValue, CustomBenchamrkPercentage;
		DecimalFormat df = new DecimalFormat(".00");
		String primaryBenchmark = "@benchmarkCategory-#-@benchmarkName--#-@percentage";
		String pmpDefaultRadio = ((WebElement) action.fluentWaitForJSWebElement("PMP Default")).getAttribute("class");
		String customRadio =((WebElement) action.fluentWaitForJSWebElement("Custom")).getAttribute("class");
		ArrayList<String> tempData = new ArrayList<String>();
		if(pmpDefaultRadio == null && customRadio == null) {
			Reporter.addStepLog("Both PMP Default and Custom Benchamrks are not selected");
		}else {
			if(pmpDefaultRadio.equals("checked")){
				action.fluentWaitWebElement("View Details").click();
				//primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
				action.pause(1000);
				List<WebElement> Elements = action.getElements("Name");
				
				if(Elements.isEmpty()) {
					Elements.clear();
					tempData.clear();
					
					Element = action.getElement("xpath", "//th[contains(text(),'Benchmark Description')]/parent::tr/parent::tbody/following-sibling::tr/child::td[3]");
					Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
					Element = action.getElement("xpath", "//th[contains(text(),'Percentage')]/parent::tr/parent::tbody/following-sibling::tr/child::td[4]");
					List<WebElement> Elements2 = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
					
					for (int i = 0; i < Elements.size(); i++) {
						PMPDefaultValuePercentage = Elements2.get(i).getText().substring(0, Elements2.get(i).getText().length()-1);
						PMPDefaultValuePercentage = df.format(Double.parseDouble(PMPDefaultValuePercentage));
						tempData.add(PMPDefaultValuePercentage);	
					}
					if(tempData.size() > 1) {
						//Collections.sort(tempData);
						PMPDefaultValuePercentage = "";
						for (String G : tempData) {
							PMPDefaultValuePercentage = PMPDefaultValuePercentage+G+",";
						}
						PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length()-1);
					}
					tempData.clear();
					clickOnCrossIcon();
				}else {
				
				Element = action.getElement("Prepopulated PMP Default Percentage");
				PMPDefaultValuePercentage = Element.getText();
				PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length()-1);
				PMPDefaultValuePercentage = df.format(Double.parseDouble(PMPDefaultValuePercentage));
				
				clickOnCrossIcon();
				}
				
				
			}else if(customRadio.equals("checked")){
				Element = action.getElement("Custom Benchmarks count");
				List<WebElement> Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
				String value;
				String[] values = null;
				for (int i = 0; i < Elements.size(); i++) {
					CustomBenchamrkPercentage = action.getElementByFormatingXpath("Custom Benchmark Percentage Value", i).getAttribute("value");
					PMPDefaultValuePercentage = CustomBenchamrkPercentage;
					tempData.add(PMPDefaultValuePercentage);	
				}
				if(tempData.size() > 1) {
					//Collections.sort(tempData);
					PMPDefaultValuePercentage = "";
					for (String G : tempData) {
						PMPDefaultValuePercentage = PMPDefaultValuePercentage+G+",";
					}
					PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length()-1);
				}
				tempData.clear();	
			}
			
			
			
		}
		return PMPDefaultValuePercentage;
	}

	public String getCustomBenchmarkReasonValue() {
		if(getBenchmarkCategoryValue().equals("Default"))
			return "isEmpty";
		Element = action.getElement("Custom Benchmark Reason Value");
		return Element.getAttribute("value");
	}

	public void enterBenchmarkCaegory(String benchmarkCaegory) {
		// TODO Auto-generated method stub
		
	}

	public void enterBenchmarkName(String benchmarkName) {
		// TODO Auto-generated method stub
		
	}

	public void enterBenchmarkPercentage(String benchmarkPercentage) {
		// TODO Auto-generated method stub
		
	}

	public void clickOnPrevious() {
		Element = action.getElement("PREVIOUS");
		action.moveToElement(Element);
		Element.click();
		
	}

	public void selectCustom() {
		
		Element =(WebElement) action.fluentWaitForJSWebElement("Custom");
		Element.click();
		action.pause(2000);
	}
	
	public void selectpmpDefault() {
		
		Element =(WebElement) action.fluentWaitForJSWebElement("PMP Default");
		Element.click();
		action.pause(2000);
	}
	
	public void enterCustomBenchmark(String replace, String replace2, String string, String benchmarkCategory) {
		if(benchmarkCategory.equalsIgnoreCase("Custom")) {
			Element = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
			action.moveToElement(Element);
			action.click(Element);
			Highlight = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace2), 10);
			Highlight = Highlight.findElement(By.linkText(string));
			action.scrollToElement(Highlight);
			action.highligthElement(Highlight);
			action.click(Highlight);
			
		}
		
	}

	public void enterCustomBenchmarkPercentage(String replace, String string, String benchmarkCategory, int benchmarkCount) {
		
		if(benchmarkCategory.equalsIgnoreCase("Custom")) {
			loopCount = 0;
			//Finding Element should be placed inside as element is changed after using send keys and need to be called again
			do {
				Element = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
				Element.click();
				myClear(Element);
				action.sendKeys(Element, string);
			} while (!(Float.parseFloat(string + "f") == Float.parseFloat(getPercentageithValuefromUI(benchmarkCount) + "f")) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
			
			((WebElement) action.fluentWaitForJSWebElement("Custom")).click();
			
		}
		
	}
	
	public void addNewBenchmark() {
		Element = action.fluentWaitWebElement("Add New Benchmark");
		Element.click();
		
	}

	public void enterCustomBenchmarkReason(String customBenchmarkReason) {
		Element =(WebElement) action.fluentWaitForJSWebElement("Custom Benchmark Reason");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, customBenchmarkReason);
		} while (!(getCustomBenchmarkReasonValue().equals(customBenchmarkReason)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}
	
	public void clickOnViewDetails() {
		
		action.scrollToBottom();
		
		Element = action.fluentWaitWebElement("View Details");
		Element.click();
		
	}
	
	public String getDefaultValueAutopopulated() {

		//The below changes to store values in format followed in Excel
		action.waitForJSWebElement("Name");
		Element = action.getElement("Prepopulated PMP Default");
		PMPDefaultValue = Element.getText();
		String Data = "ForExcelValidation - "+PMPDefaultValue;
		Element = action.getElement("Prepopulated PMP Default Percentage");
		PMPDefaultValuePercentage = Element.getText();
		PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length()-1);
		DecimalFormat df = new DecimalFormat(".00");
		return Data+":"+df.format(Double.parseDouble(PMPDefaultValuePercentage));
	}

	public void refreshThePage() {
		action.refresh();
	}

	public void deleteallcustomBenchmarks() {
		
		action.scrollToBottom();
		List<WebElement> elements = action.getElements("Delete Icon");
		
		int count = elements.size();
		if(count > 0) {
		for (int i = count; i > 0; i--) {
			action.moveToElement(elements.get(i-1));
			action.pause(1000);
			elements.get(i-1).click();
		}
		}
		Element =(WebElement) action.fluentWaitForJSWebElement("Custom Benchmark Reason");
		Element.clear();
		
		
	}

	public String getBenchmarkithValuefromUI(int i) {
		String benchmarkValue = action.getElementByFormatingXpath("Benchmark From UI", i).getAttribute("value");
		
			Element = action.getElementByFormatingXpath("Benchmark Value From UI", benchmarkValue);
			
			return Element.getAttribute("name");
	}

	public Float getPercentageithValuefromUI(int i) {
		Element = action.getElementByFormatingXpath("Percentage Value From UI", i);
		return Float.parseFloat(Element.getAttribute("value"));
	}

	public boolean isAddNewBenchmarkOptionNotVisible() {
		List<WebElement> Elements = action.getElements("Add New Benchmark");
		if(Elements.size() == 0) {
			return true;
		}
		return false;
	}
	
	
}
