package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdatePMPStrategyReviewPage {

	Action action;
	public UpdatePMPStrategyReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	WebElement Element;
	
	public boolean isUserOnReviewPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Review & Attestation")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	
	public String getRiskCategoryValue() {
		Element = action.fluentWaitWebElement("Risk Category Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPIVStyleValue() {
		Element = action.fluentWaitWebElement("PIV Style Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		return "f";
	}

	public String getGeographicIndicatorValue() {
		Element = action.fluentWaitWebElement("Geographic Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getStrategyNameValue() {
		Element = action.fluentWaitWebElement("Strategy Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getStrategyCodeValue() {
		Element = action.fluentWaitWebElement("FOA Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getBalancedAllocationValue() {
		Element = action.fluentWaitWebElement("Balanced Allocation Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getConcentratedStrategyIndicatorValue() {
		Element = action.fluentWaitWebElement("Concentrated Strategy Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStructuredProductsStrategyValue() {
		Element = action.fluentWaitWebElement("Structured Products Strategy Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStrategyStatusValue() {
		Element = action.fluentWaitWebElement("Status Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getHedgeCoreIndicatorValue() {
		Element = action.fluentWaitWebElement("Hedge Core Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStylePairingCodeValue() {
		Element = action.fluentWaitWebElement("Style Pairing Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getInvestmentStyleValue() {
		Element = action.fluentWaitWebElement("Investment Style Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPrimaryBenchmarkValue() {
		String primaryBenchmark = "";
		
		Element = action.getElement("Date Type");
		String datetype = Element.getText();
		if(datetype.equals("PMP Default")){
		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		if(WebElements.isEmpty()) {
			return "isEmpty";
		}else {
		List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0), "Benchmarks List common tag");
		ArrayList<String> tempData = new ArrayList<String>();
		//String primaryBenchmark = "";
		int size  = Elements.size();
		int count = 0;
		DecimalFormat ds = new DecimalFormat(".00");
		for (int i = 0; i < size/3; i++) {
			primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName-#-@percentage";
			primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
			if(Elements.get(count).getText().equals("—")) {
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count+1).getText());
				primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
			}else if (Elements.get(count+1).getText().equals("—")) {
				if(primaryBenchmark.contains("@benchmarkCategory")) {
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
					primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
				}else {
					Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
				}
				
			}
			tempData.add(primaryBenchmark);
			//data = data+primaryBenchmark+":";
			count = count + 3;
			
		}
		if(tempData.size() > 1) {
			Collections.sort(tempData);
			primaryBenchmark = "";
			for (String G : tempData) {
				primaryBenchmark = primaryBenchmark+G+":";
			}	
		}
		tempData.clear();
		}
		}else if (datetype.equals("Timeperiod")) {
			Element = action.getElement("Total Time periods");
			List<WebElement> Timeperiods = action.getElementsFromParentElement(Element, "Benchmarks List common tag");
			ArrayList<String> tempData = new ArrayList<String>();
			int timeperiodcount = 1;
			for (WebElement E : Timeperiods) {
				if(E.getAttribute("class").contains("mb24")) {
					//List<WebElement> WebElements2 = action.getElements("Primary Benchmark Value for Time periods");
					String locatorValue = "//div[contains(text(),'Benchmark1')]/parent::div/parent::div/following-sibling::div["+timeperiodcount+"]/child::div[3]/child::div";
					//locatorValue = locatorValue.replace("@data", String.valueOf(timeperiodcount));
					List<WebElement> WebElements2 = action.getElements("xpath", locatorValue);
					if(WebElements2.isEmpty()) {
						primaryBenchmark =  timeperiodcount + " :: time period benchamrks are not appearing";
					}else {
						List<WebElement> Elements2 = action.getElementsFromParentElement(WebElements2.get(0), "Benchmarks List common tag");
						
						//String primaryBenchmark = "";
						int size  = Elements2.size();
						int count = 0;
						DecimalFormat ds = new DecimalFormat(".00");
						for (int i = 0; i < size/2; i++) {
							primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
							primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Cap n Go");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements2.get(count).getText());
							primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements2.get(count+1).getText().substring(0, Elements2.get(count+1).getText().length()-1))));
							tempData.add(primaryBenchmark);
							//data = data+primaryBenchmark+":";
							count = count + 2;
							
						}
					}
					timeperiodcount++;
				}
				
				
			}
			
			if(tempData.size() > 1) {
				Collections.sort(tempData);
				primaryBenchmark = "";
				for (String G : tempData) {
					primaryBenchmark = primaryBenchmark+G+":";
				}	
			}
			tempData.clear();
		}
		return primaryBenchmark;
	}

	public String getMarginsValue() {
		Element = action.fluentWaitWebElement("Margin Eligible Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}
}
