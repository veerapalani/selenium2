package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class PMPSortAndFilterPage {

	Action action;
	WebElement Element, myElement;
	Boolean flag;

	public PMPSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchPMPValue(String PMPSearchValue) {
		action.pause(100);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitForJSWebElement("GlobalSearchvaluePMP");
		action.pause(2000);
		action.click(Element);
		Element.clear();
		action.pause(1000);
		action.sendKeys(Element, PMPSearchValue);
		action.pause(2000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		action.pause(1000);
	}

	public void clickOnSeeAllResultsForPMPLayout() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("SeeAllResultPMPLayout");
		// action.scrollToBottom();
		//action.jsClick(Element);
		action.highligthElement(Element);
		Element.click();
		Reporter.addScreenCapture();
	}

	public void verifyTheSearchedResultInAllTabForPMP() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitForJSWebElement("AllTabPMP");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void verifySearchedGridViewDisplay() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("GridViewPMP");
		Element.isDisplayed();
	}

	public void verifyAndClickPMPTab() {
		action.pause(2000);
		// Element = (WebElement) action.getElementByJavascript("PMPTab");
		Element = (WebElement) action.fluentWaitForJSWebElement("PMPTab");
		action.highligthElement(Element);
		Element.isDisplayed();
		// action.pause(2000);
		//action.jsClick(Element);
		Element.click();
	}

	public void verifyThePMPTabAfterFilterCondition() {
		action.pause(1000);
		Element = (WebElement) action.fluentWaitForJSWebElement("PMPTab");
		action.highligthElement(Element);
		action.scrollToElement(Element);
		Element.isDisplayed();
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		// action.pause(2000);
		action.moveToElement(element);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		action.pause(2000);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public String verifyTheSortCoumnPropertyTypeASC() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("AscSortOrder");
		return action.getAttribute(Element, "class");
	}

	public void clickOnSortIcon(WebElement element) {
		action.pause(2000);
		action.click(element);
	}

	public String verifyTheSortCoumnPropertyTypeDESC() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("DescSortOrder");
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDefault() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("DefaultSortOrder");
		return action.getAttribute(Element, "class");
	}

	public String verifyTheGridCountBeforeApplyFilterAndSortCondition() {
		action.pause(5000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterGlobalSearch");
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.click(element);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
	}

	public void clickOnFilterIconForPMPGridView(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.click(element);
	}

	public void clickOnFilterConditionForPMPGridView(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.click(element);
	}

	public void clickOnFilterCondition() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("FilterCondition");
		action.click(Element);
	}

	public void enterFilterValue(String FilterValue) {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("FilterValue");
		action.click(Element);
		// action.pause(1000);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForPMPGridView() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyThePMPGridCountAfterScroll() {
		action.pause(5000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterCondition");
		// action.pause(5000);
		String gridAllData = action.getAttribute(Element, "aria-rowcount");
		return gridAllData;
	}

	public String verifyThePMPGridCountAfterApplyFilterConditionOnTab() {
		action.pause(6000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTabForPMP");
		return action.getText(Element);
	}

	public void clickOnApplyFilterIconForPMPGridViewForReset() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForPMPGridViewForCancel() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String waitForWebElement(String xpath) {
		int timeLaps = 0;
		String status = "FAIL";
		while (status.equals("FAIL") && timeLaps < 4) {
			try {
				Element = findElementByDynamicXpath(xpath);
				if (Element == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}
			} catch (Exception e) {
				status = "FAIL";
			}
			action.pause(1000);
			++timeLaps;
		}
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);
		return status;
	}

}
