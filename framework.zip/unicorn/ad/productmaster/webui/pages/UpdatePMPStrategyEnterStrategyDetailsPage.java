package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class UpdatePMPStrategyEnterStrategyDetailsPage {

	Action action;
	public UpdatePMPStrategyEnterStrategyDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	WebElement Element;
	
	public boolean isUserOnEnterStrategyDetailsPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Enter Strategy Details")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
	}

	public String getRiskCategoryValue() {
		Element = action.fluentWaitWebElement("Risk Category Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}

	public String getPIVStyleValue() {
		Element = action.fluentWaitWebElement("PIV Style Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getGeographicIndicatorValue() {
		Element = action.fluentWaitWebElement("Geographic Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}

	public String getStrategyNameValue() {
		Element = action.fluentWaitWebElement("Strategy Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String uiValue = Element.getAttribute("value");
		if((uiValue == null) || (uiValue.isEmpty())) {
			uiValue = "isEmpty";
			((WebElement) action.fluentWaitForJSWebElement("Strategy Name")).sendKeys(uiValue);
			return uiValue;
		}
		return uiValue;
	}

	public String getStrategyCodeValue() {
		Element = action.fluentWaitWebElement("FOA Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}

	public String getBalancedAllocationValue() {
		Element = action.fluentWaitWebElement("Balanced Allocation Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}

	public String getConcentratedStrategyIndicatorValue() {
		Element = action.fluentWaitWebElement("Concentrated Strategy Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getStructuredProductsStrategyValue() {
		Element = action.fluentWaitWebElement("Structured Products Strategy Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getStrategyStatusValue() {
		Element = action.fluentWaitWebElement("Status Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}

	public String getHedgeCoreIndicatorValue() {
		Element = action.fluentWaitWebElement("Hedge Core Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getStylePairingCodeValue() {
		Element = action.fluentWaitWebElement("Style Pairing Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}

	public String getInvestmentStyleValue() {
		Element = action.fluentWaitWebElement("Investment Style Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("name");
	}

	public String getMarginsValue() {
		Element = (WebElement) action.fluentWaitForJSWebElement("Margin Eligible Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "t";
		}
		return "f";
	}
}
