package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class UpdateSMASingleAccessStrategyProxyDetailsPage {

	Action action;
	WebElement Element;
	public UpdateSMASingleAccessStrategyProxyDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	public String getProxyManagerValue() {
		Element = action.fluentWaitWebElement("Proxy Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getProxyAddress1Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getProxyAddress2Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getProxyAddress3Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getProxyAddress4Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getProxyCityValue() {
		Element = action.fluentWaitWebElement("Proxy Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getProxyStateValue() {
		Element = action.fluentWaitWebElement("Proxy Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getProxyZipCodeValue() {
		Element = action.fluentWaitWebElement("Proxy Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getVoluntaryReorgManagerValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getVoluntaryReorgAddress1Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getVoluntaryReorgAddress2Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getVoluntaryReorgAddress3Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getVoluntaryreorgAddress4Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getVoluntaryReorgCityValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getVoluntaryReorgStateValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getVoluntaryReorgZipcodeValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getInterimManagerValue() {
		Element = action.fluentWaitWebElement("Interim Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getInterimAddress1Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getInterimAddress2Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getInterimAddress3Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getInterimAddress4Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getAttribute("value").equals("")) {
			return "isEmpty";
		}
		return Element.getAttribute("value");
	}
	public String getInterimCityValue() {
		Element = action.fluentWaitWebElement("Interim Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getInterimStateValue() {
		Element = action.fluentWaitWebElement("Interim Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getInterimZipcodeValue() {
		Element = action.fluentWaitWebElement("Interim Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public boolean isUserOnProxyDetailsPage() {
		Element = action.waitForJSWebElement("Proxy Details Header");
		
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		action.moveToElement(Element);
		Element.click();
	}
}
