package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Optional;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.ibm.db2.jcc.am.br;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class UpdateFAEnterFADetailsPage {
	
	Action action;
	public UpdateFAEnterFADetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element,Highlight;
	int loopCount;
	
	public void verifyEditFAFAage(List<String> entity) {
		/*
		myElement = element;
		Action.pause(2000);
		action.highligthElement(myElement);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
		faDetailsPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']")
		*/
		for (String Elements : entity) {

			Element = action.getElementByFormatingXpath("Common Page Entity Header", Elements);
			action.highligthElement(Element);
			action.scrollToElement(Element);
			Assert.assertTrue(action.isDisplayed(Element));
		}
	}
	
	public void clickonnextbutton() {
		
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
		//action.getElement("NEXT").click();
	}

	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public String getManagerHeadValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "branchManagerMarketHead");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getFANameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faName");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getFAEmailValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faEmail");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getFAIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faId");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getUniversalIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faCode2");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getCRDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "crdNumber");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getNominationForRecruitValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "recruitNomination");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		switch (Element.getAttribute("value")) {
		case "true":
			return "t";
		case "false":
			return "f";
		default:
			break;
		}
		return "unexpected Value";
	}

	public String getRecruitHireDataValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "recruitHireDate");
		if(Element.getAttribute("date").isEmpty())
			return "isEmpty";
		return Element.getAttribute("date");
	}

	public String getPriorFirmValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "priorFirm");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getPreviouslyApprovedorNotForFADiscretionaryProgramValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "approvedDiscretionaryProgram");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		switch (Element.getAttribute("value")) {
		case "true":
			return "t";
		case "false":
			return "f";
		default:
			break;
		}
		return "unexpected Value";
	}

	public String getFADiscretionaryProgramValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faDiscretionaryProgramName");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getFASegmentValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faSegment");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getRenominationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "renomination");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		switch (Element.getAttribute("value")) {
		case "true":
			return "t";
		case "false":
			return "f";
		default:
			break;
		}
		return "unexpected Value";
	}

	public String getRenominationDateValue() {
		List<WebElement> list = action.getElements("Renomination Date");
		if(list.size() > 0) {
			Element = action.getElementByFormatingXpath("Common Attribute Value", "renominationDate");
			if(Element.getAttribute("date").isEmpty())
				return "isEmpty";
			return Element.getAttribute("date");
		}
		return "isEmpty";
	}

	public String getSeries7RegistrationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "lengthOfSeries7Reg");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getSeries65RegistrationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "lengthOfSeries65Reg");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getLenghtOfServiceAsFAValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "lengthOfService");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getAUMValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "aum");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		//DecimalFormat df = new DecimalFormat(".####");
		return Element.getAttribute("value");
		//return df.format(Integer.parseInt(Element.getAttribute("value")));
	}

	public String getAnticipatedPercentageValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "anticipatedPercentageOfOverallBusiness");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		//DecimalFormat df = new DecimalFormat(".00");
		//return df.format(Integer.parseInt(Element.getAttribute("value")));
		return Element.getAttribute("value");
	}

	public String getBranchValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "branchName");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getComplexValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "complex");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getDivisionValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "division");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getRegionValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "region");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getCFAorACPMValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "cfaAcpmCharterHolder");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getWaiverorCompletedCourseValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "waiveCoursework");
		if(Element.getAttribute("value").isEmpty())
			return "f";
		switch (Element.getAttribute("value")) {
		case "true":
			return "t";
		case "false":
			return "f";
		default:
			break;
		}
		return "unexpected Value";
	}

	public String getZoologicCourseRegistrationValue() {
		
		Element = action.getElementByFormatingXpath("Common Attribute Value", "zoologicCourseworkRegistered");
		if(Element.getAttribute("date").isEmpty())
			return "isEmpty";
		return Element.getAttribute("date");
	}

	public String getZoologicCourseCompletedValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "zoologicCourseworkCompleted");
		if(Element.getAttribute("date").isEmpty())
			return "isEmpty";
		return Element.getAttribute("date");
	}

	public String getAwardsValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "awards");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getAdditionalInformationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "additionalInformation");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public void enterBranchManagerOrMarketHead(String branchManagerOrMarketHead) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "branchManagerMarketHead");
		action.moveToElement(Element);
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, branchManagerOrMarketHead);
		} while (!(getManagerHeadValue().equals(branchManagerOrMarketHead)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterFaName(String faName) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "faName");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, faName);
		} while (!(getFANameValue().equals(faName)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterFaEmail(String faEmail) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "faEmail");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, faEmail);
		} while (!(getFAEmailValue().equals(faEmail)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterFaIDs(String faIDs) {
		if (faIDs.length() > 0) {
			Reporter.addStepLog("FA IDs field in UI is a greayed out field and is not editable");
		}
	}

	public void enterUniversalID(String universalID) {
		if (universalID.length() > 0) {
			Reporter.addStepLog("Universal IDs field in UI is a greayed out field and is not editable");
		}
		
	}

	public void enterCRDs(String cRDs) {
		if (cRDs.length() > 0) {
			Reporter.addStepLog("CRD Number field in UI is a greayed out field and is not editable");
		}
		
	}

	public void enterIsNominationForARecruit(String isNominationForARecruit) {
		
		switch (isNominationForARecruit.toLowerCase().trim()) {
		case "yes":
			Element = action.getElementByFormatingXpath("Is Nomination for a Recruit", "Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Is Nomination for a Recruit", "No");
			Element.click();
			break;
		default:
			Reporter.addStepLog("Value for isNominationForARecruit field in UI is not valid and ignoring the same");
			break;
		}
		
	}

	public void enterRecruitHireDate(String recruitHireDate) throws InterruptedException {
		
		String ID = "recruitHireDate";
		enterDate(recruitHireDate, ID);
		
		
		/*
		Element = action.getElementByFormatingXpath("Common date Field Input", "recruitHireDate");
		Element.click();
		Element.clear();
		Element.sendKeys(recruitHireDate);
		*/
	}

	private void enterDate(String excelDate, String ID) {
		
		Element = action.getElementByFormatingXpath("Common date Field Input", ID);
		action.moveToElement(Element);
		Element.click();
		
		//Below Code to prepare for Selecting Year
		String[] date = excelDate.split("/");
		date[0] = getMonthname(date[0]);
		WebElement monthYear = action.getElementByFormatingXpath("dateFrom_monthYear", ID);
		String monthYearValue = monthYear.getText();
		String[] mYValue = monthYearValue.split(" ");
		WebElement nextClick, previousClick;
		String month = mYValue[0];
		
		//clicking twice to select Year
		action.jsClick(monthYear);
		action.jsClick(monthYear);
		action.pause(500);
		monthYearValue = monthYear.getText();
		mYValue = monthYearValue.split(" - ");
		if(Integer.parseInt(mYValue[1]) > Integer.parseInt(date[2])) {
			//while()
			while(!inRange(Integer.parseInt(mYValue[0]),Integer.parseInt(mYValue[1]),Integer.parseInt(date[2]) )) {
				previousClick = action.getElementByFormatingXpath("dateFrom_previousButton", ID);
				action.jsClick(previousClick);
				monthYearValue = monthYear.getText();
				mYValue = monthYearValue.split(" - ");
				action.pause(500);
				
			}
		}else if(Integer.parseInt(mYValue[1]) < Integer.parseInt(date[2])) {
			System.out.println("Inside second if");
			//while()
			System.out.println(inRange(Integer.parseInt(mYValue[0]),Integer.parseInt(mYValue[1]),Integer.parseInt(date[2])));
			while(!inRange(Integer.parseInt(mYValue[0]),Integer.parseInt(mYValue[1]),Integer.parseInt(date[2]))) {
				nextClick = action.getElementByFormatingXpath("dateFrom_nextButton", ID);
				action.jsClick(nextClick);
				monthYearValue = monthYear.getText();
				mYValue = monthYearValue.split(" - ");
				action.pause(500);
			}
		}
		
		//Select Year
			selectYear(date[2], ID);
		
		//Select Month
			selectMonth(date[0].substring(0, 3), ID);
		
		//Select Date
			selectDate(date[1], ID);
		
	}

	private void selectDate(String date, String ID) {
		
		if(date.substring(0, 1).contentEquals("0")) {
			date = date.substring(1);
		}
		Element = (WebElement) action.getElementByFormatingXpath("dateFrom_dates", ID);
		
		List<WebElement> dateValues = Element.findElements(By.xpath("./*"));
		
		for(int i=0;i<dateValues.size();i++) {
			if(dateValues.get(i).getClass().toString().contains("pmu-not-in-month")) {
				
			}else {
				if(dateValues.get(i).getText().contentEquals(date)) {
					action.moveToElement(dateValues.get(i));
					action.jsClick(dateValues.get(i));
					action.pause(1000);
					break;
				}
			}
		
		
		}
		
	}

	private void selectMonth(String month, String ID) {
		Element = (WebElement) action.getElementByFormatingXpath("date_months", ID);
		
		List<WebElement> dateValues = Element.findElements(By.xpath("./*"));
		
		for(int i=0;i<dateValues.size();i++) {
			
				if(dateValues.get(i).getText().contentEquals(month)) {
					action.moveToElement(dateValues.get(i));
					action.jsClick(dateValues.get(i));
					action.pause(1000);
					break;
				}
			
		
		
		}
		
	}

	private void selectYear(String year, String ID) {
		Element = (WebElement) action.getElementByFormatingXpath("date_years", ID);
		
		List<WebElement> dateValues = Element.findElements(By.xpath("./*"));
		
		for(int i=0;i<dateValues.size();i++) {
			
				if(dateValues.get(i).getText().contentEquals(year)) {
					action.moveToElement(dateValues.get(i));
					action.jsClick(dateValues.get(i));
					break;
				}
			
		
		
		}
		
	}

	private boolean inRange(int low, int high, int x) {
		
		return (low <= x && high >=x);
	}

	private String getMonthname(String data) {
		String month = "";
		switch (data) {
			case "01":
				month = "January"; 
				break;
			case "02":
				month = "February";
				break;
			case "03":
				month = "March";
				break;
			case "04":
				month = "April";
				break;
			case "05":
				month = "May";
				break;
			case "06":
				month = "June";
				break;
			case "07":
				month = "July";
				break;
			case "08":
				month = "August";
				break;
			case "09":
				month = "September";
				break;
			case "10":
				month = "October";
				break;
			case "11":
				month = "November";
				break;
			case "12":
				month = "December";
				break;
			default:
				break;
				
		}
		return month;
	}

	public void enterPriorFirm(String priorFirm) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "priorFirm");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, priorFirm);
		} while (!(getPriorFirmValue().equals(priorFirm)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterPreviouslyApprovedForFADiscretionaryProgram(String previouslyApprovedForFADiscretionaryProgram) {
		switch (previouslyApprovedForFADiscretionaryProgram.toLowerCase().trim()) {
		case "yes":
			Element = action.getElementByFormatingXpath("Previously Approved For FA Discretionary Program", "Yes");
			action.moveToElement(Element);
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Previously Approved For FA Discretionary Program", "No");
			action.moveToElement(Element);
			Element.click();
			break;
		default:
			Reporter.addStepLog("Value for Previously Approved For FA Discretionary Program field in UI is not valid and ignoring the same");
			break;
		}
		
	}

	public void enterFaDiscretionaryProgramName(String faDiscretionaryProgramName, String previouslyApprovedForFADiscretionaryProgram) {
		
		if(previouslyApprovedForFADiscretionaryProgram.toLowerCase().trim().equals("yes")) {
			Element = (WebElement) action.fluentWaitForJSWebElement("Name Of FA Discretionary Programme");
			action.click(Element);
			Highlight = action.getElementByFormatingXpath("Common Dropdown Element", "faDiscretionaryProgramName");
			Highlight = Highlight.findElement(By.linkText(faDiscretionaryProgramName));
			action.scrollToElement(Highlight);
			action.highligthElement(Highlight);
			action.click(Highlight);
		}else if(previouslyApprovedForFADiscretionaryProgram.toLowerCase().trim().equals("no")){
			Reporter.addStepLog(" FA Discretionary Program field in UI is greayed out and ignoring the same");
		}else {
			action.pause(2000);
			String bool = getPreviouslyApprovedorNotForFADiscretionaryProgramValue();
			
			switch (bool) {
			case "t":
				Element = (WebElement) action.fluentWaitForJSWebElement("Name Of FA Discretionary Programme");
				action.click(Element);
				Highlight = action.getElementByFormatingXpath("Common Dropdown Element", "faDiscretionaryProgramName");
				Highlight = Highlight.findElement(By.linkText(faDiscretionaryProgramName));
				action.scrollToElement(Highlight);
				action.highligthElement(Highlight);
				action.click(Highlight);
				break;
			case "f":
				Reporter.addStepLog(" FA Discretionary Program field in UI is greayed out and ignoring the same");
				break;
			default:
				break;
			}
		}
		
	}

	public void enterFaSegment(String faSegment) {
		Element = (WebElement) action.fluentWaitForJSWebElement("FA Segment");
		action.click(Element);
		Highlight = action.getElementByFormatingXpath("Common Dropdown Element", "faSegment");
		Highlight = Highlight.findElement(By.linkText(faSegment));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
	}

	public void enterRenomination(String renomination) {
		switch (renomination.toLowerCase().trim()) {
		case "yes":
			Element = action.getElementByFormatingXpath("Renomination", "Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Renomination", "No");
			Element.click();
			break;
		default:
			Reporter.addStepLog("Value for Renomination field in UI is not valid and ignoring the same");
			break;
		}
		
	}

	public void enterLengthOfSeries7Registration(String lengthOfSeries7Registration) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "lengthOfSeries7Reg");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, lengthOfSeries7Registration);
		} while (!(getSeries7RegistrationValue().equals(lengthOfSeries7Registration)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterLengthOfSeries65Registration(String lengthOfSeries65Registration) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "lengthOfSeries65Reg");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, lengthOfSeries65Registration);
		} while (!(getSeries65RegistrationValue().equals(lengthOfSeries65Registration)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterLengthOfServiceAsFA(String lengthOfServiceAsFA) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "lengthOfService");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, lengthOfServiceAsFA);
		} while (!(getLenghtOfServiceAsFAValue().equals(lengthOfServiceAsFA)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterAum(String aum) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "aum");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, aum);
		} while (!(getAUMValue().equals(aum)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterAnticipatedPercentage(String anticipatedPercentage) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "anticipatedPercentageOfOverallBusiness");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, anticipatedPercentage);
		} while (!(getAnticipatedPercentageValue().equals(anticipatedPercentage)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterBranch(String branch) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "branchName");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, branch);
		} while (!(getBranchValue().equals(branch)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterComplex(String complex) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "complex");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, complex);
		} while (!(getComplexValue().equals(complex)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterDivision(String division) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "division");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, division);
		} while (!(getDivisionValue().equals(division)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterRegion(String region) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "region");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, region);
		} while (!(getRegionValue().equals(region)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterCfaOrAcpm(String cfaOrAcpm) {
		switch (cfaOrAcpm.toLowerCase().trim()) {
		case "cfa":
			Element = action.getElementByFormatingXpath("CFA or ACPM Holder", "CFA");
			Element.click();
			break;
		case "acpm":
			Element = action.getElementByFormatingXpath("CFA or ACPM Holder", "ACPM");
			Element.click();
			break;
		default:
			Reporter.addStepLog("Value for CFA or ACPM Holder field in UI is not valid and ignoring the same");
			break;
		}
		
	}

	public void enterWaiveOrCompletedCourseWork(String waiveOrCompletedCourseWork) {
		switch (waiveOrCompletedCourseWork.toLowerCase().trim()) {
		case "yes":
			Element = action.getElementByFormatingXpath("Waive / completed course work", "Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Waive / completed course work", "No");
			Element.click();
			break;
		default:
			Reporter.addStepLog("Value for Waive / completed course work field in UI is not valid and ignoring the same");
			break;
		}
		
	}

	public void enterZoologicCourseWorkRegistrationDate(String zoologicCourseWorkRegistrationDate, String waiveOrCompletedCourseWork) {
		String ID = "zoologicCourseworkRegistered";
		
		if(waiveOrCompletedCourseWork.toLowerCase().trim().equals("no")) {
			enterDate(zoologicCourseWorkRegistrationDate, ID);
			/*
			Element = action.getElementByFormatingXpath("Common date Field Input", "zoologicCourseworkRegistered");
			Element.click();
			Element.clear();
			Element.sendKeys(zoologicCourseWorkRegistrationDate);
			*/
		}else if(waiveOrCompletedCourseWork.toLowerCase().trim().equals("yes")){
			Reporter.addStepLog(" Renomination Date field in UI is greayed out and ignoring the same");
		}else {
			action.pause(2000);
			String bool = getWaiverorCompletedCourseValue();
			
			switch (bool) {
			case "f":
				enterDate(zoologicCourseWorkRegistrationDate, ID);
				/*
				Element = action.getElementByFormatingXpath("Common date Field Input", "zoologicCourseworkRegistered");
				Element.click();
				Element.clear();
				Element.sendKeys(zoologicCourseWorkRegistrationDate);
				*/
				break;
			case "t":
				Reporter.addStepLog(" Zoologic Course Work registration Date field in UI is greayed out and ignoring the same");
				break;
			default:
				break;
			}
		}
		
		
	}

	public void enterZoologicCourseWorkCompletedDate(String zoologicCourseWorkCompletedDate, String waiveOrCompletedCourseWork) {
		String ID = "zoologicCourseworkCompleted";
		
		if(waiveOrCompletedCourseWork.toLowerCase().trim().equals("no")) {
			enterDate(zoologicCourseWorkCompletedDate, ID);
			/*
			Element = action.getElementByFormatingXpath("Common date Field Input", "zoologicCourseworkCompleted");
			Element.click();
			Element.clear();
			Element.sendKeys(zoologicCourseWorkCompletedDate);
			*/
			
		}else if(waiveOrCompletedCourseWork.toLowerCase().trim().equals("yes")){
			Reporter.addStepLog(" Zoologic Course Work Completed Date field in UI is greayed out and ignoring the same");
		}else {
			action.pause(2000);
			String bool = getWaiverorCompletedCourseValue();
			
			switch (bool) {
			case "f":
				enterDate(zoologicCourseWorkCompletedDate, ID);
				/*
				Element = action.getElementByFormatingXpath("Common date Field Input", "zoologicCourseworkCompleted");
				Element.click();
				Element.clear();
				Element.sendKeys(zoologicCourseWorkCompletedDate);
				*/
				break;
			case "t":
				Reporter.addStepLog(" Zoologic Course Work Completed Date field in UI is greayed out and ignoring the same");
				break;
			default:
				break;
			}
		}
		/*
		Element = action.getElementByFormatingXpath("Common date Field Input", "zoologicCourseworkCompleted");
		Element.click();
		Element.clear();
		Element.sendKeys(zoologicCourseWorkCompletedDate);
		*/
	}

	public void enterAwards(String awards, String waiveOrCompletedCourseWork) {
		action.pause(2000);
		if(waiveOrCompletedCourseWork.toLowerCase().trim().equals("yes")) {
			Element = action.getElementByFormatingXpath("Common Text Area Input", "awards"); 
					//(WebElement) action.fluentWaitForJSWebElement("Awards");
					
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, awards);
			} while (!(getAwardsValue().equals(awards)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		
		}else if(waiveOrCompletedCourseWork.toLowerCase().trim().equals("no")){
			Reporter.addStepLog(" Awards field in UI is greayed out and ignoring the same");
		}else {
			action.pause(2000);
			String bool = getWaiverorCompletedCourseValue();
			
			switch (bool) {
			case "t":
				Element = action.getElementByFormatingXpath("Common Text Area Input", "awards");
				loopCount = 0;
				do {
					Element.click();
					myClear(Element);
					action.doubleClick(Element);
					action.sendKeys(Element, awards);
				} while (!(getAwardsValue().equals(awards)) && ++loopCount < 10);
				if(loopCount >= 10)
					Assert.fail("User is not able to input Text into Text Field");
			
				break;
			case "f":
				Reporter.addStepLog(" Awards field in UI is greayed out and ignoring the same");
				break;
			default:
				break;
			}
		}
		
	}

	public void enterAdditionalInformation(String additionalInformation) {
		Element = action.getElementByFormatingXpath("Common Text Area Input", "additionalInformation");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, additionalInformation);
		} while (!(getAdditionalInformationValue().equals(additionalInformation)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void enterRenominationDate(String renominationDate, String renomination) {
		String ID = "renominationDate";
		
		if(renomination.toLowerCase().trim().equals("yes")) {
			enterDate(renominationDate, ID);
			/*
			Element = action.getElementByFormatingXpath("Common date Field Input", "renominationDate");
			Element.click();
			Element.clear();
			Element.sendKeys(renominationDate);
			*/
		}else if(renomination.toLowerCase().trim().equals("no")){
			Reporter.addStepLog(" Renomination Date field in UI is greayed out and ignoring the same");
		}else {
			action.pause(2000);
			String bool = getRenominationValue();
			
			switch (bool) {
			case "t":
				enterDate(renominationDate, ID);
				/*
				Element = action.getElementByFormatingXpath("Common date Field Input", "renominationDate");
				Element.click();
				Element.clear();
				Element.sendKeys(renominationDate);
				*/
				break;
			case "f":
				Reporter.addStepLog(" Renomination Date field in UI is greayed out and ignoring the same");
				break;
			default:
				break;
			}
		}
		
		//List<WebElement> list = action.getElements("Renomination Date");
		//if(list.size() > 0) {
//			Element = action.getElementByFormatingXpath("Common date Field Input", "renominationDate");
//			Element.click();
//			Element.clear();
//			Element.sendKeys(renominationDate);
		//}
		
	}

	public boolean isAttributeEditable(String attribute) {
		Element = action.getElementByFormatingXpath("Common Attribute Value", attribute); //"CRD#(s)");
		action.highligthElement(Element);
		if(Element.getAttribute("disabled").trim().equals("true"))
			return true;
		return false;
	}

	public boolean isUserOnEnterFADetailsPage() {
		Element = action.waitForJSWebElement("Header");
		action.highligthElement(Element);
		if (Element.getText().equals("Enter Financial Advisor Details")) {
			return true;
		}
		return false;
	}

}
