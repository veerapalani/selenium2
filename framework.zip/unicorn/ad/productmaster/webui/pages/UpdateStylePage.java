package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class UpdateStylePage {
	Action action;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	public UpdateStylePage() {
		// TODO Auto-generated constructor stub
		action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStyleUIPage"));
	}
	
	
	public String getCurrentTimeStamp() {
		Long time = Calendar.getInstance().getTimeInMillis();
		return time.toString();
	}
	public void verifyTextInListOfElements(String text, List<WebElement> list1) {

		for (int i = 0; i < list1.size(); i++) {
			list.add(list1.get(i).getText());
			
			
		}
		for (int i=0; i<list.size();i++) {
//			Reporter.addStepLog("checking with "+list.get(i));
			if(list.get(i).contains(text))
			{	
				action.highligthElement(list1.get(i));
				Assert.assertTrue(true);
				return;
			}
		}
	//Assert.assertTrue(false);
	}
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		listOfElements= element.getElements("xpath", xpath);
		
		return listOfElements;
	}
}


