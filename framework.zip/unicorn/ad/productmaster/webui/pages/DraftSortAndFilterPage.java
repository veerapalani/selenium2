package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class DraftSortAndFilterPage {

	Action action;
	WebElement Element = null;
	WebElement Highlight = null;
	WebElement myElement;
	String[] expErrorlist;
	List<WebElement> actErrorMessages;
	Boolean flag;
	PMPageGeneric pmPageGeneric = new PMPageGeneric("AD_PM_BenchmarkSortAndFilterPage");
	
	public DraftSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void verifyAndClickDraftTab() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("DraftTab");
		action.highligthElement(Element);
		Element.isDisplayed();
		action.scrollToElement(Element);
		// Action.pause(2000);
		action.doubleClick(Element);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyTheDraftTabAfterFilterCondition() {
		// Action.pause(1000);
		Element = (WebElement) action.fluentWaitForJSWebElement("DraftTab");
		action.highligthElement(Element);
		action.scrollToElement(Element);
		Element.isDisplayed();
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		myElement = element;
		// Action.pause(2000);
		action.moveToElement(element);
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		myElement = element;
		// Action.pause(2000);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		myElement = element;
		// Action.pause(2000);
		action.highligthElement(myElement);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void clickOnSortIcon(WebElement element) {
		myElement = element;
		// Action.pause(2000);
		action.click(myElement);
	}

	public String verifyTheSortCoumnPropertyTypeASC() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("AscSortOrder");
		// Action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDESC() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("DescSortOrder");
		// Action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDefault() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("DefaultSortOrder");
		// Action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		//myElement = element;
		action.pause(3000);
		//action.highligthElement(element);
		action.isDisplayed(element);
		// Action.pause(4000);
		//action.jsClick(myElement);
		pmPageGeneric.actionsClick(element);
		//action.doubleClick(element);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		myElement = element;
		// Action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void clickOnFilterCondition() {
		// Action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("FilterCondition");
		action.click(Element);
	}

	public String verifyTheDraftGridCountAfterApplyFilterConditionOnTab() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTabForDraft");
		// action.pause(5000);
		action.highligthElement(Element);
		return action.getText(Element);
	}

	public void clickOnFilterConditionForDraftGridView(WebElement element) {
		myElement = element;
		// action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}

	public void enterFilterValue(String FilterValue) {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("FilterValue");
		action.click(Element);
		// action.pause(1000);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForDraftGridView() {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheDraftGridCountAfterScroll() {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterCondition");
		// action.pause(5000);
		String gridAllData = action.getAttribute(Element, "aria-rowcount");
		return gridAllData;
	}

	public void verifyTheNoResultsOnGridView() {
		// action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void clickOnApplyFilterIconForDraftGridViewForReset() {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForDraftGridViewForCancel() {
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnNextArrowTab() {
		// action.pause(5000);
		Element = (WebElement) action.fluentWaitForJSWebElement("NextArrowButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public boolean verifyNextArrowIsDisplay() {
		// action.pause(5000);
		Element = (WebElement) action.fluentWaitForJSWebElement("NextArrowButton");
		action.isDisplayed(myElement);
		return action.isDisplayed(myElement);
	}

	public WebElement getDynamicElementFromShadowRoot(String javaScript) {
		return myElement = (WebElement) action.executeJavaScript(javaScript);
	}

	/*
	 * public void verifyETFTab() { // Action.pause(5000); Element = (WebElement)
	 * action.fluentWaitForJSWebElement("NextArrowButton"); while
	 * (Element.isDisplayed()) { System.out.println("Inside While loop");
	 * action.highligthElement(Element); Element.click(); action.pause(2000); }
	 * action.pause(2000); Element = (WebElement)
	 * action.fluentWaitForJSWebElement("DraftTab"); // Action.pause(2000);
	 * action.highligthElement(Element); Action.pause(2000); Element.isDisplayed();
	 * Element.click(); action.pause(2000); }
	 */

	public String waitForWebElement(String xpath) {
		int timeLaps = 0;
		String status = "FAIL";
		while (status.equals("FAIL") && timeLaps < 2) {
			try {
				Element = findElementByDynamicXpath(xpath);
				if (Element == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}
			} catch (Exception e) {
				status = "FAIL";
			}
			action.pause(1000);
			++timeLaps;
		}
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);
		return status;
	}

}
