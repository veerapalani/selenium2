package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.utils.GlobalVariables;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import org.openqa.selenium.Keys;


public class UpdateFATeamUIPage 
{
	
	
	Action action;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();

	public UpdateFATeamUIPage()
	{
		action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategySMADualUIPage"));
	}

	public String getCurrentTimeStamp()
	{
		Long time = Calendar.getInstance().getTimeInMillis();
		return time.toString();
	}

	public void verifyTextInListOfElements(String text, List<WebElement> list1) 
	{
		for(int i = 0; i < list1.size(); i++)
		{
			list.add(list1.get(i).getText());
		}
		
		for(int i = 0; i < list.size(); i++)
		{
			if(list.get(i).contains(text))
			{
				action.highligthElement(list1.get(i));
				Assert.assertTrue(true);
				return;
			}
		}
	}

	public WebElement findElementByDynamicXpath(String xpath) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		listOfElements = element.getElements("xpath", xpath);
		return listOfElements;
	}
	
	public WebElement waitForWebElement(String xpath) 
	{

		int timeLaps = 0;
		String status = "FAIL";
		WebElement jsElement = null;
		while (status.equals("FAIL") && timeLaps < GlobalVariables.waitTime) {
			try {

				//jsElement = (WebElement) getElementByJavascript(dbkey);
				//jsElement = (WebElement) getElement(dbkey);
				jsElement = findElementByDynamicXpath(xpath);

				if (jsElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Exception e) {

				status = "FAIL";

			}

			Action.pause(2000);

			++timeLaps;

		}

		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);

		return jsElement;

	}
	
	public WebElement findElementByLinkText(String linktext) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("linktext", linktext);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public void searchFATeamName(String FATeamName) {

		Action.pause(2000);
		action.waitForPageLoad();
		myElement = (WebElement) action.getElementByJavascript("Global Search Box");
		myElement.click();
		myElement.clear();
		Action.pause(2000);
		action.sendkeysClipboard(myElement, FATeamName);
		Action.pause(5000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		Action.pause(10000);

	}
	
	public void clickOnSeeAllResults() {
		Action.pause(4000);
		myElement = (WebElement) action.getElementByJavascript("See All Result");
		action.highligthElement(myElement);
		myElement.click();
		
	}
	
	public void verifyElementsOnViewFAage(WebElement element) {
		myElement = element;
		Action.pause(3000);
		action.highligthElement(myElement);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	
	public void verifyContinueEditingAndCancelButtonsOnViewFAage(WebElement element) {
		myElement = element;
		Action.pause(2000);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	
	public void clickOnContinueEditingLink() {
		Action.pause(2000);
		myElement = (WebElement) action.getElement("ContinueEdit");
		Action.pause(2000);
		action.click(myElement);
		
	}
	
	public void verifyEditFATeamPaage(WebElement element) {
		myElement = element;
		Action.pause(2000);
		action.highligthElement(myElement);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	
}