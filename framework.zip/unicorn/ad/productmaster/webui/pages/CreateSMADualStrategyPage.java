package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateSMADualStrategyPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	String expMsg = "https://pm.uat.wmap.broadridge.com/pmui/#/smaDualMac/add";
	public static String benchmarkName1, LargeTraderId1 = null;
	WebElement Element;

	public CreateSMADualStrategyPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void enterstrategynameinthestrategywizard() {
		String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		Reporter.addStepLog("the window handle is" + winHandleBefore);
		WebElement element = (WebElement) action.getElementByJavascript("StrategyName");
		action.sendkeysClipboard(element, "create");
	}

	public void clickOnproginstrategywizard() {
		WebElement dropelement = (WebElement) action.fluentWaitForJSWebElement("SMADualProgram");
		action.highligthElement(dropelement);
		action.click(dropelement);
	}

	public void clickOnstrategybutton() throws Throwable {
		action.scrollByPixel(Integer.toString(700));
		myElement = action.getElement("Create Strategy Button");
		action.highligthElement(myElement);
		action.click(myElement);

	}

	public void enterLargeTraderId(String LargeTraderIdValue) throws InterruptedException {

		LargeTraderId1 = LargeTraderIdValue + Calendar.getInstance().getTimeInMillis();
		// Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		myElement = (WebElement) action.getElementByJavascript("txtLargetraderId");
		action.highligthElement(myElement);
		action.sendKeys(myElement, LargeTraderId1);
	}

	public void selectManagername(String managernameKey) throws InterruptedException {

		action.waitForPageLoad();
		Thread.sleep(100);
		action.jsClick((WebElement) action.fluentWaitForJSWebElement("drpDwnManagerName"));
		action.jsClick((WebElement) action.fluentWaitForJSWebElement("managernameKey"));
	}

	public void selectStylename(String stylenameKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("drpstyleType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("stylenameKey"));
	}

	public void selectFOAGrpCode(String FOAGrpCodeKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("drpDwnFOAGrpCode"));
		action.click((WebElement) action.fluentWaitForJSWebElement("FOAGrpCodeKey"));
	}

	public void selectShortDuration(String ShortDurationKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("chkboxshrtduration"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void ConcentratedStrategy(String ConcentratedStrategyKey) throws InterruptedException {
		Thread.sleep(500);
		action.click((WebElement) action.fluentWaitForJSWebElement("chkboxconcentratedstrategyindication"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void MarginEligible(String MarginEligibleKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("chkboxmargineligible"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void OptionsEligible(String OptionsEligibleKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("chkboxoptionseligible"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void ColateralEligible(String ColateralEligibleKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("chkboxcoleligible"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void SustainableInvesting(String SustainableInvestingKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("chkboxsustainableinvesting"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void selectMACEligibility(String MACEligibilityKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("drpMACEligibleType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("MACEligibilityKey"));
		Thread.sleep(100);
	}

	public void selectICEligibility(String ICEligibilityKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("drpICEligibleType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("ICEligibleKey"));
		Thread.sleep(100);
	}

	public void selectResearchRating(String ResearchRatingKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("researchratingType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("ResearchRatingKey"));
	}

	public void enterMACFeeValue(String MACFeeValue) throws InterruptedException {

		Thread.sleep(100);
		WebElement ele = (WebElement) action.fluentWaitWebElement("txtMACFee");
		action.highligthElement(ele);
		action.jsSendkeys(ele, MACFeeValue);
		Thread.sleep(100);
	}

	public void selectRiskCategory(String RiskCategoryKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("drpRiskcategoryType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("RiskCategoryKey"));
	}

	public void selectApprovaldate(String ApprovaldateKey) throws InterruptedException {
		/*
		 * Thread.sleep(500); action.click((WebElement)
		 * action.fluentWaitWebElement("selectapprovaldatetype")); WebElement el1 =
		 * action.fluentWaitWebElement("selectapprovaldatetype");
		 * action.sendKeys(action.fluentWaitWebElement("selectapprovaldatetype"),
		 * "011/06/2022" + Keys.ENTER);
		 */
		
action.click((WebElement) action.fluentWaitWebElement("selectapprovaldatetype"));
		
		action.click((WebElement) action.fluentWaitForJSWebElement("selectapprovaldatetypevalue"));
	}

	public void enterStrategyMin(String StrategyMinValue) throws InterruptedException {
		// String StrategyMinValue1="1";
		Thread.sleep(100);
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtStrategyMinimumvalue");
		action.highligthElement(ele);
		action.sendKeys(ele, StrategyMinValue);
		Thread.sleep(100);
	}

	public void selectFeeSchedule(String FeeScheduleKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("drpFeeScheduleType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("FeeScheduleKey"));
	}

	public void chkboxSplInstructions(String SplInstructionsKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitWebElement("chkboxsplinstructions"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void clickOnNextButton() throws InterruptedException {
		Thread.sleep(100);
		action.highligthElement((WebElement) action.fluentWaitWebElement("NextButton_SMADual"));
		action.captureEntireScreen();
		action.click((WebElement) action.fluentWaitWebElement("NextButton_SMADual"));
	}

	public void enterSplInstructions(String SplInstructionsValue) throws InterruptedException {
		Thread.sleep(100);
		WebElement ele = (WebElement) action.fluentWaitWebElement("txtsplinstvalue");
		action.highligthElement(ele);
		action.jsSendkeys(ele, SplInstructionsValue);
	}

	public void selectAARBaseTemplate(String AARBaseTemplateKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("basetemplateType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("AARBaseTemplateKey"));
	}

	public void chkboxHideStrategy(String HideStrategysKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitWebElement("chkboxhidestrategy"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void selectCompUniverse(String AARBaseTemplateKey) throws InterruptedException {
		Thread.sleep(100);
		action.click((WebElement) action.fluentWaitForJSWebElement("compuniverseType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("compuniverseKey"));
	}

	public Boolean smadualcreatepageURL() {
		Boolean flag = false;
		String actMsg = action.getCurrentURL();
		Reporter.addStepLog("Actual Message: " + actMsg);
		Reporter.addStepLog("Expected Message: " + expMsg);
		if (actMsg.equals(expMsg)) {
			flag = true;
		}

		return flag;
	}

	public void clickOnSMADualRadioButton() {
		myElement = (WebElement) action.fluentWaitForJSWebElement("SMA - Dual");
		action.highligthElement(myElement);
		myElement.click();
	}

	public void enterStrategyName(String data) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Add Strategy Name");
		action.highligthElement(Element);
		Element.click();
		action.sendKeys(Element, data);
	}

	public void clickOnCreateButton() {
		Element = action.fluentWaitWebElement("CREATE");
		Element.click();
	}

}
