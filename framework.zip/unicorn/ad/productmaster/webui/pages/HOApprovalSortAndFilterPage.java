package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class HOApprovalSortAndFilterPage {

	Action action;
	WebElement Element, myElement;
	Boolean flag;

	public HOApprovalSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void verifyAndClickHOApprovalTab() {
		Element = (WebElement) action.fluentWaitForJSWebElement("Next Arrow");
		while (Element.isDisplayed()) {

			// System.out.println("Inside While loop");
			// Element = (WebElement) action.fluentWaitForJSWebElement("Next Arrow");
			action.highligthElement(Element);
			action.click(Element);
			action.pause(2000);

		}
		// action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("HOApprovalTab");
		// Action.pause(2000);
		action.highligthElement(Element);
		Element.isDisplayed();
		action.pause(2000);
		action.click(Element);
		action.pause(2000);
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		myElement = element;
		Action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		// Action.pause(4000);
		action.jsClick(myElement);
	}

	public void filterIconVisible(WebElement element) {
		myElement = element;
		Action.pause(5000);
		action.highligthElement(myElement);
		action.doubleClick(myElement);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		// action.highligthElement(Element);
		return Element;
	}

	public String verifyTheGridCountBeforeApplyFilterAndSortCondition() {
		Action.pause(7000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountHOApproval");
		// Action.pause(5000);
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		Action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void clickOnFilterCondition() {
		Action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("FilterCondition");
		action.click(Element);
	}

	public void clickOnFilterConditionForHOApprovalGridView(WebElement element) {
		myElement = element;
		Action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}

	public void enterFilterValue(String FilterValue) {
		Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("FilterValue");
		action.click(Element);
		Action.pause(1000);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForHOApprovalGridView() {
		Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheHOApprovalGridCountAfterApplyFilterConditionOnTab() {
		Action.pause(5000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionHOApproval");
		// Action.pause(5000);
		return action.getText(Element);
	}

	public String verifyTheHOApprovalGridCountAfterScroll() {
		Action.pause(4000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterConditionHO");
		// Action.pause(5000);
		String gridAllData = action.getAttribute(Element, "aria-rowcount");
		return gridAllData;
	}

	public void clickOnApplyFilterIconForHOApprovalGridViewForReset() {
		// .pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForHOApprovalGridViewForCancel() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String waitForWebElement(String xpath) {
		int timeLaps = 0;
		String status = "FAIL";
		while (status.equals("FAIL") && timeLaps < 2) {
			try {
				Element = findElementByDynamicXpath(xpath);
				if (Element == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}
			} catch (Exception e) {
				status = "FAIL";
			}
			Action.pause(1000);
			++timeLaps;
		}
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);
		return status;
	}
}
