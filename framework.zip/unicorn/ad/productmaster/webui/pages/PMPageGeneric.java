package qa.unicorn.ad.productmaster.webui.pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class PMPageGeneric {
	Action action;

	public PMPageGeneric(String page) {
		// TODO Auto-generated constructor stub
		action = new Action(SQLDriver.getEleObjData(page));
	}

	public static ReadWriteLock readWriteLock = new ReentrantReadWriteLock();
	public static String storeForUse;
	WebElement myElement;
	XSSFSheet sheet;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	String excelPathForReference = "./src/test/resources/ad/productmaster/api/excel/ReferenceDetails.xlsx";
	ExcelUtils myReferenceFile = new ExcelUtils(ExcelOperation.LOAD, excelPathForReference);

	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String timeStamp = new SimpleDateFormat("ddMMyyyy(HHmm)").format(new java.util.Date());

	public void readLock() {
		readWriteLock.readLock().lock();
		;
	}

	public void writerLock() {
		readWriteLock.writeLock().lock();

	}

	public void readUnlock() {
		readWriteLock.readLock().unlock();
	}

	public void writerUnlock() {
		readWriteLock.writeLock().unlock();
	}

	public void launch_PM_URL() {

		action.openURL(SSOLoginPage.URL);
		Reporter.addStepLog("User has Launched PM URL Successfully");
	}

	public String readSearchTokenFromExcel(String attribute, String sheetName) {
		sheet = myReferenceFile.getSheet(sheetName);
		return (String) myReferenceFile.getCellData(sheet, 1,
				myReferenceFile.getCellIndexByCellValue(sheet, 0, attribute));

	}

	public void writeSearchTokenInExcel(String attribute, String sheetName, String Value) throws IOException {
		sheet = myReferenceFile.getSheet(sheetName);
		myReferenceFile.setCellData(sheet, 1, myReferenceFile.getCellIndexByCellValue(sheet, 0, attribute), Value);

	}

	public void verifyHeader(String HeaderKey) {
		myElement = getElement(HeaderKey);
		highlightElement(myElement);
		Assert.assertEquals(myElement.getText(), HeaderKey);
		Reporter.addStepLog("The header " + HeaderKey + " is present");
	}

	public void refreshPage() {
		action.refresh();
		Reporter.addStepLog("Refreshing the current page");
	}

	public void sendKeys(String keysToSend, WebElement element) {
		element.sendKeys(keysToSend);
	}

	public void sendKeys(String keysToSend, String elementKey) {
		getElement(elementKey).sendKeys(keysToSend);
	}

	public void sendKeysCharacterWise(String keysToSend, WebElement element) throws InterruptedException {

		action.sendKeyCharterWise(element, keysToSend);
		Thread.sleep(1000);
	}

	public void verifyElement(String elementKey) {

		myElement = getElement(elementKey);
		highlightElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void verifyElement(WebElement element) {
		myElement = element;
		highlightElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void verifyElementFromShadowRoot(String elementKey) {
		myElement = getElementFromShadowRoot(elementKey);
		highlightElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void verifyElementFromShadowRootdisable(String elementKey) {
		myElement = getElementFromShadowRoot(elementKey);
		highlightElement(myElement);
		Assert.assertFalse(action.isEnabled(myElement));
		Reporter.addScreenCapture();
	}

	public void highlightElement(WebElement element) {

		action.highligthElement(element);
	}

	public void highlightElementWithScroll(WebElement element) {
		scrollToElement(element);
		action.highligthElement(element);
	}

	public void verifyGhostText(String expectedGhostText, String boxKey) {
		myElement = getElement(boxKey);
		String actualGhostText = myElement.getAttribute("placeholder");
		Assert.assertEquals(actualGhostText, expectedGhostText);
	}

	public void verifyGhostText(String expectedGhostText, WebElement boxElement) {
		myElement = boxElement;
		String actualGhostText = myElement.getAttribute("placeholder");
		Reporter.addStepLog("The ghost text is " + actualGhostText);
		Assert.assertEquals(actualGhostText, expectedGhostText);
	}

	public WebElement fetchElementFromShadowRoot(String elementKey, String shadowRootElementKey) {
		WebElement shadowRootElement = action.getElement(shadowRootElementKey);
		WebElement expandedShadowRootElement = action.expandRootElement(shadowRootElement);
		myElement = action.getElementFromParentElement(expandedShadowRootElement, elementKey);
		highlightElement(myElement);
		return myElement;
	}

	public WebElement fetchElementFromShadowRoot(String elementKey, WebElement shadowRootElement) {

		WebElement expandedShadowRootElement = action.expandRootElement(shadowRootElement);
		myElement = action.getElementFromParentElement(expandedShadowRootElement, elementKey);
		highlightElement(myElement);
		return myElement;
	}

	public void verifyInsideElement(String key) {

		myElement = getInsideElement(myElement, key);
		highlightElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void verifyInsideElement(WebElement parentElement, String key) {

		myElement = getInsideElement(parentElement, key);
		highlightElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public WebElement getInsideElement(WebElement parentElement, String key) {
		myElement = action.getElementFromParentElement(parentElement, key);
		return myElement;

	}

	public List<WebElement> getInsideElements(WebElement parentElement, String key) {
		listOfElements = action.getElementsFromParentElement(parentElement, key);
		return listOfElements;

	}

	public void verifyCurrentElementColor(String expectedColorCode) {
		Assert.assertEquals(giveColorHexCode(myElement, "color"), expectedColorCode);
	}

	public void verifyHoverElement(WebElement element, WebElement hoverElement) {
		hoverOnElement(element);
		verifyElement(hoverElement);

	}

	public void scrollByPixel(int value) {
		action.scrollByPixel(Integer.toString(value));

	}

	public void scrollToElement(WebElement element) {
		action.scrollToElement(element);
	}

	public void scrollToElement(String elementKey) {
		action.scrollToElement(getElement(elementKey));
	}

	public void hoverOnElement(WebElement hoverElement) {
		action.moveToElement(hoverElement);
	}

	public List<WebElement> getElements(String key) {
		listOfElements = action.getElements(key);
		return listOfElements;

	}

	public void verifyTextInElement(String text, WebElement element) {
		Assert.assertEquals(element.getText(), text);
		highlightElement(element);
	}

	public void verifyTextNotPresentInListOfElements(String text, List<WebElement> list1) {

		for (int i = 0; i < list1.size(); i++) {
			list.add(list1.get(i).getText());
		}
		Assert.assertFalse(list.contains(text));
	}

	public void verifyTextInListOfElements(String text, List<WebElement> list1) {

		for (int i = 0; i < list1.size(); i++) {
			list.add(list1.get(i).getText());

		}
		for (int i = 0; i < list.size(); i++) {
//			Reporter.addStepLog("checking with "+list.get(i));
			if (list.get(i).contains(text)) {
				highlightElement(list1.get(i));
				Assert.assertTrue(true);
				return;
			}
		}
		// Assert.assertTrue(false);
	}

	public void verifyAttributeInListOfElements(String attribute, List<WebElement> list1, String value) {
		for (int i = 0; i < list1.size(); i++) {
			list.add(list1.get(i).getAttribute(attribute));
		}
		Assert.assertTrue(list.contains(value));
	}

	public void verifyHorizontalLineColor(String expectedColorCode, String elementKey) {
		myElement = action.getElement(elementKey);
		Assert.assertEquals(giveColorHexCode(myElement, "border-bottom-color"), expectedColorCode);
	}

	public boolean isThisDateValid(String dateToValidate, String dateFromat) {

		if (dateToValidate == null) {
			return false;
		}

		SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
		sdf.setLenient(false);

		try {

			// if not valid, it will throw ParseException
			Date date = (Date) sdf.parse(dateToValidate);
			System.out.println(date);

		} catch (ParseException e) {

			e.printStackTrace();
			return false;
		}

		return true;
	}

	public void verifyColor(String key, String expectedColorCode) {
		myElement = action.getElement(key);
		Assert.assertEquals(giveColorHexCode(myElement, "color"), expectedColorCode);
	}

	public void verifyColor(WebElement element, String expectedColorCode) {

		Assert.assertEquals(giveColorHexCode(element, "color"), expectedColorCode);
	}

	public String getText(String key) {
		myElement = action.getElement(key);
		return myElement.getText();
	}

	public void verifyBackgroundColor(String key, String expectedColorCode) {
		myElement = action.getElement(key);
		Assert.assertEquals(giveColorHexCode(myElement, "background-color"), expectedColorCode);
	}

	public String giveCssValue(WebElement element, String attribute) {

		return element.getCssValue(attribute);
	}

	public String giveColorHexCode(WebElement element, String attribute) {
		String colorCode = giveCssValue(element, attribute);
		return colorCode = Color.fromString(colorCode).asHex();

	}

	public void verifyAttribute(String expectedValue, String elementKey, String attribute) {
		Assert.assertEquals(getAttribute(elementKey, attribute), expectedValue);
	}

	public String getAttribute(String elementKey, String attribute) {
		return action.getElement(elementKey).getAttribute(attribute);
	}

	public void verifyAttribute(String expectedValue, WebElement element, String attribute) {
		Assert.assertEquals(getAttribute(element, attribute), expectedValue);

	}

	public String getAttribute(WebElement element, String attribute) {
		return element.getAttribute(attribute);
	}

	public WebElement getElement() {
		return myElement;
	}

	public void setElement(String key) {
		myElement = action.getElement(key);
	}

	public void setElement(WebElement element) {
		myElement = element;
	}

	public String getHeaderText(String elementKey) {

		String header = action.getElement(elementKey).getText();
		return header;
	}

	public void clickOnLink(String elementKey) throws Throwable {
		myElement = getElement(elementKey);
		highlightElement(myElement);
		action.click(myElement);

	}

	public void clickOnLink(WebElement element) {

		highlightElement(element);
		action.click(element);
	}

	public void scrollAndClickOnLink(String elementKey) throws Throwable {
		myElement = getElement(elementKey);
		scrollToElement(myElement);
		highlightElement(myElement);
		action.click(myElement);

	}

	public void clickOnLink1(WebElement element) {

		highlightElement(element);
		action.jsClick(element);
	}

	public static void selectDatebyJS(WebDriver driver, WebElement element, String datval) {
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		js.executeScript("arguments[0].setAttribute('value','" + datval + "');", element);
	}

	public void scrollAndClickOnLink(WebElement element) {
		scrollToElement(myElement);
		highlightElement(element);
		action.click(element);
	}

	public WebElement getElement(String key) {
		myElement = action.getElement(key);
		return myElement;
	}

	public WebElement getElementFromShadowRoot(String elementKey) {
		myElement = (WebElement) action.getElementByJavascript(elementKey);
		return myElement;
	}

	public List<WebElement> getElementsFromShadowRoot(String elementKey) {
		listOfElements = (List<WebElement>) action.getElementByJavascript(elementKey);
		return listOfElements;

	}

	public void verifyFormat(String timeStamp, String format) {
		Pattern pattern;
		Matcher matcher;
		String TIME_PATTERN = format;

		pattern = Pattern.compile(TIME_PATTERN);

		matcher = pattern.matcher(timeStamp);
		Assert.assertTrue(matcher.matches());

	}

	public void verifyScrollCapability(WebElement element) {

		int scrollHeight = Integer.parseInt(element.getAttribute("scrollHeight"));
		int offsetHeight = Integer.parseInt(element.getAttribute("offsetHeight"));
		Boolean isScrollable = scrollHeight > offsetHeight;
		Assert.assertTrue(isScrollable);
	}

	public void verifyPageURL(String expectedURL) {
		Assert.assertTrue(getPageURL().contains(expectedURL));
	}

	public String getPageURL() {
		return action.getCurrentURL();
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public WebElement getDynamicElementFromShadowRoot(String javaScript) {
		return myElement = (WebElement) action.executeJavaScript(javaScript);
	}

	public List<WebElement> getDynamicElementsFromShadowRoot(String javaScript) {
		return listOfElements = (List<WebElement>) action.executeJavaScript(javaScript);
	}

	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		return element.getElements("xpath", xpath);
	}

	public Boolean isDisplayed(String dbKey) {
		Boolean flag = false;

		myElement = action.getElement(dbKey);
		action.waitForJSWebElement(dbKey);
		action.highligthElement(myElement);
		Reporter.addScreenCapture();
		if (myElement.isDisplayed() == true) {
			flag = true;
		}
		return flag;
	}

	// For Text Box, Radio Buttons, Check boxes
	public static WebElement waitForElementToBeVisible(WebElement webElement, int seconds) {

		WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), seconds);

		WebElement element = wait.until(ExpectedConditions.visibilityOf(webElement));

		return element;
	}

	// For Buttons, Links, Clickable Images
	public static WebElement waitForElementToBeClickable(WebElement webElement, int seconds) {

		WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), seconds);

		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(webElement));

		return element;
	}
	// For Synchronising Excel Data

	public static synchronized int getRowIndexbySyncCellValue(String excelFilePath, String sheetName,
			String mandatorydetails) {
		ExcelUtil.setExcelFile(excelFilePath, sheetName);
		int rowIndex = ExcelUtil.getRowIndexByCellValue(0, mandatorydetails);
		ExcelUtil.closeWorkBook();
		return rowIndex;
	}

	public static synchronized void setCellDataSync(String excelFilePath, String sheetName, int rowIndex,
			int columnIndex, String value) throws IOException {
		ExcelUtil.setExcelFile(excelFilePath, sheetName);
		ExcelUtil.setCellData(rowIndex, columnIndex, value);
		ExcelUtil.closeWorkBook();

	}

	public static synchronized String getCellDataSync(String excelFilePath, String sheetName, int rowIndex,
			int columnIndex) {
		ExcelUtil.setExcelFile(excelFilePath, sheetName);
		/*
		 * String data; try { data = (String) ExcelUtil.getCellData(rowIndex,
		 * columnIndex).toString(); } catch (Exception e) { data =
		 * String.valueOf(ExcelUtil.getCellData(rowIndex, columnIndex)); }
		 */

		Object data = ExcelUtil.getCellData(rowIndex, columnIndex);

		if (data.getClass().toString().contains("Double")) {
			return data.toString().substring(0, data.toString().length() - 2);
		}

		ExcelUtil.closeWorkBook();
		return (String) data.toString();
	}

	// Wait till Text input by Expicit wait
	public static void waitForTextToAppear(WebDriver driver, String textToAppear, WebElement element) {

		WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 30);

		wait.until(ExpectedConditions.textToBePresentInElementValue(element, textToAppear));

	}

	public static void waitForTextToAppearInTextField(boolean flag, WebElement Element, String textToInput)
			throws InterruptedException {

		while (flag) {

			Element.click();
			Element.clear();
			Element.sendKeys(textToInput);
			Thread.sleep(1000);
			if (Element.getAttribute("value") == textToInput)
				flag = false;

		}

	}

	// Common Code for Print functionalit5y
	// to switch the Window and save the pdf file and retun pdf text
	public String switchtoWindowAndSaveThePdf() throws Exception {
		action.pause(5000);
		Set<String> windowHandles = action.getWindowsHandles();
		String childWindow = action.getWindowHandle(windowHandles, 2);
		action.switchToWindow(childWindow);

		if (isPresent("js",
				"return document.querySelector(\"body > print-preview-app\").shadowRoot.querySelector(\"#sidebar\").shadowRoot.querySelector(\"#header\").shadowRoot.querySelector(\"#headerContainer > h1\")")) {
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"body > print-preview-app\").shadowRoot.querySelector(\"#sidebar\").shadowRoot.querySelector(\"#header\").shadowRoot.querySelector(\"#headerContainer > h1\")");
		} else {
			childWindow = action.getWindowHandle(windowHandles, 3);
			action.switchToWindow(childWindow);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"body > print-preview-app\").shadowRoot.querySelector(\"#sidebar\").shadowRoot.querySelector(\"#header\").shadowRoot.querySelector(\"#headerContainer > h1\")");
		}
		action.highligthElement(myElement);
		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector(\"body > print-preview-app\").shadowRoot.querySelector(\"#sidebar\").shadowRoot.querySelector(\"#destinationSettings\").shadowRoot.querySelector(\"#destinationSelect\").shadowRoot.querySelector(\"print-preview-settings-section > div > select\")");

		Select select = new Select(myElement);
		select.selectByValue("Save as PDF/local/");
		Reporter.addScreenCapture();

		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector(\"body > print-preview-app\").shadowRoot.querySelector(\"#sidebar\").shadowRoot.querySelector(\"print-preview-button-strip\").shadowRoot.querySelector(\"div > cr-button.action-button\")");
		action.click(myElement);

		String filename = saveFileWithRobot();
		String pdfText = getPdfContent(System.getProperty("user.home") + "\\Downloads\\" + filename);
		// System.out.println(pdfText);
		// System.out.println(pdfText.replaceAll("[\\t\\n\\r]+", " ").replace(" ",
		// "").contains("GLUE_BATCH"));
		return pdfText;
	}

	public static void setClipboardData(String data) {
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		StringSelection stringSelection = new StringSelection(data);
		clipboard.setContents(stringSelection, null);
	}

	public String saveFileWithRobot() {
		action.pause(3000);
		String fileName = timeStamp + ".pdf";
		try {
			setClipboardData(fileName);

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.delay(150);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception exp) {
			exp.printStackTrace();
		}

		action.pause(5000);
		action.captureEntireScreen();
		return fileName;
	}

	public String getPdfContent(String fileLocation) throws Exception {
		PDDocument document = PDDocument.load(new File(fileLocation));
		String text = null;
		if (!document.isEncrypted()) {
			PDFTextStripper stripper = new PDFTextStripper();
			text = stripper.getText(document);
		}
		document.close();
		return text;
	}

	public final boolean isPresent(String valueType, String value) {
		boolean isPresent = false;
		String status = "FAIL";
		try {
			Element element = new Element(WebDriverManager.getDriver());
			element.getElement(valueType, value);
			isPresent = true;
			status = "PASS";
		} catch (Exception e) {
			/* please do not throw any exception here */
			status = "PASS";
		} finally {
			Report.printOperation("is Present");
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}
		return isPresent;
	}

	public static synchronized int getColumnCount(String excelFilePath, String sheetName) throws IOException {
		ExcelUtil.setExcelFile(excelFilePath, sheetName);
		int cellcount = ExcelUtil.getCellCount(1);
		ExcelUtil.closeWorkBook();
		return cellcount;
	}

	public void verifyPrintFunctionalityForFirstEntity(String excelFilePath, String sheetName) throws Exception {

		String pdfText = switchtoWindowAndSaveThePdf();
		String pdfTextReplace = pdfText.replaceAll("[\\t\\n\\r]+", " ").replace(" ", "");
		int columnCount = getColumnCount(excelFilePath, sheetName);
		// To check for header
		for (int i = 0; i < columnCount; i++) {
			// To replace quotes
			String uiValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, i);
			String uiValueReplace = uiValue.replace(" ", "");
			Reporter.addStepLog("<b>Actual: </b>" + uiValue);
			// System.out.println(uiValue);
			if (!uiValue.isEmpty()) {
				Assert.assertTrue(pdfTextReplace.contains(uiValueReplace));
			}
		}
		// To check for first entity
		for (int i = 0; i < columnCount; i++) {
			// To replace quotes
			String uiValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 1, i);
			String uiValueReplace = uiValue.replace(" ", "");
			Reporter.addStepLog("<b>Actual: </b>" + uiValue);
			// System.out.println(uiValue);
			if (!uiValue.isEmpty()) {
				Assert.assertTrue(pdfTextReplace.contains(uiValueReplace));
			}
		}
	}

	/**
	 * Actions Click
	 * 
	 * @param element
	 */
	public void actionsClick(WebElement element) {

		String status = "FAIL";
		try {
			new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.elementToBeClickable(element));
			new Actions(WebDriverManager.getDriver()).moveToElement(element).click().build().perform();
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("actions click");
			Report.printStatus(status);
		}
	}

	/**
	 * To enter text in textbox and verify it is same as input
	 * 
	 */
	public static void enterTextandVerify(WebElement Element, WebElement attributeElement, String textToInput)
			throws InterruptedException {
		boolean flag = true;
		while (flag) {
			Element.click();
			Element.clear();
			Element.sendKeys(textToInput);
			Thread.sleep(1000);
			// System.out.println(attributeElement.getAttribute("value"));
			if (attributeElement.getAttribute("value").equalsIgnoreCase(textToInput))
				flag = false;
		}
	}
}
