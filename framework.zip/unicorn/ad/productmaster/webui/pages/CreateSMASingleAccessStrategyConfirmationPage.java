package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateSMASingleAccessStrategyConfirmationPage {
	Action action;
	WebElement Element;
	WebElement myElement;
	public CreateSMASingleAccessStrategyConfirmationPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public boolean isUserOnConfirmatioPage() {
		//action.pause(5000);
		Element = action.waitForJSWebElement("Confirmation Message");
		if(action.getText(Element).contains("SMA Single Creation Request")) {
			return true;
		}
		return false;
	}
	
	public void verifyElementsonconfirmationpage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public String getStrategyCode() {
		Element = action.getElement("FOACode");
		String strategyInfo = Element.getText();
		strategyInfo = strategyInfo.replace("|", ";");
    	String message[] = strategyInfo.split(";");
    	return message[2].trim();
	}

	public boolean isStrategyCreatedSuccessfully() {
		
		Element = action.waitForJSWebElement("Confirmation Tick Mark");
				//(WebElement) action.fluentWaitForJSWebElement("Confirmation Tick Mark");
		
		if(Element.isDisplayed()) {
			//action.pause(2000);
			//System.out.println("Pass");
			return true;
		}
		
		return false;
	}

	public boolean isStrategyCreatedMessageDisplayed(String confirmationMessage) {
		Element = action.getElement("Confirmation Message");
		
		//System.out.println(action.getText(Element));
		//System.out.println(confirmationMessage);
		if(action.getText(Element).equals(confirmationMessage)) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isConfirmationMessageDisplayedInBlack(String strArg1) {
		Element = action.getElement("Confirmation Message");
		String textColor = Element.getCssValue("color");
		//System.out.println(textColor);
		String hextextColor = Color.fromString(textColor).asHex();
		//System.out.println(hextextColor);
		
		if(hextextColor.equals("#1c1c1c")) {
			return true;
		}
		return false;
	}

	public void clickOnDoneButton() {
		Element = action.fluentWaitWebElement("Done");
		Element.click();
		//action.pause(3000);
	}
	
	public String getStrategyCodeDual() {
		Element = action.getElement("Strategy Code");
		String strategyInfo = Element.getText();
		strategyInfo = strategyInfo.replace("|", ";");
    	String message[] = strategyInfo.split(";");
    	return message[2].trim();
	}
}
