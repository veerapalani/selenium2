package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateStylePage {
	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public  CreateStylePage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	public void verifyElementinCreateStylePage(String elementKey) {
myElement = getElement(elementKey);
		highlightElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}
	public WebElement getElement(String key) {
		myElement = action.getElement(key);
		return myElement;
	}
	public void highlightElement(WebElement element) {
		action.highligthElement(element);
	}

	public void clickOntheelementsoncreatestylepage(String elementKey) throws Throwable{
		myElement = action.getElement(elementKey);
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public void clickOnnextbuttononcreatestylepage() throws Throwable{
		myElement = action.getElement("Next Button");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public void verifyAttributesinCreateStylePage(String elementKey) {
		 myElement = action.getElement(elementKey);
		action.highligthElement(myElement);
				Assert.assertTrue(action.isDisplayed(myElement));
				Reporter.addScreenCapture();
			}
public void clickOnLink(WebElement element) {
		
		highlightElement(element);
		action.click(element);
	}

public void verifytimestampinCreateStylePage() {
	 myElement = action.getElement("Timestamp");
	action.highligthElement(myElement);
			Assert.assertTrue(action.isDisplayed(myElement));
			Reporter.addScreenCapture();
		}
	public void scrollAndClickOnLink(WebElement element) {
		scrollToElement(myElement);
		highlightElement(element);
		action.click(element);
	}
	public void scrollToElement(WebElement element) {
		action.scrollToElement(element);
	}
	public String giveCssValuehere(WebElement element, String attribute) {
return element.getCssValue(attribute);
	}
	public void verifystatusfieldincreatestylepage() {
		myElement = (WebElement) action.getElementByJavascript("Status field");
		highlightElement(myElement);
		Assert.assertFalse(action.isEnabled(myElement));
		Reporter.addScreenCapture();
	}
	public List<WebElement> getDynamicElementsFromShadowRoot(String javaScript) {
		return listOfElements = (List<WebElement>)action.executeJavaScript(javaScript);
	}
	public WebElement getElementFromShadowRoot(String elementKey) {
		myElement = (WebElement) action.getElementByJavascript(elementKey);
		return myElement;
	}
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	public void verifyElementsoncreatestylepage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	public void verifyAttribute(String expectedValue, WebElement element, String attribute) {
		Assert.assertEquals(getAttribute(element, attribute), expectedValue);

	}
	public String getAttribute(WebElement element, String attribute) {
		return element.getAttribute(attribute);
	}
	public List<WebElement> findElementsByDynamicXpath(String xpath){
		Element element = new Element(WebDriverManager.getDriver());
		return element.getElements("xpath", xpath);
	}
	
	public WebElement getDynamicElementFromShadowRoot(String javaScript) {
		return myElement = (WebElement) action.executeJavaScript(javaScript);
	}
	public void sendKeys(String keysToSend,WebElement element) {
		//element.sendKeys(keysToSend);
		action.sendKeys(element, keysToSend);
	}
	
	public void clickOnjsLink(WebElement element) {
		
		action.highligthElement(element);
		action.jsClick(element);
	}
}
