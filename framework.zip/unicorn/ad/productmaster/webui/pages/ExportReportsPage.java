package qa.unicorn.ad.productmaster.webui.pages;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import junit.framework.Assert;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;

public class ExportReportsPage {
	String fileDownloadPath = FileManager.getFileManagerObj().downloadFolderFilePath();
	String exlPath = FileManager.getFileManagerObj().downloadFolderFilePath();
	File tempFile;
	List<String[]> fileData = new ArrayList<String[]>();
	List<WebElement> elementsInGrid;
	ExcelUtils exlObj;
	XSSFSheet sheet;
	int count, rowIndex = 0;
	String[] expectedCsvValues = null;

	public void DeletePreviousFile(String entityName) throws InterruptedException {

		fileDownloadPath = fileDownloadPath + "\\" + entityName + ".csv";

		tempFile = new File(fileDownloadPath);

		if (tempFile.exists() == true) {
			Reporter.addStepLog("FILE found at download location - " + fileDownloadPath);
			FileManager.getFileManagerObj().deleteFile(fileDownloadPath);
			Reporter.addStepLog("<b>File Deleted!!!</b>");
		} else {
			Reporter.addStepLog("Download location - " + fileDownloadPath);
			Reporter.addStepLog("FILE not found");
		}
	}

	public Boolean VerifyFileDownloaded() throws InterruptedException {
		Boolean flag = false;
		Thread.sleep(1000);

		tempFile = new File(fileDownloadPath);

		if (tempFile.exists() == true) {
			flag = true;
			Reporter.addStepLog("<b>FILE found at download location -</b> " + fileDownloadPath);
		} else {
			Reporter.addStepLog("Download location - " + fileDownloadPath);
			Reporter.addStepLog("FILE not found");
		}

		return flag;
	}

	public List<String> getCsvData(String entityName) {
		CSVFileUtils csvReader = CSVFileUtils.getInstance();
		List<String[]> readAll = csvReader.readAll("C:\\automation\\" + entityName + ".csv", ";");

		return csvReader.getColumnValues(readAll, 0);
	}

	public Integer getNumberOfRecordsInFile(String entityName) {
		count = getCsvData(entityName).size() - 1;
		Reporter.addStepLog("<b>Number of records in file: </b>" + count);
		return count;
	}

	public String getFirstRowInCsvData(String entityName) {
		return getCsvData(entityName).get(1);
	}

	public String[] getCsvDataValues(String entityName) {
		// split using delimiter comma and ignoring commas in quotes
		return getFirstRowInCsvData(entityName).split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
	}

	public void verifyAttributesForFirstEntity(String entityName, String excelFilePath) throws IOException {
		System.out.println("path" + excelFilePath);
		exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		sheet = exlObj.getSheet(entityName);
		String[] expectedCsvValues = getCsvDataValues(entityName);

		for (int i = 0; i < expectedCsvValues.length; i++) {
			// To replace quotes
			String afterReplacingQuotes = expectedCsvValues[i].replaceAll("^\"|\"$", "");
			// System.out.println(i + "-" + expectedCsvValues[i].replaceAll("^\"|\"$", ""));
			// System.out.println(i + "-" + PMPageGeneric.getCellDataSync(excelFilePath,
			// entityName, 1, i));
			Reporter.addStepLog("__________________________________________");
			Reporter.addStepLog("<b>Expected: </b>" + afterReplacingQuotes);
			Reporter.addStepLog("<b>Actual: </b>" + PMPageGeneric.getCellDataSync(excelFilePath, entityName, 1, i));
			Reporter.addStepLog("__________________________________________");
			Assert.assertTrue(afterReplacingQuotes
					.equalsIgnoreCase(PMPageGeneric.getCellDataSync(excelFilePath, entityName, 1, i)));
		}
		exlObj.closeWorkBook();
	}

	public void verifyAttributesForFirstEntityforFA(String entityName, String excelFilePath) throws IOException {
		System.out.println("path" + excelFilePath);
		exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		sheet = exlObj.getSheet(entityName);
		String[] expectedCsvValues = getCsvDataValues(entityName);

		for (int i = 0; i < expectedCsvValues.length; i++) {
			// To replace quotes
			String afterReplacingQuotes = expectedCsvValues[i].replaceAll("^\"|\"$", "");
			String uiValue = PMPageGeneric.getCellDataSync(excelFilePath, entityName, 1, i);
			if(afterReplacingQuotes.contains("0.0")) {
				afterReplacingQuotes = afterReplacingQuotes.substring(1);
			}
			System.out.println(i + "-" + afterReplacingQuotes);
			System.out.println(i + "-" + uiValue);
			Reporter.addStepLog("__________________________________________");
			Reporter.addStepLog("<b>Expected: </b>" + afterReplacingQuotes);
			Reporter.addStepLog("<b>Actual: </b>" + uiValue);
			Reporter.addStepLog("__________________________________________");
			if (afterReplacingQuotes.equalsIgnoreCase(uiValue)) {
				Assert.assertTrue(afterReplacingQuotes.equalsIgnoreCase(uiValue));
			} else if (afterReplacingQuotes.equalsIgnoreCase("true")) {
				Assert.assertTrue(afterReplacingQuotes.equalsIgnoreCase("true"));
			} else {
				Assert.assertTrue(afterReplacingQuotes.equalsIgnoreCase("false"));
			}
		}
		exlObj.closeWorkBook();
	}
	
	public void verifyAttributesForFirstEntityBenchmark(String entityName, String excelFilePath) throws IOException {
		System.out.println("path" + excelFilePath);
		exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		sheet = exlObj.getSheet(entityName);
		String[] expectedCsvValues = getCsvDataValues(entityName);

		for (int i = 0; i < expectedCsvValues.length; i++) {
			// To replace quotes
			String afterReplacingQuotes = expectedCsvValues[i].replaceAll("^\"|\"$", "");
			String uiValue = PMPageGeneric.getCellDataSync(excelFilePath, entityName, 1, i);
			String label = PMPageGeneric.getCellDataSync(excelFilePath, entityName, 0, i);
			// System.out.println(i + "-" + expectedCsvValues[i].replaceAll("^\"|\"$", ""));
			// System.out.println(i + "-" + PMPageGeneric.getCellDataSync(excelFilePath,
			// entityName, 1, i));
			Reporter.addStepLog("__________________________________________");
			Reporter.addStepLog("<b>Field Name: </b>" + label);
			Reporter.addStepLog("<b>Expected: </b>" + afterReplacingQuotes);
			Reporter.addStepLog("<b>Actual: </b>" +uiValue);
			Reporter.addStepLog("__________________________________________");
			new SoftAssert().assertTrue(afterReplacingQuotes.equalsIgnoreCase(uiValue));
		}
		exlObj.closeWorkBook();
	}
}
