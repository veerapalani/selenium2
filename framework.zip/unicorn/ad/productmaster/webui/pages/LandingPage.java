package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class LandingPage {

	Action action;// new Action(SQLDriver.getEleObjData(""));
	Actions actions;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	int loopCount;

	public LandingPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void myClear(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		js.executeScript("arguments[0].value='';", element);
	}

	public void clickOncreatenewdropdownicon() {

		/*
		 * WebElement dropelement = (WebElement)
		 * action.getElementByJavascript("Dropdown Icon");
		 * action.highligthElement(dropelement); action.jsClick(dropelement);
		 */
		// Action.pause(2000);
		action.waitForPageLoad();
		WebElement dropelement = (WebElement) action.fluentWaitForJSWebElement("Dropdown Icon");
		action.highligthElement(dropelement);
		dropelement.click();
	}

	public void clickOncreatenewdropdownbutton() throws InterruptedException {
		Action.pause(2000);
		action.waitForPageLoad();
		WebElement dropelement = (WebElement) action.fluentWaitForJSWebElement("Dropdown Icon");
		action.highligthElement(dropelement);
		dropelement.click();
		Thread.sleep(2000);
		Reporter.addScreenCapture();
	}

	public void fateamacount() throws InterruptedException {
		Thread.sleep(4000);
		WebElement styleelement = (WebElement) action.getElementByJavascript("FA team accordion");
		action.highligthElement(styleelement);
		action.jsClick(styleelement);
		Thread.sleep(2000);
	}

	public void smacount() throws InterruptedException {

		Thread.sleep(4000);
		WebElement styleelement = (WebElement) action.getElementByJavascript("SMA count");
		action.highligthElement(styleelement);
		action.jsClick(styleelement);
		Thread.sleep(2000);

	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public void clickOnstyledropdownmenu() throws InterruptedException {
		Action.pause(2000);
		action.waitForPageLoad();
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("Style_Menu");
		WebElement styleelement = (WebElement) action.getElementByJavascript("Style_Menu");
		action.highligthElement(styleelement);
		Thread.sleep(2000);
		action.jsClick(styleelement);
	}

	public void clickOnmanagerdropdownmenu() {
		WebElement styleelement = (WebElement) action.fluentWaitForJSWebElement("Manager_Menu");
		action.highligthElement(styleelement);
		action.jsClick(styleelement);
	}

	public void clickOnstrategydropdownmenu() {
		/*
		 * WebElement element = (WebElement)
		 * action.getElementByJavascript("Strategy Menu");
		 * action.highligthElement(element); action.jsClick(element);
		 */
		WebElement element = (WebElement) action.fluentWaitForJSWebElement("Strategy Menu");
		action.highligthElement(element);
		element.click();
	}

	public void clickOnFAdropdownmenu() {
		WebElement element = (WebElement) action.fluentWaitForJSWebElement("FAMenu");
		action.highligthElement(element);
		action.jsClick(element);
	}

	public void clickOnprogdropdownlink() {
		WebElement dropelement = (WebElement) action.getElementByJavascript("PrgDropdown");
		// WebElement dropelement=(WebElement) action.executeJavaScript("return
		// document.querySelector('wf-select[label=\"Program\"]').shadowRoot.querySelector('wf-tooltip
		// div div button wf-icon')");
		action.highligthElement(dropelement);
		action.jsClick(dropelement);
	}

	public void verifyCreateNewDropdownonlandingpage() throws InterruptedException {
		Action.pause(2000);
		action.waitForPageLoad();
		WebElement dropelement = action.fluentWaitWebElement("Create New Dropdown");
		action.highligthElement(dropelement);
		Assert.assertTrue(action.isDisplayed(dropelement));
		Reporter.addScreenCapture();
	}

	public void selectprogramvalue() {
		WebElement styleelement = (WebElement) action.getElementByJavascript("PrgDropdownvalue");
		// WebElement styleelement=(WebElement) action.executeJavaScript("return
		// document.querySelector('wf-select[label=\"Program\"]').shadowRoot.querySelector('wf-tooltip
		// > div > div > wf-dropdown > ul > li:nth-child(2) > a')");
		action.highligthElement(styleelement);
		action.jsClick(styleelement);
	}

	public void verifyDropdowniconincreatenewdropdown() {
		Action.pause(2000);
		action.waitForPageLoad();
		myElement = (WebElement) action.getElementByJavascript("Dropdown Icon");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void verifyProductMasterheaderonlandingpage() throws InterruptedException {

		// Thread.sleep(3000);
		// Action.pause(2000);
		action.waitForPageLoad();
		//JavascriptExecutor executor = (JavascriptExecutor) WebDriverManager.getDriver();
		//executor.executeScript("document.body.style.zoom = '90%';");
		//WebDriverManager.getDriver().get("chrome://settings/");
		//JavascriptExecutor executor = (JavascriptExecutor) WebDriverManager.getDriver();
		//executor.executeScript("chrome.settingsPrivate.setDefaultZoom(1.25);");
		new WebDriverWait(WebDriverManager.getDriver(), 10).until(ExpectedConditions.titleIs("Product Master"));
		myElement = action.fluentWaitWebElement("Product Master");
		action.highligthElement(myElement);
		// Thread.sleep(2000);
		// Assert.assertTrue(action.isPresent("Product Master"));
		Reporter.addScreenCapture();
	}

	// -----------------------NEW-------------------------------
	public void clickOnCreateNewDropdown() {
		Action.pause(2000);
		action.waitForPageLoad();
		WebElement ele = (WebElement) action.getElementByJavascript("Create New DD");
		action.highligthElement(ele);
		action.click(ele);
	}

	public void clickOnBenchmarkEntity() {
		WebElement ele = (WebElement) action.getElementByJavascript("Benchmark Menu");
		action.highligthElement(ele);
		action.click(ele);
	}

	public void clickOnFAEntity() {
		WebElement ele = (WebElement) action.getElementByJavascript("FA Menu");
		action.highligthElement(ele);
		action.click(ele);
	}

	public void enterStyleSearchToken(String searchToken) throws InterruptedException {
		// WebElement ele = (WebElement)
		// action.getElementByJavascript("Search_TextBox");
		Action.pause(2000);
		action.waitForPageLoad();
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("Search_TextBox");
		Thread.sleep(2000);
		action.click(ele);
		ele.clear();
		action.sendKeys(ele, searchToken);
	}

	public void enterSearchToken(String searchToken) throws InterruptedException {
		// WebElement ele = (WebElement)
		// action.getElementByJavascript("Search_TextBox");
		// Action.pause(2000);
		WebElement Element = (WebElement) action.fluentWaitForJSWebElement("Search_TextBox");
		loopCount = 0;
		do {

			Element.click();
			myClear(action.waitForJSWebElement("Search_TextBox_Value"));
			Element.sendKeys(searchToken);
		} while (!getGlobalSearchValue().equals(searchToken) && ++loopCount < 10);
		if (loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		Reporter.addScreenCapture();
	}

	private String getGlobalSearchValue() {
		WebElement Element = action.waitForJSWebElement("Search_TextBox_Value");
		String data = Element.getAttribute("value");
		if (data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}

	public void clickOnSearchIconinSearchTextBox() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("Search Icon in Search TextBox");
		action.highligthElement(ele);
		Thread.sleep(5000);
		int i = 0;
		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		Action.pause(10000);
		Reporter.addScreenCapture();
	}

	public void clickOnSearchIcon() throws InterruptedException {
		
		myElement = (WebElement) action.fluentWaitForJSWebElement("Search Icon in Search TextBox");
		action.moveToElement(myElement);
		action.jsClick(myElement);
		
//		action.executeJavaScript("var ele = arguments[0];ele.addEventListener('click', function() {ele.setAttribute('automationTrack','true');});",myElement);
//		Reporter.addStepLog("Clicked on Search Icon : "+myElement.getAttribute("automationTrack"));
		
		//action.highligthElement(myElement);
		action.pause(5000);
		
	}

	public void verifySeeAllResultsButton() throws InterruptedException {

		// WebElement ele = (WebElement) action.getElementByJavascript("SEE ALL RESULTS
		// Button");
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("SEE ALL RESULTS Button");
		Assert.assertTrue(action.isDisplayed(ele));
		action.highligthElement(ele);
		Reporter.addScreenCapture();
	}

	public void clickOnSeeAllResultsButton() throws InterruptedException {
		// WebElement ele = (WebElement) action.getElementByJavascript("SEE ALL RESULTS
		// Button");
		action.waitForPageLoad();
		action.waitForJSWebElement("Search Results List");
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("SEE ALL RESULTS Button");
		action.highligthElement(ele);
		// action.scrollToBottom();
		// action.moveToElement(ele);
		//action.doubleClick(ele);
		ele.click();
		Reporter.addScreenCapture();
	}

	public void verifyUserIsOnStyleSearchResultsTab() throws InterruptedException {
		/*
		 * String URL="https://pm.dev.bpsuspm.npd.bfsaws.net/pmui/#/all"; String
		 * currentURL=action.getCurrentURL(); Assert.assertEquals(URL,currentURL);
		 */
		WebElement ele = action.getElement("All_Results_Tab");
		action.highligthElement(ele);
		Thread.sleep(1000);
	}

	public void verifyUserIsOSeeAllResultsTab() throws InterruptedException {
		/*
		 * String URL="https://pm.dev.bpsuspm.npd.bfsaws.net/pmui/#/all"; String
		 * currentURL=action.getCurrentURL(); Assert.assertEquals(URL,currentURL);
		 */
		WebElement ele = action.getElement("All_Results_Tab");
		action.highligthElement(ele);
		Thread.sleep(5000);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyNoResultsFoundMessage() throws InterruptedException {
		WebElement ele = action.getElement("No Results Found Message");
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		action.isDisplayed(ele);
		Thread.sleep(1000);
	}

	public void clickOnStyleGridEllipsesIcon() throws InterruptedException {
		action.waitForPageLoad();
		WebElement ele1 = (WebElement) action.getElement("GridViewRecord");
		action.highligthElement(ele1);
		action.moveToElement(ele1);
		Thread.sleep(2000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Style Grid Ellipses Icon");
		action.highligthElement(ele2);// Style Grid Ellipses Icon
		Thread.sleep(2000);
		action.click(ele2);
		// actions.moveToElement(ele2).click().build().perform();
		Thread.sleep(2000);
	}

	public void clickOnHOApprovalGridEllipsesIcon() throws InterruptedException {
		action.waitForPageLoad();
		WebElement ele1 = (WebElement) action.getElement("GridViewRecord");
		action.highligthElement(ele1);
		action.moveToElement(ele1);
		Thread.sleep(10000);
		// action.fluentWaitWebElement("HO Approval ellipsis");

		WebElement ele2 = (WebElement) action
				.executeJavaScript("return document.querySelector(\"div[row-index ='0']\")");
		action.highligthElement(ele2);// Style Grid Ellipses Icon
		Thread.sleep(2000);
		action.click(ele2);
		// actions.moveToElement(ele2).click().build().perform();
		Thread.sleep(2000);
	}

	public void clickOnStyleGridEllipsesIconFilter() throws InterruptedException {

		action.waitForPageLoad();
		WebElement ele1 = (WebElement) action.getElement("GridViewRecord");
		action.highligthElement(ele1);
		action.moveToElement(ele1);
		Thread.sleep(2000);
		WebElement ele2 = (WebElement) action.getElement("GridViewRecordhover");
		action.highligthElement(ele2);
		action.moveToElement(ele2);
		Thread.sleep(2000);
		WebElement ele3 = (WebElement) action.getElementByJavascript("Style Grid Ellipses Icon");
		action.highligthElement(ele3);// Style Grid Ellipses Icon
		Thread.sleep(2000);
		action.click(ele3);
		// actions.moveToElement(ele2).click().build().perform();
		Thread.sleep(2000);
	}

	public void clickOnStyleEditButton() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Style_Edit Button");
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(1000);
	}

	public void mouseHoveOnSearchedRecordsOnGrid() {
		Action.pause(4000);
		// WebElement Element = (WebElement) action.getElement("GridViewRecord");
		WebElement Element = action.fluentWaitWebElement("GridViewRecord");
		action.highligthElement(Element);
		action.moveToElement(Element);
	}

	public void movetoFirstElementinFilteredrecords() {
		Action.pause(4000);
		// WebElement Element = (WebElement) action.getElement("GridViewRecord");
		WebElement Element = action.fluentWaitWebElement("First Record in Filtered Records");
		action.highligthElement(Element);
		action.moveToElement(Element);
	}

	public void clickOnEllipsesIcon() {
		action.waitForPageLoad();
		WebElement Element = (WebElement) action.fluentWaitForJSWebElement("Style Grid Ellipses Icon");
		action.moveToElement(Element);
		Element.click();
	}

	public void verifyOnViewDetailsLink() {
		Action.pause(2000);
		WebElement Element = (WebElement) action.getElementByJavascript("Style_Edit Button");
		Element.isDisplayed();
	}

	public void verifyContinueEditingButton() {

		WebElement Element = (WebElement) action.getElement("Continue Editing Button");
		action.highligthElement(Element);
		Element.isDisplayed();
		Reporter.addCompleteScreenCapture();
	}

	public void clickOnViewDetailsLink() {
		Action.pause(2000);
		WebElement Element = (WebElement) action.getElementByJavascript("Style_Edit Button");
		action.jsClick(Element);
	}

	public void verifyOnApproveRejectLink() {
		WebElement Element = (WebElement) action.fluentWaitForJSWebElement("Approve/Reject");
		Element.isDisplayed();
	}

	public void clickOnApproveRejectLink() {
		WebElement Element = (WebElement) action.fluentWaitForJSWebElement("Approve/Reject");
		action.jsClick(Element);
	}

	public void verifyUserIsOnViewStylePage() throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele = (WebElement) action.getElementByJavascript("View Style Header");
		action.highligthElement(ele);
		Assert.assertTrue(action.isDisplayed(ele));
		Reporter.addCompleteScreenCapture();
	}

	public void verifyUserIsOnViewDraftPage() throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele = (WebElement) action.getElementByJavascript("View Draft Header");
		action.highligthElement(ele);
		Assert.assertTrue(action.isDisplayed(ele));
		Reporter.addCompleteScreenCapture();
	}

	public void clickOnStyleViewEditButton() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("StyleView_Edit Button");
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(1000);
	}

	public void clickOnDraftViewEditButton() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("DraftView_Edit Button");
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(1000);
	}

	public void verifyStyleViewEditButton() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("StyleView_Edit Button");
		action.highligthElement(ele);
		Thread.sleep(1000);
	}

	public void verifyDraftViewEditButton() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("DraftView_Edit Button");
		action.highligthElement(ele);
		Thread.sleep(1000);
	}

	public void clickOnCreateNewStrategyButtonBU() {
		/*
		 * myElement = action.getElement("Create New Strategy Button for Branch User");
		 * myElement.click(); action.pause(1000);
		 */
		myElement = action.fluentWaitWebElement("Create New Strategy Button for Branch User");
		action.moveToElement(myElement);
		myElement.click();
	}

	public void verifyCountOfAllTabsPresentOnLandingPage(String value) {
		System.out.println("value= " + value);
		List<WebElement> li = WebDriverManager.getDriver().findElements(By.tagName(value));
		for (int i = 0; i < li.size(); i++) {
			System.out.println(li.get(i));
			action.highligthElement(li.get(i));
			action.pause(2000);
		}
		action.pause(2000);
		Reporter.addScreenCapture();
		Reporter.addStepLog("Total number of tabs: " + li.size() + "are present in landing page");
		System.out.println("Total number of tabs: " + li.size());
	}

	public void compareSearchResultsFormat(String strArg1) {
		WebElement ele = (WebElement) action.getElement("Results Header Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		Assert.assertTrue(ele.getText().contains(strArg1));
		Reporter.addStepLog("UI Element Value = " + ele.getText());
		Reporter.addStepLog("String Comparator Value = " + strArg1);
	}

	public void compareSearchResultsFormat2(String strArg1) {
		WebElement ele = (WebElement) action.getElement("Results Header Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		Assert.assertTrue(ele.getText().equals(strArg1));
		Reporter.addStepLog("UI Element Value = " + ele.getText());
		Reporter.addStepLog("String Comparator Value = " + strArg1);
	}

	public void compareCapsStyleLabel(String capsStyleLabel) throws InterruptedException {
		WebElement ele = (WebElement) action.getElement("Caps Style Label Format");
		System.out.println(ele.getText());
		action.moveToElement(ele);
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(capsStyleLabel);
		Assert.assertTrue(ele.getText().contains(capsStyleLabel));
	}

	public void compareCapsStyleLabel2(String capsStyleLabel2) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Caps Style Label Format2");
		System.out.println(ele.getText());
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(capsStyleLabel2);
		Assert.assertTrue(ele.getText().contains(capsStyleLabel2));
	}

	public void compareCapsStyleLabel3(String capsStyleLabel3) throws InterruptedException {
		WebElement ele = (WebElement) action.getElement("Caps Style Label Format3");
		System.out.println(ele.getText());
		action.moveToElement(ele);
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(capsStyleLabel3);
		Assert.assertTrue(ele.getText().contains(capsStyleLabel3));
	}

	public void isDeleteOptionHidden(String deleteOptionHidden) throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Style_Edit Button");
		System.out.println(ele.getText());
		Thread.sleep(1000);
		Reporter.addScreenCapture();
		action.highligthElement(ele);
		System.out.println(deleteOptionHidden);
		Assert.assertFalse(ele.getText().contains(deleteOptionHidden));
	}

	public void compareCustomLabel1(String customLabel1) throws InterruptedException {
		WebElement ele = action.getElement("Custom Label Format1");
		System.out.println(ele.getText());
		action.moveToElement(ele);
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(customLabel1);
		Assert.assertTrue(ele.getText().contains(customLabel1));
	}

	public void compareCustomLabel2(String customLabel2) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Custom Label Format2");
		System.out.println(ele.getText());
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(customLabel2);
		Assert.assertTrue(ele.getText().contains(customLabel2));
	}

	public void compareCustomLabel3(String customLabel3) throws InterruptedException {
		WebElement ele = action.getElement("Custom Label Format3");
		System.out.println(ele.getText());
		action.moveToElement(ele);
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println(customLabel3);
		Assert.assertTrue(ele.getText().contains(customLabel3));
	}

	public void isUserOnStyleResultsTab() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Style_Results_Tab");
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(3000);
	}

	public boolean isUserOnLandingPage() {
		action.pause(5000);
		myElement = action.waitForJSWebElement("Product Master");
		action.highligthElement(myElement);

		Reporter.addScreenCapture();
		if (myElement.isDisplayed()) {
			return true;
		}
		return false;
	}

	public void clickOnSMATab() {

		myElement = action.fluentWaitWebElement("SMA Tab");
		action.highligthElement(myElement);
		myElement.click();
		action.pause(1000);
	}

	public void clickOnTab(String Tab) {
		if (Tab.contains("RejectedStrategies")) {
			myElement = action.getElement("Right Tab Navigation Key");
			action.moveToElement(myElement);
			myElement.click();
		}
		myElement = action.getElementByFormatingXpath("Common Tab Xpath", Tab);
		action.moveToElement(myElement);
		myElement.click();
		action.pause(1000);
	}

	public void clickOnTab(String Tab, String typeofuser) {

		if (typeofuser.contains("HO")) {
			if (Tab.contains("RejectedStrategies") || Tab.contains("Draft") || Tab.contains("Presets")) {
				myElement = action.getElement("Right Tab Navigation Key");
				while (myElement.isDisplayed()) {
					action.highligthElement(myElement);
					action.click(myElement);
					action.pause(2000);

				}
			}
		}
		myElement = action.getElementByFormatingXpath("Common Tab Xpath", Tab);
		action.moveToElement(myElement);
		myElement.click();
		action.pause(1000);
	}

	public void clickOnHOApprovalTab() {
		// myElement = action.waitForJSWebElement("HOApproval Tab");
		myElement = action.fluentWaitWebElement("HOApproval Tab");
		myElement.click();
		action.pause(1000);
	}

	public void enterFilterValue(String FilterValue) {
//		myElement = action.waitForJSWebElement("FilterValue");
//		myElement.click();
//		myElement.clear();
//		myElement.sendKeys(FilterValue);
		loopCount = 0;
		do {
			myElement = (WebElement) action.waitForJSWebElement("FilterValue");
			myElement.click();
			myClear(action.waitForJSWebElement("FilterValue"));
			myElement.sendKeys(FilterValue);
		} while (!getFilterConditionValue().equals(FilterValue) && ++loopCount < 10);
		if (loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	private String getFilterConditionValue() {
		return action.getElement("FilterValue").getAttribute("value");
	}

	public Boolean clickOnSearchedRecord(String data) {
		
		if(action.isPresent("Search Record Dynamic")) {
			myElement = action.getElementByFormatingXpath("Search Record Dynamic", data);
			myElement.click();
			return true;
		}
		
		return false;
	}

	public void verifyComparativeBenchmarkSelection(String token) throws InterruptedException {
		WebElement ele = (WebElement) action.getElement("Caps Style Label Format");
		String selected_comparative_benchmark_type;
		System.out.println(ele.getText());
		action.moveToElement(ele);
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		WebElement ele1 = (WebElement) action.getElement("Caps Style Label Data1");
		System.out.println(ele1.getText());
		action.highligthElement(ele1);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		WebElement ele2 = (WebElement) action.getElement("Custom Label Format1");
		System.out.println(ele2.getText());
		action.moveToElement(ele2);
		action.scrollToBottom();
		action.highligthElement(ele2);
		Thread.sleep(2000);
		WebElement ele3 = (WebElement) action.getElement("Custom Style Label Data1");
		System.out.println(ele3.getText());
		action.highligthElement(ele3);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		if (ele1.getText().equals("—")) {
			selected_comparative_benchmark_type = "Custom";
			System.out.println("token is: " + token);
			System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
			if (ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token)) {
				Assert.assertTrue(
						ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token));
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Reporter.addStepLog(
						"UI and DB Values of selected_comparative_benchmark_type on Style View Page matches");

			} else {
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Assert.assertFalse(ele1.getText() == token,
						"UI and DB Values of selected_comparative_benchmark_type on Style View Page doesn't match");
			}

		} else {
			selected_comparative_benchmark_type = "Default";
			System.out.println(selected_comparative_benchmark_type);
			if (ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token)) {
				Assert.assertTrue(
						ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token));
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Reporter.addStepLog(
						"UI and DB Values of selected_comparative_benchmark_type on Style View Page matches");
			} else {
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Assert.assertFalse(ele1.getText() == token,
						"UI and DB Values of selected_comparative_benchmark_type on Style View Page doesn't match");
			}
		}
	}

	public void verifyComparativeBenchmarkSelection2(String token) throws InterruptedException {
		WebElement ele = (WebElement) action.getElement("Caps Style Label Format3");
		String selected_comparative_benchmark_type;
		System.out.println(ele.getText());
		action.moveToElement(ele);
		action.scrollToBottom();
		action.highligthElement(ele);
		Thread.sleep(2000);
		WebElement ele1 = (WebElement) action.getElement("Caps Style Label Data3");
		System.out.println(ele1.getText());
		action.highligthElement(ele1);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		WebElement ele2 = (WebElement) action.getElement("Custom Label Format3");
		System.out.println(ele2.getText());
		action.moveToElement(ele2);
		action.scrollToBottom();
		action.highligthElement(ele2);
		Thread.sleep(2000);
		WebElement ele3 = (WebElement) action.getElement("Custom Style Label Data3");
		System.out.println(ele3.getText());
		action.highligthElement(ele3);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		if (ele1.getText().equals("—")) {
			selected_comparative_benchmark_type = "Custom";
			System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
			if (ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token)) {
				Assert.assertTrue(
						ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token));
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Reporter.addStepLog(
						"UI and DB Values of selected_comparative_benchmark_type on Style Review Page matches");

			} else {
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Assert.assertFalse(ele1.getText() == token,
						"UI and DB Values of selected_comparative_benchmark_type on Style Review Page doesn't match");
			}

		} else {
			selected_comparative_benchmark_type = "Default";
			System.out.println(selected_comparative_benchmark_type);
			if (ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token)) {
				Assert.assertTrue(
						ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token));
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Reporter.addStepLog(
						"UI and DB Values of selected_comparative_benchmark_type on Style Review Page matches");
			} else {
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Assert.assertFalse(ele1.getText() == token,
						"UI and DB Values of selected_comparative_benchmark_type on Style Review Page doesn't match");
			}
		}
	}

	public void collapseallpanelsonSeeAllResultsTab() throws InterruptedException {
		int i = 2;
		List<WebElement> li = WebDriverManager.getDriver().findElements(By.tagName("brml-expansion-panel"));
		System.out.println(li.size());
		for (i = 2; i <= li.size(); i++) {
			WebElement ele = action.getElementByFormatingXpath("Brml_accordion_expansion_panel", i);
			action.highligthElement(ele);
			ele.click();
			Thread.sleep(5000);
		}
		Reporter.addCompleteScreenCapture();
	}

	public void verifyLatestMaximum5records() throws InterruptedException {
		int i = 1;
		for (i = 1; i <= 5; i++) {
			WebElement ele = action.getElementByFormatingXpath("Latest Maximum 5 Records", i);
			System.out.println(ele);
			action.highligthElement(ele);
			Thread.sleep(2000);
		}
		Reporter.addCompleteScreenCapture();
		Reporter.addEntireScreenCaptured();
	}

	public void clickOnSearchedResultNavigatetoDetailsPage() throws InterruptedException {
		WebElement ele = (WebElement) action.getElement("Search Result Navigate to Details Page");
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(1000);
		action.click(ele);
	}

	public void compareStyleGlobalSearchResultsFormat(String strArg1, String strArg2, String strArg3) {
		WebElement ele = (WebElement) action.getElement("Global Search Results Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		System.out.println(ele.getText().substring(0, 11));
		System.out.println(ele.getText().substring(11, 13));
		System.out.println(ele.getText().substring(14, 37));
		Assert.assertTrue(ele.getText().substring(0, 11).contains(strArg1));
		Assert.assertTrue(ele.getText().substring(11, 13).contains(strArg2));
		Assert.assertTrue(ele.getText().substring(14, 37).contains(strArg3));
	}

	public void compareManagerGlobalSearchResultsFormat(String strArg1, String strArg2, String strArg3) {
		WebElement ele = (WebElement) action.getElement("Global Search Results Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		System.out.println(ele.getText().substring(0, 13));
		System.out.println(ele.getText().substring(13, 15));
		System.out.println(ele.getText().substring(16, 30));
		Assert.assertTrue(ele.getText().substring(0, 13).contains(strArg1));
		Assert.assertTrue(ele.getText().substring(13, 15).contains(strArg2));
		Assert.assertTrue(ele.getText().substring(16, 30).contains(strArg3));
	}

	public void compareBenchmarkGlobalSearchResultsFormat(String strArg1, String strArg2, String strArg3) {
		WebElement ele = (WebElement) action.getElement("Global Search Results Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		System.out.println(ele.getText().substring(0, 24));
		System.out.println(ele.getText().substring(24, 26));
		System.out.println(ele.getText().substring(27, 58));
		Assert.assertTrue(ele.getText().substring(0, 24).contains(strArg1));
		Assert.assertTrue(ele.getText().substring(24, 26).contains(strArg2));
		Assert.assertTrue(ele.getText().substring(27, 58).contains(strArg3));
	}

	public void compareProgramGlobalSearchResultsFormat(String strArg1) {
		WebElement ele = (WebElement) action.getElement("Global Search Results Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		System.out.println(ele.getText().substring(0, 16));
		Assert.assertTrue(ele.getText().substring(0, 16).contains(strArg1));
	}

	public void compareFAGlobalSearchResultsFormat(String strArg1, String strArg2, String strArg3) {
		WebElement ele = (WebElement) action.getElement("Global Search Results Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		System.out.println(ele.getText().substring(0, 28));
		System.out.println(ele.getText().substring(28, 31));
		System.out.println(ele.getText().substring(31, 63));
		Assert.assertTrue(ele.getText().substring(0, 28).contains(strArg1));
		Assert.assertTrue(ele.getText().substring(28, 31).contains(strArg2));
		Assert.assertTrue(ele.getText().substring(31, 63).contains(strArg3));
	}

	public void clickOnDraftsTab() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("Drafts Tab");
		// action.highligthElement(ele);
		WebElement ele1 = (WebElement) action.fluentWaitForJSWebElement("Drafts Tab Slide Icon");
		action.highligthElement(ele1);
		action.click(ele1);
		action.click(ele1);
		Reporter.addScreenCapture();
		ele = (WebElement) action.fluentWaitForJSWebElement("Drafts Tab");
		action.doubleClick(ele);
		Thread.sleep(1000);
	}

	public void clickOnDraftsTab2() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("Drafts Tab");
		// action.highligthElement(ele);
		WebElement ele1 = (WebElement) action.fluentWaitForJSWebElement("Drafts Tab Slide Icon");
		action.highligthElement(ele1);
		action.click(ele1);
		action.click(ele1);
		Reporter.addScreenCapture();
		ele = (WebElement) action.fluentWaitForJSWebElement("Drafts Tab");
		action.doubleClick(ele);
		Thread.sleep(1000);
		action.doubleClick(ele);
	}

	public void clickOnStyleNameFilterIcon() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("Style Name Filter Icon");
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(2000);
		action.click(ele);
	}

	public void provideInputForFilterConditions(String draftName) throws InterruptedException {
		WebElement ele = action.getElement("Filter Icon");
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(2000);
		action.click(ele);
		WebElement ele1 = action.getElement("Equal Filter Option");
		action.highligthElement(ele1);
		Reporter.addScreenCapture();
		Thread.sleep(2000);
		action.click(ele1);
		WebElement ele2 = action.getElement("Equal Filter Input Text");
		action.highligthElement(ele2);
		Reporter.addScreenCapture();
		Thread.sleep(2000);
		action.sendKeys(ele2, draftName);
		Thread.sleep(2000);
	}

	public void clickOnApplyButton() throws InterruptedException {
		WebElement ele = action.getElement("Apply Button");
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(2000);
		action.click(ele);
	}

	public void comparePMPStrategyGlobalSearchResultsFormat(String strArg1, String strArg2, String strArg3) {
		WebElement ele = (WebElement) action.getElement("Global Search Results Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		System.out.println(ele.getText().substring(0, 15));
		System.out.println(ele.getText().substring(15, 17));
		System.out.println(ele.getText().substring(17, 36));
		Assert.assertTrue(ele.getText().substring(0, 15).contains(strArg1));
		Assert.assertTrue(ele.getText().substring(15, 17).contains(strArg2));
		Assert.assertTrue(ele.getText().substring(17, 36).contains(strArg3));
	}

	public void compareSMAStrategyGlobalSearchResultsFormat(String strArg1, String strArg2, String strArg3) {
		WebElement ele = (WebElement) action.getElement("Global Search Results Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		System.out.println(strArg1);
		System.out.println(ele.getText().substring(0, 15));
		System.out.println(ele.getText().substring(15, 17));
		System.out.println(ele.getText().substring(17, 36));
		Assert.assertTrue(ele.getText().substring(0, 15).contains(strArg1));
		Assert.assertTrue(ele.getText().substring(15, 17).contains(strArg2));
		Assert.assertTrue(ele.getText().substring(17, 36).contains(strArg3));
	}

	public void clickOnStyleDeleteButton() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Style Draft Delete Button");
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Thread.sleep(2000);
		action.click(ele);
		Thread.sleep(2000);
	}

	public void verifyNoRowsToShowMessage() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("No Rows To Show Message");
		action.highligthElement(ele);
		String actlmsg = ele.getText();
		System.out.println("No Row Msg = " + actlmsg);
		Reporter.addStepLog(actlmsg);
		Reporter.addScreenCapture();
		Thread.sleep(2000);
	}

	public void verifyBenchmarkHeaderOnStyleDraftViewPage() throws InterruptedException {
		WebElement ele = action.getElement("Benchmark Header On Style Draft View Page");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		Reporter.addScreenCapture();
		Reporter.addCompleteScreenCapture();
		Thread.sleep(2000);
	}

	public void clickingonHOApproval() throws InterruptedException {
		// Thread.sleep(5000);
		// action.scrollToElement(myElement);
//    	
		// Thread.sleep(5000);
//    	
		WebElement ele = (WebElement) action.getElementByJavascript("Approve_Reject_Ho");
		String str = ele.getText();
		System.out.println("The text is " + str);
		// myElement = ((Object) ele).executeJavascript("Approve_reject_Ho");
		// action.scrollToElement(ele);
		action.highligthElement(ele);
		action.click(ele);
		// Thread.sleep(5000);

	}

	public void highlightingreason() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Highlight the reason");
		action.scrollToElement(ele);
		action.highligthElement(ele);

	}

	public void rejectingagivenstrategy() throws InterruptedException {
		Thread.sleep(4000);

		WebElement ele = (WebElement) action.getElementByJavascript("Reject button");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		action.click(ele);
		Reporter.addScreenCapture();
		Reporter.addCompleteScreenCapture();
		Thread.sleep(5000);
	}

	public void approvingstrategy() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Approve Button");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		action.click(ele);
		Reporter.addScreenCapture();
		Reporter.addCompleteScreenCapture();
		Thread.sleep(7000);
	}

	public void BUusernewstrategycreate() throws InterruptedException {
		Thread.sleep(2000);
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("BU_create_strategy");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(2000);
	}

	public void clickOnStyleViewCancelButton() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("Style_View Cancel Button");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}

	public void clickOnStyleTab() throws InterruptedException {
		WebElement ele = action.fluentWaitWebElement("Style Tab");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(2000);
	}

	public void clickOnPMPTab() throws InterruptedException {
		WebElement ele = action.fluentWaitWebElement("PMP Tab");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(2000);
	}

	public void clickOnBenchmarkTab() throws InterruptedException {
		WebElement ele = action.fluentWaitWebElement("Benchmark Tab");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(2000);
	}

	public void verifyUserIsOnViewBenchmarkPage() throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele = action.getElement("View Benchmark Header");
		action.highligthElement(ele);
		Assert.assertTrue(action.isDisplayed(ele));
		Reporter.addCompleteScreenCapture();
	}

	public void verifyUserIsOnViewPMPPage() throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele = action.getElement("View PMP Header");
		action.highligthElement(ele);
		Assert.assertTrue(action.isDisplayed(ele));
		Reporter.addCompleteScreenCapture();
	}

	public void clickOnFATab() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("FA Tab");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}

	public void clickOnManagerTab() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Manager Tab");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}

	public void verifyUserIsOnViewFAPage() throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele = action.getElement("View FA Header");
		action.highligthElement(ele);
		Assert.assertTrue(action.isDisplayed(ele));
		Reporter.addCompleteScreenCapture();
	}

	public void clickOnDisplayedFirstSearchResult() throws InterruptedException {
		WebElement ele = action.getElement("Displayed First Search Result");
		// Reporter.addCompleteScreenCapture();
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(1000);
		action.click(ele);
		Thread.sleep(1000);
	}

	public void verifyUserIsOnViewManagersPage() throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele = action.getElement("View Manager Header");
		action.highligthElement(ele);
		Assert.assertTrue(action.isDisplayed(ele));
		Reporter.addCompleteScreenCapture();
		Thread.sleep(1000);
	}

	public void highlightSearchResultsFormat() {
		WebElement ele = (WebElement) action.getElement("Results Header Format");
		System.out.println(ele.getText());
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyStyleTabHeaders(String key, String string1) {
		WebElement ele = action.getElementByFormatingXpath("Style Tab HeaderAttribute Value", string1);
		action.highligthElement(ele);
	}

	public void verifyPMPTabHeaders(String key, String string1) {
		action.waitForPageLoad();
		WebElement ele = action.getElementByFormatingXpath("PMP Tab HeaderAttribute Value", string1);
		action.highligthElement(ele);
	}

	public void verifySMATabHeaders(String key, String string1) {
		WebElement ele = action.getElementByFormatingXpath("SMA Tab HeaderAttribute Value", string1);
		action.highligthElement(ele);
	}

	public void verifyManagerTabHeaders(String key, String string1) {
		WebElement ele = action.getElementByFormatingXpath("Manager Tab HeaderAttribute Value", string1);
		action.highligthElement(ele);
	}

	public void verifyUnbundledNodeIdDisplayedInDescOrder() {
		WebElement ele = (WebElement) action.getElementByJavascript("Verify UnbundledNodeId DisplayedIn DescOrder");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyCustomBenchmarksDisplayedInDescOrder() {
		WebElement ele = (WebElement) action.getElementByJavascript("Verify CustomBenchmarks DisplayedIn DescOrder");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyFAStatusonViewFADetailsPage() {
		WebElement ele = (WebElement) action.getElementByJavascript("Verify FAStatus on ViewFA DetailsPage");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
	}

	public boolean isCreateNewStrategyButtonVisible() {
		WebElement dropelement = (WebElement) action.fluentWaitWebElement("Create New Strategy Button for Branch User");
		action.highligthElement(dropelement);
		return action.isDisplayed(dropelement);
	}

	public void hoverOnUploadButton() {

		myElement = (WebElement) action.fluentWaitForJSWebElement("Upload Button");
		action.moveToElement(myElement);
		action.pause(2000);

	}

	public boolean isUserAbleToSeeUploadText() {
		myElement = action.waitForJSWebElement("Upload Text");
		System.out.println("get text= " + myElement.getText());
		if (myElement.getText().equals("Select to Upload the report"))
			return true;
		return false;
	}

	public void clickOnUploadButton() {

		myElement = (WebElement) action.fluentWaitForJSWebElement("Upload Button");
		action.click(myElement);

	}

	public void verifyEnterFinancialAdvisorDetailsheader() throws InterruptedException {
		WebElement element = (WebElement) action.getElementByJavascript("Enter FinancialAdvisor Details header");
		action.highligthElement(element);
		Thread.sleep(2000);
		Reporter.addCompleteScreenCapture();
	}

	public void isManagerOptionHidden(String managerOptionHidden) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Manager Option Hidden");
		System.out.println(ele.getText());
		Thread.sleep(1000);
		Reporter.addScreenCapture();
		action.highligthElement(ele);
		System.out.println(managerOptionHidden);
		Assert.assertFalse(ele.getText().contains(managerOptionHidden));
	}

	public void isContinueEditingButtonHidden() {
		List<WebElement> ele = action.getElements("Continue Editing Button");
		if (ele.size() > 0) {
			Assert.fail("Continue Editing Button is present on UI");
		} else {
			Reporter.addStepLog("Continue Editing Button is not present in given page");
		}
		Reporter.addCompleteScreenCapture();
	}

	public void export() throws InterruptedException {
		Thread.sleep(4000);
		WebElement ele = (WebElement) action.getElementByJavascript("Download");
		Thread.sleep(4000);
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(8000);

	}

	public Integer getSmaCount() {
		myElement = action.fluentWaitWebElement("SMA Tab");
		String uiText = myElement.getText();
		System.out.println(uiText);
		System.out.println(uiText.substring(uiText.indexOf('(') + 1, uiText.length() - 1));
		return Integer.parseInt(uiText.substring(uiText.indexOf('(') + 1, uiText.length() - 1));
	}

	public void clickOnSMAExport() {
		Action.pause(2000);
		myElement = action.fluentWaitWebElement("SMA Export Button");
		action.moveToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Action.pause(20000);
	}

	public boolean isSortIconDisplayedInUIforEntity(String entity) {

		myElement = action.fluentWaitWebElementByFormatingXpath("Common Sort Button based on text", entity);
		return action.isDisplayed(myElement);
	}

	public void clickOnSortIconForEntity(String entity) {
		myElement = action.fluentWaitWebElementByFormatingXpath("Common Sort Button based on text", entity);
		myElement.click();

	}

	public void verifyTheSearchedResultInAllTab() {
		Action.pause(2000);
		myElement = (WebElement) action.fluentWaitForJSWebElement("All Tab");
		action.highligthElement(myElement);
		myElement.isDisplayed();
	}
}
