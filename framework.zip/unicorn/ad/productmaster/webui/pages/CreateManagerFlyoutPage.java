package qa.unicorn.ad.productmaster.webui.pages;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
public class CreateManagerFlyoutPage {
	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public  CreateManagerFlyoutPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	public void clickOncontinuebutton() throws Throwable{
		myElement = action.getElement("Continue Button");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public void verifysaveasdraftbuttonincreatemanagerpage() {
		myElement = action.getElement("Save as draft button");
		action.highligthElement(myElement);
		Assert.assertFalse(action.isSelected(myElement));
		Reporter.addScreenCapture();
	}
	public void verifyAttribute(String expectedValue, WebElement element, String attribute) {
		Assert.assertEquals(getAttribute(element, attribute), expectedValue);

	}

	public String getAttribute(WebElement element, String attribute) {
		return element.getAttribute(attribute);
	}
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	public void clickOnCancelButton() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement) action.getElement("Cancel Button"));
		action.captureEntireScreen();
		action.click((WebElement) action.getElement("Cancel Button"));
	}
}
