package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class UpdateFAApprovalPage {
	
	Action action;
	public UpdateFAApprovalPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element,Highlight;
	int loopCount;
	
	public boolean isUserOnApprovalPage() {
		Element = action.waitForJSWebElement("Header");
		action.highligthElement(Element);
		if (Element.getText().equals("Approval")) {
			return true;
		}
		return false;
	}
	
	public void verifyElementsOnApprovalDetailsPage(List<String> entity) {
		/*
		Element = element;
		action.scrollToElement(element);
		action.highligthElement(Element);
		Assert.assertTrue(action.isDisplayed(Element));
		*/
		for (String Elements : entity) {

			Element = action.getElementByFormatingXpath("Common Page Entity Header", Elements);
			action.highligthElement(Element);
			action.scrollToElement(Element);
			Assert.assertTrue(action.isDisplayed(Element));
		}
	}
	
	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void clickonnextbutton() {
		
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
		//action.getElement("NEXT").click();
	}
	
	public void enterHomeOfficeComments() throws InterruptedException {

		Thread.sleep(1000);
		WebElement ele = (WebElement) action.getElementByJavascript("txtHomeOfficeCommentsFAUpdate");
		action.highligthElement(ele);
		action.clear(ele);
		action.sendKeys(ele, "Test");
		Thread.sleep(100);
	}
	
	public void enterApproverName() throws InterruptedException {

		Thread.sleep(500);
		action.clear(Element = (WebElement) action.getElementByJavascript("txtapprovernameFAUpdate"));
		WebElement ele = (WebElement) action.getElementByJavascript("txtapprovernameFAUpdate");
		action.clear(ele);
		action.highligthElement(ele);
		action.sendKeys(ele, "approvarenamehereastest");
		Thread.sleep(100);
	}
	
	public void selectStatusDate() throws InterruptedException {
		Thread.sleep(500);
		action.click((WebElement) action.getElementByJavascript("selectStatusDateFAUpdate"));
		action.click((WebElement) action.getElementByJavascript("selectStatusDateFAUpdatevalue"));
	}
	
	public void selectFollowUpDate() throws InterruptedException {
		Thread.sleep(500);
		action.click((WebElement) action.getElementByJavascript("selectFollowUpDateFAUpdate"));
		action.click((WebElement) action.getElementByJavascript("selectFollowUpDatevalue"));

	}

	public String getExceptionorConditionApprovalValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "exceptionalApproval");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		switch (Element.getAttribute("value")) {
		case "true":
			return "t";
		case "false":
			return "f";
		default:
			break;
		}
		return "unexpected Value";
	}

	public String getExpirationDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "exceptionalApprovalExpirationDate");
		if(Element.getAttribute("date").isEmpty())
			return "isEmpty";
		return Element.getAttribute("date");
	}

	public String getHomeOfficeCommentsValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "homeOfficeComments");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getApproverNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "approver");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getFAStatusValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "status");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public String getStatusDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "nominationStatusDate");
		if(Element.getAttribute("date").isEmpty())
			return "isEmpty";
		return Element.getAttribute("date");
	}

	public String getFollowUpDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "followUpDate");
		if(Element.getAttribute("date").isEmpty())
			return "isEmpty";
		return Element.getAttribute("date");
	}

	public String getFollowUpValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "followUpNotes");
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		return Element.getAttribute("value");
	}

	public void enterApproverName(String approverName) {
		if (approverName.length() > 0) {
			Reporter.addStepLog("Approver Name field in UI is a greayed out field and is not editable");
		}
		
	}

	public void enterFaStatus(String faStatus) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Status");
		action.click(Element);
		Highlight = action.getElementByFormatingXpath("Common Dropdown Element", "status");
		Highlight = Highlight.findElement(By.linkText(faStatus));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
	}

	public void enterStatusDate(String statusDate) throws InterruptedException {

		String ID = "nominationStatusDate";
		enterDate(statusDate, ID);
		
	}

	private void enterDate(String excelDate, String ID) {
		
		Element = action.getElementByFormatingXpath("Common date Field Input", ID);
		action.moveToElement(Element);
		Element.click();
		
		//Below Code to prepare for Selecting Year
		String[] date = excelDate.split("/");
		date[0] = getMonthname(date[0]);
		WebElement monthYear = action.getElementByFormatingXpath("dateFrom_monthYear", ID);
		String monthYearValue = monthYear.getText();
		String[] mYValue = monthYearValue.split(" ");
		WebElement nextClick, previousClick;
		String month = mYValue[0];
		
		//clicking twice to select Year
		action.jsClick(monthYear);
		action.jsClick(monthYear);
		action.pause(500);
		monthYearValue = monthYear.getText();
		mYValue = monthYearValue.split(" - ");
		if(Integer.parseInt(mYValue[1]) > Integer.parseInt(date[2])) {
			//while()
			while(!inRange(Integer.parseInt(mYValue[0]),Integer.parseInt(mYValue[1]),Integer.parseInt(date[2]) )) {
				previousClick = action.getElementByFormatingXpath("dateFrom_previousButton", ID);
				action.jsClick(previousClick);
				monthYearValue = monthYear.getText();
				mYValue = monthYearValue.split(" - ");
				action.pause(500);
				
			}
		}else if(Integer.parseInt(mYValue[1]) < Integer.parseInt(date[2])) {
			System.out.println("Inside second if");
			//while()
			System.out.println(inRange(Integer.parseInt(mYValue[0]),Integer.parseInt(mYValue[1]),Integer.parseInt(date[2])));
			while(!inRange(Integer.parseInt(mYValue[0]),Integer.parseInt(mYValue[1]),Integer.parseInt(date[2]))) {
				nextClick = action.getElementByFormatingXpath("dateFrom_nextButton", ID);
				action.jsClick(nextClick);
				monthYearValue = monthYear.getText();
				mYValue = monthYearValue.split(" - ");
				action.pause(500);
			}
		}
		
		//Select Year
			selectYear(date[2], ID);
		
		//Select Month
			selectMonth(date[0].substring(0, 3), ID);
		
		//Select Date
			selectDate(date[1], ID);
		
	}

	private void selectDate(String date, String ID) {
		
		if(date.substring(0, 1).contentEquals("0")) {
			date = date.substring(1);
		}
		Element = (WebElement) action.getElementByFormatingXpath("dateFrom_dates", ID);
		
		List<WebElement> dateValues = Element.findElements(By.xpath("./*"));
		
		for(int i=0;i<dateValues.size();i++) {
			if(dateValues.get(i).getClass().toString().contains("pmu-not-in-month")) {
				
			}else {
				if(dateValues.get(i).getText().contentEquals(date)) {
					action.moveToElement(dateValues.get(i));
					action.jsClick(dateValues.get(i));
					action.pause(1000);
					break;
				}
			}
		
		
		}
		
	}

	private void selectMonth(String month, String ID) {
		Element = (WebElement) action.getElementByFormatingXpath("date_months", ID);
		
		List<WebElement> dateValues = Element.findElements(By.xpath("./*"));
		
		for(int i=0;i<dateValues.size();i++) {
			
				if(dateValues.get(i).getText().contentEquals(month)) {
					action.moveToElement(dateValues.get(i));
					action.jsClick(dateValues.get(i));
					action.pause(1000);
					break;
				}
			
		
		
		}
		
	}

	private void selectYear(String year, String ID) {
		Element = (WebElement) action.getElementByFormatingXpath("date_years", ID);
		
		List<WebElement> dateValues = Element.findElements(By.xpath("./*"));
		
		for(int i=0;i<dateValues.size();i++) {
			
				if(dateValues.get(i).getText().contentEquals(year)) {
					action.moveToElement(dateValues.get(i));
					action.jsClick(dateValues.get(i));
					break;
				}
			
		
		
		}
		
	}

	private boolean inRange(int low, int high, int x) {
		
		return (low <= x && high >=x);
	}

	private String getMonthname(String data) {
		String month = "";
		switch (data) {
			case "01":
				month = "January"; 
				break;
			case "02":
				month = "February";
				break;
			case "03":
				month = "March";
				break;
			case "04":
				month = "April";
				break;
			case "05":
				month = "May";
				break;
			case "06":
				month = "June";
				break;
			case "07":
				month = "July";
				break;
			case "08":
				month = "August";
				break;
			case "09":
				month = "September";
				break;
			case "10":
				month = "October";
				break;
			case "11":
				month = "November";
				break;
			case "12":
				month = "December";
				break;
			default:
				break;
				
		}
		return month;
	}

	public void enterExceptionOrConditionalApproval(String exceptionOrConditionalApproval) {
		switch (exceptionOrConditionalApproval.toLowerCase().trim()) {
		case "yes":
			Element = action.getElementByFormatingXpath("Exception or Conditioanl Approval", "Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Exception or Conditioanl Approval", "No");
			Element.click();
			break;
		default:
			Reporter.addStepLog("Value for Exception or Conditioanl Approval field in UI is not valid and ignoring the same");
			break;
		}
		
	}

	public void enterExpirationDate(String expirationDate, String exceptionOrConditionalApproval) throws InterruptedException {
		String ID = "exceptionalApprovalExpirationDate";
		
		if(exceptionOrConditionalApproval.trim().toLowerCase().equals("yes")) {
			
			enterDate(expirationDate, ID);
		}else if(exceptionOrConditionalApproval.isEmpty()) {
			
			if(getExceptionorConditionApprovalValue().trim().toLowerCase().equals("yes"))
			{
				enterDate(expirationDate, ID);
			}
		}
		
	}

	public void enterFollowUpDate(String followUpDate) throws InterruptedException {
		
		String ID = "followUpDate";
		enterDate(followUpDate, ID);
		
	}

	public void enterHomeOfficeComments(String homeOfficeComments, String exceptionOrConditionalApproval) {
		
		if(exceptionOrConditionalApproval.trim().toLowerCase().equals("yes")) {
			
			Element = action.getElementByFormatingXpath("Common Text Area Input", "homeOfficeComments"); 
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, homeOfficeComments);
			} while (!(getHomeOfficeCommentsValue().equals(homeOfficeComments)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
			
		}else if(exceptionOrConditionalApproval.isEmpty()) {
			
			if(getExceptionorConditionApprovalValue().trim().toLowerCase().equals("yes"))
			{
				Element = action.getElementByFormatingXpath("Common Text Area Input", "homeOfficeComments"); 
				loopCount = 0;
				do {
					Element.click();
					myClear(Element);
					action.doubleClick(Element);
					action.sendKeys(Element, homeOfficeComments);
				} while (!(getHomeOfficeCommentsValue().equals(homeOfficeComments)) && ++loopCount < 10);
				if(loopCount >= 10)
					Assert.fail("User is not able to input Text into Text Field");
			}
		}
		
	}

	public void enterFollowUp(String followUp) {
		Element = action.getElementByFormatingXpath("Common Text Area Input", "followUpNotes");
		action.highligthElement(Element);
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, followUp);
		} while (!(getFollowUpValue().equals(followUp)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void clickOnPreviousButton() {
		
		Element = action.fluentWaitWebElement("PREVIOUS");
		Element.click();
		
	}
	
	

}
