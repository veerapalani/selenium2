package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;

public class GlobalSearchPage {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_GlobalSearchPage"));
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	WebElement mytext;
	WebElement myElement;
	public void enter_token_in_searchbox(String usertoken) {
		
action.sendKeys(action.getElement("Global SearchTextbox"), usertoken);
}
	
public void click_on_Search_icon() {
		
		action.click(action.getElement("Global Search Icon"));
	}

public String getTheErrorMessage() {
	return action.getText(action.getElement("Global Search less input char error msg"));
}

public String getTheErrorMessage_Nosearch() {
	return action.getText(action.getElement("Global Search invalid char error msg"));
}

public List<WebElement> getElements(String key){
	listOfElements = action.getElements(key);
	return listOfElements;
	
}
public String getTheErrorMessage_splchar() {
	return action.getText(action.getElement("Global Search invalid char error msg"));
}

public String getThetextMessage() {
	return action.getText(action.getElement("Showing text"));
	
	
}
public List<WebElement> getElements_text(String textkey){
	listOfElements = action.getElements(textkey);
	return listOfElements;
	//RestApiHelperMethods.verifyEquals(Integer.parseInt(rowCount), listOfElements.size());
	
}

public String getThetextMessage_Showingtext() {
	return action.getText(action.getElement("Showing x results"));
	
	
}

public String getTheErrorMessage_splchar_limited() {
	return action.getText(action.getElement("Global Search limited spl char error msg"));
}
public void verifyInsideElement(WebElement parentElement, String key) {
	
	myElement = action.getElementFromParentElement(parentElement, key);
	Assert.assertTrue(action.isDisplayed(myElement));
}

public String Search_text() {
	//WaitManager.waitTillPageRefresh(action.getElement("Show text"));
	
	return action.getText(action.getElement("Show text"));
	
	
}
public List<WebElement> getElements1(String key){
	listOfElements = action.getElements(key);
	return listOfElements;
	
}
public void verifyElement(String elementKey) {
	myElement = action.getElement(elementKey);
	Assert.assertTrue(action.isDisplayed(myElement));
	}
public void verifyHeaderText(String Key) {
	mytext = action.getElement(Key);
	
	System.out.println(mytext.getText() +"richi");
	
	//Assert.assertEquals(Key, mytext.getText());
	Reporter.addStepLog("The header "+Key+" is present");
}
public void click_on_Search_icon_() {
	
	action.click(action.getElement("Global Search Icon"));
	action.moveToElement(action.getElement("Global Search Icon"));
	//WaitManager.elementToBeClickable(action.getElement("Show text"));
}

public void verifyTextInListOfElements(String text, List<WebElement> list1) {
	
	for (int i=0;i< list1.size();i++) {
		list.add(list1.get(i).getText());
	}
	Assert.assertTrue(list.contains(text));
}

public void verifyColor(WebElement element, String expectedColorCode ) {
	
	RestApiHelperMethods.verifyEquals(expectedColorCode, giveColorHexCode(element,"color"));
}
public String giveColorHexCode(WebElement element,String attribute) {
	String colorCode = element.getCssValue(attribute);
	return colorCode=Color.fromString(colorCode).asHex();
	
	
}
public String getHeaderText() {

	String header = action.getElement("Key").getText();
	return header;
}
public void click_on_Search_icon1() {
	//action.moveToElement(action.getElement("Global Search Icon"));
	
	action.click(action.getElement("Global Search Icon"));
}

}