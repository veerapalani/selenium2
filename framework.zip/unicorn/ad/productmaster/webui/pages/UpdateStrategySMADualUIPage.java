package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.ibm.db2.jcc.a.i;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class UpdateStrategySMADualUIPage 
{
	
	
	Action action;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	XSSFSheet inputSheet;
	int rowIndex, cellIndex;
	String inputSheetName = "InputSheet";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategySMADual.xlsx";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	List<WebElement> myElements;
	CreateSMASingleAccessStrategyBenchmarkPage bm = new CreateSMASingleAccessStrategyBenchmarkPage("AD_PM_CreateSMASingleAccessStrategyBenchmarkPage");
	WebElement Element;
	
	public UpdateStrategySMADualUIPage()
	{
		action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategySMADualUIPage"));
	}

	public String getCurrentTimeStamp()
	{
		Long time = Calendar.getInstance().getTimeInMillis();
		return time.toString();
	}

	public void verifyTextInListOfElements(String text, List<WebElement> list1) 
	{
		for(int i = 0; i < list1.size(); i++)
		{
			list.add(list1.get(i).getText());
		}
		
		for(int i = 0; i < list.size(); i++)
		{
			if(list.get(i).contains(text))
			{
				action.highligthElement(list1.get(i));
				Assert.assertTrue(true);
				return;
			}
		}
	}

	public WebElement findElementByDynamicXpath(String xpath) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		listOfElements = element.getElements("xpath", xpath);
		return listOfElements;
	}
	
	public WebElement findElementByCssSelector(String css) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("cssselector", css);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public List<WebElement> getDynamicElementsFromShadowRoot(String javaScript) 
	{
		return listOfElements = (List<WebElement>)action.executeJavaScript(javaScript);
	}
	
	public WebElement waitForWebElement(String xpath) 
	{

		int timeLaps = 0;
		String status = "FAIL";
		WebElement jsElement = null;
		while (status.equals("FAIL") && timeLaps < GlobalVariables.waitTime) {
			try {

				//jsElement = (WebElement) getElementByJavascript(dbkey);
				//jsElement = (WebElement) getElement(dbkey);
				jsElement = findElementByDynamicXpath(xpath);

				if (jsElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Exception e) {

				status = "FAIL";

			}

			Action.pause(2000);

			++timeLaps;

		}

		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);

		return jsElement;

	}
	
	
	public final Object executeJavaScript(String javaScript)
	{
		waitForJavaScript(javaScript);
		
		Object scriptReturn = null;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try 
		{
			scriptReturn = js.executeScript(javaScript);
			status = "PASS";

		} 
		catch (Exception e)
		{
			ExceptionHandler.handleException(e);
		} 
		finally 
		{
			Report.printOperation("Execute Javascript");
			Report.printValue(javaScript);
			Report.printStatus(status);
		}

		return scriptReturn;
	}
	
	public WebElement waitForJavaScript(String javaScript) 
	{

		int timeLaps = 0;
		String status = "FAIL";
		WebElement jsElement = null;
		while (status.equals("FAIL") && timeLaps < GlobalVariables.waitTime) {
			try {

				//jsElement = (WebElement) getElementByJavascript(dbkey);
				//jsElement = (WebElement) getElement(dbkey);
				jsElement = (WebElement)action.executeJavaScript(javaScript);

				if (jsElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Exception e) {

				status = "FAIL";

			}

			Action.pause(2000);

			++timeLaps;

		}

		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);

		return jsElement;

	}
	
	
	public void writeIntoExcel(String feildName,String valueToBeStored)
	{
		inputSheet = exlObj.getSheet(inputSheetName);
		rowIndex = exlObj.getRowIndexByCellValue(inputSheet, 0, "Valid_Data");
		cellIndex = exlObj.getCellIndexByCellValue(inputSheet, 0, feildName);
		exlObj.setCellData(inputSheet, rowIndex, cellIndex, valueToBeStored);

	}

	public void clickOnNewAsset()
	{
		findElementByDynamicXpath("//brml-button[@id='btnAddunBundledNode']").click();
	}
	
	public void clickOnNewBenchmark() 
	{
		findElementByDynamicXpath("//brml-button[@id='btnAddSet1']").click();
	}
	
	public void deleteAllBins() throws Throwable 
	{
		int i = 0;
		
		while(i<=1)
		{
				myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[class='card-body']\")["+i+"].querySelectorAll(\"brml-active-icon[name='bin']\")");
				
				int bins = myElements.size();
				System.out.println("no of bins "+bins);
				
				while(bins > 0)
				{
					bins--;
					myElement = myElements.get(bins);
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					myElement.click();
					Thread.sleep(2000);
					
				}
				
				i++;
		}
	}
	
	public String selectBMDropdown(String id,String value) throws Throwable
	{
		myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
				+id+ "\"]').shadowRoot.querySelector('wf-input')");
		
		if(myElement.isEnabled())
		{
		action.scrollToElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
		
		myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
				+id+ "\"]').shadowRoot.querySelector(\"li[data-value='" + value + "']\")");
		
		value = myElement.getText();
				
		action.scrollToElement(myElement);
		
		action.click(myElement);
		Thread.sleep(2000);
		
		}
		return value;
	}
	
	public void enterPercentage(String id,String value) throws Throwable 
	{
		myElement = (WebElement) executeJavaScript("return document.querySelector('brml-stepper-input#"+id+"').shadowRoot.querySelector('input.input-stepper-data')");

		if(myElement.isEnabled())
		{
		   action.scrollToElement(myElement);
		   action.click(myElement);
		   action.clear(myElement);
		   myElement = (WebElement) executeJavaScript("return document.querySelector('brml-stepper-input#"+id+"').shadowRoot.querySelector('input.input-stepper-data')");

		   action.click(myElement);
		   action.clear(myElement);
		   action.sendkeysClipboard(myElement, value);

		   Thread.sleep(2000);
			
		}
	
	}
	
	public void edit_all_the_below_drop_down_fields_with_valid(List<List<String>> attribute) throws Throwable
    {
	  	String sheetName = "Valid";
			XSSFSheet sheet = exlObj.getSheet(sheetName);
			Thread.sleep(2000);
			for (int i = 0; i < attribute.size(); i++)
			{

				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				if(myElement.isEnabled())
				{
				action.scrollToElement(myElement);
				action.click(myElement);
				Thread.sleep(2000);
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				String myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector(\"li[data-value='" + myValue + "']\")");
				
				System.out.println(myElement.getText());
				
				//updateStrategyPage.writeIntoExcel(attribute.get(i).get(0), myElement.getText());
								
				action.scrollToElement(myElement);
				Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

				action.click(myElement);
				Thread.sleep(2000);
				
				}
				  
			}
    }
	
}