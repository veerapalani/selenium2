package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateFATeamConfirmationPage {
	
	Action action ;
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	
	public CreateFATeamConfirmationPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public void verifyFinancialAdvisorConfirmationHeaderonConfirmationPage() {
		myElement = action.fluentWaitWebElement("Confirmation Header");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
}
	
	public void verifyFinancialAdvisorConfirmationFAIDOnConfirmationPage() {
		myElement = action.getElement("FA Creation ID");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
}
	
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public void clickOnDoneButtOnConfirmationPage() throws Throwable{
		myElement = (WebElement) action.getElementByJavascript("Done Button");
		action.highligthElement(myElement);
		action.jsClick(myElement);
	}
	
	public void clickOnCreateAnotherFinancialAdvisorButtonOnConfirmationPage() throws Throwable{
		myElement = (WebElement) action.getElementByJavascript("Create Another Financial Advisor");
		action.highligthElement(myElement);
		action.jsClick(myElement);
	}
	
	
}
