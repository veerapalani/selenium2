package qa.unicorn.ad.productmaster.webui.pages;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UploadPage {

	Action action;

	public UploadPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	WebElement Element, Highlight, Ele;

	public boolean isUserOnManualUploadSlidePage() {

		Element = action.waitForJSWebElement("Header");
		if (Element.getText().equals("Manual Upload - Strategy")) {
			action.highligthElement(Element);
			Reporter.addCompleteScreenCapture();
			return true;
		}
		return false;
	}

	public void selectFileType(String fileType) {

		Element = (WebElement) action.fluentWaitForJSWebElement("File Type");
		action.click(Element);
		Highlight = (WebElement) action.getElementByJavascript("File Type Value");
		Highlight = Highlight.findElement(By.linkText(fileType));

		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		Reporter.addCompleteScreenCapture();
		action.click(Highlight);

	}

	public void uploadFileWithoutRobot(String uploadFilePath) {
		/*
		String csvFilePath = System.getProperty("user.dir")
				+ "\\src\\test\\resources\\ad\\productmaster\\webui\\csv-files\\" + filename;
		*/
		Element = action.getElement("File Input");
		Element.sendKeys(uploadFilePath);
		action.pause(10000);
		Reporter.addCompleteScreenCapture();

	}

	public static void setClipboardData(String data) {
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		StringSelection stringSelection = new StringSelection(data);
		clipboard.setContents(stringSelection, null);
	}

	public void uploadFileWithRobot(String uploadFilePath) {

		Element = action.waitForJSWebElement("Browse Button");
		Element.click();
		action.pause(10000);
		action.captureEntireScreen();

		try {

			/*
			fileNameWithExtension = fileNameWithExtension.replace("\\", "/");
			String uploadPath = System.getProperty("user.dir")
					+ "\\src\\test\\resources\\ad\\productmaster\\webui\\csv-files\\";
			*/
			
			setClipboardData(uploadFilePath);

			Robot robot = new Robot();

			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.delay(150);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (Exception exp) {
			exp.printStackTrace();
		}

		action.pause(10000);
		action.captureEntireScreen();
	}

	public Boolean verifyConfirmationMessageonFileUpload(String confirmationmessage) {
		Ele = (WebElement) action.getElementByJavascript("File Upload Confirmation Message");
		action.highligthElement(Ele);
		if(Ele.getText().equalsIgnoreCase(confirmationmessage))
			return true;
		return false;
	}

	public void verifyUploadedFileName(String filename) {
		Ele = (WebElement) action.getElementByJavascript("Verify FileName Uploaded on PMUI");
		action.highligthElement(Ele);
		System.out.println(Ele.getText().substring(0, Ele.getText().indexOf('_')));
		Assert.assertEquals(Ele.getText().substring(0, Ele.getText().indexOf('_')), filename);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyUploadedFileType(String filetype) {
		Ele = (WebElement) action.getElementByJavascript("Verify FileType Uploaded on PMUI");
		action.highligthElement(Ele);
		System.out.println(Ele.getText());
		Assert.assertEquals(Ele.getText(), filetype);
		Reporter.addCompleteScreenCapture();
	}

	public String getErrorMessageFromUI() {
		Element = (WebElement) action.getElementByJavascript("File Upload Confirmation Message");
		action.highligthElement(Ele);
		return Element.getText();
	}
}
