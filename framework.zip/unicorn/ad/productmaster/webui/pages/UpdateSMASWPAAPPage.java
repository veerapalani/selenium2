package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class UpdateSMASWPAAPPage {

	Action action;
	WebElement Element = null;
	WebElement Highlight = null;
	WebElement myElement;
	String[] expErrorlist;
	List<WebElement> actErrorMessages;
	Boolean flag;
	public static String searchResult;
	public static String value;

	public UpdateSMASWPAAPPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public String searchAndEnterStrategyCode(String strategyCode) {
		Action.pause(2000);
		action.waitForPageLoad();
		Element = (WebElement) action.getElementByJavascript("Global Search Box");
		Element.click();
		Element.clear();
		Action.pause(2000);
		action.sendKeys(Element, strategyCode);
		Action.pause(5000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		Action.pause(10000);
		return strategyCode;

	}

	public void clickOnSeeAllResults() {
		Action.pause(4000);
		Element = (WebElement) action.getElementByJavascript("See All Result");
		action.highligthElement(Element);
		Element.click();

	}

	public void verifyTheSearchedResultInAllTab() {
		Action.pause(2000);
		Element = (WebElement) action.getElementByJavascript("All Tab");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void clickOnSMATab() {
		Action.pause(2000);
		Element = (WebElement) action.getElementByJavascript("SMA Tab");
		Element.isDisplayed();
		Element.click();
	}

	public void verifySMATab() {
		Action.pause(2000);
		Element = (WebElement) action.getElementByJavascript("SMA Tab");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void mouseHoveOnSearchedRecordsOnGrid() {
		Action.pause(4000);
		Element = (WebElement) action.getElement("GridViewRecord");
		action.highligthElement(Element);
		action.moveToElement(Element);
	}

	public void clickOnEllipsesIcon() {
		Action.pause(4000);
		Element = (WebElement) action.getElementByJavascript("Ellipses Icon");
		Element.isDisplayed();
		Element.click();
	}

	public void verifyOnViewDetailsLink() {
		Action.pause(2000);
		Element = (WebElement) action.getElementByJavascript("ViewDetails");
		Element.isDisplayed();
	}

	public void clickOnViewDetailsLink() {
		Action.pause(2000);
		Element = (WebElement) action.getElementByJavascript("ViewDetails");
		action.jsClick(Element);
	}

	public void verifyElementsOnViewFAage(WebElement element) {
		myElement = element;
		Action.pause(3000);
		action.highligthElement(myElement);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void clickOnContinueEditingButton() {
		Element = action.fluentWaitWebElement("Continue Editing");
		action.moveToElement(Element);
		action.highligthElement(Element);
		Element.click();
	}

	public void clickOnNext() {
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();

	}
	
	public void clicksonthestatusddl() throws InterruptedException
	{
		Thread.sleep(5000);
		WebElement ele = (WebElement) action.getElementByJavascript("statusddl");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(6000);
		action.click(ele);
	}
	public void expandsddl() throws InterruptedException
	{
		Thread.sleep(5000);
		WebElement ele = (WebElement) action.getElementByJavascript("expandsddl");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(5000);
	}
	

	public WebElement getDynamicElementFromShadowRoot(String javaScript) {
		return myElement = (WebElement) action.executeJavaScript(javaScript);
	}

	public boolean isUserOnDocumentspage() {
		Element = action.waitForJSWebElement("Header");
		if (Element.getText().equals("Documents")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isUserOnCommentsPage() {
		Element = action.waitForJSWebElement("Header");
		if (Element.getText().equals("Comments")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isUserOnReviewPage() {
		Element = action.waitForJSWebElement("Header");
		if (Element.getText().equals("Review")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isUserOnEnterStrategyDetailspage() {
		Element = action.waitForJSWebElement("Enter Strategy Details Header");

		if (Element.getText().contains("Enter Strategy Details")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isUserOnBenchmarkPage() {
		Element = action.waitForJSWebElement("Benchmark and Asset Classification Header");

		if (Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
		return false;

	}
	
	public void highlightbundled() throws InterruptedException
	{
		
		Thread.sleep(4000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Highlight Bundled Node");
		action.scrollToElement(ele2);
		action.highligthElement(ele2);
		Thread.sleep(6000);
	}
}
