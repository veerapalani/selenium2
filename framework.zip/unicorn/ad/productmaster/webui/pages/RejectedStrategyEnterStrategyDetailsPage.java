package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;

public class RejectedStrategyEnterStrategyDetailsPage {

	Action action;
	public RejectedStrategyEnterStrategyDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	WebElement Element,Highlight;
	int loopCount;
	private static ThreadLocal<String> FASelection = new ThreadLocal<String>();
	

	
	public static String getFASelection() {
		return FASelection.get();
	}
	
	
	/*
	 * set value to FA in case of FA
	 * set value to FA Team in case of FA Team
	 * */
	public static void setFASelection(String faSelection) {
		FASelection.set(faSelection);
	}

	public boolean isUserOnEnterStrategyDetailsPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Enter Strategy Details")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
	}
	public void validateFATeam() {
		Element = action.fluentWaitWebElement("NEXT");
		Assert.assertTrue(action.isDisplayed(Element));
	}
	public String getRiskCategoryValue() {
		Element = action.fluentWaitWebElement("Risk Category Value");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getPIVStyleValue() {
		Element = action.fluentWaitWebElement("PIV Style Value");
		action.moveToElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getGeographicIndicatorValue() {
		Element = action.fluentWaitWebElement("Geographic Indicator Value");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getStrategyNameValue() {
		Element = action.fluentWaitWebElement("Strategy Name Value");
		action.moveToElement(Element);
		String uiValue = Element.getAttribute("value");
		if((uiValue == null) || (uiValue.isEmpty())) {
			uiValue = "isEmpty";
			((WebElement) action.fluentWaitForJSWebElement("Strategy Name")).sendKeys(uiValue);
			return uiValue;
		}
		return uiValue;
	}

	public String getStrategyCodeValue() {
		Element = action.fluentWaitWebElement("FOA Code Value");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getBalancedAllocationValue() {
		Element = action.fluentWaitWebElement("Balanced Allocation Value");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getConcentratedStrategyIndicatorValue() {
		Element = action.fluentWaitWebElement("Concentrated Strategy Indicator Value");
		action.moveToElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getStructuredProductsStrategyValue() {
		Element = action.fluentWaitWebElement("Structured Products Strategy Value");
		action.moveToElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getStrategyStatusValue() {
		Element = action.fluentWaitWebElement("Status Value");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getHedgeCoreIndicatorValue() {
		Element = action.fluentWaitWebElement("Hedge Core Indicator Value");
		action.moveToElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getStylePairingCodeValue() {
		Element = action.fluentWaitWebElement("Style Pairing Code Value");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getInvestmentStyleValue() {
		Element = action.fluentWaitWebElement("Investment Style Value");
		action.moveToElement(Element);
		return Element.getAttribute("name");
	}

	public String getMarginEligibleValue() {
		Element = (WebElement) action.fluentWaitForJSWebElement("Margin Eligible Value");
		action.moveToElement(Element);
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "t";
		}
		return "f";
	}

	public String getFANameValue() {
		
		action.pause(5000);
		Element = action.getElementByFormatingXpath("FA or FA Team Visibility", "fa");
		if(Element.getAttribute("class").contains("hide")) {
			return "isEmpty";
		}
		else
		{
			Element = action.getElementByFormatingXpath("FA or FA Team Value", "fa");
			return Element.getAttribute("name");
		}
	}

	public String getFATeamNameValue() {
		Element = action.getElementByFormatingXpath("FA or FA Team Visibility", "faTeam");
		if(Element.getAttribute("class").contains("hide"))
			return "isEmpty";
		else
		{
			Element = action.getElementByFormatingXpath("FA or FA Team Value", "faTeam");
			return Element.getAttribute("name");
		}
	}

	public String getFATeamMemberDetailValue() {
		Element = action.getElementByFormatingXpath("FA or FA Team Visibility", "faTeam");
		if(Element.getAttribute("class").contains("hide"))
			return "isEmpty";
		else
		{
			Element = action.getElement("FA Team Member Name");
			return Element.getText();
		}
	}

	public String getStrategyTierValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faTier");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getMarketCapValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "marketCap");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getFeeScheduleTypeValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "feeScheduleType");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getInvestmentStyleCategoryValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "investmentStyleCategory");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getComparativeUniverseValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "comparativeUniverse");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getBundledNodeIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "bundledNodeId");
		action.moveToElement(Element);
		if(Element.getAttribute("value").contains("-"))
			return Element.getAttribute("value").split("-")[0];
		return Element.getAttribute("value");
	}

	public String getUnbundledNodeIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "unbundledNodeId");
		action.moveToElement(Element);
		if(Element.getAttribute("value").isEmpty())
			return "isEmpty";
		if(Element.getAttribute("value").contains("-"))
			return Element.getAttribute("value").split("-")[0];
		return Element.getAttribute("value");
	}

	public String getShortTermMaturityValue() {
		Element = action.getElementByFormatingXpath("Common Special Radio Button Value", "shortTermMaturity");
		action.moveToElement(Element);
		String data = Element.getAttribute("value");
		System.out.println(data);
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getAlternativesStrategyValue() {
		Element = action.getElementByFormatingXpath("Common Special Radio Button Value", "alternativeStrategy");
		action.moveToElement(Element);
		String data = Element.getAttribute("value");
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getSustainableInvestmentStrategyValue() {
		Element = action.getElementByFormatingXpath("Common Special Radio Button Value", "sustainableInvestmentStrategy");
		action.moveToElement(Element);
		String data = Element.getAttribute("value");
		System.out.println(data);
		switch (data) {
		case "true":
			return "t";
			
		case "false":
			return "f";
		default:
			break;
		}
		return "Not defined";
	}

	public String getSingleStrategyOnlyValue() {
		Element = action.getElementByFormatingXpath("Common Check Box Value", "singleStrategyOnly");
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "t";
		}
		return "f";
	}

	public String getFAEmailValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faEmail");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getNonPMPApprovedTeamMemberEmailValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "nonPmpApprovedTeamMemberEmail");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public String getDVPTemplateValue() {
//		List<WebElement> lis = action.getElements("DVP Key Trust Template Value");
//		//Element = action.getElementByFormatingXpath("DVP Key Trust Template Value", "DVPKeyTrustTemplate");
//		if(lis.size() > 0) {
//			action.moveToElement(lis.get(0));
//			return lis.get(0).getAttribute("name");
//		}
		return "isEmpty";
	}

	public String getHideStrategyValue() {
		Element = action.getElementByFormatingXpath("Common Check Box Value", "hideStrategy");
		action.moveToElement(Element);
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "t";
		}
		return "f";
	}

	public String getPMPTitleValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "faSegment");
		action.moveToElement(Element);
		return Element.getAttribute("value");
	}

	public void enterStrategyName(String strategyName) {
		Element = action.getElement("Strategy Name");
		action.moveToElement(Element);
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, strategyName);
		} while (!(getStrategyNameValue().equals(strategyName)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	public void enterInvestmentStyleName(String investmentStyleName) {
		Element = action.getElementByFormatingXpath("Common Dropdown", "investmentStyle");
		action.click(Element);
		Highlight = action.getElementByFormatingXpath("Common Dropdown Value", "investmentStyle");
		Highlight = Highlight.findElement(By.linkText(investmentStyleName));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void selectFARadioButton() {
		Element = (WebElement) action.fluentWaitForJSWebElement("FA");
		Element.click();
		action.pause(2000);
		
	}
	public void selectFATeamRadioButton() {
		Element = (WebElement) action.fluentWaitForJSWebElement("FA TEAM");
		Element.click();
		action.pause(2000);
	}
	public void enterFaName(String faAndFaTeamName, String fatype) {
		System.out.println(fatype);
		action.pause(1000);
		Element = (WebElement) action.getElementByFormatingXpath("FA AND FATEAM NAME", fatype);
		action.click(Element);
		action.pause(3000);
		Highlight = (WebElement) action.getElementByFormatingXpath("FA AND FATEAM NAME Value", fatype);
		switch (fatype) {
		case "fa":
			Highlight = Highlight.findElement(By.linkText(faAndFaTeamName));
			break;
		case "faTeam":
			
			List<WebElement> list = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
			for (WebElement E : list) {
				List<WebElement> list2 = action.getElementsFromParentElement(E, "FA Team Value");
				if(list2.size() > 0) {
					if(list2.get(0).getText().equalsIgnoreCase(faAndFaTeamName)) {
						
						Highlight = E;
							
							break;
					}
				}
			}
			break;
		default:
			break;
		}
		
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
//		action.refresh();
//		isUserOnEnterStrategyDetailsPage();
		
	}

	public void enterFaTeamMembersDetail(String faTeamMembersDetail) {
		// TODO Auto-generated method stub
		
	}

	public void enterStatus(String status) {
		// TODO Auto-generated method stub
		
	}

	public void enterPmpTitle(String pmpTitle) {
		Element = action.getElementByFormatingXpath("Common Dropdown", "faSegment");
		action.click(Element);
		Highlight = action.getElementByFormatingXpath("Common Dropdown Value", "faSegment");
		Highlight = Highlight.findElement(By.linkText(pmpTitle));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
	}

	public void enterStrategyTier(String strategyTier) {
		
		if(!getStructuredProductsStrategyValue().equalsIgnoreCase("t")) {
		Element = action.getElementByFormatingXpath("Common Dropdown", "faTier");
		action.click(Element);
		Highlight = action.getElementByFormatingXpath("Common Dropdown Value", "faTier");
		Highlight = Highlight.findElement(By.linkText(strategyTier));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		}
		
	}

	public void enterMarketCap(String marketCap) {
		// TODO Auto-generated method stub
		
	}

	public void enterRiskCategory(String riskCategory) {
		// TODO Auto-generated method stub
		
	}

	public void enterFeeScheduleType(String feeScheduleType) {
		// TODO Auto-generated method stub
		
	}

	public void enterPivStyle(String pivStyle) {
		// TODO Auto-generated method stub
		
	}

	public void enterGeographicIndicator(String geographicIndicator) {
		// TODO Auto-generated method stub
		
	}

	public void enterBalancedAllocation(String balancedAllocation) {
		// TODO Auto-generated method stub
		
	}

	public void enterInvestmentStyleCategory(String investmentStyleCategory) {
		// TODO Auto-generated method stub
		
	}

	public void enterComparativeUniverse(String comparativeUniverse) {
		// TODO Auto-generated method stub
		
	}

	public void enterBundledNodeID(String bundledNodeID) {
		// TODO Auto-generated method stub
		
	}

	public void enterUnbundledNodeID(String unbundledNodeID) {
		// TODO Auto-generated method stub
		
	}

	public void enterStylePairingCode(String stylePairingCode) {
		// TODO Auto-generated method stub
		
	}

	public void enterConcentratedStrategyIndicator(String concentratedStrategyIndicator) {
		concentratedStrategyIndicator = concentratedStrategyIndicator.toLowerCase().trim();
		switch (concentratedStrategyIndicator) {
		case "yes":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Yes", "concentratedStrategyIndicator"); 
			//(WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Common Special Radio Button No", "concentratedStrategyIndicator");
			Element.click();
			break;
		case "not defined":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Not Defined", "concentratedStrategyIndicator");
			Element.click();
			break;

		default:
			break;
		}
		
	}

	public void enterStructuredProductsStrategy(String structuredProductsStrategy) {
		structuredProductsStrategy = structuredProductsStrategy.toLowerCase().trim();
		switch (structuredProductsStrategy) {
		case "yes":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Yes", "structuredProductStrategy"); 
			//(WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Common Special Radio Button No", "structuredProductStrategy");
			Element.click();
			break;
		case "not defined":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Not Defined", "structuredProductStrategy");
			Element.click();
			break;

		default:
			break;
		}
		
	}

	public void enterHedgeCoreIndicator(String hedgeCoreIndicator) {
		hedgeCoreIndicator = hedgeCoreIndicator.toLowerCase().trim();
		switch (hedgeCoreIndicator) {
		case "yes":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Yes", "hedgeCoreIndicator"); 
			//(WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Common Special Radio Button No", "hedgeCoreIndicator");
			Element.click();
			break;
		case "not defined":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Not Defined", "hedgeCoreIndicator");
			Element.click();
			break;

		default:
			break;
		}
		
	}

	public void enterShortTermMaturity(String shortTermMaturity) {
		shortTermMaturity = shortTermMaturity.toLowerCase().trim();
		switch (shortTermMaturity) {
		case "yes":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Yes", "shortTermMaturity"); 
			//(WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Common Special Radio Button No", "shortTermMaturity");
			Element.click();
			break;
		case "not defined":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Not Defined", "shortTermMaturity");
			Element.click();
			break;

		default:
			break;
		}
		
	}

	public void enterAlternativesStrategy(String alternativesStrategy) {
		alternativesStrategy = alternativesStrategy.toLowerCase().trim();
		switch (alternativesStrategy) {
		case "yes":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Yes", "alternativeStrategy"); 
			//(WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Common Special Radio Button No", "alternativeStrategy");
			Element.click();
			break;
		case "not defined":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Not Defined", "alternativeStrategy");
			Element.click();
			break;

		default:
			break;
		}
		
	}

	public void enterFoaCode(String foaCode) {
		// TODO Auto-generated method stub
		
	}

	public void enterSingleStrategyOnly(String singleStrategyOnly) {
		// TODO Auto-generated method stub
		
	}

	public void enterMarginEligible(String marginEligible) {
		if(!marginEligible.equalsIgnoreCase(getMarginEligibleValue())) {
			Element = action.getElementByFormatingXpath("Common Checkbox Input", "marginEligible");
			Element.click();
		}
		
	}

	public void enterFaEmail(String faEmail) {
		// TODO Auto-generated method stub
		
	}

	public void enterNonPMPApprovedTeamMemberEmails(String nonPMPApprovedTeamMemberEmails) {
		Element = action.getElementByFormatingXpath("Common Text Field Input", "nonPmpApprovedTeamMemberEmai");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, nonPMPApprovedTeamMemberEmails);
		} while (!(getNonPMPApprovedTeamMemberEmailValue().equals(nonPMPApprovedTeamMemberEmails)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	public void enterDvpKeyTrustTemplate(String dvpKeyTrustTemplate) {
		Element = action.getElementByFormatingXpath("Common Dropdown", "DVPKeyTrustTemplate");
		action.click(Element);
		Highlight = action.getElementByFormatingXpath("Common Dropdown Value", "DVPKeyTrustTemplate");
		Highlight = Highlight.findElement(By.linkText(dvpKeyTrustTemplate));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
		
	}

	public void enterHideStrategy(String hideStrategy) {
		if(!hideStrategy.equalsIgnoreCase(getHideStrategyValue())) {
			Element = action.getElementByFormatingXpath("Common Checkbox Input", "hideStrategy");
			Element.click();
		}
		
	}

	public void enterSustainableInvestmentStrategy(String sustainableInvestmentStrategy) {
		sustainableInvestmentStrategy = sustainableInvestmentStrategy.toLowerCase().trim();
		switch (sustainableInvestmentStrategy) {
		case "yes":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Yes", "sustainableInvestmentStrategy"); 
			//(WebElement) action.fluentWaitForJSWebElement("Concentrated Strategy Indicator Yes");
			Element.click();
			break;
		case "no":
			Element = action.getElementByFormatingXpath("Common Special Radio Button No", "sustainableInvestmentStrategy");
			Element.click();
			break;
		case "not defined":
			Element = action.getElementByFormatingXpath("Common Special Radio Button Not Defined", "sustainableInvestmentStrategy");
			Element.click();
			break;

		default:
			break;
		}
		
	}

	public void refreshThePage() {
		action.refresh();
	}

	public boolean istheAttributeHeaderVisible(String label) {
		Element = action.getElementByFormatingXpath("Common Attribute Header", label);
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
	
		return false;
	}
	
	
}
