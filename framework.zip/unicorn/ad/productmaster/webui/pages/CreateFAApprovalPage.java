package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class CreateFAApprovalPage {
	Action action;
	WebElement myElement;
	String fieldValue = null;

	public CreateFAApprovalPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void enterHomeOfficeComments() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtHomeOfficeComments");
		action.highligthElement(ele);
		ele.sendKeys("approvarenamehereastestastxtHomeOfficeComments");
	}

	public void enterFollowUpNotes() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtFollowUpNotes");
		action.highligthElement(ele);
		action.sendKeys(ele,
				"approver name here as test as txt Home Office Comments estates here goes for follow up notes for reference .we can give up to 500 characters here .so you can see everything here will be 500c haraterdjkk.jhjhjhj klkdsc kjkdfkef kkefjkefk kfkjefkj kermfklemrfklm;ek klemflk;er kelrfkle'rk kemrfkemr efmkme klefem klflkemf klfklefm fkmkemf lek,flekf kewkfmk ewfmkefm fkekwmflk lfwlkef lflfm kwefmkf kfkfmkf lwfelewfkl lf'le lkdlwkfl lw;ekfl flkfl wflwklf klwfkwlef lkledfk'wlef lkwflwfffffffffffffffffff");
	}

	public void selectStatusDate() throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("selectStatusDate"));
		action.click((WebElement) action.fluentWaitForJSWebElement("selectStatusDatevalue"));
	}

	public void selectFollowUpDate() throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("selectFollowUpDate"));
		action.click((WebElement) action.fluentWaitForJSWebElement("selectFollowUpDatevalue"));
	}

	public void clickonnextbutoninapproverpage() throws InterruptedException {
		action.pause(2000);
		action.click(action.fluentWaitWebElement("NextButtoninapproverpage"));
		Reporter.addScreenCapture();
	}

	public void selectFAStatusvalue() throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("drpDwnFAStatusType"));
		action.click((WebElement) action.fluentWaitForJSWebElement("FAStatustypevalue"));
	}

	public void validateFollowUpField(String followUp) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtFollowUpNotes");
		action.highligthElement(ele);
		action.sendKeys(ele, followUp);
		fieldValue = ele.getAttribute("value");
		Assert.assertTrue(fieldValue.equals(followUp));
	}

	public void validateHomeOfficeComments() throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtHomeOfficeComments");
		action.highligthElement(ele);
		fieldValue = ele.getAttribute("value");
		Assert.assertTrue(fieldValue.equals("approvarenamehereastestastxtHomeOfficeComments"));
	}

	public void clickonpreviousbuttoninapprovalpage() throws InterruptedException {
		myElement = action.fluentWaitWebElement("Previous Button");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}
}
