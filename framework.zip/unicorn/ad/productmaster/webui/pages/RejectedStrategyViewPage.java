package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.ibm.db2.jcc.am.la;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class RejectedStrategyViewPage {
	Action action;

	public RejectedStrategyViewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	WebElement Element;
	//Below page 'attributeLabel' - is Attribute label for most Attributes.
	String strategyID, attributeLabel;

	public boolean isUserOnViewRejectedStrategyPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("View Strategy")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public String getRiskCategoryValue() {
		Element = action.fluentWaitWebElement("Risk Category Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPIVStyleValue() {
		Element = action.fluentWaitWebElement("PIV Style Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		return "f";
	}

	public String getGeographicIndicatorValue() {
		Element = action.fluentWaitWebElement("Geographic Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getStrategyNameValue() {
		Element = action.fluentWaitWebElement("Strategy Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getStrategyCodeValue() {
		Element = action.fluentWaitWebElement("FOA Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getBalancedAllocationValue() {
		Element = action.fluentWaitWebElement("Balanced Allocation Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getConcentratedStrategyIndicatorValue() {
		Element = action.fluentWaitWebElement("Concentrated Strategy Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStructuredProductsStrategyValue() {
		Element = action.fluentWaitWebElement("Structured Products Strategy Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStrategyStatusValue() {
		Element = action.fluentWaitWebElement("Status Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getHedgeCoreIndicatorValue() {
		Element = action.fluentWaitWebElement("Hedge Core Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStylePairingCodeValue() {
		Element = action.fluentWaitWebElement("Style Pairing Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getInvestmentStyleValue() {
		Element = action.fluentWaitWebElement("Investment Style Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPrimaryBenchmarkValue() {
		String primaryBenchmark = "";
		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		if(WebElements.isEmpty()) {
			return "isEmpty";
		}
		else {
			List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0),
					"Benchmarks List common tag");
			ArrayList<String> tempData = new ArrayList<String>();
			int size = Elements.size();
			int count = 0;
			DecimalFormat ds = new DecimalFormat(".00");
			for(int i = 0; i < size / 3; i++) {
				primaryBenchmark = "@benchmarkCategory-#-@benchmarkName--#-@percentage";
				if(Elements.get(count).getText().equals("—")) {
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count + 1).getText());
					primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements
							.get(count + 2).getText().substring(0, Elements.get(count + 2).getText().length() - 1))));
				}
				else if(Elements.get(count + 1).getText().equals("—")) {
					if(primaryBenchmark.contains("@benchmarkCategory")) {
						primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
						primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
						primaryBenchmark = primaryBenchmark.replace("@percentage",
								ds.format(Integer.parseInt(Elements.get(count + 2).getText().substring(0,
										Elements.get(count + 2).getText().length() - 1))));
					}
					else {
						Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
					}
				}
				tempData.add(primaryBenchmark);
				//data = data+primaryBenchmark+":";
				count = count + 3;
			}
			if(tempData.size() > 1) {
				Collections.sort(tempData);
				primaryBenchmark = "";
				for(String G: tempData) {
					primaryBenchmark = primaryBenchmark + G + ":";
				}
			}
			tempData.clear();
			return primaryBenchmark;
		}
	}

	public void CheckingPMPTitle() {
		Element = action.fluentWaitWebElement("PMP Title");
		Assert.assertTrue(action.isDisplayed(Element));
	}

	public void clickOnContinueEditingButton() {
		Element = action.fluentWaitWebElement("Continue Editing");
		Element.click();
	}

	public String getMarginsValue() {
		Element = action.fluentWaitWebElement("Margin Eligible Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStrategyID() {
		String URL = action.getCurrentURL();
		strategyID = URL.split("/")[URL.split("/").length - 1];
		return strategyID;
	}

	public String getFANameValue() {
		attributeLabel = "FA/FA Team";
		if(action.getElement("FA Team Member Label").getAttribute("style").contains("visibility: hidden;"))
			return getValue(attributeLabel);
		return "isEmpty";
	}

	public String getFATeamNameValue() {
		attributeLabel = "FA/FA Team";
		if(action.getElement("FA Team Member Label").getAttribute("style").contains("visibility: visible;"))
			return getValue(attributeLabel);
		return "isEmpty";
	}

	public String getFATeamMemberDetailValue() {
		attributeLabel = "FA/FA Team";
		if(action.getElement("FA Team Member Label").getAttribute("style").contains("visibility: visible;"))
			return action.fluentWaitWebElement("FA Team Member Value").getText();
		return "isEmpty";
	}

	public String getStrategyTierValue() {
		attributeLabel = "Strategy Tier";
		return getValue(attributeLabel);
	}

	public String getMarketCapValue() {
		attributeLabel = "Market Cap";
		return getValue(attributeLabel);
	}

	public String getFeeScheduleTypeValue() {
		attributeLabel = "Fee Schedule Type";
		return getValue(attributeLabel);
	}

	public String getInvestmentStyleCategoryValue() {
		attributeLabel = "Investment Style Category";
		return getValue(attributeLabel);
	}

	public String getComparativeUniverseValue() {
		attributeLabel = "Comparative Universe";
		return getValue(attributeLabel);
	}

	public String getBundledNodeIDValue() {
		attributeLabel = "Bundled Node ID";
		if(getValue(attributeLabel).contains("-"))
			return getValue(attributeLabel).split("-")[0];
		return getValue(attributeLabel);
	}

	public String getUnbundledNodeIDValue() {
		attributeLabel = "Unbundled Node ID";
		if(getValue(attributeLabel).contains("-"))
			return getValue(attributeLabel).split("-")[0];
		return getValue(attributeLabel);
	}

	public String getShortTermMaturityValue() {
		attributeLabel = "Short-Term Maturity";
		return getValue(attributeLabel);
	}

	public String getAlternativesStrategyValue() {
		attributeLabel = "Alternatives Strategy";
		return getValue(attributeLabel);
	}

	public String getSustainableInvestmentStrategyValue() {
		attributeLabel = "Sustainable Investment Strategy";
		return getValue(attributeLabel);
	}

	public String getSingleStrategyOnlyValue() {
		attributeLabel = "Single Strategy Only";
		String data = getValue(attributeLabel);
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getFAEmailValue() {
		attributeLabel = "Fa Email";
		return getValue(attributeLabel);
	}

	public String getNonPMPApprovedTeamMemberEmailValue() {
		attributeLabel = "Non PMP Approved Team Member Email";
		return getValue(attributeLabel);
	}

	public String getDVPTemplateValue() {
		attributeLabel = "DVP/Key Trust Template";
		return getValue(attributeLabel);
	}

	public String getHideStrategyValue() {
		attributeLabel = "Hide Strategy";
		String data = getValue(attributeLabel);
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getNonPMPSubmissionDateValue() {
		attributeLabel = "PMP Submission Date";
		return getValue(attributeLabel);
	}

	public String getBenchmarkCategoryValue() {
		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		if(WebElements.isEmpty()) {
			return "isEmpty";
		}
		else {
			List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0),
					"Benchmarks List common tag");
			int count = 0;
			if(Elements.get(count).getText().equals("—")) {
				return "Custom";
			}
			else if(Elements.get(count + 1).getText().equals("—")) {
				return "Default";
			}
			else {
				Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
				return "";
			}
		}
	}

	public String getBenchmarkNameValue() {
		String primaryBenchmarkName = "";
		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		if(WebElements.isEmpty()) {
			return "isEmpty";
		}
		else {
			List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0),
					"Benchmarks List common tag");
			ArrayList<String> tempData = new ArrayList<String>();
			int size = Elements.size();
			int count = 0;
			for(int i = 0; i < size / 3; i++) {
				if(Elements.get(count).getText().equals("—")) {
					primaryBenchmarkName = Elements.get(count + 1).getText();
				}
				else if(Elements.get(count + 1).getText().equals("—")) {
					primaryBenchmarkName = Elements.get(count).getText();
				}
				tempData.add(primaryBenchmarkName);
				//data = data+primaryBenchmark+":";
				count = count + 3;
			}
			if(tempData.size() > 1) {
				//Collections.sort(tempData);
				primaryBenchmarkName = "";
				for(String G: tempData) {
					primaryBenchmarkName = primaryBenchmarkName + G + ",";
				}
				primaryBenchmarkName = primaryBenchmarkName.substring(0, primaryBenchmarkName.length() - 1);
			}
			tempData.clear();
			return primaryBenchmarkName;
		}
	}

	public String getPercentageValue() {
		String primaryBenchmarkPercentage = "";
		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		if(WebElements.isEmpty()) {
			return "isEmpty";
		}
		else {
			List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0),
					"Benchmarks List common tag");
			ArrayList<String> tempData = new ArrayList<String>();
			int size = Elements.size();
			int count = 0;
			DecimalFormat ds = new DecimalFormat(".00");
			for(int i = 0; i < size / 3; i++) {
				if(Elements.get(count).getText().equals("—")) {
					primaryBenchmarkPercentage = ds.format(Integer.parseInt(Elements.get(count + 2).getText()
							.substring(0, Elements.get(count + 2).getText().length() - 1)));
				}
				else if(Elements.get(count + 1).getText().equals("—")) {
					primaryBenchmarkPercentage = ds.format(Integer.parseInt(Elements.get(count + 2).getText()
							.substring(0, Elements.get(count + 2).getText().length() - 1)));
				}
				tempData.add(primaryBenchmarkPercentage);
				//data = data+primaryBenchmark+":";
				count = count + 3;
			}
			if(tempData.size() > 1) {
				//Collections.sort(tempData);
				primaryBenchmarkPercentage = "";
				for(String G: tempData) {
					primaryBenchmarkPercentage = primaryBenchmarkPercentage + G + ",";
				}
				primaryBenchmarkPercentage = primaryBenchmarkPercentage.substring(0,
						primaryBenchmarkPercentage.length() - 1);
			}
			tempData.clear();
			return primaryBenchmarkPercentage;
		}
	}

	public String getCustomBenchmarkReasonValue() {
		Element = action.getElement("Custom Benchmark Reason Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	private String requiredDocumentValue(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		Element = action.fluentWaitWebElement("Document Grid");
		if(Element.getText().contains("There are no document links to show"))
			return "isEmpty";
		List<WebElement> documentValues = action.getElementsFromParentElement(Element,
				"Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";
		for(WebElement E: documentValues) {
			if(E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
			}
		}
		int documents = documentValuesData.size() / 3;
		for(int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i + 3;
		}
		if(documents > 1) {
			Collections.sort(tempData);
			requiredDocumentValue = "";
			for(String G: tempData) {
				requiredDocumentValue = requiredDocumentValue + G + ",";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length() - 1);
		}
		tempData.clear();
		return requiredDocumentValue;
	}

	public String getDocumentTypeValue() {
		return requiredDocumentValue(0);
	}

	public String getDocumentLinkValue() {
		return requiredDocumentValue(1);
	}

	public String getDocumentCommentValue() {
		return requiredDocumentValue(2);
	}

	private String requiredCommentValue(int i) {
		/*
		 * Comment Type --> i=0 Comment Comment --> i=1
		 * 
		 */
		Element = action.fluentWaitWebElement("Comment Grid");
		//to be changed
		if(Element.getText().contains("There are no document links to show"))
			return "isEmpty";
		List<WebElement> commentValues = action.getElementsFromParentElement(Element,
				"Common value for Comment Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> commentValuesData = new ArrayList<WebElement>();
		String requiredCommentValue = "";
		for(WebElement E: commentValues) {
			if(E.getAttribute("class").contains("body-3")) {
				commentValuesData.add(E);
			}
		}
		int comments = commentValuesData.size() / 2;
		for(int j = 0; j < comments; j++) {
			requiredCommentValue = commentValuesData.get(i).getText();
			tempData.add(requiredCommentValue);
			action.moveToElement(commentValuesData.get(i));
			action.highligthElement(commentValuesData.get(i));
			i = i + 2;
		}
		if(comments > 1) {
			Collections.sort(tempData);
			requiredCommentValue = "";
			for(String G: tempData) {
				requiredCommentValue = requiredCommentValue + G + ",";
			}
			requiredCommentValue = requiredCommentValue.substring(0, requiredCommentValue.length() - 1);
		}
		tempData.clear();
		return requiredCommentValue;
	}

	public String getCommentTypeValue() {
		return requiredCommentValue(0);
	}

	public String getCommentCommentValue() {
		return requiredCommentValue(1);
	}

	private String getValue(String attributeLabel) {
		Element = action.getElementByFormatingXpath("Common Attribute Value", attributeLabel);
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPMPTitleValue() {
		attributeLabel = "PMP Title";
		return getValue(attributeLabel);
	}

	public String getBenchmarkithValuefromUI(int j) {
		ArrayList<String> primarybenchmark = getPrimaryBenchmarksValue();
		return primarybenchmark.get(j).split("-#-")[2].trim();
	}

	public Float getPercentageithValuefromUI(int j) {
		ArrayList<String> primarybenchmark = getPrimaryBenchmarksValue();
		return Float.parseFloat(primarybenchmark.get(j).split("-#-")[3].trim());
	}

	public ArrayList<String> getPrimaryBenchmarksValue() {
		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		String primaryBenchmark = "";
		List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0),
				"Benchmarks List common tag");
		ArrayList<String> tempData = new ArrayList<String>();
		//String primaryBenchmark = "";
		int size = Elements.size();
		int count = 0;
		DecimalFormat ds = new DecimalFormat(".00");
		for(int i = 0; i < size / 3; i++) {
			primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName-#-@percentage";
			primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
			if(Elements.get(count).getText().equals("—")) {
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count + 1).getText());
				primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Float.parseFloat(Elements
						.get(count + 2).getText().substring(0, Elements.get(count + 2).getText().length() - 1))));
			}
			else if(Elements.get(count + 1).getText().equals("—")) {
				if(primaryBenchmark.contains("@benchmarkCategory")) {
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
					primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Float.parseFloat(Elements
							.get(count + 2).getText().substring(0, Elements.get(count + 2).getText().length() - 1))));
				}
				else {
					Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
				}
			}
			tempData.add(primaryBenchmark);
			//data = data+primaryBenchmark+":";
			count = count + 3;
		}
		/*
		 * if(tempData.size() > 1) { Collections.sort(tempData); primaryBenchmark = "";
		 * for (String G : tempData) { primaryBenchmark = primaryBenchmark+G+":"; } }
		 * tempData.clear();
		 */
		return tempData;
	}

	public WebElement getCommentsValues(int i) {
		List<WebElement> commentValues = action.getElements("Comments Common value");
		action.scrollToElement(commentValues.get(i));
		action.highligthElement(commentValues.get(i));
		return commentValues.get(i);
	}

	// To get Comments Type value i=2
	public WebElement getCommentsTypeValue() {
		return getCommentsValues(2);
	}

	// To get Comments Comment value i=4
	public WebElement getCommentsCommentValue() {
		return getCommentsValues(4);
	}

	public boolean isAttributeLabelDisplayed(String label) {
		
		Element = action.getElementByFormatingXpath("Common Attribute Label", label);
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
			}
		return false;
		
	}
}
