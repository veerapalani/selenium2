package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class RejectedStrategyConfirmationPage {

	Action action;
	public RejectedStrategyConfirmationPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element;
	
	public boolean isUserOnConfirmationPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Confirmation")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isConfirmationMessageDisplayed(String confirmationmessage) {
		
		action.pause(3000);
		Element = action.fluentWaitWebElement("Confirmation Message");
		if(Element.getText().equals(confirmationmessage)) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
}
