package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateFAConfirmationPage {
	Action action;
	WebElement myElement;
	String faId = "";

	public CreateFAConfirmationPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void verifyElementsonconfirmationpage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public void clickon2buttons(String elementKey) {
		myElement = action.fluentWaitWebElement(elementKey);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public String getFACodeFromConfirmationPage() {

		List<WebElement> elements = action.fluentWaitWebElements("FA Code Value displayed");
		String message[] = elements.get(1).getText().replace("|", ";").split(";");
		String foaCode = message[1].split(": ")[1];
		return foaCode;
	}

	public void clickonDonebutton() {
		myElement = action.fluentWaitWebElement("DONE");
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public String waitForWebElement(String xpath) {
		int timeLaps = 0;
		String status = "FAIL";
		while (status.equals("FAIL") && timeLaps < 2) {
			try {
				myElement = findElementByDynamicXpath(xpath);
				if (myElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}
			} catch (Exception e) {
				status = "FAIL";
			}
			Action.pause(500);
			++timeLaps;
		}
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);
		return status;
	}

	public String getFAID() {
		String URL = action.getCurrentURL();
		faId = URL.split("/")[URL.split("/").length - 1];
		return faId;
	}
}
