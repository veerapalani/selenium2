package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateStrategyPage {
Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();

	public CreateStrategyPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	public String getCreateStrategyPageURL() {
		return action.getCurrentURL();
	}
	public void clickOnprogdropdowninstrategywizard() {
		WebElement dropelement =  (WebElement) action.getElementByJavascript("ProgramDropdown");
		action.highligthElement(dropelement);
		action.click(dropelement);
	}

	public void selectsprogvalueinstrategywizard() {
		action.scrollByPixel(Integer.toString(700));
		WebElement dropelement = action.getElement("ProgValue");
		action.highligthElement(dropelement);
		action.jsClick(dropelement);
	}
public void assertbenchmarknamevalue() {
		
		String str1= getTextofReviewbenchname("benchmarknamevalue");
		WebElement dropelement = (WebElement) action.getElementByJavascript("benchmarkdropdownnamevalue");
		Assert.assertEquals(str1, dropelement);
		Reporter.addStepLog("the actual value of the benhcmark name element value"+str1);
		Reporter.addStepLog("the actual value of the benhcmark name review element value"+dropelement);
		Reporter.addScreenCapture();
	}
	public String getTextofReviewbenchname(String elemName) {
		myElement = action.getElement(elemName);
		action.highligthElement(myElement);
		Reporter.addScreenCapture();
		return myElement.getText();
		
		
	}
	public void enterstrategynameinstrategywizard() {
		WebElement element = (WebElement) action.fluentWaitForJSWebElement("StrategyName");
		element.click();
		action.sendKeys(element, "create");
	}
	public void clickOncreatenewbenchmarkLink() throws Throwable{
		WebElement myElement = action.getElement("Create New Benchmark link");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public void clickOncreatenewmanagerLink() throws Throwable{
		WebElement myElement = action.getElement("Create New Manager link");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public void clickOnstrategybutton() throws Throwable {
		//action.scrollByPixel(Integer.toString(700));
		 action.pause(700);
		WebElement myElement = action.fluentWaitWebElement("Create Strategy Button");
		action.highligthElement(myElement);
		action.jsClick(myElement);

	}

	public void clickonbenchmarkdropdownincreatestrategypage() {
		action.scrollByPixel(Integer.toString(700));
		WebElement element = (WebElement) action.getElementByJavascript("Benchmark Dropdown");
		action.click(element);
	}
	public void clickonmanagerdropdownincreatestrategypage() {
		action.scrollByPixel(Integer.toString(700));
		WebElement element = (WebElement) action.getElementByJavascript("ManagerDropdown");
		action.click(element);
	}
	public void verifycreatenewbenchmarklink() {
		myElement = action.getElement("Create New Benchmark link");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
}
