package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdateSMASingleAccessStrategyReviewPage {

	Action action;
	public UpdateSMASingleAccessStrategyReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element;
	public boolean isUserOnReviewPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Review")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	
	public String getRiskCategoryValue() {
		
		Element = action.fluentWaitWebElement("Risk Category Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getStrategyNameValue() {
		
		Element = action.fluentWaitWebElement("Strategy Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getStrategyCodeValue() {
		Element = action.fluentWaitWebElement("FOA code (ACCESS) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getResearchRatingValue() {
		Element = action.fluentWaitWebElement("Research Rating Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getStrategyMinimumValue() {
		Element = action.fluentWaitWebElement("Strategy Minimum (MEPS) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getText())).toString();
		return data;
	}

	public String getExceptionMinimumValue() {
		Element = action.fluentWaitWebElement("Exception Minimum (RAW) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getText())).toString();
		return data;
	}

	public String getWithdrawalRebalanceMinimumValue() {
		Element = action.fluentWaitWebElement("Withdrawal/Rebalance Minimum (RAW) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getText())).toString();
		return data;
	}

	public String getStrategyStatus() {
		Element = action.fluentWaitWebElement("Strategy Status Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getPremiumEligibleValue() {
		/*
//		Element = action.fluentWaitWebElement("");
//		action.moveToElement(Element);
//		action.highligthElement(Element);
		return "done";
		//return Element.getText();
		 * 
		 */
		Element = action.fluentWaitWebElement("Premium Fee Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getConcordFeeEligibleValue() {
		Element = action.fluentWaitWebElement("Concord Eligible Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		switch (Element.getText().toLowerCase()) {
		case "yes":
			return "t";
		case "no":
			return "f";
		default:
			break;
		}
		return "Incorrect Value is displayed in UI";
	}

	public String getBundledNodeIDValue() {
		/*
		Element = action.fluentWaitWebElement("Bundled Node ID Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String[] data = Element.getText().split("-");
		return data[0].trim();
		*/
		Element = action.getElement("Time Periods Count");
		List<WebElement> timeperiods = action.getElementsFromParentElement(Element, "Node Id List");
		ArrayList<String> tempData = new ArrayList<String>();
		int timeperiodscount = 1;
		//System.out.println(timeperiodscount+":::");
		String BundledNodeID = "";
		String[] data;
		//Element = action.fluentWaitWebElement("Bundled Node ID Value");
		for (WebElement E: timeperiods) {
			//System.out.println(E.getAttribute("class"));
			if(E.getAttribute("class").contains("grid")) {
			//System.out.println(timeperiodscount);
			Element = action.getElementByFormatingXpath("Bundled Node ID Value", timeperiodscount);
			action.moveToElement(Element);
			action.highligthElement(Element);
			data = Element.getText().split("-");
			BundledNodeID = data[0].trim();
			tempData.add(BundledNodeID);
			timeperiodscount++;
			}
			
		}
		if(tempData.size() > 1) {
			Collections.sort(tempData);
			BundledNodeID = "";
			for (String G : tempData) {
				BundledNodeID = BundledNodeID+G+":";
			}	
		}
		tempData.clear();
		
		
		return BundledNodeID;
	}

	public String getUnbundledNodeIDValues() {
		Element = action.getElement("Unbundled Node ID Value");
		List<WebElement> Elements = action.getElementsFromParentElement(Element, "Node Id List");
		String[] temp;
		String data = "";
		for (WebElement E : Elements) {
			action.moveToElement(E);
			action.highligthElement(E);
			temp = E.getText().split("-");
			data = data+temp[0].trim()+":";
		}
		if(Elements.size() == 1) {
			data = data.substring(0, data.length()-1);
		}
		return data;
		//return Element.getText();
	}

	public String getInceptionDateIgnore() {
//		Element = action.fluentWaitWebElement("");
//		action.moveToElement(Element);
//		action.highligthElement(Element);
		return "done";
		//return Element.getText();
	}

	public String getStartDateIgnoreValue() {
//		Element = action.fluentWaitWebElement("");
//		action.moveToElement(Element);
//		action.highligthElement(Element);
		return "done";
		//return Element.getText();
	}

	public String getIsManagerProfileValue() {
		Element = action.fluentWaitWebElement("IS Manager Profile Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		switch (Element.getText().toLowerCase()) {
		case "yes":
			return "t";
		case "no":
			return "f";
		default:
			break;
		}
		return "Incorrect Value is displayed in UI";
		//return Element.getText();
	}

	public String getDeletedValue() {
		Element = action.fluentWaitWebElement("Deleted Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		switch (Element.getText().toLowerCase()) {
		case "yes":
			return "t";
		case "no":
			return "f";
		default:
			break;
		}
		return "Incorrect Value is displayed in UI";
		//return Element.getText();
	}

	public String getAlternativesStrategyCodeValue() {
//		Element = action.fluentWaitWebElement("");
//		action.moveToElement(Element);
//		action.highligthElement(Element);
		return "done";
		//return Element.getText();
	}

	public String getProxyManagerValue() {
		Element = action.fluentWaitWebElement("Proxy Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getProxyAddress1Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getProxyAddress2Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getProxyAddress3Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getProxyAddress4Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getProxyCityValue() {
		Element = action.fluentWaitWebElement("Proxy Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getProxyStateValue() {
		Element = action.fluentWaitWebElement("Proxy Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getProxyZipCodeValue() {
		Element = action.fluentWaitWebElement("Proxy Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getVoluntaryReorgManagerValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getVoluntaryReorgAddress1Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getVoluntaryReorgAddress2Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getVoluntaryReorgAddress3Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getVoluntaryreorgAddress4Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}
	
	public String getVoluntaryReorgCityValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getVoluntaryReorgStateValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getVoluntaryReorgZipcodeValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getInterimManagerValue() {
		Element = action.fluentWaitWebElement("Interim Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getInterimAddress1Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getInterimAddress2Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getInterimAddress3Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getInterimAddress4Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if(Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getInterimCityValue() {
		Element = action.fluentWaitWebElement("Interim Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getInterimStateValue() {
		Element = action.fluentWaitWebElement("Interim Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}

	public String getInterimZipcodeValue() {
		Element = action.fluentWaitWebElement("Interim Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		
		return Element.getText();
	}
	
	public String getPrimaryBenchmarkValue() {
		String primaryBenchmark = "";

		Element = action.getElement("Date Type");
		String datetype = Element.getText();
		if (datetype.equals("Style")) {
			List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
			if (WebElements.isEmpty()) {
				return "Primary Benchmark Data is not displayed in Review Page";
			} else {
				List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0), "Benchmarks List common tag");
				ArrayList<String> tempData = new ArrayList<String>();
				// String primaryBenchmark = "";
				int size = Elements.size();
				int count = 0;
				DecimalFormat ds = new DecimalFormat(".00");
				for (int i = 0; i < size / 3; i++) {
					primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
					primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
					if (Elements.get(count).getText().equals("—")) {
						primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
						primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count + 1).getText());
						primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements.get(count + 2).getText().substring(0, Elements.get(count + 2).getText().length() - 1))));
					} else if (Elements.get(count + 1).getText().equals("—")) {
						if (primaryBenchmark.contains("@benchmarkCategory")) {
							primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
							primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements.get(count + 2).getText().substring(0, Elements.get(count + 2).getText().length() - 1))));
						} else {
							Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
						}

					}
					tempData.add(primaryBenchmark);
					// data = data+primaryBenchmark+":";
					count = count + 3;

				}
				if (tempData.size() > 1) {
					Collections.sort(tempData);
					primaryBenchmark = "";
					for (String G : tempData) {
						primaryBenchmark = primaryBenchmark + G + ":";
					}
				}
				tempData.clear();
			}
		} else if (datetype.equals("Timeperiod")) {
			Element = action.getElement("Total Time periods");
			List<WebElement> Timeperiods = action.getElementsFromParentElement(Element, "Benchmarks List common tag");
			ArrayList<String> tempData = new ArrayList<String>();
			int timeperiodcount = 1;
			for (WebElement E : Timeperiods) {
				if(E.getAttribute("class").contains("mb24")) {
					//List<WebElement> WebElements2 = action.getElements("Primary Benchmark Value for Time periods");
					String locatorValue = "//div[contains(text(),'Benchmark1')]/parent::div/parent::div/following-sibling::div["+timeperiodcount+"]/child::div[3]/child::div";
					//locatorValue = locatorValue.replace("@data", String.valueOf(timeperiodcount));
					List<WebElement> WebElements2 = action.getElements("xpath", locatorValue);
					if(WebElements2.isEmpty()) {
						primaryBenchmark =  timeperiodcount + " :: time period benchamrks are not appearing";
					}else {
						List<WebElement> Elements2 = action.getElementsFromParentElement(WebElements2.get(0), "Benchmarks List common tag");
						
						//String primaryBenchmark = "";
						int size  = Elements2.size();
						int count = 0;
						DecimalFormat ds = new DecimalFormat(".00");
						for (int i = 0; i < size/2; i++) {
							primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
							primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Cap n Go");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements2.get(count).getText());
							primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements2.get(count+1).getText().substring(0, Elements2.get(count+1).getText().length()-1))));
							tempData.add(primaryBenchmark);
							//data = data+primaryBenchmark+":";
							count = count + 2;
							
						}
					}
					timeperiodcount++;
				}
				
				
			}
			
			if(tempData.size() > 1) {
				Collections.sort(tempData);
				primaryBenchmark = "";
				for (String G : tempData) {
					primaryBenchmark = primaryBenchmark+G+":";
				}	
			}
			tempData.clear();
		}
		return primaryBenchmark;

	}
}
