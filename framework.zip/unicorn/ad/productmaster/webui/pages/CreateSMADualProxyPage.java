package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;

public class CreateSMADualProxyPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	String expMsg = "https://pm.uat.wmap.broadridge.com/pmui/#/smaDualMac/add";
	boolean flag;

	public CreateSMADualProxyPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void enterManagerNameinProxyPage() throws InterruptedException {

		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtManagerName1");
		action.highligthElement(ele);
		action.sendKeys(ele, "BlackrockManager");
	}

	public void enterAddressLine1inProxyPage() throws InterruptedException {

		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtAddressLine1");
		action.highligthElement(ele);
		action.sendKeys(ele, "esttg");
	}

	public void enterCityinProxyPage() throws InterruptedException {

		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtCity");
		action.highligthElement(ele);
		action.sendKeys(ele, "bangalore");
	}

	public void enterZipCodeinProxyPage() throws InterruptedException {

		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtZipCode");
		action.highligthElement(ele);
		action.sendKeys(ele, "12345");
	}

	public void Voluntaryreorgchkbox() throws InterruptedException {
		Thread.sleep(500);
		action.click((WebElement) action.getElementByJavascript("chkboxvultaryreorg"));
		// action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}

	public void Interimreorgchkbox() throws InterruptedException {
		Thread.sleep(500);

		action.click((WebElement) action.getElementByJavascript("chkboxInterim"));
	}

	public void selectState() throws InterruptedException {
		Thread.sleep(500);
		action.click((WebElement) action.getElementByJavascript("drpStateType"));
		action.click((WebElement) action.getElementByJavascript("StateKey"));
	}

	public void clickOnNextButtonProxyPage() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement) action.getElement("NextButtonProxy_SMADual"));
		action.captureEntireScreen();
		action.click((WebElement) action.getElement("NextButtonProxy_SMADual"));
		Thread.sleep(200);
	}

	public void clickonPreviousButton() {
		myElement = action.getElement("Previous Button");
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public boolean isUserOnProxyDetailsPage() {
		flag = false;
		myElement = action.fluentWaitWebElement("Proxy Details Header");
		if (myElement.isDisplayed()) {
			action.highligthElement(myElement);
			flag = true;
		}
		return flag;
	}
}
