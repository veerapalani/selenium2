package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class RejectedStrategyDocumentsPage {

	Action action;
	public RejectedStrategyDocumentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element,Highlight;
	Boolean flag;
	int loopCount;
	
	public boolean isUserOnDocumentsPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Enter Document Links")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
		
	}

	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void selectDocumentType(String documentType) {
		Element = (WebElement) action.fluentWaitForJSWebElement("drpDwnDocumentType");
		Element.click();
		Highlight = (WebElement) action.getElementByJavascript("DocumenttypeKey");
		Highlight = Highlight.findElement(By.linkText(documentType));
		/*
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(documentType)) {
				Highlight = E;
				break;
			}
		}
		*/
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}
	
	public void enterDocumentLink(String documentLink) {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDocLink");
		loopCount = 0;
		do {
			ele.click();
			myClear(ele);
			action.sendKeys(ele, documentLink);
		} while (!(getDocumentLinkValueFromEditPage().equals(documentLink)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}
	
	private String getDocumentLinkValueFromEditPage() {
		Element = action.waitForJSWebElement("Document Link Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}

	public void enterDocumentComment(String documentComment) {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDocComment");
		loopCount = 0;
		do {
			ele.click();
			myClear(ele);
			action.doubleClick(ele);
			action.doubleClick(ele);
			action.sendKeys(ele, documentComment);
		} while (!(getDocumentCommentValueFromEditPage().equals(documentComment)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	private String getDocumentCommentValueFromEditPage() {
		Element = action.waitForJSWebElement("Document Comment Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}

	public void clickOnAddDocumentLinkButton() {
	
		action.fluentWaitWebElement("AddDocumentLinkButton").click();
		action.pause(1000);
		isUserOnDocumentsPage();
	
	}

	public boolean checkIfAddAnotherDocumentLinkDisplayed() {
		Boolean flag = true;
		
		Element = action.fluentWaitWebElement("Document Card to identify button displayed");
		List<WebElement> elements = Element.findElements(By.xpath("./*"));
		
		for (WebElement webElement : elements) {
			if(webElement.getTagName().contains("brml-form"))
				flag = false;
		}
		
		return flag;
	}
	public void clickOnAddAnotherDocument() {
		
		 
		
		//List<WebElement> elements = action.fluentWaitWebElements("AddDocumentLinkButton");
		
		if(checkIfAddAnotherDocumentLinkDisplayed()) {
			
			Element = action.fluentWaitWebElement("Add Another Document Link");
			Element.click();
			action.pause(1000);
			isUserOnDocumentsPage();
		}else {
			Reporter.addStepLog("No Add Another Document Link is displayed in UI");
		
		}
	}
	
	
	public void clickOnPrevious() {
		
		action.scrollToBottom();
		action.fluentWaitWebElement("PREVIOUS").click();
		
	}

	public int getcountofDocuments() {
		
		List<WebElement> Elements = action.getElements("Type");
		if(Elements.size() > 0) {
			List<WebElement> Elements2 = action.getElements("Documents Count");
			return Elements2.size()-1;
		}else {
			return 0;
		}
		
	}

	public ArrayList<String> getithDocumentInfo(int i) {
		
		ArrayList<String> document = new ArrayList<String>();
		Element = action.getElementByFormatingXpath("Document Record", i+1);
		action.highligthElement(Element);
		ArrayList<WebElement> Elements = (ArrayList<WebElement>) action.getElementsFromParentElement(Element, "Common Tag for Document Values");
		String value = "";
		for (int j = 0; j < Elements.size()-1; j++) {
			
			value = Elements.get(j).getText();
			
			//deleting the extra charaters from get text
			if(j == 2) {
				
				value = value.substring(0, value.length()-15).trim();
				
			}
			document.add(value);
			
		}
		
		return document;
	}

	public void clickOnDocumentType() {
		
		Element = (WebElement) action.fluentWaitForJSWebElement("drpDwnDocumentType");
		Element.click();
		
	}

	public boolean isValueDisplayedinTypeDropdown(String dropDownValue) {
		Highlight = (WebElement) action.getElementByJavascript("DocumenttypeKey");
		//Highlight = Highlight.findElement(By.linkText(documentType));
		
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(dropDownValue)) {
				Highlight = E;
				return true;
			}
		}
		return false;
	}

	//Code data in heidisql is not implemented for below 
	private String requiredDocumentValue(int i) {
		/*
		 *  Document Type		--> i=0
			Document Link		--> i=1
			Document Comment	--> i=2
			
		*/
		Element = action.fluentWaitWebElement("Document Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element, "Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";
		
		
		for (WebElement E : documentValues) {
			if(E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
				}
			
		}
		int documents = documentValuesData.size()/3;
		
		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i+3;
		}
		
		if(documents > 1) {
			Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue+G+",";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
		}
		tempData.clear();
		
		return requiredDocumentValue;
	}
	
	public String getDocumentTypeValue() {
		
		return requiredDocumentValue(0);
	}


	public String getDocumentLinkValue() {
		return requiredDocumentValue(1);
	}

	public String getDocumentCommentValue() {
		return requiredDocumentValue(2);
	}

	public void deleteDocument() {
		List<WebElement> elements = action.getElements("Delete Documents");
		
		elements.get(elements.size()-1).click();
		action.pause(1000);
		isUserOnDocumentsPage();
		
	}

	public ArrayList<String> getDropdownValuesDisplayedInUI(String dropdownName) {
		String replacedata = "";
		
		ArrayList<String> tempData = new ArrayList<String>();
		
		String uiIterator = "testNull";
		
		switch (dropdownName) {
		case "Type":
			replacedata = "documentType";
			break;
		default:
			break;
		}
		
		Highlight = action.getElementByFormatingXpath("Common Dropdown List", replacedata);
		List<WebElement> dropdownValuesFromUI = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
			for (WebElement E : dropdownValuesFromUI) {
				
				uiIterator = E.getText();
				tempData.add(uiIterator);
			}
			//to handle Zero records from DB 
    		if(uiIterator.equalsIgnoreCase("testnull")) {
    			uiIterator = "isEmpty";
    			tempData.add(uiIterator);
    		}
    		//to handle multiple values for same column
    		if(tempData.size() > 1) {
    			Collections.sort(tempData);
    		}
		
		
		
		return tempData;
	}

	public boolean areDocumentsAvailableinUI() {
		
		List<WebElement> elements = action.getElements("Delete Documents");
		
		if(elements.size() > 0)
			return true;
		else
			return false;
	}

	public void clickOnBackLink() {
		
		action.navigateBackward();
		
	}

	public void clickOnReset() {
		
		Element = action.fluentWaitWebElement("Reset");
		action.moveToElement(Element);
		Element.click();
		isUserOnDocumentsPage();
		
	}

	public String getDocumentTypeValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Type");
		return Element.getAttribute("value");
	}

	public String getDocumentLinkValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Document Link");
		return Element.getAttribute("value");
	}

	public String getDocumentCommentValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Comment");
		return Element.getAttribute("value");
	}

	public boolean error(String errormessage) {
		flag = false;
		action.pause(2000);
		String[] expErrorlist = errormessage.split("-");
		/*
		 * if(experror.contains("-")) { expErrorlist = experror.split("-"); } else
		 * expErrorlist[0] = experror;
		 */
		
				
		for(String S:expErrorlist) {
			switch (S) {
			case "Type must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Type");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: "+Element.getText());
				Reporter.addStepLog("Expected Message: "+S);
				flag=true;
				break;
			case "Document Link must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Document Link");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: "+Element.getText());
				Reporter.addStepLog("Expected Message: "+S);
				flag=true;
				break;
			case "Comment must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Comment");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: "+Element.getText());
				Reporter.addStepLog("Expected Message: "+S);
				flag=true;
				break;
			default:
				Reporter.addStepLog("Expected Message: "+S);
				Reporter.addStepLog("Expected Error Message is invalid ");
				flag = false;
				break;
			}
			if(flag == false)
				break;
		}
		
		return flag;
		
	}

	public void clickOnPreviousButton() {
		
		Element = action.fluentWaitWebElement("PREVIOUS");
		Element.click();
		
	}

	public void refreshThePage() {
		action.refresh();
	}
}
