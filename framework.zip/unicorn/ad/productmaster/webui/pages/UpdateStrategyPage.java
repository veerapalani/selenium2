package qa.unicorn.ad.productmaster.webui.pages;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class UpdateStrategyPage {
	Action action;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	public UpdateStrategyPage() {
		// TODO Auto-generated constructor stub
		action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategyUIPage"));
	}
	
	
	public String getCurrentTimeStamp() {
		Long time = Calendar.getInstance().getTimeInMillis();
		return time.toString();
	}
	public void verifyTextInListOfElements(String text, List<WebElement> list1) {

		for (int i = 0; i < list1.size(); i++) {
			list.add(list1.get(i).getText());
			
			
		}
		for (int i=0; i<list.size();i++) {
//			Reporter.addStepLog("checking with "+list.get(i));
			if(list.get(i).contains(text))
			{	
				action.highligthElement(list1.get(i));
				Assert.assertTrue(true);
				return;
			}
		}
	//Assert.assertTrue(false);
	}
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		listOfElements= element.getElements("xpath", xpath);
		
		return listOfElements;
	}
	
	public boolean is_identifier_for_dropdown_being_displayed(String dbkey,String expected_value)
	{
		
		List<WebElement> items = action.getElements(dbkey);
		for(int i=0;i<items.size();i++)
		{
			String x = items.get(i).getText();
			System.out.println("String actual_value" + x);
			System.out.println("String expected_value" +expected_value);
			if (x.contains(expected_value))
				
		{
				return true;
				
				
		}
		
			
		
	}
		return false;
	}
	
	public void clicksonsameasproxyaddress() throws InterruptedException
	{
		WebElement ele = (WebElement) action.getElementByJavascript("sameasproxy");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}
	
	public void clickonpremiumfeecheck() throws InterruptedException{
		WebElement ele = (WebElement) action.getElementByJavascript("premiumfeecheck");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}
	
	
	public void deletetimeperiod()  throws InterruptedException{
		//Thread.sleep(4000);
		WebElement ele = (WebElement) action.getElementByJavascript("DeleteTP");
		action.highligthElement(ele);
		action.click(ele);
		Thread.sleep(1000);
	}
	
	public void sendKeysWithCheck(WebElement element, String value)
    {
        try
        {
            action.sendKeys(element, value);
            while(true)
            {
                Thread.sleep(500);
                if(!(element.getAttribute("value").trim().equalsIgnoreCase(value)))
                {
                    myClear(element);
                    //action.clear(element);
                    action.sendKeys(element, value);
                }
                else
                {
                    System.out.println("Input :" + element.getAttribute("value"));
                    break;
                }
            }
        }
        catch(Exception e)
        {
           // ExceptionHandler.handleException(e);
        }
    }
	
	public void myClear(WebElement element)
    {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
      //  js.executeScript("arguments[0].value='';", element);
        js.executeScript("arguments[0].value='';", element);
        //((JavascriptExecutor)WebDriverManager.getDriver()).executeScript("arguments[0].value='';", element);
    }
	
}
