package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.Assert.assertTrue;

import java.text.DecimalFormat;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateSMASingleAccessStrategyProxyDetailsPage {
	Action action;
	WebElement Element, Highlight;
	Boolean flag;
	String[] expErrorlist;
	int loopCount;

	public CreateSMASingleAccessStrategyProxyDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void myClear(WebElement element){        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void clickOnNext() {
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
	}

	public boolean validateErrorMessage(String expError) {
		flag = false;
		action.pause(2000);
		if(expError.contains("-")) {
			expErrorlist = expError.split("-");
		}
		else
			expErrorlist[0] = expError;
		for(String S: expErrorlist) {
			switch(S) {
				case "Manager Name must not be empty":
					Element = (WebElement)action.getElementByJavascript("Manager Name Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Address Line 1 must not be empty":
					Element = (WebElement)action.getElementByJavascript("Address Line1 Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "State must not be empty":
					Element = (WebElement)action.getElementByJavascript("State Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "City must not be empty":
					Element = (WebElement)action.getElementByJavascript("City Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Zip Code must not be empty":
					Element = (WebElement)action.getElementByJavascript("ZipCode Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				default:
					Reporter.addStepLog("Expected Message: " + S);
					Reporter.addStepLog("Expected Error Message is invalid ");
					flag = false;
					break;
			}
			if(flag == false)
				break;
		}
		return flag;
	}

	public void enterProxyAddressManagerName(String proxyAddressManagerName) {
		Element = action.fluentWaitWebElement("Proxy Address Header Text");
		Element = (WebElement)action.fluentWaitForJSWebElement("Manager Name");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, proxyAddressManagerName);
		} while (!(getCommonTextAttributeValueforProxy("managerName").equals(proxyAddressManagerName)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	public String getCommonTextAttributeValueforProxy(String ID) {
		return action.getElementByFormatingXpath("Proxy Common Attribute Text Value", ID).getAttribute("value");
	}

	public void enterProxyAddressLine1(String proxyAddressLine1) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Address Line 1");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, proxyAddressLine1);
		} while (!(getCommonTextAttributeValueforProxy("addressLine1").equals(proxyAddressLine1)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	public void enterProxyAddressLine2(String proxyAddressLine2) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Proxy Address Line 2");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, proxyAddressLine2);
		} while (!(getCommonTextAttributeValueforProxy("addressLine2").equals(proxyAddressLine2)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	public void enterProxyAddressLine3(String proxyAddressLine3) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Proxy Address Line 3");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, proxyAddressLine3);
		} while (!(getCommonTextAttributeValueforProxy("addressLine3").equals(proxyAddressLine3)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	public void enterProxyAddressLine4(String proxyAddressLine4) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Proxy Address Line 4");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, proxyAddressLine4);
		} while (!(getCommonTextAttributeValueforProxy("addressLine4").equals(proxyAddressLine4)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	public void enterProxyAddressCity(String proxyAddressCity) {
		Element = (WebElement)action.fluentWaitForJSWebElement("City");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, proxyAddressCity);
		} while (!(getCommonTextAttributeValueforProxy("city").equals(proxyAddressCity)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	public void enterProxyAddressState(String proxyAddressState) {
		Element = (WebElement)action.fluentWaitForJSWebElement("State");
		action.click(Element);
		Highlight = (WebElement)action.fluentWaitForJSWebElement("State Value");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		for(WebElement E: li) {
			if(E.getText().equalsIgnoreCase(proxyAddressState)) {
				Highlight = E;
				break;
			}
		}
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterProxyAddressZipCode(String proxyAddressZipCode) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Zip Code");
		DecimalFormat df = new DecimalFormat("0.#");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, proxyAddressZipCode);
		} while (!(df.format(Float.parseFloat(getCommonTextAttributeValueforProxy("zipCode"))).equals(df.format(Float.parseFloat(proxyAddressZipCode)))) && ++loopCount < 10);
		
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
	}

	public void enterVoluntaryReorgSameAsProxy(String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("Yes")) {
			action.scrollToElement((WebElement)action.getElementByJavascript("Voluntary Reorg Address Checkbox"));
			action.jsClick((WebElement)action.getElementByJavascript("Voluntary Reorg Address Checkbox"));
		}
	}

	public void enterVoluntaryReorgAddressManagerName(String voluntaryReorgAddressManagerName,
			String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Voluntary Manager Name");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, voluntaryReorgAddressManagerName);
			} while (!(getCommonTextAttributeValueforVoluntary("managerName").equals(voluntaryReorgAddressManagerName)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	private String getCommonTextAttributeValueforVoluntary(String ID) {
		
		return action.getElementByFormatingXpath("Voluntary Reorg Address Common Text Field Value", ID).getAttribute("value");
	}

	public void enterVoluntaryReorgAddressLine1(String voluntaryReorgAddressLine1, String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Voluntary Address Line 1");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, voluntaryReorgAddressLine1);
			} while (!(getCommonTextAttributeValueforVoluntary("addressLine1").equals(voluntaryReorgAddressLine1)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterVoluntaryReorgAddressLine2(String voluntaryReorgAddressLine2, String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Voluntary Address Line 2");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, voluntaryReorgAddressLine2);
			} while (!(getCommonTextAttributeValueforVoluntary("addressLine2").equals(voluntaryReorgAddressLine2)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterVoluntaryReorgAddressLine3(String voluntaryReorgAddressLine3, String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Voluntary Address Line 3");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, voluntaryReorgAddressLine3);
			} while (!(getCommonTextAttributeValueforVoluntary("addressLine3").equals(voluntaryReorgAddressLine3)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterVoluntaryReorgAddressLine4(String voluntaryReorgAddressLine4, String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Voluntary Address Line 4");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, voluntaryReorgAddressLine4);
			} while (!(getCommonTextAttributeValueforVoluntary("addressLine4").equals(voluntaryReorgAddressLine4)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterVoluntaryReorgAddressCity(String voluntaryReorgAddressCity, String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Voluntary City");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, voluntaryReorgAddressCity);
			} while (!(getCommonTextAttributeValueforVoluntary("city").equals(voluntaryReorgAddressCity)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterVoluntaryReorgAddressState(String voluntaryReorgAddressState, String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Voluntary State");
			action.click(Element);
			Highlight = (WebElement)action.fluentWaitForJSWebElement("Voluntary State Value");
			List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
			for(WebElement E: li) {
				if(E.getText().equalsIgnoreCase(voluntaryReorgAddressState)) {
					Highlight = E;
					break;
				}
			}
			action.scrollToElement(Highlight);
			action.highligthElement(Highlight);
			action.click(Highlight);
		}
	}

	public void enterVoluntaryReorgAddressZipCode(String voluntaryReorgAddressZipCode,
			String voluntaryReorgSameAsProxy) {
		if(voluntaryReorgSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Voluntary ZipCode");
			DecimalFormat df = new DecimalFormat("0.#");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, voluntaryReorgAddressZipCode);
			} while (!(df.format(Float.parseFloat(getCommonTextAttributeValueforProxy("zipCode"))).equals(df.format(Float.parseFloat(voluntaryReorgAddressZipCode)))) && ++loopCount < 10);
			
			if(loopCount >= 10)
				Assert.fail("Unable to input entire text to text field");
		}
	}

	public void enterInterimSameAsProxy(String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("Yes")) {
			action.jsClick((WebElement)action.getElementByJavascript("Interim Checkbox"));
		}
	}

	public void enterInterimAddressManagerName(String interimAddressManagerName, String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Interim Manager Name");
			action.scrollToBottom();
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, interimAddressManagerName);
			} while (!(getCommonTextAttributeValueforInterim("managerName").equals(interimAddressManagerName)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	private String getCommonTextAttributeValueforInterim(String ID) {
		return action.getElementByFormatingXpath("Interim Common Attribue Text Value", ID).getAttribute("value");
	}

	public void enterInterimAddressLine1(String interimAddressLine1, String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Interim Address Line 1");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, interimAddressLine1);
			} while (!(getCommonTextAttributeValueforInterim("addressLine1").equals(interimAddressLine1)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterInterimAddressLine2(String interimAddressLine2, String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Interim Address Line 2");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, interimAddressLine2);
			} while (!(getCommonTextAttributeValueforInterim("addressLine2").equals(interimAddressLine2)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterInterimAddressLine3(String interimAddressLine3, String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Interim Address Line 3");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, interimAddressLine3);
			} while (!(getCommonTextAttributeValueforInterim("addressLine3").equals(interimAddressLine3)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterInterimAddressLine4(String interimAddressLine4, String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Interim Address Line 4");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, interimAddressLine4);
			} while (!(getCommonTextAttributeValueforInterim("addressLine4").equals(interimAddressLine4)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterInterimAddressCity(String interimAddressCity, String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Interim City");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, interimAddressCity);
			} while (!(getCommonTextAttributeValueforInterim("city").equals(interimAddressCity)) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
		}
	}

	public void enterInterimAddressState(String interimAddressState, String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Interim State");
			action.click(Element);
			Highlight = (WebElement)action.fluentWaitForJSWebElement("Interim State Value");
			List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
			for(WebElement E: li) {
				if(E.getText().equalsIgnoreCase(interimAddressState)) {
					Highlight = E;
					break;
				}
			}
			action.scrollToElement(Highlight);
			action.highligthElement(Highlight);
			action.click(Highlight);
		}
	}

	public void enterInterimAddressZipCode(String interimAddressZipCode, String interimSameAsProxy) {
		if(interimSameAsProxy.equalsIgnoreCase("No")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Interim ZipCode");
			DecimalFormat df = new DecimalFormat("0.#");
			loopCount = 0;
			do {
				Element.click();
				myClear(Element);
				action.doubleClick(Element);
				action.sendKeys(Element, interimAddressZipCode);
			} while (!(df.format(Float.parseFloat(getCommonTextAttributeValueforInterim("zipCode"))).equals(df.format(Float.parseFloat(interimAddressZipCode)))) && ++loopCount < 10);
			
			if(loopCount >= 10)
				Assert.fail("Unable to input entire text to text field");
		}
	}

	public boolean isUserOnProxyDetailsPage() {
		boolean flag = false;
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Proxy Details")) {
			flag = true;
			action.highligthElement(Element);
		}
		return flag;
	}

	public void clickOnPrevious() {
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("Previous");
		Element.click();
	}

	public void selectVoluntaryReorgSameAsProxy() {
		action.scrollToElement((WebElement)action.getElementByJavascript("Voluntary Reorg Address Checkbox"));
		action.jsClick((WebElement)action.getElementByJavascript("Voluntary Reorg Address Checkbox"));
	}

	public void selectInterimSameAsProxy() {
		action.scrollToElement((WebElement)action.getElementByJavascript("Interim Checkbox"));
		action.jsClick((WebElement)action.getElementByJavascript("Interim Checkbox"));
	}
	
	public String getTextFieldAttributeValue(String textField) {
		Element = action.fluentWaitWebElement(textField);
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	
}
