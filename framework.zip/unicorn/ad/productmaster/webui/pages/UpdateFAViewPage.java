package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.CSVFileUtils;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class UpdateFAViewPage {
	Action action;

	public UpdateFAViewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	WebElement myElement, Element, Highlight;
	String faID;
	String label, attributeValue, uiValue, dbValue = null;
	public void verifyElementsOnViewFAage(List<String> entity) {
		for (String Elements : entity) {
			Element = action.getElementByFormatingXpath("Common Page Entity Header", Elements);
			action.highligthElement(Element);
			action.scrollToElement(Element);
			Assert.assertTrue(action.isDisplayed(Element));
		}
	}

	public boolean isUserOnViewFAPage() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("Header");
		action.highligthElement(Element);
		if (Element.getText().equals("View FA")) {
			return true;
		}
		return false;
	}

	public void verifyContinueEditingAndCancelButtonsOnViewFAage(List<String> entity) {
		// updateFAPage.findElementByDynamicXpath("//span[text()='" + entity.get(i) +
		// "']")
		for (String Elements : entity) {
			Element = action.getElementByFormatingXpath("Common Page Entity Header", Elements);
			action.highligthElement(Element);
			action.scrollToElement(Element);
			Assert.assertTrue(action.isDisplayed(Element));
		}
	}

	public void clickOnContinueEditingLink() {
		Element = action.fluentWaitWebElement("CONTINUE EDITING");
		// (WebElement) action.getElement("CONTINUE EDITING");
		action.click(Element);
	}

	public String getFAID() {
		String URL = action.getCurrentURL();
		faID = URL.split("/")[URL.split("/").length - 1];
		return faID;
	}

	public String getManagerHeadValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Branch Manager/Market Head");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getFANameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Name");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getFAEmailValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Email");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getFAIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA ID(s)");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getUniversalIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Universal ID");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getCRDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "CRD#(s)");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getNominationForRecruitValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Is nomination for a recruit?");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "f";
		return Element.getText();
	}

	public String getRecruitHireDataValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Recruit Hire Date");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getPriorFirmValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Prior Firm");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getPreviouslyApprovedorNotForFADiscretionaryProgramValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value",
				"Previously Approved for FA Discretionary Program?");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getFADiscretionaryProgramValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Discretionary Program Name");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getFASegmentValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Segment");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getRenominationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Re-Nomination");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getRenominationDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Re-Nomination Date");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getSeries7RegistrationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Length of Series 7 Registration");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getSeries65RegistrationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Length of Series 65 or 66 Registration");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getLenghtOfServiceAsFAValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Length of Service as a FA");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getAUMValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Assets Under Management (AUM in $)");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		DecimalFormat df = new DecimalFormat(".0000");
		return df.format(Integer.parseInt(Element.getText()));
	}

	public String getAnticipatedPercentageValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value",
				"Anticipated Percentage of Overall Business in PMP/AAP");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		DecimalFormat df = new DecimalFormat(".00");
		return df.format(Integer.parseInt(Element.getText()));
	}

	public String getBranchValue() {
		// Element = action.getElementByFormatingXpath("Common Attribute Value",
		// "Branch");
		List<WebElement> elements = action.getElements("Branch");
		action.highligthElement(elements.get(1));
		if (elements.get(1).getText().trim().equals("—"))
			return "isEmpty";
		return elements.get(1).getText();
	}

	public String getComplexValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Complex");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getDivisionValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Division");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getRegionValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Region");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getCFAorACPMValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "CFA or ACPM Charter Holder?");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getWaiverorCompletedCourseValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Waive / completed course work");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getZoologicCourseRegistrationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Zoologic course work registration date");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getZoologicCourseCompletedValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Zoologic course work completed date");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getAwardsValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Awards/Citations/Certifications");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getAdditionalInformationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Additonal Information");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	private String requiredDocumentValue(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		Element = action.fluentWaitWebElement("Document Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element,
				"Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";
		for (WebElement E : documentValues) {
			if (E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
			}
		}
		int documents = documentValuesData.size() / 3;
		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i + 3;
		}
		if (documents > 1) {
			Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue + G + ",";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length() - 1);
		}
		tempData.clear();
		return requiredDocumentValue;
	}

	public String getDocumentTypeValue() {
		return requiredDocumentValue(0);
	}

	public String getDocumentLinkValue() {
		return requiredDocumentValue(1);
	}

	public String getDocumentCommentValue() {
		return requiredDocumentValue(2);
	}

	public String getExceptionorConditionApprovalValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Exception / Conditional Approval");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getExpirationDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Expiration Date");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getHomeOfficeCommentsValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Home Office Comments");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getApproverNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Approver Name");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getFAStatusValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Status");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getStatusDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Status Date");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getFollowUpDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Follow-up Date");
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getFollowUpValue() {
		// Element = action.getElementByFormatingXpath("Common Attribute Value",
		// "Follow-up");
		List<WebElement> elements = action.getElements("Follow-up");
		action.highligthElement(elements.get(1));
		if (elements.get(1).getText().trim().equals("—"))
			return "isEmpty";
		return elements.get(1).getText();
	}

	public HashMap<String, ArrayList<String>> getSortedDualStrategyData() {
		HashMap<String, ArrayList<String>> StrategiesMap = new HashMap<String, ArrayList<String>>();
		HashMap<String, ArrayList<String>> sortedAccessStrategiesMap = new HashMap<String, ArrayList<String>>();
		ArrayList<String> dataFromAccessTab = new ArrayList<String>();
		ArrayList<WebElement> rowRecordData = new ArrayList<WebElement>();
		String[] temp = new String[7];
		String FOACode = "";
		Element = action.getElementByFormatingXpath("Tabs And Data", "Associated Strategies");
		List<WebElement> elements = Element.findElements(By.xpath("./*"));
		action.moveToElement(elements.get(2));
		elements.get(2).click();
		action.pause(1000);
		if (elements.get(3).getText().contains("No SMA Dual Strategy associated")) {
			dataFromAccessTab.add("No SMA Dual Strategy associated");
			FOACode = "No FOA Code";
			StrategiesMap.put(FOACode, dataFromAccessTab);
		} else {
			Element = action.getElementByFormatingXpath("Rows in Grid as per Tab", "dual");
			List<WebElement> recordsInGrid = Element.findElements(By.xpath("./*"));
			for (WebElement webElement : recordsInGrid) {
				rowRecordData = (ArrayList<WebElement>) action.getElementsFromParentElement(webElement,
						"Common Strategy Record Tag");
				action.moveToElement(webElement);
				for (int i = 0; i < rowRecordData.size(); i++) {
					action.moveToElement(rowRecordData.get(i));
					temp[Integer.parseInt(rowRecordData.get(i).getAttribute("aria-colindex")) - 1] = rowRecordData
							.get(i).getText().trim();
				}
				for (String string : temp) {
					dataFromAccessTab.add(string);
				}
				FOACode = dataFromAccessTab.get(4);
				StrategiesMap.put(FOACode, dataFromAccessTab);
				dataFromAccessTab.clear();
				rowRecordData.clear();
			}
			sortedAccessStrategiesMap = sortHashMapBasedOnFOACode(StrategiesMap);
		}
		return sortedAccessStrategiesMap;
	}

	public HashMap<String, ArrayList<String>> getSortedSWPStrategyData() {
		HashMap<String, ArrayList<String>> StrategiesMap = new HashMap<String, ArrayList<String>>();
		HashMap<String, ArrayList<String>> sortedAccessStrategiesMap = new HashMap<String, ArrayList<String>>();
		ArrayList<String> dataFromAccessTab = new ArrayList<String>();
		ArrayList<WebElement> rowRecordData = new ArrayList<WebElement>();
		String[] temp = new String[7];
		String FOACode = "";
		Element = action.getElementByFormatingXpath("Tabs And Data", "Associated Strategies");
		List<WebElement> elements = Element.findElements(By.xpath("./*"));
		action.moveToElement(elements.get(4));
		elements.get(4).click();
		action.pause(1000);
		if (elements.get(5).getText().contains("No SMA Single - SWP/AAP Strategy associated")) {
			dataFromAccessTab.add("No SMA Single - SWP/AAP Strategy associated");
			FOACode = "No FOA Code";
			StrategiesMap.put(FOACode, dataFromAccessTab);
		} else {
			Element = action.getElementByFormatingXpath("Rows in Grid as per Tab", "aap");
			List<WebElement> recordsInGrid = Element.findElements(By.xpath("./*"));
			for (WebElement webElement : recordsInGrid) {
				rowRecordData = (ArrayList<WebElement>) action.getElementsFromParentElement(webElement,
						"Common Strategy Record Tag");
				action.moveToElement(webElement);
				for (int i = 0; i < rowRecordData.size(); i++) {
					action.moveToElement(rowRecordData.get(i));
					temp[Integer.parseInt(rowRecordData.get(i).getAttribute("aria-colindex")) - 1] = rowRecordData
							.get(i).getText().trim();
				}
				for (String string : temp) {
					dataFromAccessTab.add(string);
				}
				FOACode = dataFromAccessTab.get(4);
				StrategiesMap.put(FOACode, dataFromAccessTab);
				dataFromAccessTab.clear();
				rowRecordData.clear();
			}
			sortedAccessStrategiesMap = sortHashMapBasedOnFOACode(StrategiesMap);
		}
		return sortedAccessStrategiesMap;
	}

	public HashMap<String, ArrayList<String>> getSortedPMPStrategyData() {
		HashMap<String, ArrayList<String>> StrategiesMap = new HashMap<String, ArrayList<String>>();
		HashMap<String, ArrayList<String>> sortedAccessStrategiesMap = new HashMap<String, ArrayList<String>>();
		ArrayList<String> dataFromAccessTab = new ArrayList<String>();
		ArrayList<WebElement> rowRecordData = new ArrayList<WebElement>();
		String[] temp = new String[6];
		String FOACode = "";
		Element = action.getElementByFormatingXpath("Tabs And Data", "Associated Strategies");
		List<WebElement> elements = Element.findElements(By.xpath("./*"));
		action.moveToElement(elements.get(6));
		elements.get(6).click();
		action.pause(1000);
		if (elements.get(7).getText().contains("No PMP Strategy associated")) {
			dataFromAccessTab.add("No PMP Strategy associated");
			FOACode = "No FOA Code";
			StrategiesMap.put(FOACode, dataFromAccessTab);
		} else {
			Element = action.getElementByFormatingXpath("Rows in Grid as per Tab", "pmp");
			List<WebElement> recordsInGrid = Element.findElements(By.xpath("./*"));
			for (WebElement webElement : recordsInGrid) {
				rowRecordData = (ArrayList<WebElement>) action.getElementsFromParentElement(webElement,
						"Common Strategy Record Tag");
				action.moveToElement(webElement);
				for (int i = 0; i < rowRecordData.size(); i++) {
					action.moveToElement(rowRecordData.get(i));
					temp[Integer.parseInt(rowRecordData.get(i).getAttribute("aria-colindex")) - 1] = rowRecordData
							.get(i).getText().trim();
				}
				for (String string : temp) {
					dataFromAccessTab.add(string);
				}
				FOACode = dataFromAccessTab.get(4);
				StrategiesMap.put(FOACode, dataFromAccessTab);
				dataFromAccessTab.clear();
				rowRecordData.clear();
			}
			sortedAccessStrategiesMap = sortHashMapBasedOnFOACode(StrategiesMap);
		}
		return sortedAccessStrategiesMap;
	}

	public HashMap<String, ArrayList<String>> getSortedAccessStrategyData() {
		HashMap<String, ArrayList<String>> StrategiesMap = new HashMap<String, ArrayList<String>>();
		HashMap<String, ArrayList<String>> sortedAccessStrategiesMap = new HashMap<String, ArrayList<String>>();
		ArrayList<String> dataFromAccessTab = new ArrayList<String>();
		ArrayList<WebElement> rowRecordData = new ArrayList<WebElement>();
		String[] temp = new String[7];
		String FOACode = "";
		Element = action.getElementByFormatingXpath("Tabs And Data", "Associated Strategies");
		List<WebElement> elements = Element.findElements(By.xpath("./*"));
		action.moveToElement(elements.get(0));
		elements.get(0).click();
		action.pause(1000);
		if (elements.get(1).getText().contains("No SMA Single-Access strategy associated")) {
			dataFromAccessTab.add("No SMA Single-Access strategy associated");
			FOACode = "No FOA Code";
			StrategiesMap.put(FOACode, dataFromAccessTab);
		} else {
			Element = action.getElementByFormatingXpath("Rows in Grid as per Tab", "access");
			List<WebElement> recordsInGrid = Element.findElements(By.xpath("./*"));
			for (WebElement webElement : recordsInGrid) {
				rowRecordData = (ArrayList<WebElement>) action.getElementsFromParentElement(webElement,
						"Common Strategy Record Tag");
				action.moveToElement(webElement);
				for (int i = 0; i < rowRecordData.size(); i++) {
					action.moveToElement(rowRecordData.get(i));
					temp[Integer.parseInt(rowRecordData.get(i).getAttribute("aria-colindex")) - 1] = rowRecordData
							.get(i).getText().trim();
					/*
					 * if(Integer.parseInt(rowRecordData.get(i).getAttribute("aria-colindex")) == 3)
					 * { action.highligthElement(rowRecordData.get(i)); }
					 */
					if (temp[Integer.parseInt(rowRecordData.get(i).getAttribute("aria-colindex")) - 1].isEmpty()) {
						temp[Integer.parseInt(rowRecordData.get(i).getAttribute("aria-colindex")) - 1] = "isEmpty";
					}
				}
				for (String string : temp) {
					dataFromAccessTab.add(string);
				}
				FOACode = dataFromAccessTab.get(4);
				StrategiesMap.put(FOACode, dataFromAccessTab);
				dataFromAccessTab.clear();
				rowRecordData.clear();
			}
			sortedAccessStrategiesMap = sortHashMapBasedOnFOACode(StrategiesMap);
		}
		return sortedAccessStrategiesMap;
	}

	private HashMap<String, ArrayList<String>> sortHashMapBasedOnFOACode(
			HashMap<String, ArrayList<String>> StrategiesMap) {
		Set<Entry<String, ArrayList<String>>> EntrySet = StrategiesMap.entrySet();
		List<Entry<String, ArrayList<String>>> entryList = new ArrayList<Entry<String, ArrayList<String>>>(EntrySet);
		// sort based on FOA Code
		Collections.sort(entryList, (o1, o2) -> o1.getKey().compareTo(o2.getKey()));
		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, ArrayList<String>> sortedHashMap = new LinkedHashMap<String, ArrayList<String>>();
		for (Entry<String, ArrayList<String>> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}
		/*
		 * for (String countryKey : sortedHashMap.keySet()) {
		 * System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		 * 
		 * }
		 */
		return sortedHashMap;
	}

	public Boolean isAssociatedStrategiesGridDisplayed() {
		Element = action.getElementByFormatingXpath("Check for Records availability", "Associated Strategies");
		List<WebElement> temp = Element.findElements(By.xpath("./*"));
		if (temp.size() > 2) {
			if (temp.get(2).getText().contains("No associated strategies"))
				return false;
		}
		return true;
	}

	public boolean areDocumentsDisplayedInUI() {
		List<WebElement> elements = action.getElements("Page Header");
		if (elements.size() > 3) {
			return true;
		}
		return false;
	}

	public boolean isAssociatedStartegyDisplayed(String strategy) {
		Element = action.getElementByFormatingXpath("Associate Strategy Common Attribute Value", strategy);
		action.highligthElement(Element);
		action.scrollToElement(Element);
		action.click(Element);
		return action.isDisplayed(Element);
	}

	public void isStrategyTableDisplayed(String strategy) {
		if (isAssociatedStartegyDisplayed(strategy)) {
			Element = action.getElementByFormatingXpath("Common No Strategy Associated Value", strategy);
			action.highligthElement(Element);
			action.scrollToElement(Element);
			Assert.assertTrue(action.isDisplayed(Element));
		}
	}

	public void isStrategyTableDisplayedWithTable(String strategy) {
		if (isAssociatedStartegyDisplayed(strategy)) {
			Element = action.getElementByFormatingXpath("Associate Strategy Common Attribute Table", strategy);
			action.highligthElement(Element);
			action.scrollToElement(Element);
			Assert.assertTrue(action.isDisplayed(Element));
		}
	}

	public String getFateamName() {
		Element = action.getElement("FA Team Name");
		action.highligthElement(Element);
		return Element.getText();
	}

	public void verifyFATeamTab() {
		Action.pause(2000);
		Element = (WebElement) action.getElementByJavascript("FA Teams Tab");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void clickOnFATeamTab() {
		Action.pause(2000);
		Element = (WebElement) action.getElementByJavascript("FA Teams Tab");
		Element.click();
	}

	public Integer getFaTeamCount() {
		Element = (WebElement) action.getElementByJavascript("FA Teams Tab");
		String count = Element.getText().split(" ")[2];
		// System.out.println(Element.getText());
		// System.out.println(Element.getText().split(" ")[2]);
		// System.out.println(count.substring(1, count.length()-1));
		return Integer.parseInt(count.substring(1, count.length() - 1));
	}

	public boolean isUserOnViewFATeamPage() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("Header");
		action.highligthElement(Element);
		if (Element.getText().equals("View FA Team")) {
			return true;
		}
		return false;
	}

	public String getFaTeamDetailsText(String field) {
		Element = action.getElementByFormatingXpath("Common FATeam Value", field);
		action.scrollToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public void clickOnFATeamExport() {
		Action.pause(2000);
		Element = action.fluentWaitWebElement("FA Team Export Button");
		action.moveToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
		Action.pause(12000);
	}

	public boolean verifyTooltipOfFATeamExport() {
		Action.pause(2000);
		Element = action.fluentWaitWebElement("FA Team Export Button");
		action.moveToElement(Element);
		Element = action.fluentWaitWebElement("FA Team Export Tooltip");
		action.highligthElement(Element);
		return Element.isDisplayed();
	}

	public String getDocumentValuesAsExport(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		String requiredDocumentValue = "";
		// Element = action.fluentWaitWebElement("Document Grid");
		if (action.isPresent("Document Grid")) {
			List<WebElement> documentValuesData = action.getElements("Document Values");
			ArrayList<String> tempData = new ArrayList<String>();

			int documents = documentValuesData.size() / 3;
			for (int j = 0; j < documents; j++) {
				requiredDocumentValue = documentValuesData.get(i).getText();
				tempData.add(requiredDocumentValue);
				action.moveToElement(documentValuesData.get(i));
				action.highligthElement(documentValuesData.get(i));
				i = i + 3;
			}
			int m = 1;
			if (documents > 1) {
				// Collections.sort(tempData);
				requiredDocumentValue = "";
				for (String str : tempData) {
					requiredDocumentValue = requiredDocumentValue + m + "." + str + ", ";
					m++;
				}
				// System.out.println("after for loop -"+requiredDocumentValue );
				requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length() - 2);
				// System.out.println("after substring -"+requiredDocumentValue );
			} else {
				requiredDocumentValue = m + "." + requiredDocumentValue;
			}

			tempData.clear();
		}

		return requiredDocumentValue;
	}
	
	public Integer getFaCount() {
		Element = (WebElement) action.getElementByJavascript("FAs Tab");
		String count = Element.getText().split(" ")[1];
		 System.out.println(Element.getText());
		 System.out.println(Element.getText().split(" ")[1]);
		 System.out.println(count.substring(1, count.length()-1));
		return Integer.parseInt(count.substring(1, count.length() - 1));
	}
	
	public String getDataFromViewPageforExport(String data) {
		switch(data) {
			case "Branch Manager/Market Head":
				uiValue = getManagerHeadValue();
				break;
			case "FA Name":
				uiValue = getFANameValue();
				break;
			case "FA Email":
				uiValue = getFAEmailValue();
				break;
			case "FAID(s)":
				uiValue = getFAIDValue();
				break;
			case "CRD#(s)":
				uiValue = getCRDValue();
				break;
			case "Universal ID(s)":
				uiValue = getUniversalIDValue();
				break;
			case "Is nomination for a recruit?":
				uiValue = getNominationForRecruitValue();
				break;
			case "Recruit Hire Date":
				uiValue = getRecruitHireDataValue();
				break;
			case "Prior Firm":
				uiValue = getPriorFirmValue();
				break;
			case "Previously Approved for FA Discretionary Program":
				uiValue = getPreviouslyApprovedorNotForFADiscretionaryProgramValue();
				break;
			case "Name of FA Discretionary Program":
				uiValue = getFADiscretionaryProgramValue();
				break;
			case "FA Segment":
				uiValue = getFASegmentValue();
				break;
			case "Re-Nomination":
				uiValue = getRenominationValue();
				break;
			case "Re-Nomination Date":
				uiValue = getRenominationDateValue();
				break;
			case "Length of Series 7 Registration":
				uiValue = getSeries7RegistrationValue();
				break;
			case "Length of Series 65 or 66 Registration":
				uiValue = getSeries65RegistrationValue();
				break;
			case "Length of Service as a FA":
				uiValue = getLenghtOfServiceAsFAValue();
				break;
			case "FA Assets Under Management (AUM in $)":
				uiValue = getAUMValue();
				break;
			case "Anticipated Percentage of Overall Business in PMP/AAP":
				uiValue = getAnticipatedPercentageValue();
				break;
			case "Branch":
				uiValue = getBranchValue();
				break;
			case "Complex":
				uiValue = getComplexValue();
				break;
			case "Division":
				uiValue = getDivisionValue();
				break;
			case "Region":
				uiValue = getRegionValue();
				break;
			case "CFA or ACPM Charter Holder?":
				uiValue = getCFAorACPMValue();
				break;
			case "Waive / completed course work":
				uiValue = getWaiverorCompletedCourseValue();
				break;
			case "Awards/Citations/Certifications":
				uiValue = getAwardsValue();
				break;
			case "Zoologic course work registration date":
				uiValue = getZoologicCourseRegistrationValue();
				break;
			case "Zoologic course work completed date":
				uiValue = getZoologicCourseCompletedValue();
				break;
			case "Additional Information":
				uiValue = getAdditionalInformationValue();
				break;
			case "Exception / Conditional Approval":
				uiValue = getExceptionorConditionApprovalValue();
				break;
			case "Expiration Date":
				uiValue = getExpirationDateValue();
				break;
			case "Home Office Comments":
				uiValue = getHomeOfficeCommentsValue();
				break;
			case "Approver Name":
				uiValue = getApproverNameValue();
				break;
			case "FA Status":
				uiValue = getFAStatusValue();
				break;
			case "Status Date":
				uiValue = getStatusDateValue();
				break;
			case "Follow-up Date":
				uiValue = getFollowUpDateValue();
				break;
			case "Follow-up":
				uiValue = getFollowUpValue();
				break;
			case "Document Link":
				uiValue = requiredDocumentValueForExport(1);
				break;
			case "Document Type":
				uiValue = requiredDocumentValueForExport(0);
				break;
			case "Document Description":
				uiValue = requiredDocumentValueForExport(2);
				break;
			default:
				uiValue = "NotChanged";
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
		return uiValue;
	}
	
	private String requiredDocumentValueForExport(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		Element = action.fluentWaitWebElement("Document Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element,
				"Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";
		for (WebElement E : documentValues) {
			if (E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
			}
		}
		int documents = documentValuesData.size() / 3;
		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i + 3;
		}
		if (documents > 1) {
			//Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue + G + ", ";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length() - 2);
		}
		tempData.clear();
		System.out.println("requiredDocumentValue:-"+requiredDocumentValue);
		return requiredDocumentValue;
	}

	public String getTextfromGridforRow(String value) {
		myElement = action.getElementByFormatingXpath("Grid Common Row value", value);
		action.moveToElement(myElement);
		return myElement.getText();
	}

	public void clickOnPrintButton() {
		Action.pause(2000);
		Element = action.fluentWaitWebElement("Print Button");
		action.moveToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
		
	}

	
}
