package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdateFAReviewPage {
	
	Action action;
	public UpdateFAReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element,Highlight;
	
	public ArrayList<String> getHeadersInReviewPage() {
		List<WebElement> elements = action.getElements("Page Header in Review");
		ArrayList<String> data = new ArrayList<String>();
		for (WebElement E : elements) {
			
			data.add(E.getText());
		}
		return data;
	}
	
	public String getManagerHeadValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Branch Manager/Market Head");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFANameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Name");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFAEmailValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Email");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFAIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA ID(s)");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getUniversalIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Universal ID");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getCRDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "CRD#(s)");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getNominationForRecruitValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Is nomination for a recruit?");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getRecruitHireDataValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Recruit Hire Date");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPriorFirmValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Prior Firm");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPreviouslyApprovedorNotForFADiscretionaryProgramValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Previously Approved for FA Discretionary Program?");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFADiscretionaryProgramValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Discretionary Program Name");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFASegmentValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Segment");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getRenominationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Re-Nomination");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getRenominationDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Re-Nomination Date");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getSeries7RegistrationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Length of Series 7 Registration");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getSeries65RegistrationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Length of Series 65 or 66 Registration");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getLenghtOfServiceAsFAValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Length of Service as a FA");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getAUMValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Assets Under Management (AUM in $)");
		action.highligthElement(Element);
		DecimalFormat df = new DecimalFormat(".0000");
		return df.format(Integer.parseInt(Element.getText()));
	}

	public String getAnticipatedPercentageValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Anticipated Percentage of Overall Business in PMP/AAP");
		action.highligthElement(Element);
		DecimalFormat df = new DecimalFormat(".00");
		return df.format(Integer.parseInt(Element.getText()));
	}

	public String getBranchValue() {
		//Element = action.getElementByFormatingXpath("Common Attribute Value", "Branch");
		List<WebElement> elements = action.getElements("Branch");
		action.highligthElement(elements.get(1));
		return elements.get(1).getText();
	}

	public String getComplexValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Complex");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getDivisionValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Division");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getRegionValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Region");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getCFAorACPMValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "CFA or ACPM Charter Holder?");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getWaiverorCompletedCourseValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Waive / completed course work");
		action.moveToElement(Element);
		action.pause(5000);
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		
		return Element.getText();
	}

	public String getZoologicCourseRegistrationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Zoologic course work registration date");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getZoologicCourseCompletedValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Zoologic course work completed date");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getAwardsValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Awards/Citations/Certifications");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getAdditionalInformationValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Additonal Information");
		action.highligthElement(Element);
		return Element.getText();
	}

	private String requiredDocumentValue(int i) {
		/*
		 *  Document Type		--> i=0
			Document Link		--> i=1
			Document Comment	--> i=2
			
		*/
		Element = action.fluentWaitWebElement("Document Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element, "Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";
		
		
		for (WebElement E : documentValues) {
			if(E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
				}
			
		}
		int documents = documentValuesData.size()/3;
		
		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i+3;
			System.out.println(requiredDocumentValue);
		}
		
		if(documents > 1) {
			Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue+G+",";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
		}
		tempData.clear();
		
		return requiredDocumentValue;
	}
	
	public String getDocumentTypeValue() {
		
		return requiredDocumentValue(0);
	}


	public String getDocumentLinkValue() {
		return requiredDocumentValue(1);
	}

	public String getDocumentCommentValue() {
		return requiredDocumentValue(2);
	}

	public String getExceptionorConditionApprovalValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Exception / Conditional Approval");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getExpirationDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Expiration Date");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getHomeOfficeCommentsValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Home Office Comments");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getApproverNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Approver Name");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFAStatusValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "FA Status");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getStatusDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Status Date");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFollowUpDateValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Follow-up Date");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFollowUpValue() {
		
		//Element = action.getElementByFormatingXpath("Common Attribute Value", "Follow-up");
		List<WebElement> elements = action.getElements("Follow-up");
		action.highligthElement(elements.get(1));
		return elements.get(1).getText();
	}

	public boolean isUserOnReviewPage() {
		Element = (WebElement) action.waitForJSWebElement("Header");
		if(Element.getText().equals("Review")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
		
	}

	public void clickOnPreviousButton() {
		Element = action.fluentWaitWebElement("PREVIOUS");
		Element.click();
		
	}

}
