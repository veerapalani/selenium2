package qa.unicorn.ad.productmaster.webui.pages;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Optional;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;

public class CreatePMPStrategyBenchmarkPage {

	Action action;
	public CreatePMPStrategyBenchmarkPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element,Highlight;
	String[] benchmarkName;
	String data,percentage;
	int size;
	String PMPDefaultValue;
	String PMPDefaultValuePercentage;
	int loopCount;
	
	public boolean isUserOnBenchmarkPage() {
		boolean flag = false;
		Element = action.waitForJSWebElement("Benchmark Header");
		if(Element.getText().equals("Benchmark")) {
			flag = true;
		    action.highligthElement(Element);
		}
		return flag;
		
	}
	
	public void myClear(WebElement element){        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void clickOnNext() {
		
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("Next");
		Element.click();
	}

	public void selectCustom() {
		
		Element =(WebElement) action.fluentWaitForJSWebElement("Custom");
		Element.click();
		
	}
	
	public void enterCustomBenchmark(String replace, String replace2, String string, String benchmarkCategory, int benchmarkCount) {
		if(benchmarkCategory.equalsIgnoreCase("Custom")) {
			Element = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
			action.click(Element);
			Highlight = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace2), 10);
			Highlight = Highlight.findElement(By.linkText(string));
			action.scrollToElement(Highlight);
			action.highligthElement(Highlight);
			action.click(Highlight);
			
		}
		
	}

	public void enterCustomBenchmarkPercentage(String replace, String string, String benchmarkCategory, int benchmarkCount) {
		if(benchmarkCategory.equalsIgnoreCase("Custom")) {
			loopCount = 0;
			//Finding Element should be placed inside as element is changed after using send keys and need to be called again
			do {
				Element = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
				Element.click();
				myClear(Element);
				action.sendKeys(Element, string);
			} while (!(Float.parseFloat(string + "f") == Float.parseFloat(getPercentageithValuefromUI(benchmarkCount) + "f")) && ++loopCount < 10);
			if(loopCount >= 10)
				Assert.fail("User is not able to input Text into Text Field");
			
			((WebElement) action.fluentWaitForJSWebElement("Custom")).click();
		}
		
	}
	
	public void addNewBenchmark() {
		Element = action.fluentWaitWebElement("Add New Benchmark");
		Element.click();
		
	}

	public void enterCustomBenchmarkReason(String customBenchmarkReason) {
		loopCount = 0;
		do {
			Element =(WebElement) action.fluentWaitForJSWebElement("Custom Benchmark Reason");
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, customBenchmarkReason);
		} while (!(getBenchmarkReason().equals(customBenchmarkReason)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
		
	}

	public void clickOnViewDetails() {
		
		action.scrollToBottom();
		
		Element = action.fluentWaitWebElement("View Details");
		Element.click();
		
	}

	public String getDefaultValueAutopopulated() {

		//The below changes to store values in format followed in Excel
		action.waitForJSWebElement("Name");
		Element = action.getElement("Prepopulated PMP Default");
		PMPDefaultValue = Element.getText();
		System.out.println("PMPDefaultValue:"+PMPDefaultValue);
		String Data = "ForExcelValidation - "+PMPDefaultValue;
		Element = action.getElement("Prepopulated PMP Default Percentage");
		PMPDefaultValuePercentage = Element.getText();
		System.out.println("PMPDefaultValuePercentage:"+PMPDefaultValuePercentage);
		PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length()-1);
		DecimalFormat df = new DecimalFormat(".00");
		return Data+":"+df.format(Double.parseDouble(PMPDefaultValuePercentage));
	}

	public void clickOnCrossIcon() {
		List<WebElement> Element =(List<WebElement>) action.getElements("Cross Icon");
		Element.get(0).click();
		
		action.pause(3000);
		
	}

	public int clickOnBenchmarkDropdown(String BenchmarkDropdownNumber, String replace) {
		Element = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", BenchmarkDropdownNumber), 10);
		//Element = action.waitForJSWebElement("Investment Style");
		action.click(Element);
		
		Highlight = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		//subtracting Select, Header and Footer from UI
		return li.size() - 3;
	}

	public void clickOnPrevious() {

		action.scrollToBottom();
		action.fluentWaitWebElement("PREVIOUS").click();
		
	}

	public String getBenchmarkithValuefromUI(int i) {
		String benchmarkValue = action.getElementByFormatingXpath("Benchmark From UI", i).getAttribute("value");
		
			Element = action.getElementByFormatingXpath("Benchmark Value From UI", benchmarkValue);
			
			return Element.getAttribute("name");
	}

	public Float getPercentageithValuefromUI(int i) {
		Element = action.getElementByFormatingXpath("Percentage Value From UI", i);
		if(Element.getAttribute("value").isEmpty()) {
			return Float.MAX_VALUE;
		}
		return Float.parseFloat(Element.getAttribute("value"));
	}

	public void deleteallcustomBenchmarks() {
		
		action.scrollToBottom();
		List<WebElement> elements = action.getElements("Delete Icon");
		
		int count = elements.size();
		if(count > 0) {
		for (int i = count; i > 0; i--) {
			action.moveToElement(elements.get(i-1));
			action.pause(1000);
			elements.get(i-1).click();
		}
		}
		Element =(WebElement) action.fluentWaitForJSWebElement("Custom Benchmark Reason");
		Element.clear();
		
		
	}

	public String getBenchmarkCategory() {
		String pmpDefaultRadio =((WebElement) action.fluentWaitForJSWebElement("PMP Default")).getAttribute("class");
		String customRadio =  ((WebElement) action.fluentWaitForJSWebElement("Custom")).getAttribute("class");
		
		if(pmpDefaultRadio.equals("checked")){
			return "PMP Default";
		}
		if(customRadio.equals("checked")){
			return "Custom";
		}
		return "";
	}

	public String getBenchmarkReason() {
		List<WebElement> Elements = action.getElements("Custom benchmark Reason Value");
		if(Elements.size() > 0) {
			String data = Elements.get(0).getAttribute("value");
			if(data.isEmpty()) {
				return "isEmpty";
			}
			return data;
		}
		return "isEmpty";
	}

	public int getbenchmarkscount() {
		List<WebElement> Elements = action.getElements("Benchmarks Count from UI");
		return Elements.size();
	}

	public boolean isLabelVisibleinBenchmarkPage(String label) {
		
		Element = (WebElement) action.getElementByFormatingXpath("Attribute Header", label);
		
		if(Element.getText().equals(label)) {
			return true;
		}
		return false;
	}

	public void clickOnResetButton() {
		
		Element = action.getElement("RESET");
		Element.click();
		
	}

	public boolean isAddNewBenchmarkOptionNotVisible() {
		
			List<WebElement> Elements = action.getElements("Add New Benchmark");
			if(Elements.size() == 0) {
				return true;
			}
			
			return false;
		
	}

	public boolean checkActiveBenchmarkCount(String locatorValueCustomBenchmark, String locatorValueCustomBenchmarkHighlight) throws SQLException {

	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
	String mandatorydetails, sheetName, uiValue = "";
	int rowIndex,columnIndex;
	
		Element = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", locatorValueCustomBenchmark), 10);
		//Element = action.waitForJSWebElement("Investment Style");
		action.click(Element);
		Highlight = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", locatorValueCustomBenchmarkHighlight), 10);
		List<WebElement> li2 = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		//size of li2 has header,footer and select option included too
		//Removing above and comparing results in DB
		int sizeFromUI = li2.size();
		sizeFromUI = sizeFromUI-3;
		pmdb.DBConnectionStart();
    	
    	String dbDataIterator;
    	sheetName = "Query";
    	//sheet = exlObj.getSheet("Query");
    	ResultSet rs;
    
				dbDataIterator = "testnull";
				
				
				String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 7, 1); 
						//(String) exlObj.getCellData(sheet, 7, 1);
	    		
	    		rs= DBManager.executeSelectQuery(SQLquery);
	    		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 7, 2); 
	    				//(String) exlObj.getCellData(sheet, 7, 2);
	    		while(rs.next()) {
	    			
	    				dbDataIterator = rs.getString(labelname);
	    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    				dbDataIterator = "isEmpty";
		    			}
	    				
	    		}
	    		//to handle Zero records from DB 
	    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
	    			dbDataIterator = "isEmpty";
	    		}
	    		
					//System.out.println(dbDataIterator);
	    		int sizeFromDB = Integer.parseInt(dbDataIterator);
	    		
					
					
					//exlObj.closeWorkBook();
			    	//pmdb.DBConnectionClose();
	    		System.out.println(sizeFromDB + " :DB");
	    		System.out.println(sizeFromUI+ " :UI");
			    if(sizeFromDB == sizeFromUI) {
			    	return true;
			    }
				
			return false;
		
	}
	
	public String getBenchmarkName() {
		action.waitForJSWebElement("Name");
		Element = action.getElement("Prepopulated PMP Default");
		action.highligthElement(Element);
		PMPDefaultValue = Element.getText();
		return PMPDefaultValue;
	}

	public String getBenchmarkPercentage() {
		Element = action.getElement("Prepopulated PMP Default Percentage");
		action.highligthElement(Element);
		PMPDefaultValuePercentage = Element.getText();
		PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length()-1);
		//DecimalFormat df = new DecimalFormat(".00");
		//return df.format(Double.parseDouble(PMPDefaultValuePercentage));
		return PMPDefaultValuePercentage;
	}
}
