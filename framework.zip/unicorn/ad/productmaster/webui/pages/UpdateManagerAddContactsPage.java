package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class UpdateManagerAddContactsPage {

	Action action;

	public UpdateManagerAddContactsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	WebElement Element, Highlight;

	public boolean isUserOnAddContactsPage() {
		Element = (WebElement) action.waitForJSWebElement("Header");
		if (Element.getText().equals("Add Contacts")) {
			action.highligthElement(Element);
			Reporter.addCompleteScreenCapture();
			return true;
		}
		return false;
	}

	public void clickOnAddAnotherContact() {
		Element = action.fluentWaitWebElement("Add Another Contact");
		Element.click();
		action.pause(1000);
		isUserOnAddContactsPage();

	}

	public void entercontactType(String contactType) {
		Element = action.waitForJSWebElement("Contact Type");
		action.click(Element);
		Highlight = (WebElement) action.fluentWaitForJSWebElement("Contact Type Dropdown List");
		Highlight = Highlight.findElement(By.linkText(contactType));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);

	}

	public void entercontactDescription(String contactDescription) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact Description");
		Element.click();
		Element.clear();
		Element.sendKeys(contactDescription);
		// using attribute id to wait for Value from excel to go to UI
		Highlight = action.getElementByFormatingXpath("Common Attribute Value", "description");
		PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), contactDescription, Highlight);

	}

	public void entercontactFirstName(String contactFirstName) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact First Name");
		Element.click();
		Element.clear();
		Element.sendKeys(contactFirstName);
		// using attribute id to wait for Value from excel to go to UI
		Highlight = action.getElementByFormatingXpath("Common Attribute Value", "contactFirstName");
		PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), contactFirstName, Highlight);

	}

	public void entercontactMiddleName(String contactMiddleName) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact Middle Name");
		Element.click();
		Element.clear();
		Element.sendKeys(contactMiddleName);
		// using attribute id to wait for Value from excel to go to UI
		Highlight = action.getElementByFormatingXpath("Common Attribute Value", "contactMiddleName");
		PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), contactMiddleName, Highlight);

	}

	public void entercontactLastName(String contactLastName) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact Last Name");
		Element.click();
		Element.clear();
		Element.sendKeys(contactLastName);
		// using attribute id to wait for Value from excel to go to UI
		Highlight = action.getElementByFormatingXpath("Common Attribute Value", "contactLastName");
		PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), contactLastName, Highlight);

	}

	public void entercontactAddress(String contactAddress) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact Address");
		Element.click();
		Element.clear();
		Element.sendKeys(contactAddress);
		// using attribute id to wait for Value from excel to go to UI
		Highlight = action.getElementByFormatingXpath("Common Attribute Value", "contactAddress");
		PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), contactAddress, Highlight);

	}

	public void entercontactCity(String contactCity) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact City");
		Element.click();
		Element.clear();
		Element.sendKeys(contactCity);
		// using attribute id to wait for Value from excel to go to UI
		Highlight = action.getElementByFormatingXpath("Common Attribute Value", "contactCity");
		PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), contactCity, Highlight);

	}

	public void entercontactState(String contactState) {
		Element = action.waitForJSWebElement("Contact State");
		action.click(Element);
		Highlight = (WebElement) action.fluentWaitForJSWebElement("Contact State Dropdown List");
		Highlight = Highlight.findElement(By.linkText(contactState));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);

	}

	public void entercontactPostalCode(String contactPostalCode) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact Postal Code");
		Element.click();
		Element.clear();
		Element.sendKeys(contactPostalCode);
		// using attribute id to wait for Value from excel to go to UI
		Highlight = action.getElementByFormatingXpath("Common Attribute Value", "contactPostalCode");
		PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), contactPostalCode, Highlight);

	}

	public void entercontactCountry(String contactCountry) {
		Element = action.waitForJSWebElement("Contact Country");
		action.click(Element);
		Highlight = (WebElement) action.fluentWaitForJSWebElement("Contact Country Dropdown List");
		Highlight = Highlight.findElement(By.linkText(contactCountry));
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);

	}

	public void entercontactEmailAddress(String contactEmailAddress) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact Email Address");
		Element.click();
		Element.clear();
		Element.sendKeys(contactEmailAddress);
		// using attribute id to wait for Value from excel to go to UI
		Highlight = action.getElementByFormatingXpath("Common Attribute Value", "emailAddress");
		PMPageGeneric.waitForTextToAppear(WebDriverManager.getDriver(), contactEmailAddress, Highlight);

	}

	public void entercontactPhoneNumber(String contactPhoneNumber) {
		Element = (WebElement) action.fluentWaitForJSWebElement("Contact Phone Number");
		Element.click();
		Element.clear();
		Element.sendKeys(contactPhoneNumber);
	}

	public void clickOnNext() {

		Element = action.fluentWaitWebElement("Next");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		Element.click();

	}

	public void clickOnAddContact() {

		Element = action.fluentWaitWebElement("Add Contact");
		Element.click();
		isUserOnAddContactsPage();

	}

	private List<WebElement> getContacts() {
		Element = action.fluentWaitWebElement("Contact List");
		List<WebElement> elements = action.getElementsFromParentElement(Element, "Contact Count");
		return elements;
	}

	private String requiredContactValue(int i) {
		/*
		 * Contact Type --> i=0 Contact Description --> i=1 Contact First Name --> i=2
		 * Contact Middle Name --> i=3 Contact Last Name` --> i=4 Contact Address -->
		 * i=5 Contact City --> i=6 Contact State --> i=7 Contact Postal Code --> i=8
		 * Contact Country --> i=9 Contact Email Address-> i=10 Contact Phone Number-->
		 * i=11
		 * 
		 */
		List<WebElement> contacts = getContacts();
		ArrayList<String> tempData = new ArrayList<String>();
		String requiredContactValue = "";
		for (WebElement webElement : contacts) {
			List<WebElement> contactValues = action.getElementsFromParentElement(webElement,
					"Contact Common Attribute");

			requiredContactValue = contactValues.get(i).getText();
			tempData.add(requiredContactValue);
			action.moveToElement(contactValues.get(i));
			action.highligthElement(contactValues.get(i));

		}
		if (contacts.size() > 1) {
			Collections.sort(tempData);
			requiredContactValue = "";
			for (String G : tempData) {
				requiredContactValue = requiredContactValue + G + ",";
			}
			requiredContactValue = requiredContactValue.substring(0, requiredContactValue.length() - 1);
		}
		tempData.clear();
		if (i == 11) {
			requiredContactValue = requiredContactValue.replace("(", "");
			requiredContactValue = requiredContactValue.replace(")", "");
		}
		return requiredContactValue;
	}

	public String getContactTypeValue() {

		return requiredContactValue(0);
	}

	public String getContactDescriptionValue() {

		return requiredContactValue(1);
	}

	public String getContactFirstNameValue() {
		return requiredContactValue(2);
	}

	public String getContactMiddleNameValue() {
		return requiredContactValue(3);
	}

	public String getContactLastNameValue() {
		return requiredContactValue(4);
	}

	public String getContactAddressValue() {
		return requiredContactValue(5);
	}

	public String getContactCityValue() {
		return requiredContactValue(6);
	}

	public String getContactStateValue() {
		return requiredContactValue(7);
	}

	public String getContactPostalCodeValue() {
		return requiredContactValue(8);
	}

	public String getContactCountryValue() {
		return requiredContactValue(9);
	}

	public String getContactEmailAddressValue() {
		return requiredContactValue(10);
	}

	public String getContactPhoneNumberValue() {
		return requiredContactValue(11);
	}

	public int getContactCount() {
		List<WebElement> elements = getContacts();
		return elements.size();
	}

	public void deleteContact() {

		List<WebElement> elements = action.getElements("Delete Contacts");

		elements.get(elements.size() - 1).click();
		action.pause(1000);
		isUserOnAddContactsPage();

	}

	public void clickOnPrevious() {
		Element = action.fluentWaitWebElement("Previous");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		Element.click();
	}

	public ArrayList<String> getDropdownValuesDisplayedInUI(String dropdownName) {

		String replacedata = "";

		ArrayList<String> tempData = new ArrayList<String>();

		String uiIterator = "testNull";

		switch (dropdownName) {
		case "Type":
			replacedata = "type";
			break;
		case "Country":
			replacedata = "contactCountry";
			break;
		case "State":
			replacedata = "contactState";
			break;
		default:
			break;
		}

		Highlight = action.getElementByFormatingXpath("Common Dropdown List", replacedata);
		List<WebElement> dropdownValuesFromUI = action.getElementsFromParentElement(Highlight,
				"List value of any dropdown");

		for (WebElement E : dropdownValuesFromUI) {

			uiIterator = E.getText();
			tempData.add(uiIterator);
		}
		// to handle Zero records from DB
		if (uiIterator.equalsIgnoreCase("testnull")) {
			uiIterator = "isEmpty";
			tempData.add(uiIterator);
		}
		// to handle multiple values for same column
		if (tempData.size() > 1) {
			Collections.sort(tempData);
		}

		return tempData;
	}

	public boolean areContactsAvailableInUI() {
		List<WebElement> elements = getContacts();
		// action.fluentWaitWebElements("Delete Contacts");
		// action.getElements("Delete Contacts");
		if (elements.size() > 0)
			return true;
		else
			return false;
	}

	public void clickOnDeleteIconofContactDetails() throws InterruptedException {
		WebElement ele = action.getElement("Delete Icon of Contact Details2");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}

	public void clickOnDeleteIconofFirmContactDetails() throws InterruptedException {
		WebElement ele = action.getElement("Delete Icon of Contact Details1");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}

}
