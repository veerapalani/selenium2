package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdateManagerReviewPage {

	Action action;

	public UpdateManagerReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	WebElement Element, Header;

	public boolean isUserOnReviewPage() {
		Element = (WebElement) action.waitForJSWebElement("Header");
		if (Element.getText().equals("Review")) {
			action.highligthElement(Element);
			Reporter.addCompleteScreenCapture();
			return true;
		}
		return false;
	}

	public void verifyReviewContactsHeader() throws InterruptedException {
		WebElement ele = action.getElement("Review Contacts Header");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		Thread.sleep(1000);
	}

	public void verifyReviewDocumentLinksHeader() throws InterruptedException {
		WebElement ele = action.getElement("Review Document Links Header");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		Thread.sleep(1000);
	}

	public void verifyFirmContactErrorMessage(String strArg1) throws InterruptedException {
		WebElement ele = action.getElement("Firm Contact Error Message");
		action.highligthElement(ele);
		System.out.println(ele.getText());
		Reporter.addCompleteScreenCapture();
		Assert.assertEquals(ele.getText(), strArg1);
		Thread.sleep(1000);
	}

	public void verifyIsSubmitButtondisabled() {
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("SUBMIT");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		String value = action.getAttribute(Element, "disabled");
		System.out.println(value);
		if (value.equalsIgnoreCase("true")) {
			Reporter.addStepLog("Submit Button is Disabled to proceed further for updation");
		} else {
			Reporter.addStepLog("Submit Button is Enabled to proceed further for updation");
		}
	}

	public String getManagerNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Manager Name");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFirmNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Firm Name");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getFirmWebsiteValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Firm Website");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getVestmarkManagerNameValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Vestmark Name");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getTaxPayerIdentificationNumberValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Taxpayer Identification Number");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getLargeTraderIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Large Trader ID");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getdtccIDValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "DTCC ID");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getStatusValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "Status");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String get4EyeCheckOverrideValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "4 Eye Check Override");
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getUBSSubsidiaryValue() {
		Element = action.getElementByFormatingXpath("Common Attribute Value", "UBS Subsidiary");
		action.highligthElement(Element);
		return Element.getText();
	}

	private List<WebElement> getContacts() {
		Element = action.fluentWaitWebElement("Contact List");
		List<WebElement> elements = action.getElementsFromParentElement(Element, "Contact Count");
		return elements;
	}

	private String requiredContactValue(int i) {
		/*
		 * Contact Type --> i=0 Contact Description --> i=1 Contact First Name --> i=2
		 * Contact Middle Name --> i=3 Contact Last Name` --> i=4 Contact Address -->
		 * i=5 Contact City --> i=6 Contact State --> i=7 Contact Postal Code --> i=8
		 * Contact Country --> i=9 Contact Email Address-> i=10 Contact Phone Number-->
		 * i=11
		 * 
		 */
		List<WebElement> contacts = getContacts();
		ArrayList<String> tempData = new ArrayList<String>();
		String requiredContactValue = "";
		for (WebElement webElement : contacts) {
			List<WebElement> contactValues = action.getElementsFromParentElement(webElement,
					"Contact Common Attribute");

			requiredContactValue = contactValues.get(i).getText();
			tempData.add(requiredContactValue);
			action.moveToElement(contactValues.get(i));
			action.highligthElement(contactValues.get(i));

		}
		if (contacts.size() > 1) {
			Collections.sort(tempData);
			requiredContactValue = "";
			for (String G : tempData) {
				requiredContactValue = requiredContactValue + G + ",";
			}
			requiredContactValue = requiredContactValue.substring(0, requiredContactValue.length() - 1);
		}
		tempData.clear();
		if (i == 11) {
			requiredContactValue = requiredContactValue.replace("(", "");
			requiredContactValue = requiredContactValue.replace(")", "");
		}
		return requiredContactValue;
	}

	public String getContactTypeValue() {
		// Test
		return requiredContactValue(0);
	}

	public String getContactDescriptionValue() {

		return requiredContactValue(1);
	}

	public String getContactFirstNameValue() {
		return requiredContactValue(2);
	}

	public String getContactMiddleNameValue() {
		return requiredContactValue(3);
	}

	public String getContactLastNameValue() {
		return requiredContactValue(4);
	}

	public String getContactAddressValue() {
		return requiredContactValue(5);
	}

	public String getContactCityValue() {
		return requiredContactValue(6);
	}

	public String getContactStateValue() {
		return requiredContactValue(7);
	}

	public String getContactPostalCodeValue() {
		return requiredContactValue(8);
	}

	public String getContactCountryValue() {
		return requiredContactValue(9);
	}

	public String getContactEmailAddressValue() {
		return requiredContactValue(10);
	}

	public String getContactPhoneNumberValue() {
		return requiredContactValue(11);
	}

	private String requiredDocumentValue(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		Element = action.fluentWaitWebElement("Document Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element,
				"Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";

		for (WebElement E : documentValues) {
			if (E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
			}

		}
		int documents = documentValuesData.size() / 3;

		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i + 3;
		}

		if (documents > 1) {
			Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue + G + ",";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length() - 1);
		}
		tempData.clear();

		return requiredDocumentValue;
	}

	public String getDocumentTypeValue() {

		// if(action.getElements("Document Header").size() > 0) {
		return requiredDocumentValue(0);

	}

	public String getDocumentLinkValue() {

		return requiredDocumentValue(1);
	}

	public String getDocumentCommentValue() {

		return requiredDocumentValue(2);

	}

	public void clickOnSubmitButton() {
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("SUBMIT");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		Element.click();
	}

	public void clickOnPrevious() {
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("Previous");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		Element.click();
	}

	public boolean isDocumentHeaderDisplayed() {
		if (action.fluentWaitWebElements("Document Header").size() > 0)
			return false;
		return true;
	}

	public boolean areContactsDisplayed() {
		List<WebElement> elements = action.getElements("Contacts Error");
		if (elements.size() > 0) {
			action.moveToElement(elements.get(0));
			return false;
		}
		return true;
	}

	public void clickOnBackLink() {

		action.navigateBackward();

	}

	public ArrayList<String> getHeadersInReviewPage() {
		List<WebElement> elements = action.getElements("Page Header in Review");
		ArrayList<String> data = new ArrayList<String>();
		for (WebElement E : elements) {

			data.add(E.getText());
		}
		return data;
	}
}
