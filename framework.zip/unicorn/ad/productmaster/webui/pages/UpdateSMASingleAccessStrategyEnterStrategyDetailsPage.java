package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class UpdateSMASingleAccessStrategyEnterStrategyDetailsPage {

	Action action;
	WebElement Element;
	public UpdateSMASingleAccessStrategyEnterStrategyDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	public boolean isUserOnEnterStrategyDetailspage() {
		Element = action.waitForJSWebElement("Enter Strategy Details Header");
		
		if(Element.getText().contains("Enter Strategy Details")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	public String getRiskCategoryValue() {
		Element = action.fluentWaitWebElement("Risk Category Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getStrategyNameValue() {
		Element = action.fluentWaitWebElement("Strategy Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String uiValue = Element.getAttribute("value");
		if((uiValue == null) || (uiValue.isEmpty())) {
			uiValue = "isEmpty";
			
			return uiValue;
			}
		return uiValue;
	}
	public String getStrategyCodeValue() {
		Element = action.fluentWaitWebElement("FOA Code (Access) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getResearchRatingValue() {
		Element = action.fluentWaitWebElement("Research Rating Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getStrategyMinimumValue() {
		Element = action.fluentWaitWebElement("Strategy Minimum (MEPS) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getAttribute("value"))).toString();
		return data;
	}
	public String getExceptionMinimumValue() {
		Element = action.fluentWaitWebElement("Exception Minimum (RAW) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getAttribute("value"))).toString();
		return data;
	}
	public String getWithdrawalRebalanceMinimumValue() {
		Element = action.fluentWaitWebElement("Withdrawal/Rebalance Minimum (RAW) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getAttribute("value"))).toString();
		return data;
	}
	public String getStrategyStatus() {
		Element = action.fluentWaitWebElement("Strategy Status Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getAttribute("value");
	}
	public String getPremiumEligibleValue() {
			Element = (WebElement) action.fluentWaitForJSWebElement("Premium Fee Value");
			action.moveToElement(Element);
			action.highligthElement(Element);
			String data = Element.getAttribute("class");
			if(data.contains("checked")) {
				return "t";
			}
			return "f";
			
	}
	
	public String getConcordFeeEligibleValue() {
		Element = (WebElement) action.fluentWaitForJSWebElement("Concord Eligible Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "t";
		}
		return "f";
	}
	public String getIsManagerProfileValue() {
		Element = (WebElement) action.fluentWaitForJSWebElement("IS Manager Profile Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "t";
		}
		return "f";
	}
	public String getDeletedValue() {
		Element = (WebElement) action.fluentWaitForJSWebElement("Deleted Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getAttribute("class");
		if(data.contains("checked")) {
			return "t";
		}
		return "f";
	}
	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
		
	}
}
