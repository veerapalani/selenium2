package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class ManagerSortAndFilterPage {
	Action action;
	WebElement Element, myElement;
	Boolean flag;

	public ManagerSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchManagerValue(String ManagerSearchValue) {
		action.pause(1000);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitForJSWebElement("GlobalSearchvalueForManager");
		//action.click(Element);
		Element.click();
		Element.clear();
		action.pause(1000);
		action.sendKeys(Element, ManagerSearchValue);
		action.pause(2000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}
	}

	public void clickOnSeeAllResultsForManagerLayout() {
		action.pause(4000);
		Element = (WebElement) action.fluentWaitForJSWebElement("SeeAllResultMangerLayout");
		// action.scrollToBottom();
		action.highligthElement(Element);
		Element.click();
		//action.jsClick(Element);
	}

	public void verifyTheSearchedResultInAllTabForManager() {
		action.pause(1000);
		Element = (WebElement) action.fluentWaitForJSWebElement("AllTabManager");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void verifyAndClickManagerTab() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("ManagerTab");
		action.pause(2000);
		action.highligthElement(Element);
		Element.isDisplayed();
		// Action.pause(3000);
		Element.click();
		// action.pause(2000);
	}

	public String verifyTheGridCountBeforeApplyFilterAndSortCondition() throws InterruptedException {
		/*
		 * action.pause(4000); Element = (WebElement)
		 * action.fluentWaitForJSWebElement("ManagerTab"); action.jsClick(Element);
		 */
		action.pause(5000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterGlobalSearchForManager");
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		action.pause(3000);
		myElement = (WebElement) action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void verifySearchedGridViewDisplay() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("GridViewManager");
		Element.isDisplayed();
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		action.pause(2000);
		action.moveToElement(element);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		action.pause(2000);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void clickOnSortIcon(WebElement element) {
		action.pause(2000);
		action.click(element);
	}

	public String verifyTheSortCoumnPropertyTypeASC() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("AscSortOrder");
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDESC() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("DescSortOrder");
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDefault() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("DefaultSortOrder");
		return action.getAttribute(Element, "class");
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		myElement = element;
		action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		myElement = element;
		action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void clickOnFilterCondition() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("FilterCondition");
		action.click(Element);
	}

	public String verifyTheManagerGridCountAfterApplyFilterConditionOnTab() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTabForManager");
		return action.getText(Element);
	}

	public void clickOnFilterConditionForManagerGridView(WebElement element) {
		myElement = element;
		action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}

	public void enterFilterValue(String FilterValue) {
		action.pause(1000);
		Element = (WebElement) action.fluentWaitWebElement("FilterValue");
		Element.click();
		Action.pause(1000);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForManagerGridView() {
		action.pause(1000);
		Element = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheStyleGridCountAfterScroll() {
		action.pause(4000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterCondition");
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void clickOnApplyFilterIconForManagerGridViewForReset() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForManagerGridViewForCancel() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String waitForWebElement(String xpath) {
		int timeLaps = 0;
		String status = "FAIL";
		while (status.equals("FAIL") && timeLaps < 4) {
			try {
				Element = findElementByDynamicXpath(xpath);
				if (Element == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}
			} catch (Exception e) {
				status = "FAIL";
			}
			action.pause(1000);
			++timeLaps;
		}
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);
		return status;
	}

}
