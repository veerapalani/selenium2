package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class HOApprovalViewPage {
	Action action;
	public HOApprovalViewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	WebElement Element;
	
	public boolean isUserOnReviewPHOAStrategyPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Review Strategy")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public String getRiskCategoryValue() {
		Element = action.fluentWaitWebElement("Risk Category Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPIVStyleValue() {
		Element = action.fluentWaitWebElement("PIV Style Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}
		return "f";
	}

	public String getGeographicIndicatorValue() {
		Element = action.fluentWaitWebElement("Geographic Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getStrategyNameValue() {
		Element = action.fluentWaitWebElement("Strategy Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getStrategyCodeValue() {
		Element = action.fluentWaitWebElement("FOA Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getBalancedAllocationValue() {
		Element = action.fluentWaitWebElement("Balanced Allocation Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getConcentratedStrategyIndicatorValue() {
		Element = action.fluentWaitWebElement("Concentrated Strategy Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStructuredProductsStrategyValue() {
		Element = action.fluentWaitWebElement("Structured Products Strategy Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStrategyStatusValue() {
		Element = action.fluentWaitWebElement("Status Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getHedgeCoreIndicatorValue() {
		Element = action.fluentWaitWebElement("Hedge Core Indicator Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getStylePairingCodeValue() {
		Element = action.fluentWaitWebElement("Style Pairing Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getInvestmentStyleValue() {
		Element = action.fluentWaitWebElement("Investment Style Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getPrimaryBenchmarkValue() {
		String primaryBenchmark = "";
		
			List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		
		if(WebElements.isEmpty()) {
			return "isEmpty";
		}else {
		List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0), "Benchmarks List common tag");
		ArrayList<String> tempData = new ArrayList<String>();
		
		int size  = Elements.size();
		int count = 0;
		DecimalFormat ds = new DecimalFormat(".00");
		for (int i = 0; i < size/3; i++) {
			primaryBenchmark = "@benchmarkCategory-#-@benchmarkName--#-@percentage";
			
			if(Elements.get(count).getText().equals("—")) {
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count+1).getText());
				primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
			}else if (Elements.get(count+1).getText().equals("—")) {
				if(primaryBenchmark.contains("@benchmarkCategory")) {
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
					primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
				}else {
					Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
				}
				
			}
			tempData.add(primaryBenchmark);
			//data = data+primaryBenchmark+":";
			count = count + 3;
			
		}
		if(tempData.size() > 1) {
			Collections.sort(tempData);
			primaryBenchmark = "";
			for (String G : tempData) {
				primaryBenchmark = primaryBenchmark+G+":";
			}	
		}
		tempData.clear();
		
		return primaryBenchmark;
		}
	}

	public String getMarginEligibleValue() {
		Element = action.fluentWaitWebElement("Margin Eligible Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if(data.equalsIgnoreCase("yes")) {
			return "t";
		}else if(data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getBenchmarkithValuefromUI(int j) {
		
		ArrayList<String> primarybenchmark = getPrimaryBenchmarksValue();
		
		return primarybenchmark.get(j).split("-#-")[2].trim();
		
	}
	public Float getPercentageithValuefromUI(int j) {
		
		ArrayList<String> primarybenchmark = getPrimaryBenchmarksValue();
		
		return Float.parseFloat(primarybenchmark.get(j).split("-#-")[3].trim());
	}
	
	public ArrayList<String> getPrimaryBenchmarksValue() {
		
		Element = action.fluentWaitWebElement("Benchmarks Header");
		action.scrollToElement(Element);
		action.highligthElement(Element);
		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		String primaryBenchmark = "";
		List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0), "Benchmarks List common tag");
		ArrayList<String> tempData = new ArrayList<String>();
		//String primaryBenchmark = "";
		int size  = Elements.size();
		int count = 0;
		DecimalFormat ds = new DecimalFormat(".00");
		for (int i = 0; i < size/3; i++) {
			primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName-#-@percentage";
			primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
			if(Elements.get(count).getText().equals("—")) {
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count+1).getText());
				primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Float.parseFloat(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
			}else if (Elements.get(count+1).getText().equals("—")) {
				if(primaryBenchmark.contains("@benchmarkCategory")) {
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
					primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Float.parseFloat(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
				}else {
					Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
				}
				
			}
			tempData.add(primaryBenchmark);
			//data = data+primaryBenchmark+":";
			count = count + 3;
			
		}
		/*
		 * if(tempData.size() > 1) { Collections.sort(tempData); primaryBenchmark = "";
		 * for (String G : tempData) { primaryBenchmark = primaryBenchmark+G+":"; } }
		 * tempData.clear();
		 */
		
		return tempData;
		
	}

	public String getBenchmarkCategoryValue() {
		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		if(WebElements.isEmpty()) {
			return "isEmpty";
		}else {
		List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0), "Benchmarks List common tag");
		int count = 0;
		
		
			if(Elements.get(count).getText().equals("—")) {
				return "Custom";
				
			}else if (Elements.get(count+1).getText().equals("—")) {
				return "Default";
				
			}else {
				Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
				return "";
			}
		}
	}

	public void CheckingPMPTitle() {
		// TODO Auto-generated method stub
		Element = action.fluentWaitWebElement("PMP Title_HO");
		Assert.assertTrue(action.isDisplayed(Element));
	}
	
	public String getCommonAttributeValue(String labelName) {
		Element = action.getElementByFormatingXpath("Common Attribute Value", labelName);
		return Element.getText();
	}


}
