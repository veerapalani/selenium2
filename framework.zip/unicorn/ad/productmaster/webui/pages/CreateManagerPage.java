package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateManagerPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static String managerFirmName, managerCode = null;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();

	public CreateManagerPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public Boolean isUserOnCreateManagerPage() {
		myElement = (WebElement)action.fluentWaitWebElement("txtCreateManager");
		action.highligthElement(myElement);
		return action.isDisplayed(myElement);
	}

	public void enterManagerName(String managerName) throws InterruptedException {
		//benchmarkCode1 = benchmarkCodeValue + Calendar.getInstance().getTimeInMillis();
		/*
		 * managerCode = managerCodeValue + Calendar.getInstance().getTimeInMillis();
		 * Long time = Calendar.getInstance().getTimeInMillis();
		 */
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtManagerName");
		action.highligthElement(ele);
		action.sendKeys(ele, managerName);
	}

	public void enterFirmWebsite(String firmWebsite) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtFirmwebsite");
		action.highligthElement(ele);
		action.sendKeys(ele, firmWebsite);
	}

	public void enterVestMarkName(String vestMarkName) throws InterruptedException {
		Thread.sleep(1000);
		WebElement ele = (WebElement)action.getElementByJavascript("txtVestMarkName");
		action.highligthElement(ele);
		action.sendKeys(ele, vestMarkName);
	}

	public void enterDTCCID(String DTCCID) throws InterruptedException {
		DTCCID = DTCCID + Calendar.getInstance().getTimeInMillis();
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtDTCCID");
		action.highligthElement(ele);
		action.sendKeys(ele, "12DT" + time);
	}

	public void enterTaxPayer(String taxpayer) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txttaxPayer");
		action.highligthElement(ele);
		action.sendKeys(ele, taxpayer);
	}

	public void enterLargetraderID(String LargeTraderId) throws InterruptedException {
		LargeTraderId = LargeTraderId + Calendar.getInstance().getTimeInMillis();
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtLargeTraderId");
		action.highligthElement(ele);
		action.sendKeys(ele, "123Blackrocklargetraderid" + time);
	}

	public void enterManagerFirmName(String ManagerFirmNameValue) throws InterruptedException {
		//benchmarkCode1 = benchmarkCodeValue + Calendar.getInstance().getTimeInMillis();
		managerFirmName = ManagerFirmNameValue;
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtFirmName");
		action.highligthElement(ele);
		action.sendKeyCharterWise(ele, ManagerFirmNameValue);
	}

	public void enterfeecodeValue(String feecodeValue) throws InterruptedException {
		//benchmarkCode1 = benchmarkCodeValue + Calendar.getInstance().getTimeInMillis();
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtFeeCode");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, feecodeValue + time);
	}

	public void eyechecktypevalue() throws InterruptedException {
		Thread.sleep(1000);
		action.click((WebElement)action.getElement("Radiobuttoneyecheck"));
		Thread.sleep(1000);
		//action.click((WebElement) action.getElementByJavascript("Radiobuttoneyechecktypevalue1"));
	}
	public void eyechecktypevalue2() throws InterruptedException {
		Thread.sleep(1000);
		action.click((WebElement)action.getElement("Radiobuttoneyecheck2"));
		Thread.sleep(1000);
		//action.click((WebElement) action.getElementByJavascript("Radiobuttoneyechecktypevalue1"));
	}
	public void enterFeeName(String feenameValue) throws InterruptedException {
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtFeeName");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, feenameValue + time);
	}

	public void enterFeeDescrp(String feedescriptionValue) throws InterruptedException {
		//benchmarkCode1 = benchmarkCodeValue + Calendar.getInstance().getTimeInMillis();
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtFeeDescription");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, feedescriptionValue);
	}

	public void selectUBSSubsidiary() throws InterruptedException {
		Thread.sleep(500);
		action.click((WebElement)action.getElementByJavascript("drpDwnUBSSub"));
		Thread.sleep(500);
		action.click((WebElement)action.getElementByJavascript("UBSSubvalue"));
	}

	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		return element.getElements("xpath", xpath);
	}

	public void enterFeeAmnt(String feeamntValue) throws InterruptedException {
		//benchmarkCode1 = benchmarkCodeValue + Calendar.getInstance().getTimeInMillis();
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("txtFeeAmount");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, feeamntValue);
	}

	public void enterManagername() throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("Manager Name");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, "Manager Name");
	}

	public WebElement getElement(String key) {
		myElement = action.getElement(key);
		return myElement;
	}

	public String giveCssValuehere(WebElement element, String attribute) {
		return element.getCssValue(attribute);
	}

	public void verifystatusfieldincreatemanagerpage() {
		myElement = (WebElement)action.getElementByJavascript("Status field");
		action.highligthElement(myElement);
		Assert.assertFalse(action.isEnabled(myElement));
		Reporter.addScreenCapture();
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public void verifyElementsoncreatemanagerpage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void clickOntheelementsoncreatemanagerpage(String elementKey) throws Throwable {
		myElement = action.getElement(elementKey);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public void verifyAttribute(String expectedValue, WebElement element, String attribute) {
		Assert.assertEquals(getAttribute(element, attribute), expectedValue);
	}

	public void clickOnBackLink() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement)action.getElement("Back Link"));
		action.captureEntireScreen();
		action.click((WebElement)action.getElement("Back Link"));
	}

	public String getAttribute(WebElement element, String attribute) {
		return element.getAttribute(attribute);
	}

	public void verifymanagerheaderdincreatemanagerpage() {
		myElement = (WebElement)action.getElement("ManagerHeader");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void clickOnNextButton() throws InterruptedException {
		Thread.sleep(500);
		myElement = action.getElement("Next Button");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.captureEntireScreen();
		action.click(myElement);
	}
}
