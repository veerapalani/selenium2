package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateManagerContactPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();

	public CreateManagerContactPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void verifyTextEntercontactDetailsoncontactpage() {
		myElement = (WebElement)action.getElementByJavascript("Enter Contact Details");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		listOfElements = element.getElements("xpath", xpath);
		return listOfElements;
	}

	public Boolean isUserOnContactPage() {
		myElement = action.fluentWaitWebElement("txtAddContacts");
		action.highligthElement(myElement);
		return action.isDisplayed(myElement);
	}

	public void selectcontacttypevalue(String feetype) throws InterruptedException {
		Thread.sleep(1000);
		action.jsClick((WebElement)action.getElementByJavascript("drpDwnContactType"));
		Thread.sleep(1000);
		action.jsClick((WebElement)action.getElementByJavascript("contacttypevalue1"));
	}

	public void selectstatetypevalue() throws InterruptedException {
		Thread.sleep(1000);
		action.click((WebElement)action.getElementByJavascript("drpDwnStateType1"));
		Thread.sleep(500);
		action.click((WebElement)action.getElementByJavascript("statetypevalue12"));
	}

	public void selectcountrytypevalue() throws InterruptedException {
		Thread.sleep(1000);
		action.click((WebElement)action.getElementByJavascript("drpDwncountryType"));
		Thread.sleep(1000);
		action.click((WebElement)action.getElementByJavascript("countrytypevalue1"));
	}

	public void selectmanagercontacttypevalue() throws InterruptedException {
		Thread.sleep(2000);
		action.click((WebElement)action.getElementByJavascript("drpDwnContactType"));
		Thread.sleep(1000);
		action.click((WebElement)action.getElementByJavascript("contacttypevalue1"));
	}

	public void entercontactcodeName(String contactcode) throws InterruptedException {
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("contactcode");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, contactcode + time);
	}

	public void entercontactcodeuniqueName() throws InterruptedException {
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("managercontactcode");
		action.highligthElement(ele);
		String code = "contactcode";
		action.sendkeysClipboard(ele, code + time);
	}

	public void entercontactdescription(String contactdescrp) throws InterruptedException {
		Thread.sleep(500);
		myElement = action.getElement("contactdescrp");
		action.click(myElement);
		//action.highligthElement(ele);
		action.sendKeys(myElement, contactdescrp);
	}

	public void entermanagercontactdescription(String description) throws InterruptedException {
		//Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("managercontactdescrp");
		action.highligthElement(ele);
		//String code = "12345678description";
		action.sendKeys(ele, description);
	}

	public void clickOnBackLink() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement)action.getElement("Back Link"));
		action.captureEntireScreen();
		action.click((WebElement)action.getElement("Back Link"));
	}

	public void clickOnAddContactButton() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement)action.getElement("Add Contact Button"));
		action.captureEntireScreen();
		action.click((WebElement)action.getElement("Add Contact Button"));
	}

	public void clickOnNextButton() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement)action.getElement("Next Button"));
		action.captureEntireScreen();
		action.click((WebElement)action.getElement("Next Button"));
	}

	public void entermanagerfirstname(String firstname) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("managercontactfirstname");
		action.highligthElement(ele);
		//String firstname="1first";
		action.sendKeys(ele, firstname);
	}

	public void entermanagermiddlename(String middlename) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("managercontactmiddlename");
		action.highligthElement(ele);
		//String middlename="1midd";
		action.sendKeys(ele, middlename);
	}

	public void entermanagerlastname(String lastname) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("managercontactlastname");
		action.highligthElement(ele);
		//String middlename="1last";
		action.sendKeys(ele, lastname);
	}

	public void enterAddress(String address) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("addressline");
		action.highligthElement(ele);
		//String address = "1addr";
		action.sendKeys(ele, address);
	}

	public void enterCity(String city) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("city");
		action.highligthElement(ele);
		//String city = "Bangalore";
		action.sendKeys(ele, city);
	}

	public void postalcode(String post) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("postalcode");
		action.highligthElement(ele);
		//String post = "12345";
		action.sendKeys(ele, post);
	}

	public void phoneno(String phone) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("phoneno");
		action.highligthElement(ele);
		//String phone = "9789814265";
		action.sendKeys(ele, phone);
	}

	public void emailaddress(String email) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("emailaddress");
		action.highligthElement(ele);
		//String email = "123blackrock@gmail.com";
		action.sendKeys(ele, email);
	}
}
