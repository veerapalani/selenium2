package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.List;

import javax.validation.constraints.AssertFalse;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateSMASingleAccessStrategyEnterStrategyDetailsPage {
	Action action;
	WebElement Element = null;
	WebElement Highlight = null;
	String[] expErrorlist;
	List<WebElement> actErrorMessages;
	Boolean flag;
	String[] underlyingStrategyDetails;
	String locatorValue;
	int loopCount;

	public CreateSMASingleAccessStrategyEnterStrategyDetailsPage(String pageName) {
		//Addign a comment
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public boolean isUserOnCreateStrategyWizardPage() {
		Element = action.waitForJSWebElement("Create Strategy Text");
		if(action.getText(Element).equalsIgnoreCase("Create Strategy")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void enterStrategyName(String strategyName) {
		Element =(WebElement) action.fluentWaitForJSWebElement("Add Strategy Name");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, strategyName);
		} while (!(getStrategyNameValueFromLandingPage().equals(strategyName)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
	}
	
	private String getStrategyNameValueFromLandingPage() {
		Element = action.waitForJSWebElement("Add Strategy Name Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}

	public void clickOnSMASingleAccessRadioButton() {
		Element = action.waitForJSWebElement("SMA - Single (Access) button");
		Element.click();
	}

	public void clickOnCreateButton() {
		Element = action.waitForJSWebElement("CREATE");
		Element.click();
	}

	public boolean isUserOnEnterStrategyDetailsPage() {
		action.waitForJSWebElement("SMA Single Access Text");
		Element = action.waitForJSWebElement("Enter Strategy Details");
		if(action.getText(Element).equalsIgnoreCase("Enter Strategy Details")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void enterManagerName(String managerName) {
		/*
		 * Element = (WebElement) action.getElementByJavascript("Manager Name");
		 * action.click(Element); action.sendKeys(Element, managerName); Highlight =
		 * (WebElement) action.getElementByJavascript("Manager Value");
		 * action.highligthElement(Highlight); action.click(Highlight);
		 */
		//		Element = action.waitForJSWebElement("Manager Name");
		//		action.click(Element);
		//
		//		Element = action.getElement("Manager Name First Dropdown Value");
		//		Highlight = action.getElementByFormatingXpath("Manager Name Expected Dropdown Value", managerName);
		//		
		//		int dataValue = Integer.parseInt(Highlight.getAttribute("value")) - Integer.parseInt(Element.getAttribute("value"));
		//		
		//		Highlight = action.getElementByFormatingXpath("Manager Value", dataValue);
		Element = action.waitForJSWebElement("Manager Name");
		action.click(Element);
		Highlight = action.waitForJSWebElement("Manager Value");
		Highlight = Highlight.findElement(By.linkText(managerName));
//		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
//		for(WebElement E: li) {
//			if(E.getText().equalsIgnoreCase(managerName)) {
//				Highlight = E;
//				break;
//			}
//		}
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterInvestmentStyleName(String investmentStyleName) {
		/*
		 * Element = (WebElement) action.getElementByJavascript("Investment Style");
		 * action.click(Element); action.pause(1000); action.sendKeys(Element,
		 * investmentStyleName); Highlight = (WebElement)
		 * action.getElementByJavascript("Investment Style Value"); action.pause(1000);
		 * action.highligthElement(Highlight); action.click(Highlight);
		 */
		Element = action.waitForJSWebElement("Investment Style");
		action.click(Element);
		//Element = action.getElement("Investment Style First Dropdown Value");
		Highlight = (WebElement)action.fluentWaitForJSWebElement("Investment Style Value");
		Highlight = Highlight.findElement(By.linkText(investmentStyleName));
		/*
		 * Highlight =
		 * action.getElementByFormatingXpath("Investment Style Expected Dropdown Value",
		 * investmentStyleName);
		 * 
		 * int dataValue = Integer.parseInt(Highlight.getAttribute("value")) -
		 * Integer.parseInt(Element.getAttribute("value"));
		 * 
		 * Highlight = action.getElementByFormatingXpath("Investment Style Value",
		 * dataValue);
		 */
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterRiskCategory(String riskCategory) {
		/*
		 * Element = (WebElement) action.getElementByJavascript("Risk Category");
		 * action.scrollToElement(Element); action.click(Element); Highlight =
		 * (WebElement) action.getElementByJavascript("Risk Category Value");
		 * action.highligthElement(Highlight); action.click(Highlight);
		 */
		Element = action.waitForJSWebElement("Risk Category");
		action.click(Element);
		Highlight = action.waitForJSWebElement("Risk Category Value");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		for(WebElement E: li) {
			if(E.getText().equalsIgnoreCase(riskCategory)) {
				Highlight = E;
				break;
			}
		}
		//action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterPortfolioManagerName(String portfolioManagerName) {
		//action.sendKeys(Element, portfolioManagerName);
		//action.sendKeys(Element, "testpmanager");
		Element = action.waitForJSWebElement("Portfolio Manager");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, portfolioManagerName);
		} while (!(getCommonTextAttributeValue("portfolioManager").equals(portfolioManagerName)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
	}

	public String getCommonTextAttributeValue(String ID) {
		return action.getElement("id", ID).getAttribute("value");
	}

	public void enterMSA(String mSA) {
		if(mSA.equalsIgnoreCase("YES")) {
			Element = (WebElement)action.getElementByJavascript("MSA");
			Element.click();
		}
	}

	public void enterUnderLyingStrategyName(String replace, String underlyingStrategyName, String mSA, int underlyingStrategyNumber) {
		if(mSA.equalsIgnoreCase("YES")) {
			Element = action.getElement("js", replace);
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, underlyingStrategyName);
		} while (!(getUnderlyingStrategyName(underlyingStrategyNumber).equals(underlyingStrategyName)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
		}
	}

	private String getUnderlyingStrategyName(int underlyingStrategyNumber) {
		return action.getElementByFormatingXpath("Underlying Strategy Name Value", underlyingStrategyNumber).getAttribute("value");
	}

	public void enterFOAID(String replace, String FOAID, String mSA, int underlyingStrategyNumber) {
		if(mSA.equalsIgnoreCase("YES")) {
			Element = action.getElement("js", replace);
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, FOAID);
		} while (!(getfoaIDValue(underlyingStrategyNumber).equals(FOAID)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
		}
	}

	private String getfoaIDValue(int underlyingStrategyNumber) {
		
		return action.getElementByFormatingXpath("FOAID Value", underlyingStrategyNumber).getAttribute("value");
	}

	public void enterMSAPercentage(String replace, String percentage, String mSA, int underlyingStrategyNumber) {
		if(mSA.equalsIgnoreCase("YES")) {
			action.pause(5000);
			Element = PMPageGeneric.waitForElementToBeVisible(action.getElement("js", replace), 10);
		loopCount = 0;
		do {
			Element.click();
			Element.clear();
			action.sendKeys(Element, percentage);
		} while (!(Float.parseFloat(percentage + "f") == Float.parseFloat(getMSAPercentageValue(underlyingStrategyNumber) + "f")) && ++loopCount < 10);
		
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
		}
	}

	private String getMSAPercentageValue(int underlyingStrategyNumber) {
		
		return action.getElementByFormatingXpath("Percentage Value", underlyingStrategyNumber).getAttribute("value");
	}

	public void addNewUnderlyingStrategy() {
		Element = action.fluentWaitWebElement("Add New Underlying Strategy");
		Element.click();
	}

	public void enterOptionsEligible(String optionsEligible) {
		if(optionsEligible.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Options Eligible");
			Element.click();
		}
	}

	public void enterCollateralEligible(String collateralEligible) {
		if(collateralEligible.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Collateral Eligible");
			Element.click();
		}
	}

	public void enterNRAEligiblility(String nraEligiblility) {
		if(nraEligiblility.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("NRA Eligibility");
			Element.click();
		}
	}

	public void enterForeignSecurities(String foreignSecurities) {
		if(foreignSecurities.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Foreign Securities");
			Element.click();
		}
	}

	public void enterConcordEligible(String concordEligible) {
		if(concordEligible.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Concord Eligible");
			Element.click();
		}
	}

	public void enterPremiumFee(String premiumFee) {
		if(premiumFee.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Premium Fee");
			Element.click();
		}
	}

	public void enterDeleted(String deleted) {
		if(deleted.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Deleted");
			Element.click();
		}
	}

	public void enterStrategyMinimum(String strategyMinimum) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Strategy Minimum (MEPS)");
		DecimalFormat df = new DecimalFormat("0.#");
		loopCount = 0;
		do {
			Element.click();
			Element.clear();
			action.sendKeys(Element, strategyMinimum);
		} while (!(df.format(Float.parseFloat(getCommonTextAttributeValue("strategyMinimum"))).equals(df.format(Float.parseFloat(strategyMinimum)))) && ++loopCount < 10);
		
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
	}

	public void enterExceptionMinimum(String exceptionMinimum) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Exception Minimum (RAW)");
		DecimalFormat df = new DecimalFormat("0.#");
		loopCount = 0;
		do {
			Element.click();
			Element.clear();
			action.sendKeys(Element, exceptionMinimum);
		} while (!(df.format(Float.parseFloat(getCommonTextAttributeValue("exceptionMinimum"))).equals(df.format(Float.parseFloat(exceptionMinimum)))) && ++loopCount < 10);
		
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
	}

	public void enterWithdrawalRebalanceMinimum(String withdrawalRebalanceMinimum) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Withdrawal/Rebalance Minimum (RAW)");
		DecimalFormat df = new DecimalFormat("0.#");
		loopCount = 0;
		do {
			Element.click();
			Element.clear();
			action.sendKeys(Element, withdrawalRebalanceMinimum);
		} while (!(df.format(Float.parseFloat(getCommonTextAttributeValue("withdrawalMinimum"))).equals(df.format(Float.parseFloat(withdrawalRebalanceMinimum)))) && ++loopCount < 10);
		
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
	}

	public void enterFeeSchedultType(String feeSchedultType) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Fee Schedule Type");
		action.scrollToElement(Element);
		action.click(Element);
		Highlight = (WebElement)action.fluentWaitForJSWebElement("Fee Schedule Type Value");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		for(WebElement E: li) {
			if(E.getText().equalsIgnoreCase(feeSchedultType)) {
				Highlight = E;
				break;
			}
		}
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterManagerFee(String managerFee) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Manager Fee (TS)");
		DecimalFormat df = new DecimalFormat("0.#");
		loopCount = 0;
		do {
			Element.click();
			Element.clear();
			action.sendKeys(Element, managerFee);
		} while (!(df.format(Float.parseFloat(getCommonTextAttributeValue("managerFee"))).equals(df.format(Float.parseFloat(managerFee)))) && ++loopCount < 10);
		
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
	}

	public void enterConcordFee(String concordFee, String concordEligible) {
		if(concordEligible.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Concord Fee");
			Element.click();
			Element.sendKeys(concordFee);
		}
	}

	public void enterTypeOfStrategy(String typeOfStrategy) {
		switch(typeOfStrategy) {
			case "Single Asset Strategy":
				Element = (WebElement)action.getElementByJavascript("Single Asset Strategy");
				//PMPageGeneric.waitForElementToBeVisible(Element, 10);
				Element.click();
				break;
			case "Multi Asset Strategy":
				Element = (WebElement)action.getElementByJavascript("Multi Asset Strategy");
				//PMPageGeneric.waitForElementToBeVisible(Element, 10);
				Element.click();
				break;
			default:
				break;
		}
	}

	public void enterVehiclePreferences(String vehiclePreferences) {
		switch(vehiclePreferences) {
			case "ETF":
				Element = (WebElement)action.getElementByJavascript("ETF");
				//PMPageGeneric.waitForElementToBeVisible(Element, 10);
				Element.click();
				break;
			case "Mutual Funds":
				Element = (WebElement)action.getElementByJavascript("MF");
				//PMPageGeneric.waitForElementToBeVisible(Element, 10);
				Element.click();
				break;
			case "Individual Equities":
				Element = (WebElement)action.getElementByJavascript("Individual Equities");
				//PMPageGeneric.waitForElementToBeVisible(Element, 10);
				Element.click();
				break;
			default:
				break;
		}
	}

	public void enterTaxPreference(String taxPreference) {
		switch(taxPreference) {
			case "Taxable":
				Element = (WebElement)action.getElementByJavascript("Taxable");
				Element.click();
				break;
			case "Tax Managed":
				Element = (WebElement)action.getElementByJavascript("Tax Managed");
				Element.click();
				break;
			default:
				break;
		}
	}

	public void enterAllocationPreference(String allocationPreference) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Allocation Preference");
		action.scrollToElement(Element);
		action.click(Element);
		Highlight = (WebElement)action.fluentWaitForJSWebElement("Allocation Preference Value");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		for(WebElement E: li) {
			if(E.getText().equalsIgnoreCase(allocationPreference)) {
				Highlight = E;
				break;
			}
		}
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterResearchRating(String researchRating) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Research Rating");
		action.scrollToElement(Element);
		action.click(Element);
		Highlight = (WebElement)action.fluentWaitForJSWebElement("Research Rating Value");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		for(WebElement E: li) {
			if(E.getText().equalsIgnoreCase(researchRating)) {
				Highlight = E;
				break;
			}
		}
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterLargeTraderId(String largeTraderId) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Large Trader Id");
		loopCount = 0;
		do {
			Element.click();
			myClear(Element);
			action.doubleClick(Element);
			action.sendKeys(Element, largeTraderId);
		} while (!(getCommonTextAttributeValue("largeTraderId").equals(largeTraderId)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("Unable to input entire text to text field");
	}

	public void enterShortDuration(String shortDuration) {
		if(shortDuration.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Short Duration");
			Element.click();
		}
	}

	public void enterMLPs(String mlps) {
		if(mlps.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("MLPS");
			Element.click();
		}
	}

	public void enterHighYield(String highYield) {
		if(highYield.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("High Yield");
			Element.click();
		}
	}

	public void enterTaxableFixedIncomeLadder(String taxableFixedIncomeLadder) {
		if(taxableFixedIncomeLadder.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Taxable Fixed Income Ladder");
			Element.click();
		}
	}

	public void enterCioAligned(String cioAligned) {
		if(cioAligned.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("CIO Aligned");
			Element.click();
		}
	}

	public void enterMunicipalFixedIncomeLadder(String municipalFixedIncomeLadder) {
		if(municipalFixedIncomeLadder.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Municipal Fixed Income Ladder");
			Element.click();
		}
	}

	public void enterConcentratedStrategyIndicator(String concentratedStrategyIndicator) {
		if(concentratedStrategyIndicator.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Concentrated Strategy Indicator");
			Element.click();
		}
	}

	public void enterYieldFocused(String yieldFocused) {
		if(yieldFocused.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Yield Focused");
			Element.click();
		}
	}

	public void enterNonTraditionalAssets(String nonTraditionalAssets) {
		if(nonTraditionalAssets.equalsIgnoreCase("yes")) {
			Element = action.waitForJSWebElement("Non Traditional Assets");
			Element.click();
		}
	}

	public void enterSustainableInvesting(String sustainableInvesting) {
		if(sustainableInvesting.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Sustainable Investing");
			Element.click();
		}
	}

	public void enterIsManagerProfile(String isManagerProfile) {
		if(isManagerProfile.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("IS Manager Profile");
			Element.click();
		}
	}

	public void enterHideStrategy(String hideStrategy) {
		if(hideStrategy.equalsIgnoreCase("yes")) {
			Element = (WebElement)action.fluentWaitForJSWebElement("Hide Strategy");
			Element.click();
		}
	}

	public void enterAARBaseTemplate(String aarBaseTemplate) {
		Element = (WebElement)action.fluentWaitForJSWebElement("AAR Base Template");
		action.scrollToElement(Element);
		action.click(Element);
		Highlight = (WebElement)action.fluentWaitForJSWebElement("AAR Base Template Value");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		for(WebElement E: li) {
			if(E.getText().equalsIgnoreCase(aarBaseTemplate)) {
				Highlight = E;
				break;
			}
		}
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterDVPKeyTrustTemplate(String dvpKeyTrustTemplate) {
	}

	public void enterComparativeUniverse(String comparativeUniverse) {
		Element = (WebElement)action.fluentWaitForJSWebElement("Comparative Universe");
		action.scrollToElement(Element);
		action.click(Element);
		Highlight = (WebElement)action.fluentWaitForJSWebElement("Comparative Universe Value");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		for(WebElement E: li) {
			if(E.getText().equalsIgnoreCase(comparativeUniverse)) {
				Highlight = E;
				break;
			}
		}
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void clickOnNext() {
		action.scrollToBottom();
		action.waitForJSWebElement("NEXT").click();
	}

	public boolean error(String experror) {
		flag = false;
		action.pause(2000);
		if(experror.contains("-")) {
			expErrorlist = experror.split("-");
		}
		else
			expErrorlist[0] = experror;
		for(String S: expErrorlist) {
			switch(S) {
				case "Manager Name must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Manager Name Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Vestmark Manager Name must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Vestmark Manager Name Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Investment Style must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Investment Style Name Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Risk Category must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Risk Category Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Portfolio Manager must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Portfolio Manager Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Strategy Minimum (MEPS) must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Strategy Minimum (MEPS) Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Exception Minimum (RAW) must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Exception Minimum (RAW) Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Withdrawal/Rebalance Minimum (RAW) must not be empty or not valid":
					Element = (WebElement)action
							.getElementByJavascript("Withdrawal/Rebalance Minimum (RAW) Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Fee Schedule Type must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Fee Schedule Type Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Manager Fee (TS) must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Manager Fee (TS) Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Research Rating must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Research Rating Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "AAR Base Template must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("AAR Base Template Error Message");
					action.scrollToElement(Element);
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				case "Comparative Universe must not be empty or not valid":
					Element = (WebElement)action.getElementByJavascript("Comparative Universe Error Message");
					//action.scrollToElement(Element);
					action.scrollToBottom();
					assertTrue(Element.isDisplayed());
					assertTrue(Element.getText().equalsIgnoreCase(S));
					Reporter.addStepLog("Actual Message: " + Element.getText());
					Reporter.addStepLog("Expected Message: " + S);
					flag = true;
					break;
				default:
					Reporter.addStepLog("Expected Message: " + S);
					Reporter.addStepLog("Expected Error Message is invalid ");
					flag = false;
					break;
			}
			if(flag == false)
				break;
		}
		return flag;
	}

	public String getStrategyName() {
		Element = action.getElement("Strategy Name Attribute Value");
		//System.out.println(Element.getAttribute("value"));
		//System.out.println("test");
		return Element.getAttribute("value");
	}

	public boolean isPMLinkVisible() {
		Element = action.waitForJSWebElement("Product Master Link");
		if(Element.isDisplayed()) {
			return true;
		}
		return false;
	}

	public void clickOnPMLink() {
		Element = action.getElement("Product Master Link");
		Element.click();
	}

	public boolean isProgramNameDisplayed() {
		Element = action.waitForJSWebElement("SMA Single Access Text");
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isStrategyNameValueDisplayed(String data) {
		Element = action.waitForJSWebElement("Strategy name Displayed Text");
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void clickOnResetButton() {
		Element = action.waitForJSWebElement("Reset");
		Element.click();
	}

	public boolean checkPrepopulatedStrategyName(String data) {
		String strategyNameValue = action.getAttribute(action.getElement("Strategy Name Attribute Value"), "value");
		if(strategyNameValue.equals(data)) {
			return true;
		}
		return false;
	}

	public boolean isStrategyNameFieldEditable() {
		Element = (WebElement)action.getElementByJavascript("Strategy Name");
		Element.click();
		Element.clear();
		Element.sendKeys("editable");
		String strategyNameValue = action.getAttribute(action.getElement("Strategy Name Attribute Value"), "value");
		if(strategyNameValue.equals("editable")) {
			return true;
		}
		return false;
	}

	public boolean isCreateStrategyTextDisplayed() {
		Element = action.getElement("Create Strategy after Product Master Link");
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isTimeStampDisplayed() {
		Element = action.getElement("Time Stamp");
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isVestmarkManagerNamePrepopulated() {
		action.waitForJSWebElement("Vestmark Manager Name");
		Element = action.getElement("VestMark Manager Name Attribute Value");
		String value = action.getAttribute(Element, "value");
		//System.out.println(value);
		if(value != null) {
			return true;
		}
		return false;
	}

	public void clearVestMarkManagerName() {
		Element = action.waitForJSWebElement("Vestmark Manager Name");
		Element.click();
		Element.clear();
	}

	public boolean isVestMarkManageryNameFieldEditable() {
		Element = (WebElement)action.getElementByJavascript("Vestmark Manager Name");
		Element.click();
		Element.clear();
		Element.sendKeys("editable");
		String VestMarkManagerNameValue = action
				.getAttribute(action.getElement("VestMark Manager Name Attribute Value"), "value");
		if(VestMarkManagerNameValue.equals("editable")) {
			return true;
		}
		return false;
	}

	public void enterVestmarkManagerName() {
		Element = action.waitForJSWebElement("Vestmark Manager Name");
		Element.click();
		Element.sendKeys("Test");
	}

	public boolean isISManagerProfileFieldEditable() {
		Element = action.waitForJSWebElement("IS Manager Profile");
		action.moveToElement(Element);
		action.highligthElement(Element);
		Element.click();
		action.pause(500);
		String isManagerProfileValue = action.getAttribute(Element, "class");
		if(isManagerProfileValue.equals("clicked checking")) {
			return true;
		}
		return false;
	}

	public boolean isMSAPresent() {
		action.pause(500);
		Element = action.getElement("MSA");
		action.scrollToElement(Element);
		if(Element.isDisplayed()) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public boolean isMSAOptional() {
		Element = action.getElement("MSAOptional");
		if(Element.isDisplayed()) {
			return true;
		}
		return false;
	}

	public boolean isUnderlyingStrategyNameMandatory() {
		Element = action.waitForJSWebElement("UnderlyingStrategyNameRequired");
		action.highligthElement(Element);
		action.pause(500);
		String isUnderlyingStrategyName = action.getAttribute(Element, "class");
		if(isUnderlyingStrategyName.equals("required")) {
			return true;
		}
		return false;
	}
	
	public String isUnderlyingStartegyAllocationPercenatageIsEqualToTotal() {
			return (String)action.getElementByJavascript("Underlying Strategy Allocation Text");
	}
}
