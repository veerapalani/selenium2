package qa.unicorn.ad.productmaster.webui.pages;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.impl.Jdk13LumberjackLogger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.bouncycastle.jcajce.provider.symmetric.util.PBE;
import org.codehaus.groovy.ast.stmt.TryCatchStatement;
import org.json.JSONObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.ibm.db2.jcc.a.i;
import com.ibm.db2.jcc.am.l;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.FileManager;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.utils.SystemProcess;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.stepdefs.CreatePMPStrategyConfirmationStepDef;

public class CreateEntitySWPUIPage 
{	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleSWPAAP1.xlsx";
	String sheetName = "";
	String myValue,myValue1;
	XSSFSheet sheet,inputSheet;
	int rowIndex, cellIndex;
	WebElement myElement,myElement1;
	List<WebElement> myElements;
	Boolean compareBoolean;
	String completeSqlQuery = null;
	ResultSet allResultMain = null;
	String timeStamp = new SimpleDateFormat("dd-MM-yyyy(HH:mm)").format(new Date());
	String Code;
	String proxyDetails[]= {"Proxy Address","Voluntary Reorg Address","Interim Address"};

//	String scenario[]= {"0","2","4"};
	int num;
	List<List<String>> attributeLists = new ArrayList<List<String>>();
	List<String> dataList = new ArrayList<String>() ;
	//	UpdateStrategyPage updateStrategyPage = new UpdateStrategyPage();
	//Action action1 = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategyUIPage"));
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateEntityPage"));		

	UpdateStrategySMADualUIPage updateStrategyPage = new UpdateStrategySMADualUIPage();
	
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	
	StrategyDetailPage strDtl = new StrategyDetailPage();
	
	SoftAssert sftAst = new SoftAssert();
	
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	DecimalFormat format = new DecimalFormat("0.##");

	HashMap<String, String> DropDownValues = new HashMap<String, String>();
	HashMap<String, String> InputValues = new HashMap<String, String>();
	HashMap<String, String> DropDownValuesId = new HashMap<String, String>();
	HashMap<String, String> InputValuesId = new HashMap<String, String>();
	HashMap<String, Double> BenchmarkValues = new HashMap<String, Double>();
	HashMap<String, String> ProxyValues = new HashMap<String, String>();

	HashMap<String ,HashMap<String,Double>> BenchmarkDetails = new HashMap<String ,HashMap<String,Double>>();
	HashMap<String ,HashMap<String,String>> ProxyDetails = new HashMap<String ,HashMap<String,String>>();
	HashMap<String ,HashMap<String,String>> DocumentDetails = new HashMap<String ,HashMap<String,String>>();
	HashMap<String ,HashMap<String,String>> CommentDetails = new HashMap<String ,HashMap<String,String>>();

	HashMap<String ,ArrayList<String>> NewInputValues = new HashMap<String ,ArrayList<String>>();

	//String applicationPropertyFilePath = "./application.properties";
	//PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	//String UIEnvironment = property.getProperty("ProductMaster_UI_Environment").trim().toUpperCase();

	//static String configFilePath = "./config.properties";
	//static PropertyFileUtils configProp = new PropertyFileUtils(configFilePath);	
	//public static String UIEnvironment = configProp.getProperty("environment").trim().toUpperCase();
	
	 String UIEnvironment = SSOLoginPage.UIEnvironment.trim().toUpperCase();
	
	Runtime r = null;
	Process p = null;
	String kafkaPath ="D://kafka_2.13-2.4.0//bin//windows";
	String NHLogFilePath=System.getProperty("user.dir")+"/temp/NH_DataGenerated.log";
	String DHLogFilePath=System.getProperty("user.dir")+"/temp/DH_DataGenerated.log";
	
	public WebElement findElementByDynamicXpath(String xpath) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public WebElement findElementByDynamicXpathWithWait(String xpath) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		waitForWebElement(xpath);
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public WebElement findElementByDynamicXpathWithRefresh(String xpath) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		String status = waitForWebElement(xpath);
		if(status.contentEquals("FAIL")) 
		{
			action.refresh();
			action.waitForPageLoad();
		}

		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}


	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		listOfElements = element.getElements("xpath", xpath);
		return listOfElements;
	}
	
	public WebElement findElementByCssSelector(String css) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("cssselector", css);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public List<WebElement> getDynamicElementsFromShadowRoot(String javaScript) 
	{
		return listOfElements = (List<WebElement>)action.executeJavaScript(javaScript);
	}
	
	public String waitForWebElement(String xpath) 
	{

		int timeLaps = 0;
		String status = "FAIL";
		WebElement jsElement = null;
		while (status.equals("FAIL") && timeLaps < 2) {
			try {

				//jsElement = (WebElement) getElementByJavascript(dbkey);
				//jsElement = (WebElement) getElement(dbkey);
				jsElement = findElementByDynamicXpath(xpath);
				
				if (jsElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Exception e) {

				status = "FAIL";

			}

			Action.pause(2000);
			++timeLaps;

		}

		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);

		return status;
	}
	
	public final boolean isPresent(String value)
	{
		boolean isPresent = false;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		while(true) 
		{
			try 
			{
				js.executeScript(value);
				isPresent = true;
				break;
			} catch (Exception e) 
			{
				break;
			} 
		}
		
		return isPresent;
	}
	
	public final Object executeJavaScript(String javaScript)
	{
		waitForJavaScript(javaScript);
		
		Object scriptReturn = null;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try 
		{
			scriptReturn = js.executeScript(javaScript);
			status = "PASS";

		} 
		catch (Exception e)
		{
			ExceptionHandler.handleException(e);
		} 
		finally 
		{
			Report.printOperation("Execute Javascript");
			Report.printValue(javaScript);
			Report.printStatus(status);
		}

		return scriptReturn;
	}
	
	public void myClear(WebElement element)
	{		
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		js.executeScript("arguments[0].value='';", element);
	}
	
	public final Object executeJavaScriptWithoutWait(String javaScript)
	{		
		Object scriptReturn = null;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try 
		{
			scriptReturn = js.executeScript(javaScript);
			status = "PASS";
		} 
		catch (Exception e)
		{
			ExceptionHandler.handleException(e);
		} 
		finally 
		{
			Report.printOperation("Execute Javascript");
			Report.printValue(javaScript);
			Report.printStatus(status);
		}

		return scriptReturn;
	}

	
	public String waitForJavaScript(String javaScript) 
	{		
		int timeLaps = 0;
		String status = "FAIL";
		Object jsElement = null;
		while (status.equals("FAIL") && timeLaps < GlobalVariables.waitTime*10) {
			try {

				//jsElement = (WebElement) getElementByJavascript(dbkey);
				//jsElement = (WebElement) getElement(dbkey);
				jsElement = action.executeJavaScript(javaScript);
				
				if (jsElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Throwable e) {

				status = "FAIL";
			}

			Action.pause(100);
			++timeLaps;

		}
		
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);

		return status;

	}
	
	public void sendKeysWithCheck(WebElement element, String value)
	{
		try 
		{
			action.sendKeys(element, value);
			while(true) 
			{
				Thread.sleep(500);
				if(!(element.getAttribute("value").trim().equalsIgnoreCase(value))) 
				{
					myClear(element);
					//action.clear(element);
					action.sendKeys(element, value);
				}
				else 
				{
					System.out.println("Input :"+element.getAttribute("value"));
					break;
				}
			}
			
		} 
		catch (Exception e) 
		{
			ExceptionHandler.handleException(e);
		} 
	}
	
	public void writeIntoExcel(String inputSheetName, String feildName,String valueToBeStored)
	{
		inputSheet = exlObj.getSheet(inputSheetName);
		rowIndex = exlObj.getRowIndexByCellValue(inputSheet, 0, "Valid_Data_"+UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(inputSheet, 0, feildName);
		exlObj.setCellData(inputSheet, rowIndex, cellIndex, valueToBeStored);

	}
	
	
	public Map<String, String> sortTheCollection(Map<String, String> unsortMap, final boolean order) throws Throwable
	{
		List<Entry<String, String>> list = new LinkedList<Entry<String,String>>(unsortMap.entrySet());
		
		Collections.sort(list, new Comparator<Entry<String,String>>() 
		{
			public int compare(Entry<String,String> o1,Entry<String,String> o2)	
			{
				if(order) 
				{
					return o1.getValue().compareTo(o2.getValue());
				}
				else
				{
					return o2.getValue().compareTo(o1.getValue());
				}
			}
		});
	
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		for(Entry<String,String> entry : list)
		{
			sortedMap.put(entry.getKey(),entry.getValue());
		}
		return sortedMap;
	}
	
	public Map<String, Double> sortTheCollectionInt(Map<String, Double> unsortMap, final boolean order) throws Throwable
	{
		List<Entry<String, Double>> list = new LinkedList<Entry<String,Double>>(unsortMap.entrySet());
		
		Collections.sort(list, new Comparator<Entry<String,Double>>() 
		{
			public int compare(Entry<String,Double> o1,Entry<String,Double> o2)	
			{
				if(order) 
				{
					return o1.getValue().compareTo(o2.getValue());
				}
				else
				{
					return o2.getValue().compareTo(o1.getValue());
				}
			}
		});
	
		Map<String, Double> sortedMap = new LinkedHashMap<String, Double>();
		for(Entry<String,Double> entry : list)
		{
			sortedMap.put(entry.getKey(),entry.getValue());
		}
		return sortedMap;
	}	
	
	public void edit_all_the_below_drop_down_fields_with_valid(List<List<String>> attribute) throws Throwable
    {
	  	String sheetName = "Valid";
			XSSFSheet sheet = exlObj.getSheet(sheetName);
			Thread.sleep(2000);
			for (int i = 0; i < attribute.size(); i++)
			{

				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				if(myElement.isEnabled())
				{
				action.scrollToElement(myElement);
				action.click(myElement);
				Thread.sleep(2000);
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				String myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector(\"li[data-value='" + myValue + "']\")");
				
				System.out.println(myElement.getText());
				
				//updateStrategyPage.writeIntoExcel(attribute.get(i).get(0), myElement.getText());
								
				action.scrollToElement(myElement);
				Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

				action.click(myElement);
				Thread.sleep(2000);
				
				}
				  
			}
    }
	
	public final Object executeJavaScriptWithRefresh(String javaScript) 
	{
		Object scriptReturn = null;

		String status = waitForJavaScript(javaScript);
		System.out.println(status);
		
		if(status.contentEquals("FAIL")) 
		{		
			action.refresh();
			System.out.println("Refreshing the page");
			Reporter.addStepLog("Refreshing the page");
			action.waitForPageLoad();
		}
	
		scriptReturn = (Object)executeJavaScript(javaScript);
		return scriptReturn;
		
	}
	
	public synchronized void globalSearch(String searchCode,String entity,String scenario) throws Throwable
	{
			action.waitForPageLoad();
			//Thread.sleep(5000);
			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchCode);

			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			Code = myValue;
			System.out.println("code "+Code);
			
	 		compareBoolean = action.isPresent("js", "return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			if(compareBoolean)
			{
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
				myElement.click();
			}
			
			Thread.sleep(2000);
			compareBoolean = action.isPresent("js", "return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			if(compareBoolean)
			{
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
				myElement.click();
			}
			
			myElement = (WebElement)executeJavaScriptWithRefresh("return document.querySelector(\"brml-search-input\")");
			myElement.click();
			action.sendKeys(myElement, myValue);
			//sendKeysWithCheck(myElement, myValue);
			Thread.sleep(2000);
			InputValues.put("FOA Code", myValue);

			int i = 0;
			
			while(i < 5)
			{
				myElement.sendKeys(Keys.ENTER);
				i++;
			}
			Thread.sleep(2000);
		}
	
	public synchronized void clickMatchingSuggestion(String searchCode,String entity,String scenario) throws Throwable
	{
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario + UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Entity Type");
		myValue1 = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		Thread.sleep(5000);
		//		waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
		//		System.out.println("clickmatching 2");
		
		if(entity.equalsIgnoreCase("FATeam")) 
		{
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[1]");
		}
		else 
		{
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
		}
		
		String status = "FAIL";
		for(WebElement E: myElements)
		{
			if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
			{
				status = "PASS";
				action.scrollToElement(E);
				action.highligthElement(E);
				Thread.sleep(5000);
				E.click();
				Reporter.addStepLog("clicking on the matching suggestion");
				break;
			}
		}
		
		int i=0;
		while(status.contentEquals("FAIL") && i<3) 
		{
			i++;
			Thread.sleep(5000);
			myElement.sendKeys(Keys.ENTER);
			if(entity.equalsIgnoreCase("FATeam")) 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[1]");
			}
			else 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
			}
			for(WebElement E: myElements) 
			{
				if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
				{
					status = "PASS";
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();
					Reporter.addStepLog("clicking on the matching suggestion");
					break;
				}
			}
		}
		if(status.contentEquals("FAIL")) 
		{
			globalSearch(searchCode, entity, scenario);
			clickMatchingSuggestion1(searchCode, entity, myValue1);
		}
	}
	
	public synchronized void clickMatchingSuggestion1(String searchCode,String entity,String value) throws Throwable
	{
		myValue1 = value;
		Thread.sleep(5000);
		//		waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
		//		System.out.println("clickmatching 2");
		
		if(entity.equalsIgnoreCase("FATeam")) 
		{
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[1]");
		}
		else 
		{
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
		}
		
		String status = "FAIL";
		for(WebElement E: myElements)
		{
			if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
			{
				status = "PASS";
				action.scrollToElement(E);
				action.highligthElement(E);
				Thread.sleep(5000);
				E.click();
				Reporter.addStepLog("clicking on the matching suggestion");
				break;
			}
		}
		
		int i=0;
		while(status.contentEquals("FAIL") && i<3) 
		{
			Thread.sleep(5000);
			myElement.sendKeys(Keys.ENTER);
			if(entity.equalsIgnoreCase("FATeam")) 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[1]");
			}
			else 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
			}
			for(WebElement E: myElements) 
			{
				if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
				{
					status = "PASS";
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();
					Reporter.addStepLog("clicking on the matching suggestion");
					break;
				}
			}
		}
	}
	
	public void waitMatchingSuggestion(String entity) throws Throwable
	{
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Entity Type");
		myValue1 = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		Thread.sleep(5000);
//		waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
//		System.out.println("clickmatching 2");
		
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
			
			String status = "FAIL";
			
			for(WebElement E : myElements)
			{
				if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
				{
					status = "PASS";
					Thread.sleep(1000);
					
					Reporter.addStepLog("waiting on the matching suggestion");
					
					break;
				}
				
			}
				
				if(status.contentEquals("FAIL"))
				{
					myElement.sendKeys(Keys.ENTER);
					
					myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
					for(WebElement E : myElements)
					{
						if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
						{
							status = "PASS";
							Thread.sleep(1000);
							
							Reporter.addStepLog("waiting on the matching suggestion");
							
							break;
						}
						
					}
				}
	}
	
	public void clickButton(String buttonName) throws Throwable
	{
		if(buttonName.contentEquals("Product Master"))
		{
			myElement = findElementByDynamicXpath("(//*[contains(text(),'"+buttonName+"')])[2]");
		}
		else
		{
			myElement = findElementByDynamicXpath("//*[contains(text(),'"+buttonName+"')]");
		}
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog(buttonName+" button is clicked");
		action.waitForPageLoad();
	}
	
	public void checkHeader(String headerName) throws Throwable
	{
		action.waitForPageLoad();

    	myElement = findElementByDynamicXpathWithRefresh("//h4[contains(text(),'"+headerName+"')] | //h3[contains(text(),'"+headerName+"')]");
    	System.out.println(myElement.getText());

    	Assert.assertEquals(myElement.getText(), headerName,headerName+" header is displayed");
		Reporter.addStepLog(headerName+" header is displayed");
	}
	
	public void clickCreateNew() throws Throwable
	{

		myElement = (WebElement)executeJavaScriptWithRefresh("return document.querySelector('brml-select').shadowRoot.querySelector('wf-button')");
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("Clicked on Create New button");
		
	}
	
	public void clickCreateNewOption(String entity) throws Throwable
	{
		try
    	{
	    	myElements = getDynamicElementsFromShadowRoot("return document.querySelector('brml-select').shadowRoot.querySelectorAll('li')");
	    	
	    	for(WebElement E : myElements) 
			{
				if(E.getText().equalsIgnoreCase(entity))
				{
					myElement = E;
					break;
				}
			}
	    	
	    	action.scrollToElement(myElement);
	    	action.highligthElement(myElement);
	    	Thread.sleep(2000);
	    	action.click(myElement);
			Reporter.addStepLog(entity+" is clicked");
			action.waitForPageLoad();
    	}	
    	catch (Exception e) 
    	{
			Assert.fail("Unable to access "+ entity +" option");
		}
	}
	
	public void clickEditLink(String pageName) throws Throwable
	{
		myElement = findElementByDynamicXpath("//h5[contains(text(),'"+pageName+"')]//div[contains(text(),'Edit')]");

		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog(pageName+" link is clicked");
		action.waitForPageLoad();
	}
	
	public void editInputFields(String entity, String scenario,List<List<String>> attribute) throws Throwable
	{
		action.waitForPageLoad();
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
//				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				
				if(attribute.get(i).get(0).contentEquals("Strategy Name"))
				{
					myValue = myValue + timeStamp;
					System.out.println(myValue);
				}
				waitForJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");
				action.highligthElement(myElement);

				if(myElement.isEnabled())
				{
				   action.scrollToElement(myElement);
				   action.clear(myElement);
				   //action.sendKeys(myElement, myValue);
				   sendKeysWithCheck(myElement, myValue);
				   InputValues.put(attribute.get(i).get(0),myValue);
				   Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));
				}
				else
				{
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("value");
					InputValues.put(attribute.get(i).get(0),myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog(attribute.get(i).get(0)+" "+myValue);
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public void editDropDownFields(String entity, String scenario,List<List<String>> attribute) throws Throwable
	{
		action.waitForPageLoad();		
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				waitForJavaScript("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				
				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");

				if(!Boolean.parseBoolean(myValue))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
					
					action.scrollToElement(myElement);
					action.click(myElement);
					Thread.sleep(500);
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					myElements = getDynamicElementsFromShadowRoot("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelectorAll('li')");
									
				for(WebElement E : myElements) 
				{
					if(E.getText().equalsIgnoreCase(myValue))
					{
						myElement = E;
						break;
					}
				}
				
				System.out.println(myElement.getText());
								
				InputValues.put(attribute.get(i).get(0),myElement.getText());
				InputValuesId.put(attribute.get(i).get(1),myElement.getText());
				action.scrollToElement(myElement);
				Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");
				System.out.println(attribute.get(i).get(0)+" "+myValue);
				action.click(myElement);				
				}
				else
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("value");
					if(isPresent("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')"))
					{
						myValue = (String)executeJavaScript("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')");
						//myValue = myValue.replaceAll("-\\d{4}$", "");
					}					
					InputValues.put(attribute.get(i).get(0),myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				}				  
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public void selectDropdownByIndex(String entity, String scenario, List<List<String>> attribute) throws Throwable
	{
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				waitForJavaScript("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");

				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");
				if(!Boolean.parseBoolean(myValue))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
						
					action.scrollToElement(myElement);
					action.click(myElement);
					Thread.sleep(500);
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+attribute.get(i).get(1)+ "\"]').shadowRoot.querySelector(\"li[data-value='" + myValue + "']\")");
					
					System.out.println(myElement.getText());
									
					InputValues.put(attribute.get(i).get(0),myElement.getText());
	
					action.scrollToElement(myElement);
					Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");
	
					action.click(myElement);
				}
				else
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("value");
					if(isPresent("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')"))
					{
						myValue = (String)executeJavaScript("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')");
//						myValue = myValue.replaceAll("-\\d{4}$", "");
					}					
					DropDownValues.put(attribute.get(i).get(0),myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				}
				  
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
    		
	}
	
	public void editTextFields(String entity, String scenario,List<List<String>> attribute) throws Throwable
	{
		action.waitForPageLoad();
		
	/*	excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/Update"+entity+".xlsx";
		this.sheetName = sheetName;
		sheet = new ExcelUtils(ExcelOperation.LOAD, excelFilePath).getSheet(sheetName);*/
		
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				
				if(attribute.get(i).get(0).contentEquals("Comment Description")
						|| attribute.get(i).get(0).contentEquals("Document Description")
						|| attribute.get(i).get(0).contentEquals("Special Instructions (Please provide links)"))
				{
					myValue = myValue + timeStamp;
					System.out.println(myValue);
				}
				
				waitForJavaScript("return document.querySelector('brml-textarea[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('textarea')");
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-textarea[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('textarea')");

				if(myElement.isEnabled())
				{
				   action.scrollToElement(myElement);
				   action.clear(myElement);
				   Thread.sleep(2000);
				   //action.sendKeys(myElement, myValue);
				   sendKeysWithCheck(myElement, myValue);
				   InputValues.put(attribute.get(i).get(0),myValue);
				   InputValuesId.put(attribute.get(i).get(1),myValue);

				   Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));   
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public void editDateFields(String entity, List<List<String>> attribute) throws Throwable
	{
    	for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-calendar-picker[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('wf-input')");
				myElement.click();
				sendKeysWithCheck(myElement, new SimpleDateFormat("MM/dd/yyyy").format(new Date()));

				if(myElement.isEnabled())
				{
					action.scrollToElement(myElement);
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-calendar-picker[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector(\"div.pmu-days > div.pmu-today.pmu-button\")");
					myElement.click();
					InputValues.put(attribute.get(i).get(0), new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
    
	}
	
	public void editCheckBox(String entity,String scenario, List<List<String>> attribute) throws Throwable
	{
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
    	for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				myElement = (WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"')");
				myValue1 = (String)executeJavaScriptWithoutWait("return document.querySelector('#"+attribute.get(i).get(1)+"').getAttribute('checked')");
				
				if(myElement.isEnabled())
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"')");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					
					if(myValue1 == null)
					{
						if(myValue.equalsIgnoreCase("true"))
						{
							myElement.click();
							System.out.println(attribute.get(i).get(0)+" "+"yes");
							InputValues.put(attribute.get(i).get(0), "Yes");
						}
						if(myValue.equalsIgnoreCase("false"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"no");
							InputValues.put(attribute.get(i).get(0), "No");
						}
					}
					else if(!myValue.equalsIgnoreCase(myValue1)) 
					{
						myElement.click();
						if(myValue.equalsIgnoreCase("true"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"yes");
							InputValues.put(attribute.get(i).get(0), "Yes");
						}
						if(myValue.equalsIgnoreCase("false"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"no");
							InputValues.put(attribute.get(i).get(0), "No");
						}
					}
					else
					{
						if(myValue.equalsIgnoreCase("true"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"yes");
							InputValues.put(attribute.get(i).get(0), "Yes");
						}
						if(myValue.equalsIgnoreCase("false"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"no");
							InputValues.put(attribute.get(i).get(0), "No");
						}
					}
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}    
	}
	
	public void clickCurrentDate(String id) throws Throwable
	{
		myElement = (WebElement)executeJavaScript("return document.querySelector(\"#"+id+"\").shadowRoot.querySelector(\"wf-input\")");
		if(myElement.isEnabled()) 
		{
			action.jsClick(myElement);
			Thread.sleep(1000);
			
			myElement = (WebElement)executeJavaScript("return document.querySelector('brml-calendar-picker[id=\""+id+"\"]').shadowRoot.querySelector(\"div.pmu-days > div.pmu-today.pmu-button\")");
			action.jsClick(myElement);
			Thread.sleep(1000);
			
			myElement = (WebElement)executeJavaScript("return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");
			action.jsClick(myElement);				
			Thread.sleep(2000);
		}
	}
	
	public void clickPreviousDate(String id) throws Throwable
	{
		myElement = (WebElement)executeJavaScript("return document.querySelector(\"#"+id+"\").shadowRoot.querySelector(\"wf-input\")");
		myValue = new SimpleDateFormat("yyyy-MM-dd").format(new Date(System.currentTimeMillis()-24*60*60*1000));

		if(myElement.isEnabled()) 
		{
			action.jsClick(myElement);
			Thread.sleep(1000);
			
			action.executeJavaScript("return document.querySelector(\"#"+id+"\").setAttribute(\"date\",\""+myValue+"\")");
			Thread.sleep(1000);
			myElement = (WebElement)executeJavaScript("return document.querySelector('brml-calendar-picker[id=\""+id+"\"]').shadowRoot.querySelector(\"div.pmu-days > div.pmu-today.pmu-button\").previousSibling");
			action.jsClick(myElement);
			Thread.sleep(1000);
			}
						
			myElement = (WebElement)executeJavaScript("return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");
			action.jsClick(myElement);				
			Thread.sleep(2000);
		}
	
	public void checkInputEdits() throws Throwable
	{
		/*	System.out.println(Arrays.asList(InputValues));
				for (Map.Entry<String, String> data : InputValues.entrySet())
				{
					if(data.getKey().equalsIgnoreCase("Document Link"))
					{
						
					}
					else if (!data.getValue().isEmpty())
					{
						myValue = data.getValue();
						System.out.println(data.getKey()+" "+data.getValue());
						myElements = findElementsByDynamicXpath("//*[contains(text(),'"+myValue+"')]");
						for(WebElement E : myElements)
						{
							sftAst.assertTrue(E.isDisplayed(), " "+myValue+"is displayed");
							action.scrollToElement(E);
							action.highligthElement(E);
							Reporter.addStepLog(myValue + " is displayed for " + data.getKey());
							Thread.sleep(500);
						}
					}
				}*/
		InputValues.putAll(DropDownValues);
		System.out.println(Arrays.asList(InputValues));
		for (Map.Entry<String, String> data : InputValues.entrySet())
		{
			myValue = data.getValue();
			if(data.getKey().equalsIgnoreCase("Benchmark Effective Date Type") || data.getKey().equalsIgnoreCase("Custom BM Reason")) 
			{
				myElements.clear();
			}
			else 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + data.getKey() + "')]//following::div[1]");
			}
			for(WebElement E: myElements) 
			{
				if(data.getValue().isEmpty())
				{
					myValue = "—";
				}
				System.out.println(data.getKey() + " Stored Value: " + data.getValue() + " Displayed Value: " + E.getText());
				sftAst.assertEquals(E.getText().toLowerCase(), myValue.toLowerCase(), data.getKey());
				action.scrollToElement(E);
				action.highligthElement(E);
				Reporter.addStepLog(data.getKey() + " Stored Value: " + data.getValue() + " Displayed Value: " + E.getText());
				Thread.sleep(200);
				break;
			}
		}
	  }
	
	/*public void checkBenchmarkEdits(HashMap<String, String> Map, String entity) throws Throwable
    {
		int i =1;
		System.out.println(Arrays.asList(Map));

			for (Map.Entry<String, String> data : Map.entrySet())
			{
				if (!data.getValue().isEmpty())
				{
					myElement = findElementByDynamicXpath("//b[contains(text(),'Benchmark')]//parent::div//label[contains(text(),'Custom')]//parent::div//following-sibling::div["+i+"]");
						
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					System.out.println("Stored Benchmark: "+data.getKey()+"-"+data.getValue()+"% Displayed Benchmark: "+myElement.getText());
					sftAst.assertEquals(myElement.getText(), data.getKey()+"-"+data.getValue()+"% ");
					Reporter.addStepLog("Stored Benchmark: "+data.getKey()+"-"+data.getValue()+"% Displayed Benchmark: "+myElement.getText());
					i++;
					Thread.sleep(500);
				}
			}
    }*/
	
	public void checkBenchmarkEdits() throws Throwable
    {
		System.out.println(Arrays.asList(BenchmarkDetails));
		
			for (Map.Entry<String, HashMap<String, Double>> data : BenchmarkDetails.entrySet())
			{
				int i =1;
				if (!data.getValue().isEmpty() && (data.getKey().equalsIgnoreCase("Custom Benchmark BM") || data.getKey().equalsIgnoreCase("Custom Benchmark BM 1")))
				{				
					for (Map.Entry<String, Double> list : data.getValue().entrySet())
					{				
						myElement = findElementByDynamicXpath("//div[contains(@class,'col-4 mb6')]["+i+"] | //div[contains(@class,'col-6 mb6')]["+i+"]");
						myValue = myElement.getText();				

						myElement1 = findElementByDynamicXpath("//div[contains(@class,'col-4 mb6')]["+(i+1)+"] | //div[contains(@class,'col-6 mb6')]["+(i+1)+"]");

						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						System.out.println("Stored Benchmark: "+list.getKey()+"-"+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"-"+myElement1.getText());
						sftAst.assertEquals(myValue+"-"+myElement1.getText(), list.getKey()+"-"+format.format(list.getValue())+"%");
						Reporter.addStepLog("Stored Benchmark: "+list.getKey()+"-"+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"-"+myElement1.getText());
						i+=2;
						Thread.sleep(300);
					}
				}
				else if (!data.getValue().isEmpty() && (data.getKey().equalsIgnoreCase("UnBundled Node ID BM") || data.getKey().equalsIgnoreCase("UnBundled Node ID BM 1")))
				{				
					for (Map.Entry<String, Double> list : data.getValue().entrySet())
					{				
						myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[class='col-2 mb12'] > div > div[class='body-3 mb6']\")["+(i-1)+"]");
						myValue = myElement.getText();
						action.scrollToElement(myElement);
						action.highligthElement(myElement);						
//						System.out.println("Stored Benchmark: "+list.getKey().replaceAll("-\\d{4}$", "")+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
						System.out.println("Stored Benchmark: "+list.getKey().replaceAll("-\\d{4}$", "")+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
						sftAst.assertEquals(myValue, list.getKey()+" - "+format.format(list.getValue())+".00%");
						Reporter.addStepLog("Stored Benchmark: "+list.getKey()+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
						i++;
						Thread.sleep(300);
					}
				}
				else if (!data.getValue().isEmpty() && (data.getKey().equalsIgnoreCase("Bundled Node ID BM")))
				{				
					for (Map.Entry<String, Double> list : data.getValue().entrySet())
					{				
						myElement = findElementByDynamicXpath("//div[contains(@class,'body-3 mb6')]");

						myValue = myElement.getText();
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
//						System.out.println("Stored Benchmark: "+list.getKey().replaceAll("-\\d{4}$", "")+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
						System.out.println("Stored Benchmark: "+list.getKey()+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
						sftAst.assertEquals(myValue, list.getKey()+" - "+format.format(list.getValue())+".00%");
						Reporter.addStepLog("Stored Benchmark: "+list.getKey()+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
						i++;
						Thread.sleep(300);
					}				
				}
			}
    }
	
	public void checkPEEdits() throws Throwable
    {
		/*Iterator it = NewInputValues.keySet().iterator();
		ArrayList<String> tempList = null;
		
		while(it.hasNext()) 
		{
			String key = it.next().toString();
			tempList = NewInputValues.get(key);
			if(tempList != null) 
			{
				for(String value: tempList) 
				{
					//System.out.println("Key "+key+" value "+value);
					System.out.println("Key "+key+" value "+value);
				}
			}
		}*/
		

		System.out.println(Arrays.asList(InputValues));
			for (Entry<String, ArrayList<String>> data : NewInputValues.entrySet())
			{
				if (!data.getValue().isEmpty())
				{
					myValue = data.getValue().get(0);
					myValue1 = data.getValue().get(1);
					System.out.println(data.getKey()+" "+myValue+" "+myValue1);
					myElement = findElementByDynamicXpathWithRefresh("//label[contains(text(),'"+data.getKey()+"')]//parent::b//parent::div//following-sibling::div//label[contains(text(),'Retirement Account Eligible')]//following-sibling::div");
					myElement1 = findElementByDynamicXpathWithRefresh("//label[contains(text(),'"+data.getKey()+"')]//parent::b//parent::div//following-sibling::div//label[contains(text(),'Non-retirement Account Eligible')]//following-sibling::div");

					sftAst.assertEquals(myElement.getText().trim(), myValue);
					sftAst.assertEquals(myElement1.getText().trim(), myValue1);

					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					action.highligthElement(myElement1);

					Reporter.addStepLog(myValue + " is displayed for Retirement Account Eligible " + data.getKey());
					Reporter.addStepLog(myValue1 + " is displayed for Non-retirement Account Eligible " + data.getKey());

					Thread.sleep(500);
				}
			}
    Thread.sleep(10000);
		
    }
	
	public void checkDropdownEdits() throws Throwable
    {
		/*System.out.println(Arrays.asList(DropDownValues));

		Thread.sleep(500);
		Reporter.addScreenCapture();
		for (Map.Entry<String, String> data : DropDownValues.entrySet())
		{
			if(data.getKey().equalsIgnoreCase("Document Type"))
			{
				
			}
			else if (!data.getValue().isEmpty())
			{
				myValue = data.getValue();
				System.out.println(myValue);
				myElements = findElementsByDynamicXpath("//*[contains(text(),'"+myValue+"')]");
				for(WebElement E : myElements)
				{
					sftAst.assertTrue(E.isDisplayed(), " "+myValue+"is displayed");
					action.scrollToElement(E);
					action.highligthElement(E);
					Reporter.addStepLog(myValue + " is displayed for " + data.getKey());
					Thread.sleep(500);
				}
			}
		}*/
		
		System.out.println(Arrays.asList(DropDownValues));
		for (Map.Entry<String, String> data : DropDownValues.entrySet())
		{			
			if (!data.getValue().isEmpty())
			{
				myValue = data.getValue();

				if(data.getKey().equalsIgnoreCase("Document Type") || data.getKey().equalsIgnoreCase("Comment Type") )
				{		

				}			
				else
				{
					myElements = findElementsByDynamicXpath("//label[contains(text(),'"+data.getKey()+"')]//following::div[1]");
				}
				
				for(WebElement E : myElements)
				{
					System.out.println(data.getKey()+" Stored Value: "+data.getValue()+" Displayed Value: "+E.getText());
	
					sftAst.assertEquals(E.getText(), myValue );
					action.scrollToElement(E);
					action.highligthElement(E);
					Reporter.addStepLog(data.getKey()+" Stored Value: "+data.getValue()+" Displayed Value: "+E.getText());
					Thread.sleep(500);
					break;
				}

			}
		}
    }
	
	public void checkProxyEdits() throws Throwable
	{
		System.out.println(Arrays.asList(ProxyDetails));
		
		for (Map.Entry<String, HashMap<String, String>> data : ProxyDetails.entrySet())
		{			
			System.out.println(data.getKey());
				for (Map.Entry<String, String> list : data.getValue().entrySet())
				{				
					myElement = findElementByDynamicXpath("//h6[contains(text(),'"+data.getKey()+"')]//parent::div//label[contains(text(),'"+list.getKey()+"')]//following-sibling::div[1]");
					myValue = myElement.getText();				

					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					Thread.sleep(500);
					if(myValue.contentEquals("—")) 
					{
						myValue = "";
					}
					System.out.println("Stored Value: "+list.getValue()+" Displayed Value: "+myValue);
					sftAst.assertEquals(myValue,list.getValue(),list.getKey());
					Reporter.addStepLog("Stored Value: "+list.getValue()+" Displayed Value: "+myValue);
				}
		}
	}
	
	public void checkDocumentEdits() throws Throwable
	{
		int j=1;
		for(int i = 1; i <= DocumentDetails.size()*3; i+=3)
		{
			HashMap<String, String> list = DocumentDetails.get("Document"+j);
			
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Documents')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+i+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Type")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Type"),"Document Type"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Type")+" Displayed Value: "+myElement.getText());
			
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Documents')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(i+1)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Link")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Link"),"Document Link"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Link")+" Displayed Value: "+myElement.getText());
		
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Documents')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(i+2)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Description")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Description"),"Document Description"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Description")+" Displayed Value: "+myElement.getText());		
			j++;
		}

	}
	
	public void checkCommentsEdits() throws Throwable
	{
		int j=1;
		for(int i = 1; i <= CommentDetails.size()*2; i+=2)
		{
			HashMap<String, String> list = CommentDetails.get("Comment"+j);
			
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Home Office Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+i+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Comment Type")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Comment Type"),"Comment Type"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Comment Type")+" Displayed Value: "+myElement.getText());
			
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Home Office Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(i+1)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Comment Description")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Comment Description"),"Comment Description"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Comment Description")+" Displayed Value: "+myElement.getText());
			j++;
		}

	}
	
	public void storeValuesDetailsPage(List<List<String>> attribute) throws Throwable
	{		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				myValue = findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']").getAttribute("value");
				action.scrollToElement(findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']"));
				if(attribute.get(i).get(0).contentEquals("Investment Style")) 
				{
					myValue = findElementByDynamicXpath("//brml-select-option[@value='"+myValue+"']").getAttribute("name");
				}
				System.out.println(attribute.get(i).get(0)+" : "+myValue);
				DropDownValues.put(attribute.get(i).get(0), myValue);
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public void storeCheckBoxDeatilsPage(List<List<String>> attribute) throws Throwable
	{
    	for (int i = 0; i < attribute.size(); i++)
		{
//			try
//			{
				action.highligthElement((WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"')"));
				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('#"+attribute.get(i).get(1)+"').getAttribute('checked')");
				System.out.println(attribute.get(i).get(0)+myValue);
				
				if(myValue==null || myValue.equalsIgnoreCase("false") ) 
				{
					DropDownValues.put(attribute.get(i).get(0), "No");
				}
				else if(myValue.equalsIgnoreCase("true"))
				{
					DropDownValues.put(attribute.get(i).get(0), "Yes");
				}

//			}
//			catch (Exception e)
//			{
//				Assert.fail("Unable to access "+attribute.get(i).get(0) );
//			}
		} 
    	System.out.println(DropDownValues);
	}
	
	/*public void storeSelectedBenchmark() throws Throwable
	{
		try 
		{
			myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\" wf-radio-option\")")
			myValue = findElementByDynamicXpath("//*[@id='" + attribute.get(i).get(1) + "']").getAttribute("value");
			System.out.println(attribute.get(i).get(0) + " : " + myValue);
			InputValues.put(attribute.get(i).get(0), myValue);
		}
		catch(Exception e) 
		{
			Assert.fail("Unable to access " + attribute.get(i).get(0));
		}
	}*/
	
	public void checkDropdownEditsOnUpdatePage(String entity,List<List<String>> attribute) throws Throwable
	{
		System.out.println(Arrays.asList(DropDownValues));
    	
    	for (int i = 0; i < attribute.size(); i++)
		{
				myValue = DropDownValues.get(attribute.get(i).get(0));
				action.scrollToElement(findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']"));
				myValue1 = findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']").getAttribute("value");
				System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
				Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
				sftAst.assertEquals(myValue1, myValue);
				Thread.sleep(1000);		
		}
    	
	}
	
	public void checkProxyEditsOnUpdatePage(HashMap<String ,HashMap<String,String>> Map,List<List<String>> attribute) throws Throwable
	{
		for (int j = 0; j < proxyDetails.length; j++)
		{	
			HashMap<String, String> data = Map.get(proxyDetails[j]);
			System.out.println(data);
	    	for (int i = 0; i < attribute.size(); i++)
				{				
					myElement = findElementByDynamicXpath("(//*[@id='"+attribute.get(i).get(1)+"'])["+(j+1)+"]");
					myValue = myElement.getAttribute("value");			

					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					Thread.sleep(1000);
					System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+data.get(attribute.get(i).get(0)));
					Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+data.get(attribute.get(i).get(0)));
					sftAst.assertEquals(myValue,data.get(attribute.get(i).get(0)));
					Thread.sleep(500);
				}
		}
	}
	
	public void storeBenchmarkDetails(List<Map<String,String>> attribute) throws Throwable
    {		
		BenchmarkValues.clear();
		
			for(int i = 0; i < attribute.size(); i++)
			{
				if(attribute.get(i).get("Dropdown Name").contains("Custom Benchmark BM")) 
				{
//					if(((String)executeJavaScript("return document.querySelectorAll(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option\")[0].shadowRoot.querySelector(\"button\").getAttribute('class')")).contentEquals("checked"))
					if(((String)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1\").getAttribute('value')")).contentEquals("style"))
					{
						selectBenchmarkType("Style");
						continue;
					}
				}
				int j=0;
					myElements = findElementsByDynamicXpath("//brml-select[contains(@id,'"+attribute.get(i).get("Dropdown ID")+"')]");
					for(WebElement E : myElements )
					{
						myValue = E.getAttribute("value");
						myElement = findElementByDynamicXpath("(//brml-select-option[@value='"+myValue+"'])[1]");
						myValue = myElement.getAttribute("name");
//						myValue = myValue.replaceAll("^.+?-\\s|-\\d{4}$","");
						myValue = myValue.replaceAll("^.+?-\\s","");

						double percentage = Double.parseDouble((String)findElementByDynamicXpath("//brml-stepper-input[@id='"+attribute.get(i).get("Percentage ID")+j+"']").getAttribute("value"));
						BenchmarkValues.put(myValue, percentage);
						j++;
					}
					
					BenchmarkDetails.put(attribute.get(i).get("Dropdown Name"), addValues1(BenchmarkDetails, attribute.get(i).get("Dropdown Name"), BenchmarkValues));
					BenchmarkValues.clear();
			}
			if(isPresent("return document.querySelector('brml-textarea[id=\"txtCustomReasonSet1\"]').shadowRoot.querySelector('textarea')"))
			{
				 myElement = (WebElement)executeJavaScript("return document.querySelector('brml-textarea[id=\"txtCustomReasonSet1\"]').shadowRoot.querySelector('textarea')");
				 myValue = myElement.getAttribute("value");
				 DropDownValues.put("Custom BM Reason",myValue);
				 System.out.println("Custom BM Reason "+myValue);
				 Reporter.addStepLog("Custom BM Reason "+myValue);
			}
		//sftAst.assertAll();
			System.out.println(BenchmarkDetails);
    
    }
	
	public void storeProxyDetails(List<List<String>> attribute) throws Throwable
	{	
		ProxyValues.clear();
		
		for(int j = 0; j < proxyDetails.length; j++) 
		{
			for(int i = 0; i < attribute.size(); i++) 
			{
				myElement = findElementByDynamicXpath("(//*[@id='" + attribute.get(i).get(1) + "'])[" + (j + 1) + "]");
				myValue = myElement.getAttribute("value");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				Thread.sleep(200);
				ProxyValues.put(attribute.get(i).get(0), myValue);
			}
			ProxyDetails.put(proxyDetails[j], addValuesString(ProxyDetails, proxyDetails[j], ProxyValues));
			ProxyValues.clear();
		}
		System.out.println(ProxyDetails);
	}
	
	public void storeDocumentsDetails() throws Throwable
	{
		ProxyValues.clear();
		DocumentDetails.clear();
		waitForJavaScript("return document.querySelector(\"tr\")");
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"tr\")");
		for(int j = 1; j < myElements.size(); j++) 
		{
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('td')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('td').textContent");
			ProxyValues.put("Document Type", myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('brml-button')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('brml-button').textContent");
			ProxyValues.put("Document Link", myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelectorAll('brml-button')[1]"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelectorAll('brml-button')[1].textContent");
			ProxyValues.put("Document Description", myValue);
			DocumentDetails.put("Document"+j, addValuesString(ProxyDetails, "Document"+j, ProxyValues));
			ProxyValues.clear();
		}
		System.out.println(DocumentDetails);
	}
	
	public void storeCommentsDetails() throws Throwable
	{
		ProxyValues.clear();
		CommentDetails.clear();
		waitForJavaScript("return document.querySelector(\"tr\")");
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"tr\")");
		for(int j = 1; j < myElements.size(); j++) 
		{
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('td')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('td').textContent");
			ProxyValues.put("Comment Type", myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelectorAll('td')[1]"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelectorAll('td')[1].textContent");
			ProxyValues.put("Comment Description", myValue);
			CommentDetails.put("Comment"+j, addValuesString(ProxyDetails, "Comment"+j, ProxyValues));
			ProxyValues.clear();
		}
		System.out.println(CommentDetails);
	}
	
	public void checkInputEditsOnEnterDetailsPage(String entity,List<List<String>> attribute) throws Throwable
	{
		System.out.println(Arrays.asList(InputValues));
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
					myValue = InputValues.get(attribute.get(i).get(0));
					action.scrollToElement(findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']"));
					myValue1 = findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']").getAttribute("value");
					System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
					Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
					sftAst.assertEquals(myValue1, myValue);
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public void checkDropdownEditsOnEnterDetailsPage(String entity,List<List<String>> attribute) throws Throwable
	{
		System.out.println(Arrays.asList(InputValues));
    	
    	for (int i = 0; i < attribute.size(); i++)
		{
				myValue = InputValues.get(attribute.get(i).get(0));
				action.scrollToElement(findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']"));
				myValue1 = (String)executeJavaScript("return document.querySelector(\"#"+attribute.get(i).get(1)+"\").getAttribute('value')");
				if(attribute.get(i).get(0).contentEquals("Manager Name") || attribute.get(i).get(0).contentEquals("Investment Style"))
				{
					myElements = findElementsByDynamicXpath("//brml-select-option[@value='"+myValue1+"']");
					for(WebElement E: myElements) 
					{
						myValue1 = E.getAttribute("name");
						if(myValue == myValue1) 
							break;
					}
				}
				System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
				Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
				sftAst.assertEquals(myValue1, myValue);
		}   	
	}
	
	public void checkCheckBoxEditsOnUpdatePage(String entity,List<List<String>> attribute) throws Throwable
	{
		System.out.println(Arrays.asList(InputValues));
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
					myValue = InputValues.get(attribute.get(i).get(0));
					if(myValue.equalsIgnoreCase("Yes")) 
						myValue = "true";
					else if (myValue.equalsIgnoreCase("No")) 
						myValue = "false";

					myValue1 = (String)executeJavaScriptWithoutWait("return document.querySelector(\"#"+attribute.get(i).get(1)+"\").getAttribute('checked')");
					System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
					Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
					sftAst.assertEquals(myValue1, myValue);
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public void checkBenchmarkEditsOnUpdateFlow(String entity,List<Map<String,String>> attribute) throws Throwable
	{
		System.out.println(BenchmarkDetails);
		
		if(BenchmarkDetails.containsKey("Style")) 
			checkNonCBEditsOnUpdatePage(entity,BenchmarkDetails.get("Style"));
		
		for(int i = 0; i < attribute.size(); i++)
		{
			int j = 0;
			if(!BenchmarkDetails.containsKey(attribute.get(i).get("Dropdown Name"))) 
			{
				continue;
			}

			HashMap<String, Double> data = BenchmarkDetails.get(attribute.get(i).get("Dropdown Name"));
			
			for(Map.Entry<String, Double> list: data.entrySet()) 
			{
				myElement = findElementByDynamicXpath("//brml-select[@id='" + attribute.get(i).get("Dropdown ID") + j + "']");
				action.moveToElement(myElement);
				myValue = myElement.getAttribute("value");
				myElement = findElementByDynamicXpath("(//brml-select-option[@value='" + myValue + "'])[1]");
				myValue = myElement.getAttribute("name");
				//myValue = myValue.replaceAll("^.+?-\\s|-\\d{4}$", "");
				myValue = myValue.replaceAll("^.+?-\\s", "");
				myValue1 = list.getKey();
				System.out.println(attribute.get(i).get("Dropdown ID") + j + " : " + myValue + " " + myValue1);
				sftAst.assertEquals(myValue, myValue1);
				myElement = findElementByDynamicXpath("//brml-stepper-input[@id='" + attribute.get(i).get("Percentage ID") + j + "']");
				action.moveToElement(myElement);
				myValue = myElement.getAttribute("value");
				System.out.println(attribute.get(i).get("Percentage ID")+j+" : "+format.format(Double.parseDouble(myValue))+" "+format.format(list.getValue()));
				sftAst.assertEquals(format.format(Double.parseDouble(myValue)), format.format(list.getValue()));
				Thread.sleep(200);
				j++;
			}
		}
		//sftAst.assertAll();
	}
	
	public void checkNonCBEditsOnUpdatePage(String entity,HashMap<String,Double> Map) throws Throwable
	{
		System.out.println(Arrays.asList(Map));
		
		myValue = (String)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1\").getAttribute('value')");
		System.out.println("Seleted Benchmark type is "+myValue);
		Reporter.addStepLog("Seleted Benchmark type is "+myValue);
		sftAst.assertTrue(myValue.contains("style"));
				
		int i=1;
		for (Map.Entry<String, Double> list : Map.entrySet())
		{
			myElement = findElementByDynamicXpath("//brml-button[@variant='link' and @class='viewDetailsCta']");
			action.jsClick(myElement);
			//myElement.click();
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[0].textContent");
			myValue1 = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[1].textContent");
			myValue1 = myValue + "-" + myValue1;
			System.out.println("Stored Benchmark: " + list.getKey() + "-" + format.format(list.getValue())+ "% Displayed Benchmark: " + myValue1);
			sftAst.assertEquals(myValue1, list.getKey() + "-" + format.format(list.getValue()) + "%");
			Reporter.addStepLog("Stored Benchmark: " + list.getKey() + "-" + format.format(list.getValue())+ "% Displayed Benchmark: " + myValue1);
			i++;
			Thread.sleep(300);
		}
		
		myElement = findElementByDynamicXpath("//brml-modal[@id='nonDetachedModal']//following::brml-button[@variant='secondary']");
		Thread.sleep(1000);
		myElement.click();
	}
	
	public void checkProxyEditsOnUpdatePage(List<List<String>> attribute) throws Throwable
	{
		for (int j = 0; j < proxyDetails.length; j++)
		{	
			HashMap<String, String> data = ProxyDetails.get(proxyDetails[j]);
			System.out.println(data);
	    	for (int i = 0; i < attribute.size(); i++)
				{				
					myElement = findElementByDynamicXpath("(//*[@id='"+attribute.get(i).get(1)+"'])["+(j+1)+"]");
					myValue = myElement.getAttribute("value");			

					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+data.get(attribute.get(i).get(0)));
					Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+data.get(attribute.get(i).get(0)));
					sftAst.assertEquals(myValue,data.get(attribute.get(i).get(0)));
					Thread.sleep(200);
				}
		}
	}
	
	public void checkDocumentEditsOnUpdatePage() throws Throwable
	{
		waitForJavaScript("return document.querySelector(\"tr\")");
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"tr\")");
		int i;
		for(int j = 1; j < myElements.size(); j++) 
		{
			HashMap<String, String> list = DocumentDetails.get("Document"+j);				

			i=1;
			while(true && i<=myElements.size()) 
			{
				myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('brml-button').textContent");

				if(list.get("Document Link").contentEquals(myValue))		
					break;
				
				i++;
			}
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('td')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('td').textContent");
			System.out.println("Stored value :"+list.get("Document Type")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Document Type")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Document Type"), myValue);

			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('brml-button')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('brml-button').textContent");
			System.out.println("Stored value :"+list.get("Document Link")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Document Link")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Document Link"), myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('brml-button')[1]"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('brml-button')[1].textContent");
			System.out.println("Stored value :"+list.get("Document Description")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Document Description")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Document Description"), myValue);
		}
			
	}
	
	public void checkCommentsEditsOnUpdatePage() throws Throwable
	{
		waitForJavaScript("return document.querySelector(\"tr\")");
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"tr\")");
		int i;
		for(int j = 1; j < myElements.size(); j++) 
		{
			HashMap<String, String> list = CommentDetails.get("Comment"+j);				
			i=1;
			while(true && i<=CommentDetails.size()) 
			{
				myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('td')[1].textContent");

				if(list.get("Comment Description").contentEquals(myValue))		
					break;
				
				i++;
			}

			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('td')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('td').textContent");
			System.out.println("Stored value :"+list.get("Comment Type")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Comment Type")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Comment Type"), myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('td')[1]"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('td')[1].textContent");
			System.out.println("Stored value :"+list.get("Comment Description")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Comment Description")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Comment Description"), myValue);
		}	
		//sftAst.assertAll();
	}
	
	public void clickTabs(String tabName) throws Throwable
	{
			Thread.sleep(5000);
			action.waitForPageLoad();
			myElement = findElementByDynamicXpath("//brml-tab-button[@tab='"+tabName+"']");
			Thread.sleep(2000);
			myElement.click();
			Reporter.addStepLog(tabName+" tab is cicked");
			action.waitForPageLoad();
			Thread.sleep(5000);
	}
	
	public void selectedBMtype(String type) throws Throwable 
	{
		InputValues.put("SelectedBMType", type);
	}
	
	public void selectBenchmarkType(String BMtype) throws Throwable
	{
		action.waitForPageLoad();
		switch(BMtype) 
		{
			case "Style":
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(1)\")");
				InputValues.put("Custom BM Reason", "—");
				//selectedBMtype("417");
				break;
			case "Custom":
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(2)\")");
				//selectedBMtype("418");
				break;
			default:
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(1)\")");
				InputValues.put("Custom BM Reason", "—");
				//selectedBMtype("417");
				break;			
		}
		myElement.click();
		myElement = findElementByDynamicXpath("//brml-button[@variant='link' and @class='viewDetailsCta']");
		myElement.click();
		
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")");  
		
		for(int i = 1; i < myElements.size(); i++) 
		{
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[0].textContent");
			myValue1 = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[1].textContent");
			myValue1 = myValue1.replaceAll("%","");
			double percentage = Double.parseDouble(myValue1);
			BenchmarkValues.put(myValue, percentage);
		}
		
		BenchmarkDetails.put(BMtype, addValues1(BenchmarkDetails, BMtype, BenchmarkValues));

		//myElement = (WebElement)executeJavaScript("return document.querySelector(\"#nonDetachedModal\").querySelector(\"brml-button[variant='primary']\")");
		//myElement = (WebElement)executeJavaScript("return document.querySelector(\"#nonDetachedModal > footer > div > div.col-2 > brml-button\").shadowRoot.querySelector(\"button > span\")");
		//myElement = findElementByDynamicXpath("//brml-modal[@id='nonDetachedModal']//following::brml-button[@variant='primary']//following::span[contains(text(),'CLOSE')]");
		myElement = findElementByDynamicXpath("//brml-modal[@id='nonDetachedModal']//following::brml-button[@variant='secondary']");
		Thread.sleep(1000);
		myElement.click();
		System.out.println(BenchmarkDetails);
	}
	
	public void viewEdit(String entity,String searchCode,String columnName,String option) throws Throwable
	{
		try
    	{
			action.waitForPageLoad();

			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchCode);
			searchCode = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			
			  myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='"+columnName+"']\")");  
			   for (int i = 1; i < myElements.size(); i++)
			   {
				   System.out.println(myElements.get(i).getText());
					if(myElements.get(i).getText().equalsIgnoreCase(searchCode)) 
					{
					   	myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[col-id='"+columnName+"']\")["+i+"]");
						action.scrollToElement(myElement);
					   	myElement.click();
					   	myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[col-id='"+columnName+"']\")["+i+"].parentElement.querySelector(\"brml-action-menu\")");
						action.highligthElement(myElement);
						Thread.sleep(2000);
						myElement.click();
						Reporter.addStepLog("clicking on ellipsis icon");
					   
						myElements =getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='"+columnName+"']\")["+i+"].parentElement.querySelector(\"brml-action-menu\").shadowRoot.querySelectorAll(\"button > span\")");
						if(option.equalsIgnoreCase("ViewEdit"))
						{
							action.highligthElement(myElements.get(0));
							Thread.sleep(2000);
							myElements.get(0).click();
							
							Reporter.addStepLog("Cicking on the View/Edit option");
						}
						
						else if(option.equalsIgnoreCase("Delete"))
						{
							action.scrollToElement(myElements.get(1));
							action.highligthElement(myElements.get(1));
							Thread.sleep(2000);
							myElements.get(1).click();
							
							Reporter.addStepLog("Cicking on the View/Edit option");
						}
						Thread.sleep(5000);
						break;
					}
			   }
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access the View/Edit option");
    	}
	}
	
	public void DBRetriveSC(String searchfeild, String entity) throws Throwable
	{
	  try 
	  {
		Thread.sleep(3000);
		pmdb.DBConnectionStart();
		Reporter.addStepLog("Connected to DB");
		//System.out.println(draftName);
				
		switch(entity) 
		{
			case "MutualFund":
				 // completeSqlQuery = "select * from mutual_funds where fund_status ='80' group by mf_id having count(cusip)=1 limit 1";
				  completeSqlQuery = "select "+searchfeild+" from mutual_funds where fund_status ='80' and mf_id in (select reference_id from program_eligibility ) and created_by ='MFRS_CONV' group by "+searchfeild+" having count("+searchfeild+")=1 limit 1";
				  break;
				  
			case "ETF":
				  completeSqlQuery = "select "+searchfeild+" from etf where style_id is not null and created_by not like '%BIMS%' group by "+searchfeild+" having count("+searchfeild+")=1 limit 1";
				  break;	
				  
			default:
				  break;
		} 
		
		//String	 completeSqlQuery = "select * from draft_entity where draft_name = 'SaveAsDraft_Rgow17-01-2022(13:51)'";

		Reporter.addStepLog("Executing the SQL Query "+completeSqlQuery);
		ResultSet allResult = DBManager.executeSelectQuery(completeSqlQuery);
		
		String searchCode = null;
		
		while (allResult.next()) 
		{
			searchCode = allResult.getString(searchfeild);
			System.out.println(searchCode);
			writeIntoExcel(entity, "SearchCodeDB", searchCode);
		
			
		}
			
		switch(entity) 
		{
			case "MutualFund":
				  completeSqlQuery = "select * from mutual_funds where "+searchfeild+"='"+searchCode+"' and fund_status ='80' limit 1 ";
				break;
				  
			case "ETF":
				  completeSqlQuery = "select * from etf where "+searchfeild+"='"+searchCode+"' limit 1 ";
				  break;	
				  
			default:
				  break;
		} 
		
		Reporter.addStepLog("Executing the SQL Query "+completeSqlQuery);
		allResultMain = DBManager.executeSelectQueryForScrollableResultSet(completeSqlQuery);
		//pmdb.DBConnectionClose();
	  }

		catch (Exception e) 
		{
			Reporter.addStepLog("Unable to perform Database UI Check");
		}
	}
	
	public void checkPE_UIValues(String entity, String searchfeild,List<List<String>> attribute) throws Throwable
	{
	   try 
	   {
		//pmdb.DBConnectionStart();
		//System.out.println(draftName);
		/*System.out.println(searchcode);
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchcode);
		searchcode = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
		
		switch(entity) 
		{
			case "MutualFund":
				  completeSqlQuery = "select * from mutual_funds where "+searchfeild+"='"+searchcode+"' and fund_status ='80' limit 1 ";
				break;
				  
			case "ETF":
				  completeSqlQuery = "select * from etf where "+searchfeild+"="+searchcode+" and fund_status ='80' limit 1 ";
				  break;	
				  
			default:
				  break;
		} 
		
		System.out.println(completeSqlQuery);
		allResultMain = DBManager.executeSelectQuery(completeSqlQuery);
		
		System.out.println(allResultMain.getFetchSize());
		/*while (allResultMain.next()) 
		{
			for (int i = 0; i < attribute.size(); i++)
			{
				//attribute.get(i).get(1).replaceAll("\\s","")
				
				//waitForJavaScript("return document.querySelector('#\"+attribute.get(i).get(1).replaceAll(\"\\\\s\",\"\")+\"').shadowRoot.querySelector('input')");
				System.out.println("return document.querySelector('#"+attribute.get(i).get(1).replaceAll("\\s","")+"').getAttribute('value')");
				myValue = (String)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1).replaceAll("\\s","")+"').getAttribute('value')");
				
				
				myValue1 = allResultMain.getString(attribute.get(i).get(1). replaceAll("\\s","_"));

				System.out.println("My Value :"+myValue+" Database value :"+myValue1);
				sftAst.assertEquals(myValue, myValue1);
				Thread.sleep(1000);
			}
		}*/
		
		String programEligibility[][]= {{"trading_eligible","tradingEligible"},{"holding_eligible","holdingEligible"},{"retirement_eligible","retirementEligible"},{"non_retirement_eligible","nonRetirementEligible"}};

		while(allResultMain.first()) 
		{
			searchfeild = allResultMain.getString(searchfeild);
			completeSqlQuery = "select * from program_eligibility where reference_id ='" + searchfeild + "'";
			Reporter.addStepLog("Executing the SQL Query "+completeSqlQuery);
			ResultSet allResult = DBManager.executeSelectQueryForScrollableResultSet(completeSqlQuery);
			
			for(int i = 0; i < attribute.size(); i++)
			{
				allResult.beforeFirst();				
				System.out.println("\n"+attribute.get(i).get(0));
				Reporter.addStepLog("Checking for the attribute "+attribute.get(i).get(0));
				
				while(allResult.next()) 
				{
					if(allResult.getString("program_id").equals(attribute.get(i).get(1))) 
					{
						/*myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-accordion:nth-child("
								+ (i+1)
								+ ") > brml-expansion-panel\").shadowRoot.querySelector(\"div.expansion-panel-header\")");*/
						
						myElement = findElementByDynamicXpath("//span[contains(text(),'"+attribute.get(i).get(0)+"')]");		

						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						myElement.click();
						Thread.sleep(500);
						
						for(int j = 0; j < programEligibility.length; j++) 
						{
							myValue1 = allResult.getString(programEligibility[j][0]);
							
							action.scrollToElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
									+ attribute.get(i).get(1) + "-"+programEligibility[j][1]+"']\")"));
							action.highligthElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
									+ attribute.get(i).get(1) + "-"+programEligibility[j][1]+"']\")"));
						
							myValue = (String)executeJavaScript("return document.querySelector(\"brml-radio[id='"
									+ attribute.get(i).get(1) + "-"+programEligibility[j][1]+"']\").getAttribute('value')");
							
							System.out.println(programEligibility[j][1]+ " \nUI Value :" + myValue.charAt(0) + " Database value :" + myValue1);
							sftAst.assertEquals(myValue.charAt(0), myValue1);
							Reporter.addStepLog(programEligibility[j][1]+ " \nUI Value :" + myValue.charAt(0) + " Database value :" + myValue1);
							Thread.sleep(1000);
							
							
						}
						
						/*myValue1 = allResult.getString("trading_eligible");
						
						action.scrollToElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-tradingEligible']\")"));
						action.highligthElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-tradingEligible']\")"));

						myValue = (String)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-tradingEligible']\").getAttribute('value')");
						
						
						System.out.println("TradingEligible \nUI Value :" + myValue.charAt(0) + " Database value :" + myValue1);
						sftAst.assertEquals(myValue.charAt(0), myValue1);
						Reporter.addStepLog("TradingEligible \nUI Value :" + myValue.charAt(0) + " Database value :" + myValue1);
						Thread.sleep(1000);
						
						myValue1 = allResult.getString("holding_eligible");
						
						action.scrollToElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-holdingEligible']\")"));
						action.highligthElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-holdingEligible']\")"));
						
						myValue = (String)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-holdingEligible']\").getAttribute('value')");
						
						System.out.println("HoldingEligible \nUI Value :" + myValue.charAt(0) + " Database value :" + myValue1);
						sftAst.assertEquals(myValue.charAt(0), myValue1);
						Reporter.addStepLog("HoldingEligible \nUI Value :" + myValue.charAt(0) + " Database value :" + myValue1);
						Thread.sleep(1000);*/
						
				 		compareBoolean = action.isPresent("xpath", "//span[contains(text(),'"+attribute.get(i).get(0)+"')]//parent::brml-expansion-panel//*[@id=\"programStatus\"]/brml-select-option[@selected='true']");
				 		if(compareBoolean)
						{
				 			myElement = findElementByDynamicXpath("//span[contains(text(),'"+attribute.get(i).get(0)+"')]//parent::brml-expansion-panel//*[@id=\"programStatus\"]/brml-select-option[@selected='true']");
							action.scrollToElement(findElementByDynamicXpath("//span[contains(text(),'"+attribute.get(i).get(0)+"')]//parent::brml-expansion-panel//*[@id=\"programStatus\"]"));
							action.highligthElement(findElementByDynamicXpath("//span[contains(text(),'"+attribute.get(i).get(0)+"')]//parent::brml-expansion-panel//*[@id=\"programStatus\"]"));
				 			myValue = myElement.getAttribute("value");
							myValue1 = allResult.getString("status");

							switch(myValue1) 
							{
								case "863":
									myValue1 = "Eligible";
									break;
									
								case "864":
									myValue1 = "Grandfathered";
									break;
									
								case "865":
									myValue1 = "Hold";
									break;
									
								case "866":
									myValue1 = "Ineligible";
									break;
									
								default:
									break;
							}
							
							System.out.println("Program Status \nUI Value :" + myValue + " Database value :" + myValue1);
							sftAst.assertEquals(myValue, myValue1);
							Reporter.addStepLog("Program Status \nUI Value :" + myValue + " Database value :" + myValue1);
							Thread.sleep(1000);
						}
						
						break;
					}
				}
			}
			break;
		}
	}
		catch (Exception e)
		{
			Reporter.addStepLog("Unable to perform Database UI Check");
		}	
	}
	
	public void editPE_UIValues(List<List<String>> attribute) throws Throwable
	{
		try 
		{
			for(int i = 0; i < attribute.size(); i++)
			{
				/*myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-accordion:nth-child("
						+ (i + 1)
						+ ") > brml-expansion-panel\").shadowRoot.querySelector(\"div.expansion-panel-header\")");*/
				
				myElement = findElementByDynamicXpath("//span[contains(text(),'"+attribute.get(i).get(0)+"')]");		
				
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				myElement.click();
				Thread.sleep(500);
				
				myValue = (String)executeJavaScript("return document.querySelector(\"brml-radio[id='"
						+ attribute.get(i).get(1) + "-retirementEligible']\").getAttribute('disabled')");
				
				if(myValue.equalsIgnoreCase("false")) 
				{
					action.scrollToElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
							+ attribute.get(i).get(1) + "-retirementEligible']\")"));
					action.highligthElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
							+ attribute.get(i).get(1) + "-retirementEligible']\")"));
					
					myValue = (String)executeJavaScript("return document.querySelector(\"brml-radio[id='"
							+ attribute.get(i).get(1) + "-retirementEligible']\").getAttribute('value')");
					
					if(myValue.equalsIgnoreCase("true")) 
					{
						myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-retirementEligible'] > brml-radio-option[label='No']\")");
						Thread.sleep(1000);
						myElement.click();
						
						addValues(NewInputValues,(attribute.get(i).get(0)),"No");
						Thread.sleep(1000);
					}
					else 
					{
						myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-retirementEligible'] > brml-radio-option[label='Yes']\")");
						Thread.sleep(1000);
						myElement.click();
						
						addValues(NewInputValues,(attribute.get(i).get(0)),"Yes");
						Thread.sleep(1000);					
					}
				}
				
				myValue = (String)executeJavaScript("return document.querySelector(\"brml-radio[id='"
						+ attribute.get(i).get(1) + "-nonRetirementEligible']\").getAttribute('disabled')");
				
				if(myValue.equalsIgnoreCase("false")) 
				{
					action.scrollToElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
							+ attribute.get(i).get(1) + "-nonRetirementEligible']\")"));
					action.highligthElement((WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
							+ attribute.get(i).get(1) + "-nonRetirementEligible']\")"));
					
					myValue = (String)executeJavaScript("return document.querySelector(\"brml-radio[id='"
							+ attribute.get(i).get(1) + "-nonRetirementEligible']\").getAttribute('value')");
					
					if(myValue.equalsIgnoreCase("true")) 
					{
						myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-nonRetirementEligible'] > brml-radio-option[label='No']\")");
						Thread.sleep(1000);
						myElement.click();
						
						addValues(NewInputValues,(attribute.get(i).get(0)),"No");
						Thread.sleep(1000);
					}
					else 
					{
						myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-radio[id='"
								+ attribute.get(i).get(1) + "-nonRetirementEligible'] > brml-radio-option[label='Yes']\")");
						Thread.sleep(1000);
						myElement.click();
						
						addValues(NewInputValues,(attribute.get(i).get(0)),"Yes");
						Thread.sleep(1000);					
					}
				}
	
			}
			
			System.out.println(Arrays.asList(NewInputValues));
		}
			catch (Exception e)
			{
				Reporter.addStepLog("Unable to perform Database UI Check");
			}	
		
	}//label[contains(text(),'Client Discretion UMA')]//parent::b//parent::div//following-sibling::div//label[contains(text(),'Retirement Account Eligible')]//following-sibling::div
	
	public void addValues(HashMap<String ,ArrayList<String>> haspMap, String key,String value) 
	{
		ArrayList tempList = null;
		if(haspMap.containsKey(key)) 
		{
			tempList = haspMap.get(key);
			if(tempList == null) 
				tempList = new ArrayList();
			tempList.add(value);
		}
		else 
		{
			tempList = new ArrayList();
			tempList.add(value);
		}
		haspMap.put(key,tempList);
	}
	
	public HashMap<String, Double> addValues1(HashMap<String ,HashMap<String,Double>> haspMap, String key,HashMap<String,Double> value) throws Throwable 
	{
		HashMap<String, Double> tempList = null;

		if(haspMap.containsKey(key)) 
		{
			tempList = haspMap.get(key);
			if(tempList == null) 
				tempList = new HashMap<String, Double>();
//			tempList.putAll(valueCopy);
			tempList.putAll(value);

		}
		else 
		{
			tempList = new HashMap<String, Double>();
//			tempList.putAll(valueCopy);
			tempList.putAll(value);
			
		}
		//haspMap.put(key,tempList);
		tempList = (HashMap<String, Double>)sortTheCollectionInt(tempList, false);

		return tempList;
		
	}
	
	public void checkPEUpdateValues() throws Throwable
	{
		for (Entry<String, ArrayList<String>> data : NewInputValues.entrySet())
		{
			myElement = findElementByDynamicXpath("//span[contains(text(),'"+data.getKey()+"')]");		
			
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			myElement.click();
			Thread.sleep(500);
			
			if (!data.getValue().isEmpty())
			{
				myValue = data.getValue().get(0);
				myValue1 = data.getValue().get(1);
				myElement = findElementByDynamicXpath("//span[contains(text(),'"+data.getKey()+"')]//parent::brml-expansion-panel//brml-radio[@label='Retirement Account Eligible']");
				myElement1 = findElementByDynamicXpath("//span[contains(text(),'"+data.getKey()+"')]//parent::brml-expansion-panel//brml-radio[@label='Non-retirement Account Eligible']");
				
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				action.highligthElement(myElement1);
				
				sftAst.assertEquals(myElement.getAttribute("checked"), myValue);
				sftAst.assertEquals(myElement.getAttribute("checked"), myValue1);

				System.out.println("Retirement Account Eligible \nUpdated value "+myValue+" displayed value "+myElement.getAttribute("checked"));
				System.out.println("Non-retirement Account Eligible \nUpdated value "+myValue1+" displayed value "+myElement1.getAttribute("checked"));

				Reporter.addStepLog("Retirement Account Eligible \nUpdated value "+myValue+" displayed value "+myElement.getAttribute("checked"));
				Reporter.addStepLog("Non-retirement Account Eligible \nUpdated value "+myValue1+" displayed value "+myElement1.getAttribute("checked"));

				Thread.sleep(500);
			}	
		}
	}
	
	public void checkInputUIValues(List<List<String>> attribute) throws Throwable
	{		
		try 
		{
			
		while(allResultMain.first()) 
		{
			for (int i = 0; i < attribute.size(); i++)
			 {
				//attribute.get(i).get(1).replaceAll("\\s","")
				
				//waitForJavaScript("return document.querySelector('#\"+attribute.get(i).get(1).replaceAll(\"\\\\s\",\"\")+\"').shadowRoot.querySelector('input')");
				System.out.println(attribute.get(i).get(0));
				Reporter.addStepLog("Checking for the attribute "+attribute.get(i).get(0));
				
				if(attribute.get(i).get(0).equals("Bundled Node ID")) 
				{
					action.scrollToElement((WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"')"));
					action.highligthElement((WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"')"));
					
					myValue = (String)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"').getAttribute('value')");				
					
					if(myValue.isEmpty()) 
					{
						action.refresh();
						action.waitForPageLoad();
						Thread.sleep(2000);
						myValue = (String)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"').getAttribute('value')");					
					}
					myValue1 = allResultMain.getString("style_node_id");

					System.out.println("UI Value :"+myValue+" Database value :"+myValue1);
					sftAst.assertEquals(myValue, myValue1);
					Thread.sleep(1000);

				}
				
				else 
				{
					action.highligthElement((WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1).replaceAll("\\s","")+"')"));
					action.highligthElement((WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1).replaceAll("\\s","")+"')"));
					
					myValue = (String)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1).replaceAll("\\s","")+"').getAttribute('value')");

					myValue1 = allResultMain.getString(attribute.get(i).get(1).replaceAll("\\s","_"));

					System.out.println("UI Value :"+myValue+" Database value :"+myValue1);
					sftAst.assertEquals(myValue, myValue1);
					Thread.sleep(1000);
					
				    InputValues.put(attribute.get(i).get(0),myValue1);
				}
			 }
			
			Reporter.addScreenCapture();
			break;
		}
	}
	
	catch(Exception e)
		{
			Reporter.addStepLog("Unable to perform Database UI Check");
		}
	}
	
	public HashMap<String, String> addValuesString(HashMap<String ,HashMap<String,String>> haspMap, String key,HashMap<String,String> value) throws Throwable 
	{
		HashMap<String, String> tempList = null;

		if(haspMap.containsKey(key)) 
		{
			tempList = haspMap.get(key);
			if(tempList == null) 
				tempList = new HashMap<String, String>();
//			tempList.putAll(valueCopy);
			tempList.putAll(value);

		}
		else 
		{
			tempList = new HashMap<String, String>();
//			tempList.putAll(valueCopy);
			tempList.putAll(value);
			
		}
		//haspMap.put(key,tempList);

		return tempList;
		
	}
	
	public void openNotificationHub() throws Throwable
	  {
    	
		FileManager.getFileManagerObj().deleteFile(NHLogFilePath);
		String command = "";
		
		switch(UIEnvironment) 
		{
			case "DEV":
				command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC";
				break;
			case "QA":
				command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.QA.OUT.WMAP.TOPIC";
				break;
			case "UAT":
				command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.UAT.OUT.WMAP.TOPIC";
				break;
			default:
				break;
		}
		
		action.waitForPageLoad();
		myValue = action.getCurrentURL();
		System.out.println(myValue);
		Pattern  pat = Pattern.compile("\\/(\\d{1,10})$");
		Matcher mat = pat.matcher(myValue);
		
		mat.find();
		myValue = mat.group(1);
		//Redirecting to a pipe and applying a filter with identifier as filter value
//		command = command+" | find /i \"\"\"systemId\"\":\"\"ProductMaster\"\"\" >> "+testmucNHLogFilePath;
//		command = command+" >> "+NHLogFilePath;

		command = command+" | find /i \"Id: "+myValue+"\" >> "+NHLogFilePath;
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command);
		System.out.println("<b>Kafka Command: </b>"+command);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/c", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();

		//Runtime rt = Runtime.getRuntime();
		//pb.exec(new String[] {"cmd", "/K", command},null,new File(kafkaPath));
		//r = Runtime.getRuntime();
		//p = r.exec(new String[] {"cmd", "/c", command},null,new File(kafkaPath));
//		String[] command1 = { "cmd /c title rgowtham && "+command+"" };
//		rt.exec(command1,null,new File(kafkaPath));
//		p = Runtime.getRuntime().exec(new String[] {"cmd", "/c", command},null,new File(kafkaPath));
//		Thread.sleep(15000);
		//p = Runtime.getRuntime().exec(command);

		//Thread.sleep(10000);
    }

	/*public void getPID(String title) throws Throwable
	  {
		Process p = Runtime.getRuntime().exec("tasklist /v /fo csv | findstr /i \""+title+"\"");
		p.waitFor();
		Thread.sleep(3000);
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		while ((line = reader.readLine()) != null)
		{

			System.out.println(line);
		
			Pattern  pat = Pattern.compile("^,\"(\\d+?)\",");
			Matcher mat = pat.matcher(line);
			
			mat.find();
			myValue = mat.group(1);
			
			System.out.println("PID "+myValue);
			
			Runtime.getRuntime().exec("taskkill /F /IM " + myValue);
		}
	
	  }*/

	
	@And("^Check if a notification is sent to Notification Hub$")
    public void checkNotificationHub(String entity) throws Throwable
	{
		try 
		{
			Thread.sleep(10000);
			FileReader fr = new FileReader(NHLogFilePath);
			BufferedReader br = new BufferedReader(fr);
			//p.destroyForcibly();
			//r.exec("taskkill /f /im cmd.exe");
			//Runtime.getRuntime().exec("cmd /c ext\\SendSignalC.exe");
			//SystemProcess.killProcess("\"WINDOWTITLE eq rgowtham\" /T");
			//getPID("rgowtham");

			StringBuilder sBuilder = new StringBuilder();
			String line = br.readLine();

			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Message");
			String message = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			
			while(line != null) 
			{
				sBuilder.append(line);
				sBuilder.append(System.lineSeparator());
				line = br.readLine();
			}

			String eveString = sBuilder.toString();
			System.out.println(eveString);	
			
			Reporter.addStepLog("<b>Notification from NH: </b> "+eveString);
			
			sftAst.assertTrue(eveString.contains(Code));
			
			if(eveString.contains(Code))
			{
				System.out.println("Contains Code");
			}
			Reporter.addStepLog("<b>Strategy Code: </b> "+Code);
			
			if(eveString.contains(message))
			{
				System.out.println("Contains Message");
			}
			
		    sftAst.assertTrue(eveString.contains(message));
			Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message+"</b>");

			if(eveString.contains("\"event\":\"UPDATE\""))
			{
				System.out.println("Contains Message1");
			}
			
			sftAst.assertTrue(eveString.contains("\"event\":\"UPDATE\""));
			Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'> \"event\":\"UPDATE\" </b>");

			br.close();
			fr.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
    		Assert.fail("Unable to access the Notification Hub");
		}
		finally 
		{
			p.destroyForcibly();
			
		}
	}
	
    public void openDataHub(String entity) throws Throwable
    {
    	
		FileManager.getFileManagerObj().deleteFile(DHLogFilePath);
		String command = "";
		
		switch(UIEnvironment) 
		{
			case "DEV":
				command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC";
				break;
			case "QA":
				command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.QA.OUT.WMAP.TOPIC";
				break;
			case "UAT":
				command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.UAT.OUT.WMAP.TOPIC";
				break;
			default:
				break;
		}
		
		myValue = action.getCurrentURL();
		System.out.println(myValue);
		Pattern  pat = Pattern.compile("\\/(\\d{1,10})$");
		Matcher mat = pat.matcher(myValue);
		
		mat.find();
		myValue = mat.group(1);
		//Redirecting to a pipe and applying a filter with identifier as filter value
//		command = command+" | find /i \"\"\"systemId\"\":\"\"ProductMaster\"\"\" >> "+testmucNHLogFilePath;
//		command = command+" >> "+DHLogFilePath;

		if(entity.equals("FATeam")) 
		{
			command = command+" | find /i \"\"\"faTeamId\"\":"+myValue+"\" >> "+DHLogFilePath;
		}
		else
		{
			command = command+" | find /i \"\"\"identifier\"\":"+myValue+"\" >> "+DHLogFilePath;
		}
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command);
		System.out.println("<b>Kafka Command: </b>"+command);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/c", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();
    }


    public void checkDataHubPay() throws Throwable
	{
		try 
		{
			Thread.sleep(10000);
			
			FileReader fr = new FileReader(DHLogFilePath);
			BufferedReader br = new BufferedReader(fr);
			
			StringBuilder sBuilder = new StringBuilder();
			String line = br.readLine();			
			
			while(line!=null ) 
			{
				sBuilder.append(line);
				sBuilder.append(System.lineSeparator());
				line = br.readLine();
//				System.out.println("qwertyu "+strategyCode);
//				if(line.contains(strategyCode)) 
//				{
//					Action.pause(1000);
//					p.destroy();
//					System.out.println("Successful!!!!!!!");
//					break;
//				}
			}
			String eveString = sBuilder.toString();
			
			System.out.println("qwertyu DH"+eveString);
			
			Reporter.addStepLog("<b>Payload from DH: </b>"+eveString);
			Reporter.addStepLog("<b>Search Code: </b>"+Code);
			
			if(eveString.contains(Code))
			{
				System.out.println("Contains Messag12e");
			}
			sftAst.assertTrue(eveString.contains(Code));
		    Reporter.addStepLog("<p style = 'color:green'>Strategy Code is Matched in Payload</p>");		
		    if(eveString.contains("\"event\":\"UPDATE\""))
			{
				System.out.println("Contains Messag12e234");
			}
			sftAst.assertTrue(eveString.contains("\"event\":\"UPDATE\""));
			Reporter.addStepLog("Message from Data Hub: <b style = 'color:green'> \"event\":\"UPDATE\" </b>");

			br.close();
			fr.close();
		}
		catch(Exception e)
		{
    		Assert.fail("Unable to access the Data Hub");
		}
		finally 
		{
			p.destroy();
		}
	}
	
    public void DBRetriveSearchCode(String entity) throws Throwable
	{
	  try 
		{
			Thread.sleep(3000);
			pmdb.DBConnectionStart();
			Reporter.addStepLog("Connected to DB");
			
			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_" + UIEnvironment);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "SearchCodeQuery");
			
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			
			String completeSqlQuery1 = myValue;
			System.out.println(completeSqlQuery1);
			ResultSet allResult = DBManager.executeSelectQuery(completeSqlQuery1);
			
			String searchCode = null;

			while (allResult.next()) 
			{
				searchCode = allResult.getString(1);
				writeIntoExcel(entity, "SearchCode1", searchCode);
			}			
		}

		catch (Exception e) 
		{
			Reporter.addStepLog("Unable to perform Database UI Check");
		}
	}

    public void searchAccessFOACode() throws Throwable
	{
		sheetName = "SMASingleSWPAAP";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(1000);
		
		try
		{
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_" + UIEnvironment);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "SearchCode1");
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			Code = myValue;
			myElement = (WebElement)executeJavaScript(
						"return document.querySelector('brml-input[id=\"searchForAccessFOACode\"]').shadowRoot.querySelector('input')");
				
				if(myElement.isEnabled()) 
				{
					action.scrollToElement(myElement);
					action.clear(myElement);
					Thread.sleep(1000);
					sendKeysWithCheck(myElement, myValue);
					int i = 0;
					
					while(i < 5) 
					{
						myElement.sendKeys(Keys.ENTER);
						i++;
					}
					//InputValues.put("FOA Code", myValue);
					//InputValuesId.put("searchForAccessFOACode", myValue);
					Reporter.addStepLog("send keys " + myValue + " for Search for Access FOA Code");
					Thread.sleep(1000);
				}
		}
		catch(Exception e) 
		{
			Assert.fail("Unable to access Search for Access FOA Code");
		}
	}
    
    public void DBRetriveSC1(String entity,String strArg1) throws Throwable
    {
  	  try 
  	  {
  		pmdb.DBConnectionStart();
  		Reporter.addStepLog("Connected to DB 1");
  		if(strArg1.contentEquals("SWP")) 
  		{
			DropDownValues.putAll(InputValues);
		}
  		System.out.println(DropDownValues);
  		sheetName = entity;
  		sheet = exlObj.getSheet(sheetName);
  		
  		for (Map.Entry<String, String> data : DropDownValues.entrySet())
  		{
  			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "SQL_Query");
  			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, data.getKey());
  			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
  			System.out.println(data.getKey());
  			if (!myValue.isEmpty())
  			{
  				//myValue = myValue+"'"+Code+"'";
  				myValue = myValue.replaceAll("@code", Code);

  				//System.out.println(myValue);
  				ResultSet allResult = DBManager.executeSelectQuery(myValue);
  				
  				Reporter.addStepLog("Executing the SQL Query "+myValue);
  				
  				String result = null;

  				while (allResult.next()) 
  				{
  					System.out.println("in here");
  					result = allResult.getString(1);
  					System.out.println(result);
  					if(result == null) 
					{
						System.out.println("DataBase Value :  Entered Value: "+data.getValue());
						Reporter.addStepLog("DataBase Value:  Entered Value: "+data.getValue());
						sftAst.assertEquals("",data.getValue(),data.getKey()+"DB");
					}	
  					else if(data.getValue().equalsIgnoreCase("Yes")) 
  					{
  						System.out.println("DataBase Value: "+result+" Entered Value: t");
  						Reporter.addStepLog("DataBase Value: "+result+" Entered Value: t");
  						sftAst.assertEquals(result, "t",data.getKey()+"DB");
  					}
  					else if(data.getValue().equalsIgnoreCase("No")) 
  					{
  						System.out.println("DataBase Value: "+result+" Entered Value: f");
  						Reporter.addStepLog("DataBase Value: "+result+" Entered Value: f");
  						sftAst.assertEquals(result, "f",data.getKey()+"DB");
  					}
  					else
					{
//							System.out.println("DataBase Value: " + result + " Entered Value: " + data.getValue());
//							Reporter.addStepLog("DataBase Value: " + result + " Entered Value: " + data.getValue());
//							
//							if(data.getKey().contentEquals("Manager Fee (TS)") || data.getKey().contentEquals("Withdrawal/Rebalance Minimum (RAW)")
//									|| data.getKey().contentEquals("Strategy Minimum (MEPS)") || data.getKey().contentEquals("Exception Minimum (RAW)")) 
//							{
//								sftAst.assertEquals(format.format(Double.parseDouble(result)), data.getValue(),data.getKey() + "DB");
//							}
//							else 
//							{
//								sftAst.assertEquals(result, data.getValue(), data.getKey() + "DB");
//							}
  						Pattern  pat = Pattern.compile("(\\d\\.\\d*[1-9])");
  						Matcher mat = pat.matcher(result);						
  						
  						if(mat.find()) 
							result =  mat.group(1);
  						
						result=result.replaceAll("\\.0{1,}$", "");

						System.out.println("DataBase Value: "+result+" Entered Value: "+data.getValue());
						Reporter.addStepLog("DataBase Value: "+result+" Entered Value: "+data.getValue());
						sftAst.assertEquals(result, data.getValue());					
					}
  				} 			
  			}		
  		}
  	  }
  	  catch(Exception e)
  	  {
			Reporter.addStepLog("Unable to perform Database UI Check");
  	  }
    }
    
    public void DBRetriveSC2(String entity) throws Throwable
    {
  	  try 
  	  {
  		pmdb.DBConnectionStart();
  		Reporter.addStepLog("Connected to DB");
  		sheetName = entity;
  		sheet = exlObj.getSheet(sheetName);
  		
  		for (Map.Entry<String, HashMap<String, Double>> data : BenchmarkDetails.entrySet())
  		{
  			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "SQL_Query");
  			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, data.getKey());
  			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
  			
  			if(!myValue.isEmpty())
			{
					System.out.println(data.getKey());
					HashMap<String, Double> list = data.getValue();
					myValue = myValue.replaceAll("@code", Code);
					//System.out.println(myValue);
					ResultSet allResult = DBManager.executeSelectQuery(myValue);
					Reporter.addStepLog("Executing the SQL Query " + myValue);
					
					String result = null;
					
					while(allResult.next())
					{
						result = allResult.getString(1);
						//System.out.println(result);
						//System.out.println("DataBase Value: "+result);
						//Reporter.addStepLog("DataBase Value: "+result+" Entered Value: "+data.getValue());
						sftAst.assertTrue(list.containsKey(result));
						
						if(data.getKey().contains("Custom")) 
						{
							cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Custom percentage");
						}
						else if(data.getKey().contains("UnBundled")) 
						{
							cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Unbundled percentage");
						}
						
						myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
						//System.out.println(data.getKey()+" "+myValue);
						myValue = myValue.replaceAll("@code", Code);
						myValue = myValue.replaceAll("@id", allResult.getString(2));
						//System.out.println(myValue);
						ResultSet allResult1 = DBManager.executeSelectQuery(myValue);
						Reporter.addStepLog("Executing the SQL Query " + myValue);
						
						while(allResult1.next()) 
						{
							result = allResult1.getString(1);
							
							System.out.println("DataBase Value: " + format.format(Double.parseDouble(result))
							+ " Entered Value: " + format.format(list.get(allResult.getString(1))));
							Reporter.addStepLog("DataBase Value: " + format.format(Double.parseDouble(result))
							+ " Entered Value: " + format.format(list.get(allResult.getString(1))));
							sftAst.assertEquals(format.format(Double.parseDouble(result)),format.format(list.get(allResult.getString(1))));
						}
					}
				} 				
  			}
  	  }
  	  catch (Exception e) 
  	  {
  		Reporter.addStepLog("Unable to perform Database UI Check");
  	  }
  	
    }
    
    public void DBProxyCheck() throws Throwable
    {
	    try 
	   	{
	   		pmdb.DBConnectionStart();
	   		Reporter.addStepLog("Connected to DB");
	   		sheetName = "SMASingleSWPAAP";
	   		sheet = exlObj.getSheet(sheetName);
	   				
			for (Map.Entry<String, HashMap<String, String>> data : ProxyDetails.entrySet())
			{						
					for (Map.Entry<String, String> list : data.getValue().entrySet())
					{	
						rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "SQL_Query");
						cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, list.getKey());
						if(list.getKey().contentEquals("Manager Name")) 
						{
							cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Manager Name Proxy");
						}
						myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
						System.out.println(data.getKey());
						
						myValue = myValue.replaceAll("@code", Code);
						switch(data.getKey())
						{
							case "Proxy Address":
								myValue = myValue.replaceAll("@Scenario", "PROXY");
								break;
							case "Voluntary Reorg Address":
								myValue = myValue.replaceAll("@Scenario", "Voluntary Reorg");
								break;
							case "Interim Address":
								myValue = myValue.replaceAll("@Scenario", "Interim");
								break;	
							default:
								break;
						}
						System.out.println(myValue);
						ResultSet allResult = DBManager.executeSelectQuery(myValue);				
						String result = null;
	
						while(allResult.next())
						{
							result = allResult.getString(1);
							if(result == null) 
							{
								System.out.println("DataBase Value :  Entered Value: "+list.getValue());
								Reporter.addStepLog("DataBase Value:  Entered Value: "+list.getValue());
								sftAst.assertEquals("",list.getValue(),data.getKey()+"DB");
							}
							else
							{
								System.out.println("DataBase Value: "+result+" Entered Value: "+list.getValue());
								Reporter.addStepLog("DataBase Value: "+result+" Entered Value: "+list.getValue());
								sftAst.assertEquals(result,list.getValue());
							}
						}
					}
			}
	   	}

	    catch (Exception e) 
		{
			Reporter.addStepLog("Unable to perform Database UI Check for Proxy Details");
		}
    }
    
  /*  public void DBRetriveSC3(String entity) throws Throwable
	{
		try
		{
			pmdb.DBConnectionStart();
			Reporter.addStepLog("Connected to DB");
			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			
			for(Map.Entry<String, HashMap<String, String>> data: DocumentDetails.entrySet()) 
			{
				HashMap<String, String> list = data.getValue();
				
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "SQL_Query");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Document Link");
				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
				System.out.println(data.getKey());
				
				myValue = myValue.replaceAll("@code", Code);
				myValue = myValue.replaceAll("@link", list.get("Document Link"));
				System.out.println(myValue);
				ResultSet allResult = DBManager.executeSelectQuery(myValue);
				Reporter.addStepLog("Executing the SQL Query " + myValue);
				sftAst.assertTrue(allResult.next() ,"Document Link is not present");
				
				for(Map.Entry<String, String> list1: data.getValue().entrySet()) 
				{
					if(list1.getKey().contentEquals("Document Link")) 
					{
						
					}
					else 
					{
						cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, list1.getKey());
						myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
						myValue = myValue.replaceAll("@code", Code);
						myValue = myValue.replaceAll("@link", list.get("Document Link"));
						System.out.println(myValue);
						allResult = DBManager.executeSelectQuery(myValue);
						Reporter.addStepLog("Executing the SQL Query " + myValue);
						
						while(allResult.next())
						{
							System.out.println("DataBase Value: " + allResult.getString(1) + " Entered Value: " + list1.getValue());
							Reporter.addStepLog("DataBase Value: " + allResult.getString(1) + " Entered Value: " + list1.getValue());
							sftAst.assertEquals(allResult.getString(1), list1.getValue());
						}
					}
				}
			}
		}
		catch(Exception e) 
		{
			Reporter.addStepLog("Unable to perform Database UI Check");
		}
	}*/
    
    public void DBRetriveSC3(String entity) throws Throwable
   	{
   		try 
   		{
   			pmdb.DBConnectionStart();
   			Reporter.addStepLog("Connected to DB");
   			sheetName = entity;
   			sheet = exlObj.getSheet(sheetName);

   			for(Map.Entry<String, HashMap<String, String>> data: DocumentDetails.entrySet()) 
   			{
   				HashMap<String, String> list = data.getValue();

   				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "SQL_Query");
   				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Document Link");
   				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
   				System.out.println(data.getKey() + " " + myValue);
   				
   				myValue = myValue.replaceAll("@code", Code);
   				System.out.println(myValue);
   				System.out.println(list);
   				
   				ResultSet allResult = DBManager.executeSelectQuery(myValue);
   				Reporter.addStepLog("Executing the SQL Query " + myValue);
   				String result = null;
   				
   				while(allResult.next())
   				{
   					result = allResult.getString(1);
   					
   					if(list.get("Document Link").equals(result))
   					{
   						System.out.println("DataBase Value: " + result+ " Entered Value: " + list.get("Document Link"));
   						Reporter.addStepLog("DataBase Value: " + result+ " Entered Value: " + list.get("Document Link"));
   	   					sftAst.assertEquals(result, list.get("Document Link"));
   	   					
   						cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Document Description");
   	   					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
   	    				myValue = myValue.replaceAll("@code", Code);
   	   					myValue = myValue.replaceAll("@id", allResult.getString(2));
   	   					System.out.println(myValue);
   	   					ResultSet allResult1 = DBManager.executeSelectQuery(myValue);
	   					Reporter.addStepLog("Executing the SQL Query " + myValue);
	   				
	   					while(allResult1.next())
	   					{
	   						result = allResult1.getString(1);
	   						System.out.println("DataBase Value: " + result+ " Entered Value: " + list.get("Document Description"));
	   						Reporter.addStepLog("DataBase Value: " + result+ " Entered Value: " + list.get("Document Description"));
	   	   					sftAst.assertEquals(result, list.get("Document Description"));
	   	   					
		   	   				result = allResult1.getString(2);
	   						System.out.println("DataBase Value: " + result+ " Entered Value: " + list.get("Document Type"));
	   						Reporter.addStepLog("DataBase Value: " + result+ " Entered Value: " + list.get("Document Type"));
	   	   					sftAst.assertEquals(result, list.get("Document Type"));
	
	   					}
					}
   					/*else if (allResult.isLast())
   					{
   						System.out.println("DataBase Value: null Entered Value: " + list.get("Document Link"));
   						Reporter.addStepLog("DataBase Value: null Entered Value: " + list.get("Document Link"));
						sftAst.assertEquals("", list.get("Document Link"));
					}*/
   				}
   			}
   		}
   		catch(Exception e) 
   		{
   			Reporter.addStepLog("Unable to perform Database UI Check");
   		}
   	}
    
  /*  public void DBRetriveSC4(String entity) throws Throwable
    {
		try
		{
			pmdb.DBConnectionStart();
			Reporter.addStepLog("Connected to DB");
			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			System.out.println(CommentDetails);
			
			for(Map.Entry<String, HashMap<String, String>> data: CommentDetails.entrySet()) 
			{
				HashMap<String, String> list = data.getValue();
				
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "SQL_Query");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Comment Description");
				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
				System.out.println(data.getKey());
				
				myValue = myValue.replaceAll("@code", Code);
				myValue = myValue.replaceAll("@link", list.get("Comment Description"));
				System.out.println(myValue);
				ResultSet allResult = DBManager.executeSelectQuery(myValue);
				Reporter.addStepLog("Executing the SQL Query " + myValue);
				sftAst.assertTrue(allResult.next(),"Comment Description is not present");
				
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Comment Type");
				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
				System.out.println(data.getKey());
				
				myValue = myValue.replaceAll("@code", Code);
				myValue = myValue.replaceAll("@link", list.get("Comment Description"));
				System.out.println(myValue);
				allResult = DBManager.executeSelectQuery(myValue);
				Reporter.addStepLog("Executing the SQL Query " + myValue);
				
				while(allResult.next())
				{
					System.out.println("DataBase Value: " + allResult.getString(1) + " Entered Value: " + list.get("Comment Type"));
					Reporter.addStepLog("DataBase Value: " + allResult.getString(1) + " Entered Value: " + list.get("Comment Type"));
					sftAst.assertEquals(allResult.getString(1), list.get("Comment Type"));
				}		
			}
		}
		catch(Exception e) 
		{
			Reporter.addStepLog("Unable to perform Database UI Check");
		}
    }*/
    
    public void DBRetriveSC4(String entity) throws Throwable
   	{
   		try 
   		{
   			pmdb.DBConnectionStart();
   			Reporter.addStepLog("Connected to DB");
   			sheetName = entity;
   			sheet = exlObj.getSheet(sheetName);

   			for(Map.Entry<String, HashMap<String, String>> data: CommentDetails.entrySet()) 
   			{
   				HashMap<String, String> list = data.getValue();

   				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "SQL_Query");
   				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Comment Description");
   				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
   				System.out.println(data.getKey() + " " + myValue);
   				
   				myValue = myValue.replaceAll("@code", Code);
   				System.out.println(myValue);
   				
   				ResultSet allResult = DBManager.executeSelectQuery(myValue);
   				Reporter.addStepLog("Executing the SQL Query " + myValue);
   				String result = null;
   				
   				while(allResult.next())
   				{
   					result = allResult.getString(1);
   					
   					if(list.get("Comment Description").equals(result))
   					{
   						System.out.println("DataBase Value: " + result+ " Entered Value: " + list.get("Comment Description"));
   						Reporter.addStepLog("DataBase Value: " + result+ " Entered Value: " + list.get("Comment Description"));
   	   					sftAst.assertEquals(result, list.get("Comment Description"));
   	   			 		
   						cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Comment Type");
   	   					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
   	   					myValue = myValue.replaceAll("@id", allResult.getString(2));
   	    				myValue = myValue.replaceAll("@code", Code);

   	   					System.out.println(myValue);
	   	   				ResultSet allResult1 = DBManager.executeSelectQuery(myValue);
	   					Reporter.addStepLog("Executing the SQL Query " + myValue);
	   				
	   					while(allResult1.next())
	   					{
	   						result = allResult1.getString(1);
	   						System.out.println("DataBase Value: " + result+ " Entered Value: " + list.get("Comment Type"));
	   						Reporter.addStepLog("DataBase Value: " + result+ " Entered Value: " + list.get("Comment Type"));
	   	   					sftAst.assertEquals(result, list.get("Comment Type"));
	   					}
					}
   					/*else if (allResult.isLast())
   					{
   						System.out.println("DataBase Value: null Entered Value: " + list.get("Comment Description"));
   						Reporter.addStepLog("DataBase Value: null Entered Value: " + list.get("Comment Description"));
						sftAst.assertEquals("", list.get("Comment Description"));
					}*/
   				}
   			}
   		}
   		catch(Exception e) 
   		{
   			Reporter.addStepLog("Unable to perform Database UI Check");
   		}
   	}
    
    public void SoftAssertion() throws Throwable
    {
    	sftAst.assertAll();
    }
}
