package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateSMASingleAccessStrategyDocumentsPage {

	Action action;
	WebElement Element,Highlight;
	int loopCount;
	
	public CreateSMASingleAccessStrategyDocumentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public void clickOnNext() {
		action.scrollToBottom();
		action.waitForJSWebElement("NEXT").click();
	}

	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void selectDocumentType(String documentType) {
		
		Element =(WebElement) action.fluentWaitForJSWebElement("drpDwnDocumentType");
		Element.click();
		Highlight =(WebElement) action.fluentWaitForJSWebElement("DocumenttypeKey");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(documentType)) {
				Highlight = E;
				break;
			}
		}
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}
	
	public void enterDocumentLink(String documentLink) {
		
		WebElement ele =(WebElement) action.fluentWaitForJSWebElement("txtDocLink");
		loopCount = 0;
		do {
			ele.click();
			myClear(ele);
			action.doubleClick(ele);
			action.sendKeys(ele, documentLink);
		} while (!(getDocumentLinkValue().equals(documentLink)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}
	
	private String getDocumentLinkValue() {
		Element = action.waitForJSWebElement("Document Link Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}
	
	public void enterDocumentComment(String documentComment) {
		
		WebElement ele =(WebElement) action.fluentWaitForJSWebElement("txtDocComment");
		loopCount = 0;
		do {
			ele.click();
			myClear(ele);
			action.doubleClick(ele);
			action.sendKeys(ele, documentComment);
		} while (!(getDocumentCommentValue().equals(documentComment)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}
	private String getDocumentCommentValue() {
		Element = action.waitForJSWebElement("Document Comment Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}
	
	public void clickOnAddDocumentLinkButton() {
	
		action.waitForJSWebElement("AddDocumentLinkButton").click();
	
	}

	public void clickOnAddAnotherDocument() {
	
		Element  = action.getElement("Add Another Document Link");
		Element.click();	
	}

	public boolean isUserOnDocumentsPage() {
		action.waitForJSWebElement("SMA Single Access Text");
		Element = action.waitForJSWebElement("Documents Text");
		if(action.getText(Element).equalsIgnoreCase("Documents")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	
	}

	
}
