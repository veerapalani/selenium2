package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class CreateFAReviewPage {
	Action action;
	WebElement myElement;

	public CreateFAReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void clickonsubmitbutoninreviewpage() throws InterruptedException {
		myElement = action.fluentWaitWebElement("SubmitButtoninreviewpage");
		action.click(myElement);
	}

	public void verifyreviewtitle() throws InterruptedException {
		action.fluentWaitWebElement("Reviewtitle");
		Assert.assertTrue(action.isDisplayed(action.getElement("Reviewtitle")));
	}

	public void verifyapprovername() throws InterruptedException {
		myElement = action.fluentWaitWebElement("Approvername");
		Assert.assertTrue(action.isDisplayed(myElement));
		String text = myElement.getText();
	}

	public String getcommonattributevalue(String label) {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", label);
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String requiredDocumentValue(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		List<WebElement> documentValues = action.getElements("Document Values");
		action.highligthElement(documentValues.get(i));
		return documentValues.get(i).getText();
	}

	public void clickonpreviousbuttoninreviewpage() throws InterruptedException {
		myElement = action.fluentWaitWebElement("Previous Button");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}
}
