package qa.unicorn.ad.productmaster.webui.pages;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class UpdateSMASingleAccessStrategyConfirmationPage {

	Action action;
	public UpdateSMASingleAccessStrategyConfirmationPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
}
