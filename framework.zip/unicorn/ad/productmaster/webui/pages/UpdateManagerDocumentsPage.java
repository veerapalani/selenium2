package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdateManagerDocumentsPage {

	Action action;

	public UpdateManagerDocumentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	WebElement Element, Highlight;
	Boolean flag;

	public boolean isUserOnDocumentsPage() {
		Element = (WebElement) action.waitForJSWebElement("Header");
		if (Element.getText().equals("Enter Document Links")) {
			action.highligthElement(Element);
			Reporter.addCompleteScreenCapture();
			return true;
		}
		return false;
	}

	public void clickOnNext() {
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("NEXT");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		Element.click();
	}

	public void selectDocumentType(String documentType) {
		Element = (WebElement) action.fluentWaitForJSWebElement("drpDwnDocumentType");
		action.highligthElement(Element);
		Element.click();
		Highlight = (WebElement) action.getElementByJavascript("DocumenttypeKey");
		Highlight = Highlight.findElement(By.linkText(documentType));
		/*
		 * List<WebElement> li = action.getElementsFromParentElement(Highlight,
		 * "List Values of any Dropdown");
		 * 
		 * for(WebElement E : li) { if(E.getText().equalsIgnoreCase(documentType)) {
		 * Highlight = E; break; } }
		 */
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterDocumentLink(String documentLink) {

		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDocLink");
		action.highligthElement(ele);
		action.sendKeys(ele, documentLink);
	}

	public void enterDocumentComment(String documentComment) {

		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDocComment");
		action.highligthElement(ele);
		action.sendKeys(ele, documentComment);
	}

	public void clickOnAddDocumentLinkButton() {

		WebElement ele = action.fluentWaitWebElement("AddDocumentLinkButton");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		ele.click();
		action.pause(1000);
		isUserOnDocumentsPage();

	}

	public boolean checkIfAddAnotherDocumentLinkDisplayed() {
		Boolean flag = true;

		Element = action.fluentWaitWebElement("Document Card to identify button displayed");
		List<WebElement> elements = Element.findElements(By.xpath("./*"));

		for (WebElement webElement : elements) {
			if (webElement.getTagName().contains("brml-form"))
				flag = false;
		}

		return flag;
	}

	public void clickOnAddAnotherDocument() {

		// List<WebElement> elements =
		// action.fluentWaitWebElements("AddDocumentLinkButton");

		if (checkIfAddAnotherDocumentLinkDisplayed()) {

			Element = action.fluentWaitWebElement("Add Another Document Link");
			Element.click();
			action.pause(1000);
			isUserOnDocumentsPage();
		} else {
			Reporter.addStepLog("No Add Another Document Link is displayed in UI");

		}
	}

	public void clickOnPrevious() {
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("PREVIOUS");
		action.highligthElement(Element);
		Reporter.addCompleteScreenCapture();
		Element.click();
	}

	public int getcountofDocuments() {

		List<WebElement> Elements = action.getElements("Type");
		if (Elements.size() > 0) {
			List<WebElement> Elements2 = action.getElements("Documents Count");
			return Elements2.size() - 1;
		} else {
			return 0;
		}

	}

	public ArrayList<String> getithDocumentInfo(int i) {

		ArrayList<String> document = new ArrayList<String>();
		Element = action.getElementByFormatingXpath("Document Record", i + 1);
		action.highligthElement(Element);
		ArrayList<WebElement> Elements = (ArrayList<WebElement>) action.getElementsFromParentElement(Element,
				"Common Tag for Document Values");
		String value = "";
		for (int j = 0; j < Elements.size() - 1; j++) {

			value = Elements.get(j).getText();

			// deleting the extra charaters from get text
			if (j == 2) {

				value = value.substring(0, value.length() - 15).trim();

			}
			document.add(value);

		}

		return document;
	}

	public void clickOnDocumentType() {

		Element = (WebElement) action.fluentWaitForJSWebElement("drpDwnDocumentType");
		Element.click();

	}

	public boolean isValueDisplayedinTypeDropdown(String dropDownValue) {
		Highlight = (WebElement) action.getElementByJavascript("DocumenttypeKey");
		// Highlight = Highlight.findElement(By.linkText(documentType));

		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");

		for (WebElement E : li) {
			if (E.getText().equalsIgnoreCase(dropDownValue)) {
				Highlight = E;
				return true;
			}
		}
		return false;
	}

	// Code data in heidisql is not implemented for below
	private String requiredDocumentValue(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		Element = action.fluentWaitWebElement("Document Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element,
				"Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";

		for (WebElement E : documentValues) {
			if (E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
			}

		}
		int documents = documentValuesData.size() / 3;

		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i + 3;
		}

		if (documents > 1) {
			Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue + G + ",";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length() - 1);
		}
		tempData.clear();

		return requiredDocumentValue;
	}

	public String getDocumentTypeValue() {

		return requiredDocumentValue(0);
	}

	public String getDocumentLinkValue() {
		return requiredDocumentValue(1);
	}

	public String getDocumentCommentValue() {
		return requiredDocumentValue(2);
	}

	public void deleteDocument() {
		List<WebElement> elements = action.getElements("Delete Documents");

		elements.get(elements.size() - 1).click();
		action.pause(1000);
		isUserOnDocumentsPage();

	}

	public ArrayList<String> getDropdownValuesDisplayedInUI(String dropdownName) {
		String replacedata = "";

		ArrayList<String> tempData = new ArrayList<String>();

		String uiIterator = "testNull";

		switch (dropdownName) {
		case "Type":
			replacedata = "documentType";
			break;
		default:
			break;
		}

		Highlight = action.getElementByFormatingXpath("Common Dropdown List", replacedata);
		List<WebElement> dropdownValuesFromUI = action.getElementsFromParentElement(Highlight,
				"List Values of any Dropdown");

		for (WebElement E : dropdownValuesFromUI) {

			uiIterator = E.getText();
			tempData.add(uiIterator);
		}
		// to handle Zero records from DB
		if (uiIterator.equalsIgnoreCase("testnull")) {
			uiIterator = "isEmpty";
			tempData.add(uiIterator);
		}
		// to handle multiple values for same column
		if (tempData.size() > 1) {
			Collections.sort(tempData);
		}

		return tempData;
	}

	public boolean areDocumentsAvailableinUI() {

		List<WebElement> elements = action.getElements("Delete Documents");

		if (elements.size() > 0)
			return true;
		else
			return false;
	}

	public void clickOnBackLink() {

		action.navigateBackward();

	}

	public void clickOnReset() {

		Element = action.fluentWaitWebElement("Reset");
		action.moveToElement(Element);
		Element.click();
		isUserOnDocumentsPage();

	}

	public String getDocumentTypeValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Type");
		return Element.getAttribute("value");
	}

	public String getDocumentLinkValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Document Link");
		return Element.getAttribute("value");
	}

	public String getDocumentCommentValueinEditPage() {
		Element = action.getElementByFormatingXpath("Common Attribute in Edit Page", "Comment");
		return Element.getAttribute("value");
	}

	public boolean error(String errormessage) {
		flag = false;
		action.pause(2000);
		String[] expErrorlist = errormessage.split("-");
		/*
		 * if(experror.contains("-")) { expErrorlist = experror.split("-"); } else
		 * expErrorlist[0] = experror;
		 */

		for (String S : expErrorlist) {
			switch (S) {
			case "Type must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Type");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: " + Element.getText());
				Reporter.addStepLog("Expected Message: " + S);
				flag = true;
				break;
			case "Document Link must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Document Link");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: " + Element.getText());
				Reporter.addStepLog("Expected Message: " + S);
				flag = true;
				break;
			case "Comment must not be empty":
				Element = action.getElementByFormatingXpath("Error Message", "Comment");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(S));
				Reporter.addStepLog("Actual Message: " + Element.getText());
				Reporter.addStepLog("Expected Message: " + S);
				flag = true;
				break;
			default:
				Reporter.addStepLog("Expected Message: " + S);
				Reporter.addStepLog("Expected Error Message is invalid ");
				flag = false;
				break;
			}
			if (flag == false)
				break;
		}

		return flag;

	}

	public void clickOnDeleteIconofDocumentLinks() throws InterruptedException {
		WebElement ele = action.getElement("Delete Icon of Document Links2");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.click(ele);
		Thread.sleep(1000);
	}

}
