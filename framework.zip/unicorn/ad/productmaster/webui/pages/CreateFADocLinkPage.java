package qa.unicorn.ad.productmaster.webui.pages;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateFADocLinkPage {
	Action action ;
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public CreateFADocLinkPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public void clickOnNext() {
		action.scrollToBottom();
		action.pause(2000);
		action.getElement("NEXTbuttonFAdocPage").click();
		action.pause(10000);
	}
	public void clickonaddanotherdoclink() {
		
		action.pause(1000);
		action.getElement("AddAnotherDocLink").click();
		
	}

	public void selectDocumentType() throws InterruptedException {
		Thread.sleep(700);
		action.click((WebElement) action.getElementByJavascript("drpDwnDocumentType"));
		action.click((WebElement) action.getElementByJavascript("DocumenttypeKey"));
	}
	
	public void enterDocumentLink() throws InterruptedException {
		
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtDocLink");
		action.highligthElement(ele);
		action.sendKeys(ele, "https://www.google.com");
	}
	
public void enterDocumentComment() throws InterruptedException {
		
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtDocComment");
		action.highligthElement(ele);
		action.sendKeys(ele, "12345creatingsmadualdocuments");
	}

public void clickOnAddDocumentLinkButton() throws InterruptedException {
	
	action.getElement("AddDocumentLinkButton").click();
	action.pause(10000);
}
}
