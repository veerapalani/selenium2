package qa.unicorn.ad.productmaster.webui.pages;

import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.poi.hssf.record.PageBreakRecord.Break;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.ibm.db2.jcc.a.i;

import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;

public class SaveAsDraftAllUIPage 
{
	/*String pageURL = SSOLoginPage.URL + "#/";
	Action action;
	WebElement myElement,myElement1;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	XSSFSheet inputSheet,sheet;
	String sheetName = "";
	String myValue,myValue1;
	String draftName = "SaveAsDraftRgow";
	int rowIndex, cellIndex;
	String inputSheetName = "InputSheet";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategySMADual.xlsx";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	Boolean compareBoolean;
	List<WebElement> myElements,myElements1;
	String proxyDetails[]= {"Proxy Address","Voluntary Reorg Address","Interim"};
	String scenario[]= {"0","2","4"};
	WebElement Element;
	int num;
	String timeStamp = new SimpleDateFormat("dd-MM-yyyy(HH:mm)").format(new Date());

	
	SoftAssert sftAst = new SoftAssert();

	HashMap<String, String> DropDownValues = new HashMap<String, String>();
	HashMap<String, String> InputValues = new HashMap<String, String>();
	HashMap<String, String> ProxyValues = new HashMap<String, String>();
	HashMap<String, String> DropDownValuesId = new HashMap<String, String>();
	HashMap<String, String> InputValuesId = new HashMap<String, String>();*/
	
	String pageURL = SSOLoginPage.URL + "#/smaDualMac/view/";
	String pageURL2 = SSOLoginPage.URL + "#/smaDualMac/edit/";
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/SaveAsDraftAll.xlsx";
	String sheetName = "";
	String myValue,myValue1;
	String draftName = "SaveAsDraftRgow";
	XSSFSheet inputSheet,sheet;
	int rowIndex, cellIndex;
	WebElement myElement,myElement1;
	List<WebElement> myElements,myElements1;
	String proxyDetails[]= {"Proxy Address","Voluntary Reorg Address","Interim"};
	String scenario[]= {"0","2","4"};
	int num;
	String inputSheetName = "InputSheet";
	String timeStamp = new SimpleDateFormat("dd-MM-yyyy(HH:mm)").format(new Date());
	List<List<String>> attributeLists = new ArrayList<List<String>>();
	List<String> dataList = new ArrayList<String>() ;
	WebElement Element;
	List<String> list = new ArrayList<String>();
	Boolean compareBoolean;

	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	Action action;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	StrategyDetailPage strDtl = new StrategyDetailPage();
	SoftAssert sftAst = new SoftAssert();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	DecimalFormat format = new DecimalFormat("0.##");

	HashMap<String, String> DropDownValues = new HashMap<String, String>();
	HashMap<String, String> InputValues = new HashMap<String, String>();
	HashMap<String, String> DropDownValuesId = new HashMap<String, String>();
	HashMap<String, String> InputValuesId = new HashMap<String, String>();
	HashMap<String, String> DataBaseValues = new HashMap<String, String>();
	HashMap<String, String> ProxyValues = new HashMap<String, String>();
	HashMap<String ,HashMap<String,String>> ProxyDetails = new HashMap<String ,HashMap<String,String>>();
	HashMap<String ,HashMap<String,String>> DocumentDetails = new HashMap<String ,HashMap<String,String>>();
	HashMap<String ,HashMap<String,String>> CommentDetails = new HashMap<String ,HashMap<String,String>>();
	HashMap<String, Double> BenchmarkValues = new HashMap<String, Double>();
	HashMap<String ,HashMap<String,Double>> BenchmarkDetails = new HashMap<String ,HashMap<String,Double>>();
	HashMap<String,String> ContactDetails = new LinkedHashMap<String,String>();
	
	String applicationPropertyFilePath = "./application.properties";

	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	//String UIEnvironment = property.getProperty("ProductMaster_UI_Environment").trim().toUpperCase();.
	 String UIEnvironment = SSOLoginPage.UIEnvironment.trim().toUpperCase();
	
	public SaveAsDraftAllUIPage()
	{
		action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategySMADualUIPage"));
	}

	public String getCurrentTimeStamp()
	{
		Long time = Calendar.getInstance().getTimeInMillis();
		return time.toString();
	}

	public void verifyTextInListOfElements(String text, List<WebElement> list1) 
	{
		for(int i = 0; i < list1.size(); i++)
		{
			list.add(list1.get(i).getText());
		}
		
		for(int i = 0; i < list.size(); i++)
		{
			if(list.get(i).contains(text))
			{
				action.highligthElement(list1.get(i));
				Assert.assertTrue(true);
				return;
			}
		}
	}

	public WebElement findElementByDynamicXpath(String xpath) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public List<WebElement> findElementsByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		listOfElements = element.getElements("xpath", xpath);
		return listOfElements;
	}
	
	public WebElement findElementByCssSelector(String css) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("cssselector", css);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public List<WebElement> getDynamicElementsFromShadowRoot(String javaScript) 
	{
		return listOfElements = (List<WebElement>)action.executeJavaScript(javaScript);
	}
	
	public String waitForWebElement(String xpath) 
	{

		int timeLaps = 0;
		String status = "FAIL";
		WebElement jsElement = null;
		while (status.equals("FAIL") && timeLaps < 2) {
			try {

				//jsElement = (WebElement) getElementByJavascript(dbkey);
				//jsElement = (WebElement) getElement(dbkey);
				jsElement = findElementByDynamicXpath(xpath);
				
				if (jsElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Exception e) {

				status = "FAIL";

			}

			Action.pause(2000);

			++timeLaps;

		}

		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);

		return status;

	}
	
	public final boolean isPresent(String value)
	{
		boolean isPresent = false;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		while(true) 
		{
			try 
			{
				js.executeScript(value);
				isPresent = true;
				break;
			} catch (Exception e) 
			{
				break;
			} 
		}
		
		return isPresent;
	}
	
	public final Object executeJavaScript(String javaScript)
	{
		waitForJavaScript(javaScript);
		
		Object scriptReturn = null;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try 
		{
			scriptReturn = js.executeScript(javaScript);
			status = "PASS";

		} 
		catch (Exception e)
		{
			ExceptionHandler.handleException(e);
		} 
		finally 
		{
			Report.printOperation("Execute Javascript");
			Report.printValue(javaScript);
			Report.printStatus(status);
		}

		return scriptReturn;
	}
	
	public void myClear(WebElement element)
	{		
		//JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		((JavascriptExecutor)WebDriverManager.getDriver()).executeScript("arguments[0].value='';", element);
	}
	
	public final Object executeJavaScriptWithoutWait(String javaScript)
	{		
		Object scriptReturn = null;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try 
		{
			scriptReturn = js.executeScript(javaScript);
			status = "PASS";
		} 
		catch (Exception e)
		{
			ExceptionHandler.handleException(e);
		} 
		finally 
		{
			Report.printOperation("Execute Javascript");
			Report.printValue(javaScript);
			Report.printStatus(status);
		}

		return scriptReturn;
	}
	
	
	public String waitForJavaScript(String javaScript) 
	{		
		int timeLaps = 0;
		String status = "FAIL";
		Object jsElement = null;
		while (status.equals("FAIL") && timeLaps < GlobalVariables.waitTime) {
			try {
				//jsElement = (WebElement) getElementByJavascript(dbkey);
				//jsElement = (WebElement) getElement(dbkey);
				jsElement = (Object)action.executeJavaScript(javaScript);
				
				if (jsElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Throwable e) {
				status = "FAIL";
			}

			Action.pause(100);
			++timeLaps;
		}
		
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);

		return status;

	}
	
	
	public void writeIntoExcel(String inputSheetName, String feildName,String valueToBeStored,String scenario)
	{
		inputSheet = exlObj.getSheet(inputSheetName);
		rowIndex = exlObj.getRowIndexByCellValue(inputSheet, 0, scenario+UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(inputSheet, 0, feildName);
		exlObj.setCellData(inputSheet, rowIndex, cellIndex, valueToBeStored);
	}
	
	public void sendKeysWithCheck(WebElement element, String value)
	{
		try 
		{
			action.sendKeys(element, value);
			while(true) 
			{
				Thread.sleep(500);
				if(!(element.getAttribute("value").trim().equalsIgnoreCase(value))) 
				{
					myClear(element);
					//action.clear(element);
					action.sendKeys(element, value);
				}
				else 
				{
					System.out.println("Input :" + element.getAttribute("value"));
					break;
				}
			}
		}
		catch(Exception e) 
		{
			ExceptionHandler.handleException(e);
		}
	}

	public void clickOnNewAsset()
	{
		findElementByDynamicXpath("//brml-button[@id='btnAddunBundledNode']").click();
	}
	
	public void clickOnNewBenchmark() 
	{
		findElementByDynamicXpath("//brml-button[@id='btnAddSet1']").click();
	}
	
	public void deleteAllBins() throws Throwable 
	{
		int i = 0;
		
		while(i<=1)
		{
				myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[class='card-body']\")["+i+"].querySelectorAll(\"brml-active-icon[name='bin']\")");
				
				int bins = myElements.size();
				System.out.println("no of bins "+bins);
				
				while(bins > 0)
				{
					bins--;
					myElement = myElements.get(bins);
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					myElement.click();
					Reporter.addStepLog("Deleted bin");
					Thread.sleep(2000);
					
				}
				
				i++;
		}
	}
	
	public void deleteAllBins(int j) throws Throwable 
	{
		int i = 0;
		
		while(i<j)
		{
//				myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[class='card-body']\")["+i+"].querySelectorAll(\"brml-active-icon[name='bin']\")");
//				myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"brml-active-icon\")["+i+"].shadowRoot.querySelector(\"svg\")");
				myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"brml-active-icon\")");

				int bins = myElements.size();
				System.out.println("no. of bins "+bins);
				
				while(bins > 0)
				{
					bins--;
					myElement = myElements.get(bins);
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					myElement.click();
					Reporter.addStepLog("Deleted bin");
					Thread.sleep(2000);
					
				}
				
				i++;
		}
	}
	
	public void selectDropdownByIndex(String entity, String scenario, List<List<String>> attribute) throws Throwable
	{
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++)
		{
//			try
//			{
				waitForJavaScript("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");

				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");
				
				if(!Boolean.parseBoolean(myValue))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
					
					action.scrollToElement(myElement);
					action.jsClick(myElement);
					Thread.sleep(500);
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+attribute.get(i).get(1)+ "\"]').shadowRoot.querySelector(\"li[data-value='" + myValue + "']\")");
					
					System.out.println(myElement.getText());
									
					DropDownValues.put(attribute.get(i).get(0),myElement.getText());
					DropDownValuesId.put(attribute.get(i).get(1),myElement.getText());
	
					action.scrollToElement(myElement);
					Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");
	
					action.click(myElement);				
				}
				else
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("value");
					if(isPresent("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')"))
					{
						myValue = (String)executeJavaScript("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')");
						myValue = myValue.replaceAll("-\\d{4}$", "");
					}					
					DropDownValues.put(attribute.get(i).get(0),myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				}
//			}
//			catch (Exception e) 
//			{
//				Assert.fail("Unable to access "+attribute.get(i).get(0) );
//			}
		}
    		
	}

	public String selectBMDropdown(String id,String value) throws Throwable
	{
		myElement1 = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
				+id+ "\"]').shadowRoot.querySelector('wf-input')");
		
		if(myElement1.isEnabled())
		{
		//action.scrollToElement(myElement1);
		action.highligthElement(myElement1);
		action.jsClick(myElement1);
		//Thread.sleep(2000);
		
		myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
				+id+ "\"]').shadowRoot.querySelector(\"li[data-value='" + value + "']\")");
		
		value = myElement.getText();
		
		 Pattern pat = Pattern.compile("^.+?-\\s|-\\d{4}$");
		// Pattern pat = Pattern.compile(".+?-\\s|-\\d{4}$");
		// Pattern pat = Pattern.compile("-\\d{4}$");

		 Matcher mat = pat.matcher(value);
		 value = mat.replaceAll("");
		   
		System.out.println(value);
		
		action.scrollToElement(myElement);
		action.jsClick(myElement);
		//Thread.sleep(2000);	
		}
		return value;
	}
	
	public String enterPercentage(String id,String value) throws Throwable 
	{
		myElement = (WebElement) executeJavaScript("return document.querySelector('brml-stepper-input#"+id+"').shadowRoot.querySelector('input.input-stepper-data')");

		if(myElement.isEnabled())
		{
		  // action.scrollToElement(myElement);
		   action.click(myElement);
		   action.clear(myElement);
		   myElement = (WebElement) executeJavaScript("return document.querySelector('brml-stepper-input#"+id+"').shadowRoot.querySelector('input.input-stepper-data')");

		   action.click(myElement);
		   action.clear(myElement);
		   action.sendKeys(myElement, value);
		   //action.click(findElementByDynamicXpath("//html"));
		   action.click(findElementByDynamicXpath("//div[contains(text(),'Benchmark')]"));

		   myElement = (WebElement) executeJavaScript("return document.querySelector('brml-stepper-input#"+id+"')");
		   Thread.sleep(2000);
		   
		   Pattern pat = Pattern.compile("\\.0{2}$");
		   Matcher mat = pat.matcher(myElement.getAttribute("value"));
		   myValue = mat.replaceAll("");
		   
		}
		   return(myValue);
	}
	
	
	
	public synchronized void globalSearch(String searchCode,String entity,String scenario) throws Throwable
	{
			action.waitForPageLoad();
			Thread.sleep(5000);
			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchCode);

			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			//Code = myValue;
			System.out.println(myValue);
			
	 		compareBoolean = action.isPresent("js", "return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			if(compareBoolean)
			{
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
				myElement.click();
			}
			
			myElement = (WebElement)executeJavaScriptWithRefresh("return document.querySelector(\"brml-search-input\")");
			myElement.click();
			action.sendKeys(myElement, myValue);
			//sendKeysWithCheck(myElement, myValue);
			Thread.sleep(2000);
			int i = 0;
			
			while(i < 5)
			{
				myElement.sendKeys(Keys.ENTER);
				i++;
			}
			Thread.sleep(2000);
		}
	
	public synchronized void clickMatchingSuggestion(String searchCode,String entity,String scenario) throws Throwable
	{
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario + UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Entity Type");
		myValue1 = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		Thread.sleep(5000);
		//		waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
		//		System.out.println("clickmatching 2");
		
		if(entity.equalsIgnoreCase("FATeam")) 
		{
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[1]");
		}
		else 
		{
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
		}
		
		String status = "FAIL";
		for(WebElement E: myElements)
		{
			if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
			{
				status = "PASS";
				action.scrollToElement(E);
				action.highligthElement(E);
				Thread.sleep(5000);
				E.click();
				Reporter.addStepLog("clicking on the matching suggestion");
				break;
			}
		}
		
		int i=0;
		while(status.contentEquals("FAIL") && i<3) 
		{
			i++;
			Thread.sleep(5000);
			myElement.sendKeys(Keys.ENTER);
			if(entity.equalsIgnoreCase("FATeam")) 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[1]");
			}
			else 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
			}
			for(WebElement E: myElements) 
			{
				if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
				{
					status = "PASS";
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();
					Reporter.addStepLog("clicking on the matching suggestion");
					break;
				}
			}
		}
		if(status.contentEquals("FAIL")) 
		{
			globalSearch(searchCode, entity, scenario);
			clickMatchingSuggestion1(searchCode, entity, myValue1);
		}
	}
	
	public synchronized void clickMatchingSuggestion1(String searchCode,String entity,String value) throws Throwable
	{
		myValue1 = value;
		Thread.sleep(5000);
		//		waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
		//		System.out.println("clickmatching 2");
		
		if(entity.equalsIgnoreCase("FATeam")) 
		{
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[1]");
		}
		else 
		{
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
		}
		
		String status = "FAIL";
		for(WebElement E: myElements)
		{
			if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
			{
				status = "PASS";
				action.scrollToElement(E);
				action.highligthElement(E);
				Thread.sleep(5000);
				E.click();
				Reporter.addStepLog("clicking on the matching suggestion");
				break;
			}
		}
		
		int i=0;
		while(status.contentEquals("FAIL") && i<3) 
		{
			Thread.sleep(5000);
			myElement.sendKeys(Keys.ENTER);
			if(entity.equalsIgnoreCase("FATeam")) 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[1]");
			}
			else 
			{
				myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
			}
			for(WebElement E: myElements) 
			{
				if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
				{
					status = "PASS";
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();
					Reporter.addStepLog("clicking on the matching suggestion");
					break;
				}
			}
		}
	}
	
	public void waitMatchingSuggestion(String entity,String scenario) throws Throwable
	{
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Entity Type");
		myValue1 = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		Thread.sleep(5000);
//		waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
//		System.out.println("clickmatching 2");
		
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
			
			String status = "FAIL";
			
			for(WebElement E : myElements)
			{
				if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
				{
					status = "PASS";
					Thread.sleep(1000);
					
					Reporter.addStepLog("waiting on the matching suggestion");
					
					break;
				}
				
			}
				
				if(status.contentEquals("FAIL"))
				{
					myElement.sendKeys(Keys.ENTER);
					
					myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
					for(WebElement E : myElements)
					{
						if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
						{
							status = "PASS";
							Thread.sleep(1000);
							
							Reporter.addStepLog("waiting on the matching suggestion");
							
							break;
						}
						
					}
				}
	}
	
	
	public void checkButton(String entity) throws Throwable
	{
		action.waitForPageLoad();
		sftAst.assertTrue(action.getCurrentURL().equalsIgnoreCase(pageURL+entity+"/view/"), "We are in Update"+entity+"UIPage"); 
		Reporter.addStepLog("We are in Update"+entity+"UIPage");
		Reporter.addScreenCapture();
		myElement = action.getElement("Continue_Editing_Button");
		sftAst.assertTrue(myElement.isDisplayed(), "Continue Edit Button is displayed");
		Reporter.addStepLog("Continue Edit Button is displayed");

	}
	
	public void clickCreateNew() throws Throwable
	{

		myElement = (WebElement)executeJavaScriptWithRefresh("return document.querySelector('brml-select').shadowRoot.querySelector('wf-button')");
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("Clicked on Create New button");
		
	}
	
	public final Object executeJavaScriptWithRefresh(String javaScript) 
	{
		Object scriptReturn = null;

		String status = waitForJavaScript(javaScript);
		System.out.println(status);
		
		if(status.contentEquals("FAIL")) 
		{		
			action.refresh();
			System.out.println("Refreshing the page");
			Reporter.addStepLog("Refreshing the page");
			action.waitForPageLoad();
		}
	
		scriptReturn = (WebElement)executeJavaScript(javaScript);
		return scriptReturn;
		
	}
	
	
	public WebElement findElementByDynamicXpathWithRefresh(String xpath) 
	{
		Element element = new Element(WebDriverManager.getDriver());
		String status = waitForWebElement(xpath);
		if(status.contentEquals("FAIL")) 
		{
			action.refresh();
			System.out.println("Refreshing the page");
			Reporter.addStepLog("Refreshing the page");
			action.waitForPageLoad();
		}

		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public void clickCreateNewOption(String entity) throws Throwable
	{

		try
    	{
	    	myElements = getDynamicElementsFromShadowRoot("return document.querySelector('brml-select').shadowRoot.querySelectorAll('li')");
	    	
	    	for(WebElement E : myElements) 
			{
				if(E.getText().equalsIgnoreCase(entity))
				{
					myElement = E;
					break;
				}
			}
	    	
	    	action.scrollToElement(myElement);
	    	action.highligthElement(myElement);
	    	action.click(myElement);
			Reporter.addStepLog(entity+" is clicked");
			action.waitForPageLoad();

    	}
    	
    	catch (Exception e) 
    	{
			Assert.fail("Unable to access "+ entity +" option");
		}
	}
	
	
	
	public void clickMatchingSuggestion(String entity) throws Throwable
	{
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Entity Type");
		myValue1 = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		Thread.sleep(5000);
//		waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
//		System.out.println("clickmatching 2");

		
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
			
			String status = "FAIL";
			
			for(WebElement E : myElements)
			{
				if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
				{
					status = "PASS";
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();
					
					Reporter.addStepLog("clicking on the matching suggestion");
					
					break;
				}
				
			}
				
				if(status.contentEquals("FAIL"))
				{
					myElement.sendKeys(Keys.ENTER);
					
					myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
					for(WebElement E : myElements)
					{
						if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
						{
							action.scrollToElement(E);
							action.highligthElement(E);
							Thread.sleep(5000);
							E.click();
							
							Reporter.addStepLog("clicking on the matching suggestion");
							
							break;
						}
						
					}
				}
	}
	
	public void waitMatchingSuggestion(String entity) throws Throwable
	{
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Entity Type");
		myValue1 = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		Thread.sleep(5000);
//		waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
//		System.out.println("clickmatching 2");

		
			myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
			
			String status = "FAIL";
			
			for(WebElement E : myElements)
			{
				if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
				{
					status = "PASS";
					Thread.sleep(1000);
					
					Reporter.addStepLog("waiting on the matching suggestion");
					
					break;
				}
				
			}
				
				if(status.contentEquals("FAIL"))
				{
					myElement.sendKeys(Keys.ENTER);
					
					myElements = findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
					for(WebElement E : myElements)
					{
						if(E.getText().toUpperCase().contains(myValue.toUpperCase())) 
						{
							status = "PASS";
							Thread.sleep(1000);
							
							Reporter.addStepLog("waiting on the matching suggestion");
							
							break;
						}
						
					}
				}
	}
	
	public void clickButton(String buttonName) throws Throwable
	{
		if(buttonName.contentEquals("Product Master"))
		{
			myElement = findElementByDynamicXpath("(//*[contains(text(),'"+buttonName+"')])[2]");
		}
		else
		{
			myElement = findElementByDynamicXpath("//*[contains(text(),'"+buttonName+"')]");
		}
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(500);
		myElement.click();
		Reporter.addStepLog(buttonName+" button is clicked");
		action.waitForPageLoad();
	}
	
	public void clickSaveAsDraft() throws Throwable
	{
		myElement = findElementByDynamicXpath("//*[contains(text(),'SAVE AS DRAFT')]");
    	action.scrollToElement(myElement);
    	myElement.click();
		Reporter.addStepLog("Save As Draft button is clicked");
    	Thread.sleep(3000);
	}
	
	public void enterDraftName() throws Throwable
	{
		    	//wait.until(ExpectedConditions.numberOfWindowsToBe(1));
		////	String draftWindow = WebDriverManager.getDriver().getWindowHandle();
		////	WebDriverManager.getDriver().switchTo().window(draftWindow);
		////	Reporter.addStepLog("the window handle is" + draftWindow);		
				
		    //	myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"brml-input[label='Draft Name']\").shadowRoot.querySelector('wf-tooltip > div > div >input')");
		    	myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-input[label='Draft Name']\").shadowRoot.querySelector('wf-tooltip > div > div >input')");

		    	action.jsClick(myElement);
		    	sendKeysWithCheck(myElement, draftName);
				
//				myElement = (WebElement) action.executeJavaScript("return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");

				action.jsClick(myElement);
				
				Thread.sleep(2000);
				Alert alt = WebDriverManager.getDriver().switchTo().alert();
				String actualmsg = alt.getText();	
				System.out.println(actualmsg);
				alt.accept();
				Thread.sleep(5000);
				Reporter.addStepLog("The draft name is entered");	
	}
	
	public void checkInDraftView() throws Throwable
	{
    	myElement = findElementByDynamicXpath("//span[contains(text(),'Product Master')]");
    	action.scrollToElement(myElement);
    	Thread.sleep(1000);
    	myElement.click();
		action.waitForPageLoad();
		Thread.sleep(2000);
		
		while(true)
		{
			try
			{
				myElement1 = (WebElement)executeJavaScriptWithoutWait("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
				action.highligthElement(myElement1);
				myElement1.click();
		    	Thread.sleep(2000);
			}
			catch (Throwable e) 
			{
				break;
			}
		}

		Thread.sleep(3000);
		
		while(true)
		{
			try 
			{
				myElement1 = (WebElement)executeJavaScriptWithoutWait(
						"return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
				action.highligthElement(myElement1);
				myElement1.click();
				Thread.sleep(2000);
			}
			catch(Throwable e) 
			{
				break;
			}
		}
		//myElement = findElementByDynamicXpath("//brml-tab-button[@tab=\"Draft\"]");
		myElement = (WebElement)executeJavaScript("return document.querySelector(\"#wftabs > brml-tab-button[tab='Draft']\")");
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("Draft tab is cicked");  
		action.waitForPageLoad();
		Thread.sleep(3000);
	}
	
	
	public void checkHeader(String headerName) throws Throwable
	{
		action.waitForPageLoad();

    	myElement = findElementByDynamicXpathWithRefresh("//h4[contains(text(),'"+headerName+"')] | //h3[contains(text(),'"+headerName+"')]");
    	System.out.println(myElement.getText());

    	sftAst.assertEquals(myElement.getText(), headerName,headerName+" header is displayed");
		Reporter.addStepLog(headerName+" header is displayed");
	}
	
	public void viewDetailsOfNewDraft(String strArg1) throws Throwable
	{
    	try
    	{
			scroll_to_bottom();

			  myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='draftName']\")");  
			   for (int i = 1; i < myElements.size(); i++)
			   {
				   System.out.println(myElements.get(i).getText()+" "+draftName);
					if(myElements.get(i).getText().equalsIgnoreCase(draftName)) 
					{
					   	myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[col-id='draftName']\")["+i+"]");
					   	myElement.click();
					   	myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[col-id='draftName']\")["+i+"].parentElement.querySelector(\"brml-action-menu\")");
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						Thread.sleep(2000);
						myElement.click();
						Reporter.addStepLog("clicking on ellipsis icon");
					   
						myElements =getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='draftName']\")["+i+"].parentElement.querySelector(\"brml-action-menu\").shadowRoot.querySelectorAll(\"button > span\")");
						if(strArg1.equalsIgnoreCase("ViewEdit"))
						{
							action.highligthElement(myElements.get(0));
							Thread.sleep(2000);
							myElements.get(0).click();
							Reporter.addStepLog("Cicking on the View/Edit option");
						}
						
						else if(strArg1.equalsIgnoreCase("Delete"))
						{
							action.scrollToElement(myElements.get(1));
							action.highligthElement(myElements.get(1));
							Thread.sleep(2000);
							myElements.get(1).click();
							
							Reporter.addStepLog("Cicking on the View/Edit option");
						}
						Thread.sleep(5000);
						break;
					}
			   }
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access the View/Edit option");
    	}
    
	}
	
	
	public void editInputFields(String entity, String scenario, List<List<String>> attribute) throws Throwable
	{
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++)
		{
//			try
//			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				
				if(attribute.get(i).get(0).equalsIgnoreCase("Entity Name") || attribute.get(i).get(0).equalsIgnoreCase("Benchmark Code") )
				{
					myValue = myValue + timeStamp;
					draftName = myValue;
				}
				
				if(attribute.get(i).get(0).equalsIgnoreCase("Large Trader ID") ||attribute.get(i).get(0).equalsIgnoreCase("Document Link") )
				{
					myValue = myValue + timeStamp;
				}
				
				if(attribute.get(i).get(0).equalsIgnoreCase("DTCC ID") )
				{
					myValue = generateCode("ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890", 4);
				}			
				
				if(attribute.get(i).get(0).equalsIgnoreCase("FA Email"))
				{
					myValue = new SimpleDateFormat("ddMMyyyyHHmm").format(new Date()) + myValue;
				}
				
				waitForJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");

				if(myElement.isEnabled())
				{
				   action.scrollToElement(myElement);
				   action.highligthElement(myElement);
				   //action.clear(myElement);
				   myClear(myElement);
				   System.out.println(myValue);
				   
				   if(attribute.get(i).get(0).contentEquals("Phone Number")) 
					   myElement.sendKeys(myValue);
				   else 
					   sendKeysWithCheck(myElement, myValue);
				   
				   InputValues.put(attribute.get(i).get(0),myValue);
				   InputValuesId.put(attribute.get(i).get(1),myValue);

				   Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));
				}
				else
				{
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					myValue = myElement.getAttribute("value");
					InputValues.put(attribute.get(i).get(0),myValue);
					InputValuesId.put(attribute.get(i).get(1),myValue);
					Reporter.addStepLog(attribute.get(i).get(0)+" "+myValue);
				}
//			}
//			catch (Exception e)
//			{
//				Assert.fail("Unable to access "+attribute.get(i).get(0) );
//			}
		}
	}
	
	public void verifyDBValues() throws Throwable
	{
		Thread.sleep(5000);
		pmdb.DBConnectionStart();
		Reporter.addStepLog("Connected to DB");
		System.out.println(draftName);
		String	 completeSqlQuery = "select * from draft_entity where draft_name = '"+draftName+"'";
		Reporter.addStepLog("Executing the SQL Query "+completeSqlQuery);
		//String	 completeSqlQuery = "select * from draft_entity where draft_name = 'SaveAsDraft_Rgow17-01-2022(13:51)'";

		ResultSet allResult = DBManager.executeSelectQuery(completeSqlQuery);
		while (allResult.next()) 
		{
			String status = allResult.getString("user_text");
			System.out.println(status);
			
			JSONObject jsonObject = new JSONObject(status);
			
			//Pattern pat = Pattern.compile("\"[a-zA-Z0-9]*?\":\\[?\\{");
			Pattern pat = Pattern.compile("\"[a-zA-Z0-9]*?\":\\[?[{\\[]");

	
			Matcher mat = pat.matcher(jsonObject.toString());
			myValue = mat.replaceAll("");
			System.out.println(myValue);
			
			 //pat = Pattern.compile("[{}\\]\"]");
			 pat = Pattern.compile("[{}\\[\\]\"]");

			 mat = pat.matcher(myValue);
			 
				myValue = mat.replaceAll("");
				System.out.println(myValue);
				
				myValue = myValue + ",";
				
				/* ------------------------------------*/
				pat = Pattern.compile("(,[\\S\\s&&[^:]]+?),");

				 mat = pat.matcher(myValue);
				 
				 while(mat.find())
				 {					 
					myValue = mat.replaceFirst(",");
					 mat = pat.matcher(myValue);

				 }
				 
				System.out.println(myValue);
				
				pat = Pattern.compile(",,");

				 mat = pat.matcher(myValue);
				 
				 while(mat.find())
				 {					 
					myValue = mat.replaceFirst(",");
					 mat = pat.matcher(myValue);

				 }
				 
				System.out.println(myValue);
				
				String str[] = myValue.split(",");
				for(String i:str)
				{
					String str1[] = i.split(":",2);
					System.out.println(str1[0] + str1[1]);
					DataBaseValues.put(str1[0], str1[1]);
				}
			
			}
		
		InputValuesId.putAll(DropDownValuesId);
		
		for (String dataKey : InputValuesId.keySet())
		{
				myValue = InputValuesId.get(dataKey);
				myValue1 = DataBaseValues.get(dataKey);
				System.out.println("UI Value :"+myValue+" Database value :"+myValue1);
				sftAst.assertEquals(myValue, myValue1);
				Reporter.addStepLog("UI Value :"+myValue+" Database value :"+myValue1);
				Thread.sleep(1000);
			
		}
	}
	
	public void editDropDownFields(String entity,String scenario, List<List<String>> attribute) throws Throwable
	{
		/*action.waitForPageLoad();		
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				waitForJavaScript("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");

				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				if(myElement.isEnabled())
				{
				action.scrollToElement(myElement);
				action.click(myElement);
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
				
				myElements = getDynamicElementsFromShadowRoot("return document.querySelector('brml-select[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelectorAll('li')");
				
				for(WebElement E : myElements) 
				{
					System.out.println(E.getText());
					if(E.getText().equalsIgnoreCase(myValue))
					{
						myElement = E;
						break;
					}
				}
				
				System.out.println(myElement.getText());
								
				DropDownValues.put(attribute.get(i).get(0),myElement.getText());
				DropDownValuesId.put(attribute.get(i).get(1),myElement.getText());

				action.scrollToElement(myElement);
				Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

				action.click(myElement);
				
				}
				  
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}*/
		

		/*action.waitForPageLoad();		
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				waitForJavaScript("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				myElement = (WebElement)executeJavaScriptWithoutWait("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]')");
				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");
				if(!Boolean.parseBoolean(myValue))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
					
					action.scrollToElement(myElement);
					action.click(myElement);
					Thread.sleep(1000);
					
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
					myElements = getDynamicElementsFromShadowRoot("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelectorAll('li')");
					
					for(WebElement E: myElements) 
					{
						if(E.getText().equalsIgnoreCase(myValue)) 
						{
							myElement = E;
							break;
						}
					}
					DropDownValues.put(attribute.get(i).get(0), myElement.getText());
					DropDownValuesId.put(attribute.get(i).get(1), myElement.getText());
					action.scrollToElement(myElement);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
					action.click(myElement);
				} 
				else
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("value");
					myValue = (String)executeJavaScript("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')");
					myValue = myValue.replaceAll("-\\d{4}$", "");
					DropDownValues.put(attribute.get(i).get(0),myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				}
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}*/
		

		action.waitForPageLoad();		
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				waitForJavaScript("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");

				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");

				if(!Boolean.parseBoolean(myValue))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
					
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					action.click(myElement);
					Thread.sleep(500);
					
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
					myElements = getDynamicElementsFromShadowRoot("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelectorAll('li')");
					
					for(WebElement E: myElements) 
					{
						if(E.getText().equalsIgnoreCase(myValue)) 
						{
							myElement = E;
							break;
						}
					}
					System.out.println(myValue);
					DropDownValues.put(attribute.get(i).get(0), myElement.getText());
					DropDownValuesId.put(attribute.get(i).get(1), myElement.getText());
					action.scrollToElement(myElement);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
					action.click(myElement);
				} 
				else
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);

					myValue = myElement.getAttribute("value");

					if(isPresent("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')"))
					{
						myValue = (String)executeJavaScript("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')");
						myValue = myValue.replaceAll("-\\d{4}$", "");
					}					
					DropDownValues.put(attribute.get(i).get(0),myValue);
					DropDownValuesId.put(attribute.get(i).get(1), myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				}
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}		
    }
	
	public void editTextFields(String entity, String scenario, List<List<String>> attribute) throws Throwable
	{
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				
				if(attribute.get(i).get(0).contentEquals("Comment Description")
						|| attribute.get(i).get(0).contentEquals("Document Description")
						|| attribute.get(i).get(0).contentEquals("Special Instructions (Please provide links)"))
				{
					myValue = myValue + timeStamp;
					System.out.println(myValue);
				}
				
				waitForJavaScript("return document.querySelector('brml-textarea[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('textarea')");
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-textarea[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('textarea')");

				if(myElement.isEnabled())
				{
				   action.scrollToElement(myElement);
				   action.clear(myElement);
				   sendKeysWithCheck(myElement, myValue);
				   InputValues.put(attribute.get(i).get(0),myValue);
				   InputValuesId.put(attribute.get(i).get(1),myValue);

				   Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));
				}
				else
				{
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("value");
					InputValues.put(attribute.get(i).get(0),myValue);
					InputValuesId.put(attribute.get(i).get(1),myValue);
					Reporter.addStepLog(attribute.get(i).get(0)+" "+myValue);
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
    }
	
	public void editDateFields(String entity, List<List<String>> attribute) throws Throwable
	{
    	for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-calendar-picker[id=\""+attribute.get(i).get(1)+"\"]')");
				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('brml-calendar-picker[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");

				if(!Boolean.parseBoolean(myValue))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-calendar-picker[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
					myElement.click();
					sendKeysWithCheck(myElement, new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
					
					action.scrollToElement(myElement);
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-calendar-picker[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector(\"div.pmu-days > div.pmu-today.pmu-button\")");
					myElement.click();
					InputValues.put(attribute.get(i).get(0), new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
					InputValuesId.put(attribute.get(i).get(1), new SimpleDateFormat("MM/dd/yyyy").format(new Date()));
				}
				else 
				{
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("date");
					InputValues.put(attribute.get(i).get(0),myValue);
					InputValuesId.put(attribute.get(i).get(1),myValue);
					Reporter.addStepLog(attribute.get(i).get(0)+" "+myValue);
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}    
	}
	
	public void editRadioButton(String entity, String scenario,List<List<String>> attribute) throws Throwable
	{
		action.waitForPageLoad();
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
		for (int i = 0; i < attribute.size(); i++)
		{
//			try
//			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				myValue1 = (String)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"').getAttribute('disabled')");
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#"+attribute.get(i).get(1)+"\")");
				//myElement = findElementByDynamicXpath("//brml-radio[@id='"+attribute.get(i).get(1)+"']");
				action.highligthElement(myElement);
				action.scrollToElement(myElement);
				if(myValue1.contentEquals("false"))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector(\"#"+attribute.get(i).get(1)+" > brml-radio-option[label='"+myValue+"']\")");
					myElement.click();
					InputValues.put(attribute.get(i).get(0), myValue);
				}
				else
				{
					myValue = myElement.getAttribute("value");
					if(!myValue.isEmpty())
					{
						myElement = (WebElement)executeJavaScript("return document.querySelector(\"#"+attribute.get(i).get(1)+" > brml-radio-option[value='"+myValue+"']\") "
								+ "|| document.querySelector(\"#"+attribute.get(i).get(1)+" > brml-radio-option[checked='true']\")");
						myValue = myElement.getAttribute("label");
					}
//					myElement = (WebElement)executeJavaScript("return document.querySelector(\"#"+attribute.get(i).get(1)+" > brml-radio-option[value='"+myValue1+"']\") "
//							+ "|| document.querySelector(\"#"+attribute.get(i).get(1)+" > brml-radio-option[checked='true']\")");
//					System.out.println("return document.querySelector(\"#"+attribute.get(i).get(1)+" > brml-radio-option[value='"+myValue1+"']\") "
//							+ "|| document.querySelector(\"#"+attribute.get(i).get(1)+" > brml-radio-option[checked='true']\")");
					//myValue = (String)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+" > brml-radio-option[checked=\"true\"]').getAttribute('label')");
					InputValues.put(attribute.get(i).get(0), myValue);
				}
				System.out.println(attribute.get(i).get(0)+" "+ myValue);
				Reporter.addStepLog(attribute.get(i).get(0)+" "+ myValue);
//			}
//			catch (Exception e)
//			{
//				Assert.fail("Unable to access "+attribute.get(i).get(0) );
//			}
		}
	}
	
	public void editCheckBox(String entity,String scenario, List<List<String>> attribute) throws Throwable
	{
    	/*sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
    	for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myElement = (WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"')");
				myValue1 = (String)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"').getAttribute('checked')");
				myValue = (String)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"').getAttribute('disabled')");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				
				if(myValue.contentEquals("false"))
				{
					myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
					if(!(myValue.equalsIgnoreCase(myValue1))) 
					{
						myElement.click();
						if(myValue.equalsIgnoreCase("true"))
						{
							InputValues.put(attribute.get(i).get(0), "Yes");
							InputValuesId.put(attribute.get(i).get(1), "Yes");
						}
						if(myValue.equalsIgnoreCase("false"))
						{
							InputValues.put(attribute.get(i).get(0), "No");
							InputValuesId.put(attribute.get(i).get(1), "No");
						}
					}
					else
					{
						if(myValue.equalsIgnoreCase("true"))
						{
							InputValues.put(attribute.get(i).get(0), "Yes");
							InputValuesId.put(attribute.get(i).get(1), "Yes");
						}
						if(myValue.equalsIgnoreCase("false"))
						{
							InputValues.put(attribute.get(i).get(0), "No");
							InputValuesId.put(attribute.get(i).get(1), "No");
						}
					}
				}
				else
				{
					if(myValue1.equalsIgnoreCase("true"))
					{
						InputValues.put(attribute.get(i).get(0), "Yes");
						InputValuesId.put(attribute.get(i).get(1), "Yes");
					}
					if(myValue1.equalsIgnoreCase("false"))
					{
						InputValues.put(attribute.get(i).get(0), "No");
						InputValuesId.put(attribute.get(i).get(1), "No");
					}
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}*/
		

    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
    	for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				myElement = (WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"')");
				myValue1 = (String)executeJavaScriptWithoutWait("return document.querySelector('#"+attribute.get(i).get(1)+"').getAttribute('checked')");
				
				if(myElement.isEnabled())
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('#"+attribute.get(i).get(1)+"')");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					
					if(myValue1 == null)
					{
						if(myValue.equalsIgnoreCase("true"))
						{
							myElement.click();
							System.out.println(attribute.get(i).get(0)+" "+"yes");
							InputValues.put(attribute.get(i).get(0), "Yes");
						}
						if(myValue.equalsIgnoreCase("false"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"no");
							InputValues.put(attribute.get(i).get(0), "No");
						}
					}
					else if(!myValue.equalsIgnoreCase(myValue1)) 
					{
						myElement.click();
						if(myValue.equalsIgnoreCase("true"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"yes");
							InputValues.put(attribute.get(i).get(0), "Yes");
						}
						if(myValue.equalsIgnoreCase("false"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"no");
							InputValues.put(attribute.get(i).get(0), "No");
						}
					}
					else
					{
						if(myValue.equalsIgnoreCase("true"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"yes");
							InputValues.put(attribute.get(i).get(0), "Yes");
						}
						if(myValue.equalsIgnoreCase("false"))
						{
							System.out.println(attribute.get(i).get(0)+" "+"no");
							InputValues.put(attribute.get(i).get(0), "No");
						}
					}
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}    
	}
	
	public void storeBenchmarkDetails(List<Map<String,String>> attribute) throws Throwable
    {		
		BenchmarkValues.clear();
		
			for(int i = 0; i < attribute.size(); i++)
			{
				if(attribute.get(i).get("Dropdown Name").contains("Custom Benchmark BM")) 
				{
//					if(((String)executeJavaScript("return document.querySelectorAll(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option\")[0].shadowRoot.querySelector(\"button\").getAttribute('class')")).contentEquals("checked"))
					if(((String)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1\").getAttribute('value')")).contentEquals("style"))
					{
						selectBenchmarkType("Style");
						continue;
					}
				}
				int j=0;
					myElements = findElementsByDynamicXpath("//brml-select[contains(@id,'"+attribute.get(i).get("Dropdown ID")+"')]");
					for(WebElement E : myElements )
					{
						myValue = E.getAttribute("value");
						myElement = findElementByDynamicXpath("(//brml-select-option[@value='"+myValue+"'])[1]");
						myValue = myElement.getAttribute("name");
						//myValue = myValue.replaceAll(".+?-\\s|-\\d{4}$","");
						myValue = myValue.replaceAll("^.+?-\\s|-\\d{4}$","");

						double percentage = Double.parseDouble((String)findElementByDynamicXpath("//brml-stepper-input[@id='"+attribute.get(i).get("Percentage ID")+j+"']").getAttribute("value"));
						BenchmarkValues.put(myValue, percentage);
						j++;
					}
					
					BenchmarkDetails.put(attribute.get(i).get("Dropdown Name"), addValues1(BenchmarkDetails, attribute.get(i).get("Dropdown Name"), BenchmarkValues));
					BenchmarkValues.clear();
			}
			if(isPresent("return document.querySelector('brml-textarea[id=\"txtCustomReasonSet1\"]').shadowRoot.querySelector('textarea')"))
			{
				 myElement = (WebElement)executeJavaScript("return document.querySelector('brml-textarea[id=\"txtCustomReasonSet1\"]').shadowRoot.querySelector('textarea')");
				 myValue = myElement.getAttribute("value");
				 InputValues.put("Custom BM Reason",myValue);
				 InputValuesId.put("Custom BM Reason",myValue);
				 System.out.println("Custom BM Reason "+myValue);
				 Reporter.addStepLog("Custom BM Reason "+myValue); 
			}
		//sftAst.assertAll();
			System.out.println(BenchmarkDetails);
    }
	
	public void storeProxyDetails(List<List<String>> attribute) throws Throwable
	{
		ProxyValues.clear();
		
		for(int j = 0; j < proxyDetails.length; j++) 
		{
			for(int i = 0; i < attribute.size(); i++) 
			{
				myElement = findElementByDynamicXpath("(//*[@id='" + attribute.get(i).get(1) + "'])[" + (j + 1) + "]");
				myValue = myElement.getAttribute("value");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				Thread.sleep(200);
				ProxyValues.put(attribute.get(i).get(0), myValue);
			}
			ProxyDetails.put(proxyDetails[j], addValuesString(ProxyDetails, proxyDetails[j], ProxyValues));
			ProxyValues.clear();
		}
		System.out.println(ProxyDetails);
	}
	
	public void storeDocumentsDetails() throws Throwable
	{
		ProxyValues.clear();
		DocumentDetails.clear();
		waitForJavaScript("return document.querySelector(\"tr\")");
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"tr\")");
		for(int j = 1; j < myElements.size(); j++) 
		{
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('td')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('td').textContent");
			ProxyValues.put("Document Type", myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('brml-button')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('brml-button').textContent");
			ProxyValues.put("Document Link", myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelectorAll('brml-button')[1]"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelectorAll('brml-button')[1].textContent");
			ProxyValues.put("Document Description", myValue);
			DocumentDetails.put("Document"+j, addValuesString(ProxyDetails, "Document"+j, ProxyValues));
			ProxyValues.clear();
		}
		System.out.println(DocumentDetails);
	}
	
	public void storeCommentsDetails() throws Throwable
	{
		ProxyValues.clear();
		CommentDetails.clear();
		waitForJavaScript("return document.querySelector(\"tr\")");
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"tr\")");
		for(int j = 1; j < myElements.size(); j++) 
		{
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('td')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelector('td').textContent");
			ProxyValues.put("Comment Type", myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelectorAll('td')[1]"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+j+"].querySelectorAll('td')[1].textContent");
			ProxyValues.put("Comment Description", myValue);
			CommentDetails.put("Comment"+j, addValuesString(ProxyDetails, "Comment"+j, ProxyValues));
			ProxyValues.clear();
		}
		System.out.println(CommentDetails);
	}
	
	public void checkInputEdits() throws Throwable
	{
		InputValues.remove("Document Description");InputValues.remove("Document Link");InputValues.remove("Comment Description");InputValues.remove("Entity Name");InputValues.remove("FA Selection");InputValues.remove("HO Comments");
		InputValues.remove("4 Eye Check Override");
		System.out.println(Arrays.asList(InputValues));
		for (Map.Entry<String, String> data : InputValues.entrySet())
		{				
			if (!data.getKey().contentEquals("Custom BM Reason"))
			{
				myValue = data.getValue();
				myElements = findElementsByDynamicXpath("//*[contains(text(),'"+data.getKey()+"')]//following::div[1]");
				
				if(myElements.size()>1) 
				{
					myElements = findElementsByDynamicXpath("//*[text()='"+data.getKey()+"']//following::div[1]");
				}
				
				for(WebElement E : myElements)
				{
					if(data.getKey().equalsIgnoreCase("FA ID(s)") || data.getKey().equalsIgnoreCase("Universal ID(s)")) 
					{
						for(String str :  E.getText().split(", ") )
						{
							System.out.println(data.getKey() + " Stored Value: " + myValue + " Displayed Value: " + str);
							sftAst.assertTrue(data.getValue().contains(str), data.getKey());
							action.scrollToElement(E);
							action.highligthElement(E);
							Reporter.addStepLog(data.getKey() + " Stored Value: " + myValue + " Displayed Value: " + str);
							Thread.sleep(200);
						}
						break;
					}
					
					if(data.getValue() == null || data.getValue().isEmpty()) 
					{
						myValue = "—";
					}
					System.out.println(data.getKey()+" Stored Value: "+myValue+" Displayed Value: "+E.getText());	
					sftAst.assertEquals(E.getText(),myValue);
					action.scrollToElement(E);
					action.highligthElement(E);
					Reporter.addStepLog(data.getKey()+" Stored Value: "+myValue+" Displayed Value: "+E.getText());
					Thread.sleep(200);
					break;
				}
			}
		}
	}
	
	public void checkBenchmarkEdits(HashMap<String ,HashMap<String,Double>> Map, String entity) throws Throwable
	{
		System.out.println(Arrays.asList(Map));
		Map.putAll(BenchmarkDetails);
		for(Map.Entry<String, HashMap<String, Double>> data: Map.entrySet())
		{
			int i = 1;
			if(!data.getValue().isEmpty() && (data.getKey().equalsIgnoreCase("Custom Benchmark BM"))) 
			{
				for(Map.Entry<String, Double> list: data.getValue().entrySet())
				{
					myElement = findElementByDynamicXpath("//div[contains(@class,'col-4 mb6')][" + i+ "] | //div[contains(@class,'col-6 mb6')][" + i + "]");
					myValue = myElement.getText();
					myElement1 = findElementByDynamicXpath("//div[contains(@class,'col-4 mb6')][" + (i + 1)+ "] | //div[contains(@class,'col-6 mb6')][" + (i + 1) + "] | //div[contains(@class,'col-4 text-left')]["+i+"]");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					System.out.println("Stored Benchmark: "+list.getKey()+"-"+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"-"+myElement1.getText());
					sftAst.assertEquals(myValue+"-"+myElement1.getText(), list.getKey()+"-"+format.format(list.getValue())+"%");
					Reporter.addStepLog("Stored Benchmark: "+list.getKey()+"-"+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"-"+myElement1.getText());
					Reporter.addStepLog("Stored Benchmark: " + list.getKey() + "-" + format.format(list.getValue())+ "% Displayed Benchmark: " + myValue + "-" + myElement1.getText());
					i += 2;
					Thread.sleep(500);
				}
			}
			else if(!data.getValue().isEmpty() && (data.getKey().equalsIgnoreCase("UnBundled Node ID BM")))
			{
				for(Map.Entry<String, Double> list: data.getValue().entrySet()) 
				{
					if(entity.equalsIgnoreCase("Style")) 
						myElements = findElementsByDynamicXpath("(//div[@class='col-2'][3]//div)[1]//div[" + i + "]");
					else
						myElements = findElementsByDynamicXpath("//div[contains(@class,'body-3 mb6')][" + i + "]");

					if(myElements.size() > 1)
					{
						myElement = myElements.get(1);
					}
					else 
					{
						myElement = myElements.get(0);
					}
					myValue = myElement.getText();
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					System.out.println("Stored Benchmark: "+list.getKey().replaceAll("-\\d{4}$", "")+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
					if(entity.contentEquals("Style"))
						sftAst.assertEquals(myValue, list.getKey()+" - "+format.format(list.getValue())+"%");
					else 
						sftAst.assertEquals(myValue, list.getKey()+" - "+format.format(list.getValue())+".00%");
					Reporter.addStepLog("Stored Benchmark: "+list.getKey().replaceAll("-\\d{4}$", "")+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
					i++;
					Thread.sleep(500);
				}
			}
			else if (!data.getValue().isEmpty() && (data.getKey().equalsIgnoreCase("Bundled Node ID BM")))
			{
				
				for (Map.Entry<String, Double> list : data.getValue().entrySet())
				{				
					if(entity.equalsIgnoreCase("Style")) 
						myElement = findElementByDynamicXpath("(//div[@class='col-2'][2]//div)[1]//div[1]");
					else
						myElement = findElementByDynamicXpath("//div[contains(@class,'body-3 mb6')]");

					myValue = myElement.getText();
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					Thread.sleep(500);
					
					System.out.println("Stored Benchmark: "+list.getKey().replaceAll("-\\d{4}$", "")+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
					if(entity.contentEquals("Style"))
						sftAst.assertEquals(myValue, list.getKey()+" - "+format.format(list.getValue())+"%");
					else 
						sftAst.assertEquals(myValue, list.getKey()+" - "+format.format(list.getValue())+".00%");
					Reporter.addStepLog("Stored Benchmark: "+list.getKey().replaceAll("-\\d{4}$", "")+" - "+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"");
					i++;
				}		
			}
			else if (!data.getValue().isEmpty() && (data.getKey().equalsIgnoreCase("Style")))
			{			
				for (Map.Entry<String, Double> list : data.getValue().entrySet())
				{
					myElement = findElementByDynamicXpath("//div[contains(@class,'col-4 mb6')]["+i+"] | //div[contains(@class,'col-6 mb6')]["+i+"]");
					myValue = myElement.getText();
					myElement1 = findElementByDynamicXpath("//div[contains(@class,'col-4 text-left body-3')]["+i+"]");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					System.out.println("Stored Benchmark: "+list.getKey()+"-"+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"-"+myElement1.getText());
					sftAst.assertEquals(myValue+"-"+myElement1.getText(), list.getKey()+"-"+format.format(list.getValue())+"%");
					Reporter.addStepLog("Stored Benchmark: "+list.getKey()+"-"+format.format(list.getValue())+"% Displayed Benchmark: "+myValue+"-"+myElement1.getText());
					Reporter.addStepLog("Stored Benchmark: " + list.getKey() + "-" + format.format(list.getValue())+ "% Displayed Benchmark: " + myValue + "-" + myElement1.getText());
					i++;
					Thread.sleep(500);
				}		
			}
		}
		
		if(InputValues.containsKey("Custom BM Reason"))
		{
			myElement = findElementByDynamicXpath(
					"//div[contains(@class,'col-2 text-left')]//span | //div[contains(@class,'col-2 text-left')]");
			myValue = myElement.getText();
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			System.out.println("Custom BM Reason Stored Value: " + InputValues.get("Custom BM Reason")
					+ " Displayed Value: " + myValue);
			sftAst.assertEquals(myValue, InputValues.get("Custom BM Reason"));
			Reporter.addStepLog("Custom BM Reason Stored Value: " + InputValues.get("Custom BM Reason")
					+ " Displayed Value: " + myValue);
		}
		//sftAst.assertAll();
	}
	
	public void checkNonCustomBenchmarkEdits(String entity) throws Throwable
	{
		System.out.println(Arrays.asList(BenchmarkDetails));
		
		if(entity.equalsIgnoreCase("MutualFund") || entity.equalsIgnoreCase("ETF")) 
		{
			for (Map.Entry<String, HashMap<String, Double>> data : BenchmarkDetails.entrySet())
			{
				int i =1;
				if (!data.getValue().isEmpty())
				{				
					for (Map.Entry<String, Double> list : data.getValue().entrySet())
					{
						myElement = findElementByDynamicXpath("//*[contains(text(),'Benchmark')]//parent::div//label[contains(text(),'"+data.getKey()+"')]//parent::div//following-sibling::div["+i+"]");
						
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						System.out.println("Stored Benchmark: "+list.getKey()+"-"+format.format(list.getValue())+"% Displayed Benchmark: "+myElement.getText());
						sftAst.assertEquals(myElement.getText(), list.getKey()+"-"+format.format(list.getValue())+"%");
						Reporter.addStepLog("Stored Benchmark: "+list.getKey()+"-"+format.format(list.getValue())+"% Displayed Benchmark: "+myElement.getText());
						i++;
						Thread.sleep(500);
					}
				}
			}
		}
	}
	
	public void updateInputFields(String entity, String scenario, List<List<String>> attribute) throws Throwable
	{
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);

		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+"Update_"+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				
				if(attribute.get(i).get(0).equalsIgnoreCase("Entity Name") || attribute.get(i).get(0).equalsIgnoreCase("Benchmark Code") )
				{
					myValue = myValue + timeStamp;
				}
				
				if(attribute.get(i).get(0).equalsIgnoreCase("FA Email"))
				{
					myValue = new SimpleDateFormat("dd-MM-yyyyHHmm").format(new Date()) + myValue;
				}
				
				myElement = (WebElement) executeJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");

				if(myElement.isEnabled())
				{
				   action.scrollToElement(myElement);
				   myClear(myElement);
				   System.out.println(myValue);
				   
				   if(attribute.get(i).get(0).contentEquals("Phone Number")) 
					   myElement.sendKeys(myValue);
				   else 
					   sendKeysWithCheck(myElement, myValue);
				   
				   InputValues.replace(attribute.get(i).get(0),myValue);
				   InputValuesId.replace(attribute.get(i).get(1),myValue);

				   Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));
				}
				else
				{
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("value");
					InputValues.replace(attribute.get(i).get(0),myValue);
					InputValuesId.replace(attribute.get(i).get(1),myValue);
					Reporter.addStepLog(attribute.get(i).get(0)+" "+myValue);
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}   
	}
	
	public void updateDropdownFields(String entity, List<List<String>> attribute) throws Throwable
	{
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				waitForJavaScript("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				
				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");
				if(!Boolean.parseBoolean(myValue))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
					
					action.scrollToElement(myElement);
					action.click(myElement);
					Thread.sleep(500);
					
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+"Update_"+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
					myElements = getDynamicElementsFromShadowRoot("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelectorAll('li')");
					
					for(WebElement E: myElements) 
					{
						if(E.getText().equalsIgnoreCase(myValue)) 
						{
							myElement = E;
							break;
						}
					}
					DropDownValues.replace(attribute.get(i).get(0), myElement.getText());
					DropDownValuesId.replace(attribute.get(i).get(1), myElement.getText());
					action.scrollToElement(myElement);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
					action.click(myElement);
				} 
				else
				{

					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);

					myValue = myElement.getAttribute("value");

					if(isPresent("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')"))
					{
						myValue = myValue.replaceAll("-\\d{4}$", "");
					}					
					
					DropDownValues.replace(attribute.get(i).get(0),myValue);
					DropDownValuesId.replace(attribute.get(i).get(1), myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				}
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		} 
	}
	
	public void updateDropdownFieldsByIndex(String entity, List<List<String>> attribute) throws Throwable
	{
    /*	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				if(myElement.isEnabled())
				{
				action.scrollToElement(myElement);
				action.click(myElement);
				Thread.sleep(2000);
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Update_Data_"+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
								
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
						+attribute.get(i).get(1)+ "\"]').shadowRoot.querySelector(\"li[data-value='" + myValue + "']\")");
				
				System.out.println(myElement.getText());
								
				DropDownValues.replace(attribute.get(i).get(0),myElement.getText());
				DropDownValuesId.replace(attribute.get(i).get(1),myElement.getText());

				action.scrollToElement(myElement);
				Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

				action.click(myElement);
				Thread.sleep(2000);		
				}
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}*/
		

    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				waitForJavaScript("return document.querySelector('brml-select[id=\""+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				
				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");
				if(!Boolean.parseBoolean(myValue))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
					
					action.scrollToElement(myElement);
					action.click(myElement);
					Thread.sleep(500);
					
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+"Update_"+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));		
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+attribute.get(i).get(1)+ "\"]').shadowRoot.querySelector(\"li[data-value='" + myValue + "']\")");
					
					System.out.println(myElement.getText());
									
					DropDownValues.replace(attribute.get(i).get(0),myElement.getText());
					DropDownValuesId.replace(attribute.get(i).get(1),myElement.getText());

					action.scrollToElement(myElement);
					Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

					action.click(myElement);
				} 
				else
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					action.scrollToElement(myElement);
					myValue = myElement.getAttribute("value");
					if(isPresent("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')"))
					{
						myValue = (String)executeJavaScript("return document.querySelector(\"#"+ attribute.get(i).get(1) +" > brml-select-option[value='"+myValue+"']\").getAttribute('name')");
						myValue = myValue.replaceAll("-\\d{4}$", "");
					}					
					DropDownValues.put(attribute.get(i).get(0),myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				}
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		} 
	
	}
	
	public void updateTextFields(String entity, List<List<String>> attribute) throws Throwable
	{
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+"Update_"+UIEnvironment);
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				
				if(attribute.get(i).get(0).contentEquals("Comment Description")
						|| attribute.get(i).get(0).contentEquals("Document Description")
						|| attribute.get(i).get(0).contentEquals("Special Instructions (Please provide links)"))
				{
					myValue = myValue + timeStamp;
					System.out.println(myValue);
				}
				
				waitForJavaScript("return document.querySelector('brml-textarea[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('textarea')");
				myElement = (WebElement)executeJavaScript("return document.querySelector('brml-textarea[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('textarea')");

				if(myElement.isEnabled())
				{
				   action.scrollToElement(myElement);
				   //action.clear(myElement);
				   myClear(myElement);
				   sendKeysWithCheck(myElement, myValue);
				   InputValues.replace(attribute.get(i).get(0),myValue);
				   InputValuesId.replace(attribute.get(i).get(1),myValue);

				   Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));
				}
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public Map<String, Double> sortTheCollectionInt(Map<String, Double> unsortMap, final boolean order) throws Throwable
	{
		List<Entry<String, Double>> list = new LinkedList<Entry<String,Double>>(unsortMap.entrySet());
		
		Collections.sort(list, new Comparator<Entry<String,Double>>() 
		{
			public int compare(Entry<String,Double> o1,Entry<String,Double> o2)	
			{
				if(order) 
				{
					return o1.getValue().compareTo(o2.getValue());
				}
				else
				{
					return o2.getValue().compareTo(o1.getValue());
				}
			}
		});
	
		Map<String, Double> sortedMap = new LinkedHashMap<String, Double>();
		for(Entry<String,Double> entry : list)
		{
			sortedMap.put(entry.getKey(),entry.getValue());
		}
		return sortedMap;
	}	
	
	public HashMap<String, Double> addValues1(HashMap<String ,HashMap<String,Double>> haspMap, String key,HashMap<String,Double> value) throws Throwable 
	{
		HashMap<String, Double> tempList = null;
		if(haspMap.containsKey(key)) 
		{
			tempList = haspMap.get(key);
			if(tempList == null)
				tempList = new HashMap<String, Double>();
			//			tempList.putAll(valueCopy);
			tempList.putAll(value);
		}
		else 
		{
			tempList = new HashMap<String, Double>();
			//			tempList.putAll(valueCopy);
			tempList.putAll(value);
		}
		//haspMap.put(key,tempList);
		tempList = (HashMap<String, Double>)sortTheCollectionInt(tempList, false);
		return tempList;
	}
	
	public void saveDraftSecond() throws Throwable
	{
		try
    	{			
			myElement = (WebElement) action.executeJavaScript("return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");
			action.jsClick(myElement);
			
			Thread.sleep(2000);
			Alert alt = WebDriverManager.getDriver().switchTo().alert();
			String actualmsg = alt.getText();	
			System.out.println(actualmsg);
			alt.accept();
			Thread.sleep(5000);
			Reporter.addStepLog("The draft name is entered");

    	}
    	catch (Exception e)
    	{
			Assert.fail("Unable to save the Draft" );
			
		}
	}
	
	public void checkDropdownEdits() throws Throwable
	{
		/*System.out.println(Arrays.asList(DropDownValues));
		Thread.sleep(500);
		Reporter.addScreenCapture();
		for(Map.Entry<String, String> data: DropDownValues.entrySet()) {
			if(data.getKey().equalsIgnoreCase("Document Type")) {}
			//			else if (!data.getKey().isEmpty())
			else if(!data.getValue().isEmpty()) {
				myValue = data.getValue();
				System.out.println(myValue);
				myElements = findElementsByDynamicXpath("//*[contains(text(),'" + myValue + "')]");
				for(WebElement E: myElements) {
					sftAst.assertTrue(E.isDisplayed(), " " + myValue + "is displayed");
					action.scrollToElement(E);
					action.highligthElement(E);
					Reporter.addStepLog(myValue + " is displayed for " + data.getKey());
					Thread.sleep(500);
				}
			}
		}*/
		DropDownValues.remove("Comment Type");DropDownValues.remove("Document Type");
		System.out.println(Arrays.asList(DropDownValues));
		for (Map.Entry<String, String> data : DropDownValues.entrySet())
		{			
				myValue = data.getValue();
				myElements = findElementsByDynamicXpath("//*[contains(text(),'"+data.getKey()+"')]//following::div[1]");
				
				if(myElements.size()>1) 
				{
					myElements = findElementsByDynamicXpath("//*[text()='"+data.getKey()+"']//following::div[1]");
				}
				
				for(WebElement E : myElements)
				{
					if(data.getValue().isEmpty()) 
					{
						myValue = "—";
					}
					System.out.println(data.getKey()+" Stored Value: "+myValue+" Displayed Value: "+E.getText());	
	
					sftAst.assertEquals(E.getText(), myValue );
					action.scrollToElement(E);
					action.highligthElement(E);
					Reporter.addStepLog(data.getKey()+" Stored Value: "+myValue+" Displayed Value: "+E.getText());
					Thread.sleep(200);
					break;
				}
		}	
	}
	
	public void checkInputEditsOnEnterDetailsPage(String entity,List<List<String>> attribute) throws Throwable
	{
		System.out.println(Arrays.asList(InputValues));
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
					myValue = InputValues.get(attribute.get(i).get(0));
					action.scrollToElement(findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']"));
					myValue1 = findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']").getAttribute("value");
					if(attribute.get(i).get(0).equalsIgnoreCase("FA ID(s)") || attribute.get(i).get(0).equalsIgnoreCase("Universal ID(s)")) 
					{
						for(String str :  myValue1.split(",") )
						{
							System.out.println(attribute.get(i).get(0) + " Stored Value: " + myValue + " Displayed Value: " + str);
							sftAst.assertTrue(myValue.contains(str),attribute.get(i).get(0));
							Reporter.addStepLog(attribute.get(i).get(0) + " Stored Value: " + myValue + " Displayed Value: " + str);
							Thread.sleep(200);
						}
						continue;
					}
					System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
					Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
					sftAst.assertEquals(myValue1, myValue);
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public void checkDropdownEditsOnEnterDetailsPage(String entity,List<List<String>> attribute) throws Throwable
	{
		System.out.println(Arrays.asList(DropDownValues));
    	
    	for (int i = 0; i < attribute.size(); i++)
		{
				myValue = DropDownValues.get(attribute.get(i).get(0));
				action.scrollToElement(findElementByDynamicXpath("//*[@id='"+attribute.get(i).get(1)+"']"));
				myValue1 = (String)executeJavaScript("return document.querySelector(\"#"+attribute.get(i).get(1)+"\").getAttribute('value')");
				if(attribute.get(i).get(0).contentEquals("Manager Name") || attribute.get(i).get(0).contentEquals("Investment Style"))
				{
					myElements = findElementsByDynamicXpath("//brml-select-option[@value='"+myValue1+"']");
					for(WebElement E: myElements) 
					{
						myValue1 = E.getAttribute("name");
						if(myValue == myValue1) 
							break;
					}
				}
				System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
				Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
				sftAst.assertEquals(myValue1, myValue);
		}   	
	}
	
	public void checkCheckBoxEditsOnUpdatePage(String entity,List<List<String>> attribute) throws Throwable
	{
		System.out.println(Arrays.asList(InputValues));
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
					myValue = InputValues.get(attribute.get(i).get(0));
					if(myValue.equalsIgnoreCase("Yes")) 
						myValue = "true";
					else if (myValue.equalsIgnoreCase("No")) 
						myValue = "false";

					myValue1 = (String)executeJavaScriptWithoutWait("return document.querySelector(\"#"+attribute.get(i).get(1)+"\").getAttribute('checked')");
					System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
					Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+myValue1);
					sftAst.assertEquals(myValue1, myValue);
			}
			catch (Exception e)
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}
	}
	
	public void checkBenchmarkEditsOnUpdateFlow(HashMap<String ,HashMap<String,Double>> Map, String entity,List<Map<String,String>> attribute) throws Throwable
	{
		System.out.println(Arrays.asList(Map));
		
		/*for(Map.Entry<String, HashMap<String, Double>> data: Map.entrySet())
		{
			int j=0;
			for(Map.Entry<String, Double> list: data.getValue().entrySet())
			{
				int i=1;
				for(Map<String, String> map2: attribute) 
				{
//					if(map2.get("Dropdown Name").contentEquals(data.getKey()) && map2.get("Dropdown Name").contentEquals("Style")) 
					if(data.getKey().contentEquals("Style")) 
					{
						myValue = (String)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1\").getAttribute('value')");
						System.out.println("Seleted Benchmark type is "+myValue);
						Reporter.addStepLog("Seleted Benchmark type is "+myValue);
						sftAst.assertTrue(myValue.contains(data.getKey().toLowerCase()));
						
						myElement.click();
						myElement = findElementByDynamicXpath("//brml-button[@variant='link' and @class='viewDetailsCta']");
						myElement.click();
						myValue = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[0].textContent");
						myValue1 = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[1].textContent");
						myValue1 = myValue + "-" + myValue1;
						System.out.println("Stored Benchmark: " + list.getKey() + "-" + format.format(list.getValue())+ "% Displayed Benchmark: " + myValue1);
						sftAst.assertEquals(myValue1, list.getKey() + "-" + format.format(list.getValue()) + "%");
						Reporter.addStepLog("Stored Benchmark: " + list.getKey() + "-" + format.format(list.getValue())+ "% Displayed Benchmark: " + myValue1);		
						i++;
						Thread.sleep(300);
						myElement = findElementByDynamicXpath("//brml-modal[@id='nonDetachedModal']//following::brml-button[@variant='secondary']");
						Thread.sleep(1000);
						myElement.click();
					}
					else if(map2.get("Dropdown Name").contentEquals(data.getKey())) 
					{
						myElement = findElementByDynamicXpath("//brml-select[@id='" + map2.get("Dropdown ID") + j + "']");
						action.moveToElement(myElement);
						myValue = myElement.getAttribute("value");
						myElement = findElementByDynamicXpath("(//brml-select-option[@value='" + myValue + "'])[1]");
						myValue = myElement.getAttribute("name");
						myValue = myValue.replaceAll(".+?-\\s|-\\d{4}$", "");
						myValue1 = list.getKey();
						System.out.println(map2.get("Dropdown ID") + j + " : " + myValue + " " + myValue1);
						sftAst.assertEquals(myValue, myValue1);
						myElement = findElementByDynamicXpath("//brml-stepper-input[@id='" + map2.get("Percentage ID") + j + "']");
						action.moveToElement(myElement);
						myValue = myElement.getAttribute("value");
						System.out.println(map2.get("Percentage ID")+j+" : "+format.format(Double.parseDouble(myValue))+" "+format.format(list.getValue()));
						sftAst.assertEquals(format.format(Double.parseDouble(myValue)), format.format(list.getValue()));
						Thread.sleep(200);
						j++;
					}
				}
			}
		}*/	
		
		if(Map.containsKey("Style")) 
		{
			checkNonCBEditsOnUpdatePage(entity,Map.get("Style"));
		}
		
		for(int i = 0; i < attribute.size(); i++)
		{
			int j = 0;
			if(!Map.containsKey(attribute.get(i).get("Dropdown Name"))) 
			{
				continue;
			}

			HashMap<String, Double> data = Map.get(attribute.get(i).get("Dropdown Name"));
			
			for(Map.Entry<String, Double> list: data.entrySet()) 
			{
				myElement = findElementByDynamicXpath("//brml-select[@id='" + attribute.get(i).get("Dropdown ID") + j + "']");
				action.moveToElement(myElement);
				myValue = myElement.getAttribute("value");
				myElement = findElementByDynamicXpath("(//brml-select-option[@value='" + myValue + "'])[1]");
				myValue = myElement.getAttribute("name");
				//myValue = myValue.replaceAll(".+?-\\s|-\\d{4}$", "");
				myValue = myValue.replaceAll("^.+?-\\s|-\\d{4}$", "");
				myValue1 = list.getKey();
				System.out.println(attribute.get(i).get("Dropdown ID") + j + " : " + myValue + " " + myValue1);
				sftAst.assertEquals(myValue, myValue1);
				myElement = findElementByDynamicXpath("//brml-stepper-input[@id='" + attribute.get(i).get("Percentage ID") + j + "']");
				action.moveToElement(myElement);
				myValue = myElement.getAttribute("value");
				//					System.out.println(attribute.get(i).get("Percentage ID")+j+" : "+myValue+" "+list.getValue()+"0");
				//					sftAst.assertEquals(myValue, list.getValue()+"0");
				System.out.println(attribute.get(i).get("Percentage ID")+j+" : "+format.format(Double.parseDouble(myValue))+" "+format.format(list.getValue()));
				sftAst.assertEquals(format.format(Double.parseDouble(myValue)), format.format(list.getValue()));
				Thread.sleep(200);
				j++;
			}
		}
		//sftAst.assertAll();
	}
	
	public void checkNonCBEditsOnUpdatePage(String entity,HashMap<String,Double> Map) throws Throwable
	{
		System.out.println(Arrays.asList(Map));
		
		myValue = (String)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1\").getAttribute('value')");
		System.out.println("Seleted Benchmark type is "+myValue);
		Reporter.addStepLog("Seleted Benchmark type is "+myValue);
		sftAst.assertTrue(myValue.contains("style"));
				
		int i=1;
		for (Map.Entry<String, Double> list : Map.entrySet())
		{
			myElement = findElementByDynamicXpath("//brml-button[@variant='link' and @class='viewDetailsCta']");
			action.jsClick(myElement);
			//myElement.click();
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[0].textContent");
			myValue1 = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[1].textContent");
			myValue1 = myValue + "-" + myValue1;
			System.out.println("Stored Benchmark: " + list.getKey() + "-" + format.format(list.getValue())+ "% Displayed Benchmark: " + myValue1);
			sftAst.assertEquals(myValue1, list.getKey() + "-" + format.format(list.getValue()) + "%");
			Reporter.addStepLog("Stored Benchmark: " + list.getKey() + "-" + format.format(list.getValue())+ "% Displayed Benchmark: " + myValue1);
			i++;
			Thread.sleep(300);
		}
		
		myElement = findElementByDynamicXpath("//brml-modal[@id='nonDetachedModal']//following::brml-button[@variant='secondary']");
		Thread.sleep(1000);
		myElement.click();
	}
	
	public void checkProxyEditsOnUpdatePage(List<List<String>> attribute) throws Throwable
	{
		for (int j = 0; j < proxyDetails.length; j++)
		{	
			HashMap<String, String> data = ProxyDetails.get(proxyDetails[j]);
			System.out.println(data);
	    	for (int i = 0; i < attribute.size(); i++)
				{				
					myElement = findElementByDynamicXpath("(//*[@id='"+attribute.get(i).get(1)+"'])["+(j+1)+"]");
					myValue = myElement.getAttribute("value");			

					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					System.out.println(attribute.get(i).get(0)+" : "+myValue+" "+data.get(attribute.get(i).get(0)));
					Reporter.addStepLog(attribute.get(i).get(0)+" : "+myValue+" "+data.get(attribute.get(i).get(0)));
					sftAst.assertEquals(myValue,data.get(attribute.get(i).get(0)));
					Thread.sleep(200);
				}
		}
	}
	
	public void checkDocumentEditsOnUpdatePage() throws Throwable
	{
		waitForJavaScript("return document.querySelector(\"tr\")");
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"tr\")");
		int i;
		for(int j = 1; j < myElements.size(); j++) 
		{
			HashMap<String, String> list = DocumentDetails.get("Document"+j);				

			i=1;
			while(true && i<=myElements.size()) 
			{
				myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('brml-button').textContent");

				if(list.get("Document Link").contentEquals(myValue))		
					break;
				
				i++;
			}
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('td')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('td').textContent");
			System.out.println("Stored value :"+list.get("Document Type")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Document Type")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Document Type"), myValue);

			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('brml-button')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('brml-button').textContent");
			System.out.println("Stored value :"+list.get("Document Link")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Document Link")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Document Link"), myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('brml-button')[1]"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('brml-button')[1].textContent");
			System.out.println("Stored value :"+list.get("Document Description")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Document Description")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Document Description"), myValue);
		}
			
	}
	
	public void checkCommentsEditsOnUpdatePage() throws Throwable
	{
		waitForJavaScript("return document.querySelector(\"tr\")");
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"tr\")");
		int i;
		for(int j = 1; j < myElements.size(); j++) 
		{
			HashMap<String, String> list = CommentDetails.get("Comment"+j);				
			i=1;
			while(true && i<=CommentDetails.size()) 
			{
				myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('td')[1].textContent");

				if(list.get("Comment Description").contentEquals(myValue))		
					break;
				
				i++;
			}

			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('td')"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelector('td').textContent");
			System.out.println("Stored value :"+list.get("Comment Type")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Comment Type")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Comment Type"), myValue);
			
			action.highligthElement((WebElement)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('td')[1]"));
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"tr\")["+i+"].querySelectorAll('td')[1].textContent");
			System.out.println("Stored value :"+list.get("Comment Description")+" Displayed value :"+myValue);
			Reporter.addStepLog("Stored value :"+list.get("Comment Description")+" Displayed value :"+myValue);
			sftAst.assertEquals(list.get("Comment Description"), myValue);
		}	
		//sftAst.assertAll();
	}
	
	
	public void checkDocumentEdits() throws Throwable
	{
		/*int j=1;
		for(int i = 1; i <= DocumentDetails.size()*3; i+=3)
		{
			HashMap<String, String> list = DocumentDetails.get("Document"+j);
			
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Documents')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+i+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Type")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Type"),"Document Type"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Type")+" Displayed Value: "+myElement.getText());
			
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Documents')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(i+1)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Link")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Link"),"Document Link"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Link")+" Displayed Value: "+myElement.getText());
		
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Documents')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(i+2)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Description")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Description"),"Document Description"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Description")+" Displayed Value: "+myElement.getText());		
			j++;
		}*/
		

		int j;
		
		for(int i = 1; i <= DocumentDetails.size(); i++)
		{
			j=1;
			HashMap<String, String> list = DocumentDetails.get("Document"+i);

			while(true && j <= DocumentDetails.size()*3) 
			{				
				myElement = findElementByDynamicXpath("(//h5[contains(text(),'Document')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(j+1)+"]");
				action.scrollToElement(myElement);
				if(list.get("Document Link").equals(myElement.getText()))		
					break;
				
				j+=3;
			}
		
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Document')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+j+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Type")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Type"),"Document Type"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Type")+" Displayed Value: "+myElement.getText());
	
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Document')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(j+1)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Link")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Link"),"Document Link"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Link")+" Displayed Value: "+myElement.getText());
			
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Document')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(j+2)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Document Description")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Document Description"),"Document Description"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Document Description")+" Displayed Value: "+myElement.getText());		
		}
	
	}
	
	public void checkCommentsEdits() throws Throwable
	{
		/*int j=1;
		for(int i = 1; i <= CommentDetails.size()*2; i+=2)
		{
			HashMap<String, String> list = CommentDetails.get("Comment"+j);
			
			//myElement = findElementByDynamicXpath("(//h5[contains(text(),'Home Office Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+i+"]");
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+i+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Comment Type")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Comment Type"),"Comment Type"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Comment Type")+" Displayed Value: "+myElement.getText());
			
			//myElement = findElementByDynamicXpath("(//h5[contains(text(),'Home Office Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(i+1)+"]");
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(i+1)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Comment Description")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Comment Description"),"Comment Description"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Comment Description")+" Displayed Value: "+myElement.getText());
			j++;
		}
//		sftAst.assertAll();*/
		

		int j;
		for(int i = 1; i <= CommentDetails.size(); i++)
		{
			HashMap<String, String> list = CommentDetails.get("Comment"+i);
			j=1;
			while(true && j <= CommentDetails.size()*2) 
			{				
				myElement = findElementByDynamicXpath("(//h5[contains(text(),'Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(j+1)+"]");
				action.scrollToElement(myElement);
				if(list.containsValue(myElement.getText()))		
					break;
				
				j+=2;
			}
			
			//myElement = findElementByDynamicXpath("(//h5[contains(text(),'Home Office Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+i+"]");
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+j+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Comment Type")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Comment Type"),"Comment Type"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Comment Type")+" Displayed Value: "+myElement.getText());
			
			//myElement = findElementByDynamicXpath("(//h5[contains(text(),'Home Office Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(i+1)+"]");
			myElement = findElementByDynamicXpath("(//h5[contains(text(),'Comments')]//following-sibling::div//following-sibling::div[contains(@class,'col-2 mb6 body-3')])["+(j+1)+"]");
			action.scrollToElement(myElement);
			System.out.println("Stored Value: "+list.get("Comment Description")+" Displayed Value: "+myElement.getText());
			sftAst.assertEquals(myElement.getText(),list.get("Comment Description"),"Comment Description"+j);
			Reporter.addStepLog("Stored Value: "+list.get("Comment Description")+" Displayed Value: "+myElement.getText());
		}
		//sftAst.assertAll();
	
	}
	
	public void selectedBMtype(String type) throws Throwable 
	{
		InputValues.put("SelectedBMType", type);
	}
	
	public void selectBenchmarkType(String BMtype) throws Throwable
	{
		action.waitForPageLoad();
		switch(BMtype) 
		{
			case "Style":
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(1)\")");
				InputValues.put("Custom BM Reason", "—");
				//selectedBMtype("417");
				break;
			case "Custom":
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(2)\")");
				//selectedBMtype("418");
				break;
			default:
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(1)\")");
				InputValues.put("Custom BM Reason", "—");
				//selectedBMtype("417");
				break;			
		}
		myElement.click();
		myElement = findElementByDynamicXpath("//brml-button[@variant='link' and @class='viewDetailsCta']");
		myElement.click();
		
		myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")");  
		
		for(int i = 1; i < myElements.size(); i++) 
		{
			myValue = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[0].textContent");
			myValue1 = (String)executeJavaScript("return document.querySelectorAll(\"#nonDetachedModal > div[class='grid p-0']\")["+i+"].querySelectorAll('span')[1].textContent");
			myValue1 = myValue1.replaceAll("%","");
			double percentage = Double.parseDouble(myValue1);
			BenchmarkValues.put(myValue, percentage);
		}
		
		BenchmarkDetails.put(BMtype, addValues1(BenchmarkDetails, BMtype, BenchmarkValues));

		//myElement = (WebElement)executeJavaScript("return document.querySelector(\"#nonDetachedModal\").querySelector(\"brml-button[variant='primary']\")");
		//myElement = (WebElement)executeJavaScript("return document.querySelector(\"#nonDetachedModal > footer > div > div.col-2 > brml-button\").shadowRoot.querySelector(\"button > span\")");
		//myElement = findElementByDynamicXpath("//brml-modal[@id='nonDetachedModal']//following::brml-button[@variant='primary']//following::span[contains(text(),'CLOSE')]");
		myElement = findElementByDynamicXpath("//brml-modal[@id='nonDetachedModal']//following::brml-button[@variant='secondary']");
		Thread.sleep(1000);
		myElement.click();
		System.out.println(BenchmarkDetails);
	}
	
	public void editProxyDetails(String entity,String strArg1, List<List<String>> attribute) throws Throwable
	{
		sheetName = strArg1;
		sheet = exlObj.getSheet(sheetName);
		
		myElement = findElementByDynamicXpath("//brml-checkbox[@id='voluntaryReorgCheckbox']");
		action.scrollToElement(myElement);
		myElement.click();
		
		myValue = (String)action.executeJavaScript("return document.querySelector('brml-checkbox[id=\"voluntaryReorgCheckbox\"]').getAttribute('checked')");
		
		if(myValue.equals("true"))
			findElementByDynamicXpath("//brml-checkbox[@id='voluntaryReorgCheckbox']").click();
		
		myElement = findElementByDynamicXpath("//brml-checkbox[@id='interimCheckbox']");
		action.scrollToElement(myElement);
		myElement.click();
		
		myValue = (String)action.executeJavaScript("return document.querySelector('brml-checkbox[id=\"interimCheckbox\"]').getAttribute('checked')");
		
		if(myValue.equals("true"))
			findElementByDynamicXpath("//brml-checkbox[@id='interimCheckbox']").click();
		
		for (int j = 0; j < proxyDetails.length; j++)
		{
			for (int i = 0; i < attribute.size(); i++)
			{	
				if(attribute.get(i).get(0).equals("State"))
				{
					myElement = (WebElement)executeJavaScript("return document.querySelectorAll('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')["+j+"].shadowRoot.querySelector(\"wf-input\")");
					
					if(myElement.isEnabled())
					{
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						action.click(myElement);

						rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, proxyDetails[j]);
						num = Integer.parseInt(scenario[j]);
						cellIndex = exlObj.getCellIndexByCellValue(sheet, num, attribute.get(i).get(0));
						myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
						System.out.println(myValue);

						myElements1 = getDynamicElementsFromShadowRoot("return document.querySelectorAll('brml-select[id=\""+attribute.get(i).get(1)+"\"]')["+j+"].shadowRoot.querySelectorAll('li')");
						
						for(WebElement E : myElements1) 
						{
							if(E.getText().equalsIgnoreCase(myValue))
							{
								myElement = E;
								break;
							}
						}
						
						System.out.println(myElement.getText());
						
						action.scrollToElement(myElement);
						Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

						action.click(myElement);
						
						ProxyValues.put(attribute.get(i).get(0),myValue);
						
					}		
				}
				else
				{
					myElement = (WebElement)executeJavaScript("return document.querySelectorAll('brml-input[id=\""
							+ attribute.get(i).get(1) + "\"]')["+j+"].shadowRoot.querySelector(\"input\")");
					
					if(myElement.isEnabled())
					{
						action.scrollToElement(myElement);
						action.highligthElement(myElement);

						rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, proxyDetails[j]);
						num = Integer.parseInt(scenario[j]);
						cellIndex = exlObj.getCellIndexByCellValue(sheet, num, attribute.get(i).get(0));
						myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
						System.out.println(myValue);
						action.scrollToElement(myElement);
						action.clear(myElement);
						//action.sendKeys(myElement, myValue);
						sendKeysWithCheck(myElement, myValue);
						
						ProxyValues.put(attribute.get(i).get(0),myValue);
						
						Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));
					}
				}
			}
			
			ProxyDetails.put(proxyDetails[j], addValuesString(ProxyDetails, proxyDetails[j], ProxyValues));
			ProxyValues.clear();   	
		} 	
		
		System.out.println(ProxyDetails); 
	}
	
	public void editContactDetails(String entity,String scenario, List<List<String>> attribute) throws Throwable
	{
		action.waitForPageLoad();		
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
		for (int i = 0; i < attribute.size(); i++)
		{
			try
			{
				waitForJavaScript("return document.querySelector('*[id=\""+ attribute.get(i).get(1) + "\"]')");

				myValue = (String)executeJavaScriptWithoutWait("return document.querySelector('*[id=\""
						+ attribute.get(i).get(1) + "\"]').getAttribute('disabled')");

				if(!Boolean.parseBoolean(myValue))
				{
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					if(attribute.get(i).get(0).contains("DD"))
					{
						myElement = (WebElement)executeJavaScript("return document.querySelector('brml-select[id=\""
								+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
						
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						action.click(myElement);
						Thread.sleep(500);
											
						myElements = getDynamicElementsFromShadowRoot("return document.querySelector('brml-select[id=\""
								+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelectorAll('li')");
						
						for(WebElement E: myElements) 
						{
							if(E.getText().equalsIgnoreCase(myValue)) 
							{
								myElement = E;
								break;
							}
						}
						myValue = myElement.getText();
						action.click(myElement);
					}
					else if (attribute.get(i).get(0).contains("IN"))
					{
						myElement = (WebElement)executeJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						myClear(myElement);
						sendKeysWithCheck(myElement, myValue);
					}
					
					ContactDetails.put(attribute.get(i).get(0), myValue);
					DropDownValuesId.put(attribute.get(i).get(1), myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				} 
				else
				{
					myElement = (WebElement)executeJavaScript("return document.querySelector('*[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					myValue = myElement.getAttribute("value");
				
					ContactDetails.put(attribute.get(i).get(0), myElement.getText());
					DropDownValuesId.put(attribute.get(i).get(1), myValue);
					System.out.println(attribute.get(i).get(0)+" "+myValue);
					Reporter.addStepLog("Drop down for" + attribute.get(i).get(0) + "selected");
				}
			}
			catch (Exception e) 
			{
				Assert.fail("Unable to access "+attribute.get(i).get(0) );
			}
		}	
		System.out.println(ContactDetails);
	}
	
	public void checkContactEdits() throws Throwable
	{
		System.out.println(ContactDetails);
		int i = 1;
		for(Map.Entry<String, String> data: ContactDetails.entrySet())
		{
			myElement = findElementByDynamicXpath("//td[" + i + "]");
			myValue = myElement.getText();
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			System.out.println(data.getKey()+" Stored Value: " + data.getValue() + " Displayed Value: " + myValue);
			sftAst.assertEquals(myValue, data.getValue());
			Reporter.addStepLog(data.getKey()+" Stored Value: " + data.getValue() + " Displayed Value: " + myValue);
			Thread.sleep(200);
			i++;
		}
	}
	
	public void checkProxyEdits() throws Throwable
	{
		System.out.println(Arrays.asList(ProxyDetails));
		
		for (Map.Entry<String, HashMap<String, String>> data : ProxyDetails.entrySet())
		{			
			System.out.println(data.getKey());
				for (Map.Entry<String, String> list : data.getValue().entrySet())
				{				
					myElement = findElementByDynamicXpath("//h6[contains(text(),'"+data.getKey()+"')]//parent::div//label[contains(text(),'"+list.getKey()+"')]//following-sibling::div[1]");
					myValue = myElement.getText();				

					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					System.out.println("Stored Value: "+list.getValue()+" Displayed Value: "+myValue);
					sftAst.assertEquals(myValue,list.getValue());
					Reporter.addStepLog("Stored Value: "+list.getValue()+" Displayed Value: "+myValue);
					Thread.sleep(200);
				}
		}
	}
	
	public HashMap<String, String> addValuesString(HashMap<String ,HashMap<String,String>> haspMap, String key,HashMap<String,String> value) throws Throwable 
	{
		HashMap<String, String> tempList = null;
		if(haspMap.containsKey(key)) 
		{
			tempList = haspMap.get(key);
			if(tempList == null)
				tempList = new HashMap<String, String>();
			//			tempList.putAll(valueCopy);
			tempList.putAll(value);
		}
		else 
		{
			tempList = new HashMap<String, String>();
			//			tempList.putAll(valueCopy);
			tempList.putAll(value);
		}
		//haspMap.put(key,tempList);
		return tempList;
	}
	
	public void globalSearchDraft() throws Throwable
	{
    	try
    	{
	    	myElement = findElementByDynamicXpath("//span[contains(text(),'Product Master')]");
	    	action.scrollToElement(myElement);
	    	myElement.click();
			action.waitForPageLoad();
			Thread.sleep(2000);
			
			compareBoolean = action.isPresent("js", "return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			if(compareBoolean)
			{
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
				myElement.click();
			}
			
			myElement = (WebElement)executeJavaScriptWithRefresh("return document.querySelector(\"brml-search-input\")");
			myElement.click();
			sendKeysWithCheck(myElement, draftName);
			
		    Thread.sleep(2000);
		        
				int i = 0;
				while(i < 5) 
				{
					myElement.sendKeys(Keys.ENTER);
					i++;
				}
		        	
		        Thread.sleep(2000);
		        
		         i = 0;
				while(i < 5) 
				{
					myElement.sendKeys(Keys.ENTER);
					i++;
				}
		        	
		        Thread.sleep(2000);
		        
		    myValue = findElementByDynamicXpath("//h6[contains(text(),'Results (')]").getText();
		    System.out.println(myValue);
		    Assert.assertTrue(myValue.contains("Results (0"), "The draft is not displayed in global search");
    	}
	    	catch (Exception e) 
	    	{
	    		Assert.fail("Unable to access the global search");
	    	}
	    	
    	
	}
	
	public void	checkDraftInTab(String strArg1) throws Throwable
	{

    	try
    	{
	    	myElement = findElementByDynamicXpath("//html");
	    	myElement.click();
	    	Thread.sleep(2000);
	    	myElement = findElementByDynamicXpath("//brml-tab-button[@tab=\""+strArg1+"\"]");
			Thread.sleep(2000);
			myElement.click();
			
			scroll_to_bottom();

			myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='styleName']\")");  
			   for (int i = 1; i < myElements.size(); i++)
			   {
				   System.out.println(myElements.get(i).getText());
					if(myElements.get(i).getText().equalsIgnoreCase(draftName)) 
					{
					   	myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[col-id='styleName']\")["+i+"]");
					   	myElement.click();
					   	myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[col-id='styleName']\")["+i+"].parentElement.querySelector(\"brml-action-menu\")");
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						Thread.sleep(2000);
						Assert.fail();
					}
			   }
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access the draft view");
    	}

	}
	
	public void	draftNameErrorMessage(String strArg1, String strArg2) throws Throwable
	{
    	try
    	{				
	    	myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"brml-input[label='Draft Name']\").shadowRoot.querySelector('wf-tooltip > div > div >input')");
			action.jsClick(myElement);
			action.clear(myElement);
			action.sendKeyCharterWise(myElement, strArg1);
			
			myElement = (WebElement) action.executeJavaScript("return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");
			action.jsClick(myElement);
			
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"#provideDraftName\").shadowRoot.querySelector(\"wf-tooltip > div > wf-conditional-animate> div\")");
			System.out.println(myElement.getText());
			System.out.println(strArg2);
		
			Assert.assertTrue(myElement.getText().contains(strArg2), "Error message is valid");
			Reporter.addStepLog("The correct error message is displayed");
    	}
    	catch (Exception e)
    	{
			Assert.fail("Unable to get the error message" );
			
		}
    
	}
	
	public void clickTabs(String tabName) throws Throwable
	{
			Thread.sleep(5000);
			action.waitForPageLoad();
			myElement = findElementByDynamicXpath("//brml-tab-button[@tab='"+tabName+"']");
			Thread.sleep(2000);
			myElement.click();
			Reporter.addStepLog(tabName+" tab is cicked");
			action.waitForPageLoad();
			Thread.sleep(5000);
	}
	
	public void draftNotVisible() throws Throwable
	{
		while(true)
		{
			try
			{
				myElement1 = (WebElement)executeJavaScriptWithoutWait("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
				action.highligthElement(myElement1);
				myElement1.click();
		    	Thread.sleep(2000);
			}
			catch (Throwable e) 
			{
				break;
			}
		}
		
		while(true)
			{
				try
				{
					myElement1 = (WebElement)executeJavaScriptWithoutWait("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
					action.highligthElement(myElement1);
					myElement1.click();
			    	Thread.sleep(2000);

				}
				catch (Throwable e) 
				{
					break;
				}
			}
		myElement = (WebElement)executeJavaScript("return document.querySelector(\"#wftabs > brml-tab-button[tab='Draft']\")");
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("Draft tab is cicked");
		action.waitForPageLoad();
		Thread.sleep(3000);



			scroll_to_bottom();

			  myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='draftName']\")");  
			   for (int i = 1; i < myElements.size(); i++)
			   {
				   System.out.println(myElements.get(i).getText());
					if(myElements.get(i).getText().equalsIgnoreCase(draftName)) 
					{
						Assert.fail("The draft is still displayed on draft view even after it is submitted");
					}
			   }
			
    }
	
	 public void editFAIDs(String search) throws Throwable
	    {
	    	try 
	    	{
	    		myElement = (WebElement)executeJavaScript("return document.querySelector(\"#faId\").shadowRoot.querySelector(\"wf-input\").shadowRoot.querySelector(\"div > wf-icon\")");
				myElement.click();
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[0].shadowRoot.querySelector(\"button\")");
				myElement.click();
				Thread.sleep(5000);
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[0].shadowRoot.querySelector(\"button\")");
				myElement.click();
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#faId\").shadowRoot.querySelector(\"wf-input\").shadowRoot.querySelector(\"input\")");
				myElement.click();
				sendKeysWithCheck(myElement, search);
//				myElement.sendKeys("a");
				Thread.sleep(5000);
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[1].shadowRoot.querySelector(\"button\")");
				myElement.click();
				Thread.sleep(1000);
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[2].shadowRoot.querySelector(\"button\")");
				myElement.click();
				Thread.sleep(1000);
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[3].shadowRoot.querySelector(\"button\")");
				myElement.click();
				Thread.sleep(1000);
				myElement = (WebElement)executeJavaScript("return document.querySelector(\"#faId\").shadowRoot.querySelector(\"div.multiselect-dropdown-footer > slot > div > wf-button:nth-child(2)\")");
				myElement.click();
				myValue = (String)executeJavaScript("return document.querySelector(\"#faId\").getAttribute('value')");
				InputValues.put("FA ID(s)", myValue);
			}
			catch(Exception e)
	    	{
				Assert.fail("Unable to access FAIDs");
			} 
	    }
	
	public void viewEdit(String entity,String searchCode,String columnName,String option,String scenario) throws Throwable
	{
			action.waitForPageLoad();

			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchCode);
			searchCode = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			
			  myElements = getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='"+columnName+"']\")");  
			   for (int i = 1; i < myElements.size(); i++)
			   {
				   System.out.println(myElements.get(i).getText());
					if(myElements.get(i).getText().contains(searchCode)) 
					{
					   	myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[col-id='"+columnName+"']\")["+i+"]");
						action.scrollToElement(myElement);
					   	myElement.click();
					   	myElement = (WebElement)executeJavaScript("return document.querySelectorAll(\"div[col-id='"+columnName+"']\")["+i+"].parentElement.querySelector(\"brml-action-menu\")");
						action.highligthElement(myElement);
						Thread.sleep(2000);
						myElement.click();
						Reporter.addStepLog("clicking on ellipsis icon");
					   
						myElements =getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='"+columnName+"']\")["+i+"].parentElement.querySelector(\"brml-action-menu\").shadowRoot.querySelectorAll(\"button > span\")");
						if(option.equalsIgnoreCase("ViewEdit"))
						{
							action.highligthElement(myElements.get(0));
							Thread.sleep(2000);
							myElements.get(0).click();
							
							Reporter.addStepLog("Cicking on the View/Edit option");
						}
						
						else if(option.equalsIgnoreCase("Delete"))
						{
							action.scrollToElement(myElements.get(1));
							action.highligthElement(myElements.get(1));
							Thread.sleep(2000);
							myElements.get(1).click();
							
							Reporter.addStepLog("Cicking on the View/Edit option");
						}
						Thread.sleep(5000);
						break;
					}
			   }
    	}
    	
	
	
	public void scroll_to_bottom() throws Throwable
	{
		try 
		{
			Object lastHeight = (Object)action.executeJavaScript("return document.body.scrollHeight");
			//Object lastHeight = (Object) executeJavaScript("return document.body.scrollHeight");
			
			while(true)
			{
				Action.scrollToBottom();
				Thread.sleep(5000);
				Object newHeight = (Object)action.executeJavaScript("return document.body.scrollHeight");
				
				if(newHeight.equals(lastHeight))
				{
					break;
				}
				lastHeight = newHeight;
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	 
	 public static String generateCode(String candidateChars, int length)
	 {
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		for(int i = 0; i < length; i++)
		{
			sb.append(candidateChars.charAt(random.nextInt(candidateChars.length())));
		}
		return sb.toString();
	 }
	 
	 public void searchAccessFOACode() throws Throwable
	 {
			sheetName = "SMASingleSWPAAP";
			sheet = exlObj.getSheet(sheetName);
			Thread.sleep(1000);
		
				try
				{
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Search for Access FOA Code");
					myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					if(myValue.isEmpty())
					{
						switch(UIEnvironment) 
						{
							case "DEV":
								
								myValue = "4NA7";
								break;
								
							case "QA":
								
								myValue = "0PC3";
								break;	
							
							case "UAT":
								
								myValue = "3EMG";
								break;
								
							default:
								
								System.out.println("Invalid case, no value found");
								Reporter.addStepLog("Invalid case, no value found");
								break;
						}
						
						myElement = (WebElement)executeJavaScript("return document.querySelector('brml-input[id=\"searchForAccessFOACode\"]').shadowRoot.querySelector('input')");

						if(myElement.isEnabled())
						{
						   action.scrollToElement(myElement);
						   action.clear(myElement);
						   Thread.sleep(1000);
						   sendKeysWithCheck(myElement, myValue);
						   
						   int i = 0;
							
							while(i < 5)
							{
								myElement.sendKeys(Keys.ENTER);
								i++;
							}
							
						   InputValues.put("Search for Access FOA Code",myValue);
						   InputValuesId.put("searchForAccessFOACode",myValue);

						   Reporter.addStepLog("send keys " + myValue + " for Search for Access FOA Code");

						   Thread.sleep(1000);
						}
						
					}
					
					else
					{
						myElement = (WebElement)executeJavaScript("return document.querySelector('brml-input[id=\"searchForAccessFOACode\"]').shadowRoot.querySelector('input')");
	
						if(myElement.isEnabled())
						{
						   action.scrollToElement(myElement);
						   action.clear(myElement);
						   Thread.sleep(1000);
						   sendKeysWithCheck(myElement, myValue);
						   
						   int i = 0;
							
							while(i < 5)
							{
								myElement.sendKeys(Keys.ENTER);
								i++;
							}
						
							Thread.sleep(5000);
							myValue1 = (String)executeJavaScriptWithoutWait("return document.querySelector(\"#searchForAccessFOACode\").shadowRoot.querySelector(\"wf-conditional-animate > div\").textContent").toString();

							if(myValue1.equals("Access Strategy Not Found")) 
							{
								switch(UIEnvironment) 
								{
									case "DEV":
										
										myValue = "4NA7";
										break;
										
									case "QA":
										
										myValue = "0PC3";
										break;	
									
									case "UAT":
										
										myValue = "3EMG";
										break;
										
									default:
										
										System.out.println("Invalid case, no value found");
										Reporter.addStepLog("Invalid case, no value found");
										break;
								}
								
								myElement = (WebElement)executeJavaScript("return document.querySelector('brml-input[id=\"searchForAccessFOACode\"]').shadowRoot.querySelector('input')");
	
								if(myElement.isEnabled())
								{
								   action.scrollToElement(myElement);
								   action.clear(myElement);
								   Thread.sleep(1000);
								   sendKeysWithCheck(myElement, myValue);
								   
								    i = 0;
									
									while(i < 5)
									{
										myElement.sendKeys(Keys.ENTER);
										i++;
									}
									
								   InputValues.put("Search for Access FOA Code",myValue);
								   InputValuesId.put("searchForAccessFOACode",myValue);
	
								   Reporter.addStepLog("send keys " + myValue + " for Search for Access FOA Code");
	
								   Thread.sleep(1000);
								}
							}
						}
					}
				}
				catch (Exception e)
				{
					Assert.fail("Unable to access Search for Access FOA Code" );
				}
			} 	 
}
