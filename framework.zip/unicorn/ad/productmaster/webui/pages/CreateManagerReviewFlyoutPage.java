package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateManagerReviewFlyoutPage {
	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
    WebElement myElement1;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateBenchmark.xlsx";
	String option, sheetName = "";
	int rowIndex;

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public  CreateManagerReviewFlyoutPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	public void verifyElementsinCreateManagerflyoutReviewPage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	
	public String getText() {
		myElement = action.getElement("Reviewheader");
		return myElement.getText();
	}
	public void clickOnnextbuttoninreviewmanagerflyout() throws Throwable{
		myElement = action.getElement("Done Button");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public void clickOneditlinkinreviewmanagerflyout() throws Throwable{
		myElement = action.getElement("Edit Link");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
}
