package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class StyleDetailsPage {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_StyleDetailPage"));
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	WebElement myElement;
	List<String> list = new ArrayList<String>();
	
public void click_on_viewlink() {
	action.scrollByPixel("40");
		action.click(action.getElement("View/Edit"));
	}
	
public void click_on_backtosearchresultlink() {
	//action.scrollByPixel("40");
		action.click(action.getElement("Back to Search Results Link"));
	}

public void click_on_editbutton() {
	//action.scrollByPixel("40");
		action.click(action.getElement("Edit Button"));
	}
public String getHeaderText() {

	String header = action.getElement("HeaderKey").getText();
	return header;
}

public List<WebElement> getElements(String key){
	listOfElements = action.getElements(key);
	return listOfElements;
	
}
public void hoverOnElement(WebElement hoverElement) {
	action.moveToElement(hoverElement);
}
public WebElement getInsideElement(WebElement parentElement, String key) {
	return action.getElementFromParentElement(parentElement, key);
	
}
public WebElement getstyleheadertext() {
	return action.getElement("Style Name");
}
public void verifyGhostText(String expectedGhostText, String boxKey) {
	myElement = action.getElement(boxKey);
	String actualGhostText = myElement.getAttribute("placeholder");
	Assert.assertEquals( actualGhostText,expectedGhostText);
}
public void verifyTextInListOfElements(String text, List<WebElement> list1) {
	
	for (int i=0;i< list1.size();i++) {
		list.add(list1.get(i).getText());
	}
	Assert.assertTrue(list.contains(text));
}
public void verifyHoverElement(WebElement element, String hoverElementKey) {
	action.moveToElement(element);
	verifyElement(hoverElementKey);
}
public void verifyElement(WebElement element) {
	myElement = element;
	Assert.assertTrue(action.isDisplayed(myElement));
	}

public WebElement fetchElementFromShadowRoot(String elementKey, String shadowRootElementKey) {
	WebElement shadowRootElement = action.getElement(shadowRootElementKey);
	WebElement expandedShadowRootElement = action.expandRootElement(shadowRootElement);
	myElement =  action.getElementFromParentElement(expandedShadowRootElement, elementKey);
	return myElement;
}
public void verifyElement(String elementKey) {
	myElement = action.getElement(elementKey);
	Assert.assertTrue(action.isDisplayed(myElement));
	}

public void verifyAttributeInListOfElements(String attribute, List<WebElement> list1,String value) {
	//action.click(action.getElement("Attributes"));
	for (int i=0;i< list1.size();i++) {
		list.add(list1.get(i).getAttribute(attribute));
	}
	Assert.assertTrue(list.contains(value));
}
}
