package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.CalendarUtils;
import qa.framework.utils.Reporter;

public class UpdateSMASingleAccesstrategyViewDetailsPage {

	Action action;
	WebElement Element;
	List<WebElement> listElement;
	String uiValue = "";

	public UpdateSMASingleAccesstrategyViewDetailsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public boolean isUserOnViewDetailsPage() {

		Element = action.waitForJSWebElement("Header View Page");
		if (Element.getText().contains("View Strategy")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void clickOnContinueEditingButton() {

		Element = action.fluentWaitWebElement("Continue Editing");
		action.moveToElement(Element);
		action.highligthElement(Element);
		Element.click();
	}

	public String getRiskCategoryValue() {

		Element = action.fluentWaitWebElement("Risk Category Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getStrategyNameValue() {

		Element = action.fluentWaitWebElement("Strategy Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getStrategyCodeValue() {
		Element = action.fluentWaitWebElement("FOA code (ACCESS) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getResearchRatingValue() {
		Element = action.fluentWaitWebElement("Research Rating Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getStrategyMinimumValue() {
		Element = action.fluentWaitWebElement("Strategy Minimum (MEPS) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getText())).toString();
		return data;
	}

	public String getExceptionMinimumValue() {
		Element = action.fluentWaitWebElement("Exception Minimum (RAW) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getText())).toString();
		return data;
	}

	public String getWithdrawalRebalanceMinimumValue() {
		Element = action.fluentWaitWebElement("Withdrawal/Rebalance Minimum (RAW) Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getText())).toString();
		return data;
	}

	public String getStrategyStatus() {
		Element = action.fluentWaitWebElement("Strategy Status Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getPremiumEligibleValue() {
		/*
		 * Element = action.fluentWaitWebElement("Premium Fee Value");
		 * action.moveToElement(Element); action.highligthElement(Element); String data
		 * = Element.getAttribute("class"); if(data.contains("checked")) { return "t"; }
		 * return "f"; //return Element.getText();
		 */
		Element = action.fluentWaitWebElement("Premium Fee Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		String data = Element.getText();
		if (data.equalsIgnoreCase("yes")) {
			return "t";
		} else if (data.equalsIgnoreCase("no")) {
			return "f";
		}
		return Element.getText();
	}

	public String getConcordFeeEligibleValue() {
		Element = action.fluentWaitWebElement("Concord Eligible Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		switch (Element.getText().toLowerCase()) {
		case "yes":
			return "t";
		case "no":
			return "f";
		default:
			break;
		}
		return "Incorrect Value is displayed in UI";
	}

	public String getBundledNodeIDValue() {
		Element = action.getElement("Time Periods Count");
		List<WebElement> timeperiods = action.getElementsFromParentElement(Element, "Node Id List");
		ArrayList<String> tempData = new ArrayList<String>();
		int timeperiodscount = 1;
		// System.out.println(timeperiodscount+":::");
		String BundledNodeID = "";
		String[] data;
		// Element = action.fluentWaitWebElement("Bundled Node ID Value");
		for (WebElement E : timeperiods) {
			// System.out.println(E.getAttribute("class"));
			if (E.getAttribute("class").contains("grid")) {
				// System.out.println(timeperiodscount);
				Element = action.getElementByFormatingXpath("Bundled Node ID Value", timeperiodscount);
				action.moveToElement(Element);
				action.highligthElement(Element);
				data = Element.getText().split("-");
				BundledNodeID = data[0].trim();
				tempData.add(BundledNodeID);
				timeperiodscount++;
			}

		}
		if (tempData.size() > 1) {
			Collections.sort(tempData);
			BundledNodeID = "";
			for (String G : tempData) {
				BundledNodeID = BundledNodeID + G + ":";
			}
		}
		tempData.clear();

		return BundledNodeID;
	}

	public String getUnbundledNodeIDValues() {
		Element = action.getElement("Unbundled Node ID Value");
		List<WebElement> Elements = action.getElementsFromParentElement(Element, "Node Id List");
		String[] temp;
		String data = "";
		for (WebElement E : Elements) {
			action.moveToElement(E);
			action.highligthElement(E);
			temp = E.getText().split("-");
			data = data + temp[0].trim() + ":";
		}
		if (Elements.size() == 1) {
			data = data.substring(0, data.length() - 1);
		}
		return data;
		// return Element.getText();
	}

	public String getInceptionDateIgnore() {
//		Element = action.fluentWaitWebElement("");
//		action.moveToElement(Element);
//		action.highligthElement(Element);
		return "done";
		// return Element.getText();
	}

	public String getStartDateIgnoreValue() {
//		Element = action.fluentWaitWebElement("");
//		action.moveToElement(Element);
//		action.highligthElement(Element);
		return "done";
		// return Element.getText();
	}

	public String getIsManagerProfileValue() {
		Element = action.fluentWaitWebElement("IS Manager Profile Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		switch (Element.getText().toLowerCase()) {
		case "yes":
			return "t";
		case "no":
			return "f";
		default:
			break;
		}
		return "Incorrect Value is displayed in UI";
		// return Element.getText();
	}

	public String getDeletedValue() {
		Element = action.fluentWaitWebElement("Deleted Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		switch (Element.getText().toLowerCase()) {
		case "yes":
			return "t";
		case "no":
			return "f";
		default:
			break;
		}
		return "Incorrect Value is displayed in UI";
		// return Element.getText();
	}

	public String getAlternativesStrategyCodeValue() {
//		Element = action.fluentWaitWebElement("");
//		action.moveToElement(Element);
//		action.highligthElement(Element);
		return "done";
		// return Element.getText();
	}

	public String getProxyManagerValue() {
		Element = action.fluentWaitWebElement("Proxy Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getProxyAddress1Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getProxyAddress2Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getProxyAddress3Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getProxyAddress4Value() {
		Element = action.fluentWaitWebElement("Proxy Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getProxyCityValue() {
		Element = action.fluentWaitWebElement("Proxy Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getProxyStateValue() {
		Element = action.fluentWaitWebElement("Proxy Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getProxyZipCodeValue() {
		Element = action.fluentWaitWebElement("Proxy Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getVoluntaryReorgManagerValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getVoluntaryReorgAddress1Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getVoluntaryReorgAddress2Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getVoluntaryReorgAddress3Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getVoluntaryreorgAddress4Value() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getVoluntaryReorgCityValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getVoluntaryReorgStateValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getVoluntaryReorgZipcodeValue() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getInterimManagerValue() {
		Element = action.fluentWaitWebElement("Interim Address - Manager Name Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getInterimAddress1Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 1 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getInterimAddress2Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 2 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getInterimAddress3Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 3 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getInterimAddress4Value() {
		Element = action.fluentWaitWebElement("Interim Address - Address Line 4 Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getInterimCityValue() {
		Element = action.fluentWaitWebElement("Interim Address - City Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getInterimStateValue() {
		Element = action.fluentWaitWebElement("Interim Address - State Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getInterimZipcodeValue() {
		Element = action.fluentWaitWebElement("Interim Address - Zip Code Value");
		action.moveToElement(Element);
		action.highligthElement(Element);

		return Element.getText();
	}

	public String getPrimaryBenchmarkValue() {
		String primaryBenchmark = "";

		Element = action.getElement("Date Type");
		String datetype = Element.getText();
		if (datetype.equals("Style")) {
			List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
			if (WebElements.isEmpty()) {
				return "Primary Benchmark Data is not displayed in Review Page";
			} else {
				List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0),
						"Benchmarks List common tag");
				ArrayList<String> tempData = new ArrayList<String>();
				// String primaryBenchmark = "";
				int size = Elements.size();
				int count = 0;
				DecimalFormat ds = new DecimalFormat(".00");
				for (int i = 0; i < size / 3; i++) {
					primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
					primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
					if (Elements.get(count).getText().equals("—")) {
						primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
						primaryBenchmark = primaryBenchmark.replace("@benchmarkName",
								Elements.get(count + 1).getText());
						primaryBenchmark = primaryBenchmark.replace("@percentage",
								ds.format(Integer.parseInt(Elements.get(count + 2).getText().substring(0,
										Elements.get(count + 2).getText().length() - 1))));
					} else if (Elements.get(count + 1).getText().equals("—")) {
						if (primaryBenchmark.contains("@benchmarkCategory")) {
							primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkName",
									Elements.get(count).getText());
							primaryBenchmark = primaryBenchmark.replace("@percentage",
									ds.format(Integer.parseInt(Elements.get(count + 2).getText().substring(0,
											Elements.get(count + 2).getText().length() - 1))));
						} else {
							Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
						}

					}
					tempData.add(primaryBenchmark);
					// data = data+primaryBenchmark+":";
					count = count + 3;

				}
				if (tempData.size() > 1) {
					Collections.sort(tempData);
					primaryBenchmark = "";
					for (String G : tempData) {
						primaryBenchmark = primaryBenchmark + G + ":";
					}
				}
				tempData.clear();
			}
		} else if (datetype.equals("Timeperiod")) {
			Element = action.getElement("Total Time periods");
			List<WebElement> Timeperiods = action.getElementsFromParentElement(Element, "Benchmarks List common tag");
			ArrayList<String> tempData = new ArrayList<String>();
			int timeperiodcount = 1;
			for (WebElement E : Timeperiods) {
				if (E.getAttribute("class").contains("mb24")) {
					// List<WebElement> WebElements2 = action.getElements("Primary Benchmark Value
					// for Time periods");
					String locatorValue = "//div[contains(text(),'Benchmark1')]/parent::div/parent::div/following-sibling::div["
							+ timeperiodcount + "]/child::div[3]/child::div";
					// locatorValue = locatorValue.replace("@data",
					// String.valueOf(timeperiodcount));
					List<WebElement> WebElements2 = action.getElements("xpath", locatorValue);
					if (WebElements2.isEmpty()) {
						primaryBenchmark = timeperiodcount + " :: time period benchamrks are not appearing";
					} else {
						List<WebElement> Elements2 = action.getElementsFromParentElement(WebElements2.get(0),
								"Benchmarks List common tag");

						// String primaryBenchmark = "";
						int size = Elements2.size();
						int count = 0;
						DecimalFormat ds = new DecimalFormat(".00");
						for (int i = 0; i < size / 2; i++) {
							primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
							primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Cap n Go");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkName",
									Elements2.get(count).getText());
							primaryBenchmark = primaryBenchmark.replace("@percentage",
									ds.format(Integer.parseInt(Elements2.get(count + 1).getText().substring(0,
											Elements2.get(count + 1).getText().length() - 1))));
							tempData.add(primaryBenchmark);
							// data = data+primaryBenchmark+":";
							count = count + 2;

						}
					}
					timeperiodcount++;
				}

			}

			if (tempData.size() > 1) {
				Collections.sort(tempData);
				primaryBenchmark = "";
				for (String G : tempData) {
					primaryBenchmark = primaryBenchmark + G + ":";
				}
			}
			tempData.clear();
		}
		return primaryBenchmark;

	}

	public String getSmaSingleAccessStrategyDetails(String fieldName) {
		Element = action.getElementByFormatingXpath("Common Strategy Value", fieldName);
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getDataFromViewPageforExport(String data) {

		switch (data) {
		case "Program":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Strategy Name":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Vestmark Manager Name":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Strategy Status":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Manager Name":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Investment Style":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Portfolio Manager":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "FOA Code":
			uiValue = getStrategyCodeValue();
			break;
		case "Type of Strategy":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Vehicle Preferences":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Tax Preference":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Risk Category":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "MSA":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Underlying Strategy Name":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "FOA ID":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Percentage":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Allocation Preference":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Short Duration":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "MLPs":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "High Yield":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Large Trader ID":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Research Rating":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Options Eligible":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Collateral Eligible":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Sustainable Investing":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "IS Manager Profile":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Concord Eligible":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Premium Fee":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Deleted":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Non-Traditional Assets":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "NRA Eligibility":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Municipal Fixed Income Ladder":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Concentrated Strategy Indicator":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Taxable Fixed Income Ladder":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Yield Focused":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "CIO Aligned":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Foreign Securities (F-Shares)":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Strategy Minimum (MEPS)":
			uiValue = getSmaSingleAccessStrategyDetailsFormatted(data);
			break;
		case "Exception Minimum (RAW)":
			uiValue = getSmaSingleAccessStrategyDetailsFormatted(data);
			break;
		case "Withdrawal/Rebalance Minimum (RAW)":
			uiValue = getSmaSingleAccessStrategyDetailsFormatted(data);
			break;
		case "Fee Schedule Type":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Manager Fee (TS) (%)":
			uiValue = getSmaSingleAccessStrategyDetailsFormattedWith3Decimals("Manager Fee (TS) %");
			break;
		case "Concord Fee (%)":
			uiValue = getSmaSingleAccessStrategyDetailsFormattedWith3Decimals("Concord Fee %");
			break;
		case "Hide Strategy":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "AAR Base Template":
			uiValue = getAARBaseTemplate();
			break;
		case "Comparative Universe":
			uiValue = getSmaSingleAccessStrategyDetails(data);
			break;
		case "Proxy Address Manager":
			uiValue = getProxyAddressManager();
			break;
		case "Proxy Address":
			uiValue = getProxyAddress();
			break;
		case "Voluntary Reorg Address Manager":
			uiValue = getVoluntaryReorgAddressManager();
			break;
		case "Voluntary Reorg Address":
			uiValue = getVoluntaryReorgAddress();
			break;
		case "Interim Address Manager":
			uiValue = getInterimAddressManager();
			break;
		case "InterimAddress":
			uiValue = getInterimAddress();
			break;
		case "Document Link":
			uiValue = requiredDocumentValueForExport(1);
			break;
		case "Document Type":
			uiValue = requiredDocumentValueForExport(0);
			break;
		case "Document Description":
			uiValue = requiredDocumentValueForExport(2);
			break;
		case "Comments":
			uiValue = requiredCommentValueForExport(1);
			break;
		case "Comment Type":
			uiValue = requiredCommentValueForExport(0);
			break;
		case "DVP/Key Trust Template":
			uiValue = getDvpTrustValue();
			break;
		case "MSA Underlying Strategy Name":
			uiValue = getMsaUnderlyingStrategyname();
			break;
		case "MSA Underlying FOA Id":
			uiValue = getMsaFoaid();
			break;
		case "MSA Underlying Percentage":
			uiValue = getMsaPercentage();
			break;
		case "Node Timeperiod":
			uiValue = getNodeTimeperiod();
			break;
		case "Bundled Node ID":
			uiValue = getBundledNodeidValue();
			break;
		case "UnBundled Node Id":
			uiValue = getUnbundledNodeidValue();
			break;
		case "Benchmark 1 Timeperiod":
			uiValue = getBenchmarkTimeperiod();
			break;
		case "Custom Benchmark Reason":
			uiValue = getCustomBenchmarkReason();
			break;
		case "Benchmark Category- Style":
			uiValue = getStyleBenchmarkStyle();
			break;
		case "Benchmark Category - Custom":
			uiValue = getCustomBenchmarkStyle();
			break;
		/*
		 * Benchmark1- Style Benchmarks Benchmark1- Custom Benchmarks
		 */
		default:
			uiValue = "check";
			break;
		}
		if (uiValue.equals("—"))
			uiValue = "isEmpty";

		return uiValue;
	}

	public String getAARBaseTemplate() {
		Element = action.fluentWaitWebElement("AAR Base Template");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getProxyAddressManager() {
		Element = action.fluentWaitWebElement("Proxy Address Manager");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getVoluntaryReorgAddressManager() {
		Element = action.fluentWaitWebElement("Voluntary Reorg Address Manager");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getInterimAddressManager() {
		Element = action.fluentWaitWebElement("Interim Address Manager");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getProxyAddress() {
		listElement = action.fluentWaitWebElements("Proxy Address Labels");
		String proxyAddress = "";
		for (WebElement ele : listElement) {
			String label = ele.getText();
			if (label.equals("") || label.equals("Manager Name")) {
				continue;
			}
			Element = action.getElementByFormatingXpath("Proxy Address Values", label);
			action.moveToElement(Element);
			action.highligthElement(Element);
			if (Element.getText().equals("")) {
				continue;
			}
			if (Element.getText().equals(" ")) {
				proxyAddress = proxyAddress + Element.getText();
				continue;
			}
			proxyAddress = proxyAddress + Element.getText() + " ";
		}
		return proxyAddress.substring(0, proxyAddress.length() - 1);
	}

	public String getVoluntaryReorgAddress() {
		listElement = action.fluentWaitWebElements("Volunatary Reorg Address Labels");
		String reorgAddress = "";
		for (WebElement ele : listElement) {
			String label = ele.getText();
			if (label.equals("") || label.equals("Manager Name")) {
				continue;
			}
			Element = action.getElementByFormatingXpath("Volunatary Reorg Address Values", label);
			action.moveToElement(Element);
			action.highligthElement(Element);
			if (Element.getText().equals("")) {
				continue;
			}
			reorgAddress = reorgAddress + Element.getText() + " ";
		}
		return reorgAddress.substring(0, reorgAddress.length() - 1);
	}

	public String getInterimAddress() {
		listElement = action.fluentWaitWebElements("Interim Address Labels");
		String proxyAddress = "";
		for (WebElement ele : listElement) {
			String label = ele.getText();
			if (label.equals("") || label.equals("Manager Name")) {
				continue;
			}
			Element = action.getElementByFormatingXpath("Interim Address Values", label);
			action.moveToElement(Element);
			action.highligthElement(Element);
			if (Element.getText().equals("")) {
				continue;
			}
			proxyAddress = proxyAddress + Element.getText() + " ";
		}
		return proxyAddress.substring(0, proxyAddress.length() - 1);
	}

	private String requiredDocumentValueForExport(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		Element = action.fluentWaitWebElement("Document Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element,
				"Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";
		for (WebElement E : documentValues) {
			if (E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
			}
		}
		int documents = documentValuesData.size() / 3;
		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i + 3;
		}
		if (documents > 1) {
			// Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue + G + ", ";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length() - 2);
		}
		tempData.clear();
		//System.out.println("requiredDocumentValue:-" + requiredDocumentValue);
		return requiredDocumentValue;
	}

	public boolean areDocumentsDisplayedInUI() {
		/*
		 * List<WebElement> elements = action.getElements("Page Header"); if
		 * (elements.size() > 4) { return true; }
		 */
		return action.isPresent("Document Grid Values");
	}

	public boolean areHomeOfficeCommentsDisplayedInUI() {
		return action.getElement("Home Office Comments Grid").isDisplayed();
	}

	public String getHomeOfficeCommentsComment() {
		Element = action.fluentWaitWebElement("Home Office Comment Comment");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getHomeOfficeCommentsCommentType() {
		Element = action.fluentWaitWebElement("Home Office Comment Type");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getDvpTrustValue() {
		Element = action.fluentWaitWebElement("Dvp KeyTrust Value");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getSmaSingleAccessStrategyDetailsFormatted(String fieldName) {
		Element = action.getElementByFormatingXpath("Common Strategy Value", fieldName);
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Float.parseFloat(Element.getText())).toString();
		return data;
	}

	public String getSmaSingleAccessStrategyDetailsFormattedWith3Decimals(String fieldName) {
		Element = action.getElementByFormatingXpath("Common Strategy Value", fieldName);
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		DecimalFormat df = new DecimalFormat(".000");
		String data = df.format(Float.parseFloat(Element.getText())).toString();
		return data;
	}

	private String requiredCommentValueForExport(int i) {
		/*
		 * Comment Type --> i=0 Comment --> i=1
		 * 
		 */
		Element = action.fluentWaitWebElement("Home Office Comments Grid");
		List<WebElement> documentValues = action.getElementsFromParentElement(Element,
				"Common value for Document Values");
		ArrayList<String> tempData = new ArrayList<String>();
		ArrayList<WebElement> documentValuesData = new ArrayList<WebElement>();
		String requiredDocumentValue = "";
		for (WebElement E : documentValues) {
			if (E.getAttribute("class").contains("body-3")) {
				documentValuesData.add(E);
			}
		}
		int documents = documentValuesData.size() / 2;
		for (int j = 0; j < documents; j++) {
			requiredDocumentValue = documentValuesData.get(i).getText();
			tempData.add(requiredDocumentValue);
			action.moveToElement(documentValuesData.get(i));
			action.highligthElement(documentValuesData.get(i));
			i = i + 2;
		}
		if (documents > 1) {
			// Collections.sort(tempData);
			requiredDocumentValue = "";
			for (String G : tempData) {
				requiredDocumentValue = requiredDocumentValue + G + ", ";
			}
			requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length() - 2);
		}
		tempData.clear();
		//System.out.println("requiredDocumentValue:-" + requiredDocumentValue);
		return requiredDocumentValue;
	}

	public String getMsaUnderlyingStrategyname() {
		listElement = action.getElements("Underlying Strategy Name");
		uiValue = "";
		if (listElement.size() == 0 || listElement.get(0).getText().equals("—")) {
			return "isEmpty";
		}
		for (WebElement ele : listElement) {
			action.highligthElement(ele);
			uiValue = uiValue + ele.getText() + ", ";
		}
		return uiValue.substring(0, uiValue.length() - 2);
	}

	public String getMsaFoaid() {
		listElement = action.getElements("FOA Id");
		if (listElement.size() == 0 || listElement.get(0).getText().equals("—")) {
			return "isEmpty";
		}
		uiValue = "";
		for (WebElement ele : listElement) {
			action.highligthElement(ele);
			uiValue = uiValue + ele.getText() + ", ";
		}
		return uiValue.substring(0, uiValue.length() - 2);
	}

	public String getMsaPercentage() {
		listElement = action.getElements("Percentage");
		if (listElement.size() == 0 || listElement.get(0).getText().equals("—")) {
			return "isEmpty";
		}
		uiValue = "";
		for (WebElement ele : listElement) {
			action.highligthElement(ele);
			DecimalFormat df = new DecimalFormat(".0");
			String data = df.format(Integer.parseInt(ele.getText())).toString();
			uiValue = uiValue + data + ", ";
		}
		return uiValue.substring(0, uiValue.length() - 2);
	}

	public String getNodeTimeperiod() {
		Element = action.getElement("Asset Classification Timeperiod");
		action.moveToElement(Element);
		action.highligthElement(Element);
		uiValue = Element.getText();
		String dateValue = null;
		if (uiValue.contains("Current") && uiValue.contains("Inception")) {
			uiValue = "Inception Date - Current Date";
		} else if (uiValue.contains("Current")) {
			//System.out.println(uiValue.split(" ")[0]);
			Date date = CalendarUtils.stringToDate("MM/dd/yyyy", uiValue.split(" ")[0]);
			//System.out.println(date);
			dateValue = new SimpleDateFormat("yyyy-MM-dd").format(date);
			//System.out.println(dateValue);
			uiValue = dateValue + " - Current Date";
		} else if (uiValue.contains("Inception")) {
			//System.out.println(uiValue.split(" ")[0]);
			Date date = CalendarUtils.stringToDate("MM/dd/yyyy", uiValue.split(" ")[2]);
			//System.out.println(date);
			dateValue = new SimpleDateFormat("yyyy-MM-dd").format(date);
			//System.out.println(dateValue);
			uiValue = "Inception Date - " + dateValue;
		}
		return uiValue;
	}

	public String getBundledNodeidValue() {
		Element = action.fluentWaitWebElement("Asset Classification BundledNodeId");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText().replace(" ", "");
	}

	public String getUnbundledNodeidValue() {
		listElement = action.getElements("Asset Classification Grid");
		if (listElement.size() > 1) {
			listElement = action.getElements("Unbundled Node Id Values");
		}
		Element = action.fluentWaitWebElement("Asset Classification UnbundledNodeId");
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getBenchmarkTimeperiod() {
		if (action.isPresent("Benchmark Timeperiod Label")) {
			Element = action.getElement("Benchmark Timeperiod");
			action.moveToElement(Element);
			action.highligthElement(Element);
			uiValue = Element.getText();
			String dateValue = null;
			if (uiValue.contains("Current")) {
				//System.out.println(uiValue.split(" ")[0]);
				Date date = CalendarUtils.stringToDate("MM/dd/yyyy", uiValue.split(" ")[0]);
				//System.out.println(date);
				dateValue = new SimpleDateFormat("yyyy-MM-dd").format(date);
				//System.out.println(dateValue);
				uiValue = dateValue + " - Current Date";
			} else if (uiValue.contains("Inception")) {
				//System.out.println(uiValue.split(" ")[0]);
				Date date = CalendarUtils.stringToDate("MM/dd/yyyy", uiValue.split(" ")[2]);
				//System.out.println(date);
				dateValue = new SimpleDateFormat("yyyy-MM-dd").format(date);
				//System.out.println(dateValue);
				uiValue = "Inception Date - " + dateValue;
			}
		}
		return uiValue;
	}

	public String getCustomBenchmarkReason() {
		Element = action.getElement("Custom Benchmark Reason");
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().equals("—")) {
			return "isEmpty";
		}
		return Element.getText();
	}

	public String getCustomBenchmarkStyle() {
		if (action.isPresent("Benchmark Timeperiod Label") || action.isPresent("Benchmark Style No Value")) {
			return "Custom";
		}
		return "isEmpty";
	}

	public String getStyleBenchmarkStyle() {
		if (!action.isPresent("Benchmark Timeperiod Label")) {
			if (!action.isPresent("Benchmark Style No Value")) {
				return "Style";
			}
		}
		return "isEmpty";
	}
	
	public String getSmaSwpStrategyDetails(String fieldName) {
		Element = action.getElementByFormatingXpath("Common Strategy Value Swp", fieldName);
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		return Element.getText();
	}

	public String getDataFromViewPageforExportforSwp(String data) {

		switch (data) {
		case "Strategy Name":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Vestmark Manager Name":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Strategy Status":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Manager Name":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Investment Style":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Portfolio Manager":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "FOA Code":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Type of Strategy":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Vehicle Preferences":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Tax Preference":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Risk Category":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "MSA":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Underlying Strategy Name":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "FOA ID":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Percentage":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Allocation Preference":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Short Duration":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "MLPs":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "High Yield":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Large Trader ID":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Research Rating":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Options Eligible":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Collateral Eligible":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Sustainable Investing":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "IS Manager Profile":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Concord Eligible":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Premium Fee":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Deleted":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Non-Traditional Assests":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "NRA Eligibility":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Municipal Fixed Income Ladder":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Concentrated Strategy Indicator":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Taxable Fixed Income Ladder":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Yield Focused":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "CIO Aligned":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Foreign Securities (F-Shares)":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Strategy Minimum (MEPS)":
			uiValue = getSmaSwpStrategyDetailsFormatted(data);
			break;
		case "Exception Minimum (RAW)":
			uiValue = getSmaSwpStrategyDetailsFormatted(data);
			break;
		case "Withdrawal/Rebalance Minimum (RAW)":
			uiValue = getSmaSwpStrategyDetailsFormatted(data);
			break;
		case "Manager Fee (TS) (%)":
			uiValue = getSmaSwpStrategyDetailsFormattedWith3Decimals("Manager Fee (TS) %");
			break;
		case "Concord Fee (%)":
			uiValue = getSmaSwpStrategyDetailsFormattedWith3Decimals("Concord Fee %");
			break;
		case "Hide Strategy":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "AAR Base Template":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Comparative Universe":
			uiValue = getSmaSwpStrategyDetails(data);
			break;
		case "Proxy Address Manager":
			uiValue = getProxyAddressManager();
			break;
		case "Proxy Address":
			uiValue = getProxyAddress();
			break;
		case "Voluntary Reorg Address Manager":
			uiValue = getVoluntaryReorgAddressManager();
			break;
		case "Voluntary Reorg Address":
			uiValue = getVoluntaryReorgAddress();
			break;
		case "Interim Address Manager":
			uiValue = getInterimAddressManager();
			break;
		case "InterimAddress":
			uiValue = getInterimAddress();
			break;
		case "Document Link":
			uiValue = requiredDocumentValueForExport(1);
			break;
		case "Document Type":
			uiValue = requiredDocumentValueForExport(0);
			break;
		case "Document Description":
			uiValue = requiredDocumentValueForExport(2);
			break;
		case "Comments":
			uiValue = requiredCommentValueForExport(1);
			break;
		case "Comment Type":
			uiValue = requiredCommentValueForExport(0);
			break;
		case "DVP/Key Trust Template":
			uiValue = getDvpTrustValue();
			break;
		case "Node Timeperiod":
			uiValue = getNodeTimeperiod();
			break;
		case "Bundled Node ID":
			uiValue = getBundledNodeidValue();
			break;
		case "UnBundled Node Id":
			uiValue = getUnbundledNodeidValue();
			break;
		case "Benchmark 1 Timeperiod":
			uiValue = getBenchmarkTimeperiod();
			break;
		case "Custom Benchmark Reason":
			uiValue = getCustomBenchmarkReason();
			break;
		case "Benchmark Category- Style":
			uiValue = getStyleBenchmarkStyle();
			break;
		case "Benchmark Category - Custom":
			uiValue = getCustomBenchmarkStyle();
			break;
		/*
		 * Benchmark1- Style Benchmarks Benchmark1- Custom Benchmarks
		 */
		default:
			uiValue = "check";
			break;
		}
		if (uiValue.equals("—"))
			uiValue = "isEmpty";

		return uiValue;
	}
	
	public String getSmaSwpStrategyDetailsFormatted(String fieldName) {
		Element = action.getElementByFormatingXpath("Common Strategy Value Swp", fieldName);
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		DecimalFormat df = new DecimalFormat(".00");
		String data = df.format(Integer.parseInt(Element.getText())).toString();
		return data;
	}

	public String getSmaSwpStrategyDetailsFormattedWith3Decimals(String fieldName) {
		Element = action.getElementByFormatingXpath("Common Strategy Value Swp", fieldName);
		action.moveToElement(Element);
		action.highligthElement(Element);
		if (Element.getText().trim().equals("—"))
			return "isEmpty";
		DecimalFormat df = new DecimalFormat(".000");
		String data = df.format(Integer.parseInt(Element.getText())).toString();
		return data;
	}
	
	public String getTextfromGridforRow(String value) {
		Element = action.getElementByFormatingXpath("Grid Common Row value", value);
		action.highligthElement(Element);
		return Element.getText();
	}
	
	public String getTextforFirmName() {
		Element = action.fluentWaitWebElement("Firm Name Value");
		action.highligthElement(Element);
		return Element.getText();
	}
	
	public boolean verifyTooltipOfSmaPrint() {
		Element = action.fluentWaitWebElement("SMA Print Button");
		action.moveToElement(Element);
		Element = action.fluentWaitWebElement("SMA Print Tooltip");
		action.highligthElement(Element);
		return Element.isDisplayed();
	}

	public void clickOnSmaPrint() {
		Element = action.fluentWaitWebElement("SMA Print Button");
		action.moveToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
	}
}
