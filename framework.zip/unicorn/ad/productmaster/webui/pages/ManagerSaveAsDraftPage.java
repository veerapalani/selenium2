package qa.unicorn.ad.productmaster.webui.pages;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
public class ManagerSaveAsDraftPage {
	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static String managerFirmName, managerCode = null;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public  ManagerSaveAsDraftPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	public void verifySaveAsdraftbuttoninCreateMManagerPage() {
		action.scrollByPixel("360");
		myElement = action.getElement("SaveAsDraftButton");
		action.highligthElement(myElement);
				Assert.assertTrue(action.isDisplayed(myElement));
				Reporter.addScreenCapture();
			}
	public void clickOnSaveAsdraftbuttoninCreateManagerPage() {
		action.scrollByPixel("360");
		myElement = action.getElement("SaveAsDraftButton");
		action.highligthElement(myElement);
				action.click(myElement);
				Reporter.addScreenCapture();
			}
	
	public void verifySaveAsdraftwizardheading() {
		
		myElement = action.getElement("SaveAsDraftwizardheading");
		action.highligthElement(myElement);
				Assert.assertTrue(action.isDisplayed(myElement));
				Reporter.addScreenCapture();
			}
	public void enterdraftnameindraftwizard() throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("DraftName");
		action.highligthElement(ele);
		action.sendKeyCharterWise(ele, "createdraft@");
		Thread.sleep(500);
	}
	public void enterdraftnameoflessthan3charindraftwizard() throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("DraftName");
		action.highligthElement(ele);
		action.sendKeys(ele, "cr");
		Thread.sleep(500);
	}
	public void clickonsaveasdraftbuttonindraftwizard() throws Throwable {
		action.scrollByPixel(Integer.toString(700));
		WebElement myElement = action.getElement("Save As Draft Button");
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(1000);

	}
	public void validaterrormsgforlessthan3charindraftwizard() {
		
		myElement = action.getElement("Error msg draft");
		action.highligthElement(myElement);
		String actualtxt=myElement.getText();
		String exptxt="Draft Name should not be less than 3 characters";
				Assert.assertEquals(actualtxt,exptxt);
				Reporter.addScreenCapture();
			}
public void validaterrormsgfordraftnameasblankindraftwizard() {
		
		myElement = action.getElement("Error msg draft name as blank");
		action.highligthElement(myElement);
		String actualtxt=myElement.getText();
		String exptxt="Draft Name must not be empty.";
				Assert.assertEquals(actualtxt,exptxt);
				Reporter.addScreenCapture();
			}
	public void clickoncancelbuttonindraftwizard() throws Throwable {
		action.scrollByPixel(Integer.toString(700));
		WebElement myElement = action.getElement("Cancel Button");
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(1000);

	}
}
