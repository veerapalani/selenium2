package qa.unicorn.ad.productmaster.webui.pages;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
public class CreateBenchmarkReviewFlyoutPage {
	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
    WebElement myElement1;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateBenchmark.xlsx";
	String option, sheetName = "";
	int rowIndex;

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public  CreateBenchmarkReviewFlyoutPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	
	public void verifyElementsinCreateBenchmarkflyoutReviewPage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	
	public void assertbenchmarkdescvalue() {
		
		String str1= getTextofReviewbenchmarkdesc("benchmarkdescvalue");
		String str2= getTextofReviewbenchmarkdesc("benchmarkdescreviewvalue");
		Assert.assertEquals(str1, str2);
		Reporter.addStepLog("the actual value of the benhcmark description element value"+str1);
		Reporter.addStepLog("the actual value of the benhcmark description review element value"+str2);
	}
	public String getTextofReviewbenchmarkdesc(String elemName) {
		myElement = action.getElement(elemName);
		action.highligthElement(myElement);
		Reporter.addScreenCapture();
		return myElement.getText();
		
		
	}
	
	public void clickOnnextbuttoninreviewbenchmarkflyout() throws Throwable{
		myElement = action.getElement("Done Button");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public void clickOnEditlink() throws Throwable{
		myElement = action.getElement("Edit Link");
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
}
