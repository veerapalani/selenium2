package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;

public class UpdateStyleConfirmationPage {
	
	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	
	public  UpdateStyleConfirmationPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
		
	}
	
	public void verifyconfirmationheaderinUpdateStyleConfPage() throws InterruptedException {
		Thread.sleep(3000); 
		myElement = action.getElement("Confirmation Header");
		Thread.sleep(2000);
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
			}
	public void verifyUpdateRequestSubmittedMessageinUpdateStyleConfPage() throws InterruptedException {
		Thread.sleep(2000); 
		myElement = action.getElement("Your Update request has been submitted message");
		Thread.sleep(1000);
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
			}
	public void verifystyleidinUpdateStyleconfPage() {
		 myElement = (WebElement) action.getElementByJavascript("Style Id");
		 action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
			}
	public void verifyDoneButtoninUpdateStyleConfPage() throws InterruptedException {
		Thread.sleep(1000); 
		myElement = (WebElement) action.getElementByJavascript("Done Button");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
		action.click(myElement);
		}

	public String getStyleId() {
		//myElement = action.getElement("tagname", "h6");
		myElement = (WebElement) action.getElementByJavascript("Style Id");
		action.highligthElement(myElement);
		String strategyInfo = myElement.getText();
		System.out.println("style Id-01: "+strategyInfo);
		//strategyInfo = strategyInfo.replace("|", ";");
		String message[] = strategyInfo.split("#");
		System.out.println("style Id-02: "+message[0]);
		System.out.println("style Id-03: "+message[1]);
		return message[1].trim();
	}

	public String getStyleName() {
		//myElement = action.getElement("tagname", "h6");
		myElement = (WebElement) action.getElementByJavascript("Style Name");
		action.highligthElement(myElement);
		String strategyInfo = myElement.getText();
		System.out.println("style Name-01: "+strategyInfo);
		//strategyInfo = strategyInfo.replace("|", ";");
		String message[] = strategyInfo.split(":");
		System.out.println("style Name-02: "+message[0]);
		System.out.println("style Name-03: "+message[1]);
		return message[1].trim();
	}

}
