package qa.unicorn.ad.productmaster.webui.pages;



import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateBenchmarkPage {
	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	public static String benchmarkName1, benchmarkCode1 = null;
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public  CreateBenchmarkPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	

	public Boolean isUserOnCreateBenchmarkPage() {
		Boolean flag = false;
		String actUrl = action.getCurrentURL();
		String expUrl = "https://pm.uat.bpsuspm.prd.bfsaws.net/pmui/#/benchmark/add";
		
		Reporter.addStepLog("Actual URL: "+actUrl);
		Reporter.addStepLog("Expected URL: "+expUrl);
		if(actUrl.equalsIgnoreCase(expUrl)) {
			flag = true;
		}
		return flag;
	}
	
	public void enterBenchmarkCode(String benchmarkCodeValue) throws InterruptedException {
		benchmarkCode1 = benchmarkCodeValue + Calendar.getInstance().getTimeInMillis();
		//Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtBenchmarkCode");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, benchmarkCode1);
	}
	
	public void enterBenchmarkName(String benchmarkNameValue) throws InterruptedException {
		benchmarkName1 = benchmarkNameValue;
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtBenchmarkName");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, benchmarkNameValue);
	}
	
	public void enterBenchmarkDescriptionValue(String benchmarkDescriptionValue) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtBenchmarkDescription");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, benchmarkDescriptionValue);
	}
	public void verifyElementsoncreatebenchmarkpage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}
	public void verifybenchmarkheaderinCreateBenchmarkPage() {
		 myElement = action.getElement("Benchmark Name Header");
		action.highligthElement(myElement);
				Assert.assertTrue(action.isDisplayed(myElement));
				Reporter.addScreenCapture();
			}
	public void verifystatusfieldisdisabledincreatebenchmarkpage() {
		myElement = (WebElement) action.getElementByJavascript("Status field");
		action.highligthElement(myElement);
		Assert.assertFalse(action.isEnabled(myElement));
		Reporter.addScreenCapture();
	}
	public void clickOnpreviousandbacklinkoncreatebenchmarkpage(String elementKey) throws Throwable{
		myElement = action.getElement(elementKey);
		action.highligthElement(myElement);
		action.click(myElement);
		  
	}
	public void verifytimestampinCreateBenchmarkPage() {
		 myElement = action.getElement("Timestamp");
		action.highligthElement(myElement);
				Assert.assertTrue(action.isDisplayed(myElement));
				Reporter.addScreenCapture();
			}
	public void enterBenchmarkPercentageValue(String benchmarkPercentageValue) throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("txtBenchmarkPercentage");
		action.highligthElement(ele);
		action.sendkeysClipboard(ele, benchmarkPercentageValue);
	}
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
	public void clickOnNextButton() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement) action.getElement("Next Button"));
		action.captureEntireScreen();
		action.click((WebElement) action.getElement("Next Button"));
	}
	
	public void selectBenchmarkType(String benchmarkTypeKey) throws InterruptedException {
		Thread.sleep(500);
		action.click((WebElement) action.getElementByJavascript("drpDwnBenchmarkType"));
		action.click((WebElement) action.getElementByJavascript("benchmarkTypeKey"));
	}
	
	public Boolean validatingErrorMessage(String key, String expError) {
		Boolean flag = false;
		String actError = action.getElement(key).getText();
		Reporter.addStepLog("Actual Message: "+actError);
		Reporter.addStepLog("Expected Message: "+expError);
		if(actError.equals(expError)) {
			flag = true;
		}
	

		return flag;
	}
}
