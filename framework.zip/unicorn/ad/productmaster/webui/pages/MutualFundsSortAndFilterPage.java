package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class MutualFundsSortAndFilterPage {

	Action action;
	WebElement Element, myElement;

	public MutualFundsSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchMFValue(String MFSearchValue) {
		// Action.pause(2000);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitForJSWebElement("Global Search value MF");
		action.click(Element);
		Element.clear();
		action.pause(1000);
		action.sendKeys(Element, MFSearchValue);
		// Action.pause(5000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		// Action.pause(10000);
	}

	public void clickOnSeeAllResultsForMFLayout() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("See All Result MF Layout");
		// action.scrollToBottom();
		action.click(Element);
	}

	public void verifyTheSearchedResultInAllTabMF() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("All Tab");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void verifyMutualFundTab() {
		Element = (WebElement) action.fluentWaitForJSWebElement("Next Arrow");
		while (Element.isDisplayed()) {

			// Element = (WebElement) action.fluentWaitForJSWebElement("Next Arrow");
			action.highligthElement(Element);
			Element.click();
			action.pause(2000);
		}
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("Mutual Fund Tab");
		action.highligthElement(Element);
		Element.isDisplayed();
		// Action.pause(3000);
		action.click(Element);
		// action.pause(2000);
	}

	public void verifySearchedGridViewDisplay() {
		// Action.pause(4000);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitWebElement("Grid View");
		Element.isDisplayed();
	}

	public void verifyTheSortIconOnMFGridView() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("Sort Icon");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyMFGridViewLabelsWithFilterIcons(WebElement element) {
		// myElement = element;
		// Action.pause(2000);
		action.highligthElement(element);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void verifyMFGridViewLabelsWithSortIcons(WebElement element) {
		// myElement = element;
		// Action.pause(2000);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void mouseHoverOnMFGridViewLabels(WebElement element) {
		myElement = element;
		// Action.pause(2000);
		action.moveToElement(element);
	}

	public void clickOnFundNameSortIcon(WebElement element) {
		// myElement = element;
		// Action.pause(2000);
		action.click(element);
	}

	public String verifyTheSortCoumnPropertyTypeASC() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("Asc Sort");
		// Action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDESC() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("Desc Sort");
		// Action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDefault() {
		action.pause(3000);
		Element = (WebElement) action.getElement("Default Sort");
		// Action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public void clickOnFilterIconForMFGridView(WebElement element) {
		// myElement = element;
		// Action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.jsClick(element);
	}

	public void clickOnFilterConditionForMFGridView(WebElement element) {
		// myElement = element;
		// Action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.click(element);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		// myElement = element;
		// Action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
	}

	public void clickOnFilterSelection() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("Filter Condition");
		action.scrollToElement(Element);
		action.click(Element);
	}

	public void enterFilterValue(String FilterValue) {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("FilterValue");
		Element.click();
		// Action.pause(1000);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForMFGridView() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheMFGridCountAfterScroll() {
		action.pause(4000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterCondition");
		// Action.pause(5000);
		return action.getAttribute(Element, "aria-rowcount");
	}

	public String verifyTheMFGridCountAfterApplyFilterConditionOnTab() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTab");
		// Action.pause(5000);
		return action.getText(Element);
	}

	public void clickOnApplyFilterIconForMFGridViewForReset() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForMFGridViewForCancel() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void verifyTheNoResultsOnGridView() {
		// Action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("No Result found");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public String waitForWebElement(String xpath) {
		int timeLaps = 0;
		String status = "FAIL";
		while (status.equals("FAIL") && timeLaps < 2) {
			try {
				Element = findElementByDynamicXpath(xpath);
				if (Element == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}
			} catch (Exception e) {
				status = "FAIL";
			}
			action.pause(2000);
			++timeLaps;
		}
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);
		return status;
	}

	public void verifyFilteredGridDataViewDisplay() {
		action.isPresent("Grid Data View");
	}

	public String getTextforBenchmarkDescription() {
		myElement = action.fluentWaitWebElement("Grid Benchmark Description");
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String getTextfromGridforRow(String value) {
		myElement = action.getElementByFormatingXpath("Grid Common Row value", value);
		// action.scrollToElement(myElement);
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public void clickOnBenchmarkPrint() {
		action.pause(2000);
		Element = action.fluentWaitWebElement("Benchmark Print Button");
		action.moveToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
	}
}
