package qa.unicorn.ad.productmaster.webui.pages;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateSMASingleAccessStrategyCommentsPage {

	Action action;
	WebElement Element,Highlight;
	int loopCount;
	
	public CreateSMASingleAccessStrategyCommentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public void myClear(WebElement element) {        
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arguments[0].value='';", element);
    }
	
	public void clickOnNext() {
		action.scrollToBottom();
		action.fluentWaitWebElement("NEXT").click();
	}
	
	public void selectCommentsType(String comType) {
		
		Element =(WebElement) action.fluentWaitForJSWebElement("drpDwnCommentType");
		action.click(Element);
		Highlight =(WebElement) action.fluentWaitForJSWebElement("CommenttypeKey");
		List<WebElement> li = action.getElementsFromParentElement(Highlight, "List Values of any Dropdown");
		
		for(WebElement E : li) {
			if(E.getText().equalsIgnoreCase(comType)) {
				Highlight = E;
				break;
			}
		}
		action.scrollToElement(Highlight);
		action.highligthElement(Highlight);
		action.click(Highlight);
	}
	
	public void enterCommentsComment(String com) {
		
		WebElement ele =(WebElement) action.fluentWaitForJSWebElement("txtCommentsComment");
		loopCount = 0;
		do {
			ele.click();
			myClear(ele);
			action.doubleClick(ele);
			action.sendKeys(ele, com);
		} while (!(getCommentCommentValue().equals(com)) && ++loopCount < 10);
		if(loopCount >= 10)
			Assert.fail("User is not able to input Text into Text Field");
	}

	private String getCommentCommentValue() {
		Element = action.waitForJSWebElement("Comments Value");
		String data = Element.getAttribute("value");
		if(data.isEmpty()) {
			return "isEmpty";
		}
		return data;
	}
	
	public void clickOnAddCommentsButton() {
		
		action.fluentWaitWebElement("AddCommentsButton").click();
		
	}
	
	public void clickOnAddAnotherComment() {
		
		action.fluentWaitWebElement("Add Another Comment").click();
		
	}
	
	public boolean isUserOnCommentsPage() {
		action.waitForJSWebElement("SMA Single Access Text");
		Element = action.waitForJSWebElement("Comments Text");
		if(action.getText(Element).equalsIgnoreCase("Comments")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
		
	}
	
}
