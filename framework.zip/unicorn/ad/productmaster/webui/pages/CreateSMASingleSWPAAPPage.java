package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.Assert.assertTrue;

import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateSMASingleSWPAAPPage {
	Action action;
	WebElement Element = null;
	WebElement Highlight = null;
	String[] expErrorlist;
	public static String value;
	List<WebElement> actErrorMessages;
	Boolean flag;

	public CreateSMASingleSWPAAPPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public boolean isUserOnCreateStrategyWizardPage() {
		Action.pause(2000);
		Element = (WebElement)action.getElement("Create Strategy title");
		if(action.getText(Element).equalsIgnoreCase("Create Strategy")) {
			return true;
		}
		return false;
	}

	public void enterStrategyName(String data) {
		Action.pause(2000);
		Element = (WebElement)action.getElementByJavascript("Strategy Name");
		action.sendKeys(Element, data + Calendar.getInstance().getTimeInMillis());
	}

	public void clickOnSMASingleSWPAPPRadioButton() {
		Action.pause(2000);
		// Accessing a Radio Button
		action.jsClick((WebElement)action.getElementByJavascript("SMA - Single (SWP/AAP) button"));
	}

	public void clickOnCreateButton() {
		Action.pause(2000);
		action.click((WebElement)action.getElement("CREATE button"));
		Action.pause(3000);
	}

	public boolean isUserOnEnterStrategyDetailsPage() {
		Action.pause(2000);
		Element = (WebElement)action.getElement("Enter Strategy Details");
		if(action.getText(Element).equalsIgnoreCase("Enter Strategy Details")) {
			return true;
		}
		return false;
	}

	public void strategyCode(String strategycode) {
		Action.pause(2000);
		action.waitForPageLoad();
		Element = (WebElement)action.getElementByJavascript("Search FOA Code");
		Action.pause(2000);
		action.sendKeys(Element, strategycode);
		Action.pause(2000);
		action.sendKeys(Keys.ENTER);
	}

	public void clickOnNextButton() {
		Action.pause(2000);
		Element = ((WebElement)action.getElement("Next button"));
		action.scrollToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
		Action.pause(3000);
	}

	public void verifyElementsOnBenchmarkAndAssectClassificationPage(WebElement element) {
		Element = element;
		action.scrollToElement(element);
		action.highligthElement(Element);
		Assert.assertTrue(action.isDisplayed(Element));
	}

	public void verifyElementsOnProxyDetailsPage(WebElement element) {
		Element = element;
		action.scrollToElement(element);
		action.highligthElement(Element);
		Assert.assertTrue(action.isDisplayed(Element));
	}

	public void verifyElementsOnDocumentsDetailsPage(WebElement element) {
		Element = element;
		action.scrollToElement(element);
		action.highligthElement(Element);
		Assert.assertTrue(action.isDisplayed(Element));
	}

	public void verifyElementsOnCommentsDetailsPage(WebElement element) {
		Element = element;
		action.scrollToElement(element);
		action.highligthElement(Element);
		Assert.assertTrue(action.isDisplayed(Element));
	}

	public void verifyElementsOnReviewDetailsPage(WebElement element) {
		Element = element;
		action.scrollToElement(element);
		action.highligthElement(Element);
		Assert.assertTrue(action.isDisplayed(Element));
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void clickOnSubmitButton() {
		Action.pause(2000);
		Element = ((WebElement)action.getElement("btnSMASWPSubmit"));
		action.scrollToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
		Action.pause(3000);
	}

	// Get Strategy code from SMA Single Access Confirmation page
	public String getStrategyCodeFromSMAAccessConfirmationPage() {
		Action.pause(3000);
		Element = ((WebElement)action.getElement("StrategyCodeSMAAccess"));
		action.scrollToElement(Element);
		action.highligthElement(Element);
		String strategyCode = action.getText(Element);
		Action.pause(3000);
		value = strategyCode.substring(strategyCode.lastIndexOf('|') + 1).trim();
		return value;
	}

	public boolean errorMessages(String experror) {
		flag = false;
		switch(experror) {
			case "Access Strategy Not Found":
				Element = (WebElement)action.getElementByJavascript("Invalid FOA Code");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(experror));
				Reporter.addStepLog("Actual Message: " + Element.getText());
				Reporter.addStepLog("Expected Message: " + experror);
				flag = true;
				break;
			case "Search for Access FOA Code must not be empty or not valid":
				Element = (WebElement)action.getElementByJavascript("Blank FOA Code");
				action.scrollToElement(Element);
				assertTrue(Element.isDisplayed());
				assertTrue(Element.getText().equalsIgnoreCase(experror));
				Reporter.addStepLog("Actual Message: " + Element.getText());
				Reporter.addStepLog("Expected Message: " + experror);
				flag = true;
				break;
			default:
				Reporter.addStepLog("Expected Message: " + experror);
				Reporter.addStepLog("Expected Error Message is invalid ");
				flag = false;
				break;
		}
		return flag;
	}

	public boolean isStrategyCreatedSuccessfully() {
		Element = action.waitForJSWebElement("ConfirmationTickMark");
		if(Element.isDisplayed()) {
			return true;
		}
		return false;
	}

	public boolean isStrategyCreatedMessageDisplayed(String confirmationMessage) {
		Element = action.getElement("ConfirmationMessage");
		if(action.getText(Element).equals(confirmationMessage)) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public String getStrategyCode() {
		Element = action.getElement("FOACode");
		String strategyInfo = Element.getText();
		strategyInfo = strategyInfo.replace("|", ";");
		String message[] = strategyInfo.split(";");
		return message[2].trim();
	}

	public void enterAARBaseTemplate(String aarBaseTemplate) {
		Action.pause(2000);
		Element = action.waitForJSWebElement("AAR Base Template");
		action.scrollToElement(Element);
		action.highligthElement(Element);
		action.click(Element);
		Highlight = action.waitForJSWebElement("AAR Base Template Value");
		action.highligthElement(Highlight);
		action.click(Highlight);
	}

	public void enterstrategyMin(String strategyMin) {
		Action.pause(2000);
		Element = action.waitForJSWebElement("strategyMinswp");
		action.scrollToElement(Element);
		action.highligthElement(Element);
		//action.click(Element);
		//Highlight = action.waitForJSWebElement("strategyMinswp");
		action.highligthElement(Highlight);
		action.sendKeys(Element, "123456789");
	}

	public boolean isDvpKeyTrustTemplateVisible() {
		flag = false;
		action.fluentWaitForJSWebElement("Dvp Key Trust Template");
		Element = action.getElement("Dvp Key Trust Template");
		if(Element.isDisplayed()) {
			action.scrollToElement(Element);
			action.highligthElement(Element);
			flag = true;
		}
		return flag;
	}
}
