package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class UpdateSMASingleAccessStrategyDocumentsPage {

	Action action;
	public UpdateSMASingleAccessStrategyDocumentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element;
	public boolean isUserOnDocumentspage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Documents")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}
	
	public void clickOnNext() {
		
		action.scrollToBottom();
		Element = action.fluentWaitWebElement("NEXT");
				//action.waitForJSWebElement("NEXT");
		Element.click();
	}
}
