package qa.unicorn.ad.productmaster.webui.pages;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
public class CreateManagerDocLinkPage {
	Action action ;// new Action(SQLDriver.getEleObjData(""));
    WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static 	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString ;
	
	public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
	public  CreateManagerDocLinkPage (String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public void clickOnNextButton() throws InterruptedException {
		Thread.sleep(500);
		action.highligthElement((WebElement) action.getElement("Next Button"));
		action.captureEntireScreen();
		action.click((WebElement) action.getElement("Next Button"));
	}
	public List<WebElement> findElementsByDynamicXpath(String xpath){
		Element element = new Element(WebDriverManager.getDriver());
		return element.getElements("xpath", xpath);
	}
	public void selectdoctypevalue() throws InterruptedException {
		Thread.sleep(1000);
		action.jsClick((WebElement) action.getElementByJavascript("drpDwndocumentType"));
		Thread.sleep(1000);
		action.jsClick((WebElement) action.getElementByJavascript("documentypevalue"));
	}
public void enterdocumentcode() throws InterruptedException {
		
		Long time = Calendar.getInstance().getTimeInMillis();
		Thread.sleep(500);
		WebElement ele = (WebElement) action.getElementByJavascript("documentcode");
		action.highligthElement(ele);
		String code="contactcode";
		action.sendkeysClipboard(ele, code+time);
		
	}
public Boolean isUserOnDocLinkPage() {
	Boolean flag = false;
	String expURL = "https://pm.dev.bpsuspm.npd.bfsaws.net/pmui/#/manager/documentLink";
	String actURL = action.getCurrentURL();
	if (actURL.equalsIgnoreCase(expURL)) {
		flag = true;
	}
	return flag;
}
public void enterdocumentlink() throws InterruptedException {
	Thread.sleep(500);
	WebElement ele = (WebElement) action.getElementByJavascript("documentlink");
	action.highligthElement(ele);
	action.sendKeys(ele, "https://google.com");
	
}

public void clickOnPreviousButton() throws InterruptedException {
	Thread.sleep(500);
	action.highligthElement((WebElement) action.getElement("Previous Button"));
	action.captureEntireScreen();
	action.click((WebElement) action.getElement("Previous Button"));
}
public void entercomments() throws InterruptedException {
	Thread.sleep(500);
	WebElement ele = (WebElement) action.getElementByJavascript("documentcomments");
	action.highligthElement(ele);
	action.sendKeys(ele, "comments to be added");
	
}
}
