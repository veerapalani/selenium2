package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class StyleSortAndFilterPage {

	Action action;
	WebElement Element, myElement;
	public static String searchResult;
	public static String value;
	public static String ascSortValue;
	public static String descSortValue;
	public static String defaultSortValue;
	public static String gridCount;
	public static String tabCountAfterCondition;
	public static String gridCountAfterGlobalSearch;

	public StyleSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchStyleValue(String glovalsearchvalue) {
		action.pause(100);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitForJSWebElement("GlobalSearchvalueStyle");
		action.pause(2000);
		Element.click();
		Element.clear();
		action.pause(100);
		action.sendkeysClipboard(Element, glovalsearchvalue);
		action.pause(4000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		action.pause(1000);
	}

	public void clickOnSeeAllResultsForStyleLayout() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("SeeAllResultStyleLayout");
		action.scrollToBottom();
		Element.click();
	}

	public void verifyTheSearchedResultInAllTabForStyle() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("AllTabStyle");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void verifySearchedGridViewDisplay() {
		action.pause(3000);
		Element = (WebElement) action.getElement("GridViewStyle");
		Element.isDisplayed();
	}

	public void verifyAndClickStyleTab() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("StyleTab");
		action.highligthElement(Element);
		Element.isDisplayed();
		action.pause(2000);
		Element.click();
		action.pause(2000);
	}

	public void verifyTheGridCountBeforeApplyFilterAndSortCondition() {
		action.pause(2000);
		Element = (WebElement) action.getElement("GridCountAfterGlobalSearch");
		action.pause(5000);
		gridCountAfterGlobalSearch = action.getAttribute(Element, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		action.pause(2000);
		myElement = (WebElement) action.getElement("NoResultToShow");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		myElement = element;
		action.pause(2000);
		action.moveToElement(element);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		myElement = element;
		action.pause(2000);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		myElement = element;
		action.pause(2000);
		action.highligthElement(myElement);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void clickOnSortIcon(WebElement element) {
		myElement = element;
		action.pause(2000);
		Element.click();
	}

	public void verifyTheSortCoumnPropertyTypeASC() {
		action.pause(5000);
		Element = (WebElement) action.getElement("AscSortOrder");
		ascSortValue = action.getAttribute(Element, "class");
	}

	public void verifyTheSortCoumnPropertyTypeDESC() {
		action.pause(5000);
		Element = (WebElement) action.getElement("DescSortOrder");
		descSortValue = action.getAttribute(Element, "class");
	}

	public void verifyTheSortCoumnPropertyTypeDefault() {
		action.pause(5000);
		Element = (WebElement) action.getElement("DefaultSortOrder");
		defaultSortValue = action.getAttribute(Element, "class");
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		myElement = element;
		action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}

	public void clickOnFilterCondition() {
		action.pause(3000);
		Element = (WebElement) action.getElement("FilterCondition");
		action.click(Element);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		myElement = element;
		action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void verifyTheStyleGridCountAfterApplyFilterConditionOnTab() {
		action.pause(5000);
		Element = (WebElement) action.getElementByJavascript("GridCountAfterfilterConditionOnTabForStyle");
		tabCountAfterCondition = action.getText(Element);
	}

	public void clickOnFilterConditionForStyleGridView(WebElement element) {
		myElement = element;
		action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}

	public void enterFilterValue(String FilterValue) {
		action.pause(2000);
		Element = (WebElement) action.getElement("FilterValue");
		Element.click();
		action.pause(1000);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForStyleGridView() {
		action.pause(2000);
		Element = (WebElement) action.getElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheStyleGridCountAfterScroll() {
		action.pause(5000);
		Element = (WebElement) action.getElement("GridCountAfterfilterCondition");
		String gridAllData = action.getAttribute(Element, "aria-rowcount");
		return gridAllData;
	}

	public void clickOnApplyFilterIconForStyleGridViewForReset() {
		action.pause(2000);
		Element = (WebElement) action.getElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForStyleGridViewForCancel() {
		action.pause(2000);
		Element = (WebElement) action.getElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

}
