package qa.unicorn.ad.productmaster.webui.pages;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.codoid.products.exception.FilloException;

import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;

public class SSOLoginPage {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_SSOLoginPage"));
	private static ThreadLocal<String> TuserName = new ThreadLocal<String>();
	static ThreadLocal<String> Ttype = new ThreadLocal<String>();

	static ProductMasterDBManager pmdb = new ProductMasterDBManager();

	String password;
	public static String URL = "";
	String applicationPropertyFilePath = "./application.properties";
	static String configFilePath = "./config.properties";
	LandingPage landingpage = new LandingPage("AD_PM_LandingPage");
	static PropertyFileUtils configProp = new PropertyFileUtils(configFilePath);

	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);

	/* reading from cmd if available else config file */
	public static String UIEnvironment = System.getProperty("environment", configProp.getProperty("environment"))
			.trim();

	WebDriver tempDriver = null;
	
	String jwtToken = null;
	String user = null;
	String requestJson;
	JSONArray repCodes = null, branch = null, entitlements = null;
	private static ThreadLocal<String> repCodesInString = new ThreadLocal<String>();
	
	public void login(String type) throws InterruptedException, FilloException, SQLException {

		Ttype.set(type);
		if (type.toLowerCase().contains("branch")) {
			Ttype.set("BU");
		} else if (type.equals("BrUser1")) {
			Ttype.set("BrUser1");
		} else if (type.equals("BrUser2")) {
			Ttype.set("BrUser2");
		} else if (!type.equals("HO") && !type.equals("BU") && !type.equals("AA") && !type.equals("BrUser1")
				&& !type.equals("BrUser2")) {
			Ttype.set("HO");
		}
		String sql = "select user_id, password, url, RAND() from pm_user_details where flag = 'NOT USED' and environment = '"
				+ UIEnvironment.toUpperCase() + "' and type = '" + Ttype.get() + "' order by RAND() limit 1";

		String credString = "";
		// System.out.println("SQL: " + sql);

		/* Checking and assigning user to test case */
		synchronized (this) {

			credString = checkUser(sql);

		}

//		System.out.println("CREDENTIALS: " + credString + " | Thread:" + Thread.currentThread().getName());

		String[] creds = credString.split(";");

		String userName = creds[0].trim();
		TuserName.set(userName);
		password = creds[1].trim();
		URL = creds[2].trim();

		System.out.println("User Assigned..[" + TuserName.get() + "] | Thread: " + Thread.currentThread().getName());

		synchronized (this) {

			pmdb.fwDBConnect();
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu/MM/dd HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();
			String executionStart = dtf.format(now);
			String executedBy = System.getProperty("user.name");

			String updateQuery = "Update pm_user_details set flag = 'USED', execution_start = '" + executionStart
					+ "', executed_by ='" + executedBy + "', execution_end = null where user_id = '" + TuserName.get()
					+ "'" + "and type = '" + Ttype.get() + "' and environment = '" + UIEnvironment.toUpperCase() + "'";
			// System.out.println("UPDT: " + updateQuery);
			pmdb.fwExecuteQuery(updateQuery);
			pmdb.fwDBDisconnect();

		}
		/* Performing actions on UI */
		Reporter.addStepLog("User has Launched PM SSO URL Successfully");
		Reporter.addStepLog("<b>Environment: </b>" + UIEnvironment + " | <b>User ID: </b>" + TuserName.get());
		Reporter.addStepLog("<b>URL Launched: </b>: " + URL);

		action.openURL(URL);
		Reporter.addScreenCapture();
		action.sendKeys(action.getElement("UsernameField"), TuserName.get());
		action.sendKeys(action.getElement("PasswordField"), password);
		action.click(action.getElement("LoginButton"));
		action.pause(3000);
		Reporter.addScreenCapture();
		landingpage.verifyProductMasterheaderonlandingpage();
		//Assert.assertTrue(landingpage.isUserOnLandingPage());
		Reporter.addScreenCapture();
	}

	public static synchronized void ReleaseUser() {

		if (TuserName.get() != null) {

			pmdb.fwDBConnect();

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu/MM/dd HH:mm:ss");
			LocalDateTime now = LocalDateTime.now();
			String executionEnd = dtf.format(now);

			System.out.println("Releasing.. [" + TuserName.get() + "] | Thread: " + Thread.currentThread().getName());

			pmdb.fwExecuteQuery("Update pm_user_details set flag = 'NOT USED', execution_end = '" + executionEnd
					+ "' where user_id = '" + TuserName.get() + "' and environment = '" + UIEnvironment.toUpperCase()
					+ "'" + " and type = '" + Ttype.get() + "'");

			System.out.print(" | Released..!!");

			TuserName.remove();
			Ttype.remove();
			pmdb.fwDBDisconnect();

		}

		/* When no user is assigned - For other work stream */
		else {
		}
	}

	static String credentials = "";

	public static String checkUser(String sql) throws SQLException, InterruptedException {
		String sq = sql;
		pmdb.fwDBConnect();
		ResultSet rs = pmdb.fwSelect(sql);

		if (rs.next()) {
			try {
				credentials = rs.getString("user_id") + ";" + rs.getString("password") + ";" + rs.getString("url");
			} catch (Exception e) {

			}
			pmdb.fwDBDisconnect();
		} else {
			Thread.sleep(3000);
			System.out.println("Waiting.. | Thread: " + Thread.currentThread().getName());
			pmdb.fwDBDisconnect();
			checkUser(sq);
		}

		return credentials;

	}

	public Set<Cookie> loginForAPI(String webUIUrl, String usernm, String pwd) {

		try {
			tempDriver = WebDriverManager.getDriver();
			String pageURL = tempDriver.getCurrentUrl();

		} catch (Exception e) {
			WebDriverManager.startDriver();
			tempDriver = WebDriverManager.getDriver();
		}

		Reporter.addStepLog("<b>WebUI URL: </b>" + webUIUrl);
		Reporter.addStepLog("<b>Username: </b>" + usernm);

		action.openURL(webUIUrl);
		action.waitForPageLoad();

		Reporter.addStepLog("User has Launched PM SSO URL Successfully");

		action.sendKeys(action.getElement("UsernameField"), usernm);
		action.sendKeys(action.getElement("PasswordField"), pwd);
		action.click(action.getElement("LoginButton"));

		Set<Cookie> cookieSet = WebDriverManager.getDriver().manage().getCookies();

		WebDriverManager.getDriver().close();
		tempDriver = null;

		return cookieSet;
	}

	public void userLogin(String username2, String password2) {
		String environment = UIEnvironment.toLowerCase();
		switch (environment) {
		case "dev":
			URL = property.getProperty("url_PM_DEV");
			break;
		case "qa":
			URL = property.getProperty("url_PM_QA");
			break;
		case "uat":
			URL = property.getProperty("url_PM_UAT");
			break;

		case "int":
			URL = property.getProperty("url_PM_INT");
			break;
		case "demo":
			URL = property.getProperty("url_PM_DEMO");
			break;
		default:
			Assert.assertTrue(false,
					"Undefined Product Master UI Environment, Please check in application.property file.");
			break;
		}
		action.openURL(URL);
		Reporter.addStepLog("User has Launched PM SSO URL Successfully");
		Reporter.addStepLog("<b>Environment: </b>" + UIEnvironment);
		action.sendKeys(action.getElement("UsernameField"), username2);
		action.sendKeys(action.getElement("PasswordField"), password2);
		Reporter.addCompleteScreenCapture();

		action.click(action.getElement("LoginButton"));
		action.pause(3000);

	}

	public void generateJWTToken() {
		/*
		 * Getting values from framework DB according to "environment" mentioned in
		 * "config.properties" file
		 */
		String keyOrPfxPath = "./src/test/resources/ad/productmaster/api/DataLoadFiles/"
				+ Action.getTestData("certName");
		String URI = Action.getTestData("tokenURI");
		String subjectValue = Action.getTestData("subjectValue");
		String certPass = Action.getTestData("certPass");

		subjectValue = TuserName.get();
		HttpClientUtils.baseUri = URI;
		HttpClientUtils.basePath = "/token";

		RetriveResponse response = HttpClientUtils.given().setHeader("Subject", subjectValue)
				.setProxy("10.98.21.24", 8080).setCetificate(keyOrPfxPath, certPass).buildUri()
				.executeRequest(MethodType.POST);

		int status = response.getStatusCode();

		if (status != 200) {
			Assert.assertTrue(false, "Not able to generate JWT Token, Please Check!");
		}

		Reporter.addStepLog("JWT Token generated successfully for userID - <b>" + subjectValue + "</b>!!");
				jwtToken = (String) response.getBody().jsonPath("token");
	}
	
	public void setRepCodes() throws ParseException {
		user = TuserName.get();

		String[] chunks = jwtToken.split("\\.");

		Base64.Decoder decoder = Base64.getUrlDecoder();

		// String header = new String(decoder.decode(chunks[0])); --not required
		String payload = new String(decoder.decode(chunks[1]));

		/* converting string to JSON Object */
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(payload);

		JSONObject authz = (JSONObject) json.get("authz");

		repCodes = (JSONArray) authz.get("repcodes");
		entitlements = (JSONArray) authz.get("entitlements");
		branch = (JSONArray) authz.get("branch");

		Reporter.addStepLog("<b>RepCodes: </b>" + repCodes.toString().replaceAll("\",\"", "\" , \"").trim().replace("[\"", "(\"").replace("\"]", "\")").replace("\"", "'"));
		Reporter.addStepLog("<b>Branch: </b>" + branch.toString().replaceAll("\",\"", "\" , \""));
		Reporter.addStepLog("<b>Entitlements: </b>" + entitlements.toString().replaceAll("\",\"", "\" , \""));
		
		repCodesInString.set(repCodes.toString().replaceAll("\",\"", "\" , \"").trim().replace("[\"", "(\"").replace("\"]", "\")").replace("\"", "'"));
	}
	
	public static String getRepCodes() {
		return repCodesInString.get();
	}
}
