package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class UpdatePMPStrategyDocumentsPage {

	Action action;
	public UpdatePMPStrategyDocumentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element;
	
	public boolean isUserOnDocumentsPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Enter Document Links")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
		
	}
}
