package qa.unicorn.ad.productmaster.webui.pages;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;

public class UpdateFAPage {
	Action action;
	WebElement Element = null;
	WebElement Highlight = null;
	WebElement myElement;
	String[] expErrorlist;
	List<WebElement> actErrorMessages;
	Boolean flag;
	public static String searchResult;
	public static String value;
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
	String sheetName, sqlQuery = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	int rowIndex;
	XSSFSheet sheet;
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String dbDataIterator = "testNull";

	public UpdateFAPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchFACode(String FAIDorFAName) {
		Action.pause(2000);
		action.waitForPageLoad();
		Element = (WebElement)action.getElementByJavascript("Global Search Box");
		Element.click();
		Element.clear();
		Action.pause(2000);
		action.sendkeysClipboard(Element, FAIDorFAName);
		Action.pause(5000);
		int i = 0;
		while(i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}
		Action.pause(10000);
	}

	public String searchAndEnterFACode(String fa) {
		Action.pause(2000);
		action.waitForPageLoad();
		Element = (WebElement)action.getElementByJavascript("Global Search Box");
		Element.click();
		Element.clear();
		Action.pause(2000);
		action.sendKeys(Element, fa);
		Action.pause(15000);
		int i = 0;
		while(i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}
		return fa;
	}

	public void verifySearchedFACode() {
		Action.pause(7000);
		Element = (WebElement)action.getElementByJavascript("FACodeSearchResult");
		Action.pause(6000);
		searchResult = action.getTextboxValue(Element);
		System.out.println("Search result -------------" + searchResult);
	}

	public void clickOnSeeAllResults() {
		Action.pause(4000);
		Element = (WebElement)action.fluentWaitWebElement("See All Result");
		action.highligthElement(Element);
		Element.click();
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyTheSearchedResultInAllTab() {
		Action.pause(2000);
		Element = (WebElement)action.getElementByJavascript("All Tab");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void verifyFATab() {
		Action.pause(2000);
		Element = (WebElement)action.getElementByJavascript("FAs Tab");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void clickOnFAsTab() {
		Action.pause(2000);
		Element = (WebElement)action.getElementByJavascript("FAs Tab");
		Element.isDisplayed();
		Element.click();
	}

	public void mouseHoveOnSearchedRecordsOnGrid() {
		Action.pause(4000);
		Element = (WebElement)action.getElement("GridViewRecord");
		action.highligthElement(Element);
		action.moveToElement(Element);
	}

	public void clickOnEllipsesIcon() {
		Action.pause(4000);
		Element = (WebElement)action.getElementByJavascript("Ellipses Icon");
		Element.isDisplayed();
		Element.click();
	}

	public void verifyOnViewDetailsLink() {
		Action.pause(2000);
		Element = (WebElement)action.getElementByJavascript("ViewDetails");
		Element.isDisplayed();
	}

	public void clickOnViewDetailsLink() {
		Action.pause(2000);
		Element = (WebElement)action.getElementByJavascript("ViewDetails");
		action.jsClick(Element);
	}

	// Get FA ID / name from FA Confirmation page
	public String getFANameFromFAConfirmationPage() {
		Action.pause(3000);
		Element = ((WebElement)action.getElement("FAName"));
		action.scrollToElement(Element);
		action.highligthElement(Element);
		String faID = action.getText(Element);
		Action.pause(3000);
		String splitValue = faID.substring(faID.indexOf("|")).trim();
		String subSplitFOID = splitValue.substring(splitValue.indexOf(":")).trim();
		value = subSplitFOID.substring(2, 6);
		System.out.println("Final value ---------" + value);
		return value;
	}

	public void enterSubmitterPosition() throws InterruptedException {
		Thread.sleep(1000);
		WebElement ele = (WebElement)action.getElementByJavascript("FAUpdateSubmitterPosition");
		action.highligthElement(ele);
		action.sendKeys(ele, "submitterpositionastest");
		Thread.sleep(1000);
	}

	public void clickonSubmitButonInReviewpage() throws InterruptedException {
		Thread.sleep(1000);
		action.click(action.getElement("SubmitFAUpdate"));
	}

	public void verifyElementsOnConfirmationPage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void verifyAttributesOnViewDetailsPage(WebElement element) {
		Assert.assertTrue(action.isDisplayed(element));
	}

	public String getFAIDFromUpdateDetailsPage() throws InterruptedException {
		Thread.sleep(1000);
		WebElement ele = (WebElement)action.getElementByJavascript("DetailsPageFAIDs");
		action.highligthElement(ele);
		return ele.getText();
	}

	public WebElement getDynamicElementFromShadowRoot(String javaScript) {
		return myElement = (WebElement)action.executeJavaScript(javaScript);
	}

	public String getFaCodeFromDbWithStatus(String faStatus) throws SQLException {
		sheetName = "Query";
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, "FACodeWithStatus");
		sqlQuery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
		//System.out.println("sql1:" + sqlQuery);
		sqlQuery = sqlQuery.replace("@data", "'" + faStatus + "'");
		//System.out.println("sql2:" + sqlQuery);
		pmdb.DBConnectionStart();
		ResultSet result = DBManager.executeSelectQuery(sqlQuery);
		while(result.next()) {
			dbDataIterator = result.getString(1);
			if(result.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
		}
		//to handle Zero records from DB 
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		pmdb.DBConnectionClose();
		return dbDataIterator;
	}
}
