package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class CreateFinancialAdvisorPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement, elementValue;
	String fieldValue = "";

	public CreateFinancialAdvisorPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void selectFAId(String FAId) throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("drpFAId"));
		action.click((WebElement) action.fluentWaitForJSWebElement("FAIdKey"));
	}

	public void enterFADiscretionaryProgram(String FADiscretionaryProgram) throws InterruptedException {
		action.click((WebElement) action.getElementByJavascript("drpFADiscretionaryProgram"));
		action.click((WebElement) action.getElementByJavascript("FADiscretionaryProgramKey"));
	}

	public void enterBranchManagername(String BranchManagerName) throws InterruptedException {

		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtBranchManagerName");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("BranchManagerNameValue");
		//action.clear(ele);
		//action.sendKeys(ele, BranchManagerName);
		PMPageGeneric.enterTextandVerify(ele, elementValue, BranchManagerName);
	}

	public void enterFAname(String FAName) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtFAName");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("FANameValue");
		//action.clear(ele);
		//action.sendKeys(ele, FAName);
		PMPageGeneric.enterTextandVerify(ele, elementValue, FAName);
	}

	public void enterFAemail(String FAEmail) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtFAEmail");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("FAEmailValue");
		PMPageGeneric.enterTextandVerify(ele, elementValue, "test@gmail.com");
	}

	public void enterPriorFirm(String PriorFirm) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtPriorFirm");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("PriorFirmValue");
		//action.clear(ele);
		//action.sendKeys(ele, PriorFirm);
		PMPageGeneric.enterTextandVerify(ele, elementValue, PriorFirm);
	}

	public void enterLengthOfSeries7Registration(String LengthOfSeries7Registration) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtLengthOfSeries7Registration");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("LengthOfSeries7RegistrationValue");
		//action.clear(ele);
		//action.sendKeys(ele, "156");
		PMPageGeneric.enterTextandVerify(ele, elementValue, "156");
	}

	public void enterLengthOfSeries65(String LengthOfSeries65) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtLengthOfSeries65");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("LengthOfSeries65Value");
		//action.clear(ele);
		//action.sendKeys(ele, "567");
		PMPageGeneric.enterTextandVerify(ele, elementValue, "567");
	}

	public void enterLengthOfService(String LengthOfService) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtLengthOfService");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("LengthOfServiceValue");
		//action.clear(ele);
		//action.sendKeys(ele, "890");
		PMPageGeneric.enterTextandVerify(ele, elementValue, "890");
	}

	public void enterAnticipatedpercentageofoverallbusiness(String Anticipatedpercentageofoverallbusiness)
			throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtAnticipatedpercentageofoverallbusiness");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("AnticipatedpercentageofoverallbusinessValue");
		//action.clear(ele);
		//action.sendKeys(ele, "789");
		PMPageGeneric.enterTextandVerify(ele, elementValue, "789");
	}

	public void enterFAAUM(String FAAUM) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtFAAUM");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("FAAUMValue");
		//action.clear(ele);
		//action.sendKeys(ele, "789");
		PMPageGeneric.enterTextandVerify(ele, elementValue, "789");
	}

	public void choosePreviouslyApprovedForFADiscretionary(String PreviouslyApprovedForFADiscretionary)
			throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("PreviouslyApprovedForFADiscretionary"));

	}

	public void selectRecruitHireDate(String RecruitHireDate) throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("selectRecruitHireDatetype"));
		action.click((WebElement) action.fluentWaitForJSWebElement("selectRecruitHireDatetypevalue"));
	}

	public void chooseISNominationForrecruit(String ISNominationForrecruit) throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("ISNominationForrecruit"));

	}

	public void chooseCFA(String CFA) throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("CFA"));

	}

	public void enterBranch(String Branch) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtBranch");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("BranchValue");
		//action.clear(ele);
		//action.sendKeys(ele, Branch);
		PMPageGeneric.enterTextandVerify(ele, elementValue, Branch);
	}

	public void enterComplex(String Complex) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtComplex");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("ComplexValue");
		//action.clear(ele);
		//action.sendKeys(ele, Complex);
		PMPageGeneric.enterTextandVerify(ele, elementValue, Complex);
	}

	public void enterDivision(String Division) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtDivision");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("DivisionValue");
		//action.clear(ele);
		//action.sendKeys(ele, Division);
		PMPageGeneric.enterTextandVerify(ele, elementValue, Division);
	}

	public void enterRegion(String Region) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtRegion");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("RegionValue");
		//action.clear(ele);
		//action.sendKeys(ele, Region);
		PMPageGeneric.enterTextandVerify(ele, elementValue, Region);
	}

	public void chooseWaive(String Waive) throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("Waive"));

	}

	public void enterAwards(String Awards) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtAwards");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("AwardsValue");
		//action.clear(ele);
		//action.sendKeys(ele, Awards);
		PMPageGeneric.enterTextandVerify(ele, elementValue, Awards);
	}

	public void enterAddInfo(String AddInfo) throws InterruptedException {
		WebElement ele = (WebElement) action.fluentWaitForJSWebElement("txtAddINfo");
		action.highligthElement(ele);
		elementValue = action.fluentWaitWebElement("AddINfoValue");
		//action.clear(ele);
		//action.sendKeys(ele, AddInfo);
		PMPageGeneric.enterTextandVerify(ele, elementValue, AddInfo);
	}

	public void clickonnextbutton() {
		action.pause(2000);
		WebElement ele = action.fluentWaitWebElement("NEXTbutton");
		action.highligthElement(ele);
		action.click(ele);
	}

	public void Isnominationforarecruit() throws InterruptedException {
		WebElement IsNomi = (WebElement) action.fluentWaitForJSWebElement("ISNominationForrecruit");
		action.click(IsNomi);
		if (IsNomi.isSelected()) {
			WebElement ele = (WebElement) action.fluentWaitForJSWebElement("RecruitHireDatemandatoryfield");
			action.highligthElement(ele);
			Assert.assertTrue(ele.isDisplayed());
		}
	}

	public void clickoncancelbutton() {
		action.scrollToBottom();
		action.fluentWaitWebElement("cancelbutton").click();
	}

	public void selectFASegment(String fASegment) throws InterruptedException {
		action.click((WebElement) action.fluentWaitForJSWebElement("drpFASegment"));
		action.click((WebElement) action.fluentWaitForJSWebElement("FASegementKey"));

	}

	public void validateFieldValues(String element, String value) throws InterruptedException {
		myElement = action.fluentWaitWebElement(element);
		action.highligthElement(myElement);
		fieldValue = myElement.getAttribute("value");
		Assert.assertTrue(fieldValue.equals(value));
	}

	public boolean isRenominationDateVisible() {
		myElement = action.getElementByFormatingXpath("Renomination", "No");
		Assert.assertTrue(myElement.isDisplayed());
		action.click(myElement);
		return action.isDisplayed((WebElement) action.getElementByJavascript("RenominationDate"));
	}

	public void highlightfateam() throws InterruptedException {
		Thread.sleep(5000);
		WebElement ele = (WebElement) action.getElementByJavascript("highlightelementfaname");

		action.highligthElement(ele);
		WebElement ele1 = (WebElement) action.getElementByJavascript("highlightteamnames");
		action.highligthElement(ele1);
		// highlightteamnames
		Reporter.addCompleteScreenCapture();
	}

	public boolean isCreateFinancialAdvisorVisible() {
		myElement = action.fluentWaitWebElement("CreateFinancialAdvisor");
		return action.isDisplayed(myElement);
	}

	public void clickOnResetbutton() {
		WebElement ele = action.fluentWaitWebElement("ResetButton");
		action.highligthElement(ele);
		action.click(ele);
		Reporter.addScreenCapture();
	}
}
