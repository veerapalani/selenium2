package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class RejectedStrategiesSortAndFilterPage {

	Action action;
	WebElement Element, myElement;
	Boolean flag;

	public RejectedStrategiesSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void verifyAndClickRejectedStrategiesTab() {
		Element = (WebElement) action.fluentWaitForJSWebElement("Next Arrow");
		while (Element.isDisplayed()) {

			// System.out.println("Inside While loop");
			// Element = (WebElement) action.fluentWaitForJSWebElement("Next Arrow");
			action.highligthElement(Element);
			Element.click();
			action.pause(2000);

		}
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("RejectedStrategiesTab");
		// Action.pause(2000);
		action.highligthElement(Element);
		Element.isDisplayed();
		Action.pause(2000);
		Element.click();
		action.pause(2000);
		Reporter.addCompleteScreenCapture();
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		myElement = element;
		Action.pause(2000);
		action.moveToElement(element);
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		myElement = element;
		Action.pause(2000);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		myElement = element;
		Action.pause(2000);
		action.highligthElement(myElement);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void clickOnSortIcon(WebElement element) {
		myElement = element;
		Action.pause(2000);
		Element.click();
	}

	public String verifyTheGridCountBeforeApplyFilterAndSortCondition() {
		Action.pause(5000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountRejectedStrategies");
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		// Action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public String verifyTheRejectedStrategiesGridCountAfterApplyFilterConditionOnTab() {
		Action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionRejectedStrategies");
		Action.pause(5000);
		return action.getText(Element);
	}

	public void clickOnFilterCondition() {
		// Action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("FilterCondition");
		action.click(Element);
	}

	public void clickOnFilterConditionForRejectedStrategiesGridView(WebElement element) {
		myElement = element;
		Action.pause(2000);
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
		action.click(myElement);
	}

	public void enterFilterValue(String FilterValue) {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("FilterValue");
		Element.click();
		Action.pause(1000);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForRejectedStrategiesGridView() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheRejectedStrategiesGridCountAfterScroll() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterConditionRS");
		Action.pause(5000);
		String gridAllData = action.getAttribute(Element, "aria-rowcount");
		return gridAllData;
	}

	public void clickOnApplyFilterIconForRejectedStrategiesGridViewForReset() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForRejectedStrategiesGridViewForCancel() {
		// Action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

}
