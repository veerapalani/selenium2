package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;

public class ProgramDetailsPage {
	
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ProgramDetailsPage"));
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	WebElement myElement;
	List<String> list = new ArrayList<String>();

	public List<WebElement> getElements(String key){
		listOfElements = action.getElements(key);
		return listOfElements;
		
	}
	
	public void hoverOnElement(WebElement hoverElement) {
		action.moveToElement(hoverElement);
	}
	public WebElement getstyleheadertext() {
		return action.getElement("Program Name");
	}
	public String getHeaderText() {

		String header = action.getElement("HeaderKey").getText();
		return header;
	}
	
	public void verifyElement(String elementKey) {
		myElement = action.getElement(elementKey);
		Assert.assertTrue(action.isDisplayed(myElement));
		}
	
	public void verifyGhostText(String expectedGhostText, String boxKey) {
		myElement = action.getElement(boxKey);
		String actualGhostText = myElement.getAttribute("placeholder");
		Assert.assertEquals( actualGhostText,expectedGhostText);
	}
	
	public void verifyTextInListOfElements(String text, List<WebElement> list1) {
		
		for (int i=0;i< list1.size();i++) {
			list.add(list1.get(i).getText());
		}
		Assert.assertTrue(list.contains(text));
	}
	
}
