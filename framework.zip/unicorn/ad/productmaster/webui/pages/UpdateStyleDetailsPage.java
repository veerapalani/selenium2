package qa.unicorn.ad.productmaster.webui.pages;

import static org.junit.Assert.assertFalse;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class UpdateStyleDetailsPage {
	Action action;
	WebElement Element = null;
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
	// TDR10_Styledatareport
	String sheetName = "TDR10_DataValidation", sheetName1 = "Style_DBValidation";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet = exlObj.getSheet(sheetName1);
	int cellnum = 3;
	int count = 0;

	public UpdateStyleDetailsPage(String pageName) {

		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void myClear(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		js.executeScript("arguments[0].value='';", element);
	}

	public void sendKeysWithCheck(WebElement element, String value) {
		try {
			action.sendKeys(element, value);
			while (true) {
				Thread.sleep(500);
				if (!(element.getAttribute("value").trim().equalsIgnoreCase(value))) {
					myClear(element);
					// action.clear(element);
					action.sendKeys(element, value);
				} else {
					System.out.println("Input :" + element.getAttribute("value"));
					break;
				}
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	public void isUserOnCreateStyleEnterInvestmentStyleDetailsPage() throws InterruptedException {
		Thread.sleep(2000);
		WebElement eisdelement = (WebElement) action.getElementByJavascript("Enter Investment Style Details Header");
		action.moveToElement(eisdelement);
		action.highligthElement(eisdelement);
		Thread.sleep(1000);
	}

	public void enterInvestmentStyleName(String investmentStyleName) throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Investment Style Name");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		/*
		 * ele.clear(); Thread.sleep(1000); action.sendKeys(ele, investmentStyleName);
		 */
		sendKeysWithCheck(ele, investmentStyleName);
	}

	public void enterRiskCategory() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Risk Category");
		Thread.sleep(1000);
		action.moveToElement(ele);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Risk Category Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterBaseTemplate() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Base Template");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Base Template Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterFeeScheduleType(String piv_Y, String piv_N) throws InterruptedException {

		Boolean flag1 = Boolean.parseBoolean(piv_Y);
		Boolean flag2 = Boolean.parseBoolean(piv_N);
		if (flag1 == false) {
			WebElement ele = (WebElement) action.getElementByJavascript("PIV Style N");
			Thread.sleep(1000);
			action.doubleClick(ele);
			action.highligthElement(ele);
			Thread.sleep(2000);
			System.out.println("Ele is Selected = " + ele.isSelected());
			if (ele.isSelected() == flag1) {
				WebElement ele1 = (WebElement) action.getElementByJavascript("Fee Schedule Type");
				action.highligthElement(ele1);
				ele1.click();
				Thread.sleep(2000);
				WebElement ele2 = (WebElement) action.getElementByJavascript("Fee Schedule Type Data");
				action.highligthElement(ele2);
				ele2.click();
				Thread.sleep(1000);
			}
		} else {
			WebElement ele3 = (WebElement) action.getElementByJavascript("PIV Style Y");
			Thread.sleep(1000);
			ele3.click();
			action.highligthElement(ele3);
			Thread.sleep(2000);
			System.out.println("Ele is Selected = " + ele3.isSelected());
			if (ele3.isSelected() == flag2) {
				WebElement ele4 = (WebElement) action.getElementByJavascript("Fee Schedule Type");
				action.highligthElement(ele4);
				assertFalse(ele4.isEnabled());
				Thread.sleep(1000);
			}

		}

	}

	public void enterStyleCategory() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Style Category");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Style Category Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterBalancedAllocation() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Balanced Allocation");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Balanced Allocation Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterComparativeUniverse() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Comparative Universe");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Universe Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterGeographicIndicator() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Geographic Indicator");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Geographic Indicator Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterMarketCap() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Market Cap");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Market Cap Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterHomeOfficeComments(String hocomments) throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Home Office Comments");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		/*
		 * ele.clear(); Thread.sleep(1000); action.sendKeys(ele, hocomments);
		 */
		sendKeysWithCheck(ele, hocomments);
		Thread.sleep(1000);
	}

	public void clickOnNextButton1() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Next Button 1");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(3000);
		ele.click();
		Reporter.addCompleteScreenCapture();
		Thread.sleep(3000);

	}

	public void clickOnNextButton3() throws InterruptedException {

		WebElement ele = action.getElement("Next Button 3");
		action.highligthElement(ele);
		Thread.sleep(3000);
		Reporter.addCompleteScreenCapture();
		action.doubleClick(ele);
		Thread.sleep(1000);

	}

	public void isUserOnBenchmarkandAssetClassificationHeaderPage() throws InterruptedException {
		Thread.sleep(1000);
		WebElement eisdelement = (WebElement) action
				.getElementByJavascript("Benchmark and Asset Classification Header");
		action.moveToElement(eisdelement);
		action.highligthElement(eisdelement);
		Thread.sleep(1000);
	}

	public void enterBundledAssetClassification() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Bundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Bundled Asset Classification Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
	}

	public void enterSingleUnbundledAssetClassification() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Unbundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele2);
		ele2.click();
		ele2.clear();
		Thread.sleep(2000);
		WebElement ele3 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		ele3.clear();
		action.sendKeys(ele3, "100.00");
		Thread.sleep(1000);
	}

	public void enterMultipleUnbundledAssetClassification() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Unbundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele2);
		ele2.click();
		ele2.clear();
		Thread.sleep(2000);
		WebElement ele3 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele3);
		ele3.clear();
		action.sendKeys(ele3, "60.00");
		Thread.sleep(1000);
		WebElement ele4 = (WebElement) action.getElement("Add New Asset Classification");
		action.highligthElement(ele4);
		ele4.click();
		Thread.sleep(1000);
		WebElement ele5 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification2");
		action.highligthElement(ele5);
		ele5.click();
		Thread.sleep(1000);
		WebElement ele6 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data2");
		action.highligthElement(ele6);
		ele6.click();
		Thread.sleep(1000);
		WebElement ele7 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage2");
		action.highligthElement(ele7);
		ele7.click();
		ele7.clear();
		Thread.sleep(2000);
		WebElement ele8 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage2");
		ele8.clear();
		action.sendKeys(ele8, "40.00");
		Thread.sleep(1000);
	}

	public void enterSingleComparativeBenchmark(String sb_1, String cb_2) throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			action.jsClick(ele);
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom");
			Thread.sleep(3000);
			action.highligthElement(ele);
			action.jsClick(ele);
			Thread.sleep(1000);
			WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
			action.highligthElement(ele1);
			action.jsClick(ele1);
			Thread.sleep(1000);
			WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
			action.highligthElement(ele2);
			ele2.click();
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			Thread.sleep(2000);
			WebElement ele4 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele4);
			ele4.clear();
			action.sendKeys(ele4, "100.00");
			Thread.sleep(1000);
		}
	}

	public void enterMultipleComparativeBenchmark(String sb_1, String cb_2) throws InterruptedException {

		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			action.jsClick(ele);
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom");
			Thread.sleep(3000);
			action.highligthElement(ele);
			action.jsClick(ele);
			Thread.sleep(1000);
			WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
			action.highligthElement(ele1);
			action.jsClick(ele1);
			Thread.sleep(1000);
			WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
			action.highligthElement(ele2);
			ele2.click();
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			Thread.sleep(2000);
			WebElement ele4 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele4);
			ele4.clear();
			action.sendKeys(ele4, "60.00");
			Thread.sleep(2000);
			WebElement ele5 = (WebElement) action.getElement("Add New Benchmark");
			action.highligthElement(ele5);
			ele5.click();
			Thread.sleep(1000);
			WebElement ele6 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data2");
			action.jsClick(ele6);
			action.highligthElement(ele6);
			Thread.sleep(1000);
			WebElement ele7 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark2");
			action.highligthElement(ele7);
			ele7.click();
			Thread.sleep(1000);
			WebElement ele8 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage2");
			action.highligthElement(ele8);
			ele8.click();
			ele8.clear();
			Thread.sleep(2000);
			WebElement ele9 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage2");
			action.highligthElement(ele9);
			ele9.clear();
			action.sendKeys(ele9, "40.00");
			Thread.sleep(2000);
		}
	}

	public void clickOnNextButton2() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Next Button 2");
		action.scrollToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(3000);
		ele.click();
		/*
		 * Thread.sleep(2000); ele.click();
		 */
		Reporter.addCompleteScreenCapture();
		Thread.sleep(3000);

	}

	public void clickOnPreviousButton1InBenchmarkPage() throws InterruptedException {
		WebElement ele = action.getElement("Previous Button 1");
		action.moveToElement(ele);
		action.highligthElement(ele);
		Thread.sleep(3000);
		ele.click();
		Reporter.addCompleteScreenCapture();
		Thread.sleep(3000);
	}

	public void compareStyleSearchToken(String token1) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Investment Style Name");
		Thread.sleep(1000);
		action.highligthElement(ele);
		ele.click();
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Style Name UI Element Value=" + ele.getAttribute("value"));
		System.out.println("Style Name DB Token Value=" + token1);
		String eleisnull1 = (String) ele.getAttribute("value");

		if (ele.getAttribute("value") == null && token1 == "isempty") {
			eleisnull1 = "isempty";
			exlObj.setCellData(sheet, 2, cellnum, eleisnull1);
			exlObj.setCellData(sheet, 2, cellnum + 1, token1);
			Assert.assertTrue(eleisnull1.equals(token1));

		} else if (ele.getAttribute("value") == null && token1 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Style Name UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Style Name DB Token Value=" + token1);
			Reporter.addStepLog("UI and DB Values of Style Name doesn't match");
			exlObj.setCellData(sheet, 2, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 2, cellnum + 1, token1);
			exlObj.setCellData(sheet, 2, cellnum + 2, "UI and DB Values Style Name doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token1, "UI and DB Values of Style Name doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getAttribute("value").equals(token1)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 2, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 2, cellnum + 1, token1);
			Assert.assertTrue(ele.getAttribute("value").equals(token1));

		} else {
			System.out.println("else check");
			Reporter.addStepLog("Style Name UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Style Name DB Token Value=" + token1);
			Reporter.addStepLog("UI and DB Values of Style Name doesn't match");
			exlObj.setCellData(sheet, 2, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 2, cellnum + 1, token1);
			exlObj.setCellData(sheet, 2, cellnum + 2, "UI and DB Values Style Name doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token1, "UI and DB Values of Style Name doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareRiskCategoryToken(String token2) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Compare Risk Category");
		Thread.sleep(1000);
		action.highligthElement(ele);
		ele.click();
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Risk Category UI Element Value=" + ele.getAttribute("value"));
		System.out.println("Risk Category DB Token Value=" + token2);
		String eleisnull2 = (String) ele.getAttribute("value");
		if (ele.getAttribute("value") == null && token2 == "isempty") {
			eleisnull2 = "isempty";
			exlObj.setCellData(sheet, 3, cellnum, eleisnull2);
			exlObj.setCellData(sheet, 3, cellnum + 1, token2);
			Assert.assertTrue(eleisnull2.equals(token2));
		} else if (ele.getAttribute("value") == null && token2 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Risk Category UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Risk Category DB Token Value=" + token2);
			Reporter.addStepLog("UI and DB Values of Risk Category doesn't match");
			exlObj.setCellData(sheet, 3, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 3, cellnum + 1, token2);
			exlObj.setCellData(sheet, 3, cellnum + 2, "UI and DB Values of Risk Category doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token2, "UI and DB Values of Risk Category doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getAttribute("value").equals(token2)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 3, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 3, cellnum + 1, token2);
			Assert.assertTrue(ele.getAttribute("value").equals(token2));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Risk Category UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Risk Category DB Token Value=" + token2);
			Reporter.addStepLog("UI and DB Values of Risk Category doesn't match");
			exlObj.setCellData(sheet, 3, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 3, cellnum + 1, token2);
			exlObj.setCellData(sheet, 3, cellnum + 2, "UI and DB Values of Risk Category doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token2, "UI and DB Values of Risk Category doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void comparePIVStyleToken(String token3) throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(token3);
		if (flag1 == false) {
			WebElement ele = (WebElement) action.getElementByJavascript("N PIV Style");
			Thread.sleep(1000);
			action.highligthElement(ele);
			action.doubleClick(ele);
			Thread.sleep(2000);
			Reporter.addScreenCapture();
			System.out.println("PIV Style UI Element Value=" + ele.getAttribute("value"));
			System.out.println("PIV Style DB Token Value=" + token3);
			String eleisnull3 = (String) ele.getAttribute("value");
			if (ele.getAttribute("value") == null && token3 == "isempty") {
				eleisnull3 = "isempty";
				exlObj.setCellData(sheet, 4, cellnum, eleisnull3);
				exlObj.setCellData(sheet, 4, cellnum + 1, token3);
				Assert.assertTrue(eleisnull3.equals(token3));
			} else if (ele.getAttribute("value") == null && token3 != "isempty") {
				System.out.println("Else If1 check");
				Reporter.addStepLog("PIV Style UI Element Value=" + ele.getAttribute("value"));
				Reporter.addStepLog("PIV Style DB Token Value=" + token3);
				Reporter.addStepLog("UI and DB Values of PIV Style doesn't match");
				exlObj.setCellData(sheet, 4, cellnum, ele.getAttribute("value"));
				exlObj.setCellData(sheet, 4, cellnum + 1, token3);
				exlObj.setCellData(sheet, 4, cellnum + 2, "UI and DB Values of PIV Style doesn't match");
				Assert.assertFalse(ele.getAttribute("value") == token3, "UI and DB Values of PIV Style doesn't match");
				count = count + 1;
				System.out.println("Count Before= " + count);
			} else if (ele.getAttribute("value").equals(token3)) {
				System.out.println("Else If check");
				exlObj.setCellData(sheet, 4, cellnum, ele.getAttribute("value"));
				exlObj.setCellData(sheet, 4, cellnum + 1, token3);
				Assert.assertTrue(ele.getAttribute("value").equals(token3));
			} else {
				System.out.println("else check");
				Reporter.addStepLog("PIV Style UI Element Value=" + ele.getAttribute("value"));
				Reporter.addStepLog("PIV Style DB Token Value=" + token3);
				Reporter.addStepLog("UI and DB Values of PIV Style doesn't match");
				exlObj.setCellData(sheet, 4, cellnum, ele.getAttribute("value"));
				exlObj.setCellData(sheet, 4, cellnum + 1, token3);
				exlObj.setCellData(sheet, 4, cellnum + 2, "UI and DB Values of PIV Style doesn't match");
				Assert.assertFalse(ele.getAttribute("value") == token3, "UI and DB Values of PIV Style doesn't match");
				count = count + 1;
				System.out.println("Count Before= " + count);
			}
		} else {
			WebElement ele = (WebElement) action.getElementByJavascript("Y PIV Style");
			Thread.sleep(1000);
			action.highligthElement(ele);
			action.doubleClick(ele);
			Thread.sleep(2000);
			Reporter.addScreenCapture();
			System.out.println("PIV Style UI Element Value=" + ele.getAttribute("value"));
			System.out.println("PIV Style DB Token Value=" + token3);
			String eleisnull3 = (String) ele.getAttribute("value");
			if (ele.getAttribute("value") == null && token3 == "isempty") {
				eleisnull3 = "isempty";
				exlObj.setCellData(sheet, 4, cellnum + 1, eleisnull3);
				exlObj.setCellData(sheet, 4, cellnum + 1, token3);
				Assert.assertTrue(eleisnull3.equals(token3));
			} else if (ele.getAttribute("value") == null && token3 != "isempty") {
				System.out.println("Else If1 check");
				Reporter.addStepLog("PIV Style UI Element Value=" + ele.getAttribute("value"));
				Reporter.addStepLog("PIV Style DB Token Value=" + token3);
				Reporter.addStepLog("UI and DB Values of PIV Style doesn't match");
				exlObj.setCellData(sheet, 4, cellnum, ele.getAttribute("value"));
				exlObj.setCellData(sheet, 4, cellnum + 1, token3);
				exlObj.setCellData(sheet, 4, cellnum + 2, "UI and DB Values of PIV Style doesn't match");
				Assert.assertFalse(ele.getAttribute("value") == token3, "UI and DB Values of PIV Style doesn't match");
				count = count + 1;
				System.out.println("Count Before= " + count);
			} else if (ele.getAttribute("value").equals(token3)) {
				System.out.println("Else If2 check");
				exlObj.setCellData(sheet, 4, cellnum, ele.getAttribute("value"));
				exlObj.setCellData(sheet, 4, cellnum + 1, token3);
				Assert.assertTrue(ele.getAttribute("value").equals(token3));
			} else {
				System.out.println("else check");
				Reporter.addStepLog("PIV Style UI Element Value=" + ele.getAttribute("value"));
				Reporter.addStepLog("PIV Style DB Token Value=" + token3);
				Reporter.addStepLog("UI and DB Values of PIV Style doesn't match");
				exlObj.setCellData(sheet, 4, cellnum, ele.getAttribute("value"));
				exlObj.setCellData(sheet, 4, cellnum + 1, token3);
				exlObj.setCellData(sheet, 4, cellnum + 2, "UI and DB Values of PIV Style doesn't match");
				Assert.assertFalse(ele.getAttribute("value") == token3, "UI and DB Values of PIV Style doesn't match");
				count = count + 1;
				System.out.println("Count Before= " + count);
			}
		}

	}

	public void compareFeeScheduleTypeToken(String token4) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Compare Fee Schedule Type");
		Thread.sleep(1000);
		action.highligthElement(ele);
		action.doubleClick(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Fee Schedule Type UI Element Value=" + ele.getAttribute("value"));
		System.out.println("Fee Schedule Type DB Token Value=" + token4);
		String eleisnull4 = (String) ele.getAttribute("value");
		if (ele.getAttribute("value") == null && token4 == "isempty") {
			eleisnull4 = "isempty";
			exlObj.setCellData(sheet, 5, cellnum, eleisnull4);
			exlObj.setCellData(sheet, 5, cellnum + 1, token4);
			Assert.assertTrue(eleisnull4.contains(token4));
		} else if (ele.getAttribute("value") == null && token4 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Fee Schedule Type UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Fee Schedule Type DB Token Value=" + token4);
			Reporter.addStepLog("UI and DB Values of Fee Schedule Type doesn't match");
			exlObj.setCellData(sheet, 5, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 5, cellnum + 1, token4);
			exlObj.setCellData(sheet, 5, cellnum + 2, "UI and DB Values of Fee Schedule Type doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token4,
					"UI and DB Values of Fee Schedule Type doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getAttribute("value").equals(token4)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 5, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 5, cellnum + 1, token4);
			Assert.assertTrue(ele.getAttribute("value").contains(token4));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Fee Schedule Type UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Fee Schedule Type DB Token Value=" + token4);
			Reporter.addStepLog("UI and DB Values of Fee Schedule Type doesn't match");
			exlObj.setCellData(sheet, 5, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 5, cellnum + 1, token4);
			exlObj.setCellData(sheet, 5, cellnum + 2, "UI and DB Values of Fee Schedule Type doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token4,
					"UI and DB Values of Fee Schedule Type doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareStyleCategoryToken(String token5) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Compare Style Category");
		Thread.sleep(1000);
		action.highligthElement(ele);
		action.doubleClick(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Style Category UI Element Value=" + ele.getAttribute("value"));
		System.out.println("Style Category DB Token Value=" + token5);
		String eleisnull5 = (String) ele.getAttribute("value");
		if (ele.getAttribute("value") == null && token5 == "isempty") {
			eleisnull5 = "isempty";
			exlObj.setCellData(sheet, 6, cellnum, eleisnull5);
			exlObj.setCellData(sheet, 6, cellnum + 1, token5);
			Assert.assertTrue(eleisnull5.equals(token5));
		} else if (ele.getAttribute("value") == null && token5 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Style Category UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Style Category DB Token Value=" + token5);
			Reporter.addStepLog("UI and DB Values of Style Category doesn't match");
			exlObj.setCellData(sheet, 6, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 6, cellnum + 1, token5);
			exlObj.setCellData(sheet, 6, cellnum + 2, "UI and DB Values of Style Category doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token5, "UI and DB Values of Style Category doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getAttribute("value").equals(token5)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 6, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 6, cellnum + 1, token5);
			Assert.assertTrue(ele.getAttribute("value").equals(token5));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Style Category UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Style Category DB Token Value=" + token5);
			Reporter.addStepLog("UI and DB Values of Style Category doesn't match");
			exlObj.setCellData(sheet, 6, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 6, cellnum + 1, token5);
			exlObj.setCellData(sheet, 6, cellnum + 2, "UI and DB Values of Style Category doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token5, "UI and DB Values of Style Category doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareCompUniverseToken(String token6) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Compare Comparative Universe");
		Thread.sleep(1000);
		action.highligthElement(ele);
		ele.click();
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Comparative Universe UI Element Value=" + ele.getAttribute("value"));
		System.out.println("Comparative Universe DB Token Value=" + token6);
		String eleisnull6 = (String) ele.getAttribute("value");
		if (ele.getAttribute("value") == null && token6 == "isempty") {
			eleisnull6 = "isempty";
			exlObj.setCellData(sheet, 7, cellnum, eleisnull6);
			exlObj.setCellData(sheet, 7, cellnum + 1, token6);
			Assert.assertTrue(eleisnull6.equals(token6));
		} else if (ele.getAttribute("value") == null && token6 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Comparative Universe UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Comparative Universe DB Token Value=" + token6);
			Reporter.addStepLog("UI and DB Values of Comparative Universe doesn't match");
			exlObj.setCellData(sheet, 7, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 7, cellnum + 1, token6);
			exlObj.setCellData(sheet, 7, cellnum + 2, "UI and DB Values of Comparative Universe doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token6,
					"UI and DB Values of Comparative Universe doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getAttribute("value").equals(token6)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 7, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 7, cellnum + 1, token6);
			Assert.assertTrue(ele.getAttribute("value").equals(token6));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Comparative Universe UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Comparative Universe DB Token Value=" + token6);
			Reporter.addStepLog("UI and DB Values of Comparative Universe doesn't match");
			exlObj.setCellData(sheet, 7, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 7, cellnum + 1, token6);
			exlObj.setCellData(sheet, 7, cellnum + 2, "UI and DB Values of Comparative Universe doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token6,
					"UI and DB Values of Comparative Universe doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareGeographicIndicatorToken(String token7) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Compare Geographic Indicator");
		Thread.sleep(1000);
		action.highligthElement(ele);
		action.doubleClick(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Geographic Indicator UI Element Value=" + ele.getAttribute("value"));
		System.out.println("Geographic Indicator DB Token Value=" + token7);
		String eleisnull7 = (String) ele.getAttribute("value");
		if (ele.getAttribute("value") == null && token7 == "isempty") {
			eleisnull7 = "isempty";
			exlObj.setCellData(sheet, 8, cellnum, eleisnull7);
			exlObj.setCellData(sheet, 8, cellnum + 1, token7);
			Assert.assertTrue(eleisnull7.equals(token7));
		} else if (ele.getAttribute("value") == null && token7 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Geographic Indicator UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Geographic Indicator DB Token Value=" + token7);
			Reporter.addStepLog("UI and DB Values of Geographic Indicator doesn't match");
			exlObj.setCellData(sheet, 8, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 8, cellnum + 1, token7);
			exlObj.setCellData(sheet, 8, cellnum + 2, "UI and DB Values of Geographic Indicator doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token7,
					"UI and DB Values of Geographic Indicator doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getAttribute("value").equals(token7)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 8, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 8, cellnum + 1, token7);
			Assert.assertTrue(ele.getAttribute("value").equals(token7));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Geographic Indicator UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Geographic Indicator DB Token Value=" + token7);
			Reporter.addStepLog("UI and DB Values of Geographic Indicator doesn't match");
			exlObj.setCellData(sheet, 8, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 8, cellnum + 1, token7);
			exlObj.setCellData(sheet, 8, cellnum + 2, "UI and DB Values of Geographic Indicator doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token7,
					"UI and DB Values of Geographic Indicator doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareMarketCapToken(String token8) throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Compare Market Cap");
		Thread.sleep(1000);
		action.highligthElement(ele);
		action.doubleClick(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Market Cap UI Element Value=" + ele.getAttribute("value"));
		System.out.println("Market Cap DB Token Value=" + token8);
		System.out.println(ele.getAttribute("value") == token8);
		String eleisnull8 = (String) ele.getAttribute("value");
		if (ele.getAttribute("value") == null && token8 == "isempty") {
			eleisnull8 = "isempty";
			exlObj.setCellData(sheet, 9, cellnum, eleisnull8);
			exlObj.setCellData(sheet, 9, cellnum + 1, token8);
			Assert.assertTrue(eleisnull8.equals(token8));
		} else if (ele.getAttribute("value") == null && token8 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Market Cap UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Market Cap DB Token Value=" + token8);
			Reporter.addStepLog("UI and DB Values of Market Cap doesn't match");
			exlObj.setCellData(sheet, 9, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 9, cellnum + 1, token8);
			exlObj.setCellData(sheet, 9, cellnum + 2, "UI and DB Values of Market Cap doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token8, "UI and DB Values of Market Cap doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getAttribute("value").equals(token8)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 9, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 9, cellnum + 1, token8);
			Assert.assertTrue(ele.getAttribute("value").equals(token8));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Market Cap UI Element Value=" + ele.getAttribute("value"));
			Reporter.addStepLog("Market Cap DB Token Value=" + token8);
			Reporter.addStepLog("UI and DB Values of Market Cap doesn't match");
			exlObj.setCellData(sheet, 9, cellnum, ele.getAttribute("value"));
			exlObj.setCellData(sheet, 9, cellnum + 1, token8);
			exlObj.setCellData(sheet, 9, cellnum + 2, "UI and DB Values of Market Cap doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token8, "UI and DB Values of Market Cap doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareTokenCount() {
		System.out.println("Count After= " + count);
		if (count > 0) {
			Assert.fail(
					"UI and DB Values don't match for all the mentioned attributes.Please refer to extent report and geneerated excel report");
			Reporter.addStepLog(
					"UI and DB Values don't match for all the mentioned attributes.Please refer to extent report and geneerated excel report");
		}

	}

	public void compareViewStyleSearchToken(String token1) throws InterruptedException {
		WebElement ele = (WebElement) action.getElement("View_Investment Style Name");// ByJavascript
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Style Name UI Element Value=" + ele.getText());
		System.out.println("Style Name DB Token Value=" + token1);
		String eleisnull1 = (String) ele.getText();

		if (ele.getText() == null && token1 == "isempty") {
			eleisnull1 = "isempty";
			exlObj.setCellData(sheet, 2, cellnum + 4, eleisnull1);
			exlObj.setCellData(sheet, 2, cellnum + 5, token1);
			Assert.assertTrue(eleisnull1.equals(token1));

		} else if (ele.getText() == null && token1 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Style Name UI Element Value=" + ele.getText());
			Reporter.addStepLog("Style Name DB Token Value=" + token1);
			Reporter.addStepLog("UI and DB Values of Style Name doesn't match");
			exlObj.setCellData(sheet, 2, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 2, cellnum + 5, token1);
			exlObj.setCellData(sheet, 2, cellnum + 6, "UI and DB Values Style Name doesn't match");
			Assert.assertFalse(ele.getText() == token1, "UI and DB Values of Style Name doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token1)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 2, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 2, cellnum + 5, token1);
			Assert.assertTrue(ele.getText().equals(token1));

		} else {
			System.out.println("else check");
			Reporter.addStepLog("Style Name UI Element Value=" + ele.getText());
			Reporter.addStepLog("Style Name DB Token Value=" + token1);
			Reporter.addStepLog("UI and DB Values of Style Name doesn't match");
			exlObj.setCellData(sheet, 2, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 2, cellnum + 5, token1);
			exlObj.setCellData(sheet, 2, cellnum + 6, "UI and DB Values Style Name doesn't match");
			Assert.assertFalse(ele.getText() == token1, "UI and DB Values of Style Name doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareViewRiskCategoryToken(String token2) throws InterruptedException {
		WebElement ele = (WebElement) action.getElement("View_Compare Risk Category");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Risk Category UI Element Value=" + ele.getText());
		System.out.println("Risk Category Name DB Token Value=" + token2);
		String eleisnull1 = (String) ele.getText();

		if (ele.getText() == null && token2 == "isempty") {
			eleisnull1 = "isempty";
			exlObj.setCellData(sheet, 3, cellnum + 4, eleisnull1);
			exlObj.setCellData(sheet, 3, cellnum + 5, token2);
			Assert.assertTrue(eleisnull1.equals(token2));

		} else if (ele.getText() == null && token2 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Risk Category UI Element Value=" + ele.getText());
			Reporter.addStepLog("Risk Category DB Token Value=" + token2);
			Reporter.addStepLog("UI and DB Values of Risk Category doesn't match");
			exlObj.setCellData(sheet, 3, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 3, cellnum + 5, token2);
			exlObj.setCellData(sheet, 3, cellnum + 6, "UI and DB Values Risk Category doesn't match");
			Assert.assertFalse(ele.getText() == token2, "UI and DB Values of Risk Category doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token2)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 3, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 3, cellnum + 5, token2);
			Assert.assertTrue(ele.getText().equals(token2));

		} else {
			System.out.println("else check");
			Reporter.addStepLog("Risk Category UI Element Value=" + ele.getText());
			Reporter.addStepLog("Risk Category DB Token Value=" + token2);
			Reporter.addStepLog("UI and DB Values of Risk Category doesn't match");
			exlObj.setCellData(sheet, 3, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 3, cellnum + 5, token2);
			exlObj.setCellData(sheet, 3, cellnum + 6, "UI and DB Values Risk Category doesn't match");
			Assert.assertFalse(ele.getText() == token2, "UI and DB Values of Risk Category doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareViewPIVStyleToken(String token3) throws InterruptedException {

		WebElement ele = (WebElement) action.getElement("View_Compare PIV STYLE");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("PIV Style UI Element Value=" + ele.getText());
		System.out.println("PIV Style Name DB Token Value=" + token3);
		String eleisnull1 = (String) ele.getText();

		if (ele.getText() == null && token3 == "isempty") {
			eleisnull1 = "isempty";
			exlObj.setCellData(sheet, 4, cellnum + 4, eleisnull1);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
			Assert.assertTrue(eleisnull1.equals(token3));

		} else if (ele.getText() == null && token3 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("PIV Style UI Element Value=" + ele.getText());
			Reporter.addStepLog("PIV Style DB Token Value=" + token3);
			Reporter.addStepLog("UI and DB Values of PIV Style doesn't match");
			exlObj.setCellData(sheet, 4, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
			exlObj.setCellData(sheet, 4, cellnum + 6, "UI and DB Values PIV Style doesn't match");
			Assert.assertFalse(ele.getText() == token3, "UI and DB Values of PIV Style doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token3)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 4, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
			Assert.assertTrue(ele.getText().equals(token3));

		} else {
			System.out.println("else check");
			Reporter.addStepLog("PIV Style UI Element Value=" + ele.getText());
			Reporter.addStepLog("PIV Style DB Token Value=" + token3);
			Reporter.addStepLog("UI and DB Values of PIV Style doesn't match");
			exlObj.setCellData(sheet, 4, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
			exlObj.setCellData(sheet, 4, cellnum + 6, "UI and DB Values PIV Style doesn't match");
			Assert.assertFalse(ele.getText() == token3, "UI and DB Values of PIV Style doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewFeeScheduleTypeToken(String token4) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Fee Schedule Type");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Fee Schedule Type UI Element Value=" + ele.getText());
		System.out.println("Fee Schedule Type DB Token Value=" + token4);
		String eleisnull4 = (String) ele.getText();
		if (ele.getText() == null && token4 == "isempty") {
			eleisnull4 = "isempty";
			exlObj.setCellData(sheet, 5, cellnum + 4, eleisnull4);
			exlObj.setCellData(sheet, 5, cellnum + 5, token4);
			Assert.assertTrue(eleisnull4.contains(token4));
		} else if (ele.getText() == null && token4 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Fee Schedule Type UI Element Value=" + ele.getText());
			Reporter.addStepLog("Fee Schedule Type DB Token Value=" + token4);
			Reporter.addStepLog("UI and DB Values of Fee Schedule Type doesn't match");
			exlObj.setCellData(sheet, 5, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 5, cellnum + 5, token4);
			exlObj.setCellData(sheet, 5, cellnum + 6, "UI and DB Values of Fee Schedule Type doesn't match");
			Assert.assertFalse(ele.getText() == token4, "UI and DB Values of Fee Schedule Type doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().contains(token4)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 5, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 5, cellnum + 5, token4);
			Assert.assertTrue(ele.getText().contains(token4));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Fee Schedule Type UI Element Value=" + ele.getText());
			Reporter.addStepLog("Fee Schedule Type DB Token Value=" + token4);
			Reporter.addStepLog("UI and DB Values of Fee Schedule Type doesn't match");
			exlObj.setCellData(sheet, 5, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 5, cellnum + 5, token4);
			exlObj.setCellData(sheet, 5, cellnum + 6, "UI and DB Values of Fee Schedule Type doesn't match");
			Assert.assertFalse(ele.getAttribute("value") == token4,
					"UI and DB Values of Fee Schedule Type doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareViewStyleCategoryToken(String token5) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Style Category");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Style Category UI Element Value=" + ele.getText());
		System.out.println("Style Category DB Token Value=" + token5);
		String eleisnull5 = (String) ele.getText();
		if (ele.getText() == null && token5 == "isempty") {
			eleisnull5 = "isempty";
			exlObj.setCellData(sheet, 6, cellnum + 4, eleisnull5);
			exlObj.setCellData(sheet, 6, cellnum + 5, token5);
			Assert.assertTrue(eleisnull5.equals(token5));
		} else if (ele.getText() == null && token5 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Style Category UI Element Value=" + ele.getText());
			Reporter.addStepLog("Style Category DB Token Value=" + token5);
			Reporter.addStepLog("UI and DB Values of Style Category doesn't match");
			exlObj.setCellData(sheet, 6, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 6, cellnum + 5, token5);
			exlObj.setCellData(sheet, 6, cellnum + 6, "UI and DB Values of Style Category doesn't match");
			Assert.assertFalse(ele.getText() == token5, "UI and DB Values of Style Category doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token5)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 6, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 6, cellnum + 5, token5);
			Assert.assertTrue(ele.getText().equals(token5));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Style Category UI Element Value=" + ele.getText());
			Reporter.addStepLog("Style Category DB Token Value=" + token5);
			Reporter.addStepLog("UI and DB Values of Style Category doesn't match");
			exlObj.setCellData(sheet, 6, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 6, cellnum + 5, token5);
			exlObj.setCellData(sheet, 6, cellnum + 6, "UI and DB Values of Style Category doesn't match");
			Assert.assertFalse(ele.getText() == token5, "UI and DB Values of Style Category doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareViewCompUniverseToken(String token6) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Comparative Universe");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Comparative Universe UI Element Value=" + ele.getText());
		System.out.println("Comparative Universe DB Token Value=" + token6);
		String eleisnull6 = (String) ele.getText();
		if (ele.getText() == null && token6 == "isempty") {
			eleisnull6 = "isempty";
			exlObj.setCellData(sheet, 7, cellnum + 4, eleisnull6);
			exlObj.setCellData(sheet, 7, cellnum + 5, token6);
			Assert.assertTrue(eleisnull6.equals(token6));
		} else if (ele.getText() == null && token6 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Comparative Universe UI Element Value=" + ele.getText());
			Reporter.addStepLog("Comparative Universe DB Token Value=" + token6);
			Reporter.addStepLog("UI and DB Values of Comparative Universe doesn't match");
			exlObj.setCellData(sheet, 7, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 7, cellnum + 5, token6);
			exlObj.setCellData(sheet, 7, cellnum + 6, "UI and DB Values of Comparative Universe doesn't match");
			Assert.assertFalse(ele.getText() == token6, "UI and DB Values of Comparative Universe doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token6)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 7, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 7, cellnum + 5, token6);
			Assert.assertTrue(ele.getText().equals(token6));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Comparative Universe UI Element Value=" + ele.getText());
			Reporter.addStepLog("Comparative Universe DB Token Value=" + token6);
			Reporter.addStepLog("UI and DB Values of Comparative Universe doesn't match");
			exlObj.setCellData(sheet, 7, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 7, cellnum + 5, token6);
			exlObj.setCellData(sheet, 7, cellnum + 6, "UI and DB Values of Comparative Universe doesn't match");
			Assert.assertFalse(ele.getText() == token6, "UI and DB Values of Comparative Universe doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareViewGeographicIndicatorToken(String token7) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Geographic Indicator");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Geographic Indicator UI Element Value=" + ele.getText());
		System.out.println("Geographic Indicator DB Token Value=" + token7);
		String eleisnull7 = (String) ele.getText();
		if (ele.getText() == null && token7 == "isempty") {
			eleisnull7 = "isempty";
			exlObj.setCellData(sheet, 8, cellnum + 4, eleisnull7);
			exlObj.setCellData(sheet, 8, cellnum + 5, token7);
			Assert.assertTrue(eleisnull7.equals(token7));
		} else if (ele.getText() == null && token7 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Geographic Indicator UI Element Value=" + ele.getText());
			Reporter.addStepLog("Geographic Indicator DB Token Value=" + token7);
			Reporter.addStepLog("UI and DB Values of Geographic Indicator doesn't match");
			exlObj.setCellData(sheet, 8, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 8, cellnum + 5, token7);
			exlObj.setCellData(sheet, 8, cellnum + 6, "UI and DB Values of Geographic Indicator doesn't match");
			Assert.assertFalse(ele.getText() == token7, "UI and DB Values of Geographic Indicator doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token7)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 8, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 8, cellnum + 5, token7);
			Assert.assertTrue(ele.getText().equals(token7));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Geographic Indicator UI Element Value=" + ele.getText());
			Reporter.addStepLog("Geographic Indicator DB Token Value=" + token7);
			Reporter.addStepLog("UI and DB Values of Geographic Indicator doesn't match");
			exlObj.setCellData(sheet, 8, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 8, cellnum + 5, token7);
			exlObj.setCellData(sheet, 8, cellnum + 6, "UI and DB Values of Geographic Indicator doesn't match");
			Assert.assertFalse(ele.getText() == token7, "UI and DB Values of Geographic Indicator doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}

	}

	public void compareViewMarketCapToken(String token8) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Market Cap");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Market Cap UI Element Value=" + ele.getText());
		System.out.println("Market Cap DB Token Value=" + token8);
		System.out.println(ele.getText() == token8);
		String eleisnull8 = (String) ele.getText();
		if (ele.getText() == null && token8 == "isempty") {
			eleisnull8 = "isempty";
			exlObj.setCellData(sheet, 9, cellnum + 4, eleisnull8);
			exlObj.setCellData(sheet, 9, cellnum + 5, token8);
			Assert.assertTrue(eleisnull8.equals(token8));
		} else if (ele.getText() == null && token8 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Market Cap UI Element Value=" + ele.getText());
			Reporter.addStepLog("Market Cap DB Token Value=" + token8);
			Reporter.addStepLog("UI and DB Values of Market Cap doesn't match");
			exlObj.setCellData(sheet, 9, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 9, cellnum + 5, token8);
			exlObj.setCellData(sheet, 9, cellnum + 6, "UI and DB Values of Market Cap doesn't match");
			Assert.assertFalse(ele.getText() == token8, "UI and DB Values of Market Cap doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token8)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 9, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 9, cellnum + 5, token8);
			Assert.assertTrue(ele.getText().equals(token8));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Market Cap UI Element Value=" + ele.getText());
			Reporter.addStepLog("Market Cap DB Token Value=" + token8);
			Reporter.addStepLog("UI and DB Values of Market Cap doesn't match");
			exlObj.setCellData(sheet, 9, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 9, cellnum + 5, token8);
			exlObj.setCellData(sheet, 9, cellnum + 6, "UI and DB Values of Market Cap doesn't match");
			Assert.assertFalse(ele.getText() == token8, "UI and DB Values of Market Cap doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewBaseTemplateToken(String token9) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Base Template");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Base Template UI Element Value=" + ele.getText());
		System.out.println("Base Template DB Token Value=" + token9);
		System.out.println(ele.getText() == token9);
		String eleisnull9 = (String) ele.getText();
		if (ele.getText() == null && token9 == "isempty") {
			eleisnull9 = "isempty";
			exlObj.setCellData(sheet, 10, cellnum + 4, eleisnull9);
			exlObj.setCellData(sheet, 10, cellnum + 5, token9);
			Assert.assertTrue(eleisnull9.equals(token9));
		} else if (ele.getText() == null && token9 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Base Template UI Element Value=" + ele.getText());
			Reporter.addStepLog("Base Template DB Token Value=" + token9);
			Reporter.addStepLog("UI and DB Values of Base Template doesn't match");
			exlObj.setCellData(sheet, 10, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 10, cellnum + 5, token9);
			exlObj.setCellData(sheet, 10, cellnum + 6, "UI and DB Values of Base Template doesn't match");
			Assert.assertFalse(ele.getText() == token9, "UI and DB Values of Base Template doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token9)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 10, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 10, cellnum + 5, token9);
			Assert.assertTrue(ele.getText().equals(token9));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Base Template UI Element Value=" + ele.getText());
			Reporter.addStepLog("Base Template DB Token Value=" + token9);
			Reporter.addStepLog("UI and DB Values of Base Template doesn't match");
			exlObj.setCellData(sheet, 10, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 10, cellnum + 5, token9);
			exlObj.setCellData(sheet, 10, cellnum + 6, "UI and DB Values of Base Template doesn't match");
			Assert.assertFalse(ele.getText() == token9, "UI and DB Values of Base Template doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewBalancedAllocationToken(String token10) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Balanced Allocation");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Balanced Allocation UI Element Value=" + ele.getText());
		System.out.println("Balanced Allocation DB Token Value=" + token10);
		System.out.println(ele.getText() == token10);
		String eleisnull10 = (String) ele.getText();
		if (ele.getText() == null && token10 == "isempty") {
			eleisnull10 = "isempty";
			exlObj.setCellData(sheet, 11, cellnum + 4, eleisnull10);
			exlObj.setCellData(sheet, 11, cellnum + 5, token10);
			Assert.assertTrue(eleisnull10.equals(token10));
		} else if (ele.getText() == null && token10 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Balanced Allocation UI Element Value=" + ele.getText());
			Reporter.addStepLog("Balanced Allocation DB Token Value=" + token10);
			Reporter.addStepLog("UI and DB Values of Balanced Allocation doesn't match");
			exlObj.setCellData(sheet, 11, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 11, cellnum + 5, token10);
			exlObj.setCellData(sheet, 11, cellnum + 6, "UI and DB Values of Balanced Allocation doesn't match");
			Assert.assertFalse(ele.getText() == token10, "UI and DB Values of Balanced Allocation doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token10)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 11, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 11, cellnum + 5, token10);
			Assert.assertTrue(ele.getText().equals(token10));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Balanced Allocation UI Element Value=" + ele.getText());
			Reporter.addStepLog("Balanced Allocation DB Token Value=" + token10);
			Reporter.addStepLog("UI and DB Values of Balanced Allocation doesn't match");
			exlObj.setCellData(sheet, 11, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 11, cellnum + 5, token10);
			exlObj.setCellData(sheet, 11, cellnum + 6, "UI and DB Values of Balanced Allocation doesn't match");
			Assert.assertFalse(ele.getText() == token10, "UI and DB Values of Balanced Allocation doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewHOCommentsToken(String token11) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare HO Comments");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("HO Comments UI Element Value=" + ele.getText());
		System.out.println("HO Comments DB Token Value=" + token11);
		System.out.println(ele.getText() == token11);
		String eleisnull11 = (String) ele.getText();
		if (ele.getText() == null && token11 == "isempty") {
			eleisnull11 = "isempty";
			exlObj.setCellData(sheet, 12, cellnum + 4, eleisnull11);
			exlObj.setCellData(sheet, 12, cellnum + 5, token11);
			Assert.assertTrue(eleisnull11.equals(token11));
		} else if (ele.getText() == null && token11 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("HO Comments UI Element Value=" + ele.getText());
			Reporter.addStepLog("HO Comments DB Token Value=" + token11);
			Reporter.addStepLog("UI and DB Values of HO Comments doesn't match");
			exlObj.setCellData(sheet, 12, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 12, cellnum + 5, token11);
			exlObj.setCellData(sheet, 12, cellnum + 6, "UI and DB Values of HO Comments doesn't match");
			Assert.assertFalse(ele.getText() == token11, "UI and DB Values of HO Comments doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token11)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 12, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 12, cellnum + 5, token11);
			Assert.assertTrue(ele.getText().equals(token11));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("HO Comments UI Element Value=" + ele.getText());
			Reporter.addStepLog("HO Comments DB Token Value=" + token11);
			Reporter.addStepLog("UI and DB Values of HO Comments doesn't match");
			exlObj.setCellData(sheet, 12, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 12, cellnum + 5, token11);
			exlObj.setCellData(sheet, 12, cellnum + 6, "UI and DB Values of HO Comments doesn't match");
			Assert.assertFalse(ele.getText() == token11, "UI and DB Values of HO Comments doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewBundledNodeIDToken(String token12) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Bundled Node ID");
		action.scrollToElement(ele);
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Bundled Node ID UI Element Value=" + ele.getText());
		System.out.println("Bundled Node ID DB Token Value=" + token12);
		System.out.println(ele.getText() == token12);
		String eleisnull12 = (String) ele.getText();
		if (ele.getText() == null && token12 == "isempty") {
			eleisnull12 = "isempty";
			exlObj.setCellData(sheet, 13, cellnum + 4, eleisnull12);
			exlObj.setCellData(sheet, 13, cellnum + 5, token12);
			Assert.assertTrue(eleisnull12.equals(token12));
		} else if (ele.getText() == null && token12 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Bundled Node ID UI Element Value=" + ele.getText());
			Reporter.addStepLog("Bundled Node ID DB Token Value=" + token12);
			Reporter.addStepLog("UI and DB Values of Bundled Node ID doesn't match");
			exlObj.setCellData(sheet, 13, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 13, cellnum + 5, token12);
			exlObj.setCellData(sheet, 13, cellnum + 6, "UI and DB Values of Bundled Node ID doesn't match");
			Assert.assertFalse(ele.getText() == token12, "UI and DB Values of Bundled Node ID doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token12)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 13, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 13, cellnum + 5, token12);
			Assert.assertTrue(ele.getText().equals(token12));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Bundled Node ID  UI Element Value=" + ele.getText());
			Reporter.addStepLog("Bundled Node ID  DB Token Value=" + token12);
			Reporter.addStepLog("UI and DB Values of Bundled Node ID  doesn't match");
			exlObj.setCellData(sheet, 13, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 13, cellnum + 5, token12);
			exlObj.setCellData(sheet, 13, cellnum + 6, "UI and DB Values of Bundled Node ID doesn't match");
			Assert.assertFalse(ele.getText() == token12, "UI and DB Values of Bundled Node ID doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewUnBundledNodeIDToken(String token13) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare UnBundled Node ID");
		action.scrollToElement(ele);
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("UnBundled Node ID UI Element Value=" + ele.getText());
		System.out.println("UnBundled Node ID DB Token Value=" + token13);
		System.out.println(ele.getText() == token13);
		String eleisnull13 = (String) ele.getText();
		if (ele.getText() == null && token13 == "isempty") {
			eleisnull13 = "isempty";
			exlObj.setCellData(sheet, 14, cellnum + 4, eleisnull13);
			exlObj.setCellData(sheet, 14, cellnum + 5, token13);
			Assert.assertTrue(eleisnull13.equals(token13));
		} else if (ele.getText() == null && token13 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("UnBundled Node ID UI Element Value=" + ele.getText());
			Reporter.addStepLog("UnBundled Node ID DB Token Value=" + token13);
			Reporter.addStepLog("UI and DB Values of UnBundled Node ID doesn't match");
			exlObj.setCellData(sheet, 14, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 14, cellnum + 5, token13);
			exlObj.setCellData(sheet, 14, cellnum + 6, "UI and DB Values of UnBundled Node ID doesn't match");
			Assert.assertFalse(ele.getText() == token13, "UI and DB Values of UnBundled Node ID doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token13)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 14, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 14, cellnum + 5, token13);
			Assert.assertTrue(ele.getText().equals(token13));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("UnBundled Node ID  UI Element Value=" + ele.getText());
			Reporter.addStepLog("UnBundled Node ID  DB Token Value=" + token13);
			Reporter.addStepLog("UI and DB Values of UnBundled Node ID  doesn't match");
			exlObj.setCellData(sheet, 14, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 14, cellnum + 5, token13);
			exlObj.setCellData(sheet, 14, cellnum + 6, "UI and DB Values of UnBundled Node ID doesn't match");
			Assert.assertFalse(ele.getText() == token13, "UI and DB Values of UnBundled Node ID doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewStyleBenchmarkNameToken(String token14) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Style Benchmark Name");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Style Benchmark Name UI Element Value=" + ele.getText());
		System.out.println("Style Benchmark Name DB Token Value=" + token14);
		System.out.println(ele.getText() == token14);
		String eleisnull14 = (String) ele.getText();
		if (ele.getText() == null && token14 == "isempty") {
			eleisnull14 = "isempty";
			exlObj.setCellData(sheet, 15, cellnum + 4, eleisnull14);
			exlObj.setCellData(sheet, 15, cellnum + 5, token14);
			Assert.assertTrue(eleisnull14.equals(token14));
		} else if (ele.getText() == null && token14 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Style Benchmark Name UI Element Value=" + ele.getText());
			Reporter.addStepLog("Style Benchmark Name DB Token Value=" + token14);
			Reporter.addStepLog("UI and DB Values of Style Benchmark Name doesn't match");
			exlObj.setCellData(sheet, 15, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 15, cellnum + 5, token14);
			exlObj.setCellData(sheet, 15, cellnum + 6, "UI and DB Values of Style Benchmark Name doesn't match");
			Assert.assertFalse(ele.getText() == token14, "UI and DB Values of Style Benchmark Name doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token14)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 15, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 15, cellnum + 5, token14);
			Assert.assertTrue(ele.getText().equals(token14));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Style Benchmark Name UI Element Value=" + ele.getText());
			Reporter.addStepLog("Style Benchmark Name DB Token Value=" + token14);
			Reporter.addStepLog("UI and DB Values of Style Benchmark Name doesn't match");
			exlObj.setCellData(sheet, 15, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 15, cellnum + 5, token14);
			exlObj.setCellData(sheet, 15, cellnum + 6, "UI and DB Values of Style Benchmark Name doesn't match");
			Assert.assertFalse(ele.getText() == token14, "UI and DB Values of Style Benchmark Name doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewCustomBenchmarkNameToken(String token14) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Custom Benchmark Name");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addScreenCapture();
		System.out.println("Custom Benchmark Name UI Element Value=" + ele.getText());
		System.out.println("Custom Benchmark Name DB Token Value=" + token14);
		System.out.println(ele.getText() == token14);
		String eleisnull14 = (String) ele.getText();
		if (ele.getText() == null && token14 == "isempty") {
			eleisnull14 = "isempty";
			exlObj.setCellData(sheet, 17, cellnum + 4, eleisnull14);
			exlObj.setCellData(sheet, 17, cellnum + 5, token14);
			Assert.assertTrue(eleisnull14.equals(token14));
		} else if (ele.getText() == null && token14 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Custom Benchmark Name UI Element Value=" + ele.getText());
			Reporter.addStepLog("Custom Benchmark Name DB Token Value=" + token14);
			Reporter.addStepLog("UI and DB Values of Custom Benchmark Name doesn't match");
			exlObj.setCellData(sheet, 17, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 17, cellnum + 5, token14);
			exlObj.setCellData(sheet, 17, cellnum + 6, "UI and DB Values of Custom Benchmark Name doesn't match");
			Assert.assertFalse(ele.getText() == token14, "UI and DB Values of Custom Benchmark Name doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token14)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 17, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 17, cellnum + 5, token14);
			Assert.assertTrue(ele.getText().equals(token14));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Custom Benchmark Name UI Element Value=" + ele.getText());
			Reporter.addStepLog("Custom Benchmark Name DB Token Value=" + token14);
			Reporter.addStepLog("UI and DB Values of Custom Benchmark Name doesn't match");
			exlObj.setCellData(sheet, 17, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 17, cellnum + 5, token14);
			exlObj.setCellData(sheet, 17, cellnum + 6, "UI and DB Values of Custom Benchmark Name doesn't match");
			Assert.assertFalse(ele.getText() == token14, "UI and DB Values of Custom Benchmark Name doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewStyleBenchmarkPercentageToken(String token15) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Benchmark Percentage");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addCompleteScreenCapture();
		System.out.println("Style Benchmark Percentage UI Element Value=" + ele.getText());
		System.out.println("Style Benchmark Percentage DB Token Value=" + token15);
		System.out.println(ele.getText() == token15);
		String eleisnull15 = (String) ele.getText();
		if (ele.getText() == null && token15 == "isempty") {
			eleisnull15 = "isempty";
			exlObj.setCellData(sheet, 16, cellnum + 4, eleisnull15);
			exlObj.setCellData(sheet, 16, cellnum + 5, token15);
			Assert.assertTrue(eleisnull15.equals(token15));
		} else if (ele.getText() == null && token15 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Style Benchmark Percentage UI Element Value=" + ele.getText());
			Reporter.addStepLog("Style Benchmark Percentage DB Token Value=" + token15);
			Reporter.addStepLog("UI and DB Values of Style Benchmark Percentage doesn't match");
			exlObj.setCellData(sheet, 16, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 16, cellnum + 5, token15);
			exlObj.setCellData(sheet, 16, cellnum + 6, "UI and DB Values of Style Benchmark Percentage doesn't match");
			Assert.assertFalse(ele.getText() == token15,
					"UI and DB Values of Style Benchmark Percentage doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token15)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 16, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 16, cellnum + 5, token15);
			Assert.assertTrue(ele.getText().equals(token15));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Style Benchmark Percentage UI Element Value=" + ele.getText());
			Reporter.addStepLog("Style Benchmark Percentage DB Token Value=" + token15);
			Reporter.addStepLog("UI and DB Values of Style Benchmark Percentage doesn't match");
			exlObj.setCellData(sheet, 16, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 16, cellnum + 5, token15);
			exlObj.setCellData(sheet, 16, cellnum + 6, "UI and DB Values of Style Benchmark Percentage doesn't match");
			Assert.assertFalse(ele.getText() == token15,
					"UI and DB Values of Style Benchmark Percentage doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void compareViewCustomBenchmarkPercentageToken(String token15) throws InterruptedException {
		WebElement ele = action.getElement("View_Compare Benchmark Percentage");
		Thread.sleep(1000);
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addCompleteScreenCapture();
		System.out.println("Custom Benchmark Percentage UI Element Value=" + ele.getText());
		System.out.println("Custom Benchmark Percentage DB Token Value=" + token15);
		System.out.println(ele.getText() == token15);
		String eleisnull15 = (String) ele.getText();
		if (ele.getText() == null && token15 == "isempty") {
			eleisnull15 = "isempty";
			exlObj.setCellData(sheet, 18, cellnum + 4, eleisnull15);
			exlObj.setCellData(sheet, 18, cellnum + 5, token15);
			Assert.assertTrue(eleisnull15.equals(token15));
		} else if (ele.getText() == null && token15 != "isempty") {
			System.out.println("Else If1 check");
			Reporter.addStepLog("Custom Benchmark Percentage UI Element Value=" + ele.getText());
			Reporter.addStepLog("Custom Benchmark Percentage DB Token Value=" + token15);
			Reporter.addStepLog("UI and DB Values of Custom Benchmark Percentage doesn't match");
			exlObj.setCellData(sheet, 18, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 18, cellnum + 5, token15);
			exlObj.setCellData(sheet, 18, cellnum + 6, "UI and DB Values of Custom Benchmark Percentage doesn't match");
			Assert.assertFalse(ele.getText() == token15,
					"UI and DB Values of Custom Benchmark Percentage doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		} else if (ele.getText().equals(token15)) {
			System.out.println("Else If2 check");
			exlObj.setCellData(sheet, 18, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 18, cellnum + 5, token15);
			Assert.assertTrue(ele.getText().equals(token15));
		} else {
			System.out.println("else check");
			Reporter.addStepLog("Custom Benchmark Percentage UI Element Value=" + ele.getText());
			Reporter.addStepLog("Custom Benchmark Percentage DB Token Value=" + token15);
			Reporter.addStepLog("UI and DB Values of Custom Benchmark Percentage doesn't match");
			exlObj.setCellData(sheet, 18, cellnum + 4, ele.getText());
			exlObj.setCellData(sheet, 18, cellnum + 5, token15);
			exlObj.setCellData(sheet, 18, cellnum + 6, "UI and DB Values of Custom Benchmark Percentage doesn't match");
			Assert.assertFalse(ele.getText() == token15,
					"UI and DB Values of Custom Benchmark Percentage doesn't match");
			count = count + 1;
			System.out.println("Count Before= " + count);
		}
	}

	public void verifyComparativeBenchmarkSelection(String token) throws InterruptedException {
		String selected_comparative_benchmark_type;
		WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style Check");
		Thread.sleep(2000);
		// action.moveToElement(ele);
		action.highligthElement(ele);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Check");
		Thread.sleep(3000);
		action.moveToElement(ele1);
		action.highligthElement(ele1);
		Thread.sleep(1000);
		Reporter.addScreenCapture();
		String pmpDefaultRadio = ((WebElement) action.fluentWaitForJSWebElement("Comparative Benchmark Style Check"))
				.getAttribute("class");
		// System.out.println("pmpDefaultRadio class= " + pmpDefaultRadio);
		String customRadio = ((WebElement) action.fluentWaitForJSWebElement("Comparative Benchmark Custom Check"))
				.getAttribute("class");
		// System.out.println("customRadio class= " + pmpDefaultRadio);
		if (customRadio.equals("checked")) {
			selected_comparative_benchmark_type = "Custom";
			System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
			if (ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token)) {
				Assert.assertTrue(
						ele1.getText().replace(ele1.getText(), selected_comparative_benchmark_type).equals(token));
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Reporter.addStepLog(
						"UI and DB Values of selected_comparative_benchmark_type on Style Benchmark Page matches");

			} else {
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Assert.assertFalse(ele1.getText() == token,
						"UI and DB Values of selected_comparative_benchmark_type on Style Benchmark Page doesn't match");
			}

		} else {
			selected_comparative_benchmark_type = "Default";
			System.out.println(selected_comparative_benchmark_type);
			if (ele.getText().replace(ele.getText(), selected_comparative_benchmark_type).equals(token)) {
				Assert.assertTrue(
						ele.getText().replace(ele.getText(), selected_comparative_benchmark_type).equals(token));
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Reporter.addStepLog(
						"UI and DB Values of selected_comparative_benchmark_type on Style Benchmark Page matches");
			} else {
				System.out.println("Selected Benchmark type is: " + selected_comparative_benchmark_type);
				Reporter.addStepLog(
						"selected_comparative_benchmark_type UI Element Value=" + selected_comparative_benchmark_type);
				Reporter.addStepLog("selected_comparative_benchmark_type DB Token Value=" + token);
				Assert.assertFalse(ele.getText() == token,
						"UI and DB Values of selected_comparative_benchmark_type on Style Benchmark Page doesn't match");
			}

		}

	}

	public void clickCurrentDate(String id) throws Throwable {
		WebElement myElement;
		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector(\"#" + id + "\").shadowRoot.querySelector(\"wf-input\")");
		if (myElement.isEnabled()) {
			action.jsClick(myElement);
			Thread.sleep(1000);
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector('brml-calendar-picker[id=\"" + id
							+ "\"]').shadowRoot.querySelector(\"div.pmu-days > div.pmu-today.pmu-button\")");
			action.jsClick(myElement);
			Thread.sleep(1000);
			/*
			 * myElement = (WebElement) action.executeJavaScript(
			 * "return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')"
			 * ); action.highligthElement(myElement); action.jsClick(myElement);
			 * Thread.sleep(2000);
			 */
		}
	}

	public void clickPreviousDate(String id) throws Throwable {
		WebElement myElement;
		String myValue;
		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"#" + id + "\")");
		myValue = new SimpleDateFormat("yyyy-MM-dd").format(new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000));
		System.out.println("in here 1 " + myElement.getAttribute("disabled"));

		if (myElement.getAttribute("disabled").equalsIgnoreCase("true")) {
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"#" + id + "\").shadowRoot.querySelector(\"wf-input\")");
			action.jsClick(myElement);
			Thread.sleep(1000);

			action.executeJavaScript(
					"return document.querySelector(\"#" + id + "\").setAttribute(\"date\",\"" + myValue + "\")");
			Thread.sleep(1000);

			myElement = (WebElement) action.executeJavaScript("return document.querySelector('brml-calendar-picker[id="
					+ id + "]').shadowRoot.querySelector(\"div.pmu-days > div.pmu-today.pmu-button\").previousSibling");
			action.jsClick(myElement);
			Thread.sleep(1000);
		}

		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");
		action.jsClick(myElement);
		Thread.sleep(2000);
	}

	public void enterCapnGoComparativeBenchmark() throws Throwable {
		action.scrollToBottom();
		WebElement ele = (WebElement) action.getElementByJavascript("Benchmark Effective Date Type");
		Thread.sleep(3000);
		action.highligthElement(ele);
		ele.click();
		WebElement ele1 = (WebElement) action.getElementByJavascript("Benchmark Effective Date Type Data");
		ele1.click();
		action.highligthElement(ele1);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
		action.highligthElement(ele2);
		action.jsClick(ele2);
		WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
		action.highligthElement(ele3);
		ele3.click();
		Thread.sleep(1000);
		WebElement ele4 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
		action.highligthElement(ele4);
		ele4.click();
		ele4.clear();
		WebElement ele5 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
		action.highligthElement(ele5);
		ele5.clear();
		action.sendKeys(ele5, "100.00");
		WebElement ele6 = action.getElement("Add New Time Period");
		action.highligthElement(ele6);
		Reporter.addScreenCapture();
		action.doubleClick(ele6);
		Thread.sleep(5000);
		WebElement ele7 = (WebElement) action.getElementByJavascript("Add Time Period Date1");
		action.highligthElement(ele7);
		ele7.click();
		clickCurrentDate("fromDate");
		Reporter.addScreenCapture();
		Thread.sleep(1000);
		WebElement ele8 = (WebElement) action.getElementByJavascript("Apply Button Flyout");
		action.highligthElement(ele8);
		ele8.click();
		Reporter.addScreenCapture();
		WebElement ele9 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
		action.highligthElement(ele9);
		action.jsClick(ele9);
		WebElement ele10 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark T1");
		action.highligthElement(ele10);
		ele10.click();
		WebElement ele11 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
		action.highligthElement(ele11);
		ele11.click();
		ele11.clear();
		WebElement ele12 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
		action.highligthElement(ele12);
		ele12.clear();
		action.sendKeys(ele12, "100.00");
		Thread.sleep(1000);
		Reporter.addCompleteScreenCapture();
	}

	public void clickOnHistoricalTimeperiodForAssetClassification() throws InterruptedException {
		WebElement ele = action.getElement("Historical Timeperiod For AssetClassification");
		action.highligthElement(ele);
		ele.click();
		Thread.sleep(2000);
	}

	public void clickOnCurrentTimeperiodForAssetClassification() throws InterruptedException {
		WebElement ele = action.getElement("Current Timeperiod For AssetClassification");
		action.highligthElement(ele);
		ele.click();
		Thread.sleep(2000);
	}

	public void verifyGreyedoutPercentageForBundledNodeId() throws InterruptedException {
		WebElement ele = action.getElement("Greyedout Percentage For BundledNodeId");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		Thread.sleep(2000);
	}

	public void clickOnCurrentTimeperiodBenchmarkDeleteIcon() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Current Timeperiod Benchmark DeleteIcon");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		action.jsClick(ele);
		Thread.sleep(2000);
	}

	public void clickOnCurrentTimeperiodBenchmarkEditIcon() throws InterruptedException {
		WebElement ele = action.getElement("Current Timeperiod Benchmark EditIcon");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		ele.click();
		Thread.sleep(2000);
	}

	public void verifyFromAndToDatetextintimeperiodpopupwindow() {
		WebElement ele = (WebElement) action.getElementByJavascript("From Date Label");
		action.highligthElement(ele);
		WebElement ele1 = (WebElement) action.getElementByJavascript("To Date Label");
		action.highligthElement(ele1);
		Reporter.addScreenCapture();
	}

	public void verifyInceptionToCurrentDateoption() throws InterruptedException {
		WebElement ele = action.getElement("Timeperiod Inception To Current Dateoption");
		action.highligthElement(ele);
		Thread.sleep(2000);
	}

	public void verifyHistoricalNodeIdTimeperiodEditIcon() throws InterruptedException {
		WebElement ele = action.getElement("Historical NodeId Timeperiod EditIcon");
		action.highligthElement(ele);
		Thread.sleep(2000);
	}

	public void verifyAddNewtimePeriodwithPlusButton() throws InterruptedException {
		WebElement ele = action.getElement("Add New timePeriod with PlusButton");
		action.highligthElement(ele);
		Thread.sleep(2000);
	}

	public void editAddedTimePeriodDateFields() throws Throwable {
//		WebElement ele = (WebElement) action.getElementByJavascript("Add Time Period Date1");
//		action.highligthElement(ele);
//		ele.click();
		clickPreviousDate("fromDate");
		Thread.sleep(1000);
		/*
		 * WebElement ele1 = (WebElement)
		 * action.getElementByJavascript("Apply Button Flyout");
		 * action.highligthElement(ele1); action.jsClick(ele1); Thread.sleep(3000);
		 */
	}

	public void verifyStyleNameAndBenchmarkdetails() {
		WebElement ele = action.getElement("Verify Investment Style Name");
		action.highligthElement(ele);
		WebElement ele1 = action.getElement("Verify Style Benchmarks Displayed");
		action.highligthElement(ele1);
	}

	public void verifyPMPStrategyStyleNameAndBenchmarkdetails() {
		action.waitForPageLoad();
		WebElement ele = action.getElement("Verify PMP Strtaegy Investment Style Name");
		action.highligthElement(ele);
		WebElement ele1 = action.getElement("Verify PMP Strategy Style Benchmarks Displayed");
		action.highligthElement(ele1);
	}

	public void clickAddNewtimePeriodwithPlusButton() throws InterruptedException {
		WebElement ele = action.getElement("Add New timePeriod with PlusButton");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		ele.click();
		Thread.sleep(2000);
	}

	public void provideDatePickertoSelectDate() throws Throwable {
		WebElement ele7 = (WebElement) action.getElementByJavascript("Add Time Period Date1");
		action.highligthElement(ele7);
		ele7.click();
		clickCurrentDate("fromDate");
		Reporter.addScreenCapture();
		Thread.sleep(1000);
		WebElement ele8 = (WebElement) action.getElementByJavascript("Apply Button Flyout");
		action.highligthElement(ele8);
		action.jsClick(ele8);
		Reporter.addCompleteScreenCapture();
	}

	public void provideDatePickertoSelectDate2() throws Throwable {
		WebElement ele7 = (WebElement) action.getElementByJavascript("Add Time Period Date1");
		action.highligthElement(ele7);
		ele7.click();
		clickPreviousDate("fromDate");
		Reporter.addCompleteScreenCapture();
	}

	public void addNodeIDTimePeriodBenchmarks() throws InterruptedException {

		WebElement ele = (WebElement) action.getElementByJavascript("Bundled Asset Classification");
		ele.click();
		action.highligthElement(ele);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Bundled Asset Classification Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele9 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification");
		action.highligthElement(ele9);
		action.jsClick(ele9);
		WebElement ele10 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data");
		action.highligthElement(ele10);
		ele10.click();
		WebElement ele11 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele11);
		ele11.click();
		ele11.clear();
		WebElement ele12 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele12);
		ele12.clear();
		action.sendKeys(ele12, "100.00");
		Thread.sleep(1000);
		Reporter.addCompleteScreenCapture();
	}

	public void addCapnGoComparativeBenchmarks() throws Throwable {
		action.scrollToBottom();
		WebElement ele = (WebElement) action.getElementByJavascript("Benchmark Effective Date Type");
		Thread.sleep(3000);
		action.highligthElement(ele);
		ele.click();
		WebElement ele1 = (WebElement) action.getElementByJavascript("Benchmark Effective Date Type Data");
		ele1.click();
		action.highligthElement(ele1);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
		action.highligthElement(ele2);
		action.jsClick(ele2);
		WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
		action.highligthElement(ele3);
		ele3.click();
		Thread.sleep(1000);
		WebElement ele4 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
		action.highligthElement(ele4);
		ele4.click();
		ele4.clear();
		WebElement ele5 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
		action.highligthElement(ele5);
		ele5.clear();
		action.sendKeys(ele5, "100.00");
		Reporter.addCompleteScreenCapture();
	}

	public void verifyReviewPageNodeIDTimeperiodBenchmarks() throws InterruptedException {
		WebElement ele = action.getElement("Verify NodeID Timeperiod Displayed Review");
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyCurrentTimePeriodEditandDeleteIcons() throws InterruptedException {
		WebElement ele = action.getElement("Current Timeperiod NodeID DeleteIcon");
		action.highligthElement(ele);
		WebElement ele1 = action.getElement("Current Timeperiod NodeID EditIcon");
		action.highligthElement(ele1);
		Thread.sleep(2000);
		Reporter.addCompleteScreenCapture();
	}

	public void verifyViewPageNodeIDTimeperiodBenchmarks() throws InterruptedException {
		WebElement ele = action.getElement("Verify NodeID Timeperiod Displayed View");
		action.highligthElement(ele);
		Thread.sleep(2000);
		Reporter.addCompleteScreenCapture();
	}

	public void clickOnCurrentTimeperiodNodeIDEditIcon() throws InterruptedException {
		WebElement ele = action.getElement("Current Timeperiod NodeID EditIcon");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
		ele.click();
		Thread.sleep(2000);
	}

	public void verifyPreviousModifiedBenchmarkTimeperiods() {
		WebElement ele = action.getElement("Verify PreviousModified  Benchmark Timeperiods");
		action.highligthElement(ele);
	}

	public void updateNodeIDTimePeriodBenchmarks() throws InterruptedException {
		WebElement ele9 = (WebElement) action.getElementByJavascript("Bundled Asset Classification");
		Thread.sleep(1000);
		ele9.click();
		action.highligthElement(ele9);
		Thread.sleep(1000);
		WebElement ele10 = (WebElement) action.getElementByJavascript("Bundled Asset Classification Data T1");
		action.highligthElement(ele10);
		ele10.click();
		Thread.sleep(1000);
		WebElement ele = (WebElement) action.getElementByJavascript("Unbundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data T1");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele2);
		ele2.click();
		ele2.clear();
		Thread.sleep(2000);
		WebElement ele3 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele3);
		ele3.clear();
		action.sendKeys(ele3, "60.00");
		WebElement ele11 = action.getElement("Current Timeperiod For AssetClassification");
		action.highligthElement(ele11);
		ele11.click();
		Thread.sleep(2000);
		WebElement ele4 = (WebElement) action.getElement("Add New Asset Classification");
		action.highligthElement(ele4);
		ele4.click();
		Thread.sleep(1000);
		WebElement ele5 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification2");
		action.highligthElement(ele5);
		ele5.click();
		Thread.sleep(1000);
		WebElement ele6 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data2 T1");
		action.highligthElement(ele6);
		ele6.click();
		Thread.sleep(1000);
		WebElement ele7 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage2");
		action.highligthElement(ele7);
		ele7.click();
		ele7.clear();
		Thread.sleep(2000);
		WebElement ele8 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage2");
		ele8.clear();
		action.sendKeys(ele8, "40.00");
		Thread.sleep(1000);
	}

	public void verifyStyleformatheader() throws InterruptedException {
		WebElement ele = (WebElement) action.getElement("Style | header1");
		action.highligthElement(ele);
		/*
		 * WebElement ele1 = (WebElement) action.getElement("Style | header2");
		 * action.highligthElement(ele1);
		 */
		Reporter.addCompleteScreenCapture();
		Thread.sleep(2000);
	}

	public void verifyDisabledStyleStatusField() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Verify Disabled StyleStatus Field");
		action.highligthElement(ele);
		if (ele.getAttribute("disabled").equalsIgnoreCase("true")) {
			Reporter.addStepLog("Status Field is disabled on Enter Style Details Page");
		} else {
			Reporter.addStepLog("Status Field is Enaabled on Enter Style Details Page");
		}
		Reporter.addCompleteScreenCapture();
		Thread.sleep(2000);
	}

	public void enterMultipleUnbundledAssetClassificationWithRandomPercentages() throws InterruptedException {
		WebElement ele = (WebElement) action.getElementByJavascript("Unbundled Asset Classification");
		Thread.sleep(1000);
		ele.click();
		action.highligthElement(ele);
		Thread.sleep(1000);
		WebElement ele1 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data");
		action.highligthElement(ele1);
		ele1.click();
		Thread.sleep(1000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele2);
		ele2.click();
		ele2.clear();
		Thread.sleep(2000);
		WebElement ele3 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage");
		action.highligthElement(ele3);
		ele3.clear();
		action.sendKeys(ele3, "10.00");
		Thread.sleep(1000);
		WebElement ele4 = (WebElement) action.getElement("Add New Asset Classification");
		action.highligthElement(ele4);
		ele4.click();
		Thread.sleep(1000);
		WebElement ele5 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification2");
		action.highligthElement(ele5);
		ele5.click();
		Thread.sleep(1000);
		WebElement ele6 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data2");
		action.highligthElement(ele6);
		ele6.click();
		Thread.sleep(1000);
		WebElement ele7 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage2");
		action.highligthElement(ele7);
		ele7.click();
		ele7.clear();
		Thread.sleep(2000);
		WebElement ele8 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage2");
		ele8.clear();
		action.sendKeys(ele8, "50.00");
		Thread.sleep(1000);
		WebElement ele9 = (WebElement) action.getElement("Add New Asset Classification");
		action.highligthElement(ele9);
		ele9.click();
		Thread.sleep(1000);
		WebElement ele10 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification3");
		action.highligthElement(ele10);
		ele10.click();
		Thread.sleep(1000);
		WebElement ele11 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Data3");
		action.highligthElement(ele11);
		ele11.click();
		Thread.sleep(1000);
		WebElement ele12 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage3");
		action.highligthElement(ele12);
		ele12.click();
		ele12.clear();
		Thread.sleep(2000);
		WebElement ele13 = (WebElement) action.getElementByJavascript("Unbundled Asset Classification Percentage3");
		ele13.clear();
		action.sendKeys(ele13, "40.00");
		Thread.sleep(1000);
	}

	public void verifyUnbundledNodeIdDisplayedInDescOrder() {
		WebElement ele = (WebElement) action.getElementByJavascript("Verify UnbundledNodeId DisplayedIn DescOrder");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
	}

	public void enterMultipleComparativeBenchmarkWithRandomPercentages(String sb_1, String cb_2)
			throws InterruptedException {
		Boolean flag1 = Boolean.parseBoolean(sb_1);
		Boolean flag2 = Boolean.parseBoolean(cb_2);
		if (flag1 == true) {
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Style");
			Thread.sleep(2000);
			action.highligthElement(ele);
			action.jsClick(ele);
		} else {
			action.scrollToBottom();
			WebElement ele = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom");
			Thread.sleep(3000);
			action.highligthElement(ele);
			action.jsClick(ele);
			Thread.sleep(1000);
			WebElement ele1 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data");
			action.highligthElement(ele1);
			action.jsClick(ele1);
			Thread.sleep(1000);
			WebElement ele2 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark");
			action.highligthElement(ele2);
			ele2.click();
			Thread.sleep(1000);
			WebElement ele3 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele3);
			ele3.click();
			ele3.clear();
			Thread.sleep(2000);
			WebElement ele4 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage");
			action.highligthElement(ele4);
			ele4.clear();
			action.sendKeys(ele4, "20.00");
			Thread.sleep(2000);
			WebElement ele5 = (WebElement) action.getElement("Add New Benchmark");
			action.highligthElement(ele5);
			ele5.click();
			Thread.sleep(1000);
			WebElement ele6 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data2");
			action.jsClick(ele6);
			action.highligthElement(ele6);
			Thread.sleep(1000);
			WebElement ele7 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark2");
			action.highligthElement(ele7);
			ele7.click();
			Thread.sleep(1000);
			WebElement ele8 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage2");
			action.highligthElement(ele8);
			ele8.click();
			ele8.clear();
			Thread.sleep(2000);
			WebElement ele9 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage2");
			action.highligthElement(ele9);
			ele9.clear();
			action.sendKeys(ele9, "40.00");
			Thread.sleep(2000);
			WebElement ele10 = (WebElement) action.getElement("Add New Benchmark");
			action.highligthElement(ele10);
			ele10.click();
			Thread.sleep(1000);
			WebElement ele11 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Data3");
			action.jsClick(ele11);
			action.highligthElement(ele11);
			Thread.sleep(1000);
			WebElement ele12 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Benchmark3");
			action.highligthElement(ele12);
			ele12.click();
			Thread.sleep(1000);
			WebElement ele13 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage3");
			action.highligthElement(ele13);
			ele13.click();
			ele13.clear();
			Thread.sleep(2000);
			WebElement ele14 = (WebElement) action.getElementByJavascript("Comparative Benchmark Custom Percentage3");
			action.highligthElement(ele14);
			ele14.clear();
			action.sendKeys(ele14, "40.00");
			Thread.sleep(2000);
		}
	}

	public void verifyCustomBenchmarksDisplayedInDescOrder() {
		WebElement ele = (WebElement) action.getElementByJavascript("Verify CustomBenchmarks DisplayedIn DescOrder");
		action.highligthElement(ele);
		Reporter.addCompleteScreenCapture();
	}
}
