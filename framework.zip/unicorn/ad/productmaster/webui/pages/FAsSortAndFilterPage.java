package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class FAsSortAndFilterPage {

	Action action;
	WebElement myElement;

	public FAsSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchFAsValue(String FAsSearchValue) {
		action.pause(100);
		action.waitForPageLoad();
		myElement = (WebElement) action.fluentWaitForJSWebElement("GlobalSearchvalueForFAs");
		action.pause(2000);
		myElement.click();
		myElement.clear();
		action.pause(100);
		action.sendkeysClipboard(myElement, FAsSearchValue);
		action.pause(1000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		action.pause(1000);
	}

	public void clickOnSeeAllResultsForFAsLayout() {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitForJSWebElement("SeeAllResultFAsLayout");
		action.scrollToBottom();
		myElement.click();
	}

	public void verifyTheSearchedResultInAllTabForFAs() {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitForJSWebElement("AllTabFAs");
		action.highligthElement(myElement);
		myElement.isDisplayed();
	}

	public void verifyAndClickFAsTab() {
		// action.pause(1000);
		action.pause(3000);
		myElement = (WebElement) action.fluentWaitForJSWebElement("FAsTab");
		// action.pause(2000);
		action.highligthElement(myElement);
		myElement.isDisplayed();
		action.pause(2000);
		myElement.click();
		action.pause(2000);
	}

	public String verifyTheGridCountBeforeApplyFilterAndSortCondition() {
		action.pause(5000);
		myElement = (WebElement) action.fluentWaitWebElement("GridCountAfterGlobalSearchForFAs");
		return action.getAttribute(myElement, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(myElement);
		action.isDisplayed(myElement);
	}

	public void verifySearchedGridViewDisplay() {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("GridViewFAs");
		myElement.isDisplayed();
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		action.pause(2000);
		action.moveToElement(element);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		action.pause(2000);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void clickOnSortIcon(WebElement element) {
		action.pause(2000);
		element.click();
	}

	public String verifyTheSortCoumnPropertyTypeASC() {
		action.pause(5000);
		myElement = (WebElement) action.fluentWaitWebElement("AscSortOrder");
		return action.getAttribute(myElement, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDESC() {
		action.pause(5000);
		myElement = (WebElement) action.fluentWaitWebElement("DescSortOrder");
		return action.getAttribute(myElement, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDefault() {
		action.pause(5000);
		myElement = (WebElement) action.fluentWaitWebElement("DefaultSortOrder");
		return action.getAttribute(myElement, "class");
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.jsClick(element);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
	}

	public void clickOnFilterCondition() {
		action.pause(3000);
		myElement = (WebElement) action.fluentWaitWebElement("FilterCondition");
		action.click(myElement);
	}

	public String verifyTheFAsGridCountAfterApplyFilterConditionOnTab() {
		action.pause(5000);
		myElement = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTabForFAs");
		return action.getText(myElement);
	}

	public void clickOnFilterConditionForFAsGridView(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.click(element);
	}

	public void enterFilterValue(String FilterValue) {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("FilterValue");
		myElement.click();
		action.pause(1000);
		action.sendKeys(myElement, FilterValue);
	}

	public void clickOnApplyFilterIconForFAsGridView() {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public String verifyTheFAsGridCountAfterScroll() {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterCondition");
		action.pause(5000);
		return action.getAttribute(myElement, "aria-rowcount");
	}

	public void clickOnApplyFilterIconForFAsGridViewForReset() {
		action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public void clickOnApplyFilterIconForFAsGridViewForCancel() {
		// action.pause(2000);
		myElement = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public void clickOnFilterDateConditionForFAsGridView(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.click(element);
	}

	public WebElement findElementByJs(String js) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("js", js);
		action.highligthElement(myElement);
		return myElement;
	}

	public WebElement getDynamicElementFromShadowRoot(String javaScript) {
		return myElement = (WebElement) action.executeJavaScript(javaScript);
	}

	public boolean verifyApplyButtonIsDisplayed() {
		// action.pause(2000);
		return action.isPresent("ApplyButton");
	}

	public String waitForWebElement(String xpath) {
		int timeLaps = 0;
		String status = "FAIL";
		while (status.equals("FAIL") && timeLaps < 4) {
			try {
				myElement = findElementByDynamicXpath(xpath);
				if (myElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}
			} catch (Exception e) {
				status = "FAIL";
			}
			action.pause(1000);
			++timeLaps;
		}
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);
		return status;
	}

}
