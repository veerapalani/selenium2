package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class FATeamSortAndFilterPage {

	Action action;
	WebElement Element;

	public FATeamSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchFATeamValue(String FATeamSearchValue) {
		action.pause(100);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitForJSWebElement("GlobalSearchvalueForFATeam");
		action.pause(2000);
		Element.click();
		Element.clear();
		action.pause(100);
		action.sendkeysClipboard(Element, FATeamSearchValue);
		action.pause(500);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		action.pause(1000);
	}

	public void clickOnSeeAllResultsForFATeamLayout() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("SeeAllResultFATeamLayout");
		action.scrollToElement(Element);
		Element.click();
	}

	public void verifyTheSearchedResultInAllTabForFATeam() {
		action.pause(1000);
		Element = (WebElement) action.fluentWaitForJSWebElement("AllTabFATeam");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void verifyAndClickManagerTab() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitForJSWebElement("FATeamTab");
		// action.pause(2000);
		action.highligthElement(Element);
		Element.isDisplayed();
		action.pause(2000);
		Element.click();
		action.pause(2000);
	}

	public String verifyTheGridCountBeforeApplyFilterAndSortCondition() {
		action.pause(5000);
		Element = (WebElement) action.getElement("GridCountAfterGlobalSearchForFATeam");
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(Element);
		action.isDisplayed(Element);
	}

	public void verifySearchedGridViewDisplay() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("GridViewFATeam");
		Element.isDisplayed();
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		action.pause(2000);
		action.moveToElement(element);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		action.pause(2000);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void clickOnSortIcon(WebElement element) {
		action.pause(2000);
		element.click();
	}

	public String verifyTheSortCoumnPropertyTypeASC() {
		action.pause(4000);
		Element = (WebElement) action.fluentWaitWebElement("AscSortOrder");
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDESC() {
		action.pause(4000);
		Element = (WebElement) action.fluentWaitWebElement("DescSortOrder");
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDefault() {
		action.pause(4000);
		Element = (WebElement) action.fluentWaitWebElement("DefaultSortOrder");
		return action.getAttribute(Element, "class");
	}

	public String verifyTheFATeamGridCountAfterApplyFilterConditionOnTab() {
		action.pause(5000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTabForFATeam");
		return action.getText(Element);
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.jsClick(element);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
	}

	public void clickOnFilterCondition() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitWebElement("FilterCondition");
		action.click(Element);
	}

	public void clickOnFilterConditionForFATeamGridView(WebElement element) {
		action.pause(2000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.click(element);
	}

	public void enterFilterValue(String FilterValue) {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("FilterValue");
		Element.click();
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForFATeamGridView() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheFATeamGridCountAfterScroll() {
		action.pause(5000);
		Element = (WebElement) action.fluentWaitWebElement("GridCountAfterfilterCondition");
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void clickOnApplyFilterIconForFATeamGridViewForReset() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForFATeamGridViewForCancel() {
		action.pause(2000);
		Element = (WebElement) action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String waitForWebElement(String xpath) {
		int timeLaps = 0;
		String status = "FAIL";
		while (status.equals("FAIL") && timeLaps < 4) {
			try {
				Element = findElementByDynamicXpath(xpath);
				if (Element == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}
			} catch (Exception e) {
				status = "FAIL";
			}
			action.pause(1000);
			++timeLaps;
		}
		Report.printOperation("wait For WebElement Element");
		Report.printStatus(status);
		return status;
	}

}
