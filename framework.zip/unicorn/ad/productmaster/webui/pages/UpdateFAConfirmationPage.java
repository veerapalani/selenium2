package qa.unicorn.ad.productmaster.webui.pages;

import static org.testng.Assert.assertTrue;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdateFAConfirmationPage {
	
	Action action;
	public UpdateFAConfirmationPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	WebElement Element,Highlight;
	
	public boolean isUserOnConfirmationPage() {
		Element = action.waitForJSWebElement("Header");
		action.highligthElement(Element);
		if (Element.getText().equals("Confirmation")) {
			return true;
		}
		return false;
	}
	
	
	
	

}
