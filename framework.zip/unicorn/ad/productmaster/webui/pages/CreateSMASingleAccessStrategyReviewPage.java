package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateSMASingleAccessStrategyReviewPage {
	Action action;
	WebElement Element;

	public CreateSMASingleAccessStrategyReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void clickOnSubmitt() {
		action.scrollToBottom();

		action.fluentWaitWebElement("Submit").click();

	}

	public void clickOnCtrlC() {

		Actions PMaction = new Actions(WebDriverManager.getDriver());
		PMaction.keyDown(Keys.CONTROL).sendKeys("C");
		PMaction.keyUp(Keys.CONTROL).build().perform();

	}

	public boolean isUserOnReviewPage() {
		
		Element = action.waitForJSWebElement("Header");
		if (Element.getText().equalsIgnoreCase("Review")) {
			action.highligthElement(Element);
			return true;
		}
		return false;

	}

	public String getPrimaryBenchmarkValue() {
		String primaryBenchmark = "";

		Element = action.getElement("Date Type");
		String datetype = Element.getText();
		if (datetype.equals("Style")) {
			List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
			if (WebElements.isEmpty()) {
				return "Primary Benchmark Data is not displayed in Review Page";
			} else {
				List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0), "Benchmarks List common tag");
				ArrayList<String> tempData = new ArrayList<String>();
				// String primaryBenchmark = "";
				int size = Elements.size();
				int count = 0;
				DecimalFormat ds = new DecimalFormat(".00");
				for (int i = 0; i < size / 3; i++) {
					primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
					primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
					if (Elements.get(count).getText().equals("—")) {
						primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
						primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count + 1).getText());
						primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements.get(count + 2).getText().substring(0, Elements.get(count + 2).getText().length() - 1))));
					} else if (Elements.get(count + 1).getText().equals("—")) {
						if (primaryBenchmark.contains("@benchmarkCategory")) {
							primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
							primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements.get(count + 2).getText().substring(0, Elements.get(count + 2).getText().length() - 1))));
						} else {
							Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
						}

					}
					tempData.add(primaryBenchmark);
					// data = data+primaryBenchmark+":";
					count = count + 3;

				}
				if (tempData.size() > 1) {
					Collections.sort(tempData);
					primaryBenchmark = "";
					for (String G : tempData) {
						primaryBenchmark = primaryBenchmark + G + ":";
					}
				}
				tempData.clear();
			}
		} else if (datetype.equals("Timeperiod")) {
			Element = action.getElement("Total Time periods");
			List<WebElement> Timeperiods = action.getElementsFromParentElement(Element, "Benchmarks List common tag");
			ArrayList<String> tempData = new ArrayList<String>();
			int timeperiodcount = 1;
			for (WebElement E : Timeperiods) {
				if(E.getAttribute("class").contains("mb24")) {
					//List<WebElement> WebElements2 = action.getElements("Primary Benchmark Value for Time periods");
					String locatorValue = "//div[contains(text(),'Benchmark1')]/parent::div/parent::div/following-sibling::div["+timeperiodcount+"]/child::div[3]/child::div";
					//locatorValue = locatorValue.replace("@data", String.valueOf(timeperiodcount));
					List<WebElement> WebElements2 = action.getElements("xpath", locatorValue);
					if(WebElements2.isEmpty()) {
						primaryBenchmark =  timeperiodcount + " :: time period benchamrks are not appearing";
					}else {
						List<WebElement> Elements2 = action.getElementsFromParentElement(WebElements2.get(0), "Benchmarks List common tag");
						
						//String primaryBenchmark = "";
						int size  = Elements2.size();
						int count = 0;
						DecimalFormat ds = new DecimalFormat(".00");
						for (int i = 0; i < size/2; i++) {
							primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
							primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Cap n Go");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
							primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements2.get(count).getText());
							primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Integer.parseInt(Elements2.get(count+1).getText().substring(0, Elements2.get(count+1).getText().length()-1))));
							tempData.add(primaryBenchmark);
							//data = data+primaryBenchmark+":";
							count = count + 2;
							
						}
					}
					timeperiodcount++;
				}
				
				
			}
			
			if(tempData.size() > 1) {
				Collections.sort(tempData);
				primaryBenchmark = "";
				for (String G : tempData) {
					primaryBenchmark = primaryBenchmark+G+":";
				}	
			}
			tempData.clear();
		}
		return primaryBenchmark;

	}

	public String getBenchmarkithValuefromUI(int j) {
		
		ArrayList<String> primarybenchmark = getPrimaryBenchmarksValue();
		
		return primarybenchmark.get(j).split("-#-")[2].trim();
		
	}
	public Float getPercentageithValuefromUI(int j) {
		
		ArrayList<String> primarybenchmark = getPrimaryBenchmarksValue();
		
		return Float.parseFloat(primarybenchmark.get(j).split("-#-")[3].trim());
	}
	
	public ArrayList<String> getPrimaryBenchmarksValue() {

		List<WebElement> WebElements = action.getElements("Primary Benchmark Value");
		String primaryBenchmark = "";
		List<WebElement> Elements = action.getElementsFromParentElement(WebElements.get(0), "Benchmarks List common tag");
		ArrayList<String> tempData = new ArrayList<String>();
		//String primaryBenchmark = "";
		int size  = Elements.size();
		int count = 0;
		DecimalFormat ds = new DecimalFormat(".00");
		for (int i = 0; i < size/3; i++) {
			primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName-#-@percentage";
			primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
			if(Elements.get(count).getText().equals("—")) {
				action.moveToElement(Elements.get(count));
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count+1).getText());
				primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Float.parseFloat(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
			}else if (Elements.get(count+1).getText().equals("—")) {
				if(primaryBenchmark.contains("@benchmarkCategory")) {
					action.moveToElement(Elements.get(count+1));
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", Elements.get(count).getText());
					primaryBenchmark = primaryBenchmark.replace("@percentage", ds.format(Float.parseFloat(Elements.get(count+2).getText().substring(0, Elements.get(count+2).getText().length()-1))));
				}else {
					Reporter.addStepLog("Primary Benchmarks incorrectly populated in UI");
				}
				
			}
			tempData.add(primaryBenchmark);
			//data = data+primaryBenchmark+":";
			count = count + 3;
			
		}
		/*
		 * if(tempData.size() > 1) { Collections.sort(tempData); primaryBenchmark = "";
		 * for (String G : tempData) { primaryBenchmark = primaryBenchmark+G+":"; } }
		 * tempData.clear();
		 */
		
		return tempData;
		
	}

	public void moveToBenchmarkHeader() {
		List<WebElement> elements = action.getElements("Enity Header");
		action.moveToElement(elements.get(2));
		//action.highligthElement(elements.get(2));
		
	}
	
	public String getCommonAttributeValue(String attributeName) {
		Element = action.getElementByFormatingXpath("Common Attribute Value", attributeName);
		action.highligthElement(Element);
		return Element.getText();
	}

	public String getUnbundledithValuefromUI(int j) {
		Element = action.getElementByFormatingXpath("Unbundled Node ID Value", j);
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Element.getText().split(" - ")[0];
	}

	public Float getUnbundledPercentageithValuefromUI(int j) {
		Element = action.getElementByFormatingXpath("Unbundled Node ID Value", j);
		action.moveToElement(Element);
		action.highligthElement(Element);
		return Float.parseFloat(Element.getText().split(" - ")[1].substring(0, Element.getText().split(" - ")[1].length()-1));
	}

}
