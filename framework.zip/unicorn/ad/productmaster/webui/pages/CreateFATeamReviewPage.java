package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateFATeamReviewPage {
	Action action;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	String uiValue = null;

	public CreateFATeamReviewPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void verifyFinancialAdvisorDetailHeaderonReviewPage() {
		myElement = action.getElement("FA Team Details Title");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public void clickOnSubmitButtonOnFATeamReviewPage() {
		myElement = action.getElement("Submit Button");
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public void verifyFATeamEnterSaveAsDraftHeaderOnFaTeamReviewPage() {
		myElement = action.getElement("Review Header");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public String getFaTeamNameValue() {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", "FA Team Name");
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String getFaidValue() {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", "FA ID(s)");
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String getNameOfFaDiscretionaryProgramValue() {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", "Name of FA Discretionary Program");
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String getFaEmailValue() {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", "FA Email");
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String getAdditionalInformationValue() {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", "Additional Information");
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String getHomeOfficeCommentsValue() {
		myElement = action.getElementByFormatingXpath("Common Attribute Value", "Home Office Comments");
		action.highligthElement(myElement);
		return myElement.getText();
	}

	public String requiredDocumentValue(int i) {
		/*
		 * Document Type --> i=0 Document Link --> i=1 Document Comment --> i=2
		 * 
		 */
		List<WebElement> documentValues = action.getElements("Document Values");
		action.highligthElement(documentValues.get(i));
		return documentValues.get(i).getText();
	}

	public String getDataFromReviewPage(String data) {
		switch(data) {
			case "FA Team Name":
				uiValue = getFaTeamNameValue();
				break;
			case "FAIDs":
				uiValue = getFaidValue();
				break;
			case "Name of FA Discretionary Program":
				uiValue = getNameOfFaDiscretionaryProgramValue();
				break;
			case "FA Email":
				uiValue = getFaEmailValue();
				break;
			case "Additional Information":
				uiValue = getAdditionalInformationValue();
				break;
			case "Home Office Comments":
				uiValue = getHomeOfficeCommentsValue();
				break;
			case "Document Type":
				uiValue = requiredDocumentValue(0);
				break;
			case "Document Link":
				uiValue = requiredDocumentValue(1);
				break;
			case "Document Comment":
				uiValue = requiredDocumentValue(2);
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
		return uiValue;
	}
	
	public void clickOnPreviousButtonOnFATeamReviewPage() {
		myElement = action.getElement("Previous Button");
		action.highligthElement(myElement);
		action.click(myElement);
	}
}
