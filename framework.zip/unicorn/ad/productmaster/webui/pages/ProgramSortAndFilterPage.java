package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class ProgramSortAndFilterPage {

	Action action;
	WebElement Element;

	public ProgramSortAndFilterPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void searchProgramValue(String ProgramSearchValue) {
		action.pause(100);
		action.waitForPageLoad();
		Element = (WebElement) action.fluentWaitForJSWebElement("GlobalSearchvalueForProgram");
		Element.click();
		Element.clear();
		action.pause(100);
		action.sendKeys(Element, ProgramSearchValue);
		action.pause(1000);
		int i = 0;

		while (i < 5) {
			action.sendKeys(Keys.ENTER);
			i++;
		}

		Action.pause(1000);
	}

	public void clickOnSeeAllResultsForProgramLayout() {
		action.pause(1000);
		Element = (WebElement) action.fluentWaitForJSWebElement("SeeAllResultProgramLayout");
		// action.scrollToBottom();
		Element.click();
	}

	public void verifyTheSearchedResultInAllTabForProgram() {
		action.pause(1000);
		Element = (WebElement) action.fluentWaitForJSWebElement("AllTabProgram");
		action.highligthElement(Element);
		Element.isDisplayed();
	}

	public void verifyAndClickProgramTab() {
		action.pause(1000);
		Element = (WebElement) action.fluentWaitForJSWebElement("ProgramTab");
		// Action.pause(2000);
		action.highligthElement(Element);
		Element.isDisplayed();
		// Action.pause(2000);
		action.click(Element);
	}

	public String verifyTheGridCountBeforeApplyFilterAndSortCondition() {
		action.pause(3000);
		Element = action.fluentWaitWebElement("GridCountAfterGlobalSearchForProgram");
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void verifyTheNoResultsOnGridView() {
		action.pause(3000);
		Element = action.fluentWaitWebElement("NoResultToShow");
		action.highligthElement(Element);
		action.isDisplayed(Element);
	}

	public void verifySearchedGridViewDisplay() {
		action.pause(1000);
		Element = action.fluentWaitWebElement("GridViewProgram");
		Element.isDisplayed();
	}

	public void mouseHoverOnGridViewLabels(WebElement element) {
		// myElement = element;
		action.pause(1000);
		action.moveToElement(element);
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		Element = element.getElement("xpath", xpath);
		action.highligthElement(Element);
		return Element;
	}

	public void verifyGridViewLabelsWithSortIcons(WebElement element) {
		// myElement = element;
		action.pause(1000);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void verifyGridViewLabelsWithFilterIcons(WebElement element) {
		// myElement = element;
		action.pause(1000);
		action.highligthElement(element);
		action.scrollToElement(element);
		Assert.assertTrue(action.isDisplayed(element));
	}

	public void clickOnSortIcon(WebElement element) {
		// myElement = element;
		action.pause(1000);
		element.click();
	}

	public String verifyTheSortCoumnPropertyTypeASC() {
		action.pause(2000);
		Element = action.fluentWaitWebElement("AscSortOrder");
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDESC() {
		action.pause(2000);
		Element = action.fluentWaitWebElement("DescSortOrder");
		// Action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public String verifyTheSortCoumnPropertyTypeDefault() {
		action.pause(2000);
		Element = action.fluentWaitWebElement("DefaultSortOrder");
		// Action.pause(3000);
		return action.getAttribute(Element, "class");
	}

	public void clickOnFilterIconForGridView(WebElement element) {
		// myElement = element;
		action.pause(1000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.jsClick(element);
	}

	public void verifyValueOfFilterCondition(WebElement element) {
		// myElement = element;
		action.pause(1000);
		action.highligthElement(element);
		action.isDisplayed(element);
	}

	public void clickOnFilterCondition() {
		action.pause(1000);
		Element = action.fluentWaitWebElement("FilterCondition");
		action.click(Element);
	}

	public String verifyTheProgramGridCountAfterApplyFilterConditionOnTab() {
		action.pause(3000);
		Element = (WebElement) action.fluentWaitForJSWebElement("GridCountAfterfilterConditionOnTabForProgram");
		return action.getText(Element);
	}

	public void clickOnFilterConditionForProgramGridView(WebElement element) {
		action.pause(1000);
		action.highligthElement(element);
		action.isDisplayed(element);
		action.click(element);
	}

	public void enterFilterValue(String FilterValue) {
		action.pause(1000);
		Element = action.fluentWaitWebElement("FilterValue");
		action.click(Element);
		action.sendKeys(Element, FilterValue);
	}

	public void clickOnApplyFilterIconForProgramGridView() {
		action.pause(1000);
		Element = action.fluentWaitWebElement("ApplyButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public String verifyTheProgramGridCountAfterScroll() {
		action.pause(3000);
		Element = action.fluentWaitWebElement("GridCountAfterfilterCondition");
		return action.getAttribute(Element, "aria-rowcount");
	}

	public void clickOnApplyFilterIconForProgramGridViewForReset() {
		action.pause(1000);
		Element = action.fluentWaitWebElement("ResetButton");
		action.highligthElement(Element);
		action.click(Element);
	}

	public void clickOnApplyFilterIconForProgramGridViewForCancel() {
		action.pause(1000);
		Element = action.fluentWaitWebElement("CancelButton");
		action.highligthElement(Element);
		action.click(Element);
	}

}
