package qa.unicorn.ad.productmaster.webui.pages;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class ReviewStylePage {

	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStyleReviewPage"));
	WebElement myElement;
	
	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}
}
