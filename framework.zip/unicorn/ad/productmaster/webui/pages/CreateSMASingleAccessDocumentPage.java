package qa.unicorn.ad.productmaster.webui.pages;

public class CreateSMASingleAccessDocumentPage {

}
