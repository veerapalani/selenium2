package qa.unicorn.ad.productmaster.webui.pages;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdatePMPStrategyBenchmarkPage {
	Action action;
	public UpdatePMPStrategyBenchmarkPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	WebElement Element,Element2;
	
	public boolean isUserOnBenchmarkPage() {
		Element = action.waitForJSWebElement("Header");
		if(Element.getText().equals("Benchmark")) {
			action.highligthElement(Element);
			return true;
		}
		return false;
	}

	public String getPrimaryBenchmarkValue() {
		
		
		
		String PMPDefaultValue,PMPDefaultValuePercentage;
		String CustomBenchmarkValue, CustomBenchamrkPercentage;
		DecimalFormat df = new DecimalFormat(".00");
		String primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
		
		Element = action.getElement("Benchmark 1 Effective Date Type Value");
		String datetype = Element.getAttribute("value");
		if(datetype.equals("Since Inception")) {
			//primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
		String pmpDefaultRadio =((WebElement) action.fluentWaitForJSWebElement("PMP Default")).getAttribute("class");
		String customRadio =  ((WebElement) action.fluentWaitForJSWebElement("Custom")).getAttribute("class");
		ArrayList<String> tempData = new ArrayList<String>();
		if(pmpDefaultRadio == null && customRadio == null) {
			Reporter.addStepLog("Both PMP Default and Custom Benchamrks are not selected");
		}else {
			if(pmpDefaultRadio.equals("checked")){
				action.fluentWaitWebElement("View Details").click();
				//primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
				action.pause(1000);
				List<WebElement> Elements = action.getElements("Name");
				if(Elements.isEmpty()) {
					Elements.clear();
					tempData.clear();
					
					Element = action.getElement("xpath", "//th[contains(text(),'Benchmark Description')]/parent::tr/parent::tbody/following-sibling::tr/child::td[3]");
					Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
					Element = action.getElement("xpath", "//th[contains(text(),'Percentage')]/parent::tr/parent::tbody/following-sibling::tr/child::td[4]");
					List<WebElement> Elements2 = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
					
					for (int i = 0; i < Elements.size(); i++) {
						primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
						primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
						primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
						
						PMPDefaultValue = Elements.get(i).getText();
						PMPDefaultValuePercentage = Elements2.get(i).getText().substring(0, Elements2.get(i).getText().length()-1);
						PMPDefaultValuePercentage = df.format(Double.parseDouble(PMPDefaultValuePercentage));
						
						primaryBenchmark = primaryBenchmark.replace("@benchmarkName", PMPDefaultValue);
						primaryBenchmark = primaryBenchmark.replace("@percentage", PMPDefaultValuePercentage);
						tempData.add(primaryBenchmark);	
					}
					if(tempData.size() > 1) {
						Collections.sort(tempData);
						primaryBenchmark = "";
						for (String G : tempData) {
							primaryBenchmark = primaryBenchmark+G+":";
						}	
					}
					tempData.clear();
					clickOnCrossIcon();
				}else {
				primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Default");
				
				Element = action.getElement("Prepopulated PMP Default");
				PMPDefaultValue = Element.getText();
				Element = action.getElement("Prepopulated PMP Default Percentage");
				PMPDefaultValuePercentage = Element.getText();
				PMPDefaultValuePercentage = PMPDefaultValuePercentage.substring(0, PMPDefaultValuePercentage.length()-1);
				PMPDefaultValuePercentage = df.format(Double.parseDouble(PMPDefaultValuePercentage));
				
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", PMPDefaultValue);
				primaryBenchmark = primaryBenchmark.replace("@percentage", PMPDefaultValuePercentage);
				
				clickOnCrossIcon();
				}
				
			}else if(customRadio.equals("checked")){
				Element = action.getElement("Custom Benchmarks count");
				List<WebElement> Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
				String value;
				String[] values = null;
				for (int i = 0; i < Elements.size(); i++) {
					primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
					primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Since Inception");
					primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
					
					
					Element = action.getElementByFormatingXpath("Custom Benchmark Variable Path", i);
					value = Element.getAttribute("value");
					Element = action.getElementByFormatingXpath("Custom Benchmark Value", value);
					CustomBenchmarkValue = Element.getAttribute("name");
					values = CustomBenchmarkValue.split(" - ", 2);
					CustomBenchamrkPercentage = action.getElementByFormatingXpath("Custom Benchmark Percentage Value", i).getAttribute("value");
					
					primaryBenchmark = primaryBenchmark.replace("@benchmarkName", values[1]);
					primaryBenchmark = primaryBenchmark.replace("@percentage", CustomBenchamrkPercentage);
					tempData.add(primaryBenchmark);	
				}
				if(tempData.size() > 1) {
					Collections.sort(tempData);
					primaryBenchmark = "";
					for (String G : tempData) {
						primaryBenchmark = primaryBenchmark+G+":";
					}	
				}
				tempData.clear();	
			}
			
			
			
		}
		}else if(datetype.equals("Cap n Go")) {
			//primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Cap n Go");
			ArrayList<String> tempData = new ArrayList<String>();
			int timeperiodscount = 1;
			Element = action.getElement("Time Periods count");
			List<WebElement> TimePeriods = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
			for (WebElement webElement : TimePeriods) {
				action.getElementByFormatingXpath("Click on Time Period", timeperiodscount).click();
				action.pause(2000);
			Element = action.getElement("Custom Benchmarks count");
			List<WebElement> Elements = action.getElementsFromParentElement(Element, "Common Tag for Benchmarks");
			String value;
			String[] values = null;
			for (int i = 0; i < Elements.size(); i++) {
				primaryBenchmark = "@benchmarkCategory-#-@benchmarkeffectivedatetype-#-@benchmarkName--#-@percentage";
				primaryBenchmark = primaryBenchmark.replace("@benchmarkeffectivedatetype", "Cap n Go");
				primaryBenchmark = primaryBenchmark.replace("@benchmarkCategory", "Custom");
				
				
				Element = action.getElementByFormatingXpath("Custom Benchmark Variable Path", i);
				value = Element.getAttribute("value");
				Element = action.getElementByFormatingXpath("Custom Benchmark Value", value);
				CustomBenchmarkValue = Element.getAttribute("name");
				values = CustomBenchmarkValue.split(" - ", 2);
				CustomBenchamrkPercentage = action.getElementByFormatingXpath("Custom Benchmark Percentage Value", i).getAttribute("value");
				
				primaryBenchmark = primaryBenchmark.replace("@benchmarkName", values[1]);
				primaryBenchmark = primaryBenchmark.replace("@percentage", CustomBenchamrkPercentage);
				tempData.add(primaryBenchmark);	
				}
			
			timeperiodscount++;
			}
			if(tempData.size() > 1) {
				Collections.sort(tempData);
				primaryBenchmark = "";
				for (String G : tempData) {
					primaryBenchmark = primaryBenchmark+G+":";
				}	
			}
			tempData.clear();
			
		}
		return primaryBenchmark;
	}
	
	public void clickOnCrossIcon() {
		List<WebElement> Element =(List<WebElement>) action.getElements("Cross Icon");
		Element.get(1).click();
		
		action.pause(3000);
		
	}

	public void clickOnNext() {
		Element = action.fluentWaitWebElement("NEXT");
		Element.click();
		
	}
}
