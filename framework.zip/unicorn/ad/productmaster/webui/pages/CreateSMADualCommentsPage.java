package qa.unicorn.ad.productmaster.webui.pages;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebElement;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;

public class CreateSMADualCommentsPage {
	Action action;// new Action(SQLDriver.getEleObjData(""));
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	String expMsg="https://pm.uat.wmap.broadridge.com/pmui/#/smaDualMac/add";
	
	public CreateSMADualCommentsPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}
	
	public void selectCommentType() throws InterruptedException {
		Thread.sleep(1000);
		action.click((WebElement)action.getElementByJavascript("drpDwncomentType1"));
		action.click((WebElement)action.getElementByJavascript("drpDwncomentType1value"));
	}

	

	public void enterComment() throws InterruptedException {
		Thread.sleep(500);
		WebElement ele = (WebElement)action.getElementByJavascript("comments");
		action.highligthElement(ele);
		action.sendKeys(ele, "12345creatingsmadualdocuments");
	}
}
