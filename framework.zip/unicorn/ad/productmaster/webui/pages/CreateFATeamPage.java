package qa.unicorn.ad.productmaster.webui.pages;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class CreateFATeamPage {
	Action action;
	WebElement myElement, ele;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<String> list = new ArrayList<String>();
	static String applicationPropertyFilePath = "./application.properties";
	static PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	List<String> listOfString;
	public static LinkedHashMap<String, String> UIPassedValues = new LinkedHashMap<String, String>();
	CreateFinancialAdvisorPage fateamAdvisorPage = new CreateFinancialAdvisorPage("AD_PM_CreateFAPage");
	String uiValue = "";
	String timeStamp = new SimpleDateFormat("dd-MM-yyyy(HH:mm)").format(new Date());
	public CreateFATeamPage(String pageName) {
		action = new Action(SQLDriver.getEleObjData(pageName));
	}

	public void verifyFATeamWizardPage() {
		myElement = action.fluentWaitWebElement("Create Financial Advisor Wizard title");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void clickOnCreateButtonOnFAWizardPage() {
		action.scrollByPixel(Integer.toString(700));
		WebElement createButton = (WebElement)action.getElementByJavascript("Create Button");
		action.highligthElement(createButton);
		action.click(createButton);
	}

	public void verifyCreateButtonOnFAWizardPage() {
		WebElement createButton = (WebElement)action.getElementByJavascript("Create Button");
		action.highligthElement(createButton);
		Assert.assertTrue(action.isDisplayed(createButton));
		Reporter.addScreenCapture();
	}

	public void clickOnFATeamRadioButtonOnFATeamWizardPage() {
		action.fluentWaitForJSWebElement("Financial Advisor Team radio button");
		myElement = action.getElement("Financial Advisor Team radio button");
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public void verifyProductMasterHeaderOnlandingPage() {
		myElement = action.getElement("Product Master");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void verifyFATeamPage() {
		myElement = action.getElement("Create Financial Advisor Team");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void clickOnCancelButtonOnFATeamWizardPage() {
		WebElement styleelement = action.getElement("Cancel Button");
		action.highligthElement(styleelement);
		action.click(styleelement);
	}

	public void clickOnProductMasterhyperlinkOnFATeamPage() {
		WebElement styleelement = action.fluentWaitWebElement("Product Master hyperlink");
		action.highligthElement(styleelement);
		action.click(styleelement);
	}

	public void clickOnCancelButtonOnFATeamPage() {
		WebElement styleelement = (WebElement)action.getElementByJavascript("Cancel button on FA Team");
		action.highligthElement(styleelement);
		action.jsClick(styleelement);
	}

	public WebElement getDynamicElementFromShadowRoot(String javaScript) {
		return myElement = (WebElement)action.executeJavaScript(javaScript);
	}

	public void scrollToElement(WebElement element) {
		action.scrollToElement(element);
	}

	public void highlightElement(WebElement element) {
		action.highligthElement(element);
	}

	public void scrollAndClickOnLink(WebElement element) {
		scrollToElement(myElement);
		highlightElement(element);
		action.click(element);
	}

	public void clickOnNextButtonOnFATeamPage() {
		myElement = action.getElement("Next Button");
		action.highligthElement(myElement);
		action.click(myElement);
	}

	public void verifyFATeamDocumentHeaderonDocumentsPage() {
		myElement = action.getElement("Enter Document Links");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void clickOnElementsOnAddDocumentsPage() throws Throwable {
		myElement = (WebElement)action.getElementByJavascript("Previous Button_Documents page");
		scrollToElement(myElement);
		action.highligthElement(myElement);
		action.jsClick(myElement);
	}

	public void verifyElementsOnCreateFATeamPage(WebElement element) {
		myElement = element;
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
	}

	public WebElement findElementByDynamicXpath(String xpath) {
		Element element = new Element(WebDriverManager.getDriver());
		myElement = element.getElement("xpath", xpath);
		action.highligthElement(myElement);
		return myElement;
	}

	public void verifyFATeamEnterFADetailsHeaderonDocumentsPage() {
		myElement = action.getElement("Enter FA Details");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void clickOnSaveAsDraftButtonOnFATeamPage() {
		WebElement saveAsDraftelement = action.getElement("Save As Draft Button");
		action.highligthElement(saveAsDraftelement);
		action.click(saveAsDraftelement);
	}

	public void verifyFATeamEnterSaveAsDraftHeaderOnFaTeamPage() {
		myElement = (WebElement)action.getElementByJavascript("Save As Draft Popup Header");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void clickOnSaveAsDraftSaveButtonFATeamPage() {
		WebElement saveAsDraftSave = (WebElement)action.getElementByJavascript("Save Button Draft Popup");
		action.highligthElement(saveAsDraftSave);
		action.jsClick(saveAsDraftSave);
	}

	public void verifyFATeamEnterSaveAsDraftHeaderOnFaTeamReviewPage() {
		myElement = action.getElement("Review Header");
		action.highligthElement(myElement);
		Assert.assertTrue(action.isDisplayed(myElement));
		Reporter.addScreenCapture();
	}

	public void enterFATeamName(String faTeamName) throws InterruptedException {
		action.fluentWaitForJSWebElement("FA Team Name Text");
		ele = (WebElement)action.getElementByJavascript("FA Team Name Text");
		action.highligthElement(ele);
		action.sendKeys(ele, faTeamName + timeStamp);
		Thread.sleep(100);
	}

	public void enterFaEmail(String faEmail) throws InterruptedException {
		Thread.sleep(500);
		ele = (WebElement)action.getElementByJavascript("FA Email Text");
		action.highligthElement(ele);
		action.sendKeyCharterWise(ele, faEmail+ RandomStringUtils.randomAlphabetic(5));
		Thread.sleep(100);
	}

	public void enterAdditionalInformation(String additionalInformation) throws InterruptedException {
		Thread.sleep(500);
		ele = (WebElement)action.getElementByJavascript("Additional information Text");
		action.highligthElement(ele);
		action.sendKeys(ele, additionalInformation);
		Thread.sleep(100);
	}

	public void enterHomeOfficeComments(String homeOfficeComments) throws InterruptedException {
		Thread.sleep(500);
		ele = (WebElement)action.getElementByJavascript("Home Office Comments");
		action.highligthElement(ele);
		action.sendKeys(ele, homeOfficeComments);
		Thread.sleep(100);
	}

	public void selectNameOfFaDiscretionaryProgram() throws InterruptedException {
		Thread.sleep(700);
		ele = (WebElement)action.getElementByJavascript("Name of FA Discretionary Program");
		action.highligthElement(ele);
		action.click(ele);
		action.click((WebElement)action.getElementByJavascript("FA Discretionary Key"));
	}

	public void selectFaId() throws InterruptedException {
		Thread.sleep(1000);
		action.fluentWaitForJSWebElement("FA Id Dropdown");
		action.click((WebElement)action.getElementByJavascript("FA Id Dropdown"));
		action.fluentWaitForJSWebElement("FA Id Key1");
		action.click((WebElement)action.getElementByJavascript("FA Id Key1"));
		action.fluentWaitForJSWebElement("FA Id Key2");
		action.click((WebElement)action.getElementByJavascript("FA Id Key2"));
		action.fluentWaitForJSWebElement("Apply Button");
		action.click((WebElement)action.getElementByJavascript("Apply Button"));
	}
	
	public String getFATeamName() {
		action.fluentWaitForJSWebElement("FA Team Name Text");
		ele = (WebElement)action.getElementByJavascript("FA Team Name Text");
		uiValue=ele.getAttribute("value");
		System.out.println(uiValue);
		return uiValue;
	}
	
	public String getAdditionalInformation() throws InterruptedException {
		Thread.sleep(500);
		ele = (WebElement)action.getElementByJavascript("Additional information Text");
		action.highligthElement(ele);
		uiValue=ele.getAttribute("value");
		System.out.println(uiValue);
		return uiValue;
	}

	public String getHomeOfficeComments() throws InterruptedException {
		Thread.sleep(500);
		ele = (WebElement)action.getElementByJavascript("Home Office Comments");
		action.highligthElement(ele);
		uiValue=ele.getAttribute("value");
		System.out.println(uiValue);
		return uiValue;
	}
	public void highlightfateam() throws InterruptedException
	{
		Thread.sleep(5000);
		WebElement ele = (WebElement) action.getElementByJavascript("highlightelementfaname");
		
		action.highligthElement(ele);
		WebElement ele1 = (WebElement) action.getElementByJavascript("highlightteamnames");
		action.highligthElement(ele1);
		//highlightteamnames
		Reporter.addCompleteScreenCapture();
		
//		Thread.sleep(1000);
//		WebElement ele2 = (WebElement) action.getElementByJavascript("draftsaving");
//		
//		action.highligthElement(ele2);
//		action.click(ele2);
	}
}
