package qa.unicorn.ad.productmaster.webui.stepdefs;

import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdateStyleConfirmationStepDef {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStyleConfirmationPage"));
	 @Then("^User should be able to see the confirmation message in Update Style Confirmation page$")
	    public void user_should_be_able_to_see_the_confirmation_message_in_update_style_confirmation_page() throws Throwable {
		 action.getElement("Confirmation Message").isDisplayed();
		 Reporter.addStepLog("Able to see the confirmation message");
		 Reporter.addScreenCapture();
	 }
}
