package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyDocumentsPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreatePMPStrategyDocumentsStepDef {

	CreatePMPStrategyDocumentsPage documentsPage = new CreatePMPStrategyDocumentsPage("AD_PM_CreatePMPStrategyDocumentsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	
	
	@And("^User inputs (.+) in Documents Page in PMP Flow$")
    public void user_inputs_in_documents_page_in_pmp_flow(String mandatorydetails) throws IOException {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}

		String tName = Thread.currentThread().getName();
		String documentType,documentLink,documentComment = "";
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			documentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 23);
			documentLink = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 24);
			documentComment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 25);
			
		}
		
		
		if(documentType != "" && documentLink != "" && documentComment != "") {
			
			if(documentType.contains(",") && documentLink.contains(",") && documentComment.contains(",")) {
				String[] docType = documentType.split(",");
				String[] docLink = documentLink.split(",");
				String[] docComment = documentComment.split(",");
				
				int docTypeSize = docType.length;
				int docLinkSize = docLink.length;
				int docCommentSize = docComment.length;
				int size = Math.min(docCommentSize, docLinkSize);
				size = Math.min(size, docTypeSize);
				int i =0;
				
					while(size > 0) {
						documentsPage.selectDocumentType(docType[i]);
						documentsPage.enterDocumentLink(docLink[i]);
						documentsPage.enterDocumentComment(docComment[i]);
						documentsPage.clickOnAddDocumentLinkButton();
						size--;
						i++;
						if(size > 0) {
						documentsPage.clickOnAddAnotherDocument();
						}
					}
				
		        
			}
			else {
			
				documentsPage.selectDocumentType(documentType);
				documentsPage.enterDocumentLink(documentLink);
				documentsPage.enterDocumentComment(documentComment);
				documentsPage.clickOnAddDocumentLinkButton();
			}
			
		
		}
		
    }
    

    @And("^User clicks on Next in Documents Page$")
    public void user_clicks_on_next_in_documents_page() {
        documentsPage.clickOnNext();
    }
    
    @And("^User should be able to see Documents Page in PMP Flow$")
    public void user_should_be_able_to_see_documents_page_in_pmp_flow() {
        assertTrue(documentsPage.isUserOnDocumentsPage());
    }
    
    @And("^User clicks on Previous Button in Documents Page in PMP Flow$")
    public void user_clicks_on_previous_button_in_documents_page_in_pmp_flow() {
        documentsPage.clickOnPrevious();
    }
    
    @Then("^User input fields from (.+) should be visible in Documents Page in PMP Flow$")
    public void user_input_fields_from_should_be_visible_in_documents_page_in_pmp_flow(String mandatorydetails) {
        
    	if(mandatorydetails.contains("Test"))
    		sheetName = "Test";
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String tName = Thread.currentThread().getName();
		String documentType,documentLink,documentComment = "";
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			documentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 23);
			documentLink = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 24);
			documentComment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 25);
			
		}
		String[] docTypefromUser = documentType.split(",");
		String[] docLinkfromUser = documentLink.split(",");
		String[] docCommentfromUser = documentComment.split(",");
    	
    	ArrayList<ArrayList<String>> documents = new ArrayList<ArrayList<String>>();
		
    	int docCount = documentsPage.getcountofDocuments();
    	
    	for (int i = 0; i < docCount; i++) {
    		
			documents.add(documentsPage.getithDocumentInfo(i));
			
		}
    	int j = 0;
    	for (ArrayList<String> arrayList : documents) {
			Assert.assertTrue(documents.get(j).get(0).equalsIgnoreCase(docTypefromUser[j]));
			Assert.assertTrue(documents.get(j).get(1).equalsIgnoreCase(docLinkfromUser[j]));
			Assert.assertTrue(documents.get(j).get(2).equalsIgnoreCase(docCommentfromUser[j]));
			j++;
		}
    }
    
    @Then("^User should be able to see \"([^\"]*)\" value in Type dropdown list in Documents Page in PMP Flow$")
    public void user_should_be_able_to_see_something_value_in_type_dropdown_list_in_documents_page_in_pmp_flow(String dropDownValue) {
        
    	Assert.assertTrue(documentsPage.isValueDisplayedinTypeDropdown(dropDownValue));
    	
    }

    @And("^User clicks on Type dropdown in Documents Page in PMP Flow$")
    public void user_clicks_on_type_dropdown_in_documents_page_in_pmp_flow() {
        documentsPage.clickOnDocumentType();
        
    }
    
    @Then("^User should be not be able to see \"([^\"]*)\" value in Type dropdown list in Documents Page in PMP Flow$")
    public void user_should_be_not_be_able_to_see_something_value_in_type_dropdown_list_in_documents_page_in_pmp_flow(String dropDownValue) {
        
    	Assert.assertFalse(documentsPage.isValueDisplayedinTypeDropdown(dropDownValue));
    	
    }
    
}
