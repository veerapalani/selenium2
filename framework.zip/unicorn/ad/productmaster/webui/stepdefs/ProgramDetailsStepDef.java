package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.parsing.Problem;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.IntegrationGeneric;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.ProgramDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.StyleDetailsPage;

public class ProgramDetailsStepDef {
	
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ProgramDetailsPage"));
	PMPageGeneric ProgramDetail=new PMPageGeneric("AD_PM_ProgramDetailsPage");
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	String expectedColorCode;
	String xpath;
	
	@Then("^User should be able to see \"([^\"]*)\" header on Program Details page$")
    public void user_should_be_able_to_see_something_header_on_program_details_page(String key) throws Throwable {
		ProgramDetail.verifyHeader(key);
		// ProgramDetail.verifyHeader(key);
    }
	
	@And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Program Details page$")
    public void something_should_be_displayed_in_something_color_on_program_details_page(String key, String expectedColor) throws Throwable {
		expectedColorCode = Action.getTestData(expectedColor);
		ProgramDetail.verifyColor(key, expectedColorCode);
		Reporter.addStepLog("validated that the color of "+key+" is "+expectedColor);
		Reporter.addScreenCapture();
		
    }
	
	@And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Program Details page$")
    public void something_should_be_displayed_in_something_color_inside_program_details_page(String key, String expectedColor) throws Throwable {
		expectedColorCode = Action.getTestData(expectedColor);
		ProgramDetail.verifyColor(ProgramDetail.getElementFromShadowRoot(key), expectedColorCode);
    }
	
	@Then("^User should be able to see the \"([^\"]*)\" inside Program Details page$")
    public void user_should_be_able_to_see_the_something_inside_program_details_page(String key) throws Throwable {
        ProgramDetail.verifyElement(ProgramDetail.getElementFromShadowRoot(key));
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Program Details page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_inside_program_details_page(String ghostText,
			String searchBox) throws Throwable {
    	ProgramDetail.verifyGhostText(ghostText, ProgramDetail.getElementFromShadowRoot(searchBox));
    }
	
	@Then("^User should be able to see the \"([^\"]*)\" on Program Details page$")
    public void user_should_be_able_to_see_the_something_on_program_details_page(String key) throws Throwable {
		ProgramDetail.verifyElement(key);
    }
	
	@Then("^User should be able to see the bottom-border below \"([^\"]*)\" on Program Details page$")
    public void user_should_be_able_to_see_the_bottomborder_below_something_on_program_details_page(String key) throws Throwable {
		String widthInPixel= ProgramDetail.giveCssValue(ProgramDetail.getElement(key), "border-bottom-width");
	       String width = widthInPixel.substring(0, widthInPixel.length()-2);
	       Assert.assertTrue(Integer.parseInt(width)>0); 
    }
	@And("^user should be able to see the below attributes on Program Details page$")
    public void user_should_be_able_to_see_the_below_attributes_on_program_details_page(List<String> attributes) throws Throwable {
		listOfElements = ProgramDetail.getElements("Attributes");
	       for(int i=0;i<attributes.size();i++)
	    	   {
	    	   ProgramDetail.verifyTextInListOfElements(attributes.get(i), listOfElements);
	    	   }
    }
	
	@And("^the attributes on Program Details Page should contain one of the below following values$")
    public void the_attributes_on_program_details_page_should_contain_one_of_the_below_following_values(List<List<String>> attributeValuePair) throws Throwable {
		String myValue=null;
    	
    	for(int i=0;i<attributeValuePair.size();i++) {
    	String xpath="//small[contains(text(),'"+attributeValuePair.get(i).get(0)+"')]/ancestor::p/following-sibling::span";
    	myValue=ProgramDetail.findElementByDynamicXpath(xpath).getText();
    	Reporter.addStepLog("The value for "+attributeValuePair.get(i).get(0)+" is "+myValue);
    	String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
    	for(int j=0;j<listOfValues.length;j++) {
    	if(myValue.equals(listOfValues[j]))
    		{Assert.assertTrue(true);
    		break;}
    	
    	else 
    		Assert.assertFalse(true);
    	
    	}
        }
    }

	@And("^The \"([^\"]*)\" on the Program Details page should contain all the following options$")
    public void the_something_on_the_program_details_page_should_contain_all_the_following_options(String key,List<String> options) throws Throwable {
		listOfElements = ProgramDetail.getElements(key);
        for(int i=0;i<options.size();i++) {
        	ProgramDetail.verifyTextInListOfElements(options.get(i), listOfElements);
        }
	}
	 @And("^compare the string values given in API and the values displayed in UI in Program Details page$")
	    public void compare_the_values_given_in_api_and_the_values_displayed_in_ui_in_program_details_page(List<List<String>> APIUIAttributePair) {
		 String APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().get(APIUIAttributePair.get(i).get(0));
		  xpath="//small[contains(text(),'"+APIUIAttributePair.get(i).get(1)+"')]/ancestor::p/following-sibling::span";
		 UIValue=ProgramDetail.findElementByDynamicXpath(xpath).getText();
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+APIValue);
		 
		 }
		 Reporter.addScreenCapture();
	    }
	 @And("^compare the numeric values given in API and the values displayed in UI in Program Details page$")
	    public void compare_the_numeric_values_given_in_api_and_the_values_displayed_in_ui_in_program_details_page(List<List<String>> APIUIAttributePair) {
		 float APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().getFloat(APIUIAttributePair.get(i).get(0));
		  xpath="//small[contains(text(),'"+APIUIAttributePair.get(i).get(1)+"')]/ancestor::p/following-sibling::span";
		 UIValue=Float.parseFloat(ProgramDetail.findElementByDynamicXpath(xpath).getText());
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+APIValue);
		 
		 }
		 Reporter.addScreenCapture();
	    }

	    @And("^retrieve the \"([^\"]*)\" time stamp from Program Details page and store it$")
	    public void retrieve_the_something_time_stamp_from_program_details_page_and_store_it(String attribute){
	     xpath="//small[contains(text(),'"+attribute+"')]/ancestor::p/following-sibling::span"; 
	     ProgramDetail.verifyElement(ProgramDetail.findElementByDynamicXpath(xpath));
	     IntegrationGeneric.dateInString = ProgramDetail.findElementByDynamicXpath(xpath).getText();
	    }
	    
	    @And("^user clicks the \"([^\"]*)\" on Program Details page$")
	    public void user_clicks_the_something_on_program_details_page(String key) throws Throwable {
	        ProgramDetail.clickOnLink(key);
	    }
	    
	    @And("^The text written in \"([^\"]*)\" should match with the value of \"([^\"]*)\" attribute on Program Details page$")
	    public void the_text_written_in_something_should_match_with_the_value_of_something_attribute_on_program_details_page(String actualKey, String expectedKey) throws Throwable {
	    	Assert.assertEquals(ProgramDetail.getText(actualKey), ProgramDetail.getText(expectedKey));
	    	Reporter.addStepLog("validated the "+actualKey);
	    }
    }
	

