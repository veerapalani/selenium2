package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerEnterManagerDetailsPage;

public class UpdateManagerEnterManagerDetailsStepDef {
	
	UpdateManagerEnterManagerDetailsPage managerDetailsPage = new UpdateManagerEnterManagerDetailsPage("AD_PM_UpdateManagerEnterManagerDetailsPage");
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateManager.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue, flowPageData = null;
	
	@Then("^user should be able to see Enter Manager Details Page in Update Manager flow$")
    public void user_should_be_able_to_see_enter_manager_details_page_in_update_manager_flow() {
        Assert.assertTrue(managerDetailsPage.isUserOnEnterManagerDetailsPage());
    }
	
	@And("^User inputs the values from (.+) in Manager details page in Update Manager Flow$")
    public void user_inputs_the_values_from_in_manager_details_page_in_update_manager_flow(String mandatorydetails) throws IOException {
		
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		int updateDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex+1;
    	
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			String managerName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 2);
			String firmName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 3);
			String firmWebsite = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 4);
			//String vestmarkManagerName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 5);
			String vestmarkManagerName = RandomStringUtils.randomAlphabetic(10);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 5, vestmarkManagerName);
			String taxPayerIdentificationNumber = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 6);
			String largeTraderID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 7);
			String dtccID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 8);
			String status = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 9);
			String fourEyeCheckOverride = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 10);
			String ubsSubsudiary = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 11);
		
			if(firmName != "") {
				managerDetailsPage.enterManagerName(managerName);
				managerDetailsPage.enterfirmName(firmName);
				managerDetailsPage.enterfirmWebsite(firmWebsite);
				managerDetailsPage.entervestmarkManagerName(vestmarkManagerName);
				managerDetailsPage.entertaxPayerIdentificationNumber(taxPayerIdentificationNumber);
				managerDetailsPage.enterlargeTraderID(largeTraderID);
				managerDetailsPage.enterdtccID(dtccID);
				managerDetailsPage.enterfourEyeCheckOverride(fourEyeCheckOverride);
				if(ubsSubsudiary != "")
					managerDetailsPage.enterubsSubsudiary(ubsSubsudiary);
				
			}
		}
		
		Reporter.addScreenCapture();
	    
	}
	
	@And("^User clicks on Next in Enter Manager Details Page in Update Manager Flow$")
    public void user_clicks_on_next_in_enter_manager_details_page_in_update_manager_flow() {
        managerDetailsPage.clickOnNext();
    }
	
	@And("^Data prepopulated in Enter Manager Details page should match with DB Data in Update Manager flow for (.+)$")
    public void data_prepopulated_in_enter_manager_details_page_should_match_with_db_data_in_update_manager_flow_for(String mandatorydetails) {

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 2;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int dbDataRowIndex = rowIndex+1;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("Delete Contacts"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Contacts"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterManagerDetailsPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						
						
						if(label.contains("4 Eye Check Override"))
						{
							switch (attributeValue.toLowerCase()) {
							case "true":
								attributeValue = "Yes";
								break;
							case "false":
								attributeValue = "No";
								break;
							default:
								break;
							}
						}
						System.out.println(attributeValue);
						System.out.println(dbValue);
						if(!dbValue.equals(attributeValue)) {
							
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							Assert.fail(label);
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Contacts"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			
    
    }

	private String getDataFromEnterManagerDetailsPage(String data) {
	    	switch (data) {
			case "Manager Name":
				
				uiValue = managerDetailsPage.getManagerNameValue();
				
				break;
			case "Firm Name":
				
				uiValue = managerDetailsPage.getFirmNameValue();
				
				break;
			case "Firm Website":
				
				uiValue = managerDetailsPage.getFirmWebsiteValue();
				
				break;
			case "Vestmark Manager Name":
				
				uiValue = managerDetailsPage.getVestmarkManagerNameValue();
				
				break;
			case "Taxpayer Identification Number":
				
				uiValue = managerDetailsPage.getTaxPayerIdentificationNumberValue();
				
				break;
			case "Large Trader ID":
				
				uiValue = managerDetailsPage.getLargeTraderIDValue();
				
				break;
			case "DTCC ID":
				
				uiValue = managerDetailsPage.getdtccIDValue();
				
				break;
			case "Status":
				
				uiValue = managerDetailsPage.getStatusValue();
				
				break;
			case "4 Eye Check Override":
				
				uiValue = managerDetailsPage.get4EyeCheckOverrideValue();
				
				break;
			case "UBS Subsidiary":
				
				uiValue = managerDetailsPage.getUBSSubsidiaryValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—") || uiValue.isEmpty())
			uiValue = "isEmpty";
	
		return uiValue;
	}
	
	@And("^data from Enter Manager Details page should be stored in Excel for (.+) in Update Manager Flow$")
    public void data_from_enter_manager_details_page_should_be_stored_in_excel_for_in_update_manager_flow(String mandatorydetails) throws IOException {

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 2;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int flowPageDataRowIndex = rowIndex+3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("Delete Contacts"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Contacts"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterManagerDetailsPage(label);
						
						
						if(label.contains("4 Eye Check Override"))
						{
							switch (attributeValue.toLowerCase()) {
							case "true":
								attributeValue = "Yes";
								break;
							case "false":
								attributeValue = "No";
								break;
							default:
								break;
							}
						}
						
						PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Contacts"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			
    
    }
	
	@Then("^Data populated in Manager Details should match with data before moving to another page in Update Manager Flow for (.+)$")
    public void data_populated_in_manager_details_should_match_with_data_before_moving_to_another_page_in_update_manager_flow_for(String mandatorydetails) {
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 2;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int flowPageDataRowIndex = rowIndex+3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("Delete Contacts"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Contacts"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterManagerDetailsPage(label);
						flowPageData = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						
						
						if(label.contains("4 Eye Check Override"))
						{
							switch (attributeValue.toLowerCase()) {
							case "true":
								attributeValue = "Yes";
								break;
							case "false":
								attributeValue = "No";
								break;
							default:
								break;
							}
						}
						
						if(flowPageData.equals(attributeValue)) {
							
						}else {
							
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value populated is not same as value displayed before moving to another page");
							Assert.fail(label);
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Contacts"))
								label = "isEmpty";
					
					}
			}
    }
	
	@And("^user is able to see the text field for \"([^\"]*)\" is editable in Update Manager flow$")
    public void user_is_able_to_see_the_text_field_for_something_is_editable_in_update_manager_flow(String label) {
        Assert.assertTrue(managerDetailsPage.isTextFieldEditable(label));
    }
	
	@Then("^user should be able to see the following values in the following dropdown in Enter Manager Details Page in Update Manager flow$")
    public void user_should_be_able_to_see_the_following_values_in_the_following_dropdown_in_enter_manager_details_page_in_update_manager_flow(List<List<String>> attributeValuePair) {
		
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Assert.assertTrue(managerDetailsPage.isDropdownValuesDisplayedInUI(attributeValuePair.get(i)));
		}
        
    }
	
	@Then("^User should be able to select Yes or No option in the following radio button attributes in Enter Manager Details Page in Update Manager flow$")
    public void user_should_be_able_to_select_yes_or_no_option_in_the_following_radio_button_attributes_in_enter_manager_details_page_in_update_manager_flow(List<String> attribute) {
		for (int i = 0; i < attribute.size(); i++) {
			Assert.assertTrue(managerDetailsPage.isUserabletoSelectYesorNoInUI(attribute.get(i)));
		}
    }

	@Then("^User should not be able to see any error message in Manager details page in Update Manager Flow$")
    public void user_should_not_be_able_to_see_any_error_message_in_manager_details_page_in_update_manager_flow() {
		String message = "Website should not be allowed to enter";
		Assert.assertFalse(managerDetailsPage.isMessageDisplayedinUI(message));
    }
	
	@Then("^User should be able to see error message in Manager details page in Update Manager Flow$")
    public void user_should_be_able_to_see_error_message_in_manager_details_page_in_update_manager_flow() {
		String message = "Website should not be allowed to enter";
		Assert.assertTrue(managerDetailsPage.isMessageDisplayedinUI(message));
    }

    @And("^User clicks on Reset button in Enter Manager Details Page in Update Manager flow$")
    public void user_clicks_on_reset_button_in_enter_manager_details_page_in_update_manager_flow() {
        managerDetailsPage.clickOnReset();
    }
    
    @And("^Progress Bar should be displayed at top in Enter Manager Details Page in Update Manager flow$")
    public void progress_bar_should_be_displayed_at_top_in_enter_manager_details_page_in_update_manager_flow() {
        Assert.assertTrue(managerDetailsPage.isPregressBarDisplayed());
    }
    
}
