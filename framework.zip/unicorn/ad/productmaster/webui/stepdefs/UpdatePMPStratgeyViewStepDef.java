package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdatePMPStratgeyViewPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASWPAAPPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessUIPage;

public class UpdatePMPStratgeyViewStepDef {
	//UpdatePMPStratgeyViewPage viewPage = new UpdatePMPStratgeyViewPage("AD_PM_UpdatePMPStrategyViewPage");
	//	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
	//XSSFSheet sheet;
	//String sheetName;
	String label, attributeValue, uiValue, dbValue = null;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateEntityPage"));
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	String sheetName = "";
	String myValue;
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	WebElement myElement;
	List<WebElement> myElements;
	UpdateSMASingleAccessUIPage updateSMASinglePage = new UpdateSMASingleAccessUIPage();
	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	UpdatePMPStratgeyViewPage viewPage = new UpdatePMPStratgeyViewPage("AD_PM_UpdatePMPStrategyViewPage");
	int num;
	//	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	//
	//	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateEntityPage"));
	//
	//	UpdateSMASingleAccessUIPage updateSMASinglePage = new UpdateSMASingleAccessUIPage();
	//	UpdateSMASWPAAPPage UpdateSMAStrategy = new UpdateSMASWPAAPPage("AD_PM_UpdateSMASWPAAPPage");
	////	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	SoftAssert sftAst = new SoftAssert();
	//
	//	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	HashMap<String, Object> row = new HashMap<String, Object>();
	//	
	public static int count;
		
		@Then("^Values for Attributes in View Page of PMP Strategy should match the values for attributes stored in DB$")
	    public void values_for_attributes_in_view_page_of_pmp_strategy_should_match_the_values_for_attributes_stored_in_db() throws IOException {
			String excelFilePath2 = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
			sheetName = "Conversion_Validation";
			   //sheet = exlObj.getSheet(sheetName);
			   count = 0;
			   int rownum = 1;
			  // label = (String) exlObj.getCellData(sheet, rownum, 0);
			   label = PMPageGeneric.getCellDataSync(excelFilePath2, sheetName, rownum, 0);
			   if(label == "")
					label = "isEmpty";
				while (label != "isEmpty") {
														
						if(label.contains("ignore") || label.contains("NIVDP")) {
								rownum++;
				    			//label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
				    			label = PMPageGeneric.getCellDataSync(excelFilePath2, sheetName, rownum, 0).toString();
				    			if(label == "")
				    				label = "isEmpty";
						}else {
							
							attributeValue = getDataFromViewPage(label);
							dbValue = PMPageGeneric.getCellDataSync(excelFilePath2, sheetName, rownum, 3);
									//(String) exlObj.getCellData(sheet, rownum, 3).toString();
							if(dbValue.equals(attributeValue)) {
								//exlObj.setCellData(sheet, rownum, 4, attributeValue);
								PMPageGeneric.setCellDataSync(excelFilePath2, sheetName, rownum, 4, attributeValue);
							}else {
								//exlObj.setCellData(sheet, rownum, 4, attributeValue+" -UI Value is not same as Stored Value in DB");
								PMPageGeneric.setCellDataSync(excelFilePath2, sheetName, rownum, 4, attributeValue+" -UI Value is not same as Stored Value in DB");
								Reporter.addEntireScreenCaptured();
								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
								count++;
								
							}
								rownum++;
								//label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
								label = PMPageGeneric.getCellDataSync(excelFilePath2, sheetName, rownum, 0).toString();
								if(label == "")
									label = "isEmpty";
						
						}
				}
				if(count > 0) {
					Assert.fail("Prepopulated Values are not same as values stored in DB");
				}
				Reporter.addCompleteScreenCapture();
				Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
				//exlObj.closeWorkBook();
	    }
	
	    private String getDataFromViewPage(String data) {
		    	switch (data) {
				case "Risk Category":
					
					uiValue = viewPage.getRiskCategoryValue();
					
					break;
				case "PIV Style":
					
					uiValue = viewPage.getPIVStyleValue();
					
					break;
				case "Geographic Indicator":
					
					uiValue = viewPage.getGeographicIndicatorValue();
					
					break;
				case "Strategy Name":
					
					uiValue = viewPage.getStrategyNameValue();
					
					break;
				case "Strategy Code":
					
					uiValue = viewPage.getStrategyCodeValue();
					
					break;
				case "Balanced Allocation":
					
					uiValue = viewPage.getBalancedAllocationValue();
					
					break;
				case "Concentrated Strategy Indicator_radiobutton":
					
					uiValue = viewPage.getConcentratedStrategyIndicatorValue();
					
					break;
				case "Structured Products Strategy_radiobutton":
					
					uiValue = viewPage.getStructuredProductsStrategyValue();
					
					break;
				case "Margins":
					
					uiValue = viewPage.getMarginsValue();
					
					break;
				case "Status":
					
					uiValue = viewPage.getStrategyStatusValue();
					
					break;
				case "Concord Eligible(NEW)":
					
					//uiValue = reviewPage.getConcordEligibleValue();
					
					break;
				case "Options Approval Level Code":
					
					//uiValue = reviewPage.getOptionalApprovalLevelCodeValues();
					
					break;
				case "Hedge Core Indicator_radiobutton":
					
					uiValue = viewPage.getHedgeCoreIndicatorValue();
					
					break;
				case "Style Pairing Code":
					
					uiValue = viewPage.getStylePairingCodeValue();
					
					break;
				case "Risk Tolerance":
					
					//uiValue = reviewPage.getRiskToleranceValue();
					
					break;
				case "Portfolio Strategy Group Code":
					
					//uiValue = reviewPage.getPortfolioStrategyGroupCodeValue();
					
					break;
				case "Investment Style":
					
					uiValue = viewPage.getInvestmentStyleValue();
					
					break;
				case "Primary Benchmark":
					
					uiValue = viewPage.getPrimaryBenchmarkValue();
					//To be changed after defect 22896 is closed
					//uiValue = "isEmpty";
					break;
				default:
					
					uiValue = "NotChanged";
					
					break;
			}
		    	if(uiValue.equals("—"))
					uiValue = "isEmpty";
		
			return uiValue;
		}
	    
	    @And("^User clicks on Continue Editing Button in View Strategy Page in Update PMP Strategy Flow$")
	    public void user_clicks_on_continue_editing_button_in_view_strategy_page_in_update_pmp_strategy_flow() {
	        viewPage.clickOnContinueEditingButton();
	    }
	
	    @And("^User is in View Strategy Page in Update PMP Strategy Flow$")
	    public void user_is_in_view_strategy_page_in_update_pmp_strategy_flow() {
			Assert.assertTrue(viewPage.isUserOnViewPMPStrategyPage());
	    }
	    

	@When("^User search with the (.+) taken from (.+) in the Search TextBox on landing page whilst updating PMP Strategy$")
	public void user_search_with_the_taken_from_in_the_search_textbox_on_landing_page_whilst_updating_pmp_strategy(
			String entity, String searchcode) throws Throwable {
		Thread.sleep(5000);
		sheetName = "PMPStrategy";
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Data");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchcode);
		myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		searchcode = myValue;
		System.out.println(myValue);
		Boolean compareBoolean = action.isPresent("js",
				"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
		if(compareBoolean) {
			Thread.sleep(5000);
			myElement = (WebElement)action.executeJavaScript(
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}
		Thread.sleep(5000);
		myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		Thread.sleep(5000);
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;
		while(i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);
	}

	@Then("^User clicks on the first element that gets populated after quering in the strategy FOA Code$")
	public void user_clicks_on_the_first_element_that_gets_populated_after_quering_in_the_strategy_foa_code()
			throws Throwable {
		myElements = updateSMASinglePage
				.findElementsByDynamicXpath("//label[contains(text(),'PMP Strategy')]//parent::div//div[2]");
		String status = "FAIL";
		for(WebElement E: myElements) {
			if(E.getText().toUpperCase().contains(myValue.toUpperCase())) {
				status = "PASS";
				action.scrollToElement(E);
				Thread.sleep(5000);
				action.highligthElement(E);
				Thread.sleep(5000);
				E.click();
				Reporter.addStepLog("clicking on the matching suggestion");
				break;
			}
			if(status.contentEquals("FAIL")) {
				myElement.sendKeys(Keys.ENTER);
				myElements = updateSMASinglePage
						.findElementsByDynamicXpath("//label[contains(text(),'PMP Strategy')]//parent::div//div[2]");
				for(WebElement E1: myElements) {
					if(E1.getText().toUpperCase().contains(myValue.toUpperCase())) {
						action.scrollToElement(E1);
						action.highligthElement(E1);
						Thread.sleep(5000);
						E1.click();
						action.waitForPageLoad();
						Reporter.addStepLog("clicking on the matching suggestion");
						break;
					}
				}
			}
		}
	}

	@Then("^User clicks on the CONTINUE EDITING Button on PMPStrategy Details page$")
	public void user_clicks_on_the_continue_editing_button_on_pmpstrategy_details_page() throws Throwable {
		Thread.sleep(3000);
		myElement = updateSMASinglePage.findElementByDynamicXpath("//span[contains(text(),'CONTINUE EDITING')]");
		action.highligthElement(myElement);
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("Clicked on Continue Editing Button");
		Thread.sleep(3000);
	}

	@And("^User has provided the below fields as inputs for the text fields$")
	public void user_has_provided_the_below_fields_as_inputs_for_the_text_fields(List<List<String>> attribute)
			throws Throwable {
		sheetName = "PMPStrategy";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			System.out.println(attribute.get(i).get(0) + " value " + myValue);
			action.sendKeys(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^for the inputs whose values are chosen through drop down list are as follows$")
	public void for_the_inputs_whose_values_are_chosen_through_drop_down_list_are_as_follows(
			List<List<String>> attribute) throws Throwable {
		sheetName = "PMPStrategy";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(2000);
			myElement = (WebElement)action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^user decides to check the box that is there in order to make the strategy Margin Eligible$")
	public void user_decides_to_check_the_box_that_is_there_in_order_to_make_the_strategy_margin_eligible()
			throws Throwable {
		myElement = (WebElement)action
				.executeJavaScript("return document.querySelector(\'brml-checkbox[id=\"marginEligible\"]')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Reporter.addStepLog("Clicked on margin eligible checkbox");
		Thread.sleep(2000);
	}

	@And("^as user comes into the benchmark page as selects the PMP Default checkbox then the selected benchmark is derived from the Investment style$")
	public void as_user_comes_into_the_benchmark_page_as_selects_the_pmp_default_checkbox_then_the_selected_benchmark_is_derived_from_the_investment_style()
			throws Throwable {
		myElement = (WebElement)action.executeJavaScript(
				"return document.querySelector(\"brml-radio[id='benchmark-mode-selectionbenchmark1']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(3000);
		Reporter.addStepLog("Clicked on Next button");
	}

	@And("^the user continues the update PMP Strategy flow by clicking on the next button$")
	public void the_user_continues_the_update_pmp_strategy_flow_by_clicking_on_the_next_button() throws Throwable {
		myElement = (WebElement)action
				.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(3000);
		Reporter.addStepLog("Clicked on Next button");
	}

	@And("^user chooses to change the value for the custom benchmark from the dropdown list$")
	public void user_chooses_to_change_the_value_for_the_custom_benchmark_from_the_dropdown_list(
			List<List<String>> attribute) throws Throwable {
		sheetName = "PMPStrategy";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(2000);
			myElement = (WebElement)action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^User chooses cap and go from the benchmark effective date type dropdown$")
	public void user_chooses_cap_and_go_from_the_benchmark_effective_date_type_dropdown(List<List<String>> attribute)
			throws Throwable {
		sheetName = "PMPStrategy";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(2000);
			myElement = (WebElement)action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^the user provides the desired value for the benchmark percentage$")
	public void the_user_provides_the_desired_value_for_the_benchmark_percentage(List<List<String>> attribute)
			throws Throwable {
		sheetName = "PMPStrategy";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			System.out.println(attribute.get(i).get(0) + " value " + myValue);
			action.sendKeys(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^User searches the same strategy and same CASP should be displayed on view page for (.+)$")
	public void user_searches_the_same_strategy_and_same_casp_should_be_displayed_on_view_page(String mandatorydetails)
			throws Throwable {
		excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails + "_" + SSOLoginPage.UIEnvironment.trim().toLowerCase();
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		String strategyCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 29);
		Thread.sleep(2000);
		if(strategyCode != "") {
			landingPage.enterSearchToken(strategyCode);
			landingPage.clickOnSearchIcon();
			landingPage.verifySeeAllResultsButton();
			landingPage.clickOnSeeAllResultsButton();
			landingPage.verifyUserIsOSeeAllResultsTab();
			landingPage.clickOnTab("PMPStrategy");
			landingPage.mouseHoveOnSearchedRecordsOnGrid();
			landingPage.movetoFirstElementinFilteredrecords();
			landingPage.clickOnEllipsesIcon();
			landingPage.verifyOnViewDetailsLink();
			landingPage.clickOnViewDetailsLink();
			landingPage.verifyUserIsOnViewPMPPage();
		}
		String givenData = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 28);
		String pmpDefaultValue = viewPage.getBenchmarkValues(0);
		String percentage = viewPage.getBenchmarkValues(2);
		String percentageTotal = percentage.substring(0, percentage.length()-1);
		Assert.assertTrue(givenData.contains(pmpDefaultValue));
		Assert.assertTrue(givenData.contains(percentageTotal));
	}
}
