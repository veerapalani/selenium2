package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.FAsSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;

public class FAsSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	FAsSortAndFilterPage fAsSortAndFilterPage = new FAsSortAndFilterPage("AD_PM_FAsSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/FAAndFATeamSortAndFilter.xlsx";
	String sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	WebElement myElement, myElement2;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_FAsSortAndFilterPage"));

	@When("^User enter valid (.+) in global search box for FAs$")
	public void user_enter_valid_in_global_search_box_for_fas(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String FAsSearchValue = (String) exlObj.getCellData(sheet, rowIndex, 2);

		exlObj.closeWorkBook();
		if (FAsSearchValue != "") {
			fAsSortAndFilterPage.searchFAsValue(FAsSearchValue);
		}
		Reporter.addScreenCapture();
	}

	@And("^user clicks on \"([^\"]*)\" on landing page for FAs$")
	public void user_clicks_on_something_on_landing_page_for_fas(String strArg1) throws Throwable {
		fAsSortAndFilterPage.clickOnSeeAllResultsForFAsLayout();
	}

	@And("^user is able to see search results in \"([^\"]*)\" tab under FAs accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_fas_accordion(String strArg1)
			throws Throwable {
		fAsSortAndFilterPage.verifyTheSearchedResultInAllTabForFAs();
	}

	@And("^user click on \"([^\"]*)\" tab on landing page for FAs$")
	public void user_click_on_something_tab_on_landing_page_for_fas(String strArg1) throws Throwable {
		fAsSortAndFilterPage.verifyAndClickFAsTab();
	}

	@Then("^User should be able to search records for FAs View using the global search box on landing page$")
	public void user_should_be_able_to_search_records_for_fas_view_using_the_global_search_box_on_landing_page()
			throws Throwable {
		fAsSortAndFilterPage.verifySearchedGridViewDisplay();
	}

	@And("^User able to see searched grid view data for FAs grid view$")
	public void user_able_to_see_searched_grid_view_data_for_fas_grid_view() throws Throwable {
		String gridCountBeforeCondition = fAsSortAndFilterPage.verifyTheGridCountBeforeApplyFilterAndSortCondition();
		// String gridCountBeforeCondition =
		// FAsSortAndFilterPage.gridCountAfterGlobalSearch;
		int beforeApplyCondition = Integer.parseInt(gridCountBeforeCondition);
		if (beforeApplyCondition == 1)
			fAsSortAndFilterPage.verifyTheNoResultsOnGridView();
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design for FAs$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design_for_fas(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fAsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			fAsSortAndFilterPage.mouseHoverOnGridViewLabels(
					fAsSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			fAsSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			fAsSortAndFilterPage.verifyGridViewLabelsWithSortIcons(
					fAsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}

	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for FAs$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_fas(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fAsSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			fAsSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					fAsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for FAs$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_fas(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fAsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			fAsSortAndFilterPage.mouseHoverOnGridViewLabels(
					fAsSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			fAsSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			fAsSortAndFilterPage.clickOnSortIcon(
					fAsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for FAs$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_fas() throws Throwable {
		String value = fAsSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = FAsSortAndFilterPage.ascSortValue;
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for FAs$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_fas(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fAsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			fAsSortAndFilterPage.mouseHoverOnGridViewLabels(
					fAsSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			fAsSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			fAsSortAndFilterPage.clickOnSortIcon(
					fAsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for FAs$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_fas() throws Throwable {
		String value = fAsSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = FAsSortAndFilterPage.descSortValue;
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for FAs$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_fas(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fAsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			fAsSortAndFilterPage.mouseHoverOnGridViewLabels(
					fAsSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			fAsSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]");
			fAsSortAndFilterPage.clickOnSortIcon(
					fAsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for FAs$")
	public void user_should_able_to_sort_the_records_with_default_order_for_fas() throws Throwable {
		String value = fAsSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = FAsSortAndFilterPage.defaultSortValue;
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to click on the filter icon for below column for FAs$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_fas(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fAsSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			fAsSortAndFilterPage.clickOnFilterIconForGridView(
					fAsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to validate the filter condition all options for FAs$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_fas(List<String> entity)
			throws Throwable {
		fAsSortAndFilterPage.clickOnFilterCondition();
		for (int i = 0; i < entity.size(); i++) {
			fAsSortAndFilterPage
					.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']");
			fAsSortAndFilterPage.verifyValueOfFilterCondition(fAsSortAndFilterPage.findElementByDynamicXpath(
					"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to see tab count as per searched keyword for before any condition for FAs$")
	public void user_able_to_see_tab_count_as_per_searched_keyword_for_before_any_condition_for_fas() throws Throwable {
		String beforeApplyFilterValue = fAsSortAndFilterPage.verifyTheFAsGridCountAfterApplyFilterConditionOnTab();
		// String beforeApplyFilterValue = FAsSortAndFilterPage.tabCountAfterCondition;
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);
	}

	@And("^User able to select the (.+) from filter condition for FAs$")
	public void user_able_to_select_the_from_filter_condition_for_fas(String filtercondition) throws Throwable {
		fAsSortAndFilterPage.clickOnFilterCondition();
		fAsSortAndFilterPage.clickOnFilterConditionForFAsGridView(fAsSortAndFilterPage.findElementByDynamicXpath(
				"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for FAs$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_fas(String filterconditionvalue)
			throws Throwable {
		fAsSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button on FAs grid view$")
	public void user_able_to_click_on_the_apply_button_on_fas_grid_view() throws Throwable {
		fAsSortAndFilterPage.clickOnApplyFilterIconForFAsGridView();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on FAs grid view$")
	public void user_should_able_to_verify_the_grid_count_on_fas_grid_view() throws Throwable {
		String countTabAfterFilter = fAsSortAndFilterPage.verifyTheFAsGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter = FAsSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = fAsSortAndFilterPage.verifyTheFAsGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition / 10; i++) {
				action.scrollToBottom();
				action.pause(1000);
				String presentGridAllData = fAsSortAndFilterPage.verifyTheFAsGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			fAsSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
			Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
					"The tab count and grid view count mismatch");
		}
	}

	@And("^User should able to verify the Tab count on FAs grid view$")
	public void user_should_able_to_verify_the_tab_count_on_fas_grid_view() throws Throwable {
		String countTabAfterFilter = fAsSortAndFilterPage.verifyTheFAsGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter = FAsSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = fAsSortAndFilterPage.verifyTheFAsGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= beforeApplyFiltertabCountValue; i++) {
				action.scrollToBottom();
				action.pause(1000);
				String presentGridAllData = fAsSortAndFilterPage.verifyTheFAsGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			fAsSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The tab count and grid view mismatch");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Reset Button on FAs grid view$")
	public void user_able_to_click_on_the_reset_button_on_fas_grid_view() throws Throwable {
		fAsSortAndFilterPage.clickOnApplyFilterIconForFAsGridViewForReset();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button on FAs grid view$")
	public void user_able_to_click_on_the_cancel_button_on_fas_grid_view() throws Throwable {
		fAsSortAndFilterPage.clickOnApplyFilterIconForFAsGridViewForCancel();
		Reporter.addScreenCapture();
	}

	@And("^User able to select the (.+) from filter date condition for FAs$")
	public void user_able_to_select_the_from_filter_date_condition_for_fas(int filtercondition) throws Throwable {
		action.pause(4000);
		myElement = fAsSortAndFilterPage.getDynamicElementFromShadowRoot(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > ul > div.os-padding > div > div > li:nth-child("
						+ filtercondition + ") > span')");
		action.highligthElement(myElement);
		action.click(myElement);

		if (filtercondition == 6) {
			action.pause(2000);
			myElement = fAsSortAndFilterPage.getDynamicElementFromShadowRoot(
					"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-range.date-picker-wrapper > div > div > div.pmu-days >div:nth-child(5)')");
			action.highligthElement(myElement);
			action.click(myElement);
			action.pause(3000);
			myElement2 = fAsSortAndFilterPage.getDynamicElementFromShadowRoot(
					"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-range.date-picker-wrapper > div > div > div.pmu-days >div:nth-child(25)')");
			action.scrollToElement(myElement2);
			action.highligthElement(myElement2);
			action.click(myElement2);
		}
	}

	@And("^User able to click on Date the Apply Button on FAs grid view$")
	public void user_able_to_click_on_date_the_apply_button_on_fas_grid_view() throws Throwable {
		action.pause(2000);
		myElement = fAsSortAndFilterPage.getDynamicElementFromShadowRoot(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(3)')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@And("^User able to click on Date the Reset Button on FAs grid view$")
	public void user_able_to_click_on_date_the_reset_button_on_fas_grid_view() throws Throwable {
		action.pause(4000);
		myElement = fAsSortAndFilterPage.getDynamicElementFromShadowRoot(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(1)')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@And("^User able to click on Date the Cancel Button on FAs grid view$")
	public void user_able_to_click_on_date_the_cancel_button_on_fas_grid_view() throws Throwable {
		action.pause(2000);
		myElement = fAsSortAndFilterPage.getDynamicElementFromShadowRoot(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(2)')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@And("^User should able to see filter window$")
	public void user_should_able_to_see_filter_window() throws Throwable {
		Assert.assertTrue(fAsSortAndFilterPage.verifyApplyButtonIsDisplayed());
		Reporter.addScreenCapture();
	}

	@Then("^User can able to see that filter window should close$")
	public void user_can_able_to_see_that_filter_window_should_close() throws Throwable {
		Assert.assertFalse(fAsSortAndFilterPage.verifyApplyButtonIsDisplayed());
		Reporter.addScreenCapture();
	}

}
