package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;


import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class GlobalSearchStepDef {
	GlobalSearchPage globalsearchpage=new GlobalSearchPage();
	PMPageGeneric GlobalSearch=new PMPageGeneric("AD_PM_GlobalSearchPage");
	String expectedColorCode,xpath;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	
	 @And("^user hover over the \"([^\"]*)\" of first element of \"([^\"]*)\" on Global Search page$")
	    public void user_hover_over_the_something_of_first_element_of_something_on_global_search_page(String insideElementKey, String parentElementKey) throws Throwable {
		 listOfElements = GlobalSearch.getElements(insideElementKey);
			GlobalSearch.hoverOnElement(listOfElements.get(0));
			Reporter.addStepLog("hovering on "+insideElementKey);
	    }

	    @And("^user clicks the \"([^\"]*)\" on Global Search page$")
	    public void user_clicks_the_something_on_global_search_page(String key) throws Throwable {
	        GlobalSearch.clickOnLink(key);
	    }
	    @And("^User clicks on Search Button$")
	    public void user_clicks_on_global_search_button() throws Throwable {
	    	globalsearchpage.click_on_Search_icon();
	    	
	    }
	    
	    @Then("^User should be able to see the following \"([^\"]*)\" while hovering on the \"([^\"]*)\" in every row of \"([^\"]*)\" on Global Search page$")
	    public void user_should_be_able_to_see_the_following_something_while_hovering_on_the_something_in_every_row_of_something_on_global_search_page(String options, String insideElementKey, String strArg2) throws Throwable {
	    	listOfElements = GlobalSearch.getElements(insideElementKey);
	    	listOfElements2 = GlobalSearch.getElements(options);
	    	for(int i=0;i<Math.min(listOfElements.size(),5) ;i++)
	    	{		
	    		GlobalSearch.verifyHoverElement(listOfElements.get(i), listOfElements2.get(i));
	    			Reporter.addStepLog("verified "+options+ " for element no"+(i+1));
	    			GlobalSearch.scrollByPixel(100);
	    			
	    		}
	    	}	
	    @Then("^User should be able to see \"([^\"]*)\" in \"([^\"]*)\" on Global Search page$")
	    public void user_should_be_able_to_see_something_on_global_search_page(String list1, String key) throws Throwable {
	    	String[] listArray = list1.split(", ");
	    	listOfElements =  GlobalSearch.getElements(key);
	    	for(int i=0;i<listArray.length;i++) {
	    		GlobalSearch.verifyTextInListOfElements(listArray[i], listOfElements);
	    		Reporter.addStepLog(listArray[i]+" is displaying in " + key);
	    	}
	    }
	    
	    @And("^Order of the \"([^\"]*)\" should be \"([^\"]*)\" on Global Search page$")
	    public void order_of_the_something_should_be_something_on_Manager_Entity_page(String key, String list1) throws Throwable {
			String[] listArray = list1.split(", ");
	     	listOfElements =  GlobalSearch.getElements(key);
	     	for(int i=0;i<listArray.length;i++) {
	     		Assert.assertEquals( listOfElements.get(i).getText(),listArray[i]);
	     		Reporter.addStepLog(listOfElements.get(i).getText()+" is the "+i+" element in " + key);
	     	}
	    }
	    @Then("^User should be able to see \"([^\"]*)\" for every row in \"([^\"]*)\" on global search screen$")
	    public void user_should_be_able_to_see_something_for_every_row_in_something_on_global_search_screen(String insideElementKey, String key) throws Throwable {
	    	listOfElements = GlobalSearch.getElements(key);
	        listOfElements2 =GlobalSearch.getElements(insideElementKey);
	        for(int i=0;i<listOfElements.size();i++) {
	        	GlobalSearch.verifyElement( listOfElements2.get(i));
	        	Reporter.addStepLog("verified "+insideElementKey+ " for element no "+(i+1));
	        	Reporter.addScreenCapture();
	        } 
	    }
	    @Then("^User should be able to see the \"([^\"]*)\" on Global search page$")
	    public void user_should_be_able_to_see_the_something_on_global_search_page(String Key) throws Throwable {
	    	globalsearchpage.verifyElement(Key);
	    }
	    
	    @Then("^User should observe \"([^\"]*)\" header on Global search page$")
        
	    public void text__should_be_able_seeon_global_search_page_text(String Key) throws Throwable {
	    	Assert.assertEquals(globalsearchpage.getHeaderText(), "Product Master");
	    }
	    
	    @Then("^User should observe \"([^\"]*)\" in every row of \"([^\"]*)\" on Global Search page$")
	    public void should_observe_somethingon_global_search_page(String insideElementKey, String key) throws Throwable {
	    	listOfElements = globalsearchpage.getElements(key);
	        
	        for(int i=0;i<listOfElements.size();i++) {
	        	globalsearchpage.verifyInsideElement(listOfElements.get(i), insideElementKey);
	        	Reporter.addStepLog("verified "+insideElementKey+ " for element no "+(i+1));
	        }
	    }

}
