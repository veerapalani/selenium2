package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.CreateFAReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class CreateFAReviewStepDef {
	WebElement myElement, myElement2;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateFAReviewPage"));
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateFA.xlsx";
	String option, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	CreateFAReviewPage createobj = new CreateFAReviewPage("AD_PM_CreateFAReviewPage");
	SoftAssert sftAst = new SoftAssert();

	@And("^User enters the details required on the Review Page$")
	public void user_enters_the_details_required_on_the_review_page() throws Throwable {
		// createobj.entersubmitterposition();
		// createobj.attestationchkboxinreviewpage();
	}

	@And("^User Clicks on the Submit button in the Review page$")
	public void user_clicks_on_the_submit_button_in_the_review_page() throws Throwable {
		Reporter.addCompleteScreenCapture();
		createobj.clickonsubmitbutoninreviewpage();
	}

	@Then("^user should not be able to see the Attestation section in the Review Page$")
	public void user_should_not_be_able_to_see_the_attestation_section_in_the_review_page() throws Throwable {
		createobj.verifyreviewtitle();
	}

	@Then("^user should be able to see the Approver name in the Review Page$")
	public void user_should_be_able_to_see_the_approver_name_in_the_review_page() throws Throwable {
		createobj.verifyapprovername();
	}

	@Then("^User verifies the details on Review Page is displayed as entered with (.+)$")
	public void user_verifies_the_details_on_Review_Page_is_displayed_as_entered(String valid_data) throws Throwable {
		if (valid_data.contains("Test")) {
			sheetName = "Test";
		}
		sheet = exlObj.getSheet(sheetName);
		int count = sheet.getRow(0).getLastCellNum();
		for (int i = 1; i < count; i++) {
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, valid_data);
			String label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex - 1, i);
			String labelValue = createobj.getcommonattributevalue(label);
			String givenData = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, i);
			if (!(givenData.isEmpty() || labelValue.contains("-"))) {
				sftAst.assertTrue(createobj.getcommonattributevalue(label).equals(givenData));
			}
		}
		Reporter.addScreenCapture();
	}

	@And("^User clicks on Previous button review page$")
	public void user_clicks_on_previous_button_review_page() throws Throwable {
		createobj.clickonpreviousbuttoninreviewpage();
		Reporter.addScreenCapture();
	}
}
