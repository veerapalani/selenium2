package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStrategyEnterStrategyDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class RejectedStrategyEnterStrategyDetailsStepDef {

	RejectedStrategyEnterStrategyDetailsPage strategyDetailsPage = new RejectedStrategyEnterStrategyDetailsPage("AD_PM_RejectedStrategyEnterStrategyDetailsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
	
	//ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	int rowIndex;
	XSSFSheet sheet;
	String sheetName, userInfo;
	String label, attributeValue, uiValue,dbValue = null;
	
	//public static int count;
	
	
	@Then("^User should able to see FA Team drop down value with Team members below FA Team Field In Rejection Strategy Details page as per wireframe $")
    public void user_should_able_to_see_fa_team_drop_down_value_with_team_members_below_fa_team_field_in_rejection_strategy_details_page_as_per_wireframe() throws Throwable {
		strategyDetailsPage.validateFATeam();
    }
	
	@Then("^Values for Attributes in Enter Strategy Details Page of Rejected Strategies Resubmission Flow should match the values for attributes stored in DB$")
    public void values_for_attributes_in_enter_strategy_details_page_of_rejected_strategies_resubmission_flow_should_match_the_values_for_attributes_stored_in_db() throws IOException {
		sheetName = "Conversion_Validation";
		   //sheet = exlObj.getSheet(sheetName);
		   int rownum = 1;
		   //count = 0;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if((label == "") || (label.contains("Primary Benchmark")))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || (label.contains("NIESDP"))) {
							rownum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if((label == "") ||(label.contains("Primary Benchmark")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterStrategyDetailsPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 3);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							//exlObj.setCellData(sheet, rownum, 5, attributeValue);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 5, attributeValue);
						}else {
							//exlObj.setCellData(sheet, rownum, 5, attributeValue+"-UI Value is not same as Stored Value in DB");
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 5, attributeValue+"-UI Value is not same as Stored Value in DB");
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							//count++;
							
						}
						
							rownum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("Primary Benchmark")))
								label = "isEmpty";
					
					}
			}
			
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In Enter Strategy Details Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
    }
	
	private String getDataFromEnterStrategyDetailsPage(String data) {
		
			switch (data) {
			case "Risk Category":
				
				uiValue = strategyDetailsPage.getRiskCategoryValue();
				
				break;
			case "PIV Style":
				
				uiValue = strategyDetailsPage.getPIVStyleValue();
				
				break;
			case "Geographic Indicator":
				
				uiValue = strategyDetailsPage.getGeographicIndicatorValue();
				
				break;
			case "Strategy Name":
				
				uiValue = strategyDetailsPage.getStrategyNameValue();
				
				break;
			case "Strategy Code":
				
				uiValue = strategyDetailsPage.getStrategyCodeValue();
				
				break;
			case "Balanced Allocation":
				
				uiValue = strategyDetailsPage.getBalancedAllocationValue();
				
				break;
			case "Concentrated Strategy Indicator_radiobutton":
				
				uiValue = strategyDetailsPage.getConcentratedStrategyIndicatorValue();
				
				break;
			case "Structured Products Strategy_radiobutton":
				
				uiValue = strategyDetailsPage.getStructuredProductsStrategyValue();
				
				break;
			case "Margins":
				
				uiValue = strategyDetailsPage.getMarginEligibleValue();
				
				break;
			case "Status":
				
				uiValue = strategyDetailsPage.getStrategyStatusValue();
				
				break;
			case "Hedge Core Indicator_radiobutton":
				
				uiValue = strategyDetailsPage.getHedgeCoreIndicatorValue();
				
				break;
			case "Style Pairing Code":
				
				uiValue = strategyDetailsPage.getStylePairingCodeValue();
				
				break;
			case "Investment Style":
				
				uiValue = strategyDetailsPage.getInvestmentStyleValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if((uiValue == null) || (uiValue.isEmpty()))
			uiValue = "isEmpty";
	
		return uiValue;
	}

	@And("^User is in Enter Strategy Details Page in Rejected Strategies Resubmission Flow$")
    public void user_is_in_enter_strategy_details_page_in_rejected_strategies_resubmission_flow() {
        Assert.assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailsPage());
    }
	
	@And("^(.+) is in Enter Strategy Details Page in Rejected Strategies Resubmission Flow$")
    public void is_in_enter_strategy_details_page_in_rejected_strategies_resubmission_flow(String typeofuser) {
		
		Assert.assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailsPage());
		userInfo = typeofuser;
    }
	
	@And("^User clicks on Next Button in Enter Startegy Details Page of Rejected Strategies Resubmission Flow$")
    public void user_clicks_on_next_button_in_enter_startegy_details_page_of_rejected_strategies_resubmission_flow() {
        strategyDetailsPage.clickOnNext();
    }
	
	@And("^Data prepopulated in Enter Strategy Details page should match with DB Data in Rejected Strategy Resubmission flow for (.+)$")
    public void data_prepopulated_in_enter_strategy_details_page_should_match_with_db_data_in_rejected_strategy_resubmission_flow_for(String mandatorydetails) throws IOException {
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
				if(mandatorydetails.contains("Test"))
					sheetName = "Test";
				 Boolean flag = true;
				   //sheet = exlObj.getSheet(sheetName);
				   //count = 0;
				   int columnIndex = 3;
				   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
				   int dbDataRowIndex = rowIndex+1;
				   int flowPageDataRowIndex = rowIndex+3;
				   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
						   //(String) exlObj.getCellData(sheet, rownum, 0);
				   
				   if(label == "" || label.contains("radiobutton - BenchmarkCategory"))
						label = "isEmpty";
					while (label != "isEmpty") {
									
						if(label.contains("checkbox - Hide Strategy"))
						{
							if(userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
								label = "ignore";
							}
						}
						if(label.contains("FA Email"))
						{
								label = "ignore";
						}
						flag = true;
							if(label.contains("ignore") || label.contains("NIESP")) {
								columnIndex++;
								
					    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
					    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
					    			
					    			if(label == "" || label.contains("radiobutton - BenchmarkCategory"))
					    				label = "isEmpty";
							}else {
								
								attributeValue = getDataFromStrategyDetailsPage(label);
								dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
								System.out.println("Label : "+label);
								System.out.println("Attribute Value : "+attributeValue);
								System.out.println("DB Value : "+dbValue);
								
								if(label.contains("FA Team Members Detail") && !dbValue.equalsIgnoreCase("isEmpty")) {
									System.out.println("Inside First If");
									String fATeamMemberNamesfromUI = attributeValue;
									String fATeamMemberNamesfromDB = dbValue;
									String[] tempData = dbValue.split(":");
									if(fATeamMemberNamesfromDB.replace(":", ", ").length() == fATeamMemberNamesfromUI.length()) {
										System.out.println("Inside second If");
										for(String string: tempData) {
											if(!fATeamMemberNamesfromUI.contains(string));
												flag = false;
										}
									}
									System.out.println(flag);
									
								}
								System.out.println(!(dbValue.equals(attributeValue)) && flag == true);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
								if(!label.equals("grey - Unbundled Node ID")) {
								if(!(dbValue.equals(attributeValue)) && flag == true) {
									
									Reporter.addEntireScreenCaptured();
									Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
									Assert.fail(label);
								}
								}
								
								columnIndex++;
									label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
											//(String) exlObj.getCellData(sheet, rownum, 0).toString();
									
									if(label == "" || label.contains("radiobutton - BenchmarkCategory"))
										label = "isEmpty";
							
							}
					}
//					if(count > 0) {
//						Assert.fail("Prepopulated Values are not same as values stored in DB");
//					}
					//Reporter.addCompleteScreenCapture();
					//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }

    private String getDataFromStrategyDetailsPage(String data) {
	    	switch (data) {
			case "txt - Strategy Name":
				
				uiValue = strategyDetailsPage.getStrategyNameValue();
				
				break;
			case "drp - Investment Style":
				
				uiValue = strategyDetailsPage.getInvestmentStyleValue();
				
				break;
			case "drp - FA Name":
				
				uiValue = strategyDetailsPage.getFANameValue();
				
				break;
			case "drp - FA Team Name":
				
				uiValue = strategyDetailsPage.getFATeamNameValue();
				
				break;
			case "ne - FA Team Members Detail":
				
				uiValue = strategyDetailsPage.getFATeamMemberDetailValue();
				
				break;
			case "drp - Status":
				
				uiValue = strategyDetailsPage.getStrategyStatusValue();
				
				break;
			case "drp - PMP Title":
				
				uiValue = strategyDetailsPage.getPMPTitleValue();
				
				break;
			case "drp - Strategy Tier":
				
				uiValue = strategyDetailsPage.getStrategyTierValue();
				
				break;
			case "grey - Market Cap":
				
				uiValue = strategyDetailsPage.getMarketCapValue();
				
				break;
			case "grey - Risk Category":
				
				uiValue = strategyDetailsPage.getRiskCategoryValue();
				
				break;
			case "grey - Fee Schedule Type":
				
				uiValue = strategyDetailsPage.getFeeScheduleTypeValue();
				
				break;
			case "grey - PIV Style":
				
				uiValue = strategyDetailsPage.getPIVStyleValue();
				
				break;
			case "grey - Geographic Indicator":
				
				uiValue = strategyDetailsPage.getGeographicIndicatorValue();
				
				break;
			case "grey - Balanced Allocation":
				
				uiValue = strategyDetailsPage.getBalancedAllocationValue();
				
				break;
			case "grey - Investment Style Category":
				
				uiValue = strategyDetailsPage.getInvestmentStyleCategoryValue();
				
				break;
			case "grey - Comparative Universe":
				
				uiValue = strategyDetailsPage.getComparativeUniverseValue();
				
				break;
			case "grey - Bunded Node ID":
				
				uiValue = strategyDetailsPage.getBundledNodeIDValue();
				
				break;
			case "grey - Unbundled Node ID":
				
				uiValue = strategyDetailsPage.getUnbundledNodeIDValue();
				
				break;
			case "grey - Style Pairing Code":
				
				uiValue = strategyDetailsPage.getStylePairingCodeValue();
				
				break;
			case "radiobutton - Concentrated Strategy Indicator":
				
				uiValue = strategyDetailsPage.getConcentratedStrategyIndicatorValue();
				
				break;
			case "radiobutton - Structured Products Strategy":
				
				uiValue = strategyDetailsPage.getStructuredProductsStrategyValue();
				
				break;
			case "radiobutton - Hedge Core Indicator":
				
				uiValue = strategyDetailsPage.getHedgeCoreIndicatorValue();
				
				break;
			case "radiobutton - Short Term Maturity":
				
				uiValue = strategyDetailsPage.getShortTermMaturityValue();
				
				break;
			case "radiobutton - Alternatives Strategy":
				
				uiValue = strategyDetailsPage.getAlternativesStrategyValue();
				
				break;
			case "radiobutton - Sustainable Investment Strategy":
				
				uiValue = strategyDetailsPage.getSustainableInvestmentStrategyValue();
				
				break;
			case "grey - FOA Code":
				
				uiValue = strategyDetailsPage.getStrategyCodeValue();
				
				break;
			case "grey - Single Strategy Only":
				
				uiValue = strategyDetailsPage.getSingleStrategyOnlyValue();
				
				break;
			case "checkbox - Margin Eligible":
				
				uiValue = strategyDetailsPage.getMarginEligibleValue();
				
				break;
			case "txt - FA Email":
				
				uiValue = strategyDetailsPage.getFAEmailValue();
				
				break;
			case "txt - Non PMP Approved Team Member Email":
				
				uiValue = strategyDetailsPage.getNonPMPApprovedTeamMemberEmailValue();
				
				break;
			case "drp - DVP/Key Trust Template":
				
				uiValue = strategyDetailsPage.getDVPTemplateValue();
				
				break;
			case "checkbox - Hide Strategy":
						
				uiValue = strategyDetailsPage.getHideStrategyValue();
						
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—") || uiValue.isEmpty())
			uiValue = "isEmpty";
	
		return uiValue;
	}

	@And("^User inputs the values from (.+) in Enter Strategy details page in Rejected Strategy Resubmission Flow$")
    public void user_inputs_the_values_from_in_enter_strategy_details_page_in_rejected_strategy_resubmission_flow(String mandatorydetails) {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		int updateDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex+1;
    	
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			String strategyName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 3);
			String investmentStyleName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 4);
			String faName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 5);
			String faTeamName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 6);
			String faTeamMembersDetail = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 7);
			String status = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 8);
			String pmpTitle = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 9);
			String strategyTier = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 10);
			String marketCap = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 11);
			String riskCategory = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 12);
			String feeScheduleType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 13);
			String pivStyle = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 14);
			String geographicIndicator = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 15);
			String balancedAllocation = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 16);
			String investmentStyleCategory = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 17);
			String comparativeUniverse = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 18);
			String bundledNodeID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 19);
			String unbundledNodeID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 20);
			String stylePairingCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 21);
			String concentratedStrategyIndicator = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 22);
			String structuredProductsStrategy = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 23);
			String hedgeCoreIndicator = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 24);
			String shortTermMaturity = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 25);
			String alternativesStrategy = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 26);
			String sustainableInvestmentStrategy = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 27);
			String foaCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 28);
			String singleStrategyOnly = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 29);
			String marginEligible = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 30);
			String faEmail = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 31);
			String nonPMPApprovedTeamMemberEmails = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 32);
			String dvpKeyTrustTemplate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 33);
			String hideStrategy = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 34);
			
			
			strategyDetailsPage.enterStrategyName(strategyName);
			
			if (investmentStyleName != "")
				strategyDetailsPage.enterInvestmentStyleName(investmentStyleName);
			
			if (faName != "") {
				
					strategyDetailsPage.selectFARadioButton();
					strategyDetailsPage.enterFaName(faName, "fa");
					strategyDetailsPage.setFASelection("fa");
			
			}
			if (faTeamName != "") {
	
					strategyDetailsPage.selectFATeamRadioButton();
					strategyDetailsPage.enterFaName(faTeamName, "faTeam");
					strategyDetailsPage.setFASelection("faTeam");
				
			}
			
			strategyDetailsPage.enterFaTeamMembersDetail(faTeamMembersDetail);
			strategyDetailsPage.enterStatus(status);
			
			if(pmpTitle != "")
				if(userInfo.contains("HO"))
					strategyDetailsPage.enterPmpTitle(pmpTitle);
			
			if(strategyTier != "")
				strategyDetailsPage.enterStrategyTier(strategyTier);
			
			strategyDetailsPage.enterMarketCap(marketCap);
			strategyDetailsPage.enterRiskCategory(riskCategory);
			strategyDetailsPage.enterFeeScheduleType(feeScheduleType);
			strategyDetailsPage.enterPivStyle(pivStyle);
			strategyDetailsPage.enterGeographicIndicator(geographicIndicator);
			strategyDetailsPage.enterBalancedAllocation(balancedAllocation);
			strategyDetailsPage.enterInvestmentStyleCategory(investmentStyleCategory);
			strategyDetailsPage.enterComparativeUniverse(comparativeUniverse);
			strategyDetailsPage.enterBundledNodeID(bundledNodeID);
			strategyDetailsPage.enterUnbundledNodeID(unbundledNodeID);
			strategyDetailsPage.enterStylePairingCode(stylePairingCode);
			strategyDetailsPage.enterConcentratedStrategyIndicator(concentratedStrategyIndicator);
			
			strategyDetailsPage.enterStructuredProductsStrategy(structuredProductsStrategy);
			if(!structuredProductsStrategy.equals("Yes")) {
				strategyDetailsPage.enterStrategyTier(strategyTier);
			}
			
			strategyDetailsPage.enterHedgeCoreIndicator(hedgeCoreIndicator);
			strategyDetailsPage.enterShortTermMaturity(shortTermMaturity);
			strategyDetailsPage.enterAlternativesStrategy(alternativesStrategy);
			strategyDetailsPage.enterSustainableInvestmentStrategy(sustainableInvestmentStrategy);
			strategyDetailsPage.enterFoaCode(foaCode);
			strategyDetailsPage.enterSingleStrategyOnly(singleStrategyOnly);
			strategyDetailsPage.enterMarginEligible(marginEligible);
			strategyDetailsPage.enterFaEmail(faEmail);
			strategyDetailsPage.enterNonPMPApprovedTeamMemberEmails(nonPMPApprovedTeamMemberEmails);
			
			if(dvpKeyTrustTemplate != "")
				strategyDetailsPage.enterDvpKeyTrustTemplate(dvpKeyTrustTemplate);
			
			if(hideStrategy != "")
				if(userInfo.contains("HO"))
					strategyDetailsPage.enterHideStrategy(hideStrategy);
			
			
				//if(ubsSubsudiary != "")
					//managerDetailsPage.enterubsSubsudiary(ubsSubsudiary);
				
			
		}
		
		Reporter.addCompleteScreenCapture();
    }

    @And("^data from Enter Strategy Details page should be stored in Excel for (.+) in Rejected Strategy Resubmission Flow$")
    public void data_from_enter_strategy_details_page_should_be_stored_in_excel_for_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException {
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
//    	strategyDetailsPage.refreshThePage();
//    	Assert.assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailsPage());
    			if(mandatorydetails.contains("Test"))
    				sheetName = "Test";
    				
    			   //sheet = exlObj.getSheet(sheetName);
    			   //count = 0;
    			   int columnIndex = 3;
    			   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    			   int flowPageDataRowIndex = rowIndex+3;
    			   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    					   //(String) exlObj.getCellData(sheet, rownum, 0);
    			   
    			   if(label == "" || label.contains("radiobutton - BenchmarkCategory"))
    					label = "isEmpty";
    				while (label != "isEmpty") {
    											
    						if(label.contains("checkbox - Hide Strategy"))
    						{
    							if(userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
    								label = "ignore";
    							}
    						}
    						if(label.contains("FA Email"))
    						{
    								label = "ignore";
    						}
    						if(label.contains("ignore") || label.contains("NIESP")) {
    							columnIndex++;
    							
    				    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    				    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
    				    			
    				    			if(label == "" || label.contains("radiobutton - BenchmarkCategory"))
    				    				label = "isEmpty";
    						}else {
    							
    							attributeValue = getDataFromStrategyDetailsPage(label);
    							
    							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
    							columnIndex++;
    								
    								label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    										//(String) exlObj.getCellData(sheet, rownum, 0).toString();
    								
    								if(label == "" || label.contains("radiobutton - BenchmarkCategory"))
    									label = "isEmpty";
    						
    						}
    				}
    				
    				
//    				if(count > 0) {
//    					Assert.fail("Prepopulated Values are not same as values stored in DB");
//    				}
    				//Reporter.addCompleteScreenCapture();
    				//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }
    
    @Then("^User should be able to see \"([^\"]*)\" attribute Header in  Enter Starategy Deatils page in Rejected Strategies Resubmission Flow$")
    public void user_should_be_able_to_see_something_attribute_header_in_enter_starategy_deatils_page_in_rejected_strategies_resubmission_flow(String label) {
    	Assert.assertTrue(strategyDetailsPage.istheAttributeHeaderVisible(label));
    }
    
}
