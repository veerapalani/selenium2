package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.ReviewStylePage;

public class UpdateStyleReviewStepDef {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStyleReviewPage"));
	ReviewStylePage reviewStylePage = new ReviewStylePage();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyle3036.xlsx";
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	int rowIndex,cellIndex;
	WebElement myElement;
	
	@And("^User clicks on Submit Button on Update Style Review page$")
    public void user_clicks_on_submit_button_on_update_style_review_page() throws Throwable {
      action.click(action.getElement("Submit Button"));
      Reporter.addStepLog("clicked on submit button");
    }
	
	@Then("^User should be able to see the Review header in Update Style Review page$")
    public void user_should_be_able_to_see_the_review_header_in_update_style_review_page() throws Throwable {
       Assert.assertTrue(action.getElement("Review Header").isDisplayed());
    }
	
	@And("^User clicks on Previous Button on Update Style Review page$")
    public void user_clicks_on_previous_button_on_update_style_review_page() throws Throwable {
        action.click(action.getElement("Previous Button"));
        Reporter.addStepLog("clicked on Previous button");
	}
	
	@And("^User click on Edit Button on Update Style Review page$")
    public void user_click_on_edit_button_on_update_style_review_page() throws Throwable {
		action.click(action.getElement("Edit Button"));
        Reporter.addStepLog("clicked on Edit button");
    }
	
	 @Then("^User should be able to see the updated values for the following attributes in Update Style Review page$")
	    public void user_should_be_able_to_see_the_updated_values_for_the_following_attributes_in_update_style_review_page(List<String> attribute) throws Throwable {
		 sheet = exlObj.getSheet("Valid");
			
			for (int i=0;i<attribute.size();i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myElement = reviewStylePage.findElementByDynamicXpath("//small[text()='"+attribute.get(i)+"']/parent::p/following-sibling::span");
			Assert.assertTrue(myElement.getText().equalsIgnoreCase((String)exlObj.getCellData(sheet, rowIndex, cellIndex)));
			Reporter.addStepLog("verified the value for "+attribute.get(i));
		
					
			}
			Reporter.addScreenCapture();
	    }
	

}