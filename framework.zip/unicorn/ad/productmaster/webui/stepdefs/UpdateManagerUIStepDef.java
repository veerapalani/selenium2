package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerAddContactsPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerDocumentsPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerEnterManagerDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerReviewPage;

public class UpdateManagerUIStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	String expectedColorCode;
	String xpath, myValue, javaScript;
	Select dropdown;
	Boolean myFlag;
	String xpathForStaleElement = "//input[@name='strategyName']";
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/manager/edit/";
	String sheetName = "", sheetName1 = "Valid2";
	String searchToken;
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateManager3038.xlsx";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);

	XSSFSheet sheet;
	int rowIndex, cellIndex;

	LandingPage lp = new LandingPage("AD_PM_LandingPage");
	UpdateManagerEnterManagerDetailsPage UEMDP = new UpdateManagerEnterManagerDetailsPage(
			"AD_PM_UpdateManagerEnterManagerDetailsPage");
	UpdateManagerAddContactsPage UMACP = new UpdateManagerAddContactsPage("AD_PM_UpdateManagerAddContactsPage");
	UpdateManagerDocumentsPage UMDP = new UpdateManagerDocumentsPage("AD_PM_UpdateManagerDocumentsPage");
	UpdateManagerReviewPage UMRP = new UpdateManagerReviewPage("AD_PM_UpdateManagerReviewPage");
	UpdateManagerConfirmationPage UMCP = new UpdateManagerConfirmationPage("AD_PM_UpdateManagerConfirmationPage");
	UpdateManagerPage UpdateManagerUI = new UpdateManagerPage();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateManagerUIPage"));
	WebElement myElement, myElement2;
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();

	@Then("^User should not be able to update the following attributes in Update Manager page$")
	public void user_should_not_be_able_to_update_the_following_attributes_in_update_manager_page(
			List<String> attribute) throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			myElement = UpdateManagerUI.findElementByDynamicXpath("//*[@label='" + attribute.get(i) + "']");
			Assert.assertEquals("true", action.getAttribute(myElement, "disabled"));
			action.highligthElement(myElement);
			Reporter.addStepLog("validated that " + attribute.get(i) + " is not editable");
		}
		Reporter.addScreenCapture();
	}

	@Then("^user should be able to see the following values in the following dropdown in Update Manager page$")
	public void user_should_be_able_to_see_the_following_values_in_the_following_dropdown_in_update_manager_page(
			List<List<String>> attributeValuePair) throws Throwable {
		for (int i = 0; i < attributeValuePair.size(); i++) {
			listOfElements = UpdateManagerUI.findElementsByDynamicXpath(
					"//wf-select[@label='" + attributeValuePair.get(i).get(0) + "']/wf-select-option");
			String[] options = attributeValuePair.get(i).get(1).split(",");
			for (int j = 0; j < options.length; j++) {
				Assert.assertEquals(listOfElements.get(j).getAttribute("name"), options[j]);
				Reporter.addStepLog(
						"verified that " + options[j] + " is present in " + attributeValuePair.get(i).get(0));
			}
		}
	}

	@Then("^User should be able to see Yes or No option in the following radio button attributes in Update Manager page$")
	public void user_should_be_able_to_see_yes_or_no_option_in_the_following_radio_button_attributes_in_update_manager_page(
			List<String> attribute) throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			listOfElements = UpdateManagerUI
					.findElementsByDynamicXpath("//wf-radio[@label='" + attribute.get(i) + "']/wf-radio-option");
			Assert.assertEquals(listOfElements.get(0).getAttribute("label"), "Yes");
			Reporter.addStepLog("Yes is present in " + attribute.get(i));
			Assert.assertEquals(listOfElements.get(1).getAttribute("label"), "No");
			Reporter.addStepLog("No is present in " + attribute.get(i));
		}
		Reporter.addScreenCapture();

	}

	@Then("^User should not be able to see any error message while updating the following attributes with following values in Update Manager page$")
	public void user_should_not_be_able_to_see_any_error_message_while_updating_the_following_attributes_with_following_values_in_update_manager_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Invalid_Special_Character_Message");
			Assert.assertFalse(action.getPageSource().contains(message));
			Reporter.addStepLog("verified that there is no error message for " + attributeValuePair.get(i).get(0));
		}
	}

	@Then("^User should be able to see the Invalid Special Character Message while updating with the following values in following attributes in Update Manager page$")
	public void user_should_be_able_to_see_the_invalid_special_character_message_while_updating_with_the_following_values_in_following_attributes_in_update_manager_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Invalid_Special_Character_Message");
			myElement2 = UpdateManagerUI.findElementByDynamicXpath(
					"//*[@label='" + attributeValuePair.get(i).get(0) + "']/following-sibling::p");
			Assert.assertTrue(myElement2.getText().contains(message));
			Reporter.addStepLog("verified the msg " + myElement2.getText());
		}
	}

	@Then("^User should be able to see the Enter Manager Details header on Update Manager UI$")
	public void user_should_be_able_to_see_the_enter_manager_details_header_on_update_manager_ui() throws Throwable {
		action.getElement("Enter Manager Details").isDisplayed();
		Reporter.addStepLog("Manager details header is present");
		Reporter.addScreenCapture();
	}

	@Then("^Following attributes should be resetted to default values after clicking on reset button in Update Manager page$")
	public void following_attributes_should_be_resetted_to_default_values_after_clicking_on_reset_button_in_update_manager_page(
			List<String> attribute) throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			myElement = UpdateManagerUI.findElementByDynamicXpath("//*[@label='" + attribute.get(i) + "']");
			myValue = myElement.getAttribute("value");
			myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector('input')");
			action.sendkeysClipboard(myElement2, UpdateManagerUI.getCurrentTimeStamp());
			Reporter.addStepLog("sent random keys to " + attribute.get(i));
			action.click(action.getElement("Reset Button"));
			Reporter.addStepLog("clicking on reset button");
			Thread.sleep(2000);
			myElement = UpdateManagerUI.findElementByDynamicXpath("//*[@label='" + attribute.get(i) + "']");
			Assert.assertEquals(myElement.getAttribute("value"), myValue);
			Reporter.addStepLog("validated that the value for " + attribute.get(i) + " is getting resetted");

		}
		Reporter.addStepLog("validated the functionality of reset button");
	}

	@And("^User clicks the Next Button on Update Manager page$")
	public void user_clicks_the_next_button_on_update_manager_page() throws Throwable {
		Thread.sleep(2000);
		action.click(action.getElement("Next Button"));
		Reporter.addStepLog("clicked on Next Button");
	}

	@And("^User clicks the Back Link on Update Manager page$")
	public void user_clicks_the_back_link_on_update_manager_page() throws Throwable {
		action.click(action.getElement("Back Link"));
		Reporter.addStepLog("clicked on Back Link");
	}

	@And("^User clicks the Previous Button on Update Manager page$")
	public void user_clicks_the_previous_button_on_update_manager_page() throws Throwable {
		action.click(action.getElement("Previous Button"));
		Reporter.addStepLog("clicked on Previous Button");
	}

	@Then("^User update the following textfields with Valid Data in the Update Manager page$")
	public void user_update_the_following_textfields_with_valid_data_in_the_update_manager_page(List<String> attribute)
			throws Throwable {
		sheetName = "Valid";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			if (attribute.get(i).equalsIgnoreCase("Description")) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector('textarea')");
			} else {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector('input')");
			}
			myElement.clear();

			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			if (attribute.get(i).equals("Amount"))
				action.sendkeysClipboard(myElement, myValue);
			else
				action.sendkeysClipboard(myElement, myValue + UpdateManagerUI.getCurrentTimeStamp());
			Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i));
		}

	}

	@And("^User update the following dopdown with Valid Data in the Update Manager page$")
	public void user_update_the_following_dopdown_with_valid_data_in_the_update_manager_page(List<String> attribute)
			throws Throwable {
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector('button')");
			action.scrollToElement(myElement);
			action.click(myElement);
			myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector(\"li[data-value='\\\""
					+ (String) exlObj.getCellData(sheet, rowIndex, cellIndex) + "\\\"']\")");
			action.click(myElement2);
		}
	}

	@And("^User update the following radio button with Valid Data in the Update Manager page$")
	public void user_update_the_following_radio_button_with_valid_data_in_the_update_manager_page(
			List<String> attribute) throws Throwable {
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			if (myValue.equalsIgnoreCase("Yes")) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-radio[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector(\"button[data-index='0']\")");
				action.click(myElement);
			} else {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-radio[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector(\"button[data-index='1']\")");
				action.click(myElement);
			}
		}
	}

	@Then("^The following attributes on Update Manager page should be marked as mandatory$")
	public void the_following_attributes_on_update_manager_page_should_be_marked_as_mandatory(List<String> items)
			throws Throwable {

		for (int i = 0; i < items.size(); i++) {
			myElement = UpdateManagerUI.findElementByDynamicXpath("//*[@label='" + items.get(i) + "']");
			Assert.assertEquals(action.getAttribute(myElement, "required"), "true");
			Reporter.addStepLog("validated that " + items.get(i) + " is mandatory");
		}
		Reporter.addScreenCapture();
	}

	@When("^User enters (.+) manager search token on Global Serach input box on PM landing page in update flow$")
	public void user_enters_manager_search_token_on_global_serach_input_box_on_pm_landing_page_in_update_flow(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid2";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		searchToken = (String) exlObj.getCellData(sheet, rowIndex, 1);
		if (searchToken != "") {
			lp.enterStyleSearchToken(searchToken);
		}
	}

	@And("^User should be able to click on searched manager results in global search flyout$")
	public void user_should_be_able_to_click_on_searched_manager_results_in_global_search_flyout() throws Throwable {
		Reporter.addCompleteScreenCapture();
		lp.clickOnDisplayedFirstSearchResult();
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User should be able to see View Managers header in update flow$")
	public void user_should_be_able_to_see_view_managers_header_in_update_flow() throws Throwable {
		lp.verifyUserIsOnViewManagersPage();
	}

	@When("^User clicks on Continue Editing button on View Manager page in update flow$")
	public void user_clicks_on_continue_editing_button_on_view_manager_page_in_update_flow() throws Throwable {
		lp.verifyContinueEditingButton();
		lp.clickOnStyleViewEditButton();
	}

	@And("^User should be able to see Enter Manager Details header in update flow$")
	public void user_should_be_able_to_see_enter_manager_details_header_in_update_flow() throws Throwable {
		UEMDP.isUserOnEnterManagerDetailsPage();
	}

	@And("^User updates all the (.+) on Enter Manager Details page$")
	public void user_updates_all_the_on_enter_manager_details_page(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid2";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String managerName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String firmName = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String firmWebsite = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String vestmarkName = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String taxPayerId = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String largeTraderId = (String) exlObj.getCellData(sheet, rowIndex, 7);
		String dtccId = (String) exlObj.getCellData(sheet, rowIndex, 8);
		String eyeCheckOverride = (String) exlObj.getCellData(sheet, rowIndex, 9);
		String ubsSubsidary = (String) exlObj.getCellData(sheet, rowIndex, 10);
		exlObj.closeWorkBook();

		if (managerName != "") {
			UEMDP.enterManagerName(managerName);
		}
		if (firmName != "") {
			UEMDP.enterfirmName(firmName);
		}
		if (firmWebsite != "") {
			UEMDP.enterfirmWebsite(firmWebsite);
		}
		if (vestmarkName != "") {
			UEMDP.entervestmarkManagerName(vestmarkName);
		}
		if (taxPayerId != "") {
			UEMDP.entertaxPayerIdentificationNumber(taxPayerId);
		}
		if (largeTraderId != "") {
			UEMDP.enterlargeTraderID(largeTraderId);
		}
		if (dtccId != "") {
			UEMDP.enterdtccID(dtccId);
		}
		if (eyeCheckOverride != "") {
			UEMDP.enterfourEyeCheckOverride(eyeCheckOverride);
		}
		if (ubsSubsidary != "") {
			UEMDP.enterubsSubsudiary(ubsSubsidary);
		}
	}

	@When("^User clicks on Nextbutton in Enter Manager Details page$")
	public void user_clicks_on_nextbutton_in_enter_manager_details_page() throws Throwable {
		UEMDP.clickOnNext();
	}

	@And("^User should be able to see Add Contacts header in update flow$")
	public void user_should_be_able_to_see_add_contacts_header_in_update_flow() throws Throwable {
		UMACP.isUserOnAddContactsPage();
	}

	@Then("^User clicks on delete icon of previously added contact details to delete those conatct details in Add Conatcts page$")
	public void user_clicks_on_delete_icon_of_previously_added_contact_details_to_delete_those_conatct_details_in_add_conatcts_page()
			throws Throwable {
		UMACP.clickOnDeleteIconofContactDetails();
	}

	@Then("^User clicks on delete icon of previously added firm contact details to delete those firm conatct details in Add Conatcts page$")
	public void user_clicks_on_delete_icon_of_previously_added_firm_contact_details_to_delete_those_firm_conatct_details_in_add_conatcts_page()
			throws Throwable {
		UMACP.clickOnDeleteIconofFirmContactDetails();
	}

	@When("^User clicks on Nextbutton in Add Contacts page$")
	public void user_clicks_on_nextbutton_in_add_contacts_page() throws Throwable {
		UMACP.clickOnNext();
	}

	@Then("^User should be able to see Enter Document Links header in update flow$")
	public void user_should_be_able_to_see_enter_document_links_header_in_update_flow() throws Throwable {
		UMDP.isUserOnDocumentsPage();
	}

	@When("^User clicks on delete icon of previously added document links to delete those document details in Enter Document Links page$")
	public void user_clicks_on_delete_icon_of_previously_added_document_links_to_delete_those_document_details_in_enter_document_links_page()
			throws Throwable {
		UMDP.clickOnDeleteIconofDocumentLinks();
	}

	@Then("^User clicks on add another document link and add document links (.+) in Enter Document Links page$")
	public void user_clicks_on_add_another_document_link_and_add_document_links_in_enter_document_links_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid2";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String documentType = (String) exlObj.getCellData(sheet, rowIndex, 11);
		String documentLink = (String) exlObj.getCellData(sheet, rowIndex, 12);
		String documentComment = (String) exlObj.getCellData(sheet, rowIndex, 13);
		UMDP.clickOnAddAnotherDocument();
		if (documentType != "") {
			UMDP.selectDocumentType(documentType);
		}
		if (documentLink != "") {
			UMDP.enterDocumentLink(documentLink);
		}
		if (documentComment != "") {
			UMDP.enterDocumentComment(documentComment);
		}
		Reporter.addCompleteScreenCapture();
	}

	@And("^User clicks on add document link button in Enter Document Links page$")
	public void user_clicks_on_add_document_link_button_in_enter_document_links_page() throws Throwable {
		UMDP.clickOnAddDocumentLinkButton();
	}

	@And("^User clicks on Nextbutton in Enter Document Links page$")
	public void user_clicks_on_nextbutton_in_enter_document_links_page() throws Throwable {
		UMDP.clickOnNext();
	}

	@Then("^User should be able to see Review header in Update Manager Review Page$")
	public void user_should_be_able_to_see_review_header_in_update_manager_review_page() throws Throwable {
		UMRP.isUserOnReviewPage();
		UMRP.verifyReviewContactsHeader();
		UMRP.verifyReviewDocumentLinksHeader();
	}

	@And("^User should be able to see the same data while navigating pages using the next button on Update Manager Review Page$")
	public void user_should_be_able_to_see_the_same_data_while_navigating_pages_using_the_next_button_on_update_manager_review_page()
			throws Throwable {
		UMRP.isUserOnReviewPage();
		UMRP.verifyReviewContactsHeader();
		UMRP.verifyReviewDocumentLinksHeader();
	}

	@And("^User clicks on Submit Button in Review Page in Update Manager Review Page$")
	public void user_clicks_on_submit_button_in_review_page_in_update_manager_review_page() throws Throwable {
		UMRP.clickOnSubmitButton();
	}

	@Then("^User should be able to see Confirmation header in Update Manager Confirmation Page$")
	public void user_should_be_able_to_see_confirmation_header_in_update_manager_confirmation_page() throws Throwable {
		UMCP.isUserOnConfirmationPage();
		UMCP.verifyManagerUpdateSuccessfulMesssage();
		UMCP.verifyManagerID();
	}

	@And("^User clicks on Done Button in Confirmation Page in Update Manager Confirmation Page$")
	public void user_clicks_on_done_button_in_confirmation_page_in_update_manager_confirmation_page() throws Throwable {
		UMCP.clickOnDoneButton();
	}

	@And("^User should be able to see \"([^\"]*)\" message displayed in Review Page$")
	public void user_should_be_able_to_see_something_message_displayed_in_review_page(String strArg1) throws Throwable {
		UMRP.verifyFirmContactErrorMessage(strArg1);
	}

	@And("^User should be able to find that Submit Button is disabled in Review Page to proceed further to confirmation page$")
	public void user_should_be_able_to_find_that_submit_button_is_disabled_in_review_page_to_proceed_further_to_confirmation_page()
			throws Throwable {
		UMRP.verifyIsSubmitButtondisabled();
	}

	@When("^User clicks on Previousbutton in update Manager Review page$")
	public void user_clicks_on_previousbutton_in_update_manager_review_page() throws Throwable {
		UMRP.clickOnPrevious();
	}

	@When("^User clicks on Previousbutton in update Manager Documents page$")
	public void user_clicks_on_previousbutton_in_update_manager_documents_page() throws Throwable {
		UMDP.clickOnPrevious();
	}

	@When("^User clicks on Previousbutton in update Manager Add Contacts page$")
	public void user_clicks_on_previousbutton_in_update_manager_add_contacts_page() throws Throwable {
		UMACP.clickOnPrevious();
	}

}
