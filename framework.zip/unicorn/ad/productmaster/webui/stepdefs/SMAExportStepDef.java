package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.ExportReportsPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAViewPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccesstrategyViewDetailsPage;

public class SMAExportStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	UpdateSMASingleAccesstrategyViewDetailsPage viewPage = new UpdateSMASingleAccesstrategyViewDetailsPage(
			"AD_PM_UpdateSMASingleAccesstrategyViewDetailsPage");
	ExportReportsPage reports = new ExportReportsPage();
	String sheetName, sheetName2 = "";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/SMAExport.xlsx";
	String attributeValue, label = "";
	int rowIndex, columNum, cellCount = 0;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	PMPageGeneric pmPageGeneric = new PMPageGeneric("AD_PM_UpdateSMASingleAccesstrategyViewDetailsPage");
	
	@Then("^user verifies the SMA export functionality using (.+)$")
	public void user_verifies_the_sma_export_functionality(String entityName) throws IOException, InterruptedException {
		int count = landingPage.getSmaCount();
		System.out.println("count: " + count);
		if (count == 0) {
			Reporter.addStepLog("There are no SMA Entities associated with search value in the Grid");
			Reporter.addScreenCapture();
		} else {
			reports.DeletePreviousFile(entityName);
			landingPage.clickOnSMAExport();
			Assert.assertTrue(reports.VerifyFileDownloaded());
			// verifying the grid count and csv file count
			Assert.assertTrue(count == reports.getNumberOfRecordsInFile(entityName));
			landingPage.movetoFirstElementinFilteredrecords();
			landingPage.clickOnEllipsesIcon();
			landingPage.verifyOnViewDetailsLink();

			landingPage.clickOnViewDetailsLink();
			Assert.assertTrue(viewPage.isUserOnViewDetailsPage());

			sheetName = entityName;
			Boolean flag1 = false;
			if (viewPage.areDocumentsDisplayedInUI()) {
				flag1 = true;
			}
			Boolean flag2 = false;
			if (viewPage.areHomeOfficeCommentsDisplayedInUI()) {
				flag2 = true;
			}
			System.out.println("flag:" + flag1);
			sheet = exlObj.getSheet(entityName);
			cellCount = exlObj.getCellCount(sheet, 0);
			System.out.println("cellcount:" + cellCount);
			while (columNum < cellCount) {
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
				System.out.println("label:" + label);
				if (flag1 == true && label.contains("Document")) {
					attributeValue = viewPage.getDataFromViewPageforExport(label);
				} else if (flag1 == false && label.contains("Document")) {
					attributeValue = "";
				} else if (flag2 == true && label.contains("Comment")) {
					attributeValue = viewPage.getDataFromViewPageforExport(label);
				} else if (flag2 == false && label.contains("Comment")) {
					attributeValue = "";
				} else {
					attributeValue = viewPage.getDataFromViewPageforExport(label);
				}

				if (attributeValue.equals("isEmpty")) {
					attributeValue = "";
				}
				System.out.println("attributeValue:" + attributeValue);
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, columNum, attributeValue);
				columNum++;
			}

			// Make sure sheet name same as entity name i.e same as downloaded file name
			reports.verifyAttributesForFirstEntityBenchmark(entityName, excelFilePath);
			exlObj.closeWorkBook();

		}
	}

	@Then("^user verifies the SMA Swp export functionality using (.+)$")
	public void user_verifies_the_sma_swp_export_functionality(String entityName)
			throws IOException, InterruptedException {
		int count = landingPage.getSmaCount();
		System.out.println("count: " + count);
		if (count == 0) {
			Reporter.addStepLog("There are no SMA Entities associated with search value in the Grid");
			Reporter.addScreenCapture();
		} else {
			reports.DeletePreviousFile(entityName);
			landingPage.clickOnSMAExport();
			Assert.assertTrue(reports.VerifyFileDownloaded());
			// verifying the grid count and csv file count
			Assert.assertTrue(count == reports.getNumberOfRecordsInFile(entityName));
			landingPage.movetoFirstElementinFilteredrecords();
			landingPage.clickOnEllipsesIcon();
			landingPage.verifyOnViewDetailsLink();

			landingPage.clickOnViewDetailsLink();
			Assert.assertTrue(viewPage.isUserOnViewDetailsPage());

			sheetName = entityName;
			Boolean flag1 = false;
			if (viewPage.areDocumentsDisplayedInUI()) {
				flag1 = true;
			}
			Boolean flag2 = false;
			if (viewPage.areHomeOfficeCommentsDisplayedInUI()) {
				flag2 = true;
			}
			System.out.println("flag:" + flag1);
			sheet = exlObj.getSheet(entityName);
			cellCount = exlObj.getCellCount(sheet, 0);
			System.out.println("cellcount:" + cellCount);
			while (columNum < cellCount) {
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
				System.out.println("label:" + label);
				if (flag1 == true && label.contains("Document")) {
					attributeValue = viewPage.getDataFromViewPageforExport(label);
				} else if (flag1 == false && label.contains("Document")) {
					attributeValue = "";
				} else if (flag2 == true && label.contains("Comment")) {
					attributeValue = viewPage.getDataFromViewPageforExport(label);
				} else if (flag2 == false && label.contains("Comment")) {
					attributeValue = "";
				} else {
					attributeValue = viewPage.getDataFromViewPageforExportforSwp(label);
				}

				if (attributeValue.equals("isEmpty")) {
					attributeValue = "";
				}
				System.out.println("attributeValue:" + attributeValue);
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, columNum, attributeValue);
				columNum++;
			}

			// Make sure sheet name same as entity name i.e same as downloaded file name
			reports.verifyAttributesForFirstEntityBenchmark(entityName, excelFilePath);
			exlObj.closeWorkBook();

		}
	}
	
	@Then("^user validates the SMA Print functionality for (.+)$")
	public void user_validates_the_sma_print_functionality(String entityName) throws Exception {
		PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, 0, viewPage.getTextforFirmName());
		int i = 2;
		while (i <= 6) {
			PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, i-1,
					viewPage.getTextfromGridforRow(String.valueOf(i)));
			i++;
		}
		viewPage.clickOnSmaPrint();
		pmPageGeneric.verifyPrintFunctionalityForFirstEntity(excelFilePath, entityName);
	}
	
	@Then("^user verifies the SMA print tooltip$")
	public void user_verifies_the_sma_print_tooltip() {
		Assert.assertTrue(viewPage.verifyTooltipOfSmaPrint());
	}

}
