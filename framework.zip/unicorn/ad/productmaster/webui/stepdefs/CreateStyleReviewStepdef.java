package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;
public class CreateStyleReviewStepdef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString ;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	Alert alert;
	
	CreateStyleReviewPage createstylereviewpage = new CreateStyleReviewPage("AD_PM_CreateStyleReviewPage");
	@Then("^User should be able to see the \"([^\"]*)\" on Create New Style Review page$")
    public void user_should_be_able_to_see_the_something_on_create_new_style_review_page(String Key) throws Throwable {
		createstylereviewpage.verifyElementinCreateStyleReviewPage(Key);
    }
	@Then("^User should be able to see the Timestamp on Create New Style Review page$")
    public void user_should_be_able_to_see_the_timestamp_on_create_new_style_review_page() throws Throwable {
		createstylereviewpage.verifytimestampinCreateStyleReviewPage();
    }

	@Then("^User should be able to see the Review Header on Create New Style Review page$")
    public void user_should_be_able_to_see_the_review_header_on_create_new_style_review_page() throws Throwable {
		createstylereviewpage.verifyreviewheaderinCreateStyleReviewPage();
    }
	@And("^User clicks on the (.+) attributes on Create New Style Review Page$")
    public void user_clicks_on_the_attributes_on_create_new_style_review_page(String key) throws Throwable {
		createstylereviewpage.clickOntheelementsoncreatestylereviewpage(key);
    }
	@And("^User clicks on Back Link on Create New Style Review Page$")
    public void user_clicks_on_back_link_on_create_new_style_review_page() throws Throwable {
		createstylereviewpage.verifyAttributesinCreateStyleReviewPage();
    }
	@And("^User clicks on Previous Button on Create New Style Review Page$")
    public void user_clicks_on_previous_button_on_create_new_style_review_page() throws Throwable {
		
		createstylereviewpage.verifyButtonsinCreateStyleReviewPage();
    }
	@Then("^User should be able to see following attributes on Create Style Review Page$")
    public void user_should_be_able_to_see_following_attributes_on_create_style_review_page(List<String> entity) throws Throwable {
		for(int i =0;i<entity.size();i++) {
			createstylereviewpage.verifyWebElementinCreateStyleReviewPage(createstylereviewpage.findElementByDynamicXpath("//small"));
				Reporter.addStepLog("able to see "+entity.get(i)+" header");
				}
				Reporter.addScreenCapture();
    }
	@Then("^the attributes on Create New Style Review page should contain either true or false or blank value$")
    public void the_attributes_on_create_new_style_review_page_should_contain_either_true_or_false_or_blank_value(List<String> attributes) throws Throwable {
		String myValue=null;
    	for(int i=0;i<attributes.size();i++) {
    	String xpath="//small[contains(text(),'"+attributes.get(i)+"')]/parent::p/following-sibling::span";
    	myValue=createstylereviewpage.findElementByDynamicXpath(xpath).getText();
    	Reporter.addStepLog("The value for "+attributes.get(i)+" is "+myValue);
    	if(myValue.equals("true")||myValue.equals("false")||myValue.equals("")) {
    		Assert.assertTrue(true);
    		
    	}
    	else {
    		Assert.assertFalse(false);
    	}
        }
    }
	@And("^User clicks on Submit Button on Create New Style Review Page$")
    public void user_clicks_on_submit_button_on_create_new_style_review_page() throws Throwable {
		createstylereviewpage.verifysubmitButtoninCreateStyleReviewPage();
    }
	@Then("^the attributes on Create New Style Review Page should contain one of the below following values$")
    public void the_attributes_on_create_new_style_review_page_should_contain_one_of_the_below_following_values(List<List<String>> attributeValuePair) throws Throwable {
String myValue=null;
  for(int i=0;i<attributeValuePair.size();i++) {
    	String xpath="//small[contains(text(),'"+attributeValuePair.get(i).get(0)+"')]/ancestor::p/following-sibling::span";
    	myValue=createstylereviewpage.findElementByDynamicXpath(xpath).getText();
    	Reporter.addStepLog("The value for "+attributeValuePair.get(i).get(0)+" is "+myValue);
    	String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
    	for(int j=0;j<listOfValues.length;j++) {
    	if(myValue.equals(listOfValues[j]))
    		{Assert.assertTrue(true);
    		break;}
    	else 
    		Assert.assertFalse(false);
    	
    	}
        }
    }

    }
    

