package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import cucumber.api.java.en.And;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessStrategyCommentsPage;

public class UpdateSMASingleAccessStrategyCommentsStepDef {
	
	UpdateSMASingleAccessStrategyCommentsPage commentsPage = new UpdateSMASingleAccessStrategyCommentsPage("AD_PM_UpdateSMASingleAccessStrategyCommentsPage");

	@And("^User is in Comments Page in Update SMA Single Access Flow$")
    public void user_is_in_comments_page_in_update_sma_single_access_flow() {
        assertTrue(commentsPage.isUserOnCommentsPage());
    }

    @And("^User clicks on Next in Comments Page in Update SMA Single Access Flow$")
    public void user_clicks_on_next_in_comments_page_in_update_sma_single_access_flow() {
        commentsPage.clickOnNext();
    }
}
