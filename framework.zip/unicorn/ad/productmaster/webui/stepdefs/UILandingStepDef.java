package qa.unicorn.ad.productmaster.webui.stepdefs;


import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.formula.SheetNameFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import qa.framework.utils.Reporter;



import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class UILandingStepDef {
	
	
	private static final Object[] arguments = null;
	PMPageGeneric landingPage = new PMPageGeneric("AD_PM_LandingPage");
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	String expectedColorCode,searchValue,myValue;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL=SSOLoginPage.URL+"#/";

	String userInfo;
	WebDriver driver;
	XSSFSheet sheet;
	String excelPathForReference = "./src/test/resources/ad/productmaster/api/excel/ReferenceDetails.xlsx";
	ExcelUtils myReferenceFile = new ExcelUtils(ExcelOperation.LOAD, excelPathForReference);
	WebElement myElement,myElement2;
	List<String> searchTokens ;
	String strategyCode,phoaStrategyCode,rejectedStrategyCode,pmpStrategyCode = "";
	Action action =  new Action(SQLDriver.getEleObjData("AD_PM_LandingPage"));
	List<WebElement> listOfElements,listOfElements2 = new ArrayList<WebElement>();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	@Then("^User should be able to see the results in proper Strategy format$")
    public void user_should_be_able_to_see_the_results_in_proper_strategy_format() throws Throwable {
       myElement = action.getElementFromParentElement(action.getElement("Strategy Searches"), "Main Heading");
       Assert.assertTrue(myElement.getText()!="");
       myElement2 = action.getElementFromParentElement(action.getElement("Strategy Searches"), "Sub Heading");
       Reporter.addStepLog(myElement2.getText());
       Assert.assertTrue(myElement2.getText().contains("Strategy Code: ")&&myElement2.getText().contains("Strategy Name: "));
    }

    @Then("^User should be able to see the results in proper Style format$")
    public void user_should_be_able_to_see_the_results_in_proper_style_format() throws Throwable {
    	 myElement = action.getElementFromParentElement(action.getElement("Style Searches"), "Main Heading");
         Assert.assertTrue(myElement.getText()!="");
         myElement2 = action.getElementFromParentElement(action.getElement("Style Searches"), "Sub Heading");
         Assert.assertTrue(myElement2.getText().contains("Style Code: ")&&myElement2.getText().contains("Style Name: "));
    }

    @Then("^User should be able to see the results in proper Program format$")
    public void user_should_be_able_to_see_the_results_in_proper_program_format() throws Throwable {
    	myElement = action.getElementFromParentElement(action.getElement("Program Searches"), "Main Heading");
        Assert.assertTrue(myElement.getText()!="");
        myElement2 = action.getElementFromParentElement(action.getElement("Program Searches"), "Sub Heading");
        Assert.assertTrue(myElement2.getText().contains("Program Code: "));
    }

    @Then("^User should be able to see the results in proper Manager format$")
    public void user_should_be_able_to_see_the_results_in_proper_manager_format() throws Throwable {
    	myElement = action.getElementFromParentElement(action.getElement("Manager Searches"), "Main Heading");
        Assert.assertTrue(myElement.getText()!="");
        myElement2 = action.getElementFromParentElement(action.getElement("Manager Searches"), "Sub Heading");
        Assert.assertTrue(myElement2.getText().contains("Manager Code: ")&&myElement2.getText().contains("Manager Name: "));
    }

    @Then("^User should be able to see the results in proper Benchmark format$")
    public void user_should_be_able_to_see_the_results_in_proper_benchmark_format() throws Throwable {
    	myElement = action.getElementFromParentElement(action.getElement("Benchmark Searches"), "Main Heading");
        Assert.assertTrue(myElement.getText()!="");
        myElement2 = action.getElementFromParentElement(action.getElement("Benchmark Searches"), "Sub Heading");
        Assert.assertTrue(myElement2.getText().contains("Benchmark Code: ")&&myElement2.getText().contains("Benchmark Name: "));
    }

    @Then("^User should be able to see the results in proper FA format$")
    public void user_should_be_able_to_see_the_results_in_proper_fa_format() throws Throwable {
    	myElement = action.getElementFromParentElement(action.getElement("FA Searches"), "Main Heading");
        Assert.assertTrue(myElement.getText()!="");
        myElement2 = action.getElementFromParentElement(action.getElement("FA Searches"), "Sub Heading");
        Assert.assertTrue(myElement2.getText().contains("Financial Advisor Code: ")&&myElement2.getText().contains("Financial Advisor Name: "));

    }
	@When("^User searches with \"([^\"]*)\" in Global search box and click Search Icon$")
    public void user_searches_with_something_in_global_search_box_and_click_search_icon(String searchtoken) throws Throwable {
		 myElement = (WebElement) action.getElementByJavascript("Search Textbox");
		 searchValue = searchtoken;
		action.sendkeysClipboard(myElement, searchtoken);
        myElement.sendKeys(Keys.ENTER);
        Reporter.addStepLog("Searching with "+searchtoken);
        
    }

    @Then("^User should be able to see maximum of 5 search results for each entity while searching any term$")
    public void user_should_be_able_to_see_maximum_of_5_search_results_for_each_entity_while_searching_any_term() throws Throwable {
        listOfElements =action.getElements("Search Results");
        for(int i=0;i<listOfElements.size();i++)
        {
        	listOfElements2 = action.getElementsFromParentElement(listOfElements.get(i), "List of Results");
        	Assert.assertTrue(listOfElements2.size()<=5);
        	Reporter.addStepLog("validated the no of results are less than 5 for "+i);
        }
        Reporter.addScreenCapture();
    }
    @And("^User search with different values in landing page$")
    public void user_search_with_different_values_in_landing_page() throws Throwable {
    	myElement = (WebElement) action.getElementByJavascript("Search TextBox");
    	for (int i=0;i<5;i++) {
        	action.sendkeysClipboard(myElement,""+Calendar.getInstance().getTimeInMillis());
        	myElement.sendKeys(Keys.ENTER);
//        	Thread.sleep(2000);
//        	landingPage.clickOnLink(landingPage.getElementFromShadowRoot("Global Search Icon"));
//        	Thread.sleep(2000);
        	
        	myElement.clear() ;
    }
    	action.refresh();
    }
    @And("^User clicks on the Search Textbox in landing page$")
    public void user_clicks_on_the_search_textbox_in_landing_page() throws Throwable {
        action.click(action.getElement("Search Textbox"));
        Reporter.addStepLog("clicking on Search Textbox");
    }
    
    @Then("^User should be able to see all the results in landing page$")
    public void user_should_be_able_to_see_all_the_results_in_landing_page() throws Throwable {
    	listOfElements = action.getElements("Rows");
    	for(int i=0;i<listOfElements.size();i++)
    	{
    		myValue="";
    		listOfElements2 = action.getElementsFromParentElement(listOfElements.get(i), "Data");
    		for(int j=0;j<listOfElements2.size();j++) {
    		 myValue= myValue.concat(listOfElements2.get(j).getText());
    		Reporter.addStepLog("concatinating "+listOfElements2.get(j).getText());
    		Reporter.addStepLog("new value is "+myValue);
    		}
    		myValue = myValue.toLowerCase();
    		Reporter.addStepLog("row is "+myValue);
    		Assert.assertTrue(myValue.contains(searchValue.toLowerCase()));
    
    	}
    }

    @And("^User clicks on See All Results Button on landing page$")
    public void user_clicks_on_see_all_results_button_on_landing_page() throws Throwable {
    	Thread.sleep(3000);
    	action.click(action.getElement("See All Results Button"));
        Reporter.addStepLog("clicking on See All Results");
    }
    
    @When("^User search with the \"([^\"]*)\" taken from \"([^\"]*)\" in the Search TextBox on landing page$")
    public void user_search_with_the_strategycode_taken_from_strategy_in_the_search_textbox_on_landing_page(String attribute,String sheetName) throws Throwable {
		sheet  = myReferenceFile.getSheet(sheetName);
		searchValue= (String)myReferenceFile.getCellData(sheet, 1, myReferenceFile.getCellIndexByCellValue(sheet, 0, attribute));
		//unlocking after reading from excel
         
         Reporter.addStepLog("searching with "+searchValue);
        Thread.sleep(1000);
        
        landingPage1.enterSearchToken(searchValue);
        landingPage1.clickOnSearchIcon();
        /*
        WebElement ele = (WebElement) action.getElementByJavascript("Search_TextBox");
		Thread.sleep(2000);
		action.click(ele);
		ele.clear();
		action.sendKeys(ele, searchValue);
        
		WebElement ele1 = (WebElement) action.getElementByJavascript("Search Icon in Search TextBox");
		action.highligthElement(ele1);
		Thread.sleep(5000);

		int i = 0;

		while (i < 10) {
			action.sendKeys(Keys.ENTER);
			i++;

		}
		Action.pause(10000);
        */
        myReferenceFile.closeWorkBook();
        Thread.sleep(1000); 
    }


    @And("^User clicks on Global Search Icon inside landing page$")
    public void user_clicks_on_global_search_icon_inside_landing_page() throws Throwable {
        action.click(action.getElement("Global Search Icon"));
    }

    @And("^User clicks on the first element of Strategy Searches on the suggestion box on landing page$")
    public void user_clicks_on_the_first_element_of_strategy_searches_on_the_suggestion_box_on_landing_page() throws Throwable {
       action.click(action.getElement("Strategy Searches"));
       Reporter.addStepLog("clicking on the first element of Strategy search");
    }
    
    @And("^User clicks on the first element of Style Searches on the suggestion box on landing page$")
    public void user_clicks_on_the_first_element_of_style_searches_on_the_suggestion_box_on_landing_page() throws Throwable {
    	action.click(action.getElement("Style Searches"));
        Reporter.addStepLog("clicking on the first element of Style search");
    }
    
    @And("^User clicks on the first element of Manager Searches on the suggestion box on landing page$")
    public void user_clicks_on_the_first_element_of_manager_searches_on_the_suggestion_box_on_landing_page() throws Throwable {
    	/*
    	WebElement ele1 = (WebElement) action.getElement("GridViewRecord");
		action.highligthElement(ele1);
		action.moveToElement(ele1);
		Thread.sleep(2000);
		WebElement ele2 = (WebElement) action.getElementByJavascript("Manager Grid Ellipses Icon");
		action.highligthElement(ele2);
		Thread.sleep(2000);
		action.click(ele2);
		Thread.sleep(2000);
        Reporter.addStepLog("clicking on the first element of Manager search");
        Thread.sleep(10000);
        */
        
        landingPage1.mouseHoveOnSearchedRecordsOnGrid();
        landingPage1.movetoFirstElementinFilteredrecords();
        Action.pause(2000);
        landingPage1.clickOnEllipsesIcon();
        landingPage1.clickOnViewDetailsLink();
    }
    
    @And("^User clicks on the first element of Benchmark Searches on the suggestion box on landing page$")
    public void user_clicks_on_the_first_element_of_Benchmark_searches_on_the_suggestion_box_on_landing_page() throws Throwable {
    	action.click(action.getElement("Benchmark Searches"));
        Reporter.addStepLog("clicking on the first element of Benchmark search");
    }
    
	@When("^User search with the \"([^\"]*)\" taken from \"([^\"]*)\" in the \"([^\"]*)\" on landing page$")
    public void user_search_with_the_something_taken_from_excel_on_landing_page(String searchtoken, String sheetName,String key) throws Throwable {
        //locking for reading from excel
		landingPage.readLock(); 
		searchValue=landingPage.readSearchTokenFromExcel(searchtoken, sheetName);
		landingPage.readUnlock();
		//unlocking after reading from excel
         if(searchValue.length()>20) {
         searchValue =searchValue.substring(searchValue.length()-20) ;
         }
        Reporter.addStepLog("searching with "+searchValue);
        myElement = landingPage.getElementFromShadowRoot(key);
        action.sendkeysClipboard( myElement,searchValue);
        myElement.sendKeys(Keys.ENTER);
        Thread.sleep(1000);
        
    }
	@Then("^User should be able to see the Product Master header on landing screen$")
    public void user_should_be_able_to_see_the_product_master_header_on_landing_screen() throws Throwable {
		landingPage1.verifyProductMasterheaderonlandingpage();
    }
    @Then("^User should be able to see the \"([^\"]*)\" header on landing screen$")
    public void user_should_be_able_to_see_the_something_header(String headerKey) throws Throwable {
    	landingPage.verifyHeader(headerKey);
    }
    @And("^\"([^\"]*)\" should have \"([^\"]*)\" background color$")
    public void something_should_have_something_background_color(String key, String backgroundColor) throws Throwable {
    	expectedColorCode = Action.getTestData(backgroundColor);
    	landingPage.verifyBackgroundColor(key,expectedColorCode);
    	Reporter.addScreenCapture();
    }
    
    @And("^User clicks on \"([^\"]*)\" inside landing page$")
    public void user_clicks_on_something_inside_landing_page(String key) throws Throwable {
        landingPage.clickOnLink(landingPage.getElementFromShadowRoot(key));
        Reporter.addStepLog("clicking on "+key);
        Thread.sleep(1000);
    }
    
    @And("^User clicks on the \"([^\"]*)\" inside landing page$")
    public void user_clicks1_on_something_inside_landing_page(String key) throws Throwable {
    	Thread.sleep(2000);
        landingPage.clickOnLink1(landingPage.getElementFromShadowRoot(key));
        Reporter.addStepLog("clicking on "+key);
        Thread.sleep(1000);
    }
    
    @And("^User clicks on the Style Menu inside the landing page$")
    public void user_clicks_on_the_style_menu_inside_the_landing_page() throws Throwable {
    	Thread.sleep(2000);
        landingPage1.clickOnstyledropdownmenu();
        
        Thread.sleep(1000);
    }
    
    @And("^User clicks on the Strategy Menu inside the landing page$")
    public void user_clicks_on_the_strategy_menu_inside_the_landing_page() throws Throwable {
    	
        landingPage1.clickOnstrategydropdownmenu();
        Thread.sleep(1000);
       
    }
    
    @And("^User clicks on the FA Menu inside the landing page$")
    public void user_clicks_on_the_fa_menu_inside_the_landing_page() throws Throwable {
    	 landingPage1.clickOnFAdropdownmenu();
         //Thread.sleep(1000);
    }
    @And("^User clicks on \"([^\"]*)\" on landing page$")
    public void user_clicks_on_something_on_landing_page(String key) throws Throwable {
        landingPage.clickOnLink(key);
        Reporter.addStepLog("clicking on "+key);
        Thread.sleep(1000);
        Reporter.addScreenCapture();
    }
    @And("^User clicks on the Dropdown Icon inside landing page$")
    public void user_clicks_on_the_dropdown_icon_inside_landing_page() throws Throwable {
    	//Thread.sleep(2000);
    	landingPage1.verifyProductMasterheaderonlandingpage();
        landingPage1.clickOncreatenewdropdownicon();
        
        //Thread.sleep(1000);
    }
    
    @When("^User clicks on Create New Dropdown and selects Manager$")
    public void user_clicks_on_create_new_dropdown_and_selects_manager() throws Throwable {
    	//Thread.sleep(2000);
    	landingPage1.verifyProductMasterheaderonlandingpage();
        landingPage1.clickOncreatenewdropdownicon();
        
        //Thread.sleep(1000);
        //Thread.sleep(2000);
        landingPage1.clickOnmanagerdropdownmenu();
        
        Thread.sleep(1000);
    }
    @Then("^User should be able to see the maximum of \"([^\"]*)\" in \"([^\"]*)\" on landing page$")
    public void user_should_be_able_to_see_the_maximum_of_something_in_something_on_landing_page(String NoOfSearches, String key) throws Throwable {
        listOfElements = landingPage.getElements(key);
        Assert.assertEquals(Integer.parseInt(NoOfSearches), listOfElements.size());
        Reporter.addStepLog("verified that the "+key+" has a maximum of "+listOfElements.size()+" ");
        Reporter.addScreenCapture();
        
    }
   
    @Then("^User clicks on first element of \"([^\"]*)\" on landing page$")
    public void user_clicks_on_first_element_of_something_on_landing_page(String key) throws Throwable {
        landingPage.clickOnLink(key);
        Reporter.addStepLog("clicking on the first element of "+key);
    }
    
    @And("^User search with \"([^\"]*)\" different searchtoken and store it in a list on landing page$")
    public void user_search_with_something_different_searchtoken_and_store_it_in_a_list_in_landing_screen(String noOfTimes) throws Throwable {
        int number = Integer.parseInt(noOfTimes);
        searchTokens =  new ArrayList<String>();
        for (int i=0;i<number;i++) {
        	Long time = Calendar.getInstance().getTimeInMillis();
        	searchTokens.add(Long.toString(time));
        	myElement =  landingPage.getElementFromShadowRoot("Search TextBox");
        	action.sendkeysClipboard(myElement,searchTokens.get(i));
        	myElement.sendKeys(Keys.ENTER);
//        	Thread.sleep(2000);
//        	landingPage.clickOnLink(landingPage.getElementFromShadowRoot("Global Search Icon"));
//        	Thread.sleep(2000);
        	Reporter.addScreenCapture();
        	myElement.clear() ;
        	
        }
    }

    @Then("^User should be able to see the \"([^\"]*)\" in the same order as stored in the list on landing page$")
    public void user_should_be_able_to_see_the_search_results_in_the_same_order_as_stored_in_the_list_on_landing_page(String key) throws Throwable {
        listOfElements = landingPage.getElements(key);
    	for(int i=searchTokens.size()-1;i>=0;i--) {
        	Assert.assertEquals(searchTokens.get(i), listOfElements.get(searchTokens.size()-i-1).getText());
        	Reporter.addStepLog("verified for the "+(searchTokens.size()-i-1)+"th element");
        	landingPage.highlightElement(listOfElements.get(searchTokens.size()-i-1));
        }
    	Reporter.addScreenCapture();
    }

    @And("^User refresh the landing page$")
    public void user_refresh_the_landing_page() throws Throwable {
        landingPage.refreshPage();
    }
    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside landing screen$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_on_landing_screen(String ghostText, String searchBox) throws Throwable {
        landingPage.verifyGhostText(ghostText, landingPage.getElementFromShadowRoot(searchBox));
        Reporter.addStepLog("verified the ghost text is "+ghostText);
    }


    @Then("^User should be able to see the \"([^\"]*)\" at the \"([^\"]*)\" of landing screen$")
    public void user_should_be_able_to_see_the_something_at_the_something_of_landing_screen(String key, String shadowRootKey) throws Throwable {
    	landingPage.verifyElement(landingPage.fetchElementFromShadowRoot(key, shadowRootKey));
    	
    }

    
  
    @And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color$")
    public void that_something_should_be_displayed_in_something_color(String strArg1, String expectedColor) throws Throwable {
    	expectedColorCode = Action.getTestData(expectedColor);
    	landingPage.verifyCurrentElementColor(expectedColorCode);
    }
    @Then("^\"([^\"]*)\" columns should be displayed in \"([^\"]*)\" on landing screen$")
    public void something_columns_on_landing_screen(String list1, String key) throws Throwable {
    	String[] listArray = list1.split(", ");
       	listOfElements =  landingPage.getElements(key);
    	for(int i=0;i<listArray.length;i++) {
    		landingPage.verifyTextInListOfElements(listArray[i], listOfElements);
    		Reporter.addStepLog(listArray[i]+" is displaying in " + key);
    	}
    	Reporter.addScreenCapture();
    }
    
    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" on landing screen$")
    public void something_on_landing_screen(String list1, String elementsKey) throws Throwable {
       String[] listArray = list1.split(", ");
       	Thread.sleep(2000);
    	listOfElements =  landingPage.getElements(elementsKey);
    	for(int i=0;i<listArray.length;i++) {
    		Reporter.addStepLog("verifying for text "+listArray[i]);
    		landingPage.verifyTextInListOfElements(listArray[i], listOfElements);
    		Reporter.addStepLog(listArray[i]+" is displaying in " + elementsKey);
    	}
    }
    @And("^Order of the columns in \"([^\"]*)\" should be \"([^\"]*)\"$")
    public void order_of_the_columns_in_something_should_be_something(String key, String list1) throws Throwable {
    	String[] listArray = list1.split(", ");
    	
       	listOfElements =  landingPage.getElements(key);
       	for(int i=0;i<listArray.length;i++) {
       		if(i==1) {
       			continue;
       		}
    		landingPage.verifyTextInElement(listArray[i], listOfElements.get(i));
    		Reporter.addStepLog(listArray[i]+" is displaying in "+i+1+" position in " + key);
    	}
    }
    
    @And("^Order of the \"([^\"]*)\" should be \"([^\"]*)\"$")
    public void order_of_the_something_should_be_something(String elementsKey, String list1) {
    	 String[] listArray = list1.split(", ");
    	listOfElements =  landingPage.getElements(elementsKey);
    	for(int i=0;i<listArray.length;i++) {
    		Assert.assertTrue( listOfElements.get(i).getText().contains(listArray[i]));
    		landingPage.highlightElement(listOfElements.get(i));
    		
    	}
    }

    @When("^User search with the \"([^\"]*)\" in the \"([^\"]*)\" inside landing page$")
    public void user_search_with_the_something_in_the_something_on_landing_page(String searchtoken, String key) throws Throwable {
    	searchValue = searchtoken;
    	if(searchtoken.contains("unique")) {
    		searchValue =  Long.toString(Calendar.getInstance().getTimeInMillis());
    	}
    	landingPage.sendKeysCharacterWise(searchValue+Keys.ENTER, landingPage.getElementFromShadowRoot(key));
    	Reporter.addStepLog("searching with "+searchtoken);
    }

    @Then("^User should be able to see the search results in every row of \"([^\"]*)\" in the Program Grid on landing page$")
    public void user_should_be_able_to_see_the_search_results_in_every_row_of_something_in_the_program_grid_on_landing_page(String key) throws Throwable {
    	String programDescription,programName,programCode;
    	listOfElements =  landingPage.getElements(key);
       for(int i=0;i<Math.min(listOfElements.size(), 20);i++) {
    	   landingPage.scrollToElement(listOfElements.get(i));
    	   listOfElements2 = landingPage.getInsideElements(listOfElements.get(i), "Data");
    	   programDescription = listOfElements2.get(0).getText();
    	   Reporter.addStepLog("Program Description is "+programDescription);
    	   programName = listOfElements2.get(2).getText();
    	   Reporter.addStepLog("Program Name is "+programName);
    	   programCode = listOfElements2.get(3).getText();
    	   Reporter.addStepLog("Program Code is "+programCode);
    	   Assert.assertTrue(programDescription.toLowerCase().contains(searchValue.toLowerCase())||programName.toLowerCase().contains(searchValue.toLowerCase())||programCode.toLowerCase().contains(searchValue.toLowerCase()));
    	   landingPage.highlightElement(listOfElements.get(i));
       }
    }
    
    @Then("^User should be able to see the search results in every row of \"([^\"]*)\" in the Managers/FAs Grid on landing page$")
    public void user_should_be_able_to_see_the_search_results_in_every_row_of_something_in_the_managersfas_grid_on_landing_page(String key) throws Throwable {
    	String managerCode;
    	listOfElements =  landingPage.getElements(key);
       for(int i=0;i<Math.min(listOfElements.size(), 20);i++) {
    	   landingPage.scrollToElement(listOfElements.get(i));
    	   listOfElements2 = landingPage.getInsideElements(listOfElements.get(i), "Data");
    	   managerCode = listOfElements2.get(2).getText();
    	   Reporter.addStepLog("Manager Code is "+managerCode);
    	   Assert.assertTrue(managerCode.toLowerCase().contains(searchValue.toLowerCase()));
    	   landingPage.highlightElement(listOfElements.get(i));
       }
    }

    @Then("^User should be able to see the search results in every row of \"([^\"]*)\" in the Benchmark Grid on landing page$")
    public void user_should_be_able_to_see_the_search_results_in_every_row_of_something_in_the_benchmark_grid_on_landing_page(String key) throws Throwable {
    	String benchmarkDescription,benchmarkCode;
    	listOfElements =  landingPage.getElements(key);
       for(int i=0;i<Math.min(listOfElements.size(), 20);i++) {
    	   landingPage.scrollToElement(listOfElements.get(i));
    	   listOfElements2 = landingPage.getInsideElements(listOfElements.get(i), "Data");
    	   benchmarkDescription = listOfElements2.get(0).getText();
    	   Reporter.addStepLog("Benchmark Description is "+benchmarkDescription);
    	   benchmarkCode = listOfElements2.get(3).getText();
    	   Reporter.addStepLog("Benchmark Code is "+benchmarkCode);
    	   Assert.assertTrue(benchmarkDescription.toLowerCase().contains(searchValue.toLowerCase())||benchmarkCode.toLowerCase().contains(searchValue.toLowerCase()));
    	   landingPage.highlightElement(listOfElements.get(i));
       }
    }

    @Then("^User should be able to see the search results in every row of \"([^\"]*)\" in the Style Grid on landing page$")
    public void user_should_be_able_to_see_the_search_results_in_every_row_of_something_in_the_style_grid_on_landing_page(String key) throws Throwable {
    	String styleDescription,styleName,styleCode;
    	listOfElements =  landingPage.getElements(key);
       for(int i=0;i<Math.min(listOfElements.size(), 20);i++) {
    	   landingPage.scrollToElement(listOfElements.get(i));
    	   listOfElements2 = landingPage.getInsideElements(listOfElements.get(i), "Data");
    	   styleDescription = listOfElements2.get(0).getText();
    	   Reporter.addStepLog("Style Description is "+styleDescription);
    	   styleName = listOfElements2.get(2).getText();
    	   Reporter.addStepLog("Style Name is "+styleName);
    	   styleCode = listOfElements2.get(3).getText();
    	   Reporter.addStepLog("Style Code is "+styleCode);
    	   Assert.assertTrue(styleDescription.toLowerCase().contains(searchValue.toLowerCase())||styleName.toLowerCase().contains(searchValue.toLowerCase())||styleCode.toLowerCase().contains(searchValue.toLowerCase()));
    	   landingPage.highlightElement(listOfElements.get(i));
       }
    }

    @Then("^User should be able to see the search results in every row of \"([^\"]*)\" in the Strategy Grid on landing page$")
    public void user_should_be_able_to_see_the_search_results_in_every_row_of_something_in_the_strategy_grid_on_landing_page(String key) throws Throwable {
       String strategyName,strategyCode;
    	listOfElements =  landingPage.getElements(key);
       for(int i=0;i<Math.min(listOfElements.size(), 20);i++) {
    	   landingPage.scrollToElement(listOfElements.get(i));
    	   listOfElements2 = landingPage.getInsideElements(listOfElements.get(i), "Data");
    	   strategyName = listOfElements2.get(0).getText();
    	   Reporter.addStepLog("Strategy Name is "+strategyName);
    	   strategyCode = listOfElements2.get(2).getText();
    	   Reporter.addStepLog("Strategy Code is "+strategyCode);
    	   Assert.assertTrue(strategyName.toLowerCase().contains(searchValue.toLowerCase())||strategyCode.toLowerCase().contains(searchValue.toLowerCase()));
    	   landingPage.highlightElement(listOfElements.get(i));
       }
    }

    @And("^User expands the \"([^\"]*)\" shown inside \"([^\"]*)\" inside the landing screen$")
    public void user_expands_the_something_shown_inside_something_inside_the_landing_screen(String insideKey, String parentKey) throws Throwable {
    	myElement =landingPage.fetchElementFromShadowRoot(insideKey, parentKey);
    	String stateOfArrow = landingPage.getAttribute(myElement, "class");
    	if(stateOfArrow.equalsIgnoreCase("arrow arrow-up")) {
    		Reporter.addStepLog("The "+insideKey+" is expanded");
    	}
    	else if(stateOfArrow.equalsIgnoreCase("arrow arrow-down")){
    		landingPage.clickOnLink(myElement);
    		Assert.assertEquals("arrow arrow-up", landingPage.getAttribute(myElement, "class"));
    		Reporter.addStepLog("The "+insideKey+" is expanded");
    	}
    	else {
    		Reporter.addStepLog("Something is wrong");
    		Assert.assertTrue(false);
    	}
    }

    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the landing page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_landing_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
    	landingPage.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = landingPage.getElementsFromShadowRoot(key);
   	 landingPage.verifyTextInListOfElements( items.get(i),listOfElements);  
        } 
    }

    @And("^the count shown in the \"([^\"]*)\" link should match with the total no of \"([^\"]*)\" shown in landing page$")
    public void the_count_shown_in_the_something_link_should_match_with_the_total_no_of_something_shown_in_landing_page(String countKey, String key) throws Throwable {
        listOfElements = landingPage.getElements(key);
        myValue = landingPage.getElement(countKey).getText();
        myValue=myValue.substring(myValue.indexOf('(')+1, myValue.indexOf(')'));
        Reporter.addStepLog("The count shown is "+myValue);
        Assert.assertEquals(Integer.parseInt(myValue), listOfElements.size());
        Reporter.addStepLog("The count is matching with the total no of rows");
        
    }
    @And("^User expands the \"([^\"]*)\" inside the landing screen$")
    public void user_expands_the_something_inside_the_landing_screen(String key) throws Throwable {
    	myElement = landingPage.getElementFromShadowRoot(key);
    	String stateOfArrow = landingPage.getAttribute(myElement, "class");
    	if(stateOfArrow.equalsIgnoreCase("arrow arrow-up")) {
    		Reporter.addStepLog("The "+key+" is expanded");
    	}
    	else if(stateOfArrow.equalsIgnoreCase("arrow arrow-down")){
    		landingPage.clickOnLink(myElement);
    		Assert.assertEquals("arrow arrow-up", landingPage.getAttribute(myElement, "class"));
    		Reporter.addStepLog("The "+key+" is expanded");
    	}
    	else {
    		Reporter.addStepLog("Something is wrong");
    		Assert.assertTrue(false);
    	}
    }
    @Then("^The \"([^\"]*)\" shown inside the \"([^\"]*)\" should be expandable and collapsible on landing page$")
    public void the_something_shown_should_be_expandable_and_collapsible_on_landing_page(String key, String parentKey) throws Throwable  {
        //clicking on the icon
    	
    	myElement = landingPage.fetchElementFromShadowRoot(key, parentKey);
    	String headerName = key.substring(0,key.length()-5);
    	WebElement contentElement= landingPage.fetchElementFromShadowRoot("Content", parentKey);
    	String stateOfArrow = landingPage.getAttribute(myElement, "class");
    	if(stateOfArrow.equalsIgnoreCase("arrow arrow-up")) {
    		Reporter.addStepLog("The arrow is up before clicking on grid");
    		landingPage.clickOnLink(myElement);
    		Thread.sleep(500);
    		Assert.assertEquals("arrow arrow-down", landingPage.getAttribute(myElement, "class"));
    		Reporter.addStepLog("The arrow is down after clicking on grid");
    		landingPage.verifyAttribute("expansion-panel-content",contentElement, "class");
    		Reporter.addStepLog("Content is not visible now");
    		Reporter.addScreenCapture();
    		landingPage.clickOnLink(myElement);
    		Thread.sleep(500);
    		Assert.assertEquals("arrow arrow-up", landingPage.getAttribute(myElement, "class"));
    		Reporter.addStepLog("The arrow is up after again clicking on grid");
    		landingPage.verifyAttribute("expansion-panel-content expansion-panel-content-active",contentElement, "class");
    		Reporter.addStepLog("Content is visible now");
    		Reporter.addScreenCapture();
//    		landingPage.findElementByDynamicXpath(xpath));
    		
    	}
    	else if(stateOfArrow.equalsIgnoreCase("arrow arrow-down")) {
    		Reporter.addStepLog("The arrow is down before clicking on grid");
    		landingPage.clickOnLink(myElement);
    		Assert.assertEquals("arrow arrow-up", landingPage.getAttribute(myElement, "class"));
    		Reporter.addStepLog("The arrow is up after clicking on grid");
    		landingPage.verifyAttribute("expansion-panel-content expansion-panel-content-active",contentElement, "class");
    		Reporter.addStepLog("Content is visible now");
    		Reporter.addScreenCapture();
    	}
    	else {
    		Reporter.addStepLog("Something is wrong");
    		Assert.assertTrue(false);
    	}
    }
    @And("^\"([^\"]*)\" horizontal line should be displayed below \"([^\"]*)\"$")
    public void something_horizontal_line_should_be_displayed_below_something(String color, String key) throws Throwable {
    	expectedColorCode = Action.getTestData(color);
    	landingPage.verifyHorizontalLineColor(expectedColorCode, key);
    	Reporter.addScreenCapture();
    }
    
    @Then("^User should be able to see maximum \"([^\"]*)\" rows of \"([^\"]*)\"$")
    public void user_should_be_able_to_see_maximum_something_rows_of_something(String rowCount, String key) {
        listOfElements = landingPage.getElements(key);
        Assert.assertTrue(Integer.parseInt(rowCount)>= listOfElements.size());
        Reporter.addScreenCapture();
    }
    @Then("^User should be able to see (.+) for every row in table under the \"([^\"]*)\" Header on landing screen$")
    public void user_should_be_able_to_see_for_every_row_in_table_under_the_something_header_on_landing_screen(String username, String key) throws Throwable {
        listOfElements = landingPage.getElements(key);
        for(int i=0;i<listOfElements.size();i++) {
        	Assert.assertEquals(username, listOfElements.get(i).getText());;
        }
        Reporter.addScreenCapture();
    }
    @Then("^User should be able to see \"([^\"]*)\" for all the rows in table on landing screen$")
    public void user_should_be_able_to_see_something_for_something_rows_in_table_on_landing_screen(String key, String rowCount) {
    	listOfElements = landingPage.getElements(key);
    	Assert.assertEquals( listOfElements.size(),Integer.parseInt(rowCount));
    	Reporter.addScreenCapture();
    	
    }
    
    @Then("^User should be able to see \"([^\"]*)\" for every row in \"([^\"]*)\" on landing screen$")
    public void user_should_be_able_to_see_something_for_every_row_in_something_on_landing_screen(String insideElementKey, String key) throws Throwable {
    		listOfElements = landingPage.getElements(key);
        listOfElements2 =landingPage.getElements(insideElementKey);
        for(int i=0;i<listOfElements.size();i++) {
        	landingPage.verifyElement( listOfElements2.get(i));
        	Reporter.addStepLog("verified "+insideElementKey+ " for element no "+(i+1));
        	Reporter.addScreenCapture();
        }
    }
    
    @Then("^User should see one from the \"([^\"]*)\" for every row in table under the \"([^\"]*)\" Header on landing screen$")
    public void user_should_be_able_to_see_one_from_the_something_header_on_landing_screen(String items, String key) throws Throwable {
    	List<String> list1 = Arrays.asList(items.split(", "));
    	listOfElements = landingPage.getElements(key);
    	for(int i=0;i<listOfElements.size();i++) {
    		list1.contains(listOfElements.get(i).getText());
    		landingPage.highlightElement(listOfElements.get(i));
    		Reporter.addStepLog("verified for "+i+"th row ");
    	}
    }
    

    @Then("^User should be able to see \"([^\"]*)\" message on the landing screen$")
    public void user_should_be_able_to_see_something_message_on_the_landing_screen(String message) throws Throwable {
    	landingPage.verifyHeader(message);
    	Reporter.addScreenCapture();
    }
    @Then("^User should be able to see the \"([^\"]*)\" on landing screen$")
    public void user_should_be_able_to_see_the_something_on_landing_screen(String Key) throws Throwable {
    	landingPage.verifyElement(Key);
    	Reporter.addStepLog("verifying that "+Key+" is present");
    	
    }
    @Then("^User should be able to see the Create New Dropdown on landing screen$")
    public void user_should_be_able_to_see_the_create_new_dropdown_on_landing_screen() throws Throwable {
    	landingPage1.verifyCreateNewDropdownonlandingpage();
    	//Reporter.addStepLog("verifying that "+Key+" is present");
    }
    @Then("^User should be able to see the \"([^\"]*)\" inside landing screen$")
    public void user_should_be_able_to_see_the_something_inside_landing_screen(String key) throws Throwable {
        landingPage.verifyElementFromShadowRoot(key);
        Reporter.addStepLog("verifying that "+key+" is present");
    }
    
    @And("^User should be able to see the Dropdown Icon inside landing screen$")
    public void user_should_be_able_to_see_the_dropdown_icon_inside_landing_screen() throws Throwable {
    	landingPage1.verifyDropdowniconincreatenewdropdown();
    }
    
    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on landing screen$")
    public void something_should_be_displayed_in_something_color(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	landingPage.verifyColor(key,expectedColorCode);
    	Reporter.addStepLog("verifying the color of  "+key+" is "+color);
    	Reporter.addScreenCapture();
    }
    
    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside landing screen$")
    public void something_should_be_displayed_in_something_color_inside_landing_screen(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	landingPage.verifyColor(landingPage.getElementFromShadowRoot(key),expectedColorCode);
    	Reporter.addStepLog("verifying the color of  "+key+" is "+color);
    	Reporter.addScreenCapture();
    }
    
    @And("^Format of the \"([^\"]*)\" should be \"([^\"]*)\"$")
    public void format_of_the_something_should_be_something(String key, String format) throws Throwable {
    	String timeStamp = landingPage.getText(key);
    	String time[]= timeStamp.split("-");
    	Reporter.addStepLog(time[0]);
    	Assert.assertTrue(landingPage.isThisDateValid(time[0],format ));
    }
    @Then("^user should get logged in to \"([^\"]*)\" landing page$")
    public void user_should_get_logged_in_to_something_landing_page(String key) throws Throwable {

    		landingPage.verifyHeader(key);
    		Reporter.addStepLog("User Successfully logged in to Product Master Landing page");
    		
    	}
   
   
    @And("^The \"([^\"]*)\" on the landing page should contain all the following options$")
    public void the_something_on_the_landing_page_should_contain_all_the_following_options(String key, List<String> items) throws Throwable {
    	for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   	 landingPage.verifyTextInListOfElements( items.get(i), landingPage.getElements(key)); 
   	Reporter.addScreenCapture();
   	 }
    }
    @When("^User types the stored \"([^\"]*)\" in \"([^\"]*)\" in landing page$")
    public void user_types_the_stored_something_in_something_in_landing_page(String notToUse, String key) throws Throwable {
        String sendKeys;
    	if(ProductMasterGeneric.duplicateCode.length()>20) {
    	  sendKeys = ProductMasterGeneric.duplicateCode.substring(ProductMasterGeneric.duplicateCode.length()-20);
        }
        else
        	sendKeys = ProductMasterGeneric.duplicateCode;
        	Reporter.addStepLog("passing the keys "+sendKeys);
    	landingPage.sendKeysCharacterWise(sendKeys, landingPage.getElementFromShadowRoot(key));
        	
    }
    @Then("^\"([^\"]*)\" should not be displayed in \"([^\"]*)\" on landing screen$")
    public void something_should_not_be_displayed_in_something_on_landing_screen(String item, String key) throws Throwable {
        listOfElements = landingPage.getElements(key);
        landingPage.verifyTextNotPresentInListOfElements(item, listOfElements);
        Reporter.addStepLog("verified that "+item+" is not present in "+key);
    }
    

    @And("^User clicks on the first element of \"([^\"]*)\" on the suggestion box on landing page$")
    public void user_clicks_on_the_first_element_of_something_on_the_suggestion_box_on_landing_page(String key) throws Throwable {
        landingPage.clickOnLink(key);
        Reporter.addStepLog("clicking on the first element of "+key);
    }
    
    @Then("^user should be able to go to Landing page$")
    public void user_should_be_able_to_go_to_landing_page() throws Throwable {
        
        Assert.assertTrue(action.getCurrentURL().contains(pageURL));
        
        Reporter.addStepLog("User has landed to landing page");
     }
    

    @When("^User inputs the Strategy Code from Conversion Data in Landing Page in Global Search$")
    public void user_inputs_the_strategy_code_from_conversion_data_in_landing_page_in_global_search() throws SQLException, InterruptedException {
    	
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
    	strategyCode = getValuesFromDBandStoreinExcel("UpdateStrategy2418");

    
		//Searching for SMA Single Access from DB in Landing page
		landingPage1.enterSearchToken(strategyCode);
		landingPage1.clickOnSearchIcon();
		landingPage1.clickOnSearchIcon();
		landingPage1.clickOnSearchedRecord("SMA Strategy");
//		landingPage1.verifySeeAllResultsButton();
//		landingPage1.clickOnSeeAllResultsButton();
		
    }
    
    @And("^User selects the first record from SMA Grid View in Landing Page$")
    public void user_selects_the_first_record_from_sma_grid_view_in_landing_page() {
        landingPage1.clickOnSMATab();
        landingPage1.movetoFirstElementinFilteredrecords();
        landingPage1.clickOnEllipsesIcon();
        landingPage1.verifyOnViewDetailsLink();
        landingPage1.clickOnViewDetailsLink();
        pmdb.DBConnectionClose();
    }
    
    @And("^User able to enter the filter condition value in input field for PMP Grid$")
    public void user_able_to_enter_the_filter_condition_value_in_input_field_for_pmp_grid() throws Throwable {
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
//    	
//    	phoaStrategyCode = getValuesFromDBandStoreinExcel("UpdatePMPStrategy");
    	landingPage1.enterFilterValue(phoaStrategyCode);
    }

//    @And("^User has strategy code for PMP Startegy for (.+)$")
//    public void user_has_strategy_code_for_pmp_startegy_for(String mandatorydetails) throws Throwable {
//    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
//    	
//    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
//    	String sheetName = "Test";
//    	int rowIndex;
//    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
//    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
//        phoaStrategyCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
//        getDataValuesFromDBandStoreinExcel("UpdatePMPStrategy", mandatorydetails);
//    }
    
    @And("^User has strategy code for PHOA Startegy for (.+)$")
    public void user_has_strategy_code_for_phoa_startegy_for(String mandatorydetails) throws IOException, SQLException {
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
    	
    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/PendingHOApproval.xlsx";
    	String sheetName = "Test";
    	int rowIndex;
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        phoaStrategyCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
        getDataValuesFromDBandStoreinExcel("PendingHOApproval", mandatorydetails);
    }
    
    
    @And("^User has strategy code for PHOA Startegy from conversion data$")
    public void user_has_strategy_code_for_phoa_startegy_from_conversion_data() throws SQLException {
    	
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
    	
    	phoaStrategyCode = getValuesFromDBandStoreinExcel("PendingHOApproval");
    	
    }
    
    
    @And("^User able to enter the filter condition value in input field for HO Approval Grid$")
    public void user_able_to_enter_the_filter_condition_value_in_input_field_for_ho_approval_grid() {
    	landingPage1.enterFilterValue(phoaStrategyCode);
    }
    
    @And("^User selects the filtered record in HO Approval grid View$")
    public void user_selects_the_filtered_record_in_ho_approval_grid_view() throws Throwable {
    	landingPage1.movetoFirstElementinFilteredrecords();
        landingPage1.clickOnEllipsesIcon();
        landingPage1.verifyOnApproveRejectLink();
        landingPage1.clickOnApproveRejectLink();
    }
    
    private String getDataValuesFromDBandStoreinExcel(String excelName, String mandatorydetails) throws SQLException, IOException {

    	
    	
    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/"+excelName+".xlsx";
    	String sheetName = "Test";
    	int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        phoaStrategyCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
        pmdb.DBConnectionStart();
        String SQLquery, labelname = null;
    	String dbDataIterator = "testNull";
    	ResultSet rs;
    	sheetName = "Conversion_Validation";
    	int cellnum = 1;
    	String label  = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
    	ArrayList<String> tempData = new ArrayList<String>();
    	
		if(label == "")
			label = "isEmpty";
		
		while (label != "isEmpty") {
			
			if(label.contains("ignore")) {
				cellnum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if(label == "")
						label = "isEmpty";
			}
			else {
				
				dbDataIterator = "testnull";
				SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
				labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
	    		SQLquery = SQLquery.replace("@data", "'"+phoaStrategyCode+"'");
	    		rs= DBManager.executeSelectQuery(SQLquery);
	    		
	    		
	    		while(rs.next()) {
	    			
	    				dbDataIterator = rs.getString(labelname);
	    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    					dbDataIterator = "isEmpty";
		    					if(label.contains("radiobutton")) {
			    					dbDataIterator = "Not defined";
			    				}
		    			}
	    				
	    				tempData.add(dbDataIterator);
	    				
	    		 }
	    		//to handle Zero records from DB 
	    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
	    			dbDataIterator = "isEmpty";
	    		}
	    		
	    		if(label.contains("Node ID")) {
	    			sheetName = "Query";
	    			int row = 2;
	    			SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, row, 1);
					labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, row, 2);
					SQLquery = SQLquery.replace("@data", "'"+phoaStrategyCode+"'");
		    		rs= DBManager.executeSelectQuery(SQLquery);
		    		
		   
		    		while(rs.next()) {
		    			
		    				dbDataIterator = rs.getString(labelname);
		    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
			    					dbDataIterator = "isEmpty";
			    					if(label.contains("radiobutton")) {
				    					dbDataIterator = "Not defined";
				    				}
			    			}
		    				
		    				tempData.add(dbDataIterator);
		    				
		    		 }
		    		
		    		sheetName = "Conversion_Validation";
	    		}
	    		
	    		//to handle multiple values for same column
	    		if(tempData.size() > 1) {
	    			Collections.sort(tempData);
	    			dbDataIterator = "";
	    			for (String G : tempData) {
							dbDataIterator = dbDataIterator+G+":";
					}	
	    		}
	    		tempData.clear();
//	    		//To be deleted below if
//	    		if(label.contains("Primary Benchmark")) {
//	    			dbDataIterator = "isEmpty";
//	    		}
	    		//setting data into excel for validation
	    		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, cellnum, 3, dbDataIterator);
				cellnum++;
	    		label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
	    		if(label == "")
	    			label = "isEmpty";
			}
			
			
		}
		
		//exlObj.closeWorkBook();
		//pmdb.DBConnectionClose();
		return phoaStrategyCode;
		
	
    }
    
    private String getDataFromDBandStoreinExcel(String excelName) throws SQLException {
    	
    	
    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/"+excelName+".xlsx";
    	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
    	String SQLquery, labelname = null;
    	pmdb.DBConnectionStart();
    	String dbDataIterator = "testNull";
    	ResultSet rs;
    	
    	//Get One Strategy Code from Conversion data
    	String sheetName = "Test";
    	XSSFSheet sheet = exlObj.getSheet(sheetName);
    	SQLquery = (String) exlObj.getCellData(sheet, 1, 1);
		labelname = (String) exlObj.getCellData(sheet, 1, 2);
		
		
    	sheetName = "Conversion_Validation";
    	sheet = exlObj.getSheet(sheetName);
    	int cellnum = 1;
    	String label  = (String) exlObj.getCellData(sheet, cellnum, 0).toString();
    	ArrayList<String> tempData = new ArrayList<String>();
    	
		if(label == "")
			label = "isEmpty";
		
		while (label != "isEmpty") {
			
			if(label.contains("ignore")) {
				cellnum++;
				label = (String) exlObj.getCellData(sheet, cellnum, 0);
					if(label == "")
						label = "isEmpty";
			}
			else {
				
				dbDataIterator = "testnull";
				SQLquery = (String) exlObj.getCellData(sheet, cellnum, 1);
				labelname = (String) exlObj.getCellData(sheet, cellnum, 2);
				
	    		SQLquery = SQLquery.replace("@data", "'"+phoaStrategyCode+"'");
	    		rs= DBManager.executeSelectQuery(SQLquery);
	    		
	   
	    		while(rs.next()) {
	    			
	    				dbDataIterator = rs.getString(labelname);
	    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    					dbDataIterator = "isEmpty";
		    					if(label.contains("radiobutton")) {
			    					dbDataIterator = "Not defined";
			    				}
		    			}
	    				
	    				tempData.add(dbDataIterator);
	    				
	    		 }
	    		//to handle Zero records from DB 
	    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
	    			dbDataIterator = "isEmpty";
	    		}
	    		
	    		if(label.contains("Node ID")) {
	    			sheetName = "Query";
	    			int row = 2;
	    	    	sheet = exlObj.getSheet(sheetName);
	    			SQLquery = (String) exlObj.getCellData(sheet, row, 1);
					labelname = (String) exlObj.getCellData(sheet, row, 2);
					SQLquery = SQLquery.replace("@data", "'"+phoaStrategyCode+"'");
		    		rs= DBManager.executeSelectQuery(SQLquery);
		    		
		   
		    		while(rs.next()) {
		    			
		    				dbDataIterator = rs.getString(labelname);
		    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
			    					dbDataIterator = "isEmpty";
			    					if(label.contains("radiobutton")) {
				    					dbDataIterator = "Not defined";
				    				}
			    			}
		    				
		    				tempData.add(dbDataIterator);
		    				
		    		 }
		    		
		    		sheetName = "Conversion_Validation";
		        	sheet = exlObj.getSheet(sheetName);
	    		}
	    		
	    		//to handle multiple values for same column
	    		if(tempData.size() > 1) {
	    			Collections.sort(tempData);
	    			dbDataIterator = "";
	    			for (String G : tempData) {
							dbDataIterator = dbDataIterator+G+":";
					}	
	    		}
	    		tempData.clear();
	    		
	    		//setting data into excel for validation
	    		exlObj.setCellData(sheet, cellnum, 3, dbDataIterator);
				cellnum++;
	    		label = (String) exlObj.getCellData(sheet, cellnum, 0);
	    		if(label == "")
	    			label = "isEmpty";
			}
			
			
		}
		
		exlObj.closeWorkBook();
		//pmdb.DBConnectionClose();
		return phoaStrategyCode;
		
	}

    private String getValuesFromDBandStoreinExcel(String excelName) throws SQLException {
    	
    	
    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/"+excelName+".xlsx";
    	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
    	String SQLquery, labelname = null;
    	pmdb.DBConnectionStart();
    	String dbDataIterator = "testNull";
    	ResultSet rs;
    	
    	//Get One Strategy Code from Conversion data
    	String sheetName = "Query";
    	XSSFSheet sheet = exlObj.getSheet(sheetName);
    	SQLquery = (String) exlObj.getCellData(sheet, 1, 1);
		labelname = (String) exlObj.getCellData(sheet, 1, 2);
		
		//SQLquery = SQLquery.replace("@data", "'"+strategyCode+"'");
		//System.out.println(excelName+" :: "+SQLquery);
		rs= DBManager.executeSelectQuery(SQLquery);
		

		while(rs.next()) {
			
				dbDataIterator = rs.getString(labelname);
				if(rs.wasNull() || dbDataIterator.isEmpty()) {
    					dbDataIterator = "isEmpty";
    			}
				break;
				
		 }
		phoaStrategyCode = dbDataIterator;
		
		if(phoaStrategyCode.contains("testNull")) {
			Assert.fail("There is no Conversion Data in DB");
		}
    	sheetName = "Conversion_Validation";
    	sheet = exlObj.getSheet(sheetName);
    	int cellnum = 1;
    	String label  = (String) exlObj.getCellData(sheet, cellnum, 0).toString();
    	ArrayList<String> tempData = new ArrayList<String>();
    	
		if(label == "")
			label = "isEmpty";
		
		while (label != "isEmpty") {
			
			if(label.contains("ignore")) {
				cellnum++;
				label = (String) exlObj.getCellData(sheet, cellnum, 0);
					if(label == "")
						label = "isEmpty";
			}
			else {
				
				dbDataIterator = "testnull";
				SQLquery = (String) exlObj.getCellData(sheet, cellnum, 1);
				labelname = (String) exlObj.getCellData(sheet, cellnum, 2);
				
	    		SQLquery = SQLquery.replace("@data", "'"+phoaStrategyCode+"'");
	    		rs= DBManager.executeSelectQuery(SQLquery);
	    		
	   
	    		while(rs.next()) {
	    			
	    				dbDataIterator = rs.getString(labelname);
	    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    					dbDataIterator = "isEmpty";
		    					if(label.contains("radiobutton")) {
			    					dbDataIterator = "Not defined";
			    				}
		    			}
	    				
	    				tempData.add(dbDataIterator);
	    				
	    		 }
	    		//to handle Zero records from DB 
	    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
	    			dbDataIterator = "isEmpty";
	    		}
	    		
	    		if(label.contains("Node ID")) {
	    			sheetName = "Query";
	    			int row = 2;
	    	    	sheet = exlObj.getSheet(sheetName);
	    			SQLquery = (String) exlObj.getCellData(sheet, row, 1);
					labelname = (String) exlObj.getCellData(sheet, row, 2);
					SQLquery = SQLquery.replace("@data", "'"+phoaStrategyCode+"'");
		    		rs= DBManager.executeSelectQuery(SQLquery);
		    		
		   
		    		while(rs.next()) {
		    			
		    				dbDataIterator = rs.getString(labelname);
		    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
			    					dbDataIterator = "isEmpty";
			    					if(label.contains("radiobutton")) {
				    					dbDataIterator = "Not defined";
				    				}
			    			}
		    				
		    				tempData.add(dbDataIterator);
		    				
		    		 }
		    		
		    		sheetName = "Conversion_Validation";
		        	sheet = exlObj.getSheet(sheetName);
	    		}
	    		
	    		//to handle multiple values for same column
	    		if(tempData.size() > 1) {
	    			Collections.sort(tempData);
	    			dbDataIterator = "";
	    			for (String G : tempData) {
							dbDataIterator = dbDataIterator+G+":";
					}	
	    		}
	    		tempData.clear();
	    		
	    		//setting data into excel for validation
	    		exlObj.setCellData(sheet, cellnum, 3, dbDataIterator);
				cellnum++;
	    		label = (String) exlObj.getCellData(sheet, cellnum, 0);
	    		if(label == "")
	    			label = "isEmpty";
			}
			
			
		}
		
		exlObj.closeWorkBook();
		//pmdb.DBConnectionClose();
		return phoaStrategyCode;
		
	}

    
    
    
    @And("^User has strategy code for Rejected Startegy from conversion data$")
    public void user_has_strategy_code_for_rejected_startegy_from_conversion_data() throws SQLException {
    	
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
    	
    	rejectedStrategyCode = getValuesFromDBandStoreinExcel("RejectedStrategy");

    }
    
    @And("^User has strategy code for Rejected Startegy stored in (.+)$")
    public void user_has_strategy_code_for_rejected_startegy_stored_in(String mandatorydetails) {
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
    	String sheetName = "";
    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
    	if (mandatorydetails.contains("Test")) {
    		sheetName = "Test";
		}
    	
    	int rowIndex;
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    	rejectedStrategyCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 2);
        
    }
    
    @And("^User has strategy code for Rejected Startegy$")
    public void user_has_strategy_code_for_rejected_startegy() {
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
    	
    	rejectedStrategyCode = getRejectedStrategyCodeFromDB();
    }
    
    private String getRejectedStrategyCodeFromDB() {
		
    	String env = SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	switch (env) {
		case "dev":
			return "EYR7";
			//return "DX21";
			//return "J464";
			//return "X32D";
		case "qa":
			return "6PSP";
		case "uat":
			return "1WEQ";
		default:
			break;
		}
    	
    	return "Env Do not match";
		
	}

	@And("^User able to enter the filter condition value in input field for Rejected Strategies Grid$")
    public void user_able_to_enter_the_filter_condition_value_in_input_field_for_rejected_strategies_grid() {
    	landingPage1.enterFilterValue(rejectedStrategyCode);
    }
    
    @And("^User selects the filtered record in Rejected Strategies Grid View$")
    public void user_selects_the_filtered_record_in_rejected_strategies_grid_view() {
    	landingPage1.movetoFirstElementinFilteredrecords();
        landingPage1.clickOnEllipsesIcon();
        landingPage1.verifyOnViewDetailsLink();
        landingPage1.clickOnViewDetailsLink();
    }
    
    @When("^User inputs the Strategy Code for PMP from Conversion Data in Landing Page in Global Search$")
    public void user_inputs_the_strategy_code_for_pmp_from_conversion_data_in_landing_page_in_global_search() throws SQLException, InterruptedException {
    	
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
    	pmpStrategyCode = getValuesFromDBandStoreinExcel("UpdatePMPStrategy");

    
		//Searching for PMP Strategy from DB in Landing page
		landingPage1.enterSearchToken(pmpStrategyCode);
		landingPage1.clickOnSearchIcon();
		landingPage1.clickOnSearchedRecord("PMP Strategy");
		
    }
    
    @And("^User selects the first record in PMP Strategies Grid View$")
    public void user_selects_the_first_record_in_pmp_strategies_grid_view() {
    	landingPage1.movetoFirstElementinFilteredrecords();
        landingPage1.clickOnEllipsesIcon();
        landingPage1.verifyOnViewDetailsLink();
        landingPage1.clickOnViewDetailsLink();
    }

    @When("^User inputs the Strategy Code for PMP in Landing Page in Global Search for (.+)$")
    public void user_inputs_the_strategy_code_for_pmp_in_landing_page_in_global_search_for(String mandatorydetails) throws InterruptedException, SQLException, IOException {
    	Reporter.addStepLog(Thread.currentThread().getName());
    	Assert.assertTrue(landingPage1.isUserOnLandingPage());
    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
    	String sheetName = "Test";
    	int rowIndex;
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    	pmpStrategyCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
    	
		//Searching for PMP Strategy from DB in Landing page
		landingPage1.enterSearchToken(pmpStrategyCode);
		action.pause(500);
		//Boolean bool = landingPage1.clickOnSearchedRecord("PMP Strategy");
		
		//if(!bool) {
			landingPage1.clickOnSearchIcon();
			action.pause(500);
			landingPage1.clickOnSeeAllResultsButton();
		//}
		
		
		getDataValuesFromDBandStoreinExcel("UpdatePMPStrategy", mandatorydetails);
    }
    
    /*
     * Below Step Def -- Use strategy code from confirmation page
     * and use it as searchtoken in global search
     */
    @When("^User inputs the Strategy Code from Confirmation Page for \"([^\"]*)\" with (.+)$")
    public void user_inputs_the_strategy_code_from_confirmation_page_for_something_with(String strArg1, String mandatorydetails) throws Throwable {
    	String data = "";
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	if(strArg1.equals("Create SMA Single Access")) {
    		data = "CreateSMASingleAccess";
    	}
    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/"+data+".xlsx";
    	
    	String sheetName = "";
    	int rowIndex;
    	ExcelUtils exlObject = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
    	XSSFSheet sheet;
    	
    	sheetName = "Test";
    	sheet = exlObject.getSheet(sheetName);
    	rowIndex = exlObject.getRowIndexByCellValue(sheet, 0, mandatorydetails);
    	strategyCode = (String) exlObject.getCellData(sheet, rowIndex, 82);

    
		//Searching for SMA Single Access from DB in Landing page
		landingPage1.enterSearchToken(strategyCode);
		landingPage1.clickOnSearchIcon();
		
		/*
		 * direct click on Record from search results
		 * application global search does not support parallel testing
		 */
		landingPage1.clickOnSearchedRecord("SMA Strategy");
		
//		landingPage1.verifySeeAllResultsButton();
//		landingPage1.clickOnSeeAllResultsButton();
    }
    
    @When("^User search with a \"([^\"]*)\" taken from \"([^\"]*)\" in the Search TextBox on landing page$")
    public void user_search_with_a_strategycode_taken_from_strategy_in_the_search_textbox_on_landing_page(String attribute,String sheetName) throws Throwable {
		sheet  = myReferenceFile.getSheet(sheetName);
		searchValue= (String)myReferenceFile.getCellData(sheet, 2, myReferenceFile.getCellIndexByCellValue(sheet, 0, attribute));
		//unlocking after reading from excel
         
         Reporter.addStepLog("searching with "+searchValue);
        Thread.sleep(1000);
        WebElement ele = (WebElement) action.getElementByJavascript("Search_TextBox");
		Thread.sleep(2000);
		action.click(ele);
		ele.clear();
		action.sendKeys(ele, searchValue);
        
		WebElement ele1 = (WebElement) action.getElementByJavascript("Search Icon in Search TextBox");
		action.highligthElement(ele1);
		Thread.sleep(5000);

		int i = 0;

		while (i < 10) {
			action.sendKeys(Keys.ENTER);
			i++;

		}
		Action.pause(10000);
        
        myReferenceFile.closeWorkBook();
        Thread.sleep(1000); 
    }
    
    @And("^User clicks on the first element of Strategy Searches on suggestion box on landing page$")
    public void user_clicks_on_the_first_element_of_strategy_searches_on__suggestion_box_on_landing_page() throws Throwable {
       action.click(action.getElement("Strategy_singleAccess"));
       System.out.println("clicking on strategy search element");
       Reporter.addStepLog("clicking on the first element of Strategy search");
    }
    
    @Then("^User should be able to see Landing Page$")
    public void user_should_be_able_to_see_landing_page() {
        Assert.assertTrue(landingPage1.isUserOnLandingPage());
    }
    
    @And("^User clicks on \"([^\"]*)\" Tab in Landing Page$")
    public void user_clicks_on_something_tab_in_landing_page(String Tab) {
    	landingPage1.clickOnTab(Tab);
    }
    
    @And("^(.+) clicks on \"([^\"]*)\" Tab in the Landing Page$")
    public void clicks_on_something_tab_in_the_landing_page(String typeofuser, String Tab) {
    	userInfo = typeofuser;
    	
    		landingPage1.clickOnTab(Tab, userInfo);
    }

    @And("^User with (.+) inputs searchtoken for \"([^\"]*)\" in Landing Page$")
    public void user_with_inputs_searchtoken_for_something_in_landing_page(String mandatorydetails, String excelName) throws InterruptedException {
    	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/"+excelName+".xlsx";
    	//ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
    	XSSFSheet sheet;
    	String sheetName = "";
    	if(mandatorydetails.contains("Test"))
    		sheetName = "Test";
    	
    	//sheet = exlObj.getSheet(sheetName);
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    			//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
    	
    	int updateDataRowIndex = rowIndex;
    	int dBDataRowIndex = rowIndex+1;
    	
    	String searchToken = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 2);
    	//String dbsearchToken = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dBDataRowIndex, 2);
    	/*
    	String searchToken = (String) exlObj.getCellData(sheet, updateDataRowIndex, 1);
    	String dbsearchToken = (String) exlObj.getCellData(sheet, dBDataRowIndex, 1);
    	*/
    	//searchToken = "Atlanta Capital Management Co., LLC";
    			//"12th Street Asset Management, LLC";
    			//"Atlanta Capital Management Co., LLC"; 
    			//"sxrwPEZDTgKIBrkDHFRn";
    	
    	landingPage1.enterSearchToken(searchToken);
        landingPage1.clickOnSearchIcon();
    	
    }
    
    @Then("^User should able to see create new strategy button$")
    public void user_should_be_able_to_see_create_new_strategy_button() throws Throwable {
        Assert.assertTrue(landingPage1.isCreateNewStrategyButtonVisible());
    }
    
    @When("^User hovers over Upload button in Landing page$")
    public void user_hovers_over_upload_button_in_landing_page() {
        landingPage1.hoverOnUploadButton();
    }

    @Then("^User should be able to see Select to Upload the report text on UI$")
    public void user_should_be_able_to_see_select_to_upload_the_report_text_on_ui() {
        Assert.assertTrue(landingPage1.isUserAbleToSeeUploadText());
    }
    
    @And("^User Clicks on Upload button in Landing page$")
    public void user_clicks_on_upload_button_in_landing_page() {
    	landingPage1.clickOnUploadButton();
    }


}

