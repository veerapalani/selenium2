package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.CreateFAApprovalPage;

public class CreateFAApprovalStepDef {
	WebElement myElement, myElement2;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateFApprovalPage"));
	Alert alert;
	CreateFAApprovalPage createobj = new CreateFAApprovalPage("AD_PM_CreateFApprovalPage");

	@And("^User enters the details required on the Approval Page$")
	public void user_enters_the_details_required_on_the_approval_page() throws Throwable {
		createobj.enterHomeOfficeComments();
		// createobj.enterApprovername();
		createobj.selectFAStatusvalue();
		createobj.selectStatusDate();
		createobj.selectFollowUpDate();
		Reporter.addScreenCapture();
	}

	@And("^User enters the details required for Followup Notes field on the Approval Page$")
	public void user_enters_the_details_required_for_followup_notes_field_on_the_approval_page() throws Throwable {
		createobj.enterFollowUpNotes();
	}

	@And("^User Clicks on the Next button in Approval page$")
	public void user_clicks_on_the_next_button_in_approval_page() throws Throwable {
		createobj.clickonnextbutoninapproverpage();
		Reporter.addScreenCapture();
	}

	@Then("^User can able to enter details in Follow Up text field in Approval page with (.+)$")
	public void user_can_able_to_enter_details_in_follow_up_text_field_in_approval_page(String followUp)
			throws Throwable {
		createobj.validateFollowUpField(followUp);
	}

	@And("^User verifies the entered details in approval page in Create FA$")
	public void user_verifies_the_entered_details_in_approval_page() throws Throwable {
		createobj.validateHomeOfficeComments();
	}

	@And("^User clicks on Previous button in approval page in Create FA$")
	public void user_clicks_on_previous_button_in_approval_page_in_create_fa() throws Throwable {
		createobj.clickonpreviousbuttoninapprovalpage();
		Reporter.addScreenCapture();
	}
}
