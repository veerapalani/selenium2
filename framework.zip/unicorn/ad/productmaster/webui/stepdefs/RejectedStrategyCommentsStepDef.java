package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStrategyCommentsPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class RejectedStrategyCommentsStepDef {

	RejectedStrategyCommentsPage commentsPage = new RejectedStrategyCommentsPage("AD_PM_RejectedStrategyCommentsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
	int rowIndex;
	//ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName, userInfo;
	String label, attributeValue, uiValue,dbValue = null;
	
	@And("^User is in Comments Page in Rejected Strategies Resubmission Flow$")
    public void user_is_in_comments_page_in_rejected_strategies_resubmission_flow() {
        Assert.assertTrue(commentsPage.isUserOnCommentsPage());
    }

    @And("^User clicks on Next in Comments Page in Rejected Strategies Resubmission Flow$")
    public void user_clicks_on_next_in_comments_page_in_rejected_strategies_resubmission_flow() {
        commentsPage.clickOnNext();
    }
    
    @And("^(.+) is in Comments Page in Rejected Strategies Resubmission Flow$")
    public void is_in_comments_page_in_rejected_strategies_resubmission_flow(String typeofuser) {
    	
    	Assert.assertTrue(commentsPage.isUserOnCommentsPage());
    	userInfo = typeofuser;
    }
    
    @And("^Data prepopulated in Comments page should match with DB Data in Rejected Strategy Resubmission flow for (.+)$")
    public void data_prepopulated_in_comments_page_should_match_with_db_data_in_rejected_strategy_resubmission_flow_for(String mandatorydetails) throws IOException {
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 45;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int dbDataRowIndex = rowIndex+1;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NICP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromCommentsPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
						if(!dbValue.equals(attributeValue)) {
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							Assert.fail(label);
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }

    private String getDataFromCommentsPage(String data) {
    	
	    	Action.pause(2000);
			ArrayList<ArrayList<String>> comments = new ArrayList<ArrayList<String>>();
			ArrayList<String> tempData = new ArrayList<String>();
			String requiredCommentValue = "";
	    	int comCount = commentsPage.getcountofComments();
	    	
	    	int j=0;
	    	for (int i = 0; i < comCount; i++) {
	    		
				comments.add(commentsPage.getithCommentInfo(i));
				
			}
	    	
	    	
	    	switch (data) {
			case "drp - Comment Type":
				j = 0;
		    	for (ArrayList<String> arrayList : comments) {
		    		requiredCommentValue = comments.get(j).get(0);
					tempData.add(requiredCommentValue);
					j++;
				}
		    	if(comments.size() > 1) {
					Collections.sort(tempData);
					requiredCommentValue = "";
					for (String G : tempData) {
						requiredCommentValue = requiredCommentValue+G+",";
					}
					requiredCommentValue = requiredCommentValue.substring(0, requiredCommentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredCommentValue;
				
				break;
			case "txt - Comment":
				j = 0;
		    	for (ArrayList<String> arrayList : comments) {
		    		requiredCommentValue = comments.get(j).get(1);
					tempData.add(requiredCommentValue);
					j++;
				}
		    	if(comments.size() > 1) {
					Collections.sort(tempData);
					requiredCommentValue = "";
					for (String G : tempData) {
						requiredCommentValue = requiredCommentValue+G+",";
					}
					requiredCommentValue = requiredCommentValue.substring(0, requiredCommentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredCommentValue;
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
	    	
	    	comments.clear();
		if(uiValue.equals("—") || uiValue.isEmpty())
			uiValue = "isEmpty";
	
		return uiValue;
		
	    	
	}

	@And("^User inputs the values from (.+) in Comments page in Rejected Strategy Resubmission Flow$")
    public void user_inputs_the_values_from_in_comments_page_in_rejected_strategy_resubmission_flow(String mandatorydetails) {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		int updateDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex+1;
		
		String commentType,comment,deleteComments = "";
		String tName = Thread.currentThread().getName();
		synchronized (tName) {

			deleteComments = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 44);
			commentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 45);
			comment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 46);

		}

		int commentsCount = commentsPage.getcountofComments();
		
		if(Integer.parseInt(deleteComments) > commentsCount) {
			Reporter.addStepLog("Document Count in UI is less than the count given in Excel -- Deleting all contacts");
			
			for (int i = 0; i < commentsCount; i++) {
				commentsPage.deleteComment();
				
			}
			
		}else {
			for (int i = 0; i < Integer.parseInt(deleteComments); i++) {
				commentsPage.deleteComment();
				
			}
		}
		
		if (commentType != "" && comment != "") {

			commentsPage.clickOnAddAnotherComment();
			if (commentType.contains(",") && comment.contains(",")) {
				String[] comType = commentType.split(",");
				String[] com = comment.split(",");

				int comTypeSize = comType.length;
				int comSize = com.length;
				int size = Math.min(comTypeSize, comSize);
				int i = 0;

				while (size > 0) {
					commentsPage.selectCommentsType(comType[i]);
					commentsPage.enterCommentsComment(com[i]);
					commentsPage.clickOnAddCommentsButton();
					size--;
					i++;
					if (size > 0) {
						commentsPage.clickOnAddAnotherComment();
					}
				}

			} else {

				commentsPage.selectCommentsType(commentType);
				commentsPage.enterCommentsComment(comment);
				commentsPage.clickOnAddCommentsButton();
			}

		}
		
		Reporter.addScreenCapture();
    }

    @And("^data from Comments page should be stored in Excel for (.+) in Rejected Strategy Resubmission Flow$")
    public void data_from_comments_page_should_be_stored_in_excel_for_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException {
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
//    	commentsPage.refreshThePage();
//    	Assert.assertTrue(commentsPage.isUserOnCommentsPage());
    	
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 45;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int flowPageDataRowIndex = rowIndex+3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIDP")) {
							columnIndex++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    			if(label == "")
			    				label = "isEmpty";
					}else {
							attributeValue = getDataFromCommentsPage(label);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
							columnIndex++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
							if(label == "")
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }
}
