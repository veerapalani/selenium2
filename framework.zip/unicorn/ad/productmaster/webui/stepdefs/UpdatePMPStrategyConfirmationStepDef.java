package qa.unicorn.ad.productmaster.webui.stepdefs;

public class UpdatePMPStrategyConfirmationStepDef {

}
