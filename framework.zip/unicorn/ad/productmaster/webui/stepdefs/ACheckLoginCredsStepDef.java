package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.ResultSet; 
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import cucumber.api.java.en.When;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.EISLBaseAPIGeneric;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;

@SuppressWarnings("deprecation")
public class ACheckLoginCredsStepDef {

	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String userName = "", pwd = "", url = "", type = "", status = "";
	
	WebDriver driver;
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	ProductMasterGeneric pmg = new ProductMasterGeneric();

	@When("^check credentials for login to PM for below environments$")
	public void cred_for_login_to_pm_for_envs(List<String> environments) throws SQLException, InterruptedException {

		

		for (String env : environments) {
			
			int count = 0;
			String sqlQuery = "", sqlQueryUpdate = "", sqlCount = "";

			/* fetching all users on the basis of environments mentioned in FF. */
			sqlQuery = "select * from pm_user_details where environment = '" + env.toUpperCase() + "'";
			sqlCount = "select count(*) as count from pm_user_details where environment = '" + env.toUpperCase() + "'";
			

			pmdb.fwDBConnect();
			ResultSet rs = pmdb.fwSelect(sqlQuery);
			ResultSet rsCount = pmdb.fwSelect(sqlCount);
			while(rsCount.next()) {
				count = rsCount.getInt("count");
			}
			

			Reporter.addStepLog("<b>FOR " + env.toUpperCase() + ": </b>");

			/* Printing table headers in reports. */
			ebag.SetAndPrintTableHeaders("UserName|Type|Status");
			try {
				while (rs.next()) {

					driver = WebDriverManager.getDriver();

					driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);

					userName = rs.getString("user_id");
					pwd = rs.getString("password");
					url = rs.getString("url");
					type = rs.getString("type");

					DateTimeFormatter dtf = DateTimeFormatter.ofPattern("uuuu/MM/dd HH:mm");
					String executionStart = dtf.format(LocalDateTime.now());

					driver.get(url);

					/* input values of userName, pwd and click on login button */
					driver.findElement(By.xpath("//input[@name = \"USER\"]")).sendKeys(userName);
					driver.findElement(By.xpath("//input[@name = \"PASSWORD\"]")).sendKeys(pwd);

					driver.findElement(By.xpath("//input[@name = \"loginButton\"]")).click();

					/*
					 * User clicked on login button, now user is on a page where we can identify if
					 * credentials are correct or need to change pwd or account is locked. if, title
					 * = Product Master, means credentials are working. | else if screen shows
					 * elements to change pwd, script will generate a pwd and update it in IDM and
					 * DB. | else if screen shows message for limit exceeded, script will update
					 * flag in DB. | else PW not matching, need to check manually.
					 */

					boolean pwdChange = false;
					boolean locked = false;
					try {
						pwdChange = driver.findElement(By.xpath("//table[@id=\"im-validation-errors\"]")).isDisplayed();
					} catch (Exception e) {
						// Nothing to do
					}

					String expMessage = "You cannot access your account because you have exceeded the limit of login attempts.";

					try {
						locked = driver.findElement(By.xpath("//td[contains(text(),\"" + expMessage + "\")]"))
								.isDisplayed();
					} catch (Exception e) {
						// Nothing to do
					}

					String title = driver.getTitle();

					if (pwdChange == true) {

						String newPwd = updatePassword(driver);
						if (!newPwd.equalsIgnoreCase("false")) {
							status = "NOT USED";
							String sql = "UPDATE pm_user_details set password = '" + newPwd + "' WHERE environment = '"
									+ env.toUpperCase() + "'" + " AND user_id = '" + userName + "'";

							pmdb.fwExecuteQuery(sql);
							ebag.SetAndPrintTableRows(userName + "|" + type + "|<p>PWD UPDATED; ACTIVE</p>");

						} else {
							status = "RQ PWD UPDATE";
							ebag.SetAndPrintTableRows(
									userName + "|" + type + "|<p style=\"color:red\">RQ PWD UPDATE</p>");
						}

					} else if (locked == true) {
						status = "LOCKED";
						ebag.SetAndPrintTableRows(userName + "|" + type + "|<p style=\"color:red\">LOCKED</p>");
					} else if (title.toLowerCase().contains("product")) {
						status = "NOT USED";
						ebag.SetAndPrintTableRows(userName + "|" + type + "|<p>ACTIVE</p>");
					} else {
						status = "PWD NOT MTCHNG";
						ebag.SetAndPrintTableRows(userName + "|" + type + "|<p style=\"color:red\">PWD NOT MTCHNG</p>");
					}

					sqlQueryUpdate = "UPDATE pm_user_details set flag = '" + status + "', execution_start = '"
							+ executionStart + "', execution_end = null,"
							+ " executed_by = 'PW CHCK SCRIPT' WHERE environment = '" + env.toUpperCase()
							+ "' AND user_id = '" + userName + "'";

					pmdb.fwExecuteQuery(sqlQueryUpdate);

					/*
					 * deleteAllCookies() is not working for Dev and UAT Environment Hence, closing the
					 * browser and re-initializing it for next iteration.
					 * 
					 */
					
						driver.close();

						WebDriverManager.configureDriver();
						WebDriverManager.startDriver();
					

				}
			} catch (Exception e) {
				/*
				 * if encounter any issue in above script, we need to close table and disconnect
				 * DB.
				 */
				ebag.SetAndPrintTableFooter();
				pmdb.fwDBDisconnect();
			}

			ebag.SetAndPrintTableFooter();
			pmdb.fwDBDisconnect();

		}
	}

	public String updatePassword(WebDriver driver) throws InterruptedException {
		/* Generating password with UpperCase, LowerCase and Numeric */
		String newPwd = pmg.randomStringAlphaNumeric(4).toUpperCase() + pmg.randomStringAlphaNumeric(2).toLowerCase()
				+ "13";

		/* New Password Text Box */
		driver.findElement(By.xpath("*//input[@title='New Password']")).sendKeys(newPwd);

		/* Confirm Password Text Box */
		driver.findElement(By.xpath("*//input[@title='Confirm Password']")).sendKeys(newPwd);

		/* Submit Button */
		driver.findElement(By.xpath("*//button[contains(text(),'Submit')]")).click();

		Thread.sleep(5000);
		driver.getTitle();
		try {
			boolean flag = driver.findElement(By.xpath("*//td[contains(text(),'Task completed')]")).isDisplayed();
			return newPwd;
		} catch (Exception e) {
			return "false";
		}

	}
}
