package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.MutualFundsSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class MutualFundsSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	MutualFundsSortAndFilterPage mutualFundsSortAndFilterPage = new MutualFundsSortAndFilterPage(
			"AD_PM_MutualFundsSortAndFilterPage");
	MutualFundsSortAndFilterPage mutualFundsSortAndFilterPage2 = new MutualFundsSortAndFilterPage(
			"AD_PM_BenchmarkSortAndFilterPage");
	PMPageGeneric pmPageGeneric = new PMPageGeneric("AD_PM_MutualFundsSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/MutualFundSortAndFilter.xlsx";
	String sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	WebElement myElement;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_MutualFundsSortAndFilterPage"));

	@When("^User enter valid (.+) in global search box for MF$")
	public void user_enter_valid_in_global_search_box_for_mf(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String MFSearchValue = (String) exlObj.getCellData(sheet, rowIndex, 1);

		exlObj.closeWorkBook();
		if (MFSearchValue != "") {
			mutualFundsSortAndFilterPage.searchMFValue(MFSearchValue);
		}
		Reporter.addScreenCapture();
	}

	@And("^user clicks on \"([^\"]*)\" on landing page for MF$")
	public void user_clicks_on_something_on_landing_page_for_mf(String strArg1) throws Throwable {
		mutualFundsSortAndFilterPage.clickOnSeeAllResultsForMFLayout();
		Reporter.addScreenCapture();
	}

	@And("^user is able to see search results in \"([^\"]*)\" tab under MF accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_mf_accordion(String strArg1)
			throws Throwable {
		mutualFundsSortAndFilterPage.verifyTheSearchedResultInAllTabMF();
		Reporter.addScreenCapture();
	}

	@And("^user click on \"([^\"]*)\" tab on landing page$")
	public void user_click_on_something_tab_on_landing_page(String strArg1) throws Throwable {
		mutualFundsSortAndFilterPage.verifyMutualFundTab();
		Reporter.addScreenCapture();
	}

	@And("^User able to see grid view of all records as per search$")
	public void user_able_to_see_grid_view_of_all_records_as_per_search() throws Throwable {
		mutualFundsSortAndFilterPage.verifySearchedGridViewDisplay();
		Reporter.addScreenCapture();
	}

	@And("^User able to see tab count as per searched keyword$")
	public void user_able_to_see_tab_count_as_per_searched_keyword() throws Throwable {
		String beforeApplyFilterValue = mutualFundsSortAndFilterPage
				.verifyTheMFGridCountAfterApplyFilterConditionOnTab();
		// String beforeApplyFilterValue =
		// MutualFundsSortAndFilterPage.tabCountAfterCondition;
		beforeCountTabValue = beforeApplyFilterValue.substring(13, 14);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage.mouseHoverOnMFGridViewLabels(mutualFundsSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			mutualFundsSortAndFilterPage.verifyMFGridViewLabelsWithSortIcons(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement(
					"//span[contains(text(),'" + entity.get(i) + "')]//parent::div//parent::div//brml-action-icon)[1]");
			mutualFundsSortAndFilterPage.verifyMFGridViewLabelsWithFilterIcons(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column$")
	public void user_able_to_click_on_the_sort_icon_for_below_column(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage.mouseHoverOnMFGridViewLabels(mutualFundsSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			mutualFundsSortAndFilterPage.clickOnFundNameSortIcon(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order$")
	public void user_should_able_to_sort_the_records_with_asc_order() throws Throwable {
		String value = mutualFundsSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = MutualFundsSortAndFilterPage.ascSortValue;
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User should able to validate the filter condition all options for MF$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_mf(List<String> entity)
			throws Throwable {
		mutualFundsSortAndFilterPage.clickOnFilterSelection();
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage
					.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage
					.verifyValueOfFilterCondition(mutualFundsSortAndFilterPage.findElementByDynamicXpath(
							"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to click on the Asc Sort icon for below Column$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage.mouseHoverOnMFGridViewLabels(mutualFundsSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			mutualFundsSortAndFilterPage.clickOnFundNameSortIcon(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order$")
	public void user_should_able_to_sort_the_records_with_desc_order() throws Throwable {
		String value = mutualFundsSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = MutualFundsSortAndFilterPage.descSortValue;
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage.mouseHoverOnMFGridViewLabels(mutualFundsSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			mutualFundsSortAndFilterPage.clickOnFundNameSortIcon(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order$")
	public void user_should_able_to_sort_the_records_with_default_order() throws Throwable {
		String value = mutualFundsSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = MutualFundsSortAndFilterPage.defaultSortValue;
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to click on the filter icon for below column$")
	public void user_able_to_click_on_the_filter_icon_for_below_column(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement(
					"//span[contains(text(),'" + entity.get(i) + "')]//parent::div//parent::div//brml-action-icon)[1]");
			mutualFundsSortAndFilterPage.clickOnFilterIconForMFGridView(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to select the (.+) from filter condition$")
	public void user_able_to_select_the_from_filter_condition(String FilterCondition) throws Throwable {
		mutualFundsSortAndFilterPage.clickOnFilterSelection();
		mutualFundsSortAndFilterPage
				.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + FilterCondition + "']");
		mutualFundsSortAndFilterPage
				.clickOnFilterConditionForMFGridView(mutualFundsSortAndFilterPage.findElementByDynamicXpath(
						"//div[@class='options-list-wrapper']//ul//li[text()='" + FilterCondition + "']"));
		Reporter.addScreenCapture();

	}

	@And("^User able to enter the filter condition (.+) in input field$")
	public void user_able_to_enter_the_filter_condition_in_input_filed(String FilterConditionValue) throws Throwable {
		mutualFundsSortAndFilterPage.enterFilterValue(FilterConditionValue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button$")
	public void user_able_to_click_on_the_apply_button() throws Throwable {
		mutualFundsSortAndFilterPage.clickOnApplyFilterIconForMFGridView();
		mutualFundsSortAndFilterPage.verifyFilteredGridDataViewDisplay();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on MF grid view$")
	public void user_should_able_to_verify_the_grid_count_on_mf_grid_view() throws Throwable {

		String presentGridData = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		String countTabAfterFilter = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// MutualFundsSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		// action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10) {
			for (int i = 0; i <= tabCountAfterFilterCondition/10; i++) {
				action.waitForDomToComplete(WebDriverManager.getDriver());
				mutualFundsSortAndFilterPage
						.waitForWebElement("//div[@class='ag-center-cols-container']/div[@role='row']["
								+ String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				myElement = mutualFundsSortAndFilterPage
						.findElementByDynamicXpath("//div[@class='ag-center-cols-container']/div[@role='row']["
								+ String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				// action.moveToElement(myElement);
				action.scrollToElement(myElement);
				action.pause(2000);
				String presentGridAllData = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			mutualFundsSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The grid view and tab count mismatch");}
	}

	@And("^User should able to verify the Tab count on MF grid view$")
	public void user_should_able_to_verify_the_tab_count_on_mf_grid_view() throws Throwable {

		String presentGridData = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		String countTabAfterFilter = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// MutualFundsSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10) {
			for (int i = 0; i <= beforeApplyFiltertabCountValue; i++) {
				action.scrollToBottom();
				Action.pause(1000);
				String presentGridAllData = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			mutualFundsSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The tab count and grid count mismatch");
	}

	@And("^User able to click on the Reset Button$")
	public void user_able_to_click_on_the_reset_button() throws Throwable {
		mutualFundsSortAndFilterPage.clickOnApplyFilterIconForMFGridViewForReset();
		mutualFundsSortAndFilterPage.verifyFilteredGridDataViewDisplay();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button$")
	public void user_able_to_click_on_the_cancel_button() throws Throwable {
		mutualFundsSortAndFilterPage.clickOnApplyFilterIconForMFGridViewForCancel();
		mutualFundsSortAndFilterPage.verifyFilteredGridDataViewDisplay();
		Reporter.addScreenCapture();
	}

	@Then("^user validates the MF Print functionality for (.+)$")
	public void user_validates_the_mf_print_functionality_for(String entityName) throws Throwable {
		PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, 0,
				mutualFundsSortAndFilterPage2.getTextforBenchmarkDescription());
		int i = 2;
		while (i <= 7) {
			PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, i - 1,
					mutualFundsSortAndFilterPage2.getTextfromGridforRow(String.valueOf(i)));
			i++;
		}
		mutualFundsSortAndFilterPage2.clickOnBenchmarkPrint();
		pmPageGeneric.verifyPrintFunctionalityForFirstEntity(excelFilePath, entityName);
	}
}
