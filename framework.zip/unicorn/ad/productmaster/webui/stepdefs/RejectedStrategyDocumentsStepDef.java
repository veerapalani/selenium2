package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import net.bytebuddy.asm.Advice.Enter;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStrategyDocumentsPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class RejectedStrategyDocumentsStepDef {

	RejectedStrategyDocumentsPage documentsPage = new RejectedStrategyDocumentsPage("AD_PM_RejectedStrategyDocumentsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
	int rowIndex;
	//ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName, userInfo;
	String label, attributeValue, uiValue,dbValue = null;
	
	@And("^User is in Documents Page in Rejected Strategies Resubmission Flow$")
    public void user_is_in_documents_page_in_rejected_strategies_resubmission_flow() {
        Assert.assertTrue(documentsPage.isUserOnDocumentsPage());
    }

    @And("^User clicks on Next in Documents Page in Rejected Strategies Resubmission Flow$")
    public void user_clicks_on_next_in_documents_page_in_rejected_strategies_resubmission_flow() {
        documentsPage.clickOnNext();
    }
    
    @And("^(.+) is in Documents Page in Rejected Strategies Resubmission Flow$")
    public void is_in_documents_page_in_rejected_strategies_resubmission_flow(String typeofuser) {
    	
    	Assert.assertTrue(documentsPage.isUserOnDocumentsPage());
    	userInfo = typeofuser;
        
    }
    
    @And("^Data prepopulated in Documents page should match with DB Data in Rejected Strategy Resubmission flow for (.+)$")
    public void data_prepopulated_in_documents_page_should_match_with_db_data_in_rejected_strategy_resubmission_flow_for(String mandatorydetails) throws IOException {
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
    			if(mandatorydetails.contains("Test"))
    				sheetName = "Test";
    				
    			   //sheet = exlObj.getSheet(sheetName);
    			   //count = 0;
    			   int columnIndex = 41;
    			   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    			   int dbDataRowIndex = rowIndex+1;
    			   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    					   //(String) exlObj.getCellData(sheet, rownum, 0);
    			   
    			   if(label == "" || label.contains("Delete Comments_ignore"))
    					label = "isEmpty";
    				while (label != "isEmpty") {
    														
    						if(label.contains("ignore") || label.contains("NIDP")) {
    							columnIndex++;
    							
    				    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    				    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
    				    			
    				    			if(label == "" || label.contains("Delete Comments_ignore"))
    				    				label = "isEmpty";
    						}else {
    							
    							attributeValue = getDataFromDocumentsPage(label);
    							dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
    							if(!dbValue.equalsIgnoreCase(attributeValue)) {
    							
    								Reporter.addEntireScreenCaptured();
    								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
    								Assert.fail(label);
    								
    							}
    							columnIndex++;
    								
    								label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    										//(String) exlObj.getCellData(sheet, rownum, 0).toString();
    								
    								if(label == "" || label.contains("Delete Comments_ignore"))
    									label = "isEmpty";
    						
    						}
    				}
//    				if(count > 0) {
//    					Assert.fail("Prepopulated Values are not same as values stored in DB");
//    				}
    				//Reporter.addCompleteScreenCapture();
    				//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }

    private String getDataFromDocumentsPage(String data) {
    	uiValue = "";
	    	Action.pause(2000);
			ArrayList<ArrayList<String>> documents = new ArrayList<ArrayList<String>>();
			ArrayList<String> tempData = new ArrayList<String>();
			String requiredDocumentValue = "";
	    	int docCount = documentsPage.getcountofDocuments();
	    	for (int i = 0; i < docCount; i++) {
	    		
				documents.add(documentsPage.getithDocumentInfo(i));
				
			}
	    	
	    	
	    	switch (data) {
			case "drp - Document Type":
				//j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = arrayList.get(0);
					tempData.add(requiredDocumentValue);
					//j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			case "txt - Document Link":
				//j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = arrayList.get(1);
					tempData.add(requiredDocumentValue);
					//j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			case "txt - Document Comment":
				//j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = arrayList.get(2);
					tempData.add(requiredDocumentValue);
					//j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
	    	
	    	documents.clear();
		if(uiValue.equals("—") || uiValue == "")
			uiValue = "isEmpty";
		
		return uiValue;
	    	
	}

	@And("^User inputs the values from (.+) in Documents page in Rejected Strategy Resubmission Flow$")
    public void user_inputs_the_values_from_in_documents_page_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();

		String tName = Thread.currentThread().getName();
		String documentType,documentLink,documentComment,deleteDocuments = "";
		
		documentLink = RandomStringUtils.randomAlphanumeric(10);
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			deleteDocuments = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 40);
			documentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 41);
			//documentLink = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 27);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 42, documentLink);
			documentComment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 43);
			
		}
		
		int documentsCount = documentsPage.getcountofDocuments();
		
		if(Integer.parseInt(deleteDocuments) > documentsCount) {
			Reporter.addStepLog("Document Count in UI is less than the count given in Excel -- Deleting all contacts");
			
			for (int i = 0; i < documentsCount; i++) {
				documentsPage.deleteDocument();
				
			}
			
		}else {
			for (int i = 0; i < Integer.parseInt(deleteDocuments); i++) {
				documentsPage.deleteDocument();
				
			}
		}
		
		if(documentType != "" && documentLink != "" && documentComment != "") {
			documentsPage.clickOnAddAnotherDocument();
			if(documentType.contains(",") && documentLink.contains(",") && documentComment.contains(",")) {
				String[] docType = documentType.split(",");
				String[] docLink = documentLink.split(",");
				String[] docComment = documentComment.split(",");
				
				int docTypeSize = docType.length;
				int docLinkSize = docLink.length;
				int docCommentSize = docComment.length;
				int size = Math.min(docCommentSize, docLinkSize);
				size = Math.min(size, docTypeSize);
				int i =0;
				
					while(size > 0) {
						documentsPage.selectDocumentType(docType[i]);
						documentsPage.enterDocumentLink(docLink[i]);
						documentsPage.enterDocumentComment(docComment[i]);
						documentsPage.clickOnAddDocumentLinkButton();
						size--;
						i++;
						if(size > 0) {
						documentsPage.clickOnAddAnotherDocument();
						}
					}
				
		        
			}
			else {
			
				documentsPage.selectDocumentType(documentType);
				documentsPage.enterDocumentLink(documentLink);
				documentsPage.enterDocumentComment(documentComment);
				documentsPage.clickOnAddDocumentLinkButton();
			}
			
		
		}
    }

    @And("^data from Documents page should be stored in Excel for (.+) in Rejected Strategy Resubmission Flow$")
    public void data_from_documents_page_should_be_stored_in_excel_for_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException {
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
//    	documentsPage.refreshThePage();
//    	Assert.assertTrue(documentsPage.isUserOnDocumentsPage());
    	
    			if(mandatorydetails.contains("Test"))
    				sheetName = "Test";
    				
    			   //sheet = exlObj.getSheet(sheetName);
    			   //count = 0;
    			   int columnIndex = 41;
    			   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    			   int flowPageDataRowIndex = rowIndex+3;
    			   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    			   
    			   if(label == "" || label.contains("Delete Comments_ignore"))
    					label = "isEmpty";
    			   System.out.println("In Documents PAGE ????????????????");
    				while (label != "isEmpty") {
    														
    						if(label.contains("ignore") || label.contains("NIDP")) {
    								columnIndex++;
    				    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    				    			if(label == "" || label.contains("Delete Comments_ignore"))
    				    				label = "isEmpty";
    						}else {
    								attributeValue = getDataFromDocumentsPage(label);
    								System.out.println("Doc Value :"+attributeValue);
    								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
    								columnIndex++;
    								label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
    								if(label == "" || label.contains("Delete Comments_ignore"))
    									label = "isEmpty";
    						
    						}
    				}
//    				if(count > 0) {
//    					Assert.fail("Prepopulated Values are not same as values stored in DB");
//    				}
    				//Reporter.addCompleteScreenCapture();
    				//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }
    
    @And("^User clicks on Previous Button in Documents page in Rejected Strategy Resubmission Flow$")
    public void user_clicks_on_previous_button_in_documents_page_in_rejected_strategy_resubmission_flow() {
    	documentsPage.clickOnPrevious();
    }
}
