package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStartegyReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class RejectedStartegyReviewStepDef {

	RejectedStartegyReviewPage reviewPage = new RejectedStartegyReviewPage("AD_PM_RejectedStartegyReviewPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
	
	//ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	int rowIndex;
	String sheetName, userInfo;
	String label, attributeValue, uiValue,dbValue = null;
	
	//public static int count;
	
	@And("^User is in Review Page in Rejected Strategies Resubmission Flow$")
    public void user_is_in_review_page_in_rejected_strategies_resubmission_flow() {
        Assert.assertTrue(reviewPage.isUserOnReviewPage());
    }
	
	@And("^(.+) is in Review Page in Rejected Strategies Resubmission Flow$")
    public void is_in_review_page_in_rejected_strategies_resubmission_flow(String typeofuser) {
		
		Assert.assertTrue(reviewPage.isUserOnReviewPage());
		userInfo = typeofuser;
    }

    @And("^Stored Values in DB should be prepopulated in Review Page in Rejected Strategies Resubmission Flow$")
    public void stored_values_in_db_should_be_prepopulated_in_review_page_in_rejected_strategies_resubmission_flow() throws IOException {
    	sheetName = "Conversion_Validation";
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int rownum = 1;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")  || (label.contains("NIESDP"))) {
							rownum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromReviewPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 3);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							//exlObj.setCellData(sheet, rownum, 6, attributeValue);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 6, attributeValue);
						}else {
							//exlObj.setCellData(sheet, rownum, 6, attributeValue+" -UI Value is not same as Stored Value in DB");
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 6, attributeValue+" -UI Value is not same as Stored Value in DB");
							
							Reporter.addCompleteScreenCapture();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							//count++;
							
						}
							rownum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
//			
//			if(RejectedStrategyViewStepDef.count+RejectedStrategyEnterStrategyDetailsStepDef.count+RejectedStrategyBenchmarkStepDef.count+count > 0) {
//				if(RejectedStrategyViewStepDef.count>0) {
//					Reporter.addStepLog("In View Page Values Stored in DB differ from Values Populated in UI");
//				}
//				if(RejectedStrategyEnterStrategyDetailsStepDef.count>0) {
//					Reporter.addStepLog("In Enter Startegy Details Page Values Stored in DB differ from Values Populated in UI");
//				}
//				if(RejectedStrategyBenchmarkStepDef.count>0) {
//					Reporter.addStepLog("In Benchmark Page Values Stored in DB differ from Values Populated in UI");
//				}
//				if(count>0) {
//					Reporter.addStepLog("In Review & Attestation Page Values Stored in DB differ from Values Populated in UI");
//				}
//				
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
//			
			Reporter.addEntireScreenCaptured();
			//Reporter.addStepLog("In Review & Attestation Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
    }

	private String getDataFromReviewPage(String data) {
			switch (data) {
			case "Risk Category":
				
				uiValue = reviewPage.getRiskCategoryValue();
				
				break;
			case "PIV Style":
				
				uiValue = reviewPage.getPIVStyleValue();
				
				break;
			case "Geographic Indicator":
				
				uiValue = reviewPage.getGeographicIndicatorValue();
				
				break;
			case "Strategy Name":
				
				uiValue = reviewPage.getStrategyNameValue();
				
				break;
			case "Strategy Code":
				
				uiValue = reviewPage.getStrategyCodeValue();
				
				break;
			case "Balanced Allocation":
				
				uiValue = reviewPage.getBalancedAllocationValue();
				
				break;
			case "Concentrated Strategy Indicator_radiobutton":
				
				uiValue = reviewPage.getConcentratedStrategyIndicatorValue();
				
				break;
			case "Structured Products Strategy_radiobutton":
				
				uiValue = reviewPage.getStructuredProductsStrategyValue();
				
				break;
			case "Margins":
				
				uiValue = reviewPage.getMarginsValue();
				
				break;
			case "Status":
				
				uiValue = reviewPage.getStrategyStatusValue();
				
				break;
			case "Concord Eligible(NEW)":
				
				//uiValue = reviewPage.getConcordEligibleValue();
				
				break;
			case "Options Approval Level Code":
				
				//uiValue = reviewPage.getOptionalApprovalLevelCodeValues();
				
				break;
			case "Hedge Core Indicator_radiobutton":
				
				uiValue = reviewPage.getHedgeCoreIndicatorValue();
				
				break;
			case "Style Pairing Code":
				
				uiValue = reviewPage.getStylePairingCodeValue();
				
				break;
			case "Risk Tolerance":
				
				//uiValue = reviewPage.getRiskToleranceValue();
				
				break;
			case "Portfolio Strategy Group Code":
				
				//uiValue = reviewPage.getPortfolioStrategyGroupCodeValue();
				
				break;
			case "Investment Style":
				
				uiValue = reviewPage.getInvestmentStyleValue();
				
				break;
			case "Primary Benchmark":
				
				uiValue = reviewPage.getPrimaryBenchmarkValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
	}
	
	@And("^with Strategy ID from UI store the data related to Rejected Strategy from review page in Excel for (.+) in Rejected Strategy Resubmission Flow$")
    public void with_strategy_id_from_ui_store_the_data_related_to_rejected_strategy_from_review_page_in_excel_for_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
        
        rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        
    	int reviewPageDataRowIndex = rowIndex+4;
    	String managerCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex+1, 45);
		getDataFromreviewPageandStoreInExcel(managerCode, reviewPageDataRowIndex);
    }

	private void getDataFromreviewPageandStoreInExcel(String managerCode, int reviewPageDataRowIndex) throws IOException {
		sheetName = "Test";
		   
		   int columNum = 3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
		   
		   //Boolean bool = reviewPage.areContactsDisplayed();
		   //Boolean bool2 = reviewPage.isDocumentHeaderDisplayed();
		  
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
							
				if(label.contains("checkbox - Hide Strategy"))
				{
					if(userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
						label = "ignore";
					}
				}
				if(label.contains("FA Email"))
				{
						label = "ignore";
				}
				
					if(label.contains("ignore") || label.contains("NIESP")) {
						columNum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						 
						
							attributeValue = getDataFromReViewPage(label);
						
						if(label.split(" - ")[0].equals("radiobutton"))
						{
							switch (attributeValue.toLowerCase().trim()) {
							case "yes":
								attributeValue = "t";
								break;
							case "no":
								attributeValue = "f";
								break;
							default:
								break;
							}
						}
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex-1, columNum);
						
								
						if(label.contains("Document")) {
							if(dbValue.equalsIgnoreCase(attributeValue)) {
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue);
							}else if (label.contains("Link")) {
								//This else if is written to handle a scenario where Sort performed in Documents page for uppercase characters differ from sort performed in 
								//mixed upper and lower case characters stored in DB
								int countOfDocuments = reviewPage.getCountOfDocuments();
								ArrayList<String> linkdBData = new ArrayList<String>();
								ArrayList<String> linkattributeData = new ArrayList<String>();
								for (int i = 0; i < countOfDocuments; i++) {
									linkdBData.add(dbValue.split(",")[i].toUpperCase());
									linkattributeData.add(attributeValue.split(",")[i].toUpperCase());
								}
								Collections.sort(linkdBData);
								Collections.sort(linkattributeData);
								if(linkdBData.equals(linkattributeData)) {
									PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue);
								}
							}else {
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue+" -Review Page Value is not same as Flow Page Value in UI");
								Reporter.addEntireScreenCaptured();
								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Value Displayed in Flow Pages");
							}
						}else if(dbValue.equals(attributeValue)) {
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue);
						}else {
							
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue+" -Review Page Value is not same as Flow Page Value in UI");
								Reporter.addEntireScreenCaptured();
								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Value Displayed in Flow Pages");
							
						}
						
						columNum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
							if(label == "")
								label = "isEmpty";
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
	}

	private String getDataFromReViewPage(String data) {
			switch (data) {
			case "txt - Strategy Name":
				
				uiValue = reviewPage.getStrategyNameValue();
				
				break;
			case "drp - Investment Style":
				
				uiValue = reviewPage.getInvestmentStyleValue();
				
				break;
			case "drp - FA Name":
				
				uiValue = reviewPage.getFANameValue();
				
				break;
			case "drp - FA Team Name":
				
				uiValue = reviewPage.getFATeamNameValue();
				
				break;
			case "ne - FA Team Members Detail":
				
				uiValue = reviewPage.getFATeamMemberDetailValue();
				
				break;
			case "drp - Status":
				
				uiValue = reviewPage.getStrategyStatusValue();
				
				break;
			case "drp - PMP Title":
				
				uiValue = reviewPage.getPMPTitleValue();
				
				break;
			case "drp - Strategy Tier":
				
				uiValue = reviewPage.getStrategyTierValue();
				
				break;
			case "grey - Market Cap":
				
				uiValue = reviewPage.getMarketCapValue();
				
				break;
			case "grey - Risk Category":
				
				uiValue = reviewPage.getRiskCategoryValue();
				
				break;
			case "grey - Fee Schedule Type":
				
				uiValue = reviewPage.getFeeScheduleTypeValue();
				
				break;
			case "grey - PIV Style":
				
				uiValue = reviewPage.getPIVStyleValue();
				
				break;
			case "grey - Geographic Indicator":
				
				uiValue = reviewPage.getGeographicIndicatorValue();
				
				break;
			case "grey - Balanced Allocation":
				
				uiValue = reviewPage.getBalancedAllocationValue();
				
				break;
			case "grey - Investment Style Category":
				
				uiValue = reviewPage.getInvestmentStyleCategoryValue();
				
				break;
			case "grey - Comparative Universe":
				
				uiValue = reviewPage.getComparativeUniverseValue();
				
				break;
			case "grey - Bunded Node ID":
				
				uiValue = reviewPage.getBundledNodeIDValue();
				
				break;
			case "grey - Unbundled Node ID":
				
				uiValue = reviewPage.getUnbundledNodeIDValue();
				
				break;
			case "grey - Style Pairing Code":
				
				uiValue = reviewPage.getStylePairingCodeValue();
				
				break;
			case "radiobutton - Concentrated Strategy Indicator":
				
				uiValue = reviewPage.getConcentratedStrategyIndicatorValue();
				
				break;
			case "radiobutton - Structured Products Strategy":
				
				uiValue = reviewPage.getStructuredProductsStrategyValue();
				
				break;
			case "radiobutton - Hedge Core Indicator":
				
				uiValue = reviewPage.getHedgeCoreIndicatorValue();
				
				break;
			case "radiobutton - Short Term Maturity":
				
				uiValue = reviewPage.getShortTermMaturityValue();
				
				break;
			case "radiobutton - Alternatives Strategy":
				
				uiValue = reviewPage.getAlternativesStrategyValue();
				
				break;
			case "radiobutton - Sustainable Investment Strategy":
				
				uiValue = reviewPage.getSustainableInvestmentStrategyValue();
				
				break;
			case "grey - FOA Code":
				
				uiValue = reviewPage.getStrategyCodeValue();
				
				break;
			case "grey - Single Strategy Only":
				
				uiValue = reviewPage.getSingleStrategyOnlyValue();
				
				break;
			case "checkbox - Margin Eligible":
				
				uiValue = reviewPage.getMarginsValue();
				
				break;
			case "txt - FA Email":
				
				uiValue = reviewPage.getFAEmailValue();
				
				break;
			case "txt - Non PMP Approved Team Member Email":
				
				uiValue = reviewPage.getNonPMPApprovedTeamMemberEmailValue();
				
				break;
			case "drp - DVP/Key Trust Template":
				
				uiValue = reviewPage.getDVPTemplateValue();
				
				break;
			case "checkbox - Hide Strategy":
						
				uiValue = reviewPage.getHideStrategyValue();
						
				break;
			case "NIESP - PMP Submission Date":
				
				uiValue = reviewPage.getNonPMPSubmissionDateValue();
				
				break;
			case "radiobutton - BenchmarkCategory":
				
				uiValue = reviewPage.getBenchmarkCategoryValue();
				
				break;
			case "drp - Benchmark Name":
				
				uiValue = reviewPage.getBenchmarkNameValue();
				
				break;
			case "txt - Percentage":
				
				uiValue = reviewPage.getPercentageValue();
				
				break;
			case "txt - Custom Benchmark Reason":
				
				uiValue = reviewPage.getCustomBenchmarkReasonValue();
				
				break;
			case "drp - Document Type":
				
				uiValue = reviewPage.getDocumentTypeValue();
				
				break;
			case "txt - Document Link":
				
				uiValue = reviewPage.getDocumentLinkValue();
				
				break;
			case "txt - Document Comment":
				
				uiValue = reviewPage.getDocumentCommentValue();
				
				break;
			case "drp - Comment Type":
				
				uiValue = reviewPage.getCommentTypeValue();
				
				break;
			case "txt - Comment":
				
				uiValue = reviewPage.getCommentCommentValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—") || uiValue.isEmpty())
			uiValue = "isEmpty";
	
		return uiValue;
	
	}
	
	@And("^User clicks on Submit in Review Page in Rejected Stratgey Rsubmission Flow$")
    public void user_clicks_on_submit_in_review_page_in_rejected_stratgey_rsubmission_flow() {
        reviewPage.clickOnSubmit();
    }
	
	@Then("^User should be able to see benchmarks sorted in descending order in Review Page in Rejected Strategy Resubmission Flow for (.+)$")
    public void user_should_be_able_to_see_benchmarks_sorted_in_descending_order_in_review_page_in_rejected_strategy_resubmission_flow_for(String mandatorydetails) {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String benchmarkCategory,benchmark,benchmarkPercentage,customBenchmarkReason = "";
		String locatorValueCustomBenchmark,locatorValueCustomBenchmarkHighlight,locatorValueCustomBenchmarkPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 37);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 38);
			
		}
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			benchmarkfromUI = reviewPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = reviewPage.getPercentageithValuefromUI(j);
			
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey.split(" - ")[1].trim()));
			j++;
			
		}
		
    }

    private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
    	
    	Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

				//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().split(" - ")[1].trim().compareTo(o2.getKey().split(" - ")[1].trim()));
				
				//sort based on benchmark percentage
				Collections.sort(entryList, (o1, o2) -> {
					if(o1.getValue() > o2.getValue()) {
						return -1;
					}else if(o1.getValue() < o2.getValue()) {
						return 1;
					}
					return 0;
				});
				
				/*
				 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
					@Override
					public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
						if(o1.getValue() > o2.getValue()) {
							return -1;
						}else if(o1.getValue() < o2.getValue()) {
							return 1;
						}
						return 0;
					}
				});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		 * for (String countryKey : sortedHashMap.keySet()) {
		 * System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		 * 
		 * }
		 */
		return sortedHashMap;
	}
    
	
}
