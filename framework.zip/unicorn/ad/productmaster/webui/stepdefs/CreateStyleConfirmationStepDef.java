package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateStyleConfirmationStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	Alert alert;
	Process p = null;
	String kafkaPath = "C://PM_SANITYTEST//kafka_2.13-3.2.1//bin//windows";
	String testmucNHLogFilePath, testmucDHLogFilePath = "";
	String styleId = null;
	String styleName="";

	CreateStyleConfirmationPage createstylecon = new CreateStyleConfirmationPage("AD_PM_CreateStyleConfirmationPage");

	@Then("^User should be able to see the Confirmation Header on Create New Style Confirmation page$")
	public void user_should_be_able_to_see_the_confirmation_header_on_create_new_style_confirmation_page()
			throws Throwable {
		createstylecon.verifyconfirmationheaderinCreateStyleConfPage();
	}

	@Then("^User should be able to see the \"([^\"]*)\" on Create New Style Confirmation page$")
	public void user_should_be_able_to_see_the_something_on_create_new_style_confirmation_page(String Key)
			throws Throwable {
		createstylecon.verifyElementssinCreateStylePage(Key);
	}

	@And("^User clicks on \"([^\"]*)\" on Create New Style Confirmation Page$")
	public void user_clicks_on_something_on_create_new_style_confirmation_page(String Key) throws Throwable {
		createstylecon.clickontheElements(Key);
	}

	@And("^User clicks on the (.+) attributes on Create New Style Confirmation Page$")
	public void user_clicks_on_the_attributes_on_create_new_style_confirmation_page(String key) throws Throwable {
		createstylecon.clickOntheelementsoncreatestyleconfirmationpage(key);
	}

	@And("^User clicks on Back Link on Create New Style Confirmation Page$")
	public void user_clicks_on_back_link_on_create_new_style_confirmation_page() throws Throwable {
		createstylecon.clickonbacklinkinconfirmationpage();
	}

	@Then("^User should be able to see the Style Id on Create New Style Confirmation page$")
	public void user_should_be_able_to_see_the_style_id_on_create_new_style_confirmation_page() throws Throwable {
		createstylecon.verifystyleidinCreateStyleconfPage();
	}

	@Then("^User should be able to see the below fields on Create New Style Confirmation page$")
	public void user_should_be_able_to_see_the_below_fields_on_create_new_style_confirmation_page(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			createstylecon.verifyElementsoncreatestyleconfirmationpage(
					createstylecon.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}
	 @And("^Notification Hub Process is started for create Style with (.+)$")
	    public void notification_hub_process_is_started_for_create_style_with(String mandatorydetails) throws Throwable {
		    String filename = mandatorydetails.split("_")[1];
			testmucNHLogFilePath = System.getProperty("user.dir") + "/temp/topic-NotiHub" + filename + ".log";
			System.out.println(testmucNHLogFilePath);
			FileManager.getFileManagerObj().deleteFile(testmucNHLogFilePath);
			String command = "";
			// String environment =
			// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
			String environment = SSOLoginPage.UIEnvironment.toLowerCase();
			if(environment.equalsIgnoreCase("dev")) {
				command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC";
			}
			if(environment.equalsIgnoreCase("qa")) {
				command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.QA.OUT.WMAP.TOPIC";
			}
			if(environment.equalsIgnoreCase("uat")) {
				command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.UAT.OUT.WMAP.TOPIC";
			}
			// Redirecting to a pipe and applying a filter with identifier as filter value
			String identifier = "ProductMaster";
			command = command + " | find /i \"" + identifier + "\" >>" + testmucNHLogFilePath;
			Reporter.addStepLog("<b>Kafka Command: </b>" + command);
			ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
			pb.directory(new File(kafkaPath));
			p = pb.start();
			// Thread.sleep(10000);
	    }
	 @And("^Data Hub Process is started for create Style with (.+)$")
	    public void data_hub_process_is_started_for_create_style_with(String mandatorydetails) throws Throwable {
		    String filename = mandatorydetails.split("_")[1];
		    testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-DataHub" + filename + ".log";
			//String testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-testmucDataHub.log";
			FileManager.getFileManagerObj().deleteFile(testmucDHLogFilePath);
			String command = "";
			// String environment =
			// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
			String environment = SSOLoginPage.UIEnvironment;
			if(environment.equalsIgnoreCase("dev")) {
				command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC";
			}
			if(environment.equalsIgnoreCase("qa")) {
				command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.QA.OUT.WMAP.TOPIC";
			}
			if(environment.equalsIgnoreCase("uat")) {
				command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.UAT.OUT.WMAP.TOPIC";
			}
			// Redirecting to a pipe and applying a filter with identifier as filter value
			String identifier = "Style";
			command = command + " | find /i \"" + identifier + "\" >>" + testmucDHLogFilePath;
			Reporter.addStepLog("<b>Kafka Command: </b>" + command);
			ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
			pb.directory(new File(kafkaPath));
			p = pb.start();
	    } 
	 @And("^a notification is sent to Notification Hub after Create Style flow on UI$")
	    public void a_notification_is_sent_to_notification_hub_after_create_style_flow_on_ui() throws Throwable {
		    Thread.sleep(10000);
		    styleId = createstylecon.getStyleId();
		    styleName = createstylecon.getStyleName();
			FileReader fr = new FileReader(testmucNHLogFilePath);
			BufferedReader br = new BufferedReader(fr);
			String line;
			// String strategyName = CreateStrategyStepDef.strategyName;
			// String message = "\"Operation\":\"CREATE\"";
			// String strategyCode = strategyCode;
			while((line = br.readLine()) != null) {
				if(line.contains(styleId)) {
					Action.pause(1000);
					p.destroy();
					// System.out.println("Successful!!!!!!!");
					break;
				}
			}
			Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucNHLogFilePath);
			Reporter.addStepLog("<b>Notification from NH: </b>" + line);
			Reporter.addStepLog("<b>Style Name: </b>" + styleName);
			Reporter.addStepLog("<b>Style Id: </b>" + styleId);
			if(line.contains(styleName)) {
				Reporter.addStepLog("<p style = 'color:green'>Style Name is Matched in Notification</p>");
				Assert.assertTrue(line.contains(styleName));
			}
			else if(line.contains(styleId)) {
				Reporter.addStepLog("<p style = 'color:green'>Style Id is Matched in Notification</p>");
				Assert.assertTrue(line.contains(styleId));
			}
			else {
				Assert.fail("No Response from Notification Hub");
			}
			/*
			 * if(line.contains(message)) { Reporter.
			 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
			 * +"</b>"); Assert.assertTrue(line.contains(message)); }
			 */
			p.destroyForcibly();
			br.close();
			fr.close();
	    }
	 @And("^a Payload is sent to Data Hub after Create Style flow on UI$")
	    public void a_payload_is_sent_to_data_hub_after_create_style_flow_on_ui() throws Throwable {
		 Thread.sleep(10000);
			styleId = createstylecon.getStyleId();
			styleName = createstylecon.getStyleName();
			FileReader fr = new FileReader(testmucDHLogFilePath);
			BufferedReader br = new BufferedReader(fr);
			String line;
			// String strategyName = CreateStrategyStepDef.strategyName;
			// String message = "\"Operation\":\"CREATE\"";
			// String strategyCode = strategyCode;
			while((line = br.readLine()) != null) {
				if(line.contains(styleId)) {
					Action.pause(1000);
					p.destroy();
					// System.out.println("Successful!!!!!!!");
					break;
				}
			}
			Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
			Reporter.addStepLog("<b>Notification from DH: </b>" + line);
			Reporter.addStepLog("<b>Style Name: </b>" + styleName);
			Reporter.addStepLog("<b>Style Id: </b>" + styleId);
			if(line.contains(styleName)) {
				Reporter.addStepLog("<p style = 'color:green'>Style Name is Matched in Notification</p>");
				Assert.assertTrue(line.contains(styleName));
			}
			else if(line.contains(styleId)) {
				Reporter.addStepLog("<p style = 'color:green'>Style Id is Matched in Notification</p>");
				Assert.assertTrue(line.contains(styleId));
			}
			else {
				Assert.fail("No Payload is recieved from Data Hub");
			}
			/*
			 * if(line.contains(message)) { Reporter.
			 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
			 * +"</b>"); Assert.assertTrue(line.contains(message)); }
			 */
			p.destroyForcibly();
			br.close();
			fr.close();
	    }

}
