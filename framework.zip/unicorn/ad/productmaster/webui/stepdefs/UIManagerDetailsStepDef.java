package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class UIManagerDetailsStepDef {
	
	PMPageGeneric ManagerDetail = new PMPageGeneric("AD_PM_ManagerDetailPage");
	List<WebElement> listOfElements;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/manager/view";
	
	String xpath;
	Boolean myFlag;
	String expectedColorCode;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ManagerDetailPage"));
	
	
	@Then("^user should be able to go Update Manager UI screen$")
	public void user_should_be_able_to_go_update_manager_ui_screen() throws Throwable {
		Assert.assertTrue(action.getCurrentURL().contains(pageURL), "We are in UpdateManagerUIPage");
		Reporter.addStepLog("the pageURL is " + action.getCurrentURL());
		Reporter.addScreenCapture();
	}

	@Then("^User should not be able to see the \"([^\"]*)\" in the \"([^\"]*)\" on Manager Detail page$")
	public void user_should_not_be_able_to_see_the_something_in_the_something_on_manager_detail_page(String text,
			String key) throws Throwable {
		ManagerDetail.verifyTextNotPresentInListOfElements(text, ManagerDetail.getElements(key));
	}

	@And("^user clicks the Edit Button on Manager Detail page$")
    public void user_clicks_the_edit_button_on_manager_detail_page() throws Throwable {
		action.click(action.getElement("Edit Button"));
		//viewPage.clickOnContinueEditing();
        Reporter.addStepLog("clicked on Edit button");
    }
	
	@Then("^User should be able to see the \"([^\"]*)\" header on Manager Detail page$")
	public void user_should_be_able_to_see_the_something_header_on_manager_detail_page(String key) throws Throwable {
		ManagerDetail.verifyHeader(key);
	}

	@Then("^User should be able to see the \"([^\"]*)\" on Manager Detail page$")
	public void user_should_be_able_to_see_the_something_on_manager_detail_page(String key) throws Throwable {
		ManagerDetail.verifyElement(key);
	}
	@Then("^User should be able to see the \"([^\"]*)\" inside Manager Detail page$")
    public void user_should_be_able_to_see_the_something_inside_manager_detail_page(String key) throws Throwable {
        ManagerDetail.verifyElement(ManagerDetail.getElementFromShadowRoot(key));
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Manager Detail page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_inside_manager_detail_page(String ghostText, String searchBox) throws Throwable {
    	ManagerDetail.verifyGhostText(ghostText, ManagerDetail.getElementFromShadowRoot(searchBox));
    }
	@And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" on Manager Detail page$")
	public void user_should_be_able_to_see_the_something_ghost_text_in_something_on_manager_detail_page(
			String ghostText, String searchBox) throws Throwable {
		ManagerDetail.verifyGhostText(ghostText, searchBox);
	}

	
    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Manager Detail page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_manager_detail_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
    	ManagerDetail.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = ManagerDetail.getElementsFromShadowRoot(key);
   	 ManagerDetail.verifyTextInListOfElements( items.get(i),listOfElements);  
        } 
    }

	@Then("^User should be able to see the bottom-border below \"([^\"]*)\" on Manager Detail page$")
	public void user_should_be_able_to_see_the_bottomborder_below_something_on_manager_detail_page(String key)
			throws Throwable {
		String widthInPixel = ManagerDetail.giveCssValue(ManagerDetail.getElement(key), "border-bottom-width");
		String width = widthInPixel.substring(0, widthInPixel.length() - 2);
		Assert.assertTrue(Integer.parseInt(width) > 0);
		Reporter.addStepLog("validated the border below"+key);
	}

	@Then("^user should be able to see the following attributes on Manager Detail page$")
	public void user_should_be_able_to_see_the_following_attributes_on_manager_detail_page(List<String> attributes)
			throws Throwable {
		listOfElements = ManagerDetail.getElements("Attributes");
		for (int i = 0; i < attributes.size(); i++) {
			ManagerDetail.verifyTextInListOfElements(attributes.get(i), listOfElements);
		}
	}

	@And("^user clicks the \"([^\"]*)\" on Manager Detail page$")
	public void user_clicks_the_something_on_manager_detail_page(String key) throws Throwable {
		ManagerDetail.clickOnLink(key);
	}

	

	@Then("^The attributes on Manager Detail page should contain either true or false or blank value$")
	public void the_attributes_on_manager_detail_page_should_contain_either_true_or_false_or_blank_value(
			List<String> attributes) throws Throwable {
		String myValue = null;
		for (int i = 0; i < attributes.size(); i++) {
			String xpath = "//small[contains(text(),'" + attributes.get(i) + "')]/ancestor::p/following-sibling::input";
			myValue = ManagerDetail.findElementByDynamicXpath(xpath).getAttribute("value");
			Reporter.addStepLog("The value for " + attributes.get(i) + " is " + myValue);
			if (myValue.equals("true") || myValue.equals("false") || myValue.equals("")) {
				Assert.assertTrue(true);

			} else {
				Assert.assertFalse(true);
			}
		}
	}

	@And("^The text written in \"([^\"]*)\" should match with the value of \"([^\"]*)\" attribute on Manager Detail page$")
	public void the_text_written_in_something_should_match_with_the_value_of_something_attribute_on_manager_detail_page(
			String actualkey, String expectedkey) throws Throwable {
		Assert.assertEquals(ManagerDetail.getText(actualkey), ManagerDetail.getText(expectedkey));
	}

	@And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Manager Detail page$")
	public void something_should_be_displayed_in_something_color_on_manager_detail_page(String key,
			String expectedColor) throws Throwable {
		expectedColorCode = Action.getTestData(expectedColor);
		ManagerDetail.verifyColor(key, expectedColorCode);
	}
	
	@And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Manager Detail page$")
    public void something_should_be_displayed_in_something_color_inside_manager_detail_page(String key,
			String expectedColor) throws Throwable {
		expectedColorCode = Action.getTestData(expectedColor);
		ManagerDetail.verifyColor(ManagerDetail.getElementFromShadowRoot(key), expectedColorCode);
    }

	
	@Then("^The attributes on Manager Detail page should contain one of the following values$")
	public void the_attributes_on_manager_detail_page_should_contain_one_of_the_following_values(
			List<List<String>> attributeValuePair) throws Throwable {
		String myValue = null;

		for (int i = 0; i < attributeValuePair.size(); i++) {
			myFlag = false;
			xpath = "//small[contains(text(),'" + attributeValuePair.get(i).get(0)
					+ "')]/ancestor::p/following-sibling::span";
			myValue = ManagerDetail.findElementByDynamicXpath(xpath).getText();
			Reporter.addStepLog("The value for " + attributeValuePair.get(i).get(0) + " is " + myValue);
			String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
			for (int j = 0; j < listOfValues.length; j++)
				if (myValue.equals(listOfValues[j])) {
					myFlag = true;
					break;
				}

			Assert.assertTrue(myFlag);

		}
	}

	@And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Manager Detail page$")
	public void that_something_should_be_displayed_in_something_color_on_manager_detail_page(String strArg1,
			String expectedColor) throws Throwable {
		expectedColorCode = Action.getTestData(expectedColor);
		ManagerDetail.verifyCurrentElementColor(expectedColorCode);
		Reporter.addScreenCapture();
	}

	@Then("^The value on Manager Detail page of the following attributes should be in \"([^\"]*)\" format$")
	public void the_value_on_manager_detail_page_of_the_following_attributes_should_be_in_something_format(
			String format, List<String> attributes) throws Throwable {
		String myValue = null;
		for (int i = 0; i < attributes.size(); i++) {
			xpath = "//small[contains(text(),'" + attributes.get(i) + "')]/ancestor::p/following-sibling::span";
			myValue = ManagerDetail.findElementByDynamicXpath(xpath).getText();
			Reporter.addStepLog("validating for " + attributes.get(i) + " with value " + myValue);
			if (!myValue.equals(""))
				ManagerDetail.verifyFormat(myValue, Action.getTestData(format));

		}
	}

	@And("^compare the string values given in API and the values displayed in UI in Manager Details page$")
    public void compare_the_string_values_given_in_api_and_the_values_displayed_in_ui_in_manager_details_page(List<List<String>> APIUIAttributePair) {
		String APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().get(APIUIAttributePair.get(i).get(0));
		  xpath="//small[contains(text(),'"+APIUIAttributePair.get(i).get(1)+"')]/ancestor::p/following-sibling::span";
		 UIValue=ManagerDetail.findElementByDynamicXpath(xpath).getText();
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+APIValue);
		 
		 }
		 Reporter.addScreenCapture();
	}
	@And("^compare the boolean values given in API and the values displayed in UI in Manager Detail page$")
    public void compare_the_boolean_values_given_in_api_and_the_values_displayed_in_ui_in_manager_detail_page(List<List<String>> APIUIAttributePair) {
		Boolean APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().getBoolean(APIUIAttributePair.get(i).get(0));
		  xpath="//small[contains(text(),'"+APIUIAttributePair.get(i).get(1)+"')]/ancestor::p/following-sibling::input";
		 UIValue=Boolean.parseBoolean(ManagerDetail.findElementByDynamicXpath(xpath).getAttribute("value"));
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+APIValue);
		 
		 }
		 Reporter.addScreenCapture();
    }
	
	@Then("^User should be able to go to Manager Detail Page$")
    public void user_should_be_able_to_go_to_manager_detail_page() throws Throwable {
		Reporter.addStepLog("The page url is "+action.getCurrentURL());
		Assert.assertTrue(action.getCurrentURL().contains(pageURL));
    }
	
	
}
