package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.junit.Assert;

import cucumber.api.java.en.And;
import qa.unicorn.ad.productmaster.webui.pages.UpdatePMPStrategyCommentsPage;

public class UpdatePMPStrategyCommentsStepDef {

	UpdatePMPStrategyCommentsPage commentsPage = new UpdatePMPStrategyCommentsPage("AD_PM_UpdatePMPStrategyCommentsPage");
	
	@And("^User is in Comments Page in Update PMP Strategy Flow$")
    public void user_is_in_comments_page_in_update_pmp_strategy_flow() {
        Assert.assertTrue(commentsPage.isUserOnCommentsPage());
    }

	@And("^User clicks on Next in Comments Page in Update PMP Strategy Flow$")
    public void user_clicks_on_next_in_comments_page_in_update_pmp_strategy_flow() {
        commentsPage.clickOnNext();
    }
}
