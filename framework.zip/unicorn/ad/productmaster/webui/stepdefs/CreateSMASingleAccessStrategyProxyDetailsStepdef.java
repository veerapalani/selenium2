package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyProxyDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreateSMASingleAccessStrategyProxyDetailsStepdef {
	CreateSMASingleAccessStrategyProxyDetailsPage proxyDetailsPage = new CreateSMASingleAccessStrategyProxyDetailsPage(
			"AD_PM_CreateSMASingleAccessStrategyProxyDetailsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError;

	@And("^User inputs (.+) in Proxy Details Page$")
	public void user_inputs_in_proxy_details_page(String mandatorydetails) throws IOException {
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		//String environment = property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails + "_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails + "_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails + "_uat";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String proxyAddressManagerName = (String)exlObj.getCellData(sheet, rowIndex, 49);
		String proxyAddressLine1 = (String)exlObj.getCellData(sheet, rowIndex, 50);
		String proxyAddressLine2 = (String)exlObj.getCellData(sheet, rowIndex, 51);
		String proxyAddressLine3 = (String)exlObj.getCellData(sheet, rowIndex, 52);
		String proxyAddressLine4 = (String)exlObj.getCellData(sheet, rowIndex, 53);
		String proxyAddressCity = (String)exlObj.getCellData(sheet, rowIndex, 54);
		String proxyAddressState = (String)exlObj.getCellData(sheet, rowIndex, 55);
		String proxyAddressZipCode = String.valueOf(exlObj.getCellData(sheet, rowIndex, 56));
		String voluntaryReorgSameAsProxy = (String)exlObj.getCellData(sheet, rowIndex, 57);
		String voluntaryReorgAddressManagerName = (String)exlObj.getCellData(sheet, rowIndex, 58);
		String voluntaryReorgAddressLine1 = (String)exlObj.getCellData(sheet, rowIndex, 59);
		String voluntaryReorgAddressLine2 = (String)exlObj.getCellData(sheet, rowIndex, 60);
		String voluntaryReorgAddressLine3 = (String)exlObj.getCellData(sheet, rowIndex, 61);
		String voluntaryReorgAddressLine4 = (String)exlObj.getCellData(sheet, rowIndex, 62);
		String voluntaryReorgAddressCity = (String)exlObj.getCellData(sheet, rowIndex, 63);
		String voluntaryReorgAddressState = (String)exlObj.getCellData(sheet, rowIndex, 64);
		String voluntaryReorgAddressZipCode = String.valueOf(exlObj.getCellData(sheet, rowIndex, 65));
		String interimSameAsProxy = (String)exlObj.getCellData(sheet, rowIndex, 66);
		String interimAddressManagerName = (String)exlObj.getCellData(sheet, rowIndex, 67);
		String interimAddressLine1 = (String)exlObj.getCellData(sheet, rowIndex, 68);
		String interimAddressLine2 = (String)exlObj.getCellData(sheet, rowIndex, 69);
		String interimAddressLine3 = (String)exlObj.getCellData(sheet, rowIndex, 70);
		String interimAddressLine4 = (String)exlObj.getCellData(sheet, rowIndex, 71);
		String interimAddressCity = (String)exlObj.getCellData(sheet, rowIndex, 72);
		String interimAddressState = (String)exlObj.getCellData(sheet, rowIndex, 73);
		String interimAddressZipCode = String.valueOf(exlObj.getCellData(sheet, rowIndex, 74));
		if(proxyAddressManagerName != "") {
			proxyDetailsPage.enterProxyAddressManagerName(proxyAddressManagerName);
		}
		if(proxyAddressLine1 != "") {
			proxyDetailsPage.enterProxyAddressLine1(proxyAddressLine1);
		}
		if(proxyAddressLine2 != "") {
			proxyDetailsPage.enterProxyAddressLine2(proxyAddressLine2);
		}
		if(proxyAddressLine3 != "") {
			proxyDetailsPage.enterProxyAddressLine3(proxyAddressLine3);
		}
		if(proxyAddressLine4 != "") {
			proxyDetailsPage.enterProxyAddressLine4(proxyAddressLine4);
		}
		if(proxyAddressCity != "") {
			proxyDetailsPage.enterProxyAddressCity(proxyAddressCity);
		}
		if(proxyAddressState != "") {
			proxyDetailsPage.enterProxyAddressState(proxyAddressState);
		}
		if(proxyAddressZipCode != "") {
			proxyDetailsPage.enterProxyAddressZipCode(proxyAddressZipCode);
		}
		if(voluntaryReorgSameAsProxy != "") {
			proxyDetailsPage.enterVoluntaryReorgSameAsProxy(voluntaryReorgSameAsProxy);
		}
		if(voluntaryReorgAddressManagerName != "") {
			proxyDetailsPage.enterVoluntaryReorgAddressManagerName(voluntaryReorgAddressManagerName,
					voluntaryReorgSameAsProxy);
		}
		if(voluntaryReorgAddressLine1 != "") {
			proxyDetailsPage.enterVoluntaryReorgAddressLine1(voluntaryReorgAddressLine1, voluntaryReorgSameAsProxy);
		}
		if(voluntaryReorgAddressLine2 != "") {
			proxyDetailsPage.enterVoluntaryReorgAddressLine2(voluntaryReorgAddressLine2, voluntaryReorgSameAsProxy);
		}
		if(voluntaryReorgAddressLine3 != "") {
			proxyDetailsPage.enterVoluntaryReorgAddressLine3(voluntaryReorgAddressLine3, voluntaryReorgSameAsProxy);
		}
		if(voluntaryReorgAddressLine4 != "") {
			proxyDetailsPage.enterVoluntaryReorgAddressLine4(voluntaryReorgAddressLine4, voluntaryReorgSameAsProxy);
		}
		if(voluntaryReorgAddressCity != "") {
			proxyDetailsPage.enterVoluntaryReorgAddressCity(voluntaryReorgAddressCity, voluntaryReorgSameAsProxy);
		}
		if(voluntaryReorgAddressState != "") {
			proxyDetailsPage.enterVoluntaryReorgAddressState(voluntaryReorgAddressState, voluntaryReorgSameAsProxy);
		}
		if(voluntaryReorgAddressZipCode != "") {
			proxyDetailsPage.enterVoluntaryReorgAddressZipCode(voluntaryReorgAddressZipCode, voluntaryReorgSameAsProxy);
		}
		if(interimSameAsProxy != "") {
			proxyDetailsPage.enterInterimSameAsProxy(interimSameAsProxy);
		}
		if(interimAddressManagerName != "") {
			proxyDetailsPage.enterInterimAddressManagerName(interimAddressManagerName, interimSameAsProxy);
		}
		if(interimAddressLine1 != "") {
			proxyDetailsPage.enterInterimAddressLine1(interimAddressLine1, interimSameAsProxy);
		}
		if(interimAddressLine2 != "") {
			proxyDetailsPage.enterInterimAddressLine2(interimAddressLine2, interimSameAsProxy);
		}
		if(interimAddressLine3 != "") {
			proxyDetailsPage.enterInterimAddressLine3(interimAddressLine3, interimSameAsProxy);
		}
		if(interimAddressLine4 != "") {
			proxyDetailsPage.enterInterimAddressLine4(interimAddressLine4, interimSameAsProxy);
		}
		if(interimAddressCity != "") {
			proxyDetailsPage.enterInterimAddressCity(interimAddressCity, interimSameAsProxy);
		}
		if(interimAddressState != "") {
			proxyDetailsPage.enterInterimAddressState(interimAddressState, interimSameAsProxy);
		}
		if(interimAddressZipCode != "") {
			proxyDetailsPage.enterInterimAddressZipCode(interimAddressZipCode, interimSameAsProxy);
		}
	}

	@When("^User clicks on Next in Proxy Details Page$")
	public void user_clicks_on_next_in_proxy_details_page() {
		proxyDetailsPage.clickOnNext();
	}

	@Then("^User should be able to see error message in ProxyDetails Page$")
	public void user_should_be_able_to_see_error_message_in_proxydetails_page() throws IOException {
		sheetName = "Test";
		sheet = exlObj.getSheet(sheetName);
		//need to get mandatory details - change step def
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		expError = (String)exlObj.getCellData(sheet, rowIndex, 80);
		assertTrue(proxyDetailsPage.validateErrorMessage(expError));
	}

	@And("^User should be able to see Proxy Details Page in Create SMA SA Flow$")
	public void user_should_be_able_to_see_proxy_details_page_in_create_sma_sa_flow() {
		Assert.assertTrue(proxyDetailsPage.isUserOnProxyDetailsPage());
	}

	@And("^User clicks on Previous Button in Proxy Details Page in Create SMA SA Flow$")
	public void user_clicks_on_previous_button_in_proxy_details_page_in_create_sma_sa_flow() {
		proxyDetailsPage.clickOnPrevious();
	}

	@Then("^User verfies same as proxy option for both addresses with (.+) in Proxy Details Page$")
	public void user_verifies_same_as_proxy_option_for_both_addresses_in_proxy_details_page(String mandatoryDetails)
			throws IOException {
		if(mandatoryDetails.contains("Test")) {
			sheetName = "Test";
		}
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatoryDetails = mandatoryDetails + "_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatoryDetails = mandatoryDetails + "_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatoryDetails = mandatoryDetails + "_uat";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatoryDetails);
		String proxyAddressManagerName = (String)exlObj.getCellData(sheet, rowIndex, 49);
		String proxyAddressLine1 = (String)exlObj.getCellData(sheet, rowIndex, 50);
		String proxyAddressLine2 = (String)exlObj.getCellData(sheet, rowIndex, 51);
		String proxyAddressLine3 = (String)exlObj.getCellData(sheet, rowIndex, 52);
		String proxyAddressLine4 = (String)exlObj.getCellData(sheet, rowIndex, 53);
		String proxyAddressCity = (String)exlObj.getCellData(sheet, rowIndex, 54);
		String proxyAddressState = (String)exlObj.getCellData(sheet, rowIndex, 55);
		String proxyAddressZipCode = String.valueOf(exlObj.getCellData(sheet, rowIndex, 56));
		String voluntaryReorgSameAsProxy = (String)exlObj.getCellData(sheet, rowIndex, 57);
		String voluntaryReorgAddressManagerName = (String)exlObj.getCellData(sheet, rowIndex, 58);
		String voluntaryReorgAddressLine1 = (String)exlObj.getCellData(sheet, rowIndex, 59);
		String voluntaryReorgAddressLine2 = (String)exlObj.getCellData(sheet, rowIndex, 60);
		String voluntaryReorgAddressLine3 = (String)exlObj.getCellData(sheet, rowIndex, 61);
		String voluntaryReorgAddressLine4 = (String)exlObj.getCellData(sheet, rowIndex, 62);
		String voluntaryReorgAddressCity = (String)exlObj.getCellData(sheet, rowIndex, 63);
		String voluntaryReorgAddressState = (String)exlObj.getCellData(sheet, rowIndex, 64);
		String voluntaryReorgAddressZipCode = String.valueOf(exlObj.getCellData(sheet, rowIndex, 65));
		String interimSameAsProxy = (String)exlObj.getCellData(sheet, rowIndex, 66);
		String interimAddressManagerName = (String)exlObj.getCellData(sheet, rowIndex, 67);
		String interimAddressLine1 = (String)exlObj.getCellData(sheet, rowIndex, 68);
		String interimAddressLine2 = (String)exlObj.getCellData(sheet, rowIndex, 69);
		String interimAddressLine3 = (String)exlObj.getCellData(sheet, rowIndex, 70);
		String interimAddressLine4 = (String)exlObj.getCellData(sheet, rowIndex, 71);
		String interimAddressCity = (String)exlObj.getCellData(sheet, rowIndex, 72);
		String interimAddressState = (String)exlObj.getCellData(sheet, rowIndex, 73);
		String interimAddressZipCode = String.valueOf(exlObj.getCellData(sheet, rowIndex, 74));
		if(proxyAddressManagerName != "") {
			proxyDetailsPage.enterProxyAddressManagerName(proxyAddressManagerName);
		}
		if(proxyAddressLine1 != "") {
			proxyDetailsPage.enterProxyAddressLine1(proxyAddressLine1);
		}
		if(proxyAddressLine2 != "") {
			proxyDetailsPage.enterProxyAddressLine2(proxyAddressLine2);
		}
		if(proxyAddressLine3 != "") {
			proxyDetailsPage.enterProxyAddressLine3(proxyAddressLine3);
		}
		if(proxyAddressLine4 != "") {
			proxyDetailsPage.enterProxyAddressLine4(proxyAddressLine4);
		}
		if(proxyAddressCity != "") {
			proxyDetailsPage.enterProxyAddressCity(proxyAddressCity);
		}
		if(proxyAddressState != "") {
			proxyDetailsPage.enterProxyAddressState(proxyAddressState);
		}
		if(proxyAddressZipCode != "") {
			proxyDetailsPage.enterProxyAddressZipCode(proxyAddressZipCode);
		}
		proxyDetailsPage.selectVoluntaryReorgSameAsProxy();
		proxyDetailsPage.selectInterimSameAsProxy();
		Assert.assertTrue(
				proxyAddressManagerName.equals(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Manager Name")));
		Assert.assertTrue(
				proxyAddressLine1.equals(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Address Line 1")));
		Assert.assertTrue(
				proxyAddressLine2.equals(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Address Line 2")));
		Assert.assertTrue(
				proxyAddressLine3.equals(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Address Line 3")));
		Assert.assertTrue(
				proxyAddressLine4.equals(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Address Line 4")));
		Assert.assertTrue(proxyAddressCity.equals(proxyDetailsPage.getTextFieldAttributeValue("Voluntary City")));
		Assert.assertTrue(proxyAddressState.equals(proxyDetailsPage.getTextFieldAttributeValue("Voluntary State")));
		Assert.assertTrue(proxyAddressZipCode.equals(proxyDetailsPage.getTextFieldAttributeValue("Voluntary ZipCode")));
		Assert.assertTrue(
				proxyAddressManagerName.equals(proxyDetailsPage.getTextFieldAttributeValue("Interim Manager Name")));
		Assert.assertTrue(
				proxyAddressLine1.equals(proxyDetailsPage.getTextFieldAttributeValue("Interim Address Line 1")));
		Assert.assertTrue(
				proxyAddressLine2.equals(proxyDetailsPage.getTextFieldAttributeValue("Interim Address Line 2")));
		Assert.assertTrue(
				proxyAddressLine3.equals(proxyDetailsPage.getTextFieldAttributeValue("Interim Address Line 3")));
		Assert.assertTrue(
				proxyAddressLine4.equals(proxyDetailsPage.getTextFieldAttributeValue("Interim Address Line 4")));
		Assert.assertTrue(proxyAddressCity.equals(proxyDetailsPage.getTextFieldAttributeValue("Interim City")));
		Assert.assertTrue(proxyAddressState.equals(proxyDetailsPage.getTextFieldAttributeValue("Interim State")));
		Assert.assertTrue(proxyAddressZipCode.equals(proxyDetailsPage.getTextFieldAttributeValue("Interim ZipCode")));
		Reporter.addScreenCapture();
		proxyDetailsPage.selectVoluntaryReorgSameAsProxy();
		proxyDetailsPage.selectInterimSameAsProxy();
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Manager Name").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Address Line 1").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Address Line 2").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Address Line 3").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Voluntary Address Line 4").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Voluntary City").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Voluntary State").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Voluntary ZipCode").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Interim Manager Name").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Interim Address Line 1").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Interim Address Line 2").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Interim Address Line 3").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Interim Address Line 4").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Interim City").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Interim State").isEmpty());
		Assert.assertTrue(proxyDetailsPage.getTextFieldAttributeValue("Interim ZipCode").isEmpty());
		Reporter.addScreenCapture();
	}
}
