package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAApprovalPage;

public class UpdateFAApprovalStepDef {
	
	UpdateFAApprovalPage approvalPage = new UpdateFAApprovalPage("AD_PM_UpdateFAApprovalPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
	
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue,flowPageDataValue = null;
	
	@Then("^User should be able to see Approval Page in Update FA Flow$")
    public void user_should_be_able_to_see_approval_page_in_update_fa_flow() {
		Assert.assertTrue(approvalPage.isUserOnApprovalPage());
    }
	
	@And("^User should be able to see fields on Approval details page for FA Update$")
	public void user_should_be_able_to_see_fields_on_approval_details_page_for_fa_update(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			approvalPage.verifyElementsOnApprovalDetailsPage(entity);
			
		}
	}
	
	@And("^User Clicks on Next in Approval deatils FA Update$")
	public void user_clicks_on_next_in_approval_deatils_fa_update() {
		approvalPage.clickonnextbutton();
	}
	
	@And("^User Clicks on Next in Approval details Page in Update FA Flow$")
    public void user_clicks_on_next_in_approval_details_page_in_update_fa_flow() throws Throwable {
		approvalPage.clickonnextbutton();
    }
	
	@And("^User Clicks on Previous button in Approval details Page in Update FA Flow$")
    public void user_clicks_on_previous_button_in_approval_details_page_in_update_fa_flow() {
        approvalPage.clickOnPreviousButton();
    }
	
	@And("^User enters the details required on the FA Update Approval Page$")
	public void user_enters_the_details_required_on_the_fa_update_approval_page() throws Throwable {
		approvalPage.enterHomeOfficeComments();
		//approvalPage.enterApproverName();
		approvalPage.selectStatusDate();
		approvalPage.selectFollowUpDate();
	}
	
	@And("^Data prepopulated in Approval page should match with DB Data in Update FA flow for (.+)$")
    public void data_prepopulated_in_approval_page_should_match_with_db_data_in_update_fa_flow_for(String mandatorydetails) {
		//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
				if(mandatorydetails.contains("Test"))
					sheetName = "Test";
					
				   //sheet = exlObj.getSheet(sheetName);
				   //count = 0;
				   int columnIndex = 36;
				   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
				   int dbDataRowIndex = rowIndex+1;
				   
				   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
						   //(String) exlObj.getCellData(sheet, rownum, 0);
				   
				   if(label == "")
						label = "isEmpty";
					while (label != "isEmpty") {
															
							if(label.contains("ignore") || label.contains("NIVDP")) {
								columnIndex++;
								
					    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
					    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
					    			
					    			if(label == "")
					    				label = "isEmpty";
							}else {
								
								attributeValue = getDataFromApprovalPage(label);
								dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
										//(String) exlObj.getCellData(sheet, rownum, 3).toString();
								if(dbValue.equalsIgnoreCase(attributeValue)) {
									
									
									
								}else {
									
									
									Reporter.addEntireScreenCaptured();
									Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
									
									
								}
								columnIndex++;
									
									label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
											//(String) exlObj.getCellData(sheet, rownum, 0).toString();
									
									if(label == "")
										label = "isEmpty";
							
							}
					}
//					if(count > 0) {
//						Assert.fail("Prepopulated Values are not same as values stored in DB");
//					}
					//Reporter.addCompleteScreenCapture();
					//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }

    private String getDataFromApprovalPage(String data) {
		    	switch (data) {
				case "radiobutton - Exception / Conditional Approval":
					
					uiValue = approvalPage.getExceptionorConditionApprovalValue();
					
					break;
				case "date - Expiration Date":
					
					uiValue = approvalPage.getExpirationDateValue();
					
					break;
				case "txt - Home Office Comments":
					
					uiValue = approvalPage.getHomeOfficeCommentsValue();
					
					break;
				case "grey - Approver Name":
					
					uiValue = approvalPage.getApproverNameValue();
					
					break;
				case "drp - FA Status":
					
					uiValue = approvalPage.getFAStatusValue();
					
					break;
				case "date - Status Date":
					
					uiValue = approvalPage.getStatusDateValue();
					
					break;
				case "date - Follow-up Date":
					
					uiValue = approvalPage.getFollowUpDateValue();
					
					break;
				case "txt - Follow-up":
					
					uiValue = approvalPage.getFollowUpValue();
					
					break;
					
				default:
					
					uiValue = "NotChanged";
					
					break;
			}
			if(uiValue.equals("—"))
				uiValue = "isEmpty";
		
			return uiValue;
			
			
	}

	@And("^User inputs the values from (.+) in Approval page in Update FA Flow$")
    public void user_inputs_the_values_from_in_approval_page_in_update_fa_flow(String mandatorydetails) throws InterruptedException {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		int updateDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex+1;
    	
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			String approverName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 36);
			String faStatus = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 37);
			String statusDate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 38);
			String exceptionOrConditionalApproval = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 39);
			String expirationDate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 40);
			String followUpDate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 41);
			String homeOfficeComments = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 42);
			String followUp = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 43);
			
			if(approverName != "")
				approvalPage.enterApproverName(approverName);
			if(faStatus != "")
				approvalPage.enterFaStatus(faStatus);
			if(statusDate != "")
				approvalPage.enterStatusDate(statusDate);
			approvalPage.enterExceptionOrConditionalApproval(exceptionOrConditionalApproval);
			if(expirationDate != "")
				approvalPage.enterExpirationDate(expirationDate, exceptionOrConditionalApproval);
			if(followUpDate != "")
				approvalPage.enterFollowUpDate(followUpDate);
			if(homeOfficeComments != "")
				approvalPage.enterHomeOfficeComments(homeOfficeComments, exceptionOrConditionalApproval);
			approvalPage.enterFollowUp(followUp);
			
			
				//if(ubsSubsudiary != "")
					//managerDetailsPage.enterubsSubsudiary(ubsSubsudiary);
				
			
		}
		
		Reporter.addScreenCapture();
    }

    @And("^data from Approval page should be stored in Excel for (.+) in Update FA Flow$")
    public void data_from_approval_page_should_be_stored_in_excel_for_in_update_fa_flow(String mandatorydetails) throws IOException {
    	if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		
			
			
			   int columnIndex = 36;
			   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			   int flowPageDataRowIndex = rowIndex+3;
			   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			   
			   if(label == "")
					label = "isEmpty";
				while (label != "isEmpty") {
											
						if(label.contains("ignore") || label.contains("NIVDP")) {
							columnIndex++;
							
				    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
				    			
				    			if(label == "")
				    				label = "isEmpty";
						}else {
							
							attributeValue = getDataFromApprovalPage(label);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
									//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 3).toString();
							
							columnIndex++;
								
								label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
										//(String) exlObj.getCellData(sheet, rownum, 0).toString();
								
								if(label == "")
									label = "isEmpty";
						
						}
				}
			
    }
    
    @And("^Data prepopulated in Approval page should match with Flow Page Data in Update FA flow for (.+)$")
    public void data_prepopulated_in_approval_page_should_match_with_flow_page_data_in_update_fa_flow_for(String mandatorydetails) {
        
    }
     
    @Then("^User can able to enter details in Follow Up text field with (.+)$")
    public void user_can_able_to_enter_details_in_follow_up_text_field(String followUp) {
    	approvalPage.enterFollowUp(followUp);
        
    }

}
