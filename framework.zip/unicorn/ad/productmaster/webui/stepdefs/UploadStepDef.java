package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UploadPage;

public class UploadStepDef {

	UploadPage uploadPage = new UploadPage("AD_PM_UploadPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();

	String excelFilePath = "./src/test/resources/ad/productmaster/webui/csv-files/Upload.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex, columnIndex;
	Boolean uploadStatus;
	String fileNameWithExtension;
	String uploadFilePath;
	String fileType;

	@And("^User should be able to see Manual Upload Strategy Page in UI$")
	public void user_should_be_able_to_see_manual_upload_strategy_page_in_ui() {
		Assert.assertTrue(uploadPage.isUserOnManualUploadSlidePage());
	}

	@Then("^User should be able to see (.+) in UI in Upload File flow$")
	public void user_should_be_able_to_see_in_ui_in_upload_file_flow(String confirmationmessage) {
		uploadStatus = uploadPage.verifyConfirmationMessageonFileUpload(confirmationmessage);

		Assert.assertTrue(uploadStatus, "File Upload Confirmation Message is as Expected");
		Reporter.addCompleteScreenCapture();
	}

	@And("^User Selects \"([^\"]*)\" file type value from Dropdown in Upload Flow$")
	public void user_selects_something_file_type_value_from_dropdown_in_upload_flow(String fileType) {
		this.fileType = fileType;
		uploadPage.selectFileType(fileType);
	}

	@And("^User uploads the File with (.+) in Upload File Flow$")
	public void user_uploads_the_file_with_in_upload_file_flow(String filename) {

		fileNameWithExtension = filename + "_" + SSOLoginPage.UIEnvironment.toLowerCase().trim() + ".csv";
		uploadFilePath = System.getProperty("user.dir")
				+ "\\src\\test\\resources\\ad\\productmaster\\webui\\csv-files\\" + fileNameWithExtension;

		uploadPage.uploadFileWithRobot(uploadFilePath);
	}

	@And("^User should be able to verify selected \"([^\"]*)\" file type and (.+) filename values on PMUI$")
	public void user_should_be_able_to_verify_selected_something_file_type_and_filename_values_on_pmui(String filename,
			String filetype) throws Throwable {
		uploadPage.verifyUploadedFileName(filename);
		uploadPage.verifyUploadedFileType(filetype);
	}

	@And("^Data From File should match with the DB data for programs mentioned in File after successful file upload$")
	public void data_from_file_should_match_with_the_db_data_for_programs_mentioned_in_file_after_successful_file_upload()
			throws SQLException {
		List<String[]> dataFromCSVFile = CSVFileUtils.getInstance().readAllCommaSeparatedValues(uploadFilePath);

		if (uploadStatus) {
			int sizeOfArray = dataFromCSVFile.get(0).length;
			dataFromCSVFile.remove(0);
			String[] arr;
			int noOfRecords = dataFromCSVFile.size();
			List<String> foaCodes;
			List<String[]> dataFromDB;
			List<String[]> dataFromDB2;
			boolean flag = false;

			switch (fileType) {
			case "Strategy - Basic Info":

				// Adding isEmpty to the DVP Template from CSV File if not read
				for (int i = 0; i < dataFromCSVFile.size(); i++) {
					if (dataFromCSVFile.get(i).length < 6) {

						arr = new String[6];
						for (int j = 0; j < 5; j++) {
							arr[j] = dataFromCSVFile.get(i)[j];
						}
						arr[5] = "isEmpty";
						dataFromCSVFile.remove(i);
						dataFromCSVFile.add(i, arr);

					}
				}

				foaCodes = CSVFileUtils.getInstance().getColumnValues(dataFromCSVFile, 1);
				dataFromDB = getDataFromDB(foaCodes, noOfRecords, 1, sizeOfArray);

				
				System.out.println("CSV File Data");
				  for (String i[] : dataFromCSVFile) { 
					  System.out.println(Arrays.toString(i));
				  }
				System.out.println("Data From DB");
				  for (String i[] : dataFromDB) { 
					  System.out.println(Arrays.toString(i)); 
				  }
				  
				  /*
				  for (int i = 0; i < foaCodes.size(); i++) { 
					  System.out.print(foaCodes.get(i)+ " -> "); 
				  }
				 */
				for (String[] strings : dataFromDB) {
					if (isInList(dataFromCSVFile, strings)) {
						flag = true;
						break;
					}
				}
				Assert.assertTrue(flag, "Data from DB Donot match with Data from CSV File for" + fileType
						+ "with File Name as " + fileNameWithExtension);
				Reporter.addCompleteScreenCapture();

				break;
			case "Strategy - Node ID Info":

				List<String> nodeIdFlag = CSVFileUtils.getInstance().getColumnValues(dataFromCSVFile, 2);
				List<String[]> bundledNodeIds = new ArrayList<String[]>();
				List<String[]> unBundledNodeIds = new ArrayList<String[]>();

				//for (String i[] : dataFromCSVFile) {
				//	System.out.println(Arrays.toString(i));
				//}

				for (int j = 0; j < nodeIdFlag.size(); j++) {
					if (nodeIdFlag.get(j).equals("F"))
						bundledNodeIds.add(dataFromCSVFile.get(j));
					else if (nodeIdFlag.get(j).equals("P")) {
						unBundledNodeIds.add(dataFromCSVFile.get(j));
					} else
						Assert.fail("Node ID Flag provided is incorrect");

				}

				List<String> onlyFOACodesFromBundled = CSVFileUtils.getInstance().getColumnValues(bundledNodeIds, 0);

				// Starting the comparision of Lists
				Assert.assertTrue(bundledNodeIds.size() + unBundledNodeIds.size() == dataFromCSVFile.size(),
						"Node ID Flag provided is incorrect");

				// setting flag as false for next checks
				flag = false;
				// Evaluating Bundled Node IDs First
				dataFromDB = getDataFromDB(onlyFOACodesFromBundled, noOfRecords, 2, sizeOfArray);

				
				  // for (String i[] : dataFromCSVFile) { System.out.println(Arrays.toString(i));
				  //}
				  System.out.println("Bundled Node Ids Data from CSV File");
				  for (String i[] : bundledNodeIds) { System.out.println(Arrays.toString(i)); }
				  
				  System.out.println("Data From DB for Bundled node IDs");
				  for (String i[] : dataFromDB) { System.out.println(Arrays.toString(i)); }
				 /* 
				 * for (int i = 0; i < onlyFOACodesFromBundled.size(); i++) {
				 * System.out.print(foaCodes.get(i) + " -> "); }
				 */

				for (String[] strings : dataFromDB) {
					if (isInList(bundledNodeIds, strings)) {
						flag = true;
						break;
					}
				}
				Assert.assertTrue(flag, "Data from DB Donot match with Bundled Node ID Data from CSV File for"
						+ fileType + "with File Name as " + fileNameWithExtension);

				// setting flag as false for next checks
				flag = false;

				// Evaluating Unbundled Node IDs
				dataFromDB2 = getDataFromDB(onlyFOACodesFromBundled, noOfRecords, 3, sizeOfArray);

				/*
				 * for (String i[] : dataFromCSVFile) { System.out.println(Arrays.toString(i));
				 * }
				 */ 
				System.out.println("Data from CSV Files for Unbundled Node IDs");  
				for (String i[] : unBundledNodeIds) { System.out.println(Arrays.toString(i));
				  }
				System.out.println("Data from DB fro Unbundled Node IDs");  
				  for (String i[] : dataFromDB2) { System.out.println(Arrays.toString(i)); }
				 /* 
				 * for (int i = 0; i < onlyFOACodesFromBundled.size(); i++) {
				 * System.out.print(foaCodes.get(i) + " -> "); }
				 */

				for (String[] strings : dataFromDB2) {
					if (isInList(unBundledNodeIds, strings)) {
						flag = true;
						break;
					}
				}
				Assert.assertTrue(flag, "Data from DB Donot match with Unbundled Node Id Data from CSV File for"
						+ fileType + "with File Name as " + fileNameWithExtension);

				Reporter.addCompleteScreenCapture();
				break;
			default:
				break;
			}

		} else {
			Reporter.addStepLog(
					fileType + "with File Name as " + fileNameWithExtension + " was not successfully Uploaded");
			Reporter.addCompleteScreenCapture();
		}

	}

	private static boolean isInList(List<String[]> dataFromCSVFile, String[] strings) {

		return dataFromCSVFile.stream().anyMatch(a -> Arrays.equals(a, strings));
	}

	private List<String[]> getDataFromDB(List<String> foaCodes, int noOfRecords, int cellnum, int sizeOfArray)
			throws SQLException {

		// Make a string of FOA Codes seperated by comma too use in DB Query
		String replaceData = "";
		if (foaCodes.size() > 0) {

			for (int i = 0; i < foaCodes.size(); i++) {
				replaceData = replaceData + "'" + foaCodes.get(i) + "'" + ",";
			}
			replaceData = replaceData.substring(0, replaceData.length() - 1);
		}

		pmdb.DBConnectionStart();
		sheetName = "SQLquery";
		ArrayList<String[]> dbData = new ArrayList<String[]>(noOfRecords);
		String[] array;
		DecimalFormat df = new DecimalFormat("0.#");

		ResultSet rs;
		String dbDataIterator = "testnull";

		// Get SQL Queries from Excel
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		String[] columnName = labelname.split(",");

		// Execute SQL Query
		SQLquery = SQLquery.replace("@data", replaceData);
		rs = DBManager.executeSelectQuery(SQLquery);
		int count = 0;
		while (rs.next()) {

			// Initiating array for each loop - to counter the repeated instance getting
			// added to Array List
			array = new String[sizeOfArray];
			for (int i = 0; i < columnName.length; i++) {

				dbDataIterator = rs.getString(columnName[i]);
				if (rs.wasNull() || dbDataIterator.isEmpty()) {
					dbDataIterator = "isEmpty";
				}

				if (columnName[i].equals("nrpercentage"))
					dbDataIterator = df.format(Double.parseDouble(dbDataIterator)).toString();
				array[i] = dbDataIterator;
			}
			dbData.add(count, array);
			count++;
		}
		// to handle Zero records from DB
		if (dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
			array = new String[6];
			for (int i = 0; i < columnName.length; i++) {

				array[i] = dbDataIterator;

			}
			dbData.add(array);
		}
		pmdb.DBConnectionClose();

		return dbData;
	}

	@Then("^User should be able to verify the uploaded \"([^\"]*)\" strategy benchmark details on PMDB$")
	public void user_should_be_able_to_verify_the_uploaded_something_strategy_benchmark_details_on_pmdb(String strArg1)
			throws Throwable {

		if (uploadStatus) {

			List<String[]> dataFromCSVFile3 = CSVFileUtils.getInstance().readAllCommaSeparatedValues(uploadFilePath);
			dataFromCSVFile3.remove(0);
			String[] arr3, arr4;

			// Adding isEmpty to the benchmark_name and benchmark_percentage if
			// benchmark_type is 'S' from CSV File if not read
			for (int i = 0; i < dataFromCSVFile3.size(); i++) {
				if (dataFromCSVFile3.get(i).length < 6) {

					arr3 = new String[6];
					for (int j = 0; j < 4; j++) {
						arr3[j] = dataFromCSVFile3.get(i)[j];
					}
					if (arr3[3].charAt(0) == 'S') {
						arr3[4] = "isEmpty";
						arr3[5] = "isEmpty";
						dataFromCSVFile3.remove(i);
						dataFromCSVFile3.add(i, arr3);
					}
				}
			}

			int noOfRecords3 = dataFromCSVFile3.size();
			List<String> foaCodes3 = CSVFileUtils.getInstance().getColumnValues(dataFromCSVFile3, 0);
			List<String[]> dataFromDB3 = getDataFromDB3(foaCodes3, noOfRecords3);
			System.out.println("Length = " + dataFromDB3);
			for (int m = 0; m < dataFromDB3.size(); m++) {
				// System.out.println("Length = " + dataFromDB3.get(m).length);
				if (dataFromDB3.get(m).length <= 6) {
					arr4 = new String[6];
					for (int n = 0; n < 4; n++) {
						arr4[n] = dataFromDB3.get(m)[n];
					}
					if (arr4[3].charAt(0) == 'D') {
						arr4[3] = "S";
						arr4[4] = "isEmpty";
						arr4[5] = "isEmpty";
						dataFromDB3.remove(m);
						dataFromDB3.add(m, arr4);
					}
				}
			}
			Reporter.addStepLog("Strategy-Benchmark Info CSV File Data");
			for (String i[] : dataFromCSVFile3) {
				System.out.println(Arrays.toString(i));
				Reporter.addStepLog(Arrays.toString(i));

			}
			System.out.println("///////////////////////=-------------------------=///////////////////////");
			Reporter.addStepLog("Strategy-Benchmark Info DB Data");
			for (String i[] : dataFromDB3) {
				System.out.println(Arrays.toString(i));
				Reporter.addStepLog(Arrays.toString(i));
			}
			for (int i = 0; i < foaCodes3.size(); i++) {
				System.out.println("--------------------");
				System.out.println(foaCodes3.get(i));
			}
			boolean flag3 = false;
			for (String[] strings3 : dataFromDB3) {
				if (isInList(dataFromCSVFile3, strings3)) {
					flag3 = true;
					break;
				}
			}
			Assert.assertTrue(flag3, "Data from DB Donot match with Data from Strategy- Benchmark Info CSV File");
			Reporter.addCompleteScreenCapture();

		} else {
			Reporter.addStepLog("Strategy- Benchmark Info CSV File was not successfully Uploaded on UI");
			Reporter.addCompleteScreenCapture();
		}

	}

	private List<String[]> getDataFromDB3(List<String> foaCodes3, int noOfRecords3) throws SQLException {

		// Make a string of FOA Codes seperated by comma too use in DB Query
		String replaceData3 = "";
		if (foaCodes3.size() > 0) {

			for (int i = 0; i < foaCodes3.size(); i++) {
				replaceData3 = replaceData3 + "'" + foaCodes3.get(i) + "'" + ",";
			}
			replaceData3 = replaceData3.substring(0, replaceData3.length() - 1);
		}
		pmdb.DBConnectionStart();
		sheetName = "SQLquery";
		ArrayList<String[]> dbData3 = new ArrayList<String[]>(noOfRecords3);
		String[] array3;

		ResultSet rs3;
		int cellnum3 = 4;
		String dbDataIterator3 = "testnull";

		// Get SQL Queries from Excel
		String SQLquery3 = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum3, 0);
		String labelname3 = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum3, 1);
		String[] columnName3 = labelname3.split(",");
		// Execute SQL Query
		SQLquery3 = SQLquery3.replace("@data", replaceData3);
		System.out.println("SQL Query3= " + SQLquery3);
		rs3 = DBManager.executeSelectQuery(SQLquery3);
		int count3 = 0;
		while (rs3.next()) {

			// Initiating array for each loop - to counter the repeated instance getting
			// added to Array List
			array3 = new String[6];
			for (int i = 0; i < columnName3.length; i++) {

				dbDataIterator3 = rs3.getString(columnName3[i]);
				if (rs3.wasNull() || dbDataIterator3.isEmpty()) {
					dbDataIterator3 = "isEmpty";
				}

				array3[i] = dbDataIterator3;
			}
			dbData3.add(count3, array3);
			count3++;
		}
		// to handle Zero records from DB
		if (dbDataIterator3.equalsIgnoreCase("testnull")) {
			dbDataIterator3 = "isEmpty";
			array3 = new String[6];
			for (int i = 0; i < columnName3.length; i++) {

				array3[i] = dbDataIterator3;

			}
			dbData3.add(array3);
		}
		pmdb.DBConnectionClose();

		return dbData3;
	}

	@Then("^User should be able to see the (.+) on UI after File Upload$")
    public void user_should_be_able_to_see_the_on_ui_after_file_upload(String errormessage) {
		uploadStatus = uploadPage.verifyConfirmationMessageonFileUpload("File was successfully uploaded");
		
		if(!uploadStatus) {
			Assert.assertTrue(uploadPage.getErrorMessageFromUI().contains(errormessage), "Error message displayed is Incorrect");
		}else {
			
			Assert.fail("File Got Successfully Uploaded in UI");
		}
		
    }

}
