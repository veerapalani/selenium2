package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFADocumentsPage;

public class UpdateFADocumentsStepDef {
	
	UpdateFADocumentsPage documentsPage = new UpdateFADocumentsPage("AD_PM_UpdateFADocumentsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue,flowPageDataValue = null;
	
	@Then("^User should be able to see Documents Page in Update FA Flow$")
    public void user_should_be_able_to_see_documents_page_in_update_fa_flow() {
		Assert.assertTrue(documentsPage.isUserOnDocumentsPage());
    }
	
	@And("^User should be able to see fields on Documents details page for FA Update$")
	public void user_should_be_able_to_see_fields_on_documents_details_page_for_fa_update(List<String> entity) {
		//for (int i = 0; i < entity.size(); i++) {
			documentsPage.verifyElementsOnDocumentsDetailsPage(entity);
			
		//}
	}
	
	@And("^User Clicks on Next in Documents deatils FA Update$")
	public void user_clicks_on_next_in_documents_deatils_fa_update() throws Throwable {
		documentsPage.clickonnextbutton();
	}
	
	@And("^User Clicks on Next in Documents deatils page in Update FA Flow$")
    public void user_clicks_on_next_in_documents_deatils_page_in_update_fa_flow() {
		documentsPage.clickonnextbutton();
    }
	
	@And("^User clicks on Previous button on the Documents page in Update FA Flow$")
    public void user_clicks_on_previous_button_on_the_documents_page_in_update_fa_flow() {
        documentsPage.clickOnPreviousButton();
    }

	@And("^Data prepopulated in Documents page should match with DB Data in Update FA flow for (.+)$")
    public void data_prepopulated_in_documents_page_should_match_with_db_data_in_update_fa_flow_for(String mandatorydetails) {
    	//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 33;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int dbDataRowIndex = rowIndex+1;
		   
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("grey - Approver Name"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromDocumentsPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equalsIgnoreCase(attributeValue)) {
							
							
							
						}else {
							
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("grey - Approver Name"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }

    private String getDataFromDocumentsPage(String data) {
    	
	    	Action.pause(2000);
			ArrayList<ArrayList<String>> documents = new ArrayList<ArrayList<String>>();
			ArrayList<String> tempData = new ArrayList<String>();
			String requiredDocumentValue = "";
	    	int docCount = documentsPage.getcountofDocuments();
	    	
	    	int j=0;
	    	for (int i = 0; i < docCount; i++) {
	    		
				documents.add(documentsPage.getithDocumentInfo(i));
				
			}
	    	
	    	
	    	switch (data) {
			case "drp - Document Type":
				j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = documents.get(j).get(0);
					tempData.add(requiredDocumentValue);
					j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			case "txt - Document Link":
				j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = documents.get(j).get(1);
					tempData.add(requiredDocumentValue);
					j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			case "txt - Document Comment":
				j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = documents.get(j).get(2);
					tempData.add(requiredDocumentValue);
					j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
	    	
	    	documents.clear();
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
	
    }

    @And("^User inputs the values from (.+) in Documents page in Update FA Flow$")
    public void user_inputs_the_values_from_in_documents_page_in_update_fa_flow(String mandatorydetails) throws IOException {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();

		String tName = Thread.currentThread().getName();
		String documentType,documentLink,documentComment,deleteDocuments = "";
		
		documentLink = RandomStringUtils.randomAlphanumeric(10);
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			deleteDocuments = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 32);
			documentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 33);
			//documentLink = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 34);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 34, documentLink);
			documentComment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 35);
			
		}
		
		int documentsCount = documentsPage.getcountofDocuments();
		
		if(Integer.parseInt(deleteDocuments) > documentsCount) {
			Reporter.addStepLog("Document Count in UI is less than the count given in Excel -- Deleting all contacts");
			
			for (int i = 0; i < documentsCount; i++) {
				documentsPage.deleteDocument();
				
			}
			
		}else {
			for (int i = 0; i < Integer.parseInt(deleteDocuments); i++) {
				documentsPage.deleteDocument();
				
			}
		}
		
		if(documentType != "" && documentLink != "" && documentComment != "") {
			documentsPage.clickOnAddAnotherDocument();
			if(documentType.contains(",") && documentLink.contains(",") && documentComment.contains(",")) {
				String[] docType = documentType.split(",");
				String[] docLink = documentLink.split(",");
				String[] docComment = documentComment.split(",");
				
				int docTypeSize = docType.length;
				int docLinkSize = docLink.length;
				int docCommentSize = docComment.length;
				int size = Math.min(docCommentSize, docLinkSize);
				size = Math.min(size, docTypeSize);
				int i =0;
				
					while(size > 0) {
						documentsPage.selectDocumentType(docType[i]);
						documentsPage.enterDocumentLink(docLink[i]);
						documentsPage.enterDocumentComment(docComment[i]);
						documentsPage.clickOnAddDocumentLinkButton();
						size--;
						i++;
						if(size > 0) {
						documentsPage.clickOnAddAnotherDocument();
						}
					}
				
		        
			}
			else {
			
				documentsPage.selectDocumentType(documentType);
				documentsPage.enterDocumentLink(documentLink);
				documentsPage.enterDocumentComment(documentComment);
				documentsPage.clickOnAddDocumentLinkButton();
			}
			
		
		}
    }

    @And("^data from Documents page should be stored in Excel for (.+) in Update FA Flow$")
    public void data_from_documents_page_should_be_stored_in_excel_for_in_update_fa_flow(String mandatorydetails) throws IOException {
    	if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(documentsPage.areDocumentsAvailableinUI()) {
			
			
			   int columnIndex = 33;
			   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			   int flowPageDataRowIndex = rowIndex+3;
			   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			   
			   if(label == "" || label.contains("grey - Approver Name"))
					label = "isEmpty";
				while (label != "isEmpty") {
											
						if(label.contains("ignore") || label.contains("NIVDP")) {
							columnIndex++;
							
				    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
				    			
				    			if(label == "")
				    				label = "isEmpty";
						}else {
							
							
							attributeValue = getDataFromDocumentsPage(label);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
									//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 3).toString();
							
							columnIndex++;
								
								label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
										//(String) exlObj.getCellData(sheet, rownum, 0).toString();
								
								if(label == "" || label.contains("grey - Approver Name"))
									label = "isEmpty";
						
						}
				}
			}
    }
    
    @And("^Data prepopulated in Documents page should match with Flow Page Data in Update FA flow for (.+)$")
    public void data_prepopulated_in_documents_page_should_match_with_flow_page_data_in_update_fa_flow_for(String mandatorydetails) {
        
    }
    
    @And("^User Updates the Existing documents in Documents Page in Update FA Flow$")
    public void user_updates_the_existing_documents_in_documents_page_in_update_fa_flow() {
        
    	int docCount = documentsPage.getcountofDocuments();
    	
    	for (int i = 0; i < docCount; i++) {
			documentsPage.updateExistingDocumentComment(i);
		}
    }
     
    @Then("^User should able to see the records for FA update in DB in audit table attribute wise having previous and new values with (.+)$")
    public void user_should_be_able_to_see_records_for_FA_update_in_DB_in_audit_table_attributewise_having_previous_and_new_values(String mandatoryDetails) throws SQLException {
        
    	documentsPage.verifyAttributeValuesofEnterDocumentLinkswithDb(mandatoryDetails,"ADD","document_type");
    	documentsPage.verifyAttributeValuesofEnterDocumentLinkswithDb(mandatoryDetails,"ADD","document_description");
    	documentsPage.verifyAttributeValuesofEnterDocumentLinkswithDb(mandatoryDetails,"ADD","document_link");
    	documentsPage.verifyAttributeValuesofEnterDocumentLinkswithDb(mandatoryDetails,"DELETE","document_type");
    	documentsPage.verifyAttributeValuesofEnterDocumentLinkswithDb(mandatoryDetails,"DELETE","document_description");
    	documentsPage.verifyAttributeValuesofEnterDocumentLinkswithDb(mandatoryDetails,"DELETE","document_link");
    }
}
