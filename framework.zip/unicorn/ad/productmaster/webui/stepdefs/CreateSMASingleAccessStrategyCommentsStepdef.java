package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyCommentsPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreateSMASingleAccessStrategyCommentsStepdef {

	CreateSMASingleAccessStrategyCommentsPage commentsPage = new CreateSMASingleAccessStrategyCommentsPage("AD_PM_CreateSMASingleAccessStrategyCommentsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	
	@And("^User inputs (.+) in Comments Page$")
    public void user_inputs_in_comments_page(String mandatorydetails) throws IOException {
		
		commentsPage.isUserOnCommentsPage();
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		
		//String environment = property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment;
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		
		String commentType = (String) exlObj.getCellData(sheet, rowIndex, 78);
		String comment = (String) exlObj.getCellData(sheet, rowIndex, 79);
		//String documentComment = (String) exlObj.getCellData(sheet, rowIndex, 76);
		exlObj.closeWorkBook();
		
		
		
		
		if(commentType != "" && comment != "") {
			
			if(commentType.contains(",") && comment.contains(",")) {
				String[] comType = commentType.split(",");
				String[] com = comment.split(",");
				
				
				int comTypeSize = comType.length;
				int comSize = com.length;
				int size = Math.min(comTypeSize, comSize);
				int i =0;
				
					while(size > 0) {
						commentsPage.selectCommentsType(comType[i]);
						commentsPage.enterCommentsComment(com[i]);
						commentsPage.clickOnAddCommentsButton();
						size--;
						i++;
						if(size > 0) {
						commentsPage.clickOnAddAnotherComment();
						}
					}
				
		        
			}
			else {
			
				commentsPage.selectCommentsType(commentType);
				commentsPage.enterCommentsComment(comment);
				commentsPage.clickOnAddCommentsButton();
			}
			
		
		}
    }
	
	@When("User clicks on Next in Comments page")
	public void user_clicks_on_Next_in_Comments_page() {
		commentsPage.clickOnNext();
	}
}
