package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.BenchmarkSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class BenchmarkSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	BenchmarkSortAndFilterPage benchmarkSortAndFilterPage = new BenchmarkSortAndFilterPage(
			"AD_PM_BenchmarkSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/BenchmarkSortAndFilter.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError, countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	WebElement myElement, myElement2;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_BenchmarkSortAndFilterPage"));
	
	@When("^User enter valid (.+) in global search box for Benchmark$")
	public void user_enter_valid_in_global_search_box_for_benchmark(String mandatorydetails) throws Throwable {

		Assert.assertTrue(landingPage.isUserOnLandingPage());
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String BenchmarkSearchValue = (String) exlObj.getCellData(sheet, rowIndex, 2);
		System.out.println(BenchmarkSearchValue);
		exlObj.closeWorkBook();
		if (BenchmarkSearchValue != "") {
			benchmarkSortAndFilterPage.searchBenchmarkValue(BenchmarkSearchValue);
		}
		Reporter.addScreenCapture();
	}

	@And("^user clicks on \"([^\"]*)\" on landing page for Benchmark$")
	public void user_clicks_on_something_on_landing_page_for_benchmark(String strArg1) throws Throwable {
		benchmarkSortAndFilterPage.clickOnSeeAllResultsForBenchmarkLayout();
		Assert.assertTrue(landingPage.isUserOnLandingPage());
	}

	@And("^user is able to see search results in \"([^\"]*)\" tab under Benchmark accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_benchmark_accordion(String strArg1)
			throws Throwable {
		benchmarkSortAndFilterPage.verifyTheSearchedResultInAllTabForBenchmark();

	}

	@And("^user click on \"([^\"]*)\" tab on landing page for Benchmark$")
	public void user_click_on_something_tab_on_landing_page_for_benchmark(String strArg1) throws Throwable {
		Assert.assertTrue(landingPage.isUserOnLandingPage());
		benchmarkSortAndFilterPage.verifyAndClickBenchmarkTab();
	}

	@Then("^User should be able to search records for Benchmark View using the global search box on landing page$")
	public void user_should_be_able_to_search_records_for_benchmark_view_using_the_global_search_box_on_landing_page()
			throws Throwable {
		benchmarkSortAndFilterPage.verifySearchedGridViewDisplay();
	}

	@And("^User able to see searched grid view data for Benchmark grid view$")
	public void user_able_to_see_searched_grid_view_data_for_benchmark_grid_view() throws Throwable {
		String gridCountBeforeCondition = benchmarkSortAndFilterPage
				.verifyTheGridCountBeforeApplyFilterAndSortCondition();
		// String gridCountBeforeCondition =
		// BenchmarkSortAndFilterPage.gridCountAfterGlobalSearch;
		int beforeApplyCondition = Integer.parseInt(gridCountBeforeCondition);
		if (beforeApplyCondition == 1)
			benchmarkSortAndFilterPage.verifyTheNoResultsOnGridView();
	}

	@And("^User able to see searched grid view data for Benchmark$")
	public void user_able_to_see_searched_grid_view_data_for_benchmark() throws Throwable {

		Assert.assertTrue(landingPage.isUserOnLandingPage());
		String gridCountBeforeCondition = benchmarkSortAndFilterPage
				.verifyTheGridCountBeforeApplyFilterAndSortCondition();
		// String gridCountBeforeCondition =
		// BenchmarkSortAndFilterPage.gridCountAfterGlobalSearch;
		int beforeApplyCondition = Integer.parseInt(gridCountBeforeCondition);
		if (beforeApplyCondition == 1)
			benchmarkSortAndFilterPage.verifyTheNoResultsOnGridView();
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design for Benchmark$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design_for_benchmark(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			benchmarkSortAndFilterPage.mouseHoverOnGridViewLabels(benchmarkSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			Assert.assertTrue(landingPage.isSortIconDisplayedInUIforEntity(entity.get(i)));
			/*
			 * benchmarkSortAndFilterPage.verifyGridViewLabelsWithSortIcons(
			 * benchmarkSortAndFilterPage.findElementByDynamicXpath(
			 * "(//span[contains(text(),'" + entity.get(i) +
			 * "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			 */
			Reporter.addScreenCapture();
		}
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for Benchmark$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_benchmark(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			benchmarkSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					benchmarkSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for Benchmark$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_benchmark(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			benchmarkSortAndFilterPage.mouseHoverOnGridViewLabels(benchmarkSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			Assert.assertTrue(landingPage.isSortIconDisplayedInUIforEntity(entity.get(i)));
			landingPage.clickOnSortIconForEntity(entity.get(i));
			/*
			 * benchmarkSortAndFilterPage.clickOnSortIcon(
			 * benchmarkSortAndFilterPage.findElementByDynamicXpath(
			 * "(//span[contains(text(),'" + entity.get(i) +
			 * "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			 */
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for Benchmark$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_benchmark() throws Throwable {
		String value = benchmarkSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = BenchmarkSortAndFilterPage.ascSortValue;
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for Benchmark$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_benchmark(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			benchmarkSortAndFilterPage.mouseHoverOnGridViewLabels(benchmarkSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			benchmarkSortAndFilterPage.clickOnSortIcon(
					benchmarkSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for Benchmark$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_benchmark() throws Throwable {
		String value = benchmarkSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = BenchmarkSortAndFilterPage.descSortValue;
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for Benchmark$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_benchmark(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			benchmarkSortAndFilterPage.mouseHoverOnGridViewLabels(benchmarkSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			benchmarkSortAndFilterPage.clickOnSortIcon(
					benchmarkSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for Benchmark$")
	public void user_should_able_to_sort_the_records_with_default_order_for_benchmark() throws Throwable {
		String value = benchmarkSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = BenchmarkSortAndFilterPage.defaultSortValue;
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to click on the filter icon for below column for Benchmark$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_benchmark(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			benchmarkSortAndFilterPage.clickOnFilterIconForGridView(
					benchmarkSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to validate the filter condition all options for Benchmark$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_benchmark(List<String> entity)
			throws Throwable {
		benchmarkSortAndFilterPage.clickOnFilterCondition();
		for (int i = 0; i < entity.size(); i++) {
			benchmarkSortAndFilterPage
					.verifyValueOfFilterCondition(benchmarkSortAndFilterPage.findElementByDynamicXpath(
							"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to see tab count as per searched keyword for before any condition for Benchmark$")
	public void user_able_to_see_tab_count_as_per_searched_keyword_for_before_any_condition_for_benchmark()
			throws Throwable {
		String beforeApplyFilterValue = benchmarkSortAndFilterPage
				.verifyTheBenchmarkGridCountAfterApplyFilterConditionOnTab();
		// String beforeApplyFilterValue =
		// BenchmarkSortAndFilterPage.tabCountAfterCondition;
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);

	}

	@And("^User able to select the (.+) from filter condition for Benchmark$")
	public void user_able_to_select_the_from_filter_condition_for_benchmark(String filtercondition) throws Throwable {
		benchmarkSortAndFilterPage.clickOnFilterCondition();
		benchmarkSortAndFilterPage
				.clickOnFilterConditionForBenchmarkGridView(benchmarkSortAndFilterPage.findElementByDynamicXpath(
						"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for Benchmark$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_benchmark(String filterconditionvalue)
			throws Throwable {
		benchmarkSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button on Benchmark grid view$")
	public void user_able_to_click_on_the_apply_button_on_benchmark_grid_view() throws Throwable {
		benchmarkSortAndFilterPage.clickOnApplyFilterIconForBenchmarkGridView();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on Benchmark grid view$")
	public void user_should_able_to_verify_the_grid_count_on_benchmark_grid_view() throws Throwable {
		String countTabAfterFilter = benchmarkSortAndFilterPage
				.verifyTheBenchmarkGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// benchmarkSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = benchmarkSortAndFilterPage.verifyTheBenchmarkGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition/10; i++) {
				action.scrollToBottom();
				// Action.pause(1000);
				String presentGridAllData = benchmarkSortAndFilterPage.verifyTheBenchmarkGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			benchmarkSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
			Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
					"The tab count and grid view count mismatch");
		}
	}

	@And("^User should able to verify the Tab count on Benchmark grid view$")
	public void user_should_able_to_verify_the_tab_count_on_benchmark_grid_view() throws Throwable {
		String countTabAfterFilter = benchmarkSortAndFilterPage
				.verifyTheBenchmarkGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// benchmarkSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = benchmarkSortAndFilterPage.verifyTheBenchmarkGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= beforeApplyFiltertabCountValue; i++) {
				action.scrollToBottom();
				// Action.pause(1000);
				String presentGridAllData = benchmarkSortAndFilterPage.verifyTheBenchmarkGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			benchmarkSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The tab count and grid view mismatch");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Reset Button on Benchmark grid view$")
	public void user_able_to_click_on_the_reset_button_on_benchmark_grid_view() throws Throwable {
		benchmarkSortAndFilterPage.clickOnApplyFilterIconForBenchmarkGridViewForReset();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button on Benchmark grid view$")
	public void user_able_to_click_on_the_cancel_button_on_benchmark_grid_view() throws Throwable {
		benchmarkSortAndFilterPage.clickOnApplyFilterIconForBenchmarkGridViewForCancel();
		Reporter.addScreenCapture();
	}

	@And("^User able to select the (.+) from filter date condition for Benchmark$")
	public void user_able_to_select_the_from_filter_date_condition_for_benchmark(int filtercondition) throws Throwable {
		action.pause(4000);
		myElement = benchmarkSortAndFilterPage.getDynamicElementFromShadowRoot(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > ul > div.os-padding > div > div > li:nth-child("
						+ filtercondition + ") > span')");
		action.highligthElement(myElement);
		action.click(myElement);

		if (filtercondition == 6) {
			action.pause(2000);
			myElement = benchmarkSortAndFilterPage.getDynamicElementFromShadowRoot(
					"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-range.date-picker-wrapper > div > div > div.pmu-days >div:nth-child(5)')");
			action.highligthElement(myElement);
			action.click(myElement);
			action.pause(1000);
			myElement2 = benchmarkSortAndFilterPage.getDynamicElementFromShadowRoot(
					"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-range.date-picker-wrapper > div > div > div.pmu-days >div:nth-child(25)')");
			action.scrollToElement(myElement2);
			action.highligthElement(myElement2);
			action.click(myElement2);
		}

	}

	@And("^User able to click on Date the Apply Button on Benchmark grid view$")
	public void user_able_to_click_on_date_the_apply_button_on_benchmark_grid_view() throws Throwable {
		action.pause(2000);
		myElement = benchmarkSortAndFilterPage.getDynamicElementFromShadowRoot(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(3)')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@And("^User able to click on Date the Reset Button on Benchmark grid view$")
	public void user_able_to_click_on_date_the_reset_button_on_benchmark_grid_view() throws Throwable {
		action.pause(2000);
		myElement = benchmarkSortAndFilterPage.getDynamicElementFromShadowRoot(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(1)')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@And("^User able to click on Date the Cancel Button on Benchmark grid view$")
	public void user_able_to_click_on_date_the_cancel_button_on_benchmark_grid_view() throws Throwable {
		action.pause(2000);
		myElement = benchmarkSortAndFilterPage.getDynamicElementFromShadowRoot(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(2)')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@When("^User enter valid (.+) in search box for Benchmark$")
	public void user_enter_valid_in_search_box_for_benchmark(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String BenchmarkSearchValue = (String) exlObj.getCellData(sheet, rowIndex, 2);
		System.out.println(BenchmarkSearchValue);
		exlObj.closeWorkBook();
		if (BenchmarkSearchValue != "") {
			landingPage.enterSearchToken(BenchmarkSearchValue);
			landingPage.clickOnSearchIcon();
		}
		Reporter.addScreenCapture();
	}

}
