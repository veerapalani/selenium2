package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class UpdateBenchmarkConfirmationStepDef {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateBenchmarkConfirmationPage"));
	 @Then("^User should be able to see the confirmation message in Update Benchmark Confirmation page$")
	    public void user_should_be_able_to_see_the_confirmation_message_in_update_benchmark_confirmation_page() throws Throwable {
		 action.getElement("Confirmation Message").isDisplayed();
		 Reporter.addStepLog("Able to see the confirmation message");
		 Reporter.addScreenCapture();
	 }
	 
	 @And("^User clicks on Back Link on Confirmation Benchmark page$")
	    public void user_clicks_on_back_link_on_Confirmation_Benchmark_page() throws Throwable {
		 action.click(action.getElement("Back Link"));
		 Reporter.addStepLog("clicked on Back Link");

	    }
	 
	
	 @And("^Your request has been submitted text should be displayed in Black color on Confirmation Page$")
	    public void  Your_request_has_been_submitted_text_should_be_displayed_in_Black_color_on_Confirmation_Page() throws Throwable {
	 }
	 
	 @Then("^User should be able to see the Confirmation header in Update Benchmark Confirmation page$")
	    public void user_should_be_able_to_see_the_review_header_in_update_Benchmark_Confirmation_page() throws Throwable {
	       Assert.assertTrue(action.getElement("Confirmation Header").isDisplayed());
	    }
	 
}
