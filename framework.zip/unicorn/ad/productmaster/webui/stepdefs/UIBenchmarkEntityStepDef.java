package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class UIBenchmarkEntityStepDef {
	PMPageGeneric BenchmarkEntity=new PMPageGeneric("AD_PM_BenchmarkEntityPage");
	String activeLink = "Benchmark";
	String expectedColorCode,xpath;
	String pageURL = "http://10.49.116.4:8080/pmui/?#/benchmark";
	List<WebElement> listOfElements,listOfElements2 = new ArrayList<WebElement>();
	Action action =  new Action(SQLDriver.getEleObjData("AD_PM_BenchmarkEntityPage"));
	@Then("^Benchmark Link should be active$")
    public void Benchmark_link_should_be_something() throws Throwable {
        BenchmarkEntity.verifyAttribute("true", activeLink, "selected");
    }
    

    
    @Then("^User should be able to see \"([^\"]*)\" in \"([^\"]*)\" on Benchmark Entity page$")
    public void user_should_be_able_to_see_something_on_Benchmark_Entity_page(String list1, String key) throws Throwable {
    	String[] listArray = list1.split(", ");
    	listOfElements =  BenchmarkEntity.getElements(key);
    	for(int i=0;i<listArray.length;i++) {
    		BenchmarkEntity.verifyTextInListOfElements(listArray[i], listOfElements);
    		Reporter.addStepLog(listArray[i]+" is displaying in " + key);
    	}
    }

    @And("^Order of the \"([^\"]*)\" should be \"([^\"]*)\" on Benchmark Entity page$")
    public void order_of_the_something_should_be_something_on_Benchmark_Entity_page(String key, String list1) throws Throwable {
    	String[] listArray = list1.split(", ");
     	listOfElements =  BenchmarkEntity.getElements(key);
     	for(int i=0;i<listArray.length;i++) {
     		Assert.assertEquals( listOfElements.get(i).getText(),listArray[i]);
     		Reporter.addStepLog(listOfElements.get(i).getText()+" is the "+i+" element in " + key);
     	}
    }

    @And("^All the \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Benchmark Entity page$")
    public void all_the_something_should_be_displayed_in_something_color_on_Benchmark_Entity_page(String key, String color) throws Throwable {
        listOfElements = BenchmarkEntity.getElements(key);
        expectedColorCode = Action.getTestData(color);
        for(int i=0;i<listOfElements.size();i++) {
        	BenchmarkEntity.verifyColor(listOfElements.get(i), expectedColorCode);
        }
        
        
    }
    @Then("^User should be able to see \"([^\"]*)\" in every row of \"([^\"]*)\" on Benchmark Entity page$")
    public void user_should_be_able_to_see_something_in_every_row_of_something_on_Benchmark_Entity(String insideElementKey, String key) throws Throwable {
    	listOfElements = BenchmarkEntity.getElements(key);        
        for(int i=1;i<=Math.min(listOfElements.size(),10);i++) {
        	xpath="//tr[@class='divider divider-top divider-03 divider-color-03']["+i+"]//wf-icon[@name='ellipsis-v-solid']";
        	BenchmarkEntity.verifyElement(BenchmarkEntity.findElementByDynamicXpath(xpath));
        	Reporter.addStepLog("verified "+insideElementKey+ " for element no "+(i));
        	BenchmarkEntity.scrollByPixel(100);
        }
    }
    
    @Then("^User should be able to see the Following \"([^\"]*)\" while \"([^\\\"]*)\" on the Ellipse Icon in every row of \"([^\"]*)\" on Benchmark Entity page$")
    public void user_should_be_able_to_see_the_following_something_while_hovering_on_the_something_in_every_row_of_something_on_Benchmark_entity_page(String options, String insideElementKey, String strArg2) throws Throwable 
    {
    	Thread.sleep(3000);
    	
    		
    			BenchmarkEntity.hoverOnElement(BenchmarkEntity.getElementFromShadowRoot(insideElementKey));
    			Thread.sleep(1000);
    			BenchmarkEntity.verifyElement(options);
    			Reporter.addStepLog("verified "+options+ " for element");
    			BenchmarkEntity.scrollByPixel(100);  
    	
//    	String threedotHovering = "return document.querySelector('body > wf-bridge > product-master > div > div > section > table > tbody > tr:nth-child(1) > td:nth-child(2) > button > wf-icon').shadowRoot.querySelector('div > svg')";
//    	   WebElement elethreedotHovering = (WebElement) action.executeJavaScript(threedotHovering);
//    			  Thread.sleep(1000);
//    			   Assert.assertTrue(elethreedotHovering.isDisplayed());
//    	   Actions actElement = new Actions(WebDriverManager.getDriver());
//    	    actElement.moveToElement(elethreedotHovering).build().perform();
//    	    BenchmarkEntity.verifyElement(options);
//    	    Reporter.addStepLog("verified "+options+ " for element");
//    	    Thread.sleep(1000);
    	}	
       

    @And("^the \"([^\"]*)\" should contain the following options on Benchmark Entity page$")
    public void the_something_should_contain_on_Benchmark_Entity_page( String key, List<String> options) throws Throwable {
        listOfElements = BenchmarkEntity.getElements(key);
        for (int i = 0; i < listOfElements.size(); i++) {
        	for (int j=0;j<options.size();j++)
			BenchmarkEntity.verifyInsideElement(listOfElements.get(i),options.get(j));
		}
    }
    @Then("^User should be able to see the \"([^\"]*)\" header on Benchmark Entity page$")
    public void user_should_be_able_to_see_the_something_header_on_benchmark_entity_page(String key) throws Throwable {
        BenchmarkEntity.verifyHeader(key);
    }
    @Then("^User should be able to see the \"([^\"]*)\" at the \"([^\"]*)\" on Benchmark Entity page$")
    public void user_should_be_able_to_see_the_something_at_the_something_on_Benchmark_entity_page(String key, String shadowRootKey) throws Throwable {
    	BenchmarkEntity.verifyElement(BenchmarkEntity.fetchElementFromShadowRoot(key, shadowRootKey));
    }

    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Benchmark Entity page$")
    public void something_should_be_displayed_in_something_color_on_Benchmark_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	BenchmarkEntity.verifyColor(key,expectedColorCode);
    	
    }

    @And("^\"([^\"]*)\" should have \"([^\"]*)\" background color on Benchmark Entity page$")
    public void something_should_have_something_background_color_on_Benchmark_entity_page(String key, String backgroundColor) throws Throwable {
    	expectedColorCode = Action.getTestData(backgroundColor);
    	BenchmarkEntity.verifyBackgroundColor(key,expectedColorCode);
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" on Benchmark Entity page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_on_Benchmark_entity_page(String ghostText, String searchBox) throws Throwable {
    	BenchmarkEntity.verifyGhostText(ghostText, searchBox);
    }
    
    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Benchmark Entity page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_inside_benchmark_entity_page(String ghostText, String searchBox) throws Throwable {
        BenchmarkEntity.verifyGhostText(ghostText, BenchmarkEntity.getElementFromShadowRoot(searchBox));
        Reporter.addScreenCapture();
    }

    @And("^User should be able to see the \"([^\"]*)\" on Benchmark Entity page$")
    public void user_should_be_able_to_see_the_something_on_Benchmark_entity_page(String key) throws Throwable {
    	BenchmarkEntity.verifyElement(key);
    }

    @And("^User should be able to see the \"([^\"]*)\" inside Benchmark Entity page$")
    public void user_should_be_able_to_see_the_something_inside_benchmark_entity_page(String key) throws Throwable {
    	BenchmarkEntity.verifyElementFromShadowRoot(key);
    }

    @And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Benchmark Entity page$")
    public void that_something_should_be_displayed_in_something_color_on_Benchmark_entity_page(String key, String expectedColor) throws Throwable {
    	expectedColorCode = Action.getTestData(expectedColor);
    	BenchmarkEntity.verifyCurrentElementColor(expectedColorCode);
    }
    
    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Benchmark Entity page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_benchmark_entity_page_should_contain_all_the_following_options(String clickKey, String key, List<String> items) throws Throwable {
        BenchmarkEntity.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = BenchmarkEntity.getElementsFromShadowRoot(key);
   		 Reporter.addStepLog(listOfElements.get(0).getText());
   	 BenchmarkEntity.verifyTextInListOfElements( items.get(i),listOfElements); 
   	 }
    }
    
    @And("^The \"([^\"]*)\" on the Benchmark Entity page should contain all the following options$")
    public void the_something_on_the_Benchmark_Entity_page_should_contain_all_the_following_options(String key,List<String> items) throws Throwable {
    	 for(int i=0;i<items.size();i++) {
    		 Reporter.addStepLog("verifying for "+items.get(i));
    		 listOfElements = BenchmarkEntity.getElementsFromShadowRoot(key);
    		 Reporter.addStepLog(listOfElements.get(0).getText());
    	 BenchmarkEntity.verifyTextInListOfElements( items.get(i),listOfElements); 
    	 }
    }
    
    @And("^user hover over the \"([^\"]*)\" of first element of \"([^\"]*)\" on Benchmark Entity page$")
    public void user_hover_over_the_something_of_first_element_of_something_on_benchmark_entity_page(String insideElementKey, String parentElementKey) throws Throwable {
    	listOfElements = BenchmarkEntity.getElements(insideElementKey);
    			BenchmarkEntity.hoverOnElement(listOfElements.get(0));
//    	Reporter.addStepLog(listOfElements.get(1).getText());
    			Reporter.addStepLog("hovering on "+insideElementKey);
    		
    }
    
    @And("^user clicks the \"([^\"]*)\" on Benchmark Entity page$")
    public void user_clicks_the_something_on_benchmark_entity_page(String key) throws Throwable {
        BenchmarkEntity.clickOnLink(key);
    }
    
    @Then("^user should be able to go to Benchmark Entity page$")
    public void user_should_be_able_to_go_to_strategy_entity_page() {
        BenchmarkEntity.verifyPageURL(pageURL);
        Reporter.addScreenCapture();
    }
    
    @And("^following option should be displayed$")
	 public void following_option_should_be_displayed(List<String> options) {
    	
		 listOfElements = BenchmarkEntity.getElements("hover options");
		 Reporter.addStepLog("SIZE: "+listOfElements.size());
	       for(int i=0;i<options.size();i++)
	    	   {
	    	   Reporter.addStepLog("<b>Actual: </b>"+listOfElements.get(i).getText()
	    			   +" | <b>Expected: </b>"+options.get(i).toString());
	    	   
	    	   BenchmarkEntity.verifyTextInListOfElements(options.get(i), listOfElements);
	    	   }
	 }
    
    @Then("^User should be able to see only \"([^\"]*)\" \"([^\"]*)\" on Benchmark Entity Page$")
    public void user_should_be_able_to_see_only_something_something_on_program_entity_page(String numberOfItems, String key) throws Throwable {
        listOfElements = BenchmarkEntity.getElements(key);
        Assert.assertEquals(Integer.parseInt(numberOfItems), listOfElements.size());
        Reporter.addStepLog("verified that "+numberOfItems+" "+key+" present");
    }
    
    @Then("^\"([^\"]*)\" should not be displayed in \"([^\"]*)\" on Benchmark Entity Page$")
    public void something_should_not_be_displayed_in_something_on_program_entity_page(String item, String key) throws Throwable {
    	listOfElements = BenchmarkEntity.getElements(key);
    	BenchmarkEntity.verifyTextNotPresentInListOfElements(item, listOfElements);
        Reporter.addStepLog("verified that "+item+" is not present in "+key);
    }
    

}
