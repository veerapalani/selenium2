package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyEnterStrategyDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStartegyReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.SaveAsDraftAllUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;

public class ETFSaveAndPrintValidation {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	String expectedColorCode;
	String xpath, myValue;
	Select dropdown;
	Boolean myFlag;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/smaAccess/view/2053002";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/ETFOperations.xlsx";
	String excelFilePath1 = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategyvestmark_1.xlsx";
	CreatePMPStrategyEnterStrategyDetailsPage strategyDetailsPage = new CreatePMPStrategyEnterStrategyDetailsPage("AD_PM_UpdateStrategyUIPage");
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	ExcelUtils exlObj1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath1);
	RejectedStartegyReviewPage rw = new RejectedStartegyReviewPage("AD_PM_RejectedStartegyReviewPage");
	PMPageGeneric generic = new PMPageGeneric("Genesis");
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	UpdateStrategyPage UpdateStrategyUI = new UpdateStrategyPage();
	WebElement myElement, myElement1,myElement2;
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_LandingPage"));

	List<String> list = new ArrayList<String>();
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");

	
	SaveAsDraftAllUIPage ho = new SaveAsDraftAllUIPage();


	    @And("^the user navigates into the (.+) of his choice from the accordion$")
	    public void the_user_navigates_into_the_of_his_choice_from_the_accordion(String entity) throws Throwable {
	    	 
			 while(true)
			 {
			 try
			 {
			 myElement1 =(WebElement)action.executeJavaScript("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
				while (myElement1.isDisplayed()) {
			 action.highligthElement(myElement1);
			 myElement1.click();
			 Thread.sleep(2000);
				}}
			 catch (Throwable e)
			 {
			 break;
			 }
			 }



			 Thread.sleep(3000);

			 while(true)
			 {
			 try
			 {
			 myElement1 = (WebElement)action.executeJavaScript("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
			 action.highligthElement(myElement1);
			 myElement1.click();
			 Thread.sleep(2000);



			 }
			 catch (Throwable e)
			 {
			 break;
			 }
			 }
			 myElement = ho.findElementByDynamicXpath("//brml-tab-button[@tab=\""+entity+"\"]");
			 Thread.sleep(2000);
			 myElement.click();
			 Reporter.addStepLog("Draft tab is cicked");
			 action.waitForPageLoad();
			 Thread.sleep(3000);
	    	
	    }
	    

	    @Then("^user provides a legible (.+) as an attribute to search at the global search for a given (.+)$")
	    public void user_provides_a_legible_as_an_attribute_to_search_at_the_global_search_for_a_given(String searchcode, String entity) throws Throwable {
	    	Thread.sleep(5000);
			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchcode);

			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			searchcode = myValue;
			System.out.println(myValue);

			Boolean compareBoolean = action.isPresent("js",
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");

			if (compareBoolean) {

				Thread.sleep(5000);
				myElement = (WebElement) action.executeJavaScript(
						"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
				myElement.click();
			}

			Thread.sleep(5000);

			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
			Thread.sleep(5000);
			myElement.click();
			action.sendkeysClipboard(myElement, myValue);
			Thread.sleep(2000);
			int i = 0;

			while (i < 5) {
				myElement.sendKeys(Keys.ENTER);
				i++;
			}
			Thread.sleep(2000);
	    	
	    }  
	    @When("^the user clicks on the cancel button in etf$")
	    public void the_user_clicks_on_the_cancel_button_in_etf() throws Throwable {
	    	String db2 = "return document.querySelector(\"brml-button[proto='button']\")";
	    	
	    	WebElement ele = (WebElement) action.executeJavaScript(db2);
	    	action.scrollToElement(ele);
	    	action.highligthElement(ele);
	    	Reporter.addCompleteScreenCapture();
	    	action.click(ele);
	    	Thread.sleep(5000);
	    }
	    
	    @Then("^user subsequently saves the PDF file$")
	    public void user_subsequently_saves_the_pdf_file() throws Throwable {
	    	generic.switchtoWindowAndSaveThePdf();
	    }
	    }
	    
	    
	    

	    

