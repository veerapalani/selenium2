package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.framework.utils.Action;
public class ReviewBenchmarkStepDef {
	CreateBenchmarkReviewPage createbenchmarkreviewpage = new CreateBenchmarkReviewPage("AD_PM_ReviewBenchmarkPage");
	PMPageGeneric reviewbenchmark = new PMPageGeneric("AD_PM_ReviewBenchmarkPage");
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	
	@Then("^User should be able to see the \"([^\"]*)\" on Benchmark Review page$")
    public void user_should_be_able_to_see_the_something_on_benchmark_review_page(String Key) throws Throwable {
		reviewbenchmark.verifyElement(Key);
    }
	@And("^User clicks on the \"([^\"]*)\" on Benchmark Review Page$")
    public void user_clicks_on_the_something_on_benchmark_review_page(String key) throws Throwable {
		reviewbenchmark.clickOnLink(key);
		Reporter.addScreenCapture();
    }
	@And("^The text written in \"([^\"]*)\" should match with the value of \"([^\"]*)\" attribute on Benchmark Review page$")
    public void the_text_written_in_something_should_match_with_the_value_of_something_attribute_on_benchmark_review_page(String actualkey, String expectedkey) throws Throwable {
		Assert.assertEquals(reviewbenchmark.getElementFromShadowRoot(actualkey).getText(),
				reviewbenchmark.getElementFromShadowRoot(expectedkey).getText());
    }
	
	@Then("^the attributes on Benchmark Review Page should contain one of the below following values$")
    public void the_attributes_on_benchmark_review_page_should_contain_one_of_the_below_following_values(List<List<String>> attributeValuePair) throws Throwable {
String myValue=null;
    	
    	for(int i=0;i<attributeValuePair.size();i++) {
    	String xpath="//small[contains(text(),'"+attributeValuePair.get(i).get(0)+"')]/ancestor::p/following-sibling::span";
    	myValue=reviewbenchmark.findElementByDynamicXpath(xpath).getText();
    	Reporter.addStepLog("The value for "+attributeValuePair.get(i).get(0)+" is "+myValue);
    	String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
    	for(int j=0;j<listOfValues.length;j++) {
    	if(myValue.equals(listOfValues[j]))
    		{Assert.assertTrue(true);
    		break;}
    	
    	else 
    		Assert.assertFalse(false);
    	
    	}
        } 
    }
	@Then("^the attributes on Create New Benchmark Review Page should contain one of the below following values$")
    public void the_attributes_on_create_new_benchmark_review_page_should_contain_one_of_the_below_following_values(List<List<String>> attributeValuePair) throws Throwable {
		String myValue=null;
		  for(int i=0;i<attributeValuePair.size();i++) {
		    	String xpath="//label[contains(text(),'"+attributeValuePair.get(i).get(0)+"')]/ancestor::div/following-sibling::div";
		    	myValue=createbenchmarkreviewpage.findElementByDynamicXpath(xpath).getText();
		    	Reporter.addStepLog("The value for "+attributeValuePair.get(i).get(0)+" is "+myValue);
		    	String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
		    	for(int j=0;j<listOfValues.length;j++) {
		    	if(myValue.equals(listOfValues[j]))
		    		{Assert.assertTrue(true);
		    		break;}
		    	else 
		    		Assert.assertFalse(false);
		    	
		    	}
		        }
		    }
    
	@Then("^User should be able to see following attributes on Create Benchmark Review Page$")
    public void user_should_be_able_to_see_following_attributes_on_create_benchmark_review_page(List<String> entity) throws Throwable {
		for(int i =0;i<entity.size();i++) {
			createbenchmarkreviewpage.verifyWebElementinCreateBenchmarkReviewPage(createbenchmarkreviewpage.findElementByDynamicXpath("//label"));
				Reporter.addStepLog("able to see "+entity.get(i)+" header");
				}
				Reporter.addScreenCapture();
    }
	@And("^User clicks on Submit Button on Create New Benchmark Review Page$")
    public void user_clicks_on_submit_button_on_create_new_benchmark_review_page() throws Throwable {
		createbenchmarkreviewpage.verifysubmitButtoninCreateBenchmarkReviewPage();
    }


	@Then("^User should be able to see the Timestamp on Create New Benchmark Review page$")
    public void user_should_be_able_to_see_the_timestamp_on_create_new_benchmark_review_page() throws Throwable {
		createbenchmarkreviewpage.verifytimestampinCreateBenchmarkReviewPage();
    }
	@And("^User clicks on the Back Link on Create New Benchmark Review Page$")
    public void user_clicks_on_the_back_link_on_create_new_benchmark_review_page() throws Throwable {
		createbenchmarkreviewpage.clickOnbacklinkoncreatebenchmarkreviewpage();
    }
	@And("^User clicks on the Previous button on Create New Benchmark Review Page$")
    public void user_clicks_on_the_previous_button_on_create_new_benchmark_review_page() throws Throwable {
		createbenchmarkreviewpage.clickOnpreviousbuttononcreatebenchmarkreviewpage();
    }
	@And("^User clicks on the (.+) attributes on Create New Benchmark Review Page$")
    public void user_clicks_on_the_attributes_on_create_new_benchmark_review_page(String key) throws Throwable {
		createbenchmarkreviewpage.clickOntheelementsoncreatebenchmarkreviewpage(key);
    }
	@Then("^user should be able to see the following attributes on Benchmark Review page$")
    public void user_should_be_able_to_see_the_following_attributes_on_benchmark_review_page(List<String> attributes) throws Throwable {
		listOfElements = reviewbenchmark.getElements("Attributes_ReviewBenchmarkPage");
	       for(int i=0;i<attributes.size();i++)
	    	   {
	    	   reviewbenchmark.verifyTextInListOfElements(attributes.get(i), listOfElements);
	    	   Reporter.addStepLog("verified for "+attributes.get(i)+" attribute");
	    	   }
    }
}
