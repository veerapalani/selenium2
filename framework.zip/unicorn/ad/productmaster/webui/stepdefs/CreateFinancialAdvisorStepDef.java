package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateFinancialAdvisorPage;
import qa.unicorn.ad.productmaster.webui.pages.CreatenewFAPage;

public class CreateFinancialAdvisorStepDef {
	WebElement Element, myElement, myElement2;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateFAPage"));
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateFA.xlsx";
	String option, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	CreateFinancialAdvisorPage createobj = new CreateFinancialAdvisorPage("AD_PM_CreateFAPage");
	CreatenewFAPage createobj1 = new CreatenewFAPage("AD_PM_CreateEnterFAPage");

	@Then("^User should be able to see the Create Financial Advisor Wizard on landing screen$")
	public void user_should_be_able_to_see_the_create_financial_advisor_wizard_on_landing_screen() throws Throwable {
	}

	@When("^User enters (.+) in all the fields for FA$")
	public void user_enters_in_all_the_fields_for_fa(String option) throws Throwable {
		if (option.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
		String BranchManagerName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String FAName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String FAEmail = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String FAId = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String RecruitHireDate = (String) exlObj.getCellData(sheet, rowIndex, 5).toString();
		String PriorFirm = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String PreviouslyApprovedForFADiscretionary = (String) exlObj.getCellData(sheet, rowIndex, 7);
		String FADiscretionaryProgram = (String) exlObj.getCellData(sheet, rowIndex, 8);
		String LengthOfSeries7Registration = (String) exlObj.getCellData(sheet, rowIndex, 9).toString();
		String LengthOfSeries65 = (String) exlObj.getCellData(sheet, rowIndex, 10).toString();
		String LengthOfService = (String) exlObj.getCellData(sheet, rowIndex, 11).toString();
		String FAAUM = (String) exlObj.getCellData(sheet, rowIndex, 12).toString();
		String Anticipatedpercentageofoverallbusiness = (String) exlObj.getCellData(sheet, rowIndex, 13).toString();
		String ISNominationForrecruit = (String) exlObj.getCellData(sheet, rowIndex, 14);
		String CFA = (String) exlObj.getCellData(sheet, rowIndex, 15);
		String Branch = (String) exlObj.getCellData(sheet, rowIndex, 16).toString();
		String Complex = (String) exlObj.getCellData(sheet, rowIndex, 17).toString();
		String Division = (String) exlObj.getCellData(sheet, rowIndex, 18).toString();
		String Region = (String) exlObj.getCellData(sheet, rowIndex, 19).toString();
		String Waive = (String) exlObj.getCellData(sheet, rowIndex, 20);
		String Awards = (String) exlObj.getCellData(sheet, rowIndex, 21).toString();
		String AddINfo = (String) exlObj.getCellData(sheet, rowIndex, 22).toString();
		exlObj.closeWorkBook();
		if (BranchManagerName != "") {
			createobj.enterBranchManagername(BranchManagerName);
		}
		if (FAName != "") {
			createobj.enterFAname(FAName);
		}
		if (FAEmail != "") {
			createobj.enterFAemail(FAEmail);
		}
		if (FAId != "") {
			createobj.selectFAId(FAId);
		}
		if (RecruitHireDate != "") {
			createobj.selectRecruitHireDate(RecruitHireDate);
		}
		if (PriorFirm != "") {
			createobj.enterPriorFirm(PriorFirm);
		}
		if (PreviouslyApprovedForFADiscretionary != "") {
			createobj.choosePreviouslyApprovedForFADiscretionary(PreviouslyApprovedForFADiscretionary);
		}
		createobj.selectFASegment("FASegment");
		if (LengthOfSeries7Registration != "") {
			createobj.enterLengthOfSeries7Registration(LengthOfSeries7Registration);
		}
		if (LengthOfSeries65 != "") {
			createobj.enterLengthOfSeries65(LengthOfSeries65);
		}
		if (LengthOfService != "") {
			createobj.enterLengthOfService(LengthOfService);
		}
		if (FAAUM != "") {
			createobj.enterFAAUM(FAAUM);
		}
		if (Anticipatedpercentageofoverallbusiness != "") {
			createobj.enterAnticipatedpercentageofoverallbusiness(Anticipatedpercentageofoverallbusiness);
		}
		if (ISNominationForrecruit != "") {
			createobj.chooseISNominationForrecruit(ISNominationForrecruit);
		}
		if (CFA != "") {
			createobj.chooseCFA(CFA);
		}
		if (Branch != "") {
			createobj.enterBranch(Branch);
		}
		if (Complex != "") {
			createobj.enterComplex(Complex);
		}
		if (Division != "") {
			createobj.enterDivision(Division);
		}
		if (Region != "") {
			createobj.enterRegion(Region);
		}
		if (Waive != "") {
			createobj.chooseWaive(Waive);
		}
		if (Awards != "") {
			createobj.enterAwards(Awards);
		}
		if (AddINfo != "") {
			createobj.enterAddInfo(AddINfo);
		}
		Reporter.addCompleteScreenCapture();
	}

	@And("^User enters the mandatory details in FA Wizard for FA creation$")
	public void user_enters_the_mandatory_details_in_fa_wizard_for_fa_creation() throws Throwable {
		String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		Reporter.addStepLog("the window handle is" + winHandleBefore);
		createobj1.clickOnFAinwizard();
		createobj1.clickOncreatebutton();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User clicks on Next Button on the Create FA Page$")
	public void user_clicks_on_next_button_on_the_create_fa_page() throws Throwable {
		createobj.clickonnextbutton();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User clicks on the Cancel Button on the Create FA Page$")
	public void user_clicks_on_cancel_button_on_the_create_fa_page() throws Throwable {
		createobj.clickoncancelbutton();
		Reporter.addCompleteScreenCapture();
	}

	@Then("^user should be able to see if Is Nomination for a recruit is yes Recurit hire date will act as a mandatory field$")
	public void user_should_be_able_to_see_if_is_nomination_for_a_recruit_is_yes_recurit_hire_date_will_act_as_a_mandatory_field()
			throws Throwable {
		createobj.Isnominationforarecruit();
	}

	@And("^User enters (.+) in mandatory fields in Enter FA details page$")
	public void user_enters_in_mandatory_fields_in_Enter_FA_details_page(String option) throws Throwable {
		if (option.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
		String BranchManagerName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String FAName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String FAEmail = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String FAId = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String RecruitHireDate = (String) exlObj.getCellData(sheet, rowIndex, 5).toString();
		String PriorFirm = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String PreviouslyApprovedForFADiscretionary = (String) exlObj.getCellData(sheet, rowIndex, 7);
		String FASegment = (String) exlObj.getCellData(sheet, rowIndex, 23);
		String Waive = (String) exlObj.getCellData(sheet, rowIndex, 20);
		String Awards = (String) exlObj.getCellData(sheet, rowIndex, 21).toString();
		exlObj.closeWorkBook();
		if (BranchManagerName != "") {
			createobj.enterBranchManagername(BranchManagerName);
		}
		if (FAName != "") {
			createobj.enterFAname(FAName);
		}
		if (FAEmail != "") {
			createobj.enterFAemail(FAEmail);
		}
		if (FAId != "") {
			createobj.selectFAId(FAId);
		}
		if (RecruitHireDate != "") {
			createobj.selectRecruitHireDate(RecruitHireDate);
		}
		if (PriorFirm != "") {
			createobj.enterPriorFirm(PriorFirm);
		}
		createobj.selectFASegment(FASegment);
		if (PreviouslyApprovedForFADiscretionary != "") {
			createobj.choosePreviouslyApprovedForFADiscretionary(PreviouslyApprovedForFADiscretionary);
		}
		if (Waive != "") {
			createobj.chooseWaive(Waive);
		}
		if (Awards != "") {
			createobj.enterAwards(Awards);
		}
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User verfies the entered details in Enter FA details page with (.+)$")
	public void user_verifies_the_entered_details_in_enter_fa_details_page(String option) throws Throwable {
		if (option.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
		String BranchManagerName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String FAName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String PriorFirm = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String Awards = (String) exlObj.getCellData(sheet, rowIndex, 21).toString();
		exlObj.closeWorkBook();
		createobj.validateFieldValues("txtBranchManagerName", BranchManagerName);
		createobj.validateFieldValues("txtFAName", FAName);
		createobj.validateFieldValues("txtFAEmail", "test@gmail.com");
		createobj.validateFieldValues("txtPriorFirm", PriorFirm);
		createobj.validateFieldValues("txtAwards", Awards);
		Reporter.addScreenCapture();
	}

	@Then("^User verifies Renomination date is in hidden state$")
	public void user_verifies_renomination_date_is_in_hidden_state() {
		Assert.assertFalse(createobj.isRenominationDateVisible());
	}

	@Then("^User should be able to see the Create Financial advisor page$")
	public void user_should_able_to_see_the_create_financial_advisor_page() {
		Assert.assertTrue(createobj.isCreateFinancialAdvisorVisible());
	}

	@Then("^User clicks on reset button and validate$")
	public void user_clicks_on_reset_button_and_validate() throws InterruptedException {
		action.pause(1000);
		createobj.clickOnResetbutton();
		action.pause(3000);
		Reporter.addScreenCapture();
		createobj.validateFieldValues("txtBranchManagerName", "");
		createobj.validateFieldValues("txtFAName", "");
		createobj.validateFieldValues("txtFAEmail", "");
		createobj.validateFieldValues("txtPriorFirm", "");
		createobj.validateFieldValues("txtAwards", "");
	}
}
