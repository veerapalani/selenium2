package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreateSMASingleAccessStrategyReviewStepdef {
	
	CreateSMASingleAccessStrategyReviewPage reviewPage = new CreateSMASingleAccessStrategyReviewPage("AD_PM_CreateSMASingleAccessStrategyReviewPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	public static int defaultbenchmarkcount;

	@And("^User clicks on Submit in Review Page for Create SMA Single Access flow$")
    public void user_clicks_on_submit_in_review_page_for_create_sma_single_access_flow() throws Throwable {
    	
    	reviewPage.isUserOnReviewPage();
    	reviewPage.clickOnSubmitt();
    	
    	
    }
	
	@Then("^User should be able to see Benchmark value matching as per value in DB with (.+)$")
    public void user_should_be_able_to_see_benchmark_value_matching_as_per_value_in_db_with(String mandatorydetails) throws SQLException {
		
		String primaryBenchmarkValue = reviewPage.getPrimaryBenchmarkValue();
		//System.out.println("CreateSMASingleAccessStrategyReviewStepdef::"+primaryBenchmarkValue);
		String defaultBenchmarkName ="";
		defaultbenchmarkcount = 0;
		if(primaryBenchmarkValue.contains(",")) {
			Reporter.addStepLog("In SMA Single Access - Default Benchmark cannot have two Benchmarks associated");
			defaultbenchmarkcount++;
		}
		else {
			String[] data = primaryBenchmarkValue.split("-#-");
			defaultBenchmarkName = data[2];
		}
		//get DB Query
		sheetName = "Query";
		sheet = exlObj.getSheet(sheetName);
		String SQLquery = (String) exlObj.getCellData(sheet, 1, 1);
		String labelname = (String) exlObj.getCellData(sheet, 1, 2);
		
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
			mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		}
		
		//get investment style name
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		
		pmdb.DBConnectionStart();
		SQLquery = SQLquery.replace("@data", "'"+investmentStyleName+"'");
		ResultSet rs;
		rs= DBManager.executeSelectQuery(SQLquery);
		String dbDataIterator = null;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			
		 }
		pmdb.DBConnectionClose();
		exlObj.closeWorkBook();
		
		//comparing only Benchmark Name as Percentage will be 100 for default
		if(dbDataIterator.equals(defaultBenchmarkName)) {
			Reporter.addStepLog("Default Benchmark Name Value displayed in Review Page matches with Value in DB");
		}
		else {
			defaultbenchmarkcount++;
			Reporter.addStepLog("Default Benchmark Name Value displayed in Review Page does not match with Value in DB");
		}
		
		
        
    }
	
	@And("^User should be able to see Review Page in Create SMA SA Flow$")
    public void user_should_be_able_to_see_review_page_in_create_sma_sa_flow() {
		Assert.assertTrue(reviewPage.isUserOnReviewPage());
    }
	
	@Then("^User should be able to see added benchmarks from (.+) are sorted in descending order in Review Page in Create SMA SA Flow$")
    public void user_should_be_able_to_see_added_benchmarks_from_are_sorted_in_descending_order_in_review_page_in_create_sma_sa_flow(String mandatorydetails) {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String benchmarkCategory,benchmark,benchmarkPercentage,customBenchmarkReason = "";
		String locatorValueCustomBenchmark,locatorValueCustomBenchmarkHighlight,locatorValueCustomBenchmarkPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 46);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 47);
			
		}
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		reviewPage.moveToBenchmarkHeader();
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			benchmarkfromUI = reviewPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = reviewPage.getPercentageithValuefromUI(j);
			
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey.split(" - ")[1].trim()));
			j++;
			
		}
    }
	
	private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
    	
    	Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

				//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().split(" - ")[1].trim().compareTo(o2.getKey().split(" - ")[1].trim()));
				
				//sort based on benchmark percentage
				Collections.sort(entryList, (o1, o2) -> {
					if(o1.getValue() > o2.getValue()) {
						return -1;
					}else if(o1.getValue() < o2.getValue()) {
						return 1;
					}
					return 0;
				});
				
				/*
				 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
					@Override
					public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
						if(o1.getValue() > o2.getValue()) {
							return -1;
						}else if(o1.getValue() < o2.getValue()) {
							return 1;
						}
						return 0;
					}
				});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		 * for (String countryKey : sortedHashMap.keySet()) {
		 * System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		 * 
		 * }
		 */
		return sortedHashMap;
	}
	
	@Then("^Value for \"([^\"]*)\" field displayed should match with the value given in Enter Strategy details page for (.+)$")
    public void value_for_something_field_displayed_should_match_with_the_value_given_in_enter_strategy_details_page_for(String attributeName, String mandatorydetails) {
        
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		mandatorydetails = mandatorydetails+"_"+environment;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		int col = exlObj.getCellIndexByCellValue(sheet, 0, attributeName);
		String researchRating = (String)exlObj.getCellData(sheet, rowIndex, col).toString();
		
		Assert.assertTrue(reviewPage.getCommonAttributeValue(attributeName).equals(researchRating));
		
    }
	
	@Then("^User should be able to see added Unbundled Node Ids from (.+) are sorted in descending order in Review Page in Create SMA SA Flow$")
    public void user_should_be_able_to_see_added_unbundled_node_ids_from_are_sorted_in_descending_order_in_review_page_in_create_sma_sa_flow(String mandatorydetails) {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String unBundledNodeID,unBundledNodeIDPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			
			unBundledNodeID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 43);
			unBundledNodeIDPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 44);
			
		}
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(unBundledNodeID.contains(",")) {
			String[] customBenchmark = unBundledNodeID.split(",");
			String[] customBenchmarkPercentage = unBundledNodeIDPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortUnbundledNodeIds(customBenchmarkMap);
		}else {
			sortedHashMap.put(unBundledNodeID, Float.parseFloat(unBundledNodeIDPercentage));
		}
		
		String unbundledNodeIdfromUI;
		Float unbundledNodeIdPercentagefromUI;
		int j = 1;
		reviewPage.moveToBenchmarkHeader();
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			unbundledNodeIdfromUI = reviewPage.getUnbundledithValuefromUI(j);
			unbundledNodeIdPercentagefromUI = reviewPage.getUnbundledPercentageithValuefromUI(j);
			Assert.assertTrue(unbundledNodeIdPercentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(unbundledNodeIdfromUI.equals(benchmarkKey));
			j++;
			
		}
    }
	
private LinkedHashMap<String, Float> sortUnbundledNodeIds(HashMap<String, Float> customBenchmarkMap) {
    	
    	Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

				//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().substring(0, o1.getKey().length()-5).trim().compareTo(o2.getKey().substring(0, o2.getKey().length()-5).trim()));
				
				//sort based on benchmark percentage
				Collections.sort(entryList, (o1, o2) -> {
					if(o1.getValue() > o2.getValue()) {
						return -1;
					}else if(o1.getValue() < o2.getValue()) {
						return 1;
					}
					return 0;
				});
				
				/*
				 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
					@Override
					public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
						if(o1.getValue() > o2.getValue()) {
							return -1;
						}else if(o1.getValue() < o2.getValue()) {
							return 1;
						}
						return 0;
					}
				});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		  for (String countryKey : sortedHashMap.keySet()) {
		  System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		  
		  }
		 */
		return sortedHashMap;
	}

}
