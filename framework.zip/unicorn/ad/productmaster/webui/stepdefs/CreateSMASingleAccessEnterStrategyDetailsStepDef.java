package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.StrategyDetailPage;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyEnterStrategyDetailsPage;

public class CreateSMASingleAccessEnterStrategyDetailsStepDef {
	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	CreateSMASingleAccessStrategyEnterStrategyDetailsPage strategyDetailsPage = new CreateSMASingleAccessStrategyEnterStrategyDetailsPage(
			"AD_PM_CreateSMASingleAccessStrategyEnterStrategyDetailsPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError;
	List<String> strategyAttributes = new ArrayList<String>();
	String strategyCode;

	@When("^User clicks on the Create New Dropdown$")
	public void user_clicks_on_the_create_new_dropdown() {
		landingPage.clickOncreatenewdropdownicon();
	}

	@And("^User selects the Strategy from dropdown$")
	public void user_selects_the_strategy_from_dropdown() {
		landingPage.clickOnstrategydropdownmenu();
	}

	@When("User should be able to see Create New Strategy Wizard page")
	public void user_should_be_able_to_see_Create_New_Strategy_Wizard_page() {
		assertTrue(strategyDetailsPage.isUserOnCreateStrategyWizardPage());
	}

	@When("User selects SMA Single Access Radio button")
	public void user_selects_SMA_Single_Access_Radio_button() {
		strategyDetailsPage.clickOnSMASingleAccessRadioButton();
	}

	@When("^User inputs (.+) into Strategy Name$")
	public void user_inputs_into_strategy_name(String data) {
		strategyDetailsPage.enterStrategyName(data);
	}

	@When("User clicks on Create Button")
	public void user_clicks_on_Create_Button() {
		strategyDetailsPage.clickOnCreateButton();
	}

	@When("^User inputs all (.+) in Enter Strategy deatils page$")
	public void user_inputs_all_in_enter_strategy_deatils_page(String mandatorydetails) throws IOException {
		strategyDetailsPage.isUserOnEnterStrategyDetailsPage();
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails + "_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails + "_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails + "_uat";
		}
		String tName = Thread.currentThread().getName();
		synchronized(tName) {
			sheet = exlObj.getSheet(sheetName);
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
			String managerName = (String)exlObj.getCellData(sheet, rowIndex, 1);
			String investmentStyleName = (String)exlObj.getCellData(sheet, rowIndex, 2);
			String riskCategory = (String)exlObj.getCellData(sheet, rowIndex, 3);
			String portfolioManagerName = (String)exlObj.getCellData(sheet, rowIndex, 4);
			String MSA = (String)exlObj.getCellData(sheet, rowIndex, 5);
			String underlyingStrategyName = (String)exlObj.getCellData(sheet, rowIndex, 6);
			String foaId = (String)exlObj.getCellData(sheet, rowIndex, 7);
			String msaPercentage = (String)exlObj.getCellData(sheet, rowIndex, 8).toString();
			String optionsEligible = (String)exlObj.getCellData(sheet, rowIndex, 9);
			String collateralEligible = (String)exlObj.getCellData(sheet, rowIndex, 10);
			String nraEligiblility = (String)exlObj.getCellData(sheet, rowIndex, 11);
			String foreignSecurities = (String)exlObj.getCellData(sheet, rowIndex, 12);
			String concordEligible = (String)exlObj.getCellData(sheet, rowIndex, 13);
			String premiumFee = (String)exlObj.getCellData(sheet, rowIndex, 14);
			String deleted = (String)exlObj.getCellData(sheet, rowIndex, 15);
			String strategyMinimum = (String)exlObj.getCellData(sheet, rowIndex, 16).toString();
			String exceptionMinimum = (String)exlObj.getCellData(sheet, rowIndex, 17).toString();
			String withdrawalRebalanceMinimum = (String)exlObj.getCellData(sheet, rowIndex, 18).toString();
			String feeSchedultType = (String)exlObj.getCellData(sheet, rowIndex, 19);
			String managerFee = (String)exlObj.getCellData(sheet, rowIndex, 20).toString();
			String concordFee = (String)exlObj.getCellData(sheet, rowIndex, 21).toString();
			String typeOfStrategy = (String)exlObj.getCellData(sheet, rowIndex, 22).toString();
			String vehiclePreferences = (String)exlObj.getCellData(sheet, rowIndex, 23).toString();
			String taxPreference = (String)exlObj.getCellData(sheet, rowIndex, 24).toString();
			String allocationPreference = (String)exlObj.getCellData(sheet, rowIndex, 25).toString();
			String researchRating = (String)exlObj.getCellData(sheet, rowIndex, 26).toString();
			String largeTraderId = (String)exlObj.getCellData(sheet, rowIndex, 27).toString();
			String shortDuration = (String)exlObj.getCellData(sheet, rowIndex, 28).toString();
			String mlps = (String)exlObj.getCellData(sheet, rowIndex, 29).toString();
			String highYield = (String)exlObj.getCellData(sheet, rowIndex, 30).toString();
			String taxableFixedIncomeLadder = (String)exlObj.getCellData(sheet, rowIndex, 31).toString();
			String cioAligned = (String)exlObj.getCellData(sheet, rowIndex, 32).toString();
			String municipalFixedIncomeLadder = (String)exlObj.getCellData(sheet, rowIndex, 33).toString();
			String concentratedStrategyIndicator = (String)exlObj.getCellData(sheet, rowIndex, 34).toString();
			String yieldFocused = (String)exlObj.getCellData(sheet, rowIndex, 35).toString();
			String nonTraditionalAssets = (String)exlObj.getCellData(sheet, rowIndex, 36).toString();
			String sustainableInvesting = (String)exlObj.getCellData(sheet, rowIndex, 37).toString();
			String isManagerProfile = (String)exlObj.getCellData(sheet, rowIndex, 38).toString();
			String hideStrategy = (String)exlObj.getCellData(sheet, rowIndex, 39).toString();
			String aarBaseTemplate = (String)exlObj.getCellData(sheet, rowIndex, 40).toString();
			String dvpKeyTrustTemplate = (String)exlObj.getCellData(sheet, rowIndex, 41).toString();
			String comparativeUniverse = (String)exlObj.getCellData(sheet, rowIndex, 42).toString();
			exlObj.closeWorkBook();
			if(managerName != "") {
				strategyDetailsPage.enterManagerName(managerName);
				Boolean bool = strategyDetailsPage.isVestmarkManagerNamePrepopulated();
				if(!bool)
					strategyDetailsPage.enterVestmarkManagerName();
			}
			if(investmentStyleName != "") {
				strategyDetailsPage.enterInvestmentStyleName(investmentStyleName);
			}
			if(riskCategory != "") {
				strategyDetailsPage.enterRiskCategory(riskCategory);
			}
			if(portfolioManagerName != "") {
				strategyDetailsPage.enterPortfolioManagerName(portfolioManagerName);
			}
			if(MSA != "") {
				strategyDetailsPage.enterMSA(MSA);
			}
			if(underlyingStrategyName != "" && foaId != "" && msaPercentage != "") {
				int underlyingStrategyNumber = 0;
				sheetName = "VariablePaths";
				sheet = exlObj.getSheet(sheetName);
				String locatorValueUSN = (String)exlObj.getCellData(sheet, 1, 1);
				String locatorValueFOA = (String)exlObj.getCellData(sheet, 2, 1);
				String locatorValueMSAPercentage = (String)exlObj.getCellData(sheet, 3, 1);
				if(underlyingStrategyName.contains(",") && foaId.contains(",") && msaPercentage.contains(",")) {
					String[] underlyingStrategy = underlyingStrategyName.split(",");
					String[] underlyingFoaId = foaId.split(",");
					String[] underlyingMSAPercentage = msaPercentage.split(",");
					int size = underlyingStrategy.length;
					while(size > 0) {
						strategyDetailsPage.enterUnderLyingStrategyName(
								locatorValueUSN.replace("@data", underlyingStrategyNumber + "'"),
								underlyingStrategy[underlyingStrategyNumber], MSA, underlyingStrategyNumber);
						strategyDetailsPage.enterFOAID(locatorValueFOA.replace("@data", underlyingStrategyNumber + "'"),
								underlyingFoaId[underlyingStrategyNumber], MSA, underlyingStrategyNumber);
						strategyDetailsPage.enterMSAPercentage(
								locatorValueMSAPercentage.replace("@data", underlyingStrategyNumber + "'"),
								underlyingMSAPercentage[underlyingStrategyNumber], MSA, underlyingStrategyNumber);
						underlyingStrategyNumber++;
						size--;
						if(size > 0) {
							strategyDetailsPage.addNewUnderlyingStrategy();
						}
					}
				}
				else {
					strategyDetailsPage.enterUnderLyingStrategyName(
							locatorValueUSN.replace("@data", underlyingStrategyNumber + "'"), underlyingStrategyName,
							MSA, underlyingStrategyNumber);
					strategyDetailsPage.enterFOAID(locatorValueFOA.replace("@data", underlyingStrategyNumber + "'"),
							foaId, MSA, underlyingStrategyNumber);
					strategyDetailsPage.enterMSAPercentage(
							locatorValueMSAPercentage.replace("@data", underlyingStrategyNumber + "'"), msaPercentage,
							MSA, underlyingStrategyNumber);
				}
			}
			if(optionsEligible != "") {
				strategyDetailsPage.enterOptionsEligible(optionsEligible);
			}
			if(collateralEligible != "") {
				strategyDetailsPage.enterCollateralEligible(collateralEligible);
			}
			if(nraEligiblility != "") {
				strategyDetailsPage.enterNRAEligiblility(nraEligiblility);
			}
			if(foreignSecurities != "") {
				strategyDetailsPage.enterForeignSecurities(foreignSecurities);
			}
			if(concordEligible != "") {
				strategyDetailsPage.enterConcordEligible(concordEligible);
			}
			if(premiumFee != "") {
				strategyDetailsPage.enterPremiumFee(premiumFee);
			}
			if(deleted != "") {
				strategyDetailsPage.enterDeleted(deleted);
			}
			if(strategyMinimum != "") {
				strategyDetailsPage.enterStrategyMinimum(strategyMinimum);
			}
			if(exceptionMinimum != "") {
				strategyDetailsPage.enterExceptionMinimum(exceptionMinimum);
			}
			if(withdrawalRebalanceMinimum != "") {
				strategyDetailsPage.enterWithdrawalRebalanceMinimum(withdrawalRebalanceMinimum);
			}
			if(feeSchedultType != "") {
				strategyDetailsPage.enterFeeSchedultType(feeSchedultType);
			}
			if(managerFee != "") {
				strategyDetailsPage.enterManagerFee(managerFee);
			}
			if(concordFee != "") {
				strategyDetailsPage.enterConcordFee(concordFee, concordEligible);
			}
			if(typeOfStrategy != "") {
				strategyDetailsPage.enterTypeOfStrategy(typeOfStrategy);
			}
			if(vehiclePreferences != "") {
				strategyDetailsPage.enterVehiclePreferences(vehiclePreferences);
			}
			if(taxPreference != "") {
				strategyDetailsPage.enterTaxPreference(taxPreference);
			}
			if(allocationPreference != "") {
				strategyDetailsPage.enterAllocationPreference(allocationPreference);
			}
			if(researchRating != "") {
				strategyDetailsPage.enterResearchRating(researchRating);
			}
			if(largeTraderId != "") {
				strategyDetailsPage.enterLargeTraderId(largeTraderId);
			}
			if(shortDuration != "") {
				strategyDetailsPage.enterShortDuration(shortDuration);
			}
			if(mlps != "") {
				strategyDetailsPage.enterMLPs(mlps);
			}
			if(highYield != "") {
				strategyDetailsPage.enterHighYield(highYield);
			}
			if(taxableFixedIncomeLadder != "") {
				strategyDetailsPage.enterTaxableFixedIncomeLadder(taxableFixedIncomeLadder);
			}
			if(cioAligned != "") {
				strategyDetailsPage.enterCioAligned(cioAligned);
			}
			if(municipalFixedIncomeLadder != "") {
				strategyDetailsPage.enterMunicipalFixedIncomeLadder(municipalFixedIncomeLadder);
			}
			if(concentratedStrategyIndicator != "") {
				strategyDetailsPage.enterConcentratedStrategyIndicator(concentratedStrategyIndicator);
			}
			if(yieldFocused != "") {
				strategyDetailsPage.enterYieldFocused(yieldFocused);
			}
			if(nonTraditionalAssets != "") {
				strategyDetailsPage.enterNonTraditionalAssets(nonTraditionalAssets);
			}
			if(sustainableInvesting != "") {
				strategyDetailsPage.enterSustainableInvesting(sustainableInvesting);
			}
			if(isManagerProfile != "") {
				strategyDetailsPage.enterIsManagerProfile(isManagerProfile);
			}
			if(hideStrategy != "") {
				strategyDetailsPage.enterHideStrategy(hideStrategy);
			}
			if(aarBaseTemplate != "") {
				strategyDetailsPage.enterAARBaseTemplate(aarBaseTemplate);
			}
			if(dvpKeyTrustTemplate != "") {
				strategyDetailsPage.enterDVPKeyTrustTemplate(dvpKeyTrustTemplate);
			}
			if(comparativeUniverse != "") {
				strategyDetailsPage.enterComparativeUniverse(comparativeUniverse);
			}
		}
		Reporter.addScreenCapture();
	}

	@When("User Clicks on Next in Enter Strategy deatils page")
	public void user_Clicks_on_Next_in_Enter_Strategy_deatils_page() {
		strategyDetailsPage.clickOnNext();
	}

	@Then("^User should be able to see error message$")
	public void user_should_be_able_to_see_error_message() {
		//expError = (String) exlObj.getCellData(sheet, rowIndex, 80);
		assertTrue(strategyDetailsPage.error(expError));
	}

	@Then("^User should be able to see Enter strategy details page in SMA SA Flow$")
	public void user_should_be_able_to_see_enter_strategy_details_page_in_sma_sa_flow() {
		assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailsPage());
	}

	@And("^User should be able to see entered (.+) in Strategy Name field$")
	public void user_should_be_able_to_see_entered_in_strategy_name_field(String strategyName) {
		String testData = strategyDetailsPage.getStrategyName();
		assertTrue(testData.equals(strategyName));
	}

	@Then("^User should be redirected to Product Master Home Page$")
	public void user_should_be_redirected_to_product_master_home_page() throws InterruptedException {
		landingPage.verifyProductMasterheaderonlandingpage();
	}

	@And("^User should be able to see Product Master Link in Enter Strategy details page in SMA SA Flow$")
	public void user_should_be_able_to_see_product_master_link_in_enter_strategy_details_page_in_sma_sa_flow() {
		assertTrue(strategyDetailsPage.isPMLinkVisible());
	}

	@And("^User clicks on Product Master Link  in SMA SA Flow$")
	public void user_clicks_on_product_master_link_in_sma_sa_flow() {
		strategyDetailsPage.clickOnPMLink();
	}

	@Then("^User should be able to see SMA Single Access Header text in SMA SA Flow$")
	public void user_should_be_able_to_see_sma_single_access_header_text_in_sma_sa_flow() {
		assertTrue(strategyDetailsPage.isProgramNameDisplayed());
	}

	@And("^User should be able to see (.+) in Strategy Name Header$")
	public void user_should_be_able_to_see_in_strategy_name_header(String data) {
		assertTrue(strategyDetailsPage.isStrategyNameValueDisplayed(data));
	}

	@Then("^data in all fields should be discarded in Enter Startegy details page in Create SMA Single flow$")
	public void data_in_all_fields_should_be_discarded_in_enter_startegy_details_page_in_create_sma_single_flow() {
		strategyDetailsPage.isUserOnEnterStrategyDetailsPage();
	}

	@And("^User clicks on Reset Button in Create SMA Single Flow$")
	public void user_clicks_on_reset_button_in_create_sma_single_flow() {
		strategyDetailsPage.clickOnResetButton();
	}

	@Then("^User should be able to see (.+) in Strategy Name field$")
	public void user_should_be_able_to_see_in_strategy_name_field(String data) {
		assertTrue(strategyDetailsPage.checkPrepopulatedStrategyName(data));
	}

	@And("^User should be able to edit the Startegy Name field (.+) in Enter Startegy details page$")
	public void user_should_be_able_to_edit_the_startegy_name_field_in_enter_startegy_details_page(String data) {
		assertTrue(strategyDetailsPage.checkPrepopulatedStrategyName(data));
		assertTrue(strategyDetailsPage.isStrategyNameFieldEditable());
	}

	@Then("^User should be able to see text Create Strategy next to Product Master Link$")
	public void user_should_be_able_to_see_text_create_strategy_next_to_product_master_link() {
		assertTrue(strategyDetailsPage.isCreateStrategyTextDisplayed());
	}

	@Then("^User should be able to see time stamp in Enter Strategy details page in Create SMA Single fow$")
	public void user_should_be_able_to_see_time_stamp_in_enter_strategy_details_page_in_create_sma_single_fow() {
		assertTrue(strategyDetailsPage.isTimeStampDisplayed());
	}

	@Then("^Vestmark Manager Name field should be autopopulated provided Manager Name in (.+) is not empty$")
	public void vestmark_manager_name_field_should_be_autopopulated_provided_manager_name_in_is_not_empty(
			String mandatorydetails) throws IOException {
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String managerName = (String)exlObj.getCellData(sheet, rowIndex, 1);
		if(managerName != "") {
			assertTrue(strategyDetailsPage.isVestmarkManagerNamePrepopulated());
		}
	}

	@And("^User clears the prepopulated Vest Mark Manager Name$")
	public void user_clears_the_prepopulated_vest_mark_manager_name() {
		strategyDetailsPage.clearVestMarkManagerName();
	}

	@Then("^User should be able to edit the Vest Mark Manager Name field in Enter Startegy details page$")
	public void user_should_be_able_to_edit_the_vest_mark_manager_name_field_in_enter_startegy_details_page() {
		assertTrue(strategyDetailsPage.isVestMarkManageryNameFieldEditable());
	}

	@Then("^User should be able to edit the IS Manager Profile field in Enter Startegy details page$")
	public void user_should_be_able_to_edit_the_is_manager_profile_field_in_enter_startegy_details_page() {
		assertTrue(strategyDetailsPage.isISManagerProfileFieldEditable());
	}

	@Then("^User should be able to see that Research Ratings dropdown field (.+) has been updated to Highly Recommended$")
	public void user_should_be_able_see_that_research_ratings_dropdown_field_value_has_been_updated_to_highly_recommended(
			String value) {
		strategyDetailsPage.enterResearchRating(value);
	}

	@And("^User should able to see MSA checkbox and able to select (.+)$")
	public void user_should_able_to_see_MSA_checkbox_andable_to_select_MSA(String Msa) {
		strategyDetailsPage.isUserOnEnterStrategyDetailsPage();
		assertTrue(strategyDetailsPage.isMSAPresent());
		strategyDetailsPage.enterMSA(Msa);
	}

	@Then("^User should able to see MSA checkbox as optional$")
	public void user_should_able_to_see_MSA_checkbox_as_optional() {
		assertFalse(strategyDetailsPage.isMSAOptional());
	}

	@And("^User should able to see Underlying Strategy name and able to add upto 6 items with (.+) and (.+)$")
	public void user_should_able_to_see_Underlying_strategy_name_and_able_to_add_upto_6_items(String mandatorydetails,
			String Msa) {
		strategyDetailsPage.isUserOnEnterStrategyDetailsPage();
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String underlyingStrategyName = (String)exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		if(underlyingStrategyName != "") {
			int underlyingStrategyNumber = 0;
			sheetName = "VariablePaths";
			sheet = exlObj.getSheet(sheetName);
			String locatorValueUSN = (String)exlObj.getCellData(sheet, 1, 1);
			if(underlyingStrategyName.contains(",")) {
				String[] underlyingStrategy = underlyingStrategyName.split(",");
				int size = underlyingStrategy.length;
				while(size > 0) {
					strategyDetailsPage.enterUnderLyingStrategyName(
							locatorValueUSN.replace("@data", underlyingStrategyNumber + "'"),
							underlyingStrategy[underlyingStrategyNumber], Msa, underlyingStrategyNumber);
					underlyingStrategyNumber++;
					size--;
					if(size > 0) {
						strategyDetailsPage.addNewUnderlyingStrategy();
					}
				}
				Assert.assertTrue("Able to add 6 line itesm under MSA", underlyingStrategyNumber == 6);
			}
			else {
				strategyDetailsPage.enterUnderLyingStrategyName(
						locatorValueUSN.replace("@data", underlyingStrategyNumber + "'"), underlyingStrategyName, Msa, underlyingStrategyNumber);
			}
		}
	}

	@Then("^User should able to see Underlying Strategy name as mandatory$")
	public void user_should_able_to_see_Underlying_Strategy_name_as_mandatory() {
		strategyDetailsPage.isUnderlyingStrategyNameMandatory();
	}

	@And("^User should be able to see Enter Strategy details Page in Create SMA SA Flow$")
	public void user_should_be_able_to_see_enter_strategy_details_page_in_create_sma_sa_flow() {
		Assert.assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailsPage());
	}

	@And("^User should able to see MSA Underlying Strategy Percentage Allocation editable with (.+) and (.+) and total value system generated$")
	public void user_should_able_to_see_MSA_Underlying_strategy_name_Percentage_Allocation_editable_nad_total_value_system_generated(String mandatorydetails,
			String Msa) {
		strategyDetailsPage.isUserOnEnterStrategyDetailsPage();
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String msaPercentage = (String)exlObj.getCellData(sheet, rowIndex, 8).toString();
		
		if(msaPercentage != "") {
			int underlyingStrategyNumber = 0;
			int total =0;
			sheetName = "VariablePaths";
			sheet = exlObj.getSheet(sheetName);
			String locatorValueMSAPercentage = (String)exlObj.getCellData(sheet, 3, 1);
			if(msaPercentage.contains(",")) {
				String[] underlyingMSAPercentage = msaPercentage.split(",");
				int size = underlyingMSAPercentage.length;
				while(size > 0) {
					total += Integer.parseInt(underlyingMSAPercentage[underlyingStrategyNumber]);
					strategyDetailsPage.enterMSAPercentage(
							locatorValueMSAPercentage.replace("@data", underlyingStrategyNumber + "'"),
							underlyingMSAPercentage[underlyingStrategyNumber], Msa, underlyingStrategyNumber);
					underlyingStrategyNumber++;
					size--;
					if(size > 0) {
						strategyDetailsPage.addNewUnderlyingStrategy();
					}
				}
			}
			Assert.assertTrue(strategyDetailsPage.isUnderlyingStartegyAllocationPercenatageIsEqualToTotal().contains(String.valueOf(total)));
		}
		exlObj.closeWorkBook();
		Reporter.addScreenCapture();
	}
}
