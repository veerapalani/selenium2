package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyEnterStrategyDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStartegyReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.SaveAsDraftAllUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;
public class StyleExportStepDef {


	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	String expectedColorCode;
	String xpath, myValue;
	Select dropdown;
	Boolean myFlag;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/smaAccess/view/2053002";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	String excelFilePath1 = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategyvestmark_1.xlsx";
	CreatePMPStrategyEnterStrategyDetailsPage strategyDetailsPage = new CreatePMPStrategyEnterStrategyDetailsPage("AD_PM_UpdateStrategyUIPage");
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	ExcelUtils exlObj1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath1);
	RejectedStartegyReviewPage rw = new RejectedStartegyReviewPage("AD_PM_RejectedStartegyReviewPage");
	String StrategyName, InvestStyle, fAFAteamName, selection, StrategyStatus, submissiondate, Mcap,
riskcategory, feeschedule, PivStyle, FASegment, HideStrategy, GeographicIndicator, BalancedAllocation, InvestmentStyleCategory,
ComparativeUniverse, BundledNodeID, UnbundledNodeID, StylePairingCode, FOACode, MarginEligible, SingleStrategyOnly, StructuredProductsStrategy,
ConcentratedStrategyIndicator, ShortTermMaturity, HedgeCoreIndicator, SustainableInvestmentStrategy, AlternativesStrategy, FAEmail, 
NonPMPApprovedTeamMemberemails, DVPKeyTrustTemplate, BenchmarkCategory, BenchmarkCategoryCustom, Benchmark1, Benchmark1CustomBenchmarks, DocumentLink,
DocumentType, DocumentDescription, Comments, CommentType, hOApprovalReasonsString, FAPMPApprovedDate="";
	
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	UpdateStrategyPage UpdateStrategyUI = new UpdateStrategyPage();
	WebElement myElement, myElement1,myElement2;
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_LandingPage"));

	List<String> list = new ArrayList<String>();
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	SaveAsDraftAllUIPage st = new SaveAsDraftAllUIPage();
	

    @And("^the user clicks on the (.+) which is style$")
    public void the_user_clicks_on_the_which_is_style(String entity) throws Throwable {
    	 while(true)
		 {
		 try
		 {
		 myElement1 =(WebElement)action.executeJavaScript("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
		 action.highligthElement(myElement1);
		 myElement1.click();
		 Thread.sleep(2000);
		 }
		 catch (Throwable e)
		 {
		 break;
		 }
		 }



		 Thread.sleep(3000);

		 while(true)
		 {
		 try
		 {
		 myElement1 = (WebElement)action.executeJavaScript("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
		 action.highligthElement(myElement1);
		 myElement1.click();
		 Thread.sleep(2000);



		 }
		 catch (Throwable e)
		 {
		 break;
		 }
		 }
		 myElement = st.findElementByDynamicXpath("//brml-tab-button[@tab=\""+entity+"\"]");
		 Thread.sleep(2000);
		 myElement.click();
		 Reporter.addStepLog("Draft tab is cicked");
		 action.waitForPageLoad();
		 Thread.sleep(3000);
    }
    
    

    @When("^user queries style name attribute (.+)  for an already created Style as a search token (.+)$")
    public void user_queries_style_name_attribute_for_an_already_created_style_as_a_search_token(String entity, String searchcode) throws Throwable {

    	Thread.sleep(5000);
		sheetName = entity;
		
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "token");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchcode);

		myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		searchcode = myValue;
		System.out.println(myValue);
		
 		Boolean compareBoolean = action.isPresent("js", "return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
		

 		if(compareBoolean)
		{
 			

			Thread.sleep(5000);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}
		
		Thread.sleep(5000);

		myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		Thread.sleep(5000);
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;
		
		while(i < 5)
		{
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);}



@And("^user clicks on the the ellipsis icon for editing a style$")
public void user_clicks_on_the_the_ellipsis_icon_for_editing_a_style() throws Throwable {
//Thread.sleep(5000);
WebElement ele = (WebElement) action.getElementByJavascript("elipsis");
action.highligthElement(ele);
Reporter.addCompleteScreenCapture();
action.click(ele);
Thread.sleep(5000);
}
}
