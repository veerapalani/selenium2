package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStrategyViewPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class RejectedStrategyViewStepDef {

	RejectedStrategyViewPage viewPage = new RejectedStrategyViewPage("AD_PM_RejectedStrategyViewPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
	int rowIndex;
	XSSFSheet sheet;
	String sheetName, userInfo;
	String label, attributeValue, uiValue,dbValue = null;
	Action action;
	//public static int count;
	
	@Then("^Values for Attributes in View Page of Rejected Strategies Resubmission flow should match the values for attributes stored in DB$")
    public void values_for_attributes_in_view_page_of_rejected_strategies_resubmission_flow_should_match_the_values_for_attributes_stored_in_db() throws IOException {
		
		//ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		sheetName = "Conversion_Validation";
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int rownum = 1;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
							rownum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromViewPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 3);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							//exlObj.setCellData(sheet, rownum, 4, attributeValue);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 4, attributeValue);
						}else {
							//exlObj.setCellData(sheet, rownum, 4, attributeValue+" -UI Value is not same as Stored Value in DB");
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 4, attributeValue+" -UI Value is not same as Stored Value in DB");
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							//count++;
							
						}
							rownum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
    }

    private String getDataFromViewPage(String data) {
	    	switch (data) {
			case "Risk Category":
				
				uiValue = viewPage.getRiskCategoryValue();
				
				break;
			case "PIV Style":
				
				uiValue = viewPage.getPIVStyleValue();
				
				break;
			case "Geographic Indicator":
				
				uiValue = viewPage.getGeographicIndicatorValue();
				
				break;
			case "Strategy Name":
				
				uiValue = viewPage.getStrategyNameValue();
				
				break;
			case "Strategy Code":
				
				uiValue = viewPage.getStrategyCodeValue();
				
				break;
			case "Balanced Allocation":
				
				uiValue = viewPage.getBalancedAllocationValue();
				
				break;
			case "Concentrated Strategy Indicator_radiobutton":
				
				uiValue = viewPage.getConcentratedStrategyIndicatorValue();
				
				break;
			case "Structured Products Strategy_radiobutton":
				
				uiValue = viewPage.getStructuredProductsStrategyValue();
				
				break;
			case "Margins":
				
				uiValue = viewPage.getMarginsValue();
				
				break;
			case "Status":
				
				uiValue = viewPage.getStrategyStatusValue();
				
				break;
			case "Concord Eligible(NEW)":
				
				//uiValue = reviewPage.getConcordEligibleValue();
				
				break;
			case "Options Approval Level Code":
				
				//uiValue = reviewPage.getOptionalApprovalLevelCodeValues();
				
				break;
			case "Hedge Core Indicator_radiobutton":
				
				uiValue = viewPage.getHedgeCoreIndicatorValue();
				
				break;
			case "Style Pairing Code":
				
				uiValue = viewPage.getStylePairingCodeValue();
				
				break;
			case "Risk Tolerance":
				
				//uiValue = reviewPage.getRiskToleranceValue();
				
				break;
			case "Portfolio Strategy Group Code":
				
				//uiValue = reviewPage.getPortfolioStrategyGroupCodeValue();
				
				break;
			case "Investment Style":
				
				uiValue = viewPage.getInvestmentStyleValue();
				
				break;
			case "Primary Benchmark":
				
				uiValue = viewPage.getPrimaryBenchmarkValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
	}
    
    @And("^User clicks on Continue Editing Button in View Strategy Page in Rejected Strategies Resubmission Flow$")
    public void user_clicks_on_continue_editing_button_in_view_strategy_page_in_rejected_strategies_resubmission_flow() {
        viewPage.clickOnContinueEditingButton();
    }

	@And("^User is in View Strategy Page in Rejected Strategies Resubmission Flow$")
    public void user_is_in_view_strategy_page_in_rejected_strategies_resubmission_flow() {
		Assert.assertTrue(viewPage.isUserOnViewRejectedStrategyPage());
    }
	
	@And("^(.+) is in View Strategy Page in Rejected Strategies Resubmission Flow$")
    public void is_in_view_strategy_page_in_rejected_strategies_resubmission_flow(String typeofuser) {
        
        Assert.assertTrue(viewPage.isUserOnViewRejectedStrategyPage());
        userInfo = typeofuser;
    }
	
	@And("^with Strategy ID from UI store the data related to Rejected Strategy from DB in Excel for (.+) in Rejected Strategy Resubmission Flow$")
    public void with_strategy_id_from_ui_store_the_data_related_to_rejected_strategy_from_db_in_excel_for_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException, SQLException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
        String StrategyID = viewPage.getStrategyID();
        rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 48, StrategyID);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex+1, 48, StrategyID);
        
        int updateDataRowIndex = rowIndex;
    	int dBDataRowIndex = rowIndex+1;

		getDataFromDBandStoreInExcel(StrategyID, dBDataRowIndex);
    }

    private void getDataFromDBandStoreInExcel(String strategyID, int dBDataRowIndex) throws SQLException, IOException {
    	pmdb.DBConnectionStart();

    	String SQLquery, labelname, category = null;
    	String dbDataIterator = "testNull";
    	ResultSet rs;
    	
    	
    	sheetName = "SQLQuery";
    	
    	int cellnum = 1;
    	String label  =  PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
    			//(String) exlObj.getCellData(sheet, cellnum, 0).toString();
    	ArrayList<String> tempData = new ArrayList<String>();
    	
		if(label == "")
			label = "isEmpty";
		
		while (label != "isEmpty") {
			
			if(label.contains("Hide Strategy"))
			{
				if(userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
					label = "ignore";
				}
			}
			if(label.contains("FA Email"))
			{
					label = "ignore";
			}
			
			if(label.contains("ignore")) {
				cellnum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
						//(String) exlObj.getCellData(sheet, cellnum, 0);
					if(label == "")
						label = "isEmpty";
			}
			else {
				
				dbDataIterator = "testnull";
				SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
						//(String) exlObj.getCellData(sheet, cellnum, 1);
				labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
						//(String) exlObj.getCellData(sheet, cellnum, 2);
				//System.out.println(labelname);
	    		SQLquery = SQLquery.replace("@data", "'"+strategyID+"'");
	    		rs= DBManager.executeSelectQuery(SQLquery);
	    		
	   
	    		while(rs.next()) {
	    			
	    				dbDataIterator = rs.getString(labelname);
	    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    					dbDataIterator = "isEmpty";
		    					if(label.contains("radiobutton")) {
			    					dbDataIterator = "Not defined";
			    				}
		    					
		    					
		    		    		
		    			}
	    				
	    				tempData.add(dbDataIterator);
	    				
	    				if(label.contains("BenchmarkCategory")) {
	    					category = dbDataIterator;
	    				}
	    				
	    		 }
	    		//to handle Zero records from DB 
	    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
	    			dbDataIterator = "isEmpty";
	    		}
	    		
	    		
	    		//to handle multiple values for same column
	    		if(tempData.size() > 1) {
	    			if(label.contains("Benchmark Name") || label.contains("Percentage")) {
	    				
			    				String benchmark = "",benchmarkPercentage = "";
			    				
			    				dbDataIterator = "";
				    			for (String G : tempData) {
				    				benchmark = benchmark+G.split("-#-")[0]+",";
				    				benchmarkPercentage = benchmarkPercentage+G.split("-#-")[1]+"f,";
								}
				    			benchmark = benchmark.substring(0, benchmark.length()-1);
				    			benchmarkPercentage = benchmarkPercentage.substring(0, benchmarkPercentage.length()-1);
			    				
				    			System.out.println("Final Bechmark :"+benchmark);
				    			System.out.println("Final Percentage :"+ benchmarkPercentage);
			    				//Sorting the Benchmakrs or Percentages
			    				HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
			    				LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
			    				
			    				if(benchmark.contains(",")) {
			    					String[] customBenchmark = benchmark.split(",");
			    					String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			    					int size = customBenchmark.length;
			    					
			    					for (int i = 0; i < size; i++) {
			    						customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			    					}
			    					
			    					sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
			    				}else {
			    					sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
			    				}
			    				
			    				
			    				
			    				if(label.contains("Benchmark Name")) {
			    					
			    					for (String countryKey : sortedHashMap.keySet()) {
				    					  //System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
				    					  dbDataIterator = dbDataIterator+countryKey+",";
									}
					    			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
			    					
			    				}
			    				if(label.contains("Percentage")) {
			    					
			    					for (String countryKey : sortedHashMap.keySet()) {
				    					  //System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
				    					  dbDataIterator = dbDataIterator+String.format("%.2f", sortedHashMap.get(countryKey))+",";
									}
					    			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
			    					
			    				}
			    				
			    				if(category.equalsIgnoreCase("default")) {
			    					dbDataIterator = dbDataIterator.split(",")[0];
			    				}
	    			}else {
			    			Collections.sort(tempData);
			    			dbDataIterator = "";
			    			for (String G : tempData) {
			    					if(label.contains("FA Team Members Detail"))
			    						dbDataIterator = dbDataIterator+G+":";
			    					else
			    						dbDataIterator = dbDataIterator+G+",";
							}
			    			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
			    	}
	    		}else {
	    			if(label.contains("Benchmark Name")) {
	    				dbDataIterator = dbDataIterator.split("-#-")[0];
	    			}
	    			if(label.contains("Percentage")) {
	    				dbDataIterator = dbDataIterator.split("-#-")[1];
	    			}
	    		}
	    		tempData.clear();
	    		
	    		//setting data into excel for validation
	    		sheetName = "Test";
	    		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, dBDataRowIndex, cellnum+2, dbDataIterator);
	    		sheetName = "SQLQuery";
				cellnum++;
	    		label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
	    		if(label == "")
	    			label = "isEmpty";
			}
			
			
		}
		
		//exlObj.closeWorkBook();
		//pmdb.DBConnectionClose();
		
	}

//	public static String getExactValue(String data) {
//		
//		if(Float.parseFloat(data) == (long) Float.parseFloat(data))
//			return String.format("%d", (long) Float.parseFloat(data));
//		else
//			return String.format("%s", Float.parseFloat(data));
//		
//	}
//	
//	public static String getExactValue2(double d) {
//		
//		if(d == (long) d)
//			return String.format("%d", (long) d);
//		else
//			return String.format("%s", d);
//		
//	}

	@And("^with Strategy ID from UI store the data related to Rejected Strategy from view page in Excel for (.+) in Rejected Strategy Resubmission Flow$")
    public void with_strategy_id_from_ui_store_the_data_related_to_rejected_strategy_from_view_page_in_excel_for_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		String StrategyID = viewPage.getStrategyID();
        rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 48, StrategyID);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex+2, 48, StrategyID);
        
    	int viewPageDataRowIndex = rowIndex+2;
    	
		getDataFromViewPageandStoreInExcel(StrategyID, viewPageDataRowIndex);
    }

	private void getDataFromViewPageandStoreInExcel(String strategyID, int viewPageDataRowIndex) throws IOException {
		
		Action.scrollToUp();
		sheetName = "Test";
		   Boolean flag = true;
		   //count = 0;
		   int columNum = 3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
				
				if(label.contains("checkbox - Hide Strategy"))
				{
					if(userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
						label = "ignore";
					}
				}
				if(label.contains("FA Email"))
				{
						label = "ignore";
				}
				flag = true;
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columNum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataInViewPage(label);
						if(label.split(" - ")[0].equals("radiobutton"))
						{
							switch (attributeValue.toLowerCase().trim()) {
							case "yes":
								attributeValue = "t";
								break;
							case "no":
								attributeValue = "f";
								break;
							default:
								break;
							}
						}
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex-1, columNum);
						
						
						if(label.contains("FA Team Members Detail") && !dbValue.equalsIgnoreCase("isEmpty")) {
							String fATeamMemberNamesfromUI = attributeValue;
							String fATeamMemberNamesfromDB = dbValue;
							String[] tempData = dbValue.split(":");
							if(fATeamMemberNamesfromDB.replace(":", ",").length() == fATeamMemberNamesfromUI.length()) {
								for(String string: tempData) {
									if(!fATeamMemberNamesfromUI.contains(string));
										flag = false;
								}
								if (flag == true) {
									attributeValue = dbValue;
								}
							}
							
						}
						
						if(dbValue.equals(attributeValue) && flag == true) {
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex, columNum, attributeValue);
						}else{
							
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex, columNum, attributeValue+" -UI Value is not same as Stored Value in DB");
								Reporter.addEntireScreenCaptured();
								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							
						}
						
						columNum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
							if(label == "")
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
		
	}

	private String getDataInViewPage(String data) {
		switch (data) {
		case "txt - Strategy Name":
			
			uiValue = viewPage.getStrategyNameValue();
			
			break;
		case "drp - Investment Style":
			
			uiValue = viewPage.getInvestmentStyleValue();
			
			break;
		case "drp - FA Name":
			
			uiValue = viewPage.getFANameValue();
			
			break;
		case "drp - FA Team Name":
			
			uiValue = viewPage.getFATeamNameValue();
			
			break;
		case "ne - FA Team Members Detail":
			
			uiValue = viewPage.getFATeamMemberDetailValue();
			
			break;
		case "drp - Status":
			
			uiValue = viewPage.getStrategyStatusValue();
			
			break;
		case "drp - PMP Title":
			
			uiValue = viewPage.getPMPTitleValue();
			
			break;
		case "drp - Strategy Tier":
			
			uiValue = viewPage.getStrategyTierValue();
			
			break;
		case "grey - Market Cap":
			
			uiValue = viewPage.getMarketCapValue();
			
			break;
		case "grey - Risk Category":
			
			uiValue = viewPage.getRiskCategoryValue();
			
			break;
		case "grey - Fee Schedule Type":
			
			uiValue = viewPage.getFeeScheduleTypeValue();
			
			break;
		case "grey - PIV Style":
			
			uiValue = viewPage.getPIVStyleValue();
			
			break;
		case "grey - Geographic Indicator":
			
			uiValue = viewPage.getGeographicIndicatorValue();
			
			break;
		case "grey - Balanced Allocation":
			
			uiValue = viewPage.getBalancedAllocationValue();
			
			break;
		case "grey - Investment Style Category":
			
			uiValue = viewPage.getInvestmentStyleCategoryValue();
			
			break;
		case "grey - Comparative Universe":
			
			uiValue = viewPage.getComparativeUniverseValue();
			
			break;
		case "grey - Bunded Node ID":
			
			uiValue = viewPage.getBundledNodeIDValue();
			
			break;
		case "grey - Unbundled Node ID":
			
			uiValue = viewPage.getUnbundledNodeIDValue();
			
			break;
		case "grey - Style Pairing Code":
			
			uiValue = viewPage.getStylePairingCodeValue();
			
			break;
		case "radiobutton - Concentrated Strategy Indicator":
			
			uiValue = viewPage.getConcentratedStrategyIndicatorValue();
			
			break;
		case "radiobutton - Structured Products Strategy":
			
			uiValue = viewPage.getStructuredProductsStrategyValue();
			
			break;
		case "radiobutton - Hedge Core Indicator":
			
			uiValue = viewPage.getHedgeCoreIndicatorValue();
			
			break;
		case "radiobutton - Short Term Maturity":
			
			uiValue = viewPage.getShortTermMaturityValue();
			
			break;
		case "radiobutton - Alternatives Strategy":
			
			uiValue = viewPage.getAlternativesStrategyValue();
			
			break;
		case "radiobutton - Sustainable Investment Strategy":
			
			uiValue = viewPage.getSustainableInvestmentStrategyValue();
			
			break;
		case "grey - FOA Code":
			
			uiValue = viewPage.getStrategyCodeValue();
			
			break;
		case "grey - Single Strategy Only":
			
			uiValue = viewPage.getSingleStrategyOnlyValue();
			
			break;
		case "checkbox - Margin Eligible":
			
			uiValue = viewPage.getMarginsValue();
			
			break;
		case "txt - FA Email":
			
			uiValue = viewPage.getFAEmailValue();
			
			break;
		case "txt - Non PMP Approved Team Member Email":
			
			uiValue = viewPage.getNonPMPApprovedTeamMemberEmailValue();
			
			break;
		case "drp - DVP/Key Trust Template":
			
			uiValue = viewPage.getDVPTemplateValue();
			
			break;
		case "checkbox - Hide Strategy":
					
			uiValue = viewPage.getHideStrategyValue();
					
			break;
		case "NIESP - PMP Submission Date":
			
			uiValue = viewPage.getNonPMPSubmissionDateValue();
			
			break;
		case "radiobutton - BenchmarkCategory":
			
			uiValue = viewPage.getBenchmarkCategoryValue();
			
			break;
		case "drp - Benchmark Name":
			
			uiValue = viewPage.getBenchmarkNameValue();
			
			break;
		case "txt - Percentage":
			
			uiValue = viewPage.getPercentageValue();
			
			break;
		case "txt - Custom Benchmark Reason":
			
			uiValue = viewPage.getCustomBenchmarkReasonValue();
			
			break;
		case "drp - Document Type":
			
			uiValue = viewPage.getDocumentTypeValue();
			
			break;
		case "txt - Document Link":
			
			uiValue = viewPage.getDocumentLinkValue();
			
			break;
		case "txt - Document Comment":
			
			uiValue = viewPage.getDocumentCommentValue();
			
			break;
		case "drp - Comment Type":
			
			uiValue = viewPage.getCommentTypeValue();
			
			break;
		case "txt - Comment":
			
			uiValue = viewPage.getCommentCommentValue();
			
			break;
		default:
			
			uiValue = "NotChanged";
			
			break;
	}
	if(uiValue.equals("—") || uiValue.isEmpty())
		uiValue = "isEmpty";

	return uiValue;
	}
	
	@Then("^User should be able to see benchmarks are sorted in descending order in View Page in Rejected Strategy Resubmission Flow for (.+)$")
    public void user_should_be_able_to_see_benchmarks_are_sorted_in_descending_order_in_view_page_in_rejected_strategy_resubmission_flow_for(String mandatorydetails) {
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String benchmark,benchmarkPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			int dBDataRowIndex = rowIndex+1;
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dBDataRowIndex, 37);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dBDataRowIndex, 38);
			
		}
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			benchmarkfromUI = viewPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = viewPage.getPercentageithValuefromUI(j);
			//System.out.println(percentagefromUI);
			//System.out.println(sortedHashMap.get(benchmarkKey));
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			//System.out.println(benchmarkfromUI);
			//System.out.println(benchmarkKey);
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey));
			j++;
			
		}
    }

	private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
		Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		//System.out.println(entryList.get(0).getKey());
		//System.out.println(entryList.get(0).getKey().split(" - ")[0].trim());
		
		//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().trim().compareTo(o2.getKey().trim()));
		
		//sort based on benchmark percentage
		Collections.sort(entryList, (o1, o2) -> {
			if(o1.getValue() > o2.getValue()) {
				return -1;
			}else if(o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});
		
		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
			@Override
			public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
				if(o1.getValue() > o2.getValue()) {
					return -1;
				}else if(o1.getValue() < o2.getValue()) {
					return 1;
				}
				return 0;
			}
		});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		
		  for (String countryKey : sortedHashMap.keySet()) {
		  //System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		  
		  }
		  
		  //System.out.println("----------------##---------------");
		 
		return sortedHashMap;
	}
	
	@Then("^user should be able to see that Label FA Segment changed to PMP Title$")
    public void user_should_be_able_to_see_that_label_fa_segment_changed_to_pmp_title() throws Throwable {
		viewPage.CheckingPMPTitle();
    }
	 
	@Then("^User should able to see HO user comments for rejected strategy in view mode$")
    public void user_should_be_able_to_HO_user_comments_for_rejected_strategy_in_view_mode() throws Throwable {
		Assert.assertTrue(viewPage.getCommentsTypeValue().isDisplayed());
		Assert.assertTrue(viewPage.getCommentsCommentValue().isDisplayed());
    }
	
	@Then("^User should be able to see \"([^\"]*)\" field on the Rejected strategy view page$")
    public void user_should_be_able_to_see_something_field_on_the_rejected_strategy_view_page(String label) {
        Assert.assertTrue(viewPage.isAttributeLabelDisplayed(label));
    }

}
