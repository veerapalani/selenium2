package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.framework.utils.Action;

public class ValidateDataStrategy {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);

	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	Alert alert;
	//PMPageGeneric validatestrategypage = new PMPageGeneric("AD_PM_ValidateStrategyPage");
	PMPageGeneric createstrategypage = new PMPageGeneric("AD_PM_CreateStrategyPage");
	PMPageGeneric createdoclink = new PMPageGeneric("AD_PM_CreateDocumentLinkPage");
	
	@Then("^it should throw the error message as (.+) in the Create New Strategy Page UI$")
    public void it_should_throw_the_error_message_as_in_the_create_new_strategy_page_ui(String message) throws Throwable {
		createstrategypage.verifyHeader(message);
    	Reporter.addScreenCapture();
    }
}
