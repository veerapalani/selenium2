package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccesstrategyViewDetailsPage;

public class UpdateSMASingleAccesstrategyViewDetailsStepDef {

	UpdateSMASingleAccesstrategyViewDetailsPage viewDetailsPage = new UpdateSMASingleAccesstrategyViewDetailsPage(
			"AD_PM_UpdateSMASingleAccesstrategyViewDetailsPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName;
	String label, attributeValue, uiValue, dbValue = null;
	/*
	 * SMA Single Access Conversion Data Validation
	 */

	public static int count;
	public static int defaultbenchmarkcount;

	@And("^User is in View Strategy Page in Update SMA Single Access flow$")
	public void user_is_in_view_strategy_page_in_update_sma_single_access_flow() {
		Assert.assertTrue(viewDetailsPage.isUserOnViewDetailsPage());
	}

	@Then("^Values for Attributes in View Page should match the values for attributes stored in DB$")
	public void values_for_attributes_in_view_page_should_match_the_values_for_attributes_stored_in_db() {

		sheetName = "Conversion_Validation";
		sheet = exlObj.getSheet(sheetName);
		count = 0;
		int rownum = 1;
		label = (String) exlObj.getCellData(sheet, rownum, 0);

		if (label == "")
			label = "isEmpty";
		while (label != "isEmpty") {

			if (label.contains("ignore") || label.contains("NIVDP")) {
				rownum++;
				label = (String) exlObj.getCellData(sheet, rownum, 0).toString();

				if (label == "")
					label = "isEmpty";
			} else {

				attributeValue = getDataFromViewPage(label);
				dbValue = (String) exlObj.getCellData(sheet, rownum, 3).toString();
				if (dbValue.equals(attributeValue)) {
					exlObj.setCellData(sheet, rownum, 4, attributeValue);
				} else {
					exlObj.setCellData(sheet, rownum, 4,
							attributeValue + " -UI Value is not same as Stored Value in DB");

					Reporter.addEntireScreenCaptured();
					Reporter.addStepLog(
							"For Attribute - " + label + " UI Value Prepopulated is not same as Stored Value in DB");
					count++;

				}
				rownum++;
				label = (String) exlObj.getCellData(sheet, rownum, 0).toString();

				if (label == "")
					label = "isEmpty";

			}
		}
//		if(count > 0) {
//			Assert.fail("Prepopulated Values are not same as values stored in DB");
//		}
		Reporter.addCompleteScreenCapture();
		// Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are
		// Populated in UI");
		exlObj.closeWorkBook();

	}

	private String getDataFromViewPage(String data) {

		switch (data) {
		case "Risk Category":

			uiValue = viewDetailsPage.getRiskCategoryValue();

			break;
		case "Strategy Name":

			uiValue = viewDetailsPage.getStrategyNameValue();

			break;
		case "Strategy Code":

			uiValue = viewDetailsPage.getStrategyCodeValue();

			break;
		case "Research Rating":

			uiValue = viewDetailsPage.getResearchRatingValue();

			break;
		case "Strategy Minimum":

			uiValue = viewDetailsPage.getStrategyMinimumValue();

			break;
		case "Exception Minimum":

			uiValue = viewDetailsPage.getExceptionMinimumValue();

			break;
		case "Withdrawal/Rebalance Minimum":

			uiValue = viewDetailsPage.getWithdrawalRebalanceMinimumValue();

			break;
		case "Status":

			uiValue = viewDetailsPage.getStrategyStatus();

			break;
		case "Premium Fee Eligible":

			uiValue = viewDetailsPage.getPremiumEligibleValue();

			break;
		case "Concord Fee Eligible":

			uiValue = viewDetailsPage.getConcordFeeEligibleValue();

			break;
		case "Node ID - Bundled":

			uiValue = viewDetailsPage.getBundledNodeIDValue();

			break;
		case "Assets":

			uiValue = viewDetailsPage.getUnbundledNodeIDValues();

			break;
		case "Inception Date_ignore":

			uiValue = viewDetailsPage.getInceptionDateIgnore();

			break;
		case "Premium Fee Eligible2":

			uiValue = viewDetailsPage.getPremiumEligibleValue();

			break;
		case "Start Date_ignore":

			uiValue = viewDetailsPage.getStartDateIgnoreValue();

			break;
		case "IS Manager Profile Available":

			uiValue = viewDetailsPage.getIsManagerProfileValue();

			break;
		case "Deleted":

			uiValue = viewDetailsPage.getDeletedValue();

			break;
		case "Alternatives Strategy Code_ignore":

			uiValue = viewDetailsPage.getAlternativesStrategyCodeValue();

			break;
		case "Proxy Manager":

			uiValue = viewDetailsPage.getProxyManagerValue();

			break;
		case "Proxy Address1":

			uiValue = viewDetailsPage.getProxyAddress1Value();

			break;
		case "Proxy Address2":

			uiValue = viewDetailsPage.getProxyAddress2Value();

			break;
		case "Proxy Address3":

			uiValue = viewDetailsPage.getProxyAddress3Value();

			break;
		case "Proxy Address4":

			uiValue = viewDetailsPage.getProxyAddress4Value();

			break;
		case "Proxy City":

			uiValue = viewDetailsPage.getProxyCityValue();

			break;
		case "Proxy State":

			uiValue = viewDetailsPage.getProxyStateValue();

			break;
		case "Proxy Zipcode":

			uiValue = viewDetailsPage.getProxyZipCodeValue();

			break;
		case "Voluntary Reorg Manager":

			uiValue = viewDetailsPage.getVoluntaryReorgManagerValue();

			break;
		case "Voluntary Reorg Address1":

			uiValue = viewDetailsPage.getVoluntaryReorgAddress1Value();

			break;
		case "Voluntary Reorg Address2":

			uiValue = viewDetailsPage.getVoluntaryReorgAddress2Value();

			break;
		case "Voluntary Reorg Address3":

			uiValue = viewDetailsPage.getVoluntaryReorgAddress3Value();

			break;
		case "Voluntary Reorg Address4":

			uiValue = viewDetailsPage.getVoluntaryreorgAddress4Value();

			break;
		case "Voluntary Reorg City":

			uiValue = viewDetailsPage.getVoluntaryReorgCityValue();

			break;
		case "Voluntary Reorg State":

			uiValue = viewDetailsPage.getVoluntaryReorgStateValue();

			break;
		case "Voluntary Reorg Zipcode":

			uiValue = viewDetailsPage.getVoluntaryReorgZipcodeValue();

			break;
		case "Interim Manager":

			uiValue = viewDetailsPage.getInterimManagerValue();

			break;
		case "Interim Address1":

			uiValue = viewDetailsPage.getInterimAddress1Value();

			break;
		case "Interim Address2":

			uiValue = viewDetailsPage.getInterimAddress2Value();

			break;
		case "Interim Address3":

			uiValue = viewDetailsPage.getInterimAddress3Value();

			break;
		case "Interim Address4":

			uiValue = viewDetailsPage.getInterimAddress4Value();

			break;
		case "Interim City":

			uiValue = viewDetailsPage.getInterimCityValue();

			break;
		case "Interim State":

			uiValue = viewDetailsPage.getInterimStateValue();

			break;
		case "Interim Zipcode":

			uiValue = viewDetailsPage.getInterimZipcodeValue();

			break;

		default:
			uiValue = "NotChanged";
			break;
		}
		if (uiValue.equals("—"))
			uiValue = "isEmpty";

		return uiValue;
	}

	@And("^User clicks on Continue Editing Option in View Details page in Update SMA Single Access Flow$")
	public void user_clicks_on_continue_editing_option_in_view_details_page_in_update_sma_single_access_flow() {
		viewDetailsPage.clickOnContinueEditingButton();
	}

	@Then("^User should be able to see Benchmark value matching as per value in DB in Update SMA Access View Page with (.+)$")
	public void user_should_be_able_to_see_benchmark_value_matching_as_per_value_in_db_in_update_sma_access_view_page_with(
			String mandatorydetails) throws SQLException {
		String primaryBenchmarkValue = viewDetailsPage.getPrimaryBenchmarkValue();
		// System.out.println("CreateSMASingleAccessStrategyReviewStepdef::"+primaryBenchmarkValue);
		String defaultBenchmarkName = "isEmpty";
		defaultbenchmarkcount = 0;
		if (primaryBenchmarkValue.contains(",")) {
			Reporter.addStepLog("In SMA Single Access - Default Benchmark cannot have two Benchmarks associated");
			defaultbenchmarkcount++;
		} else {
			if (primaryBenchmarkValue.contains("-#-")) {
				String[] data = primaryBenchmarkValue.split("-#-");
				defaultBenchmarkName = data[2];
			}
		}

		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
		String sheetName = "";
		int rowIndex;
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet;

		// get DB Query
		sheetName = "Query";
		sheet = exlObj.getSheet(sheetName);
		String SQLquery = (String) exlObj.getCellData(sheet, 1, 1);
		String labelname = (String) exlObj.getCellData(sheet, 1, 2);

		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
			mandatorydetails = mandatorydetails + "_" + SSOLoginPage.UIEnvironment.trim().toLowerCase();
		}

		// get investment style name
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 2);

		pmdb.DBConnectionStart();
		SQLquery = SQLquery.replace("@data", "'" + investmentStyleName + "'");
		ResultSet rs;
		rs = DBManager.executeSelectQuery(SQLquery);
		String dbDataIterator = null;
		while (rs.next()) {
			dbDataIterator = rs.getString(labelname);

		}
		pmdb.DBConnectionClose();
		exlObj.closeWorkBook();

		// comparing only Benchmark Name as Percentage will be 100 for default
		if (dbDataIterator.equals(defaultBenchmarkName)) {
			Reporter.addStepLog("Default Benchmark Name Value displayed in view Page matches with Value in DB");
		} else {
			defaultbenchmarkcount++;
			Reporter.addStepLog("Default Benchmark Name Value displayed in view Page does not match with Value in DB");
		}
	}

}
