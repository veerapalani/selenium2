package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerAddContactsPage;

public class UpdateManagerAddContactsStepDef {
	
	UpdateManagerAddContactsPage addContactsPage = new UpdateManagerAddContactsPage("AD_PM_UpdateManagerAddContactsPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateManager.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue, flowPageDataValue = null;
	
	@And("^User should be able to see Add Contacts page in Update Manager Flow$")
    public void user_should_be_able_to_see_add_contacts_page_in_update_manager_flow() {
        Assert.assertTrue(addContactsPage.isUserOnAddContactsPage());
    }
	
	@And("^User clicks on Add Contacts button in Add Contacts page in Update Manager Flow$")
    public void user_clicks_on_add_contacts_button_in_add_contacts_page_in_update_manager_flow() {
        addContactsPage.clickOnAddAnotherContact();
    }

    @And("^User inputs the values from (.+) in Add Contacts page in Update Manager Flow$")
    public void user_inputs_the_values_from_in_add_contacts_page_in_update_manager_flow(String mandatorydetails) throws IOException {
		
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		int updateDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex+1;
    	
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			String deleteContacts = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 12);
			String contactType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 13);
			//String contactDescription = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 14);
			String contactDescription = RandomStringUtils.randomAlphanumeric(10);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 14, contactDescription);
			String contactFirstName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 15);
			String contactMiddleName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 16);
			String contactLastName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 17);
			String contactAddress = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 18);
			String contactCity = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 19);
			String contactState = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 20);
			String contactPostalCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 21);
			String contactCountry = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 22);
			String contactEmailAddress = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 23);
			String contactPhoneNumber = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 24);
			
			int contactsCount = addContactsPage.getContactCount();
			
			if(Integer.parseInt(deleteContacts) > contactsCount) {
				Reporter.addStepLog("Contact Count in UI is less than the count given in Excel -- Deleting all contacts");
				
				for (int i = 0; i < contactsCount; i++) {
					addContactsPage.deleteContact();
					
				}
				
			}else {
				for (int i = 0; i < Integer.parseInt(deleteContacts); i++) {
					addContactsPage.deleteContact();
					
				}
			}
		
			if(contactType != "" && contactDescription != "") {
				addContactsPage.clickOnAddAnotherContact();
				if(contactType.contains(",") && contactDescription.contains(",")) {
					String[] contType = contactType.split(",");
					String[] contDescription = contactDescription.split(",");
					String[] contFirstName = contactFirstName.split(",");
					String[] contMiddleName = contactMiddleName.split(",");
					String[] contLastName = contactLastName.split(",");
					String[] contAddress = contactAddress.split(",");
					String[] contCity = contactCity.split(",");
					String[] contState = contactState.split(",");
					String[] contPostalCode = contactPostalCode.split(",");
					String[] contCountry = contactCountry.split(",");
					String[] contEmailAddress = contactEmailAddress.split(",");
					String[] contPhoneNumber = contactPhoneNumber.split(",");
					
					
					int size = Math.min(contactType.length(), contactDescription.length());
					int i =0;
					
						while(size > 0) {
							
								addContactsPage.entercontactType(contType[i]);
								addContactsPage.entercontactDescription(contDescription[i]);
								addContactsPage.entercontactFirstName(contFirstName[i]);
								addContactsPage.entercontactMiddleName(contMiddleName[i]);
								addContactsPage.entercontactLastName(contLastName[i]);
								addContactsPage.entercontactAddress(contAddress[i]);
								addContactsPage.entercontactCity(contCity[i]);
								if(contState[i] != "")
									addContactsPage.entercontactState(contState[i]);
								addContactsPage.entercontactPostalCode(contPostalCode[i]);
								if(contCountry[i] != "")
									addContactsPage.entercontactCountry(contCountry[i]);
								addContactsPage.entercontactEmailAddress(contEmailAddress[i]);
								addContactsPage.entercontactPhoneNumber(contPhoneNumber[i]);
								addContactsPage.clickOnAddContact();
							
							size--;
							i++;
							if(size > 0) {
								addContactsPage.clickOnAddAnotherContact();
								}
						}
					
			        
				}
				else {
				
					
					addContactsPage.entercontactType(contactType);
					addContactsPage.entercontactDescription(contactDescription);
					addContactsPage.entercontactFirstName(contactFirstName);
					addContactsPage.entercontactMiddleName(contactMiddleName);
					addContactsPage.entercontactLastName(contactLastName);
					addContactsPage.entercontactAddress(contactAddress);
					addContactsPage.entercontactCity(contactCity);
					if(contactState != "")
						addContactsPage.entercontactState(contactState);
					addContactsPage.entercontactPostalCode(contactPostalCode);
					if(contactCountry != "")
						addContactsPage.entercontactCountry(contactCountry);
					addContactsPage.entercontactEmailAddress(contactEmailAddress);
					addContactsPage.entercontactPhoneNumber(contactPhoneNumber);
					addContactsPage.clickOnAddContact();
				}
				
			
			}
		
		
		}
		
		Reporter.addScreenCapture();
	    
	}
    
    @And("^User clicks on Next in Add Contacts Page in Update Manager Flow$")
    public void user_clicks_on_next_in_add_contacts_page_in_update_manager_flow() {
        addContactsPage.clickOnNext();
    }
    
    @And("^Data prepopulated in Add Contacts page should match with DB Data in Update Manager flow for (.+)$")
    public void data_prepopulated_in_add_contacts_page_should_match_with_db_data_in_update_manager_flow_for(String mandatorydetails) {

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 13;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int dbDataRowIndex = rowIndex+1;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("Delete Documents"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Documents"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromAddContactsPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							
						}else {
							
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Documents"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			
    
    }

	private String getDataFromAddContactsPage(String data) {
	    	switch (data) {
			case "Contact Type":
				
				uiValue = addContactsPage.getContactTypeValue();
				
				break;
			case "Contact Description":
				
				uiValue = addContactsPage.getContactDescriptionValue();
				
				break;
			case "Contact First Name":
				
				uiValue = addContactsPage.getContactFirstNameValue();
				
				break;
			case "Contact Middle Name":
				
				uiValue = addContactsPage.getContactMiddleNameValue();
				
				break;
			case "Contact Last Name":
				
				uiValue = addContactsPage.getContactLastNameValue();
				
				break;
			case "Contact Address":
				
				uiValue = addContactsPage.getContactAddressValue();
				
				break;
			case "Contact City":
				
				uiValue = addContactsPage.getContactCityValue();
				
				break;
			case "Contact State":
				
				uiValue = addContactsPage.getContactStateValue();
				
				break;
			case "Contact Postal Code":
							
				uiValue = addContactsPage.getContactPostalCodeValue();
							
				break;
			case "Contact Country":
				
				uiValue = addContactsPage.getContactCountryValue();
				
				break;
			case "Contact Email Address":
				
				uiValue = addContactsPage.getContactEmailAddressValue();
				
				break;
			case "Contact Phone Number":
				
				uiValue = addContactsPage.getContactPhoneNumberValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
	}
	
	@And("^data from Add Contacts page should be stored in Excel for (.+) in Update Manager Flow$")
    public void data_from_add_contacts_page_should_be_stored_in_excel_for_in_update_manager_flow(String mandatorydetails) throws IOException {

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		if(addContactsPage.areContactsAvailableInUI()) {
			
			
		   int columnIndex = 13;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int flowPageDataRowIndex = rowIndex+3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("Delete Documents"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Documents"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromAddContactsPage(label);
						PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
						
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Documents"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			
		}
    }
	
	@And("^User clicks on Previous button in Add Contacts Page in Update Manager Flow$")
    public void user_clicks_on_previous_button_in_add_contacts_page_in_update_manager_flow() {
        addContactsPage.clickOnPrevious();
    }
	
	@Then("^Data populated in Add Contacts page should match with data before moving to another page in Update Manager Flow for (.+)$")
    public void data_populated_in_add_contacts_page_should_match_with_data_before_moving_to_another_page_in_update_manager_flow_for(String mandatorydetails) {
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 13;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int flowPageDataRowIndex = rowIndex+3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("Delete Documents"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Documents"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromAddContactsPage(label);
						flowPageDataValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(flowPageDataValue.equals(attributeValue)) {
							
						}else {
							
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							Assert.fail(label);
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Documents"))
								label = "isEmpty";
					
					}
			}
    }
	
	@Then("^user should be able to see the attribute values match with DB values in the following dropdown in Add Contacts Page in Update Manager flow$")
    public void user_should_be_able_to_see_the_attribute_values_match_with_db_values_in_the_following_dropdown_in_add_contacts_page_in_update_manager_flow(List<String> dropdownNames) throws SQLException {
		
		addContactsPage.clickOnAddAnotherContact();
		
		String replacedata = "";
		String failedDropdowns = "";
		pmdb.DBConnectionStart();
		
		for (int i = 0; i < dropdownNames.size(); i++) {
			
			switch (dropdownNames.get(i)) {
			case "Type":
				replacedata = "CONTACT TYPE";
				break;
			case "Country":
				replacedata = "COUNTRY";	
				break;
			case "State":
				replacedata = "STATE";
				break;
			default:
				break;
			}
			sheetName = "Query";
			

	    	String SQLquery, labelname = null;
	    	String dbDataIterator = "testNull";
	    	List<String> dbData = new ArrayList<String>();
	    	ResultSet rs;
	    	
	    	ArrayList<String> tempData = new ArrayList<String>();
	    	ArrayList<String> uiTempData = new ArrayList<String>();
	    	
	    	dbDataIterator = "testnull";
			SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 1, 1);
			labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 1, 2);
			
    		SQLquery = SQLquery.replace("@data", "'"+replacedata+"'");
    		rs= DBManager.executeSelectQuery(SQLquery);
    		
   
    		while(rs.next()) {
    			
    				dbDataIterator = rs.getString(labelname);
    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
	    					dbDataIterator = "isEmpty";
	    			}
    				
    				tempData.add(dbDataIterator);
    				
    		 }
    		//to handle Zero records from DB 
    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
    			dbDataIterator = "isEmpty";
    			tempData.add(dbDataIterator);
    		}
    		//to handle multiple values for same column
    		if(tempData.size() > 1) {
    			Collections.sort(tempData);
    		}
    		
			uiTempData = addContactsPage.getDropdownValuesDisplayedInUI(dropdownNames.get(i));
			
			if(uiTempData.size() != tempData.size()) {
				failedDropdowns = failedDropdowns+dropdownNames.get(i)+",";
			}else {
				if(uiTempData.equals(tempData))
					Reporter.addStepLog("For Dropdown Label "+dropdownNames.get(i)+" DB values match with UI values displayed");
				else {
					failedDropdowns = failedDropdowns+dropdownNames.get(i)+",";
				}
			}
			
			tempData.clear();
			uiTempData.clear();
		}
		
		if(failedDropdowns.length() > 0) {
			Assert.fail("For Labels "+failedDropdowns+" Dropdown values in UI do not match with DB");
		}
		
		pmdb.DBConnectionClose();
		
    }

}
