package qa.unicorn.ad.productmaster.webui.stepdefs;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;

public class LandingPageStepDef {
	LandingPage lp = new LandingPage("AD_PM_LandingPage");
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");

	@When("^User clicks on Create New Dropdown and selects Benchmark$")
	public void user_clicks_on_create_new_dropdown_and_selects_benchmark() throws Throwable {
		Thread.sleep(2000);

		landingPage1.clickOncreatenewdropdownicon();

		Thread.sleep(1000);
		// lp.clickOnCreateNewDropdown();
		Reporter.addScreenCapture();
		lp.clickOnBenchmarkEntity();
		Reporter.addScreenCapture();
	}

	@Then("^user is able to see search results in \"([^\"]*)\" tab in Landing page$")
	public void user_is_able_to_see_search_results_in_something_tab_in_landing_PAGE(String strArg1) throws Throwable {
		landingPage1.verifyTheSearchedResultInAllTab();
	}

}