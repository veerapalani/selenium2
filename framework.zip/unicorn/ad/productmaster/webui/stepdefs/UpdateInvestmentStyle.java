package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.InvestmentStyleUIPage;


public class UpdateInvestmentStyle {
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyle3606.xlsx";
	String sheetName = "";
	String myValue;
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	WebElement myElement;
	List<WebElement> myElements;
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);

	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateEntityPage"));
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	SoftAssert sftAst = new SoftAssert();
	InvestmentStyleUIPage style = new InvestmentStyleUIPage();

	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	HashMap<String, Object> row = new HashMap<String, Object>();
    @When("^User search with the (.+) taken from (.+) in the Search TextBox on landing page while updating a given investment style$")
    public void user_search_with_the_taken_from_in_the_search_textbox_on_landing_page_while_updating_a_given_investment_style(String entity, String searchcode) throws Throwable {
		Thread.sleep(5000);
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "advisory");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchcode);

		myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
		searchcode = myValue;
		System.out.println(myValue);

		Boolean compareBoolean = action.isPresent("js",
				"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");

		if (compareBoolean) {

			Thread.sleep(5000);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}

		Thread.sleep(5000);

		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		Thread.sleep(5000);
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;

		while (i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);
    }
		
	    @Then("^User clicks on the first element of SMASingleAccess Searches on the suggestion box on landing page while updating a given investment style$")
	    public void user_clicks_on_the_first_element_of_smasingleaccess_searches_on_the_suggestion_box_on_landing_page_while_updating_a_given_investment_style() throws Throwable {
	    	

			myElements = style.findElementsByDynamicXpath("//label[contains(text(),'STYLE')]//parent::div//div[2]");
			String status = "FAIL";

			for (WebElement E : myElements) {
				if (E.getText().toUpperCase().contains(myValue.toUpperCase())) {
					status = "PASS";
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();
					Reporter.addStepLog("clicking on the matching suggestion");

					break;
				}

			}

			if (status.contentEquals("FAIL")) {
				myElement.sendKeys(Keys.ENTER);
				myElements = style
						.findElementsByDynamicXpath("//label[contains(text(),'STYLE')]//parent::div//div[2]");
				for (WebElement E : myElements) {
					if (E.getText().toUpperCase().contains(myValue.toUpperCase())) {
						action.scrollToElement(E);
						action.highligthElement(E);
						Thread.sleep(5000);
						E.click();

						action.waitForPageLoad();

						Reporter.addStepLog("clicking on the matching suggestion");

						break;
					}

				}
			}

		}
}

