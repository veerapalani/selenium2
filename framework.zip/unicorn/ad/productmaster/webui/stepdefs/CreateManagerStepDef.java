package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;

public class CreateManagerStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString ;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	Alert alert;
	public static String managerName, managerCode = null;
	
	CreateManagerPage createmanagerpage = new CreateManagerPage("AD_PM_CreateManagerPage");
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateManager.xlsx";
	String option, sheetName = "";
	int rowIndex;

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;

	
	

    @When("^User enters the (.+) in all of the fields$")
    public void user_enters_the_in_all_of_the_fields(String option) throws Throwable {
    	if (option.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
		
		

		String ManagerName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String Managerfirmname = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String FirmWebsite = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String VestMarkName = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String Taxpayer= (String) exlObj.getCellData(sheet, rowIndex, 5);
		String LargeTraderId= (String) exlObj.getCellData(sheet, rowIndex, 6);
		String DTCCID= (String) exlObj.getCellData(sheet, rowIndex, 7);
		//String feeamnt= exlObj.getCellData(sheet, rowIndex, 8).toString();
		exlObj.closeWorkBook();
		
		if (ManagerName != "") {
			createmanagerpage.enterManagerName(ManagerName);
		}
		
		if (Managerfirmname != "") {
			createmanagerpage.enterManagerFirmName(Managerfirmname);
		}
		if (FirmWebsite != "") {
			createmanagerpage.enterFirmWebsite(FirmWebsite);
		}
		if (VestMarkName != "") {
			createmanagerpage.enterVestMarkName(VestMarkName);
		}
		if (Taxpayer != "") {
			createmanagerpage.enterTaxPayer(Taxpayer);
		}
		if (LargeTraderId != "") {
			createmanagerpage.enterLargetraderID(LargeTraderId);
		}
		
		/*
		 * if (DTCCID != "") { createmanagerpage.enterDTCCID(DTCCID); }
		 */
		
		createmanagerpage.selectUBSSubsidiary();
		createmanagerpage.eyechecktypevalue();
		
		/*
		 * if (feetype != "") { createmanagerpage.selectfeetypevalue(feetype); } if
		 * (feeName != "") { createmanagerpage.enterFeeName(feeName); } if (feedescrp !=
		 * "") { createmanagerpage.enterFeeDescrp(feedescrp); } if (feefreq != "") {
		 * createmanagerpage.selectfeefreqvalue(feefreq); } if (feeamnt != "") {
		 * createmanagerpage.enterFeeAmnt(feeamnt); }
		 */
		Reporter.addScreenCapture();
    }
    @When("^User enters the (.+) in all of the fields with Eye CheckOverride as No$")
    public void user_enters_the_in_all_of_the_fields_with_eye_checkoverride_as_no(String validdata1) throws Throwable {
    	if (validdata1.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, validdata1);
		String ManagerName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String Managerfirmname = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String FirmWebsite = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String VestMarkName = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String Taxpayer= (String) exlObj.getCellData(sheet, rowIndex, 5);
		String LargeTraderId= (String) exlObj.getCellData(sheet, rowIndex, 6);
		String DTCCID= (String) exlObj.getCellData(sheet, rowIndex, 7);
		exlObj.closeWorkBook();
		
		if (ManagerName != "") {
			createmanagerpage.enterManagerName(ManagerName);
		}
		
		if (Managerfirmname != "") {
			createmanagerpage.enterManagerFirmName(Managerfirmname);
		}
		if (FirmWebsite != "") {
			createmanagerpage.enterFirmWebsite(FirmWebsite);
		}
		if (VestMarkName != "") {
			createmanagerpage.enterVestMarkName(VestMarkName);
		}
		if (Taxpayer != "") {
			createmanagerpage.enterTaxPayer(Taxpayer);
		}
		if (LargeTraderId != "") {
			createmanagerpage.enterLargetraderID(LargeTraderId);
		}
		/*
		 * if (DTCCID != "") { createmanagerpage.enterDTCCID(DTCCID); }
		 */
		createmanagerpage.selectUBSSubsidiary();
		createmanagerpage.eyechecktypevalue2();
		Reporter.addScreenCapture();
    }

    
    @And("^User enters the manager name on Manager Flyout Page$")
    public void user_enters_the_manager_name_on_manager_flyout_page() throws Throwable {
    	createmanagerpage.enterManagername();
    }
    @Then("^the attributes on Create Manager page should contain all of the below following values$")
    public void the_attributes_on_create_manager_page_should_contain_all_of_the_below_following_values(List<List<String>> entityValuePair) throws Throwable {
    	for(int i=0;i<entityValuePair.size();i++) {
			String[] listOfValues ;
			listOfString = new ArrayList<String>();
			listOfValues = entityValuePair.get(i).get(1).split(",");
			listOfElements = createmanagerpage.findElementsByDynamicXpath("//*[@label='"+entityValuePair.get(i).get(0)+"']/wf-select-option");
			
			for(int j=0;j<listOfElements.size();j++) {
				listOfString.add(listOfElements.get(j).getAttribute("name"));
				
			}
			for(int j=0;j<listOfValues.length;j++) {
				Assert.assertTrue(listOfString.contains(listOfValues[j]));
				Reporter.addStepLog("the value "+listOfValues[j]+" is present in "+entityValuePair.get(i).get(0));
			}
			
		}
    } 
    
    @Then("^the attributes on Create Manager Flyout should contain all of the below following values$")
    public void the_attributes_on_create_manager_flyout_should_contain_all_of_the_below_following_values(List<List<String>> entityValuePair) throws Throwable {
    	for (int i = 0; i < entityValuePair.size(); i++) {
			String[] listOfValues;
			listOfString = new ArrayList<String>();
			listOfValues = entityValuePair.get(i).get(1).split(",");
			listOfElements = createmanagerpage
					.findElementsByDynamicXpath("//*[@label='" + entityValuePair.get(i).get(0) + "']/wf-select-option");

			for (int j = 0; j < listOfElements.size(); j++) {
				listOfString.add(listOfElements.get(j).getAttribute("name"));

			}
			for (int j = 0; j < listOfValues.length; j++) {
				Assert.assertTrue(listOfString.contains(listOfValues[j]));
				Reporter.addStepLog("the value " + listOfValues[j] + " is present in " + entityValuePair.get(i).get(0));
			}

		}
    }
    @Then("^User should be able to see the status field will be in disabled state on Create New Manager Flyout$")
    public void user_should_be_able_to_see_the_status_field_will_be_in_disabled_state_on_create_new_manager_flyout() throws Throwable {
    	createmanagerpage.verifystatusfieldincreatemanagerpage();
    }
    
    @Then("^User should be able to see the bottom-border below \"([^\"]*)\" on Create New Manager page$")
    public void user_should_be_able_to_see_the_bottomborder_below_something_on_create_new_manager_page(String key) throws Throwable {
    	String widthInPixel = createmanagerpage.giveCssValuehere(createmanagerpage.getElement(key),
				"border-bottom-width");
		String width = widthInPixel.substring(0, widthInPixel.length() - 2);
		Assert.assertTrue(Integer.parseInt(width) > 0);
    }
    @Then("^User is able to see Enter Manager Details Page$")
    public void user_is_able_to_see_enter_manager_details_page() throws Throwable {
        Assert.assertTrue(createmanagerpage.isUserOnCreateManagerPage());
    }
    @Then("^User should be able to see the required symbol for the below attributes in Create Manager Page$")
    public void user_should_be_able_to_see_the_required_symbol_for_the_below_attributes_in_create_manager_page(List<String> entity) throws Throwable {
    	String attribute="required";
    	for(int i =0;i<entity.size();i++) {
        	myElement = createmanagerpage.findElementByDynamicXpath("//*[@label='\"+entity.get(i)+\"']");
        	createmanagerpage.verifyAttribute("true", myElement, attribute);
        }
    }
    @And("^User clicks on the Back Link on Create New Manager page$")
    public void user_clicks_on_the_back_link_on_create_new_manager_page() throws Throwable {
    	createmanagerpage.clickOnBackLink();
    }
    //@Then("^User should be able to see Manager Contact Page$")
    public void user_should_be_able_to_see_manager1_contact1_page() throws Throwable {
        
    }
    @Then("^User should be able to see Enter Manager Details header on Manager Details Page$")
    public void user_should_be_able_to_see_enter_manager_details_header_on_manager_details_page() throws Throwable {
    	createmanagerpage.verifymanagerheaderdincreatemanagerpage();
    }
    @And("^User clicks on Next Button on Manager Page$")
    public void user_clicks_on_next_button_on_manager_page() throws Throwable {
    	createmanagerpage.clickOnNextButton();
    }
    @And("^User clicks on the (.+) attributes on Create New Manager Page$")
    public void user_clicks_on_the_attributes_on_create_new_manager_page(String key) throws Throwable {
    	createmanagerpage.clickOntheelementsoncreatemanagerpage(key);
    		  
    	}
    
    
    @Then("^User should be able to see the Status field should be in disabled state on Create New Manager page$")
    public void user_should_be_able_to_see_the_status_field_should_be_in_disabled_state_on_create_new_manager_page() throws Throwable {
    	createmanagerpage.verifystatusfieldincreatemanagerpage();  
    }
    @Then("^User should be able to see the below fields on Create New Manager page$")
    public void user_should_be_able_to_see_the_below_fields_on_create_new_manager_page(List<String> entity) throws Throwable {
    	for(int i =0;i<entity.size();i++) {
    		createmanagerpage.verifyElementsoncreatemanagerpage(createmanagerpage.findElementByDynamicXpath("//*[text()='"+entity.get(i)+"']"));
			 Reporter.addScreenCapture();
		}
   }
    }


