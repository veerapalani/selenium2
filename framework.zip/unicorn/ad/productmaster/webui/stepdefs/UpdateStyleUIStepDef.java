package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertEquals; 

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.IntegrationGeneric;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStylePage;

public class UpdateStyleUIStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	String expectedColorCode;
	String xpath, myValue, javaScript;
	Select dropdown;
	Boolean myFlag;
	String xpathForStaleElement = "//wf-input[@name='styleName']";
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/style/edit/";
	String pageURL2 = SSOLoginPage.URL + "#/style/add";
	WebElement myElement, myElement2;
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStyleUIPage"));
	UpdateStylePage updateStylePage = new UpdateStylePage();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyle3036.xlsx";
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);

	XSSFSheet sheet;
	int rowIndex, cellIndex;

	@Then("^User should be able to see the Enter Style Details header on Update Style page$")
	public void user_should_be_able_to_see_the_enter_style_details_header_on_update_style_page() throws Throwable {
		action.getElement("Enter Style Details").isDisplayed();
		Reporter.addStepLog("Enter style details header is present");
	}

	@Then("^user should be able to go Update Style UI screen$")
	public void user_should_be_able_to_go_update_style_ui_screen() throws Throwable {
		Assert.assertTrue(action.getCurrentURL().contains(pageURL), "We are in UpdateStrategyUIPage");
		Reporter.addScreenCapture();
	}
	
	@Then("^user should again be navigated to Update Style UI screen$")
    public void user_should_again_be_navigated_to_update_style_ui_screen() throws Throwable {
		Assert.assertTrue(action.getCurrentURL().contains(pageURL2), "We are in UpdateStrategyUIPage");
		Reporter.addScreenCapture();
    }
	
	@Then("^User should be able to see the Invalid Special Character Message while updating with the following values in following attributes in Update Style page$")
	public void user_should_be_able_to_see_the_invalid_special_character_message_while_updating_with_the_following_values_in_following_attributes_in_update_style_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Invalid_Special_Character_Message");
			myElement2 = updateStylePage.findElementByDynamicXpath(
					"//*[@label='" + attributeValuePair.get(i).get(0) + "']/following-sibling::p");
			Assert.assertTrue(myElement2.getText().contains(message));
			Reporter.addStepLog("verified the msg " + myElement2.getText());
		}
	}

	@Then("^User should not be able to see any error message while updating the following attributes with following values in Update Style page$")
	public void user_should_not_be_able_to_see_any_error_message_while_updating_the_following_attributes_with_following_values_in_update_style_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Invalid_Special_Character_Message");
			Assert.assertFalse(action.getPageSource().contains(message));
			Reporter.addStepLog("verified that there is no error message for " + attributeValuePair.get(i).get(0));
		}
	}

	@Then("^User should be able to see the Minimum Characters Message while updating with the following values in following attributes in Update Style page$")
	public void user_should_be_able_to_see_the_minimum_characters_message_while_updating_with_the_following_values_in_following_attributes_in_update_style_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Minimum_Character_Message");
			myElement2 = updateStylePage.findElementByDynamicXpath(
					"//*[@label='" + attributeValuePair.get(i).get(0) + "']/following-sibling::p");
			Assert.assertTrue(myElement2.getText().contains(message));
			Reporter.addStepLog("verified the msg " + myElement2.getText());
		}
	}

	@Then("^The following attributes should have the following maxlength in the Update Style page$")
	public void the_following_attributes_should_have_the_following_maxlength_in_the_update_style_page(
			List<List<String>> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			myElement = updateStylePage.findElementByDynamicXpath("//*[@label='" + items.get(i).get(0) + "']");
			Assert.assertEquals(action.getAttribute(myElement, "maxlength"), items.get(i).get(1));
		}
	}

	@Then("^User should be able to see and select the following attributes with the respective options in the Update Style UI$")
	public void user_should_be_able_to_see_and_select_the_following_attributes_with_the_respective_options_in_the_update_style_ui(
			List<List<String>> attributeValuePair) throws Throwable {
		for (int i = 0; i < attributeValuePair.size(); i++) {
			listOfElements = updateStylePage.findElementsByDynamicXpath(
					"//wf-select[@label='" + attributeValuePair.get(i).get(0) + "']/wf-select-option");
			String[] options = attributeValuePair.get(i).get(1).split(",");
			for (int j = 0; j < options.length; j++) {
				Assert.assertEquals(listOfElements.get(j).getAttribute("name"), options[j]);
				Reporter.addStepLog(
						"verified that " + options[j] + " is present in " + attributeValuePair.get(i).get(0));
			}
		}
	}

	@Then("^User should be able to see and select the following attributes with Yes or No radio button in the Update Style UI$")
	public void user_should_be_able_to_see_and_select_the_following_attributes_with_yes_or_no_radio_button_in_the_update_style_ui(
			List<String> attribute) throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			listOfElements = updateStylePage
					.findElementsByDynamicXpath("//wf-radio[@label='" + attribute.get(i) + "']/wf-radio-option");
			Assert.assertEquals(listOfElements.get(0).getAttribute("label"), "Yes");
			Reporter.addStepLog("Yes is present in " + attribute.get(i));
			Assert.assertEquals(listOfElements.get(1).getAttribute("label"), "No");
			Reporter.addStepLog("No is present in " + attribute.get(i));
		}
		Reporter.addScreenCapture();
	}

	@Then("^user should be able to see the following Column Headers in the Update Style UI$")
	public void user_should_be_able_to_see_the_following_column_headers_in_the_update_style_ui(List<String> items)
			throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < items.size(); i++) {
			myElement = updateStylePage.findElementByDynamicXpath("//*[@label='" + items.get(i) + "']");
			Assert.assertTrue(action.isDisplayed(myElement));
			Reporter.addStepLog(items.get(i) + " is present in Upate Style UI page");
		}

		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see and click Calender Icon and select any date in the following attributes in the Update Style UI$")
	public void user_should_be_able_to_see_and_click_calender_icon_and_select_any_date_in_the_following_attributes_in_the_update_style_ui(
			List<String> attribute) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {
			Reporter.addStepLog("document.querySelector(\"wf-calendar-picker[label='" + attribute.get(i)
					+ "']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\"wf-calendar-picker[label='" + attribute.get(i)
							+ "']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.click(myElement);
			// action.click(myElement);
			Reporter.addStepLog("return document.querySelector(\"wf-calendar-picker[label='" + attribute.get(i)
					+ "']\").shadowRoot.querySelector('div.calendar-wrapper')");
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\"wf-calendar-picker[label='" + attribute.get(i)
							+ "']\").shadowRoot.querySelector('div.calendar-wrapper')");
			Assert.assertTrue(myElement.isDisplayed());
			Reporter.addStepLog("The calender for " + attribute.get(i) + " is getting displayed");
		}
	}

	@Then("^User should not see any error while updating the following numeric fields with following values in Update Strategy UI$")
	public void user_should_not_see_any_error_while_updating_the_following_numeric_fields_with_following_values_in_update_strategy_ui(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			// verifying that no error message is there
			String message = Action.getTestData("Invalid_Numeric_Message");
			Assert.assertFalse(action.getPageSource().contains(message));
			Reporter.addStepLog("validated that no error message is there in " + attributeValuePair.get(i).get(0));

		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the format error by updating the following numeric fields with following values in Update Strategy UI$")
	public void user_should_be_able_to_see_the_format_error_by_updating_the_following_numeric_fields_with_following_values_in_update_strategy_ui(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			// verifying that no error message is there
			String message = Action.getTestData("Invalid_Numeric_Message");
			myElement2 = null;
			myElement2 = updateStylePage.findElementByDynamicXpath(
					"//*[@label='" + attributeValuePair.get(i).get(0) + "']//following-sibling::p");
			Assert.assertTrue(myElement2.getText().contains(message));
			Reporter.addStepLog("validated that the error message is " + myElement2.getText() + " below "
					+ attributeValuePair.get(i).get(0));

		}
		Reporter.addScreenCapture();
	}

	@Then("^User update the following textfields with Valid Data in the Update Style page$")
	public void user_update_the_following_textfields_with_valid_data_in_the_update_style_page(List<String> attribute)
			throws Throwable {
		sheetName = "Valid";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
//			if (attribute.get(i).equals("Description"))
//				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
//						+ attribute.get(i) + "']\").shadowRoot.querySelector('textarea')");
//			else
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector('input')");
			myElement.clear();

			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i));

		}
	}

	@And("^User update the following dopdown with Valid Data in the Update Style page$")
	public void user_update_the_following_dopdown_with_valid_data_in_the_update_style_page(List<String> attribute)
			throws Throwable {
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector('button')");
			action.scrollToElement(myElement);
			action.click(myElement);
			myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector(\"li[data-value='\\\""
					+ (String) exlObj.getCellData(sheet, rowIndex, cellIndex) + "\\\"']\")");
			action.click(myElement2);
		}
	}

	@Then("^User should be able to see the Style header on Update Style UI$")
	public void user_should_be_able_to_see_the_style_header_on_update_strategy_ui() throws Throwable {
		action.getElement("Style |").isDisplayed();
		Reporter.addStepLog("validate that the style header is present");
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Style Name below Style header on Update Style page$")
	public void user_should_be_able_to_see_the_style_name_below_style_header_on_update_strategy_page()
			throws Throwable {
		Assert.assertTrue(
				action.getElement("Style |").getText().contains(action.getElement("Style Name").getAttribute("value")));
		Reporter.addStepLog("validated that the style name header value matches with the style name");
		Reporter.addScreenCapture();
	}

	@And("^User update the following radio button with Valid Data in the Update Style page$")
	public void user_update_the_following_radio_button_with_valid_data_in_the_update_style_page(List<String> attribute)
			throws Throwable {
		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			if (myValue.equalsIgnoreCase("Yes")) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-radio[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector(\"button[data-index='0']\")");
				action.click(myElement);
			} else {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-radio[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector(\"button[data-index='1']\")");
				action.click(myElement);
			}
		}
	}

	@And("^User clicks the Next Button on Update Style page$")
	public void user_clicks_the_next_button_on_update_style_page() throws Throwable {
		action.click(action.getElement("Next Button"));
		Reporter.addStepLog("clicked on next button");
	}
	 @And("^User clicks on Previous Button on Update Style page$")
	    public void uer_clicks_on_previous_button_on_update_style_page() throws Throwable {
		 action.click(action.getElement("Previous Button"));
		 Reporter.addStepLog("clicked on previous button");
	    }
	 
	 @And("^User clicks on Back Link on Update Style page$")
	    public void user_clicks_on_back_link_on_update_style_page() throws Throwable {
		 action.click(action.getElement("Back Link"));
		 Reporter.addStepLog("clicked on Back Link");

	    }
	 
	 @Then("^Following attributes should be resetted to default values after clicking on reset button in Update Style page$")
	    public void following_attributes_should_be_resetted_to_default_values_after_clicking_on_reset_button_in_update_style_page(List<String> attribute) throws Throwable {
		 for(int i=0;i<attribute.size();i++) {
			 myElement =  updateStylePage.findElementByDynamicXpath("//*[@label='"+attribute.get(i)+"']");
			 myValue = myElement.getAttribute("value");
			 myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector('input')");
			 action.sendkeysClipboard(myElement2, updateStylePage.getCurrentTimeStamp());
			 Reporter.addStepLog("sent random keys to "+attribute.get(i));
			 action.click(action.getElement("Reset Button"));
			 Reporter.addStepLog("clicking on reset button");
			 myElement =  updateStylePage.findElementByDynamicXpath("//*[@label='"+attribute.get(i)+"']");
			 Assert.assertEquals(myElement.getAttribute("value"), myValue);
			 Reporter.addStepLog("validated that the value for "+attribute.get(i)+" is getting resetted");
			 
		 }
		 Reporter.addStepLog("validated the functionality of reset button");
	    }

	   
	    
	    @Then("^Following attributes should not be updateable in Update Style page$")
	    public void following_attributes_should_not_be_updateable_in_update_style_page(List<String> attribute) throws Throwable {
	       for(int i=0;i<attribute.size();i++) {
	    	myElement = updateStylePage.findElementByDynamicXpath("//*[@label='"+attribute.get(i)+"']");
	    	Assert.assertEquals("true", action.getAttribute(myElement, "disabled"));
	    	action.highligthElement(myElement);
	    	Reporter.addStepLog("validated that "+attribute.get(i)+" is not editable");
	       }
	       Reporter.addScreenCapture();
	       
	    }

}
