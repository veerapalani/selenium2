package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerContactPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerConfirmationPage;
public class ManagerConfirmationPageStepDef {

	CreateManagerConfirmationPage con=new CreateManagerConfirmationPage("AD_PM_CreateManagerConfirmationPage");
	UpdateManagerConfirmationPage confirmationPage = new UpdateManagerConfirmationPage("AD_PM_UpdateManagerConfirmationPage");
	Process p = null;
	String kafkaPath = "D://kafka_2.13-2.4.0//bin//windows";
	String testmucNHLogFilePath, testmucDHLogFilePath = "";
	String strategyCode = null;
	String strategyName = "";
	String userinfo = null;
	@Then("^User should be able to see the below fields on Create Manager Confirmation page$")
    public void user_should_be_able_to_see_the_below_fields_on_create_manager_confirmation_page(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			con.verifyElementsoncreatebenchmarkconfirmationpage(
					con.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addCompleteScreenCapture();
		}
		confirmationPage.verifyManagerID();
		confirmationPage.clickOnDoneButton();
    }
	
	@And("^a Payload is sent to Data Hub after Creation of manager$")
    public void a_payload_is_sent_to_data_hub_after_creation_of_manager() throws Throwable {
		Thread.sleep(10000);

		FileReader fr = new FileReader(testmucDHLogFilePath);
		BufferedReader br = new BufferedReader(fr);

		String line;

		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;

		while ((line = br.readLine()) != null) {

			if (line.contains(strategyCode)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}

		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Strategy Name: </b>" + strategyName);
		Reporter.addStepLog("<b>Strategy Code: </b>" + strategyCode);

		if (line.contains(strategyName)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyName));

		}
		if (line.contains(strategyCode)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyCode));
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
    }
	@And("^User clicks on the Create Another Manager Button on Manager Confirmation Page$")
    public void user_clicks_on_the_create_another_manager_button_on_manager_confirmation_page() throws Throwable {
        con.clickOncreateanothermanagerbutton();
    }
	@And("^User clicks on the Back Link on Manager Confirmation Page$")
    public void user_clicks_on_the_back_link_on_manager_confirmation_page() throws Throwable {
        con.clickOnbacklink();
        Reporter.addScreenCapture();
    }
	
	@And("^a notification is sent to Notification Hub after Creation of Manager$")
    public void a_notification_is_sent_to_notification_hub_after_creation_of_manager() throws Throwable {
		Thread.sleep(10000);

		FileReader fr = new FileReader(testmucNHLogFilePath);
		BufferedReader br = new BufferedReader(fr);

		String line;

		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;

		while ((line = br.readLine()) != null) {

			if (line.contains(strategyCode)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}

		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucNHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Strategy Name: </b>" + strategyName);
		Reporter.addStepLog("<b>Strategy Code: </b>" + strategyCode);

		if (line.contains(strategyName)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyName));

		}
		if (line.contains(strategyCode)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyCode));
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
    }
	@And("^User clicks on Done Button on Manager Confirmation page$")
    public void user_clicks_on_done_button_on_manager_confirmation_page() throws Throwable {
       con.clickOnDoneButton();
       Reporter.addStepLog("clicked on done button");
    }
    }

