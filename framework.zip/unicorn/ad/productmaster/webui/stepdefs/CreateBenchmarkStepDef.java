package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateBenchmarkStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);

	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	Alert alert;
	//PMPageGeneric createbenchmarkpage = new PMPageGeneric("AD_PM_CreateBenchmarkPage");
	CreateBenchmarkPage cb1 = new CreateBenchmarkPage("AD_PM_CreateBenchmarkPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateBenchmark.xlsx";
	String option, sheetName = "";
	int rowIndex;

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;

	public static String benchmarkName1, benchmarkCode1 = null;

	
	@Then("^User should be able to see the \"([^\"]*)\" should be in disabled state on Create New Benchmark page$")
	public void user_should_be_able_to_see_the_something_should_be_in_disabled_state_on_create_new_benchmark_page(
			String key) throws Throwable {
		//createbenchmarkpage.verifyElementFromShadowRootdisable(key);
	}

	@And("^User clicks on the (.+) attributes on Create New Benchmark Page$")
    public void user_clicks_on_the_attributes_on_create_new_benchmark_page(String key) throws Throwable {
        cb1.clickOnpreviousandbacklinkoncreatebenchmarkpage(key);
    }

	@Then("^User should be able to see the below fields on Create New Benchmark page$")
    public void user_should_be_able_to_see_the_below_fields_on_create_new_benchmark_page(List<String> entity) throws Throwable {
		for(int i =0;i<entity.size();i++) {
			cb1.verifyElementsoncreatebenchmarkpage(cb1.findElementByDynamicXpath("//*[text()='"+entity.get(i)+"']"));
			 Reporter.addScreenCapture();
		}
    }
	@Then("^User should be able to see the Timestamp on Create New Benchmark page$")
    public void user_should_be_able_to_see_the_timestamp_on_create_new_benchmark_page() throws Throwable {
        cb1.verifytimestampinCreateBenchmarkPage();
    }
	
	@Then("^User should be able to see the Benchmark Name Header on Create New Benchmark page$")
    public void user_should_be_able_to_see_the_benchmark_name_header_on_create_new_benchmark_page() throws Throwable {
        cb1.verifybenchmarkheaderinCreateBenchmarkPage();
    }
	
	@Then("^User should be able to see the Status field should be in disabled state on Create New Benchmark page$")
    public void user_should_be_able_to_see_the_status_field_should_be_in_disabled_state_on_create_new_benchmark_page() throws Throwable {
        cb1.verifystatusfieldisdisabledincreatebenchmarkpage();
    }
	@Then("^User is able to see Enter Benchmark Details Page$")
	public void user_is_able_to_see_enter_benchmark_details_page() throws Throwable {
		assertTrue(cb1.isUserOnCreateBenchmarkPage());
		Reporter.addScreenCapture();
	}
	
	@When("^User enters (.+) in all the fields$")
	public void user_enters_in_all_the_fields(String option) throws Throwable {
		if (option.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
		
		

		String benchmarkCode = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String benchmarkType = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String benchmarkDescription = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String benchmarkPercentage = (String) exlObj.getCellData(sheet, rowIndex, 4).toString();
		String benchmarkName = (String) exlObj.getCellData(sheet, rowIndex, 5);
		exlObj.closeWorkBook();
		if (benchmarkCode != "") {
			cb1.enterBenchmarkCode(benchmarkCode);
		}
		if (benchmarkName != "") {
			cb1.enterBenchmarkName(benchmarkName);
		}
		if (benchmarkDescription != "") {
			cb1.enterBenchmarkDescriptionValue(benchmarkDescription);
		}
		if (benchmarkPercentage != "") {
			cb1.enterBenchmarkPercentageValue(benchmarkPercentage);
		}
		if (benchmarkType != "") {
			cb1.selectBenchmarkType(benchmarkType);
		}

		Reporter.addScreenCapture();
	}

	@And("^User clicks on Next Button on Benchmark Page$")
	public void user_clicks_on_next_button_on_benchmark_page() throws Throwable {
		cb1.clickOnNextButton();
	}
	
	@Then("^User is able to see error message on benchmark page$")
    public void user_is_able_to_see_error_message_on_benchmark_page() throws Throwable {
		String expError = (String) exlObj.getCellData(sheet, rowIndex, 7);
		String errKey = (String) exlObj.getCellData(sheet, rowIndex, 6);
		cb1.validatingErrorMessage(errKey, expError);
		assertTrue(cb1.validatingErrorMessage(errKey, expError));
    }

}
