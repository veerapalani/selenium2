package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAViewPage;

public class UpdateFAViewStepDef {
	UpdateFAViewPage viewPage = new UpdateFAViewPage("AD_PM_UpdateFAViewPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
	//ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	//XSSFSheet sheet;
	String mandatorydetails, sheetName = "";
	int rowIndex;
	String label, attributeValue, uiValue, dbValue = null;

	@Then("^User should be able to see View FA Details Page in Update FA Flow$")
	public void user_should_be_able_to_see_view_fa_details_page_in_update_fa_flow() {
		Assert.assertTrue(viewPage.isUserOnViewFAPage());
	}

	@Then("^user is able to navigate to view details page of FA$")
	public void user_is_able_to_navigate_to_view_details_page_of_fa(List<String> entity) {
		for(int i = 0; i < entity.size(); i++) {
			viewPage.verifyElementsOnViewFAage(entity);
		}
	}

	@And("^user is able to see below button on upper right side of screen$")
	public void user_is_able_to_see_below_button_on_upper_right_side_of_screen(List<String> entity) {
		for(int i = 0; i < entity.size(); i++) {
			viewPage.verifyContinueEditingAndCancelButtonsOnViewFAage(entity);
		}
	}

	@When("^user clicks on \"([^\"]*)\" icon$")
	public void user_clicks_on_something_icon(String strArg1) throws Throwable {
		viewPage.clickOnContinueEditingLink();
	}

	@And("^with FA ID from UI store the data related to FA from DB in Excel for (.+) in Update FA Flow$")
	public void with_fa_id_from_ui_store_the_data_related_to_fa_from_db_in_excel_for_in_update_fa_flow(
			String mandatorydetails) throws IOException, SQLException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		///mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		String faID = viewPage.getFAID();
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 45, faID);
		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex + 1, 45, faID);
		int updateDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex + 1;
		getDataFromDBandStoreInExcel(faID, dBDataRowIndex);
	}

	private void getDataFromDBandStoreInExcel(String faID, int dBDataRowIndex) throws IOException, SQLException {
		pmdb.DBConnectionStart();
		String SQLquery, labelname = null;
		String dbDataIterator = "testNull";
		ResultSet rs;
		sheetName = "SQLQuery";
		int cellnum = 1;
		String label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
		//(String) exlObj.getCellData(sheet, cellnum, 0).toString();
		ArrayList<String> tempData = new ArrayList<String>();
		if(label == "")
			label = "isEmpty";
		while(label != "isEmpty") {
			if(label.contains("ignore")) {
				cellnum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
				//(String) exlObj.getCellData(sheet, cellnum, 0);
				if(label == "")
					label = "isEmpty";
			}
			else {
				dbDataIterator = "testnull";
				SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
				//(String) exlObj.getCellData(sheet, cellnum, 1);
				labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
				//(String) exlObj.getCellData(sheet, cellnum, 2);
				SQLquery = SQLquery.replace("@data", "'" + faID + "'");
				rs = DBManager.executeSelectQuery(SQLquery);
				while(rs.next()) {
					dbDataIterator = rs.getString(labelname);
					if(rs.wasNull() || dbDataIterator.isEmpty()) {
						dbDataIterator = "isEmpty";
						if(label.contains("radiobutton")) {
							dbDataIterator = "f";
						}
					}
					tempData.add(dbDataIterator);
				}
				//to handle Zero records from DB 
				if(dbDataIterator.equalsIgnoreCase("testnull")) {
					dbDataIterator = "isEmpty";
				}
				//to handle multiple values for same column
				if(tempData.size() > 1) {
					Collections.sort(tempData);
					dbDataIterator = "";
					for(String G: tempData) {
						dbDataIterator = dbDataIterator + G + ",";
					}
					dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length() - 1);
				}
				tempData.clear();
				//setting data into excel for validation
				sheetName = "Test";
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, dBDataRowIndex, cellnum + 2, dbDataIterator);
				//exlObj.setCellData(sheet, cellnum, 3, dbDataIterator);
				sheetName = "SQLQuery";
				cellnum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
				if(label == "")
					label = "isEmpty";
			}
		}
		//exlObj.closeWorkBook();
		pmdb.DBConnectionClose();
	}

	@And("^with FA ID from UI store the data related to FA from view page in Excel for (.+) in Update FA Flow$")
	public void with_fa_id_from_ui_store_the_data_related_to_fa_from_view_page_in_excel_for_in_update_fa_flow(
			String mandatorydetails) throws IOException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		String faID = viewPage.getFAID();
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 45, faID);
		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex + 2, 45, faID);
		int viewPageDataRowIndex = rowIndex + 2;
		getDataFromViewPageandStoreInExcel(faID, viewPageDataRowIndex);
	}

	private void getDataFromViewPageandStoreInExcel(String faID, int viewPageDataRowIndex) throws IOException {
		Action.scrollToUp();
		sheetName = "Test";
		Boolean flag = false;
		if(viewPage.areDocumentsDisplayedInUI()) {
			flag = true;
		}
		//count = 0;
		int columNum = 3;
		label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
		//(String) exlObj.getCellData(sheet, rownum, 0);
		if(label == "")
			label = "isEmpty";
		while(label != "isEmpty") {
			if(label.contains("ignore") || label.contains("NIVDP")) {
				columNum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
				//(String) exlObj.getCellData(sheet, rownum, 0).toString();
				if(label == "")
					label = "isEmpty";
			}
			else {
				if(label.contains("Document")) {
					if(flag)
						attributeValue = getDataFromViewPage(label);
					else
						attributeValue = "isEmpty";
				}
				else
					attributeValue = getDataFromViewPage(label);
				if(label.split(" - ")[0].equals("radiobutton")) {
					switch(attributeValue.toLowerCase().trim()) {
						case "yes":
							attributeValue = "t";
							break;
						case "no":
							attributeValue = "f";
							break;
						default:
							break;
					}
				}
				dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex - 1, columNum);
				if(dbValue.equals(attributeValue)) {
					PMPageGeneric.setCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex, columNum,
							attributeValue);
					//exlObj.setCellData(sheet, rownum, 4, attributeValue);
				}
				else {
					PMPageGeneric.setCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex, columNum,
							attributeValue + " -UI Value is not same as Stored Value in DB");
					Reporter.addEntireScreenCaptured();
					Reporter.addStepLog(
							"For Attribute - " + label + " UI Value Prepopulated is not same as Stored Value in DB");
				}
				columNum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
				//(String) exlObj.getCellData(sheet, rownum, 0).toString();
				if(label == "")
					label = "isEmpty";
			}
		}
		//			if(count > 0) {
		//				Assert.fail("Prepopulated Values are not same as values stored in DB");
		//			}
		Reporter.addCompleteScreenCapture();
		Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
		//exlObj.closeWorkBook();
	}

	private String getDataFromViewPage(String data) {
		switch(data) {
			case "txt - Branch Manager/Market Head":
				uiValue = viewPage.getManagerHeadValue();
				break;
			case "txt - FA Name":
				uiValue = viewPage.getFANameValue();
				break;
			case "txt - FA Email":
				uiValue = viewPage.getFAEmailValue();
				break;
			case "grey - FA ID(s)":
				uiValue = viewPage.getFAIDValue();
				break;
			case "grey - Universal ID(s)":
				uiValue = viewPage.getUniversalIDValue();
				break;
			case "grey - CRD#(s)":
				uiValue = viewPage.getCRDValue();
				break;
			case "radiobutton - Is nomination for a recruit?":
				uiValue = viewPage.getNominationForRecruitValue();
				break;
			case "date - Recruit Hire Date":
				uiValue = viewPage.getRecruitHireDataValue();
				break;
			case "txt - Prior Firm":
				uiValue = viewPage.getPriorFirmValue();
				break;
			case "radiobutton - Previously Approved for FA Discretionary Program?":
				uiValue = viewPage.getPreviouslyApprovedorNotForFADiscretionaryProgramValue();
				break;
			case "drp - FA Discretionary Program Name":
				uiValue = viewPage.getFADiscretionaryProgramValue();
				break;
			case "drp - FA Segment":
				uiValue = viewPage.getFASegmentValue();
				break;
			case "radiobutton - Re-Nomination":
				uiValue = viewPage.getRenominationValue();
				break;
			case "date - Re-Nomination Date":
				uiValue = viewPage.getRenominationDateValue();
				break;
			case "txtint - Length of Series 7 Registration":
				uiValue = viewPage.getSeries7RegistrationValue();
				break;
			case "txtint - Length of Series 65 or 66 Registration":
				uiValue = viewPage.getSeries65RegistrationValue();
				break;
			case "txtint - Length of Service as a FA":
				uiValue = viewPage.getLenghtOfServiceAsFAValue();
				break;
			case "txtint - FA Assets Under Management (AUM in $)":
				uiValue = viewPage.getAUMValue();
				break;
			case "txtint - Anticipated Percentage of Overall Business in PMP/AAP":
				uiValue = viewPage.getAnticipatedPercentageValue();
				break;
			case "txt - Branch":
				uiValue = viewPage.getBranchValue();
				break;
			case "txt - Complex":
				uiValue = viewPage.getComplexValue();
				break;
			case "txt - Division":
				uiValue = viewPage.getDivisionValue();
				break;
			case "txt - Region":
				uiValue = viewPage.getRegionValue();
				break;
			case "radiobutton - CFA or ACPM Charter Holder?":
				uiValue = viewPage.getCFAorACPMValue();
				break;
			case "radiobutton - Waive / completed course work":
				uiValue = viewPage.getWaiverorCompletedCourseValue();
				break;
			case "date - Zoologic course work registration date":
				uiValue = viewPage.getZoologicCourseRegistrationValue();
				break;
			case "date - Zoologic course work completed date":
				uiValue = viewPage.getZoologicCourseCompletedValue();
				break;
			case "txt - Awards/Citations/Certifications":
				uiValue = viewPage.getAwardsValue();
				break;
			case "txt - Additonal Information":
				uiValue = viewPage.getAdditionalInformationValue();
				break;
			case "drp - Document Type":
				uiValue = viewPage.getDocumentTypeValue();
				break;
			case "txt - Document Link":
				uiValue = viewPage.getDocumentLinkValue();
				break;
			case "txt - Document Comment":
				uiValue = viewPage.getDocumentCommentValue();
				break;
			case "radiobutton - Exception / Conditional Approval":
				uiValue = viewPage.getExceptionorConditionApprovalValue();
				break;
			case "date - Expiration Date":
				uiValue = viewPage.getExpirationDateValue();
				break;
			case "txt - Home Office Comments":
				uiValue = viewPage.getHomeOfficeCommentsValue();
				break;
			case "grey - Approver Name":
				uiValue = viewPage.getApproverNameValue();
				break;
			case "drp - FA Status":
				uiValue = viewPage.getFAStatusValue();
				break;
			case "date - Status Date":
				uiValue = viewPage.getStatusDateValue();
				break;
			case "date - Follow-up Date":
				uiValue = viewPage.getFollowUpDateValue();
				break;
			case "txt - Follow-up":
				uiValue = viewPage.getFollowUpValue();
				break;
			default:
				uiValue = "NotChanged";
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
		return uiValue;
	}

	@And("^strategies linked to FA should be displayed in View Page in Update Manager Flow$")
	public void strategies_linked_to_fa_should_be_displayed_in_view_page_in_update_manager_flow() throws SQLException {
		String faID = viewPage.getFAID();
		Boolean bool = viewPage.isAssociatedStrategiesGridDisplayed();
		if(bool) {
			HashMap<String, ArrayList<String>> accessStrategiesMap = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> dualStrategiesMap = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> swpStrategiesMap = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> pmpStrategiesMap = new HashMap<String, ArrayList<String>>();
			accessStrategiesMap = viewPage.getSortedAccessStrategyData();
			dualStrategiesMap = viewPage.getSortedDualStrategyData();
			swpStrategiesMap = viewPage.getSortedSWPStrategyData();
			pmpStrategiesMap = viewPage.getSortedPMPStrategyData();
			/*
			 * Program codes
			 * 
			 * SMA Access -- 15 SMA SWP -- 36 PMP -- 12 Dual -- 13,39
			 *
			 */
			HashMap<String, ArrayList<String>> accessStrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> dualStrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> swpStrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> pmpStrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			accessStrategiesMapFromDB = getAssociatedStrategiesData("15", faID);
			dualStrategiesMapFromDB = getAssociatedStrategiesData("13,39", faID);
			swpStrategiesMapFromDB = getAssociatedStrategiesData("36", faID);
			pmpStrategiesMapFromDB = getAssociatedStrategiesData("12", faID);
			Assert.assertTrue(accessStrategiesMapFromDB.equals(accessStrategiesMap));
			Assert.assertTrue(swpStrategiesMapFromDB.equals(swpStrategiesMap));
			Assert.assertTrue(pmpStrategiesMapFromDB.equals(pmpStrategiesMap));
			Assert.assertTrue(dualStrategiesMapFromDB.equals(dualStrategiesMap));
		}
		else {
			Reporter.addStepLog("No associated strategies in UI");
		}
	}

	private HashMap<String, ArrayList<String>> getAssociatedStrategiesData(String programCode, String faID)
			throws SQLException {
		HashMap<String, ArrayList<String>> StrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
		ArrayList<String> rowData = new ArrayList<String>();
		pmdb.DBConnectionStart();
		String SQLquery, labelname = null;
		String dbDataIterator = "testNull";
		ResultSet rs;
		sheetName = "Query";
		dbDataIterator = "testnull";
		SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 2, 1);
		labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 2, 2);
		String[] columnName = labelname.split(",");
		SQLquery = SQLquery.replace("@data", "'" + faID + "'");
		if(programCode.contains(",")) {
			String[] data = programCode.split(",");
			programCode = "in ('" + data[0] + "','" + data[1] + "')";
		}
		else {
			programCode = "= '" + programCode + "'";
		}
		SQLquery = SQLquery.replace("@programcode", programCode);
		rs = DBManager.executeSelectQuery(SQLquery);
		while(rs.next()) {
			for(String iterator: columnName) {
				dbDataIterator = rs.getString(iterator);
				if(rs.wasNull() || dbDataIterator.isEmpty()) {
					dbDataIterator = "isEmpty";
				}
				rowData.add(dbDataIterator);
			}
			StrategiesMapFromDB.put(rowData.get(4), rowData);
			rowData.clear();
		}
		//to handle Zero records from DB 
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			switch(programCode) {
				case "15":
					rowData.add("No SMA Single-Access strategy associated");
					StrategiesMapFromDB.put("No FOA Code", rowData);
					break;
				case "12":
					rowData.add("No PMP Strategy associated");
					StrategiesMapFromDB.put("No FOA Code", rowData);
					break;
				case "36":
					rowData.add("No SMA Single - SWP/AAP Strategy associated");
					StrategiesMapFromDB.put("No FOA Code", rowData);
					break;
				case "13,39":
					rowData.add("No SMA Dual Strategy associated");
					StrategiesMapFromDB.put("No FOA Code", rowData);
					break;
				default:
					break;
			}
		}
		//exlObj.closeWorkBook();
		pmdb.DBConnectionClose();
		return sortHashMapBasedOnFOACode(StrategiesMapFromDB);
	}

	private HashMap<String, ArrayList<String>> sortHashMapBasedOnFOACode(
			HashMap<String, ArrayList<String>> accessStrategiesMap) {
		Set<Entry<String, ArrayList<String>>> customBenchmarkEntrySet = accessStrategiesMap.entrySet();
		List<Entry<String, ArrayList<String>>> entryList = new ArrayList<Entry<String, ArrayList<String>>>(
				customBenchmarkEntrySet);
		//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().compareTo(o2.getKey()));
		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, ArrayList<String>> sortedHashMap = new LinkedHashMap<String, ArrayList<String>>();
		for(Entry<String, ArrayList<String>> entry: entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}
		/*
		 * for (String countryKey : sortedHashMap.keySet()) {
		 * System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		 * 
		 * }
		 */
		return sortedHashMap;
	}

	@Then("^user should able to see strategy details in view FA page$")
	public void user_should_able_to_see_strategy_details_in_view_FA_page() {
		viewPage.isUserOnViewFAPage();
		viewPage.isAssociatedStrategiesGridDisplayed();
		viewPage.isStrategyTableDisplayed("access");
		viewPage.isStrategyTableDisplayed("dual");
		viewPage.isStrategyTableDisplayed("aap");
		viewPage.isStrategyTableDisplayedWithTable("pmp");
	}
	
	
}
