package qa.unicorn.ad.productmaster.webui.stepdefs;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.utils.Reporter;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.RestApiHelperMethods;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;



public class UIProgramEntityStepDef {
	
	PMPageGeneric programEntity=new PMPageGeneric("AD_PM_ProgramEntityPage");
	String activeLink = "Program";
	String expectedColorCode,xpath;
	String pageURL = "http://10.49.116.4:8080/pmui/?#/program";
	List<WebElement> listOfElements,listOfElements2 = new ArrayList<WebElement>();
    @Then("^Program Link should be active$")
    public void program_link_should_be_something() throws Throwable {
        programEntity.verifyAttribute("true", activeLink, "selected");
    }
    

    
    @Then("^User should be able to see \"([^\"]*)\" in \"([^\"]*)\" on program Entity page$")
    public void user_should_be_able_to_see_something_on_program_Entity_page(String list1, String key) throws Throwable {
    	String[] listArray = list1.split(", ");
    	listOfElements =  programEntity.getElements(key);
    	for(int i=0;i<listArray.length;i++) {
    		programEntity.verifyTextInListOfElements(listArray[i], listOfElements);
    		Reporter.addStepLog(listArray[i]+" is displaying in " + key);
    	}
    }

    @And("^Order of the \"([^\"]*)\" should be \"([^\"]*)\" on program Entity page$")
    public void order_of_the_something_should_be_something_on_program_Entity_page(String key, String list1) throws Throwable {
    	 String[] listArray = list1.split(", ");
     	listOfElements =  programEntity.getElements(key);
     	for(int i=0;i<listArray.length;i++) {
     		Assert.assertEquals( listOfElements.get(i).getText(),listArray[i]);
     		Reporter.addStepLog(listOfElements.get(i).getText()+" is the "+i+" element in " + key);
     	}
    }

    @And("^All the \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on program Entity page$")
    public void all_the_something_should_be_displayed_in_something_color_on_program_Entity_page(String key, String color) throws Throwable {
        listOfElements = programEntity.getElements(key);
        expectedColorCode = Action.getTestData(color);
        for(int i=0;i<listOfElements.size();i++) {
        	programEntity.verifyColor(listOfElements.get(i), expectedColorCode);
        }
        
        
    }
    @Then("^User should be able to see \"([^\"]*)\" in every row of \"([^\"]*)\" on program Entity page$")
    public void user_should_be_able_to_see_something_in_every_row_of_something_on_program_Entity(String insideElementKey, String key) throws Throwable {
    	listOfElements = programEntity.getElements(key);        
        for(int i=1;i<=Math.min(listOfElements.size(),10);i++) {
        	xpath="//tr[@class='divider divider-top divider-03 divider-color-03']["+i+"]//wf-icon[@name='ellipsis-v-solid']";
        	programEntity.verifyElement(programEntity.findElementByDynamicXpath(xpath));
        	Reporter.addStepLog("verified "+insideElementKey+ " for element no "+(i));
        	programEntity.scrollByPixel(100);
        }
    }
    
    @Then("^User should be able to see the Following \"([^\"]*)\" while \"([^\"]*)\" on the Ellipse Icon in every row of \"([^\"]*)\" on Program Entity page$")
    public void user_should_be_able_to_see_the_following_something_while_something_on_the_ellipse_icon_in_every_row_of_something_on_program_entity_page(String options, String insideElementKey, String strArg2) throws Throwable {
    	Thread.sleep(3000);
		programEntity.hoverOnElement(programEntity.getElementFromShadowRoot(insideElementKey));
		Thread.sleep(1000);
		programEntity.verifyElement(options);
		Reporter.addStepLog("verified "+options+ " for element");
		programEntity.scrollByPixel(100); 
    }

   
    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Program Entity page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_program_entity_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
    	programEntity.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = programEntity.getElementsFromShadowRoot(key);
   	 programEntity.verifyTextInListOfElements( items.get(i),listOfElements);  
        } 
    }
    @Then("^User should be able to see the \"([^\"]*)\" header on Program Entity page$")
    public void user_should_be_able_to_see_the_something_header_on_program_entity_page(String key) throws Throwable {
        programEntity.verifyHeader(key);
    }
    @Then("^User should be able to see the \"([^\"]*)\" at the \"([^\"]*)\" on Program Entity page$")
    public void user_should_be_able_to_see_the_something_at_the_something_on_program_entity_page(String key, String shadowRootKey) throws Throwable {
    	programEntity.verifyElement(programEntity.fetchElementFromShadowRoot(key, shadowRootKey));
    }

    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Program Entity page$")
    public void something_should_be_displayed_in_something_color_on_program_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	programEntity.verifyColor(key,expectedColorCode);
    	
    }
    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Program Entity page$")
    public void something_should_be_displayed_in_something_color_inside_program_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	programEntity.verifyColor(programEntity.getElementFromShadowRoot(key),expectedColorCode);
    }

    @And("^\"([^\"]*)\" should have \"([^\"]*)\" background color on Program Entity page$")
    public void something_should_have_something_background_color_on_program_entity_page(String key, String backgroundColor) throws Throwable {
    	expectedColorCode = Action.getTestData(backgroundColor);
    	programEntity.verifyBackgroundColor(key,expectedColorCode);
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Program Entity page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_on_program_entity_page(String ghostText, String searchBox) throws Throwable {
    	programEntity.verifyGhostText(ghostText, programEntity.getElementFromShadowRoot(searchBox));
    }

    @And("^User should be able to see the \"([^\"]*)\" on Program Entity page$")
    public void user_should_be_able_to_see_the_something_on_program_entity_page(String key) throws Throwable {
    	programEntity.verifyElement(key);
    }

    @Then("^User should be able to see the \"([^\"]*)\" inside Program Entity page$")
    public void user_should_be_able_to_see_the_something_inside_program_entity_page(String key) throws Throwable {
        programEntity.verifyElementFromShadowRoot(key);
    }

    @And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Program Entity page$")
    public void that_something_should_be_displayed_in_something_color_on_program_entity_page(String key, String expectedColor) throws Throwable {
    	expectedColorCode = Action.getTestData(expectedColor);
    	programEntity.verifyCurrentElementColor(expectedColorCode);
    }

    @And("^The \"([^\"]*)\" on the Program Entity page should contain all the following options$")
    public void the_something_on_the_Program_Entity_page_should_contain_all_the_following_options(String key,List<String> items) throws Throwable {
    	for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   	 programEntity.verifyTextInListOfElements( items.get(i), programEntity.getElements(key)); 
   	 } 
    }
    @Then("^User should be able to see only \"([^\"]*)\" \"([^\"]*)\" on Program Entity Page$")
    public void user_should_be_able_to_see_only_something_something_on_program_entity_page(String numberOfItems, String key) throws Throwable {
        listOfElements = programEntity.getElements(key);
        Assert.assertEquals(Integer.parseInt(numberOfItems), listOfElements.size());
        Reporter.addStepLog("verified that "+numberOfItems+" "+key+" present");
    }
    @Then("^\"([^\"]*)\" should not be displayed in \"([^\"]*)\" on Program Entity Page$")
    public void something_should_not_be_displayed_in_something_on_program_entity_page(String item, String key) throws Throwable {
    	listOfElements = programEntity.getElements(key);
        programEntity.verifyTextNotPresentInListOfElements(item, listOfElements);
        Reporter.addStepLog("verified that "+item+" is not present in "+key);
    }
    
    @And("^user hover over the \"([^\"]*)\" of first element of \"([^\"]*)\" on Program Entity page$")
    public void user_hover_over_the_something_of_first_element_of_something_on_program_entity_page(String insideElementKey, String parentElementKey) throws Throwable {
		listOfElements = programEntity.getElements(insideElementKey);
		programEntity.hoverOnElement(listOfElements.get(0));
		Reporter.addStepLog("hovering on "+insideElementKey);
    }
	@And("^user clicks the \"([^\"]*)\" Link on Program Entity page$")
    public void user_clicks_the_something_link_on_program_entity_page(String key) throws Throwable {
        programEntity.clickOnLink(key);
        Reporter.addStepLog("clicking on "+key);
    }
	
	@Then("^user should be able to go to Program Entity page$")
    public void user_should_be_able_to_go_to_program_entity_page() throws Throwable {
        programEntity.verifyPageURL(pageURL);
        Reporter.addScreenCapture();
    }
}


