package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import com.ibm.db2.jcc.am.db;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAEnterFADetailsPage;

public class UpdateFAEnterFADetailsStepDef {
	
	UpdateFAEnterFADetailsPage faDetailsPage = new UpdateFAEnterFADetailsPage("AD_PM_UpdateFAEnterFADetailsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue, flowPageData = null;
	
	@Then("^User should be able to see Enter FA Details Page in Update FA Flow$")
    public void user_should_be_able_to_see_enter_fa_details_page_in_update_fa_flow() throws Throwable {
		Assert.assertTrue(faDetailsPage.isUserOnEnterFADetailsPage());
    }
	
	@Then("^user is able to navigate to Edit details screen for FA$")
	public void user_is_able_to_navigate_to_edit_details_screen_for_fa(List<String> entity) {
		
		for (int i = 0; i < entity.size(); i++) {
			faDetailsPage.verifyEditFAFAage(entity);
		}

	}
	
	@And("^User clicks on Next Button on the Create FA Update Page$")
	public void user_clicks_on_next_button_on_the_create_fa_update_page() throws Throwable {
		faDetailsPage.clickonnextbutton();
	}
	
	@And("^User clicks on Next Button on the Enter FA Details Page in Update FA Flow$")
    public void user_clicks_on_next_button_on_the_enter_fa_details_page_in_update_fa_flow() {
		faDetailsPage.clickonnextbutton();
    }
	
	@And("^Data prepopulated in Enter FA Details page should match with DB Data in Update FA flow for (.+)$")
    public void data_prepopulated_in_enter_fa_details_page_should_match_with_db_data_in_update_fa_flow_for(String mandatorydetails) {
    	//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 3;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int dbDataRowIndex = rowIndex+1;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("Delete Documents_ignore"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Documents_ignore"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterFADetailsPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);	
						//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						
						//To handle "0.00" values from DB
						if(label.contains("FA Assets") || label.contains("Anticipated")) {
							if(dbValue.substring(0, 2).equals("0."))
								dbValue = "isEmpty";
						
							//To Handle AUM Value comparision
							if(label.contains("txtint")) {
								dbValue = String.valueOf(Float.parseFloat(dbValue+"f"));
								attributeValue = String.valueOf(Float.parseFloat(attributeValue+"f"));
								}
								
						}
						System.out.println(label+" - DB Value :: "+dbValue+" - Attribute value :: "+attributeValue);
						if(dbValue.equals(attributeValue)) {
							
						}else {
							
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							Assert.fail(label);
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Documents_ignore"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }

    private String getDataFromEnterFADetailsPage(String data) {
	    	switch (data) {
			case "txt - Branch Manager/Market Head":
				
				uiValue = faDetailsPage.getManagerHeadValue();
				
				break;
			case "txt - FA Name":
				
				uiValue = faDetailsPage.getFANameValue();
				
				break;
			case "txt - FA Email":
				
				uiValue = faDetailsPage.getFAEmailValue();
				
				break;
			case "grey - FA ID(s)":
				
				uiValue = faDetailsPage.getFAIDValue();
				
				break;
			case "grey - Universal ID(s)":
				
				uiValue = faDetailsPage.getUniversalIDValue();
				
				break;
			case "grey - CRD#(s)":
				
				uiValue = faDetailsPage.getCRDValue();
				
				break;
			case "radiobutton - Is nomination for a recruit?":
				
				uiValue = faDetailsPage.getNominationForRecruitValue();
				
				break;
			case "date - Recruit Hire Date":
				
				uiValue = faDetailsPage.getRecruitHireDataValue();
				
				break;
			case "txt - Prior Firm":
				
				uiValue = faDetailsPage.getPriorFirmValue();
				
				break;
			case "radiobutton - Previously Approved for FA Discretionary Program?":
				
				uiValue = faDetailsPage.getPreviouslyApprovedorNotForFADiscretionaryProgramValue();
				
				break;
			case "drp - FA Discretionary Program Name":
				
				uiValue = faDetailsPage.getFADiscretionaryProgramValue();
				
				break;
			case "drp - FA Segment":
				
				uiValue = faDetailsPage.getFASegmentValue();
				
				break;
			case "radiobutton - Re-Nomination":
				
				uiValue = faDetailsPage.getRenominationValue();
				
				break;
			case "date - Re-Nomination Date":
				
				uiValue = faDetailsPage.getRenominationDateValue();
				
				break;
			case "txtint - Length of Series 7 Registration":
				
				uiValue = faDetailsPage.getSeries7RegistrationValue();
				
				break;
			case "txtint - Length of Series 65 or 66 Registration":
				
				uiValue = faDetailsPage.getSeries65RegistrationValue();
				
				break;
			case "txtint - Length of Service as a FA":
				
				uiValue = faDetailsPage.getLenghtOfServiceAsFAValue();
				
				break;
			case "txtint - FA Assets Under Management (AUM in $)":
				
				uiValue = faDetailsPage.getAUMValue();
				
				break;
			case "txtint - Anticipated Percentage of Overall Business in PMP/AAP":
							
				uiValue = faDetailsPage.getAnticipatedPercentageValue();
							
				break;
			case "txt - Branch":
				
				uiValue = faDetailsPage.getBranchValue();
				
				break;
			case "txt - Complex":
				
				uiValue = faDetailsPage.getComplexValue();
				
				break;
			case "txt - Division":
				
				uiValue = faDetailsPage.getDivisionValue();
				
				break;
			case "txt - Region":
				
				uiValue = faDetailsPage.getRegionValue();
				
				break;
			case "radiobutton - CFA or ACPM Charter Holder?":
				
				uiValue = faDetailsPage.getCFAorACPMValue();
				
				break;
			case "radiobutton - Waive / completed course work":
				
				uiValue = faDetailsPage.getWaiverorCompletedCourseValue();
				
				break;
			case "date - Zoologic course work registration date":
				
				uiValue = faDetailsPage.getZoologicCourseRegistrationValue();
				
				break;
			case "date - Zoologic course work completed date":
				
				uiValue = faDetailsPage.getZoologicCourseCompletedValue();
				
				break;
			case "txt - Awards/Citations/Certifications":
				
				uiValue = faDetailsPage.getAwardsValue();
				
				break;
			case "txt - Additonal Information":
				
				uiValue = faDetailsPage.getAdditionalInformationValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
	}

    @And("^User inputs the values from (.+) in Enter FA details page in Update FA Flow$")
    public void user_inputs_the_values_from_in_enter_fa_details_page_in_update_fa_flow(String mandatorydetails) throws InterruptedException {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		int updateDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex+1;
    	
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			String branchManagerOrMarketHead = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 3);
			String faName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 4);
			String faEmail = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 5);
			String faIDs = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 6);
			String UniversalID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 7);
			String CRDs = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 8);
			String isNominationForARecruit = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 9);
			String recruitHireDate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 10);
			String priorFirm = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 11);
			String previouslyApprovedForFADiscretionaryProgram = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 12);
			String faDiscretionaryProgramName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 13);
			String faSegment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 14);
			String renomination = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 15);
			String renominationDate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 16);
			String lengthOfSeries7Registration = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 17);
			String lengthOfSeries65Registration = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 18);
			String lengthOfServiceAsFA = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 19);
			String aum = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 20);
			String anticipatedPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 21);
			String branch = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 22);
			String complex = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 23);
			String division = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 24);
			String region = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 25);
			String cfaOrAcpm = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 26);
			String waiveOrCompletedCourseWork = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 27);
			String zoologicCourseWorkRegistrationDate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 28);
			String zoologicCourseWorkCompletedDate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 29);
			String awards = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 30);
			String additionalInformation = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 31);
			
			if(branchManagerOrMarketHead != "")
				faDetailsPage.enterBranchManagerOrMarketHead(branchManagerOrMarketHead);
			if(faName != "")
				faDetailsPage.enterFaName(faName);
			if(faEmail != "")
				faDetailsPage.enterFaEmail(faEmail);
			if(faIDs != "")
				faDetailsPage.enterFaIDs(faIDs);
			if(UniversalID != "")
				faDetailsPage.enterUniversalID(UniversalID);
			faDetailsPage.enterCRDs(CRDs);
			faDetailsPage.enterIsNominationForARecruit(isNominationForARecruit);
			if(recruitHireDate != "")
				faDetailsPage.enterRecruitHireDate(recruitHireDate);
			faDetailsPage.enterPriorFirm(priorFirm);
			if(previouslyApprovedForFADiscretionaryProgram != "")
				faDetailsPage.enterPreviouslyApprovedForFADiscretionaryProgram(previouslyApprovedForFADiscretionaryProgram);
			if(faDiscretionaryProgramName != "")
				faDetailsPage.enterFaDiscretionaryProgramName(faDiscretionaryProgramName, previouslyApprovedForFADiscretionaryProgram);
			if(faDiscretionaryProgramName != "")
				faDetailsPage.enterFaSegment(faSegment);
			faDetailsPage.enterRenomination(renomination);
			if(renominationDate != "")
				faDetailsPage.enterRenominationDate(renominationDate, renomination);
			faDetailsPage.enterLengthOfSeries7Registration(lengthOfSeries7Registration);
			faDetailsPage.enterLengthOfSeries65Registration(lengthOfSeries65Registration);
			faDetailsPage.enterLengthOfServiceAsFA(lengthOfServiceAsFA);
			faDetailsPage.enterAum(aum);
			faDetailsPage.enterAnticipatedPercentage(anticipatedPercentage);
			faDetailsPage.enterBranch(branch);
			faDetailsPage.enterComplex(complex);
			faDetailsPage.enterDivision(division);
			faDetailsPage.enterRegion(region);
			faDetailsPage.enterCfaOrAcpm(cfaOrAcpm);
			faDetailsPage.enterWaiveOrCompletedCourseWork(waiveOrCompletedCourseWork);
			if(zoologicCourseWorkRegistrationDate != "")
				faDetailsPage.enterZoologicCourseWorkRegistrationDate(zoologicCourseWorkRegistrationDate, waiveOrCompletedCourseWork);
			if(zoologicCourseWorkCompletedDate != "")
				faDetailsPage.enterZoologicCourseWorkCompletedDate(zoologicCourseWorkCompletedDate, waiveOrCompletedCourseWork);
			if(waiveOrCompletedCourseWork != "")
				faDetailsPage.enterAwards(awards, waiveOrCompletedCourseWork);
			faDetailsPage.enterAdditionalInformation(additionalInformation);
			
				//if(ubsSubsudiary != "")
					//managerDetailsPage.enterubsSubsudiary(ubsSubsudiary);
				
			
		}
		
		Reporter.addCompleteScreenCapture();
    }

	@And("^data from Enter FA Details page should be stored in Excel for (.+) in Update FA Flow$")
    public void data_from_enter_fa_details_page_should_be_stored_in_excel_for_in_update_fa_flow(String mandatorydetails) throws IOException {
    	//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 2;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int flowPageDataRowIndex = rowIndex+3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "" || label.contains("Delete Contacts"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Documents_ignore"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterFADetailsPage(label);
						
						PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Documents_ignore"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }
	
	@And("^Data prepopulated in Enter FA Details page should match with Flow Page Data in Update FA flow for (.+)$")
    public void data_prepopulated_in_enter_fa_details_page_should_match_with_flow_page_data_in_update_fa_flow_for(String mandatorydetails) {
        
    }
	
	@And("^User changes the Discretionary program Value in UI for update FA$")
    public void user_changes_the_discretionary_program_value_in_ui_for_update_fa() {
		faDetailsPage.enterPreviouslyApprovedForFADiscretionaryProgram("Yes");
		Action.pause(1000);
        faDetailsPage.enterFaDiscretionaryProgramName("PMP", "Yes");
        Action.pause(1000);
        Assert.assertTrue(faDetailsPage.getFADiscretionaryProgramValue().trim().toLowerCase().equals("pmp"));
        faDetailsPage.enterFaDiscretionaryProgramName("AAP", "Yes");
        Action.pause(1000);
        Assert.assertTrue(faDetailsPage.getFADiscretionaryProgramValue().trim().toLowerCase().equals("aap"));
        faDetailsPage.enterFaDiscretionaryProgramName("BOTH", "Yes");
        Action.pause(1000);
        Assert.assertTrue(faDetailsPage.getFADiscretionaryProgramValue().trim().toLowerCase().equals("both"));
    }
	
	@Then("^user is able to see that fields with below IDs are disabled$")
    public void user_is_able_to_see_that_fields_with_below_ids_are_disabled(List<String> entity) {
		for(int i = 0; i < entity.size(); i++) {
			Assert.assertTrue(faDetailsPage.isAttributeEditable(entity.get(i)));
		}
    }

}
