package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
//import java.awt.Robot;//AD_PM_UpdateMutualFundUIPage
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator; 
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap; 

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.ibm.db2.jcc.t2zos.u;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.StrategyDetailPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateEntityUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategySMADualUIPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;

public class UpdateEntityUIPageStepDef 
{
	String pageURL = SSOLoginPage.URL + "#/smaDualMac/view/";
	String pageURL2 = SSOLoginPage.URL + "#/smaDualMac/edit/";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateEntity.xlsx";
	String sheetName = "";
	String inputSheetName = "InputSheet";
	String myValue,myValue1;
	XSSFSheet sheet,inputSheet;
	int rowIndex, cellIndex;
	WebElement myElement;
	List<WebElement> myElements,myElements1;
	String proxyDetails[]= {"Proxy Address","Voluntary Reorg Address","Interim Address"};
	String scenario[]= {"0","2","4"};
	int num;
	List<List<String>> attributeLists = new ArrayList<List<String>>();
	List<String> dataList = new ArrayList<String>() ;
	//PMPageGeneric CreateStyleFlyout = new PMPageGeneric("AD_PM_CreateStyleFlyout");
	//	UpdateStrategyPage updateStrategyPage = new UpdateStrategyPage();
	//Action action1 = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategyUIPage"));
	
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateEntityPage"));		

	UpdateEntityUIPage updateEntityPage = new UpdateEntityUIPage();
	static UpdateEntityUIPage updateEntityPage1 = new UpdateEntityUIPage();
	static SSOLoginPage ssologin=new SSOLoginPage();

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	
	StrategyDetailPage strDtl = new StrategyDetailPage();
	
	SoftAssert sftAst = new SoftAssert();
	
	//HashMap<String, String> BenchmarkDetails = new HashMap<String, String>();
	HashMap<String, String> InputValues = new HashMap<String, String>();
	HashMap<String, String> ProxyValues = new HashMap<String, String>();
	
	HashMap<String, Double> BenchmarkValues = new HashMap<String, Double>();
	HashMap<String ,HashMap<String,Double>> BenchmarkDetails = new HashMap<String ,HashMap<String,Double>>();

	HashMap<String ,HashMap<String,String>> ProxyDetails = new HashMap<String ,HashMap<String,String>>();

	//String applicationPropertyFilePath = "./application.properties";
	//PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	//String UIEnvironment = property.getProperty("ProductMaster_UI_Environment").trim().toUpperCase();

	 //String configFilePath = "./config.properties";
	 //PropertyFileUtils configProp = new PropertyFileUtils(configFilePath);	
	 //String UIEnvironment = configProp.getProperty("environment").trim().toUpperCase();
	 String UIEnvironment = SSOLoginPage.UIEnvironment.trim().toUpperCase();

	 
	@Then("^User searches with the (.+) for (.+) with \"([^\"]*)\" and clicks on matching suggestion$")
	public void user_searches_with_the_for_with_something_and_clicks_on_matching_suggestion(String searchcode,String entity, String strArg1) throws Throwable
	{
		followthesteps( searchcode, entity,  strArg1);
			
		
		//String tName = Thread.currentThread().getName();
	}

	//private static synchronized void followthesteps(String searchcode,String entity, String strArg1) throws Throwable 
	public static synchronized void followthesteps(String searchcode,String entity, String strArg1) throws Throwable 
	{
		try
    	{
			ssologin.login("");
        	updateEntityPage1.globalSearch(searchcode,entity,strArg1);
        	Reporter.addStepLog("Searching with the search code");
        	//updateEntityPage1.waitMatchingSuggestion(entity,strArg1);
        	//updateEntityPage1.clickMatchingSuggestion(searchcode,entity,strArg1);
        	//updateEntityPage1.clickButton("SEE ALL RESULTS");
        	//updateEntityPage1.clickTabs("SMAStrategy");
        	//updateEntityPage1.viewEdit(entity, searchcode, "strategyCode", "viewedit",strArg1);
        }
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search");
    	}
	}

	@When("^User searches with the (.+) taken from (.+) in the Search TextBox with \"([^\"]*)\" on landing page$")
	public void user_searches_with_the_taken_from_in_the_search_textbox_with_something_on_landing_page(String searchcode, String entity, String strArg1) throws Throwable
	{
		try 
		{
			updateEntityPage.globalSearch(searchcode, entity, strArg1);
			Reporter.addStepLog("Searching with the search code");
		}
		catch(Exception e)
		{
			Assert.fail("Unable to access global search");
		}
	}
	
    @Then("^User should be taken to (.+) Details page with the CONTINUE EDITING option visible$")
    public void user_should_be_taken_to_details_page_with_the_continue_editing_option_visible(String entity) throws Throwable 
    {
    	try
    	{
        	updateEntityPage.checkButton(entity);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access Continue Button");
    	}
    }
    
    @Then("^User clicks on the suggestion which matches with (.+) and (.+) search token for \"([^\"]*)\" with column \"([^\"]*)\" for \"([^\"]*)\"$")
    public void user_clicks_on_the_suggestion_which_matches_with_and_search_token_for_something_with_column_something_for_something(String searchcode, String entity, String scenario, String columnName, String tab) throws Throwable
    {
    	try
    	{
        	updateEntityPage.clickMatchingSuggestion(searchcode,entity,scenario,columnName,tab);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}
    }
    
    @And("^User clicks on the \"([^\"]*)\" Button of Update flow$")
    public void user_clicks_on_the_something_button_of_update_flow(String strArg1) throws Throwable
    {
//    	try
//    	{
        	updateEntityPage.clickButton(strArg1);
//    	}
//    	catch (Exception e) 
//    	{
//    		Assert.fail("Unable to access global search Results");
//    	}	
    }
    

    @Then("^User checks if there is an error message like \"([^\"]*)\"$")
    public void user_checks_if_there_is_an_error_message_like_something(String strArg1) throws Throwable
    {
    	updateEntityPage.checkErrorMessage(strArg1);
    }
    
    @And("^Click on Edit link to jump to \"([^\"]*)\" page of Update flow$")
    public void click_on_edit_link_to_jump_to_something_page_of_update_flow(String strArg1) throws Throwable
    {
    	try
    	{
        	updateEntityPage.clickEditLink(strArg1);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access Edit link");
    	}	
    }
    
    @Then("^User should be able to see the \"([^\"]*)\" header of Update flow$")
    public void user_should_be_able_to_see_the_something_header_of_update_flow(String strArg1) throws Throwable
    {
    	try
    	{
        	updateEntityPage.checkHeader(strArg1);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}		
    }
    
    @Then("^use thread sleep$")
    public void use_thread_sleep() throws Throwable
    {
    	Thread.sleep(60000);
    }
    
    @Then("^Edit all the below input fields of (.+) with \"([^\"]*)\" data of Update flow$")
    public void edit_all_the_below_input_fields_of_with_something_data_of_update_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
    {
    	try
    	{
        	updateEntityPage.editInputFields(entity, strArg1, attribute);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}	
    }
    
    @And("^Edit all the below text fields of (.+) with \"([^\"]*)\" data of Update flow$")
    public void edit_all_the_below_text_fields_of_with_something_data_of_update_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
    {
    	try
    	{
        	updateEntityPage.editTextFields(entity, strArg1, attribute);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}	
    }

    
    @And("^Edit all the below date fields with valid data for (.+)entity of Update flow$")
    public void edit_all_the_below_date_fields_with_valid_data_for_entity_of_update_flow(String entity,List<List<String>> attribute) throws Throwable
    {

    	try
    	{
        	updateEntityPage.editDateFields(entity, attribute);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}	
    
    }
    
    @And("^Edit all the below drop down fields of (.+) with \"([^\"]*)\" data of Update flow$")
    public void edit_all_the_below_drop_down_fields_of_with_something_data_of_update_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable 
    {
        	updateEntityPage.editDropDownFields(entity, strArg1, attribute);
    }
    
    @And("^Edit all the below drop down fields with index for (.+) with \"([^\"]*)\" data of Update flow$")
    public void edit_all_the_below_drop_down_fields_with_index_for_with_something_data_of_update_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
    {
    	updateEntityPage.selectDropdownByIndex(entity, strArg1, attribute);
    }
    
    @And("^Edit all the below check boxes of (.+) with \"([^\"]*)\" data of Update flow$")
    public void edit_all_the_below_check_boxes_of_with_something_data_of_update_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
    {
    	updateEntityPage.editCheckBox(entity, strArg1, attribute);
    }
    
    @And("^Edit all the below radio button fields of (.+) with \"([^\"]*)\" data of Update flow$")
    public void edit_all_the_below_radio_button_fields_of_with_something_data_of_update_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
    {
    	updateEntityPage.editRadioButton(entity, strArg1, attribute);
    }
    
    @And("^User selects the benchmark category as \"([^\"]*)\" during Update flow$")
    public void user_selects_the_benchmark_category_as_something_during_update_flow(String strArg1) throws Throwable
    {
    	updateEntityPage.selectBenchmarkType(strArg1);
    }
    
    @Then("^User edits all the details of Documents Page of (.+) with \"([^\"]*)\" data of Update flow$")
    public void user_edits_all_the_details_of_documents_page_of_with_something_data_of_update_flow(String entity, String strArg1) throws Throwable
	{
		dataList.clear();
		attributeLists.clear();
		if(updateEntityPage.isPresent("return document.querySelectorAll(\"brml-active-icon\")[0].shadowRoot.querySelector(\"span\")"))	
		{
			myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelectorAll(\"brml-active-icon\")[0]");
			action.jsClick(myElement);
		}
		
		myElement = updateEntityPage.findElementByDynamicXpath("//*[contains(text(),'DOCUMENT LINK')]");
		if(myElement.isEnabled())
			myElement.click();
		
		dataList.add(0, "Document Type");
		dataList.add(1, "documentType");
		attributeLists.add(0, dataList);
		updateEntityPage.editDropDownFields(entity, strArg1, attributeLists);
		
		dataList.set(0, "Document Link");
		dataList.set(1, "documentLink");
		attributeLists.set(0, dataList);
		updateEntityPage.editInputFields(entity, strArg1, attributeLists);
		
		dataList.set(0, "Document Description");
		dataList.set(1, "documentDescription");
		attributeLists.set(0, dataList);
		updateEntityPage.editTextFields(entity, strArg1, attributeLists);
		
		myElement = updateEntityPage.findElementByDynamicXpath("//wf-button[contains(text(),'DOCUMENT LINK')]");
		myElement.click();
		Thread.sleep(500);
	}
    
    @Then("^User edits all the details of Comments Page of (.+) with \"([^\"]*)\" data of Update flow$")
    public void user_edits_all_the_details_of_comments_page_of_with_something_data_of_update_flow(String entity, String strArg1) throws Throwable
    {
    	   dataList.clear();
		   attributeLists.clear();
		   
		   if(updateEntityPage.isPresent("return document.querySelectorAll(\"brml-active-icon\")[0].shadowRoot.querySelector(\"span\")"))	
		   {
				myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelectorAll(\"brml-active-icon\")[0].shadowRoot.querySelector(\"span\")");
				action.jsClick(myElement);
		   }
		   myElement = updateEntityPage.findElementByDynamicXpath("//*[contains(text(),'COMMENT')]");
		   if(myElement.isEnabled())
			   myElement.click();
		   
		   dataList.add(0,"Comment Type");
		   dataList.add(1,"commentType");
		   attributeLists.add(0,dataList);
		   updateEntityPage.editDropDownFields(entity, strArg1, attributeLists);

		   dataList.set(0,"Comment Description");
		   dataList.set(1,"comments");
		   attributeLists.set(0,dataList);
		   updateEntityPage.editTextFields(entity, strArg1, attributeLists);
		   
		   myElement = updateEntityPage.findElementByDynamicXpath("//wf-button[contains(text(),'COMMENT')]");
		   myElement.click();
		   Thread.sleep(500);
	    }
    
    @Then("^Edit the below fields of Benchmark Page for (.+) with \"([^\"]*)\" data of Update flow delete bins \"([^\"]*)\"$")
    public void edit_the_below_fields_of_benchmark_page_for_with_something_data_of_update_flow_delete_bins_something(String entity, String scenario, String deleteBins,List<Map<String,String>> attribute) throws Throwable
    {
    	BenchmarkDetails.clear();
    	/*excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/Update"+entity+".xlsx";
		this.sheetName = sheetName;
		sheet = new ExcelUtils(ExcelOperation.LOAD, excelFilePath).getSheet(sheetName);*/
    	
    	sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		
		if(entity.equalsIgnoreCase("MutualFund") || entity.equalsIgnoreCase("ETF"))
		{
			myElement = (WebElement)updateEntityPage.executeJavaScript(
					"return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(4)\").shadowRoot.querySelector(\"button\")");
			action.scrollToElement(myElement);
		}
		
		else
		{	
			if((updateEntityPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option\")").size() > 1))
			{
				myElement = (WebElement)updateEntityPage.executeJavaScript(
						"return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(2)\").shadowRoot.querySelector(\"button\")");
				action.scrollToElement(myElement);
			}
			else 
			{
				myElement = (WebElement)updateEntityPage.executeJavaScript(
						"return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option\").shadowRoot.querySelector(\"button\")");
			}
		}
		
		if(!myElement.isSelected())
		{
			myElement.click();
			if(deleteBins.equalsIgnoreCase("yes")) 
			{
				updateEntityPage.deleteAllBins(attribute.size());
			}
		}
		else 
		{
			if(deleteBins.equalsIgnoreCase("yes")) 
			{
				updateEntityPage.deleteAllBins(attribute.size());
			}	
		}
		updateEntityPage.selectedBMtype("418");
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario+UIEnvironment);
		
		if(!(entity.equalsIgnoreCase("Style") || entity.equalsIgnoreCase("MutualFund") || entity.equalsIgnoreCase("ETF")))
		{
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0,"Custom BM Reason");
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
			
			myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelector('brml-textarea[id=\"txtCustomReasonSet1\"]').shadowRoot.querySelector('textarea')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);	
			action.clear(myElement);
			//action.sendKeys(myElement, myValue);
			updateEntityPage.sendKeysWithCheck(myElement, myValue);
		}
			
		for(int i = 0; i < attribute.size(); i++)
		{
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get("Dropdown Name"));
			String dropdownValues = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get("Dropdown Percentage"));
			String dropdownPercentages = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
			
			if(dropdownValues.contains(",")) 
			{
				String[] ddValue = dropdownValues.split(",");
				String[] ddpercent = dropdownPercentages.split(",");
				
				if(ddValue.length != ddpercent.length) 
				{
					Assert.fail("The number of benchmarks & percentages don't match");
				}
				
				int size = ddValue.length;
				int j = 0;
				float sum = 0;
				
				while(size > 0 && size <= 10) 
				{
					String id = attribute.get(i).get("Percentage ID") + j;
					myValue = ddpercent[j];
					sum = sum + Float.parseFloat(myValue);
					
					if(sum != 100 && size == 1) 
					{
						myValue = "100";
					}
					
					double percentage = Double.parseDouble((String)updateEntityPage.enterPercentage(id, myValue));
					Reporter.addStepLog(
							"send keys " + myValue + " for " + attribute.get(i).get("Dropdown Percentage"));
					
					myValue = ddValue[j];
					id = attribute.get(i).get("Dropdown ID") + j;
					myValue1 = updateEntityPage.selectBMDropdown(id, myValue);
					
					BenchmarkValues.put(myValue1, percentage);
					
					Reporter.addStepLog("Drop down for" + attribute.get(i).get("Dropdown Name") + "selected");
					
					j++;
					size--;
					
					if(sum >= 100 && size !=0)
					{
						break;
					}
					
					if(size > 0 && size != 0)
					{
						if(attribute.get(i).get("Dropdown Name").contentEquals("UnBundled Node ID BM") || attribute.get(i).get("Dropdown Name").contentEquals("UnBundled Node ID BM 1"))
						{
							//updateStrategyPage.clickOnNewAsset();
							//updateEntityPage.findElementByDynamicXpath("//brml-button[@id='btnAddunBundledNode']").click();
							myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#btnAddunBundledNode\")");
							action.jsClick(myElement);
							Reporter.addStepLog("Clicked on New Asset");
						}
						else if(attribute.get(i).get("Dropdown Name").contentEquals("Custom Benchmark BM") || attribute.get(i).get("Dropdown Name").contentEquals("Custom Benchmark BM 1")) 
						{
							//updateStrategyPage.clickOnNewBenchmark();
							//updateEntityPage.findElementByDynamicXpath("//brml-button[@id='btnAddSet1']").click();
							myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#btnAddSet1\")");
							action.jsClick(myElement);
							Reporter.addStepLog("Clicked on New Benchmark");

						}
						else if(attribute.get(i).get("Dropdown Name").contentEquals("Secondary Benchmark BM") || attribute.get(i).get("Dropdown Name").contentEquals("Secondary Benchmark BM 1")) 
						{
							//updateStrategyPage.clickOnNewBenchmark();
							//updateEntityPage.findElementByDynamicXpath("//brml-button[@id='btnAddSet2']").click();
							myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#btnAddSet2\")");
							action.jsClick(myElement);
							Reporter.addStepLog("Clicked on New Benchmark");

						}
					}
				}
			}
					else 
					{
						String id = attribute.get(i).get("Percentage ID") + 0;
						updateEntityPage.enterPercentage(id, "100");
						
						myValue = dropdownValues;
						id = attribute.get(i).get("Dropdown ID") + 0;
						myValue1 = updateEntityPage.selectBMDropdown(id, myValue);
						
						BenchmarkValues.put(myValue1, 100d);

					}
			
						BenchmarkDetails.put(attribute.get(i).get("Dropdown Name"), updateEntityPage.addValues1(BenchmarkDetails, attribute.get(i).get("Dropdown Name"), BenchmarkValues));
						
						BenchmarkValues.clear();
				}
		System.out.println("final Map "+Arrays.asList(BenchmarkDetails));

    }
    
   /* @Then("^User Edits all the below fields of Proxy Details for (.+) with \"([^\"]*)\" data of Update flow$")
    public void user_edits_all_the_below_fields_of_proxy_details_for_with_something_data_of_update_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
    {
    		sheetName = "Proxy_Deatils";
			sheet = exlObj.getSheet(sheetName);
			
			action.scrollToElement(updateEntityPage.findElementByDynamicXpath("//brml-checkbox[@id='voluntaryReorgCheckbox']"));
			myValue = (String)action.executeJavaScript("return document.querySelector('brml-checkbox[id=\"voluntaryReorgCheckbox\"]').getAttribute('checked')");

			if(myValue.equals("true"))
			{
				updateEntityPage.findElementByDynamicXpath("//brml-checkbox[@id='voluntaryReorgCheckbox']").click();
				Thread.sleep(1000);
			}
			
			action.scrollToElement(updateEntityPage.findElementByDynamicXpath("//brml-checkbox[@id='interimCheckbox']"));
			myValue = (String)action.executeJavaScript("return document.querySelector('brml-checkbox[id=\"interimCheckbox\"]').getAttribute('checked')");

			if(myValue.equals("true"))
			{
				updateEntityPage.findElementByDynamicXpath("//brml-checkbox[@id='interimCheckbox']").click();
				Thread.sleep(1000);
			}
			
			
			for (int i = 0; i < attribute.size(); i++)
			{
				if(attribute.get(i).get(0).equals("State"))
				{
					myElements = updateEntityPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll('brml-select[id=\""
							+ attribute.get(i).get(1) + "\"]')");
				}
				else
				{
					myElements = updateEntityPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll('brml-input[id=\""
							+ attribute.get(i).get(1) + "\"]')");
				}
				
				
				for (int j = 0; j < myElements.size(); j++)
				{
					
					if(attribute.get(i).get(0).equals("State"))
					{
						myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelectorAll('brml-select[id=\""
								+ attribute.get(i).get(1) + "\"]')["+j+"].shadowRoot.querySelector(\"wf-input\")");
						
						if(myElement.isEnabled())
						{
							action.scrollToElement(myElement);
							action.highligthElement(myElement);
							action.click(myElement);

							rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, proxyDetails[j]);
							num = Integer.parseInt(scenario[j]);
							cellIndex = exlObj.getCellIndexByCellValue(sheet, num, attribute.get(i).get(0));
							myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
							System.out.println(myValue);
							Thread.sleep(2000);

							myElements1 = updateEntityPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll('brml-select[id=\""+attribute.get(i).get(1)+"\"]')["+j+"].shadowRoot.querySelectorAll('li')");
							
							for(WebElement E : myElements1) 
							{
								if(E.getText().equalsIgnoreCase(myValue))
								{
									myElement = E;
									break;
								}
							}
							
							System.out.println(myElement.getText());
							
							action.scrollToElement(myElement);
							Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

							action.click(myElement);
							Thread.sleep(1000);
							
							String abcString = attribute.get(i).get(0)+j;
							System.out.println(abcString);
							ProxyValues.put(attribute.get(i).get(0)+j,myValue);
							
						}
						
					}
					else
					{
						myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelectorAll('brml-input[id=\""
								+ attribute.get(i).get(1) + "\"]')["+j+"].shadowRoot.querySelector(\"input\")");
						
						if(myElement.isEnabled())
						{
							action.scrollToElement(myElement);
							action.highligthElement(myElement);
	
							rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, proxyDetails[j]);
							num = Integer.parseInt(scenario[j]);
							cellIndex = exlObj.getCellIndexByCellValue(sheet, num, attribute.get(i).get(0));
							myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
							System.out.println(myValue);
							action.scrollToElement(myElement);
							action.clear(myElement);
							Thread.sleep(2000);
							//action.sendKeys(myElement, myValue);
							updateEntityPage.sendKeysWithCheck(myElement, myValue);
							
							String abcString = attribute.get(i).get(0)+j;
							System.out.println(abcString);
							ProxyValues.put(attribute.get(i).get(0)+j,myValue);
							
							Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0)+j);

							Thread.sleep(2000);
						}
					}
				}
			}
			
    }*/
    
    @Then("^User Edits all the below fields of Proxy Details for (.+) with \"([^\"]*)\" data of Update flow$")
    public void user_edits_all_the_below_fields_of_proxy_details_for_with_something_data_of_update_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
    {
    		//sheetName = "Proxy_Deatils";
			sheetName = strArg1;
			sheet = exlObj.getSheet(sheetName);
			
			action.scrollToElement(updateEntityPage.findElementByDynamicXpath("//brml-checkbox[@id='voluntaryReorgCheckbox']"));
			myValue = (String)action.executeJavaScript("return document.querySelector('brml-checkbox[id=\"voluntaryReorgCheckbox\"]').getAttribute('checked')");

			if(myValue.equals("true"))
			{
				updateEntityPage.findElementByDynamicXpath("//brml-checkbox[@id='voluntaryReorgCheckbox']").click();
				Thread.sleep(1000);
			}
			
			action.scrollToElement(updateEntityPage.findElementByDynamicXpath("//brml-checkbox[@id='interimCheckbox']"));
			myValue = (String)action.executeJavaScript("return document.querySelector('brml-checkbox[id=\"interimCheckbox\"]').getAttribute('checked')");

			if(myValue.equals("true"))
			{
				updateEntityPage.findElementByDynamicXpath("//brml-checkbox[@id='interimCheckbox']").click();
				Thread.sleep(1000);
			}
			
			for (int j = 0; j < proxyDetails.length; j++)
			{
				for (int i = 0; i < attribute.size(); i++)
				{	
					if(attribute.get(i).get(0).equals("State"))
					{
						myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelectorAll('brml-select[id=\""
								+ attribute.get(i).get(1) + "\"]')["+j+"].shadowRoot.querySelector(\"wf-input\")");
						
						if(myElement.isEnabled())
						{
							action.scrollToElement(myElement);
							action.highligthElement(myElement);
							action.click(myElement);

							rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, proxyDetails[j]);
							num = Integer.parseInt(scenario[j]);
							cellIndex = exlObj.getCellIndexByCellValue(sheet, num, attribute.get(i).get(0));
							myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
							System.out.println(myValue);
							//Thread.sleep(2000);

							myElements1 = updateEntityPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll('brml-select[id=\""+attribute.get(i).get(1)+"\"]')["+j+"].shadowRoot.querySelectorAll('li')");
							
							for(WebElement E : myElements1) 
							{
								if(E.getText().equalsIgnoreCase(myValue))
								{
									myElement = E;
									break;
								}
							}
							
							System.out.println(myElement.getText());
							
							action.scrollToElement(myElement);
							Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

							action.click(myElement);
							
							ProxyValues.put(attribute.get(i).get(0),myValue);
							
						}		
					}
					else
					{
						myElement = (WebElement)updateEntityPage.executeJavaScript("return document.querySelectorAll('brml-input[id=\""
								+ attribute.get(i).get(1) + "\"]')["+j+"].shadowRoot.querySelector(\"input\")");
						
						if(myElement.isEnabled())
						{
							action.scrollToElement(myElement);
							action.highligthElement(myElement);
	
							rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, proxyDetails[j]);
							num = Integer.parseInt(scenario[j]);
							cellIndex = exlObj.getCellIndexByCellValue(sheet, num, attribute.get(i).get(0));
							myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
							System.out.println(myValue);
							action.scrollToElement(myElement);
							action.clear(myElement);
							//action.sendKeys(myElement, myValue);
							updateEntityPage.sendKeysWithCheck(myElement, myValue);
							
							ProxyValues.put(attribute.get(i).get(0),myValue);
							
							Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));
						}
					}
				}
				
				ProxyDetails.put(proxyDetails[j], updateEntityPage.addValuesString(ProxyDetails, proxyDetails[j], ProxyValues));
				ProxyValues.clear();   	
			} 	
			
			System.out.println(ProxyDetails);
    }
    
    @Then("^Store all the fields of Documents Page for Update flow$")
    public void store_all_the_fields_of_documents_page_for_update_flow() throws Throwable
    {
    	updateEntityPage.storeDocumentsDetails();
    }

    @Then("^Store all the fields of Comments Page for Update flow$")
    public void store_all_the_fields_of_comments_page_for_update_flow() throws Throwable
    {
    	updateEntityPage.storeCommentsDetails();
    }
    
    @Then("^Check if all the edits made to the input and text feilds on Documents page are reflected on View page of Update flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_documents_page_are_reflected_on_view_page_of_update_flow() throws Throwable
    {
    	updateEntityPage.checkDocumentEdits();
    }
    
    @Then("^Check if all the edits made to the input and text feilds on Comments page are reflected on View page of Update flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_comments_page_are_reflected_on_view_page_of_update_flow() throws Throwable
    {
    	updateEntityPage.checkCommentsEdits();
    }
    
    @And("^Check if all the edits made to the Proxy Details feilds for (.+) match with the DB of Update flow$")
    public void check_if_all_the_edits_made_to_the_proxy_details_feilds_for_match_with_the_db_of_update_flow(String entity) throws Throwable
    {
    	updateEntityPage.DBProxyCheck(ProxyDetails);
    }
    
    @Then("^User adds time periods for below feilds for (.+) with \"([^\"]*)\" data of Update flow$")
    public void user_adds_time_periods_for_below_feilds_for_with_something_data_of_update_flow(String entity, String strArg1, List<String> attribute) throws Throwable
    {
		for(int i = 0; i < attribute.size(); i++)
		{
			//myValue = new SimpleDateFormat("yyyy-MM-dd").format(new Date(System.currentTimeMillis()-24*60*60*1000));

			if(attribute.get(i).equalsIgnoreCase("UnBundled Node ID BM"))
			{
				((WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"brml-active-icon[name ='edit']\")")).click();
				updateEntityPage.clickPreviousDate("fromDate");
				
				myElement =  (WebElement)updateEntityPage.executeJavaScript("return document.querySelectorAll(\"#timePeriod\")[0]");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				myElement.click();
				
				updateEntityPage.clickCurrentDate("fromDate");
			}
			
			if(attribute.get(i).equalsIgnoreCase("Custom Benchmark BM"))
			{
				if((updateEntityPage.executeJavaScript("return document.querySelector(\"#benchmarkEffectiveDateType\").getAttribute('value')")).toString().equalsIgnoreCase("Since Inception")) 
				{
					((WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#benchmarkEffectiveDateType\").shadowRoot.querySelector(\"wf-input\")")).click();
					Thread.sleep(1000);
					((WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#benchmarkEffectiveDateType\").shadowRoot.querySelector(\"li:nth-child(2)\")")).click();
					Thread.sleep(2000);
				}
				
				action.scrollToElement((WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#benchmarkEffectiveDateType\").shadowRoot.querySelector(\"wf-input\")"));
				Thread.sleep(1000);
				((WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"div.capNGo.pl-0\").querySelector(\"brml-active-icon[name='edit']\")")).click();
				updateEntityPage.clickPreviousDate("fromDate");
				
				myElements =  updateEntityPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"#timePeriod\")");
				
				for(WebElement E : myElements)
					myElement = E;
				
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				myElement.click();
				
				updateEntityPage.clickCurrentDate("fromDate");
			}
			if(attribute.get(i).equalsIgnoreCase("Secondary Benchmark BM"))
			{
				if((updateEntityPage.executeJavaScript("return document.querySelector(\"#benchmark2EffectiveDateType\").getAttribute('value')")).toString().equalsIgnoreCase("Since Inception")) 
				{
					((WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#benchmark2EffectiveDateType\").shadowRoot.querySelector(\"wf-input\")")).click();
					Thread.sleep(1000);
					((WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#benchmark2EffectiveDateType\").shadowRoot.querySelector(\"li:nth-child(2)\")")).click();
					Thread.sleep(2000);
				}
				
				action.scrollToElement((WebElement)updateEntityPage.executeJavaScript("return document.querySelector(\"#benchmark2EffectiveDateType\").shadowRoot.querySelector(\"wf-input\")"));
				Thread.sleep(1000);
				((WebElement)updateEntityPage.executeJavaScript("return document.querySelectorAll(\"div.capNGo.pl-0\")[1].querySelector(\"brml-active-icon[name='edit']\")")).click();
				updateEntityPage.clickPreviousDate("fromDate");
				
				myElements =  updateEntityPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"#timePeriod\")");
				
				for(WebElement E : myElements)
					myElement = E;
				
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				myElement.click();
				
				updateEntityPage.clickCurrentDate("fromDate");
			}
		}
    }
    			
    @Then("^Check if all the edits made to the input and text feilds for (.+) are reflected on View page of Update flow$")
	 public void check_if_all_the_edits_made_to_the_input_and_text_feilds_for_are_reflected_on_view_page_of_update_flow(String entity) throws Throwable
		{
		   	try
		    {
		       	updateEntityPage.checkInputEdits();
		   	}
		   	catch (Exception e) 
		   	{
	    		Assert.fail("Unable to access Continue Button");
	    	}
		    
    }
    
    @Then("^Check if all the edits made to the drop down feilds for (.+) are reflected on View page of Update flow$")
    public void check_if_all_the_edits_made_to_the_drop_down_feilds_for_are_reflected_on_view_page_of_update_flow(String entity) throws Throwable
    {
    	try
	    {
	       	updateEntityPage.checkDropdownEdits();
	   	}
	   	catch (Exception e) 
	   	{
    		Assert.fail("Unable to access Continue Button");
    	}
    }
    
    @Then("^Check if all the edits made to the input and text feilds on Proxy Details page are reflected on View page of Update flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_proxy_details_page_are_reflected_on_view_page_of_update_flow() throws Throwable
    {
    	try
	    {
    		updateEntityPage.checkProxyEdits(ProxyDetails);
	    }
	   	catch (Exception e) 
	   	{
    		Assert.fail("Unable to access Proxy Details");
    	}
    }
    
    @Then("^Check if updates made to program eligibility are retained on Update flow$")
    public void check_if_updates_made_to_program_eligibility_are_retained_on_update_flow() throws Throwable
    {
    	try 
    	{
			updateEntityPage.checkPEUpdateValues();
		}
		catch(Exception e) 
    	{
			Assert.fail("Unable to access Program Eligibility");
		}
    }
    

    @Then("^Check if all the edits made to the Benchmark feilds for (.+) are reflected on View page of Update flow$")
    public void check_if_all_the_edits_made_to_the_benchmark_feilds_for_are_reflected_on_view_page_of_update_flow(String entity) throws Throwable 
    {
//    	try 
//    	{
    		if(!BenchmarkDetails.isEmpty()) 
    		{
    			updateEntityPage.checkBenchmarkEdits(BenchmarkDetails,entity);
			}
    		else
    		{
    			updateEntityPage.checkNonCustomBenchmarkEdits(entity);
			}
//		}
//		catch(Exception e) 
//    	{
//			Assert.fail("Unable to access Benchmark Details");
//		}
    }
    
    @Then("^Check if all the edits made to the check box feilds for (.+) are reflected on Update flow$")
    public void check_if_all_the_edits_made_to_the_check_box_feilds_for_are_reflected_on_update_flow(String entity,List<List<String>> attribute) throws Throwable
    {

    	try 
    	{
			updateEntityPage.checkCheckBoxEditsOnUpdatePage(entity,attribute);
		}
		catch(Exception e) 
    	{
			Assert.fail("Unable to access Benchmark Details");
		}   
    
    }
    
    @Then("^Check if all the edits made the below fields of Benchmark Page for (.+) are reflected on Update flow$")
    public void check_if_all_the_edits_made_the_below_fields_of_benchmark_page_for_are_reflected_on_update_flow(String entity,List<Map<String,String>> attribute) throws Throwable
    {
//    	try 
//    	{
			updateEntityPage.checkBenchmarkEditsOnUpdateFlow(BenchmarkDetails,entity, attribute);
//		}
//		catch(Exception e) 
//    	{
//			Assert.fail("Unable to access Benchmark Details");
//		}   
    }
    
    @Then("^Check if all the edits made to the input and text feilds for (.+) are reflected on Update flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_for_are_reflected_on_update_flow(String entity,List<List<String>> attribute) throws Throwable 
    {
    	updateEntityPage.checkInputEditsOnUpdatePage(entity, attribute);
    }
    
    @Then("^Check if all the edits made to the drop down feilds for (.+) are reflected on Update flow$")
    public void check_if_all_the_edits_made_to_the_drop_down_feilds_for_are_reflected_on_update_flow(String entity,List<List<String>> attribute) throws Throwable
    {
    	updateEntityPage.checkDropdownEditsOnUpdatePage(entity, attribute);
    }
    
    @Then("^Check if all the edits made to the input feilds for (.+) are reflected on Proxy Page of Update flow$")
    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_proxy_page_of_update_flow(String entity,List<List<String>> attribute) throws Throwable
    {
    	updateEntityPage.checkProxyEditsOnUpdatePage(ProxyDetails, attribute);
    }
    
    @Then("^Check if all the edits made to the input feilds for  (.+) are reflected on Documents Page of Update flow$")
    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_documents_page_of_update_flow(String entity) throws Throwable
    {
    	updateEntityPage.checkDocumentEditsOnUpdatePage();
    }
    
    @Then("^Check if all the edits made to the input feilds for  (.+) are reflected on Comments Page of Update flow$")
    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_comments_page_of_update_flow(String entity) throws Throwable
    {
    	updateEntityPage.checkCommentsEditsOnUpdatePage();
    }
    
    @Then("^User waits for the suggestion which matches with (.+) search token with \"([^\"]*)\"$")
    public void user_waits_for_the_suggestion_which_matches_with_search_token_with_something(String entity, String strArg1) throws Throwable
    {
    	try
    	{
        	updateEntityPage.waitMatchingSuggestion(entity,strArg1);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}
    }
    
    @Then("^User clicks on \"([^\"]*)\" tab of Update flow$")
    public void user_clicks_on_something_tab_of_update_flow(String strArg1) throws Throwable
    {
    	try
    	{
        	updateEntityPage.clickTabs(strArg1);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}
    }
    

    @And("^User should be able to \"([^\"]*)\" details of the (.+) taken from (.+) using the column \"([^\"]*)\" with \"([^\"]*)\"$")
    public void user_should_be_able_to_something_details_of_the_taken_from_using_the_column_something_with_something(String option, String searchCode,  String entity, String columnName,String strArg1) throws Throwable
    {
    	try
    	{
        	updateEntityPage.viewEdit(entity, searchCode, columnName, option,strArg1);
    		
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}
    }
    
    @Then("^Connect with DB to retrive search code with (.+) for (.+) with \"([^\"]*)\" for TDR checkout$")
    public void connect_with_db_to_retrive_search_code_with_for_with_something_for_tdr_checkout(String searchfeild, String entity, String strArg1) throws Throwable
    {
    	updateEntityPage.DBRetriveSC(searchfeild, entity,strArg1);
    }
    
    @Then("^Connect with DataBase to retrive search code for (.+) with \"([^\"]*)\"$")
    public void connect_with_database_to_retrive_search_code_for_with_something(String entity, String strArg1) throws Throwable
    {
    	updateEntityPage.DBRetriveSearchCode(entity,strArg1);
    }
    
    @Then("^Check if database values checks with the UI values for all the below feilds$")
    public void check_if_database_values_checks_with_the_ui_values_for_all_the_below_feilds(List<List<String>> attribute) throws Throwable
    {
    	updateEntityPage.checkInputUIValues(attribute);
    }
    
    @Then("^Check program eligibility database values checks with the UI values of (.+) with \"([^\"]*)\" for all the below feilds$")
    public void check_program_eligibility_database_values_checks_with_the_ui_values_of_with_something_for_all_the_below_feilds(String entity, String searchfeild,List<Map<String,String>> attribute) throws Throwable
    {
    	updateEntityPage.checkPE_UIValues(entity, searchfeild, attribute);
    }
    
    @Then("^Check if all the edits made to the Program Eligibility details for (.+) are reflected on View page of Update flow$")
    public void check_if_all_the_edits_made_to_the_program_eligibility_details_for_are_reflected_on_view_page_of_update_flow(String entity) throws Throwable
    {
    	updateEntityPage.checkPEEdits1();
    }
    
    @Then("^Edit all the below radio buttons of Program Eligibility of Update flow$")
    public void edit_all_the_below_radio_buttons_of_program_eligibility_of_update_flow(List<List<String>> attribute) throws Throwable
    {
    	updateEntityPage.editPE_UIValues(attribute);
    }
    
    @And("^New Notification Hub Window is opened and started$")
	  public void new_notification_hub_window_is_opened_and_started() throws Throwable
	  {
    	updateEntityPage.openNotificationHub();
	  }

    @And("^Check if a notification is sent for (.+) to Notification Hub with \"([^\"]*)\"$")
    public void check_if_a_notification_is_sent_for_to_notification_hub_with_something(String entity, String strArg1) throws Throwable
    {
    	updateEntityPage.checkNotificationHub(entity,strArg1);
    }
	
    @And("^New Data Hub Window is opened and started for (.+)$")
    public void new_data_hub_window_is_opened_and_started_for(String entity) throws Throwable
	{
	  updateEntityPage.openDataHub(entity);
	}

	@And("^Check if a payload is sent to Data Hub$")
	public void check_if_a_payload_is_sent_to_data_hub() throws Throwable
	{
		updateEntityPage.checkDataHubPay();
	}
	
    @And("^Edit FAIDs feild with search \"([^\"]*)\" of Update flow$")
    public void edit_faids_feild_with_search_something_of_update_flow(String strArg1) throws Throwable
	{
		updateEntityPage.editFAIDs(strArg1);
	}
	
	@And("^Check if all the edits made to the input and text feilds for (.+) match with the DB of Update flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_for_match_with_the_db_of_update_flow(String entity) throws Throwable
    {
		updateEntityPage.DBRetriveSC1(entity);
    }
	
    @And("^Check if all the edits made to the Benchmark feilds for (.+) match with the DB of Update flow$")
    public void check_if_all_the_edits_made_to_the_benchmark_feilds_for_match_with_the_db_of_update_flow(String entity) throws Throwable
    {
		updateEntityPage.DBRetriveSC2(entity,BenchmarkDetails);
    }
    
    @And("^Check if all the edits made to the Documents Details feilds for (.+) match with the DB of Update flow$")
    public void check_if_all_the_edits_made_to_the_documents_details_feilds_for_match_with_the_db_of_update_flow(String entity) throws Throwable
    {
    	updateEntityPage.DBDocDetails(entity);
    }
    
    @And("^Check if all the edits made to the Comments Details feilds for (.+) match with the DB of Update flow$")
    public void check_if_all_the_edits_made_to_the_comments_details_feilds_for_match_with_the_db_of_update_flow(String entity) throws Throwable
    {
    	updateEntityPage.DBCommentsDetails(entity);
    }
    
    @Then("^Verify the csv file of the \"([^\"]*)\" of file flow$")
    public void verify_the_csv_file_of_the_something_of_file_flow(String entity) throws Throwable
    {
    	//ExportReport exp = new ExportReport();
    	updateEntityPage.verifycsvFile(entity);
    }
    
    @Then("^Verify the pdf file of the \"([^\"]*)\" of file flow$")
    public void verify_the_pdf_file_of_the_something_of_file_flow(String entity) throws Throwable
    {
    	updateEntityPage.clickPDFReport(entity);
    }
    
    @Then("^Check if all the edits made to the Benchmark feilds for (.+) are reflected on View page of Export Report flow$")
    public void check_if_all_the_edits_made_to_the_benchmark_feilds_for_are_reflected_on_view_page_of_export_report_flow(String entity) throws Throwable
    {
    	updateEntityPage.checkExportBenchmarks(entity);
    }
    
    @Then("^Check if all the edits made to the input and text feilds on Proxy Details page are reflected on View page of Export Report flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_proxy_details_page_are_reflected_on_view_page_of_export_report_flow() throws Throwable
    {
    	updateEntityPage.checkProxyEditsExport();
    }
    
    @Then("^Apply the Assertion for Update flow$")
    public void apply_the_assertion_for_update_flow() throws Throwable
    {
    	updateEntityPage.SoftAssertion();
    }
}