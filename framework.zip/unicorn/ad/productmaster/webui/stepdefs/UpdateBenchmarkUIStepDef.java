package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.IntegrationGeneric;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStylePage;

public class UpdateBenchmarkUIStepDef {
	
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(),20);
	String expectedColorCode;
	String xpath,myValue,javaScript;
	Select dropdown;
	Boolean myFlag;
	Robot robot;
	String xpathForStaleElement="//input[@name='benchmarkName']";
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateBenchmarkUIPage"));	
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/benchmark/edit/";
	UpdateBenchmarkPage UpdateBenchmarkUI = new UpdateBenchmarkPage();
	//Action action =new Action(SQLDriver.getEleObjData("AD_PM_UpdateManagerUIPage")); 
	WebElement myElement,myElement2;
	List<WebElement> listOfElements,listOfElements2 = new ArrayList<WebElement>();
	UpdateBenchmarkPage updateBenchmarkPage = new UpdateBenchmarkPage();
	String sheetName = "";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateBenchmark3037.xlsx";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	String pageURL2 = SSOLoginPage.URL + "#/benchmark/edit";
	String pageURL1 = SSOLoginPage.URL + "#/all";
	String pageURL3 = SSOLoginPage.URL + "#/benchmark/view";
	String pageURL4 = SSOLoginPage.URL + "#/benchmark/review";
	
	@Then("^User should be able to go Update Benchmark UI screen$")
	public void user_should_be_able_to_go_update_Benchmark_ui_screen() throws Throwable {
		Assert.assertTrue(action.getCurrentURL().contains(pageURL), "We are in UpdateBenchmarkUIPage");
		Reporter.addScreenCapture();
	}
	
	 @And("^User clicks on Previous Button on Benchmark Review page$")
	    public void uer_clicks_on_previous_button_on_Benchmark_Review_page() throws Throwable {
		 action.click(action.getElement("Previous Button"));
		 Reporter.addStepLog("clicked on previous button");
	    }
	
	 @Then("^User should again be navigated to Update Benchmark UI screen$")
	    public void user_should_again_be_navigated_to_update_Benchmark_ui_screen() throws Throwable {
			Assert.assertTrue(action.getCurrentURL().contains(pageURL2), "We are in UpdateBenchmarkUIPage");
			Reporter.addScreenCapture();
	    }
	 
	 @Then("^User should be navigated to Landing Page$")
	    public void user_should_be_navigated_to_Landing_Page() throws Throwable {
			Assert.assertTrue(action.getCurrentURL().contains(pageURL1), "We are in Landing Page");
			Reporter.addScreenCapture();
	    }
	 
	 @Then("^User should be able to go Benchmark Details Page$")
	    public void User_should_be_able_to_go_Benchmark_Details_Page() throws Throwable {
			Assert.assertTrue(action.getCurrentURL().contains(pageURL3), "We are in Landing Page");
			Reporter.addScreenCapture();
	    }
	 
	 @Then("^User should be able to go Benchmark Review Page$")
	    public void User_should_be_able_to_go_Benchmark_Review_Page() throws Throwable {
			Assert.assertTrue(action.getCurrentURL().contains(pageURL4), "We are in Benchmark review Page");
			Reporter.addScreenCapture();
	    }
	 
	 
	 	
	@And("^User clicks the Next Button on Update Benchmark page$")
	public void user_clicks_the_next_button_on_update_benchmark_page() throws Throwable {
		action.click(action.getElement("Next Button"));
		Reporter.addStepLog("clicked on next button");
	}
	
	 @And("^User clicks on Back Link on Update Benchmark page$")
	    public void user_clicks_on_back_link_on_update_benchmark_page() throws Throwable {
		 action.click(action.getElement("Back Link"));
		 Reporter.addStepLog("clicked on Back Link");

	    }
	 
		
	
	 
	 @Then("^User should be able to see the Invalid Special Character Message while updating with the following values in following attributes in Update Benchmark page$")
		public void user_should_be_able_to_see_the_invalid_special_character_message_while_updating_with_the_following_values_in_following_attributes_in_update_benchmark_page(
				List<List<String>> attributeValuePair) throws Throwable {
			Thread.sleep(2000);
			for (int i = 0; i < attributeValuePair.size(); i++) {
				Thread.sleep(2000);
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
						+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
				action.clear(myElement);
				action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
				myElement.sendKeys(Keys.ENTER);
				String message = Action.getTestData("Invalid_Special_Character_Message");
				myElement2 = updateBenchmarkPage.findElementByDynamicXpath(
						"//*[@label='" + attributeValuePair.get(i).get(0) + "']/following-sibling::p");
				Assert.assertTrue(myElement2.getText().contains(message));
				Reporter.addStepLog("verified the msg " + myElement2.getText());
			}  
	 }
	 
	 
	 @Then("^User should not be able to see any error message while updating the following attributes with following values in Update Benchmark page$")
		public void user_should_not_be_able_to_see_any_error_message_while_updating_the_following_attributes_with_following_values_in_update_Benchmark_page(
				List<List<String>> attributeValuePair) throws Throwable {
			Thread.sleep(2000);
			for (int i = 0; i < attributeValuePair.size(); i++) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
						+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
				action.clear(myElement);
				action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
				myElement.sendKeys(Keys.ENTER);
				String message = Action.getTestData("Invalid_Special_Character_Message");
				Assert.assertFalse(action.getPageSource().contains(message));
				Reporter.addStepLog("verified that there is no error message for " + attributeValuePair.get(i).get(0));
			}
		}
	 
	 
	 @Then("^User update the following textfields with Valid Data in the Update Benchmark page$")
	    public void user_update_the_following_textfields_with_valid_data_in_the_update_manager_page(List<String> attribute) throws Throwable {
		 sheetName = "Valid";
			sheet = exlObj.getSheet(sheetName);
			Thread.sleep(2000);
			for (int i = 0; i < attribute.size(); i++) {

				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));	
				if(attribute.get(i).equalsIgnoreCase("Description")) {
					myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
							+ attribute.get(i) + "']\").shadowRoot.querySelector('textarea')");	
				}
				else
					{myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector('input')");
					}
				myElement.clear();

				
				
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				action.sendkeysClipboard(myElement, myValue+UpdateBenchmarkUI.getCurrentTimeStamp());
				Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i));
			}

	    }

	  @And("^User update the following dopdown with Valid Data in the Update Benchmark page$")
	    public void user_update_the_following_dopdown_with_valid_data_in_the_update_benchmark_page(List<String> attribute) throws Throwable {
	    	sheet = exlObj.getSheet(sheetName);
			for (int j = 1; j < attribute.size(); j++) {
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(j));
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
						+ attribute.get(j) + "']\").shadowRoot.querySelector('button')");
				action.scrollToElement(myElement);
				action.click(myElement);
				System.out.println("cell index is"+cellIndex);
				
				myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
						+ attribute.get(j) + "']\").shadowRoot.querySelector(\"li[data-value='\\\""
						+ (String) exlObj.getCellData(sheet, rowIndex, cellIndex) + "\\\"']\")");
				action.click(myElement2);
			}
	    }
	 
	  
	  @Then("^User should be able to see and select the following attributes with the respective options in the Update Benchmark UI$")
		public void user_should_be_able_to_see_and_select_the_following_attributes_with_the_respective_options_in_the_update_benchmark_ui(
				List<List<String>> attributeValuePair) throws Throwable {
			for (int i = 0; i < attributeValuePair.size(); i++) {
				listOfElements = updateBenchmarkPage.findElementsByDynamicXpath(
						"//wf-select[@label='" + attributeValuePair.get(i).get(0) + "']/wf-select-option");
				String[] options = attributeValuePair.get(i).get(1).split(",");
				for (int j = 0; j < options.length; j++) {
					Assert.assertEquals(listOfElements.get(j).getAttribute("name"), options[j]);
					Reporter.addStepLog(
							"verified that " + options[j] + " is present in " + attributeValuePair.get(i).get(0));
				}
			}
		}

	  @Then("^The following attributes should have the following maxlength in the Update Benchmark page$")
		public void the_following_attributes_should_have_the_following_maxlength_in_the_update_benchmark_page(
				List<List<String>> items) throws Throwable {
			for (int i = 0; i < items.size(); i++) {
				myElement = updateBenchmarkPage.findElementByDynamicXpath("//*[@label='" + items.get(i).get(0) + "']");
				Assert.assertEquals(action.getAttribute(myElement, "maxlength"), items.get(i).get(1));
			}
		}
	  
	  @Then("^User should be able to see the Minimum Characters Message while updating with the following values in following attributes in Update Benchmark page$")
		public void user_should_be_able_to_see_the_minimum_characters_message_while_updating_with_the_following_values_in_following_attributes_in_update_benchmark_page(
				List<List<String>> attributeValuePair) throws Throwable {
			Thread.sleep(2000);
			for (int i = 0; i < attributeValuePair.size(); i++) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
						+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
				action.clear(myElement);
				action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
				myElement.sendKeys(Keys.ENTER);
				String message = Action.getTestData("Minimum_Character_Message");
				myElement2 = updateBenchmarkPage.findElementByDynamicXpath(
						"//*[@label='" + attributeValuePair.get(i).get(0) + "']/following-sibling::p");
				Assert.assertTrue(myElement2.getText().contains(message));
				Reporter.addStepLog("verified the msg " + myElement2.getText());
			}
		}
	  
	  @Then("^user should be able to see the following Column Headers in the Update Benchmark UI$")
		public void user_should_be_able_to_see_the_following_column_headers_in_the_update_benchmark_ui(List<String> items)
				throws Throwable {
			Thread.sleep(2000);
			for (int i = 0; i < items.size(); i++) {
				myElement = updateBenchmarkPage.findElementByDynamicXpath("//*[@label='" + items.get(i) + "']");
				Assert.assertTrue(action.isDisplayed(myElement));
				Reporter.addStepLog(items.get(i) + " is present in Upate Style UI page");
			}
	  
	  }
	  
	  
	  @Then("^User should not see any error while updating the following numeric fields with following values in Update Benchmark UI$")
		public void user_should_not_see_any_error_while_updating_the_following_numeric_fields_with_following_values_in_update_benchmark_ui(
				List<List<String>> attributeValuePair) throws Throwable {
			Thread.sleep(2000);
			for (int i = 0; i < attributeValuePair.size(); i++) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
						+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
				action.clear(myElement);
				action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
				// verifying that no error message is there
				String message = Action.getTestData("Invalid_Numeric_Message");
				Assert.assertFalse(action.getPageSource().contains(message));
				Reporter.addStepLog("validated that no error message is there in " + attributeValuePair.get(i).get(0));

			}
			Reporter.addScreenCapture();
		}

		@Then("^User should be able to see the format error by updating the following numeric fields with following values in Update Benchmark UI$")
		public void user_should_be_able_to_see_the_format_error_by_updating_the_following_numeric_fields_with_following_values_in_update_Benchmark_ui(
				List<List<String>> attributeValuePair) throws Throwable {
			Thread.sleep(2000);
			for (int i = 0; i < attributeValuePair.size(); i++) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
						+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
				action.clear(myElement);
				action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
				// verifying that no error message is there
				String message = Action.getTestData("Invalid_Numeric_Message");
				myElement2 = null;
				myElement2 = updateBenchmarkPage.findElementByDynamicXpath(
						"//*[@label='" + attributeValuePair.get(i).get(0) + "']//following-sibling::p");
				Assert.assertTrue(myElement2.getText().contains(message));
				Reporter.addStepLog("validated that the error message is " + myElement2.getText() + " below "
						+ attributeValuePair.get(i).get(0));

			}
			Reporter.addScreenCapture();
		}


		
		@Then("^User should be able to see the Benchmark header on Update Benchmark UI$")
		public void user_should_be_able_to_see_the_style_header_on_update_Benchmark_ui() throws Throwable {
			action.getElement("Benchmark |").isDisplayed();
			Reporter.addStepLog("validate that the Benchmark header is present");
			Reporter.addScreenCapture();
		}

		@Then("^User should be able to see the Benchmark Description below Benchmark header on Update Benchmark page$")
		public void user_should_be_able_to_see_the_style_name_below_style_header_on_update_Benchmark_page()
				throws Throwable {
			Assert.assertTrue(
					action.getElement("Benchmark |").getText().contains(action.getElement("Benchmark Description").getAttribute("value")));
			Reporter.addStepLog("validated that the  Benchmark Description header value matches with the Benchmark Description");
			Reporter.addScreenCapture();
		}
		
		  @Then("^Following attributes should not be updateable in Update Benchmark page$")
		    public void following_attributes_should_not_be_updateable_in_update_benchmark_page(List<String> attribute) throws Throwable {
		       for(int i=0;i<attribute.size();i++) {
		    	myElement = updateBenchmarkPage.findElementByDynamicXpath("//*[@label='"+attribute.get(i)+"']");
		    	Assert.assertEquals("true", action.getAttribute(myElement, "disabled"));
		    	action.highligthElement(myElement);
		    	Reporter.addStepLog("validated that "+attribute.get(i)+" is not editable");
		       }
		       Reporter.addScreenCapture();
		       
		    }
		
	  
	
	 /* 		@Then("^User should be able to see the bottom-border below \"([^\"]*)\" on Update Benchmark UI Page$")
    public void user_should_be_able_to_see_the_bottomborder_below_something_on_update_benchmark_ui_page(String key) throws Throwable {
		String widthInPixel= UpdateBenchmarkUI.giveCssValue(UpdateBenchmarkUI.getElement(key), "border-bottom-width");
        String width = widthInPixel.substring(0, widthInPixel.length()-2);
        Assert.assertTrue(Integer.parseInt(width)>0);
    }
	@Then("^user should be able to see the following \"([^\"]*)\" on Update Benchmark UI Page$")
    public void user_should_be_able_to_see_the_following_something_on_update_benchmark_ui_page(String header,List<String> items) throws Throwable {
		if(header.equalsIgnoreCase("Column Headers")) {
		       for(int i=0;i<items.size();i++) {
		    	   xpath = "//wf-input[@label='"+items.get(i)+"']";
		    	   UpdateBenchmarkUI.verifyElement(UpdateBenchmarkUI.findElementByDynamicXpath(xpath));
		    	   Reporter.addStepLog("The header "+items.get(i)+" is present");
		       }
		       
	    }
			else if(header.equalsIgnoreCase("Dropdown Headers")){
				for(int i=0;i<items.size();i++) {
			    	   xpath = "//label[text()='"+items.get(i)+"']";
			    	   UpdateBenchmarkUI.verifyElement(UpdateBenchmarkUI.findElementByDynamicXpath(xpath));
			    	   Reporter.addStepLog("The header "+items.get(i)+" is present");
			       }
				}
			else if(header.equalsIgnoreCase("Radio Button Headers")){
				for(int i=0;i<items.size();i++) {
			    	   xpath = "//p[text()='"+items.get(i)+"']";
			    	   UpdateBenchmarkUI.verifyElement(UpdateBenchmarkUI.findElementByDynamicXpath(xpath));
			    	   Reporter.addStepLog("The header "+items.get(i)+" is present");
			       }
				
				}
			else if(header.equals("Reference Headers")) {
				listOfElements = UpdateBenchmarkUI.getElements(header);
				for(int i=0;i<items.size();i++) {
				UpdateBenchmarkUI.verifyTextInListOfElements(items.get(i), listOfElements);
				}
			}
	       Reporter.addScreenCapture();
    }
	@Then("^User should \"([^\"]*)\" able to update the following attributes with \"([^\"]*)\" on Update Benchmark UI Page$")
    public void user_should_something_able_to_update_the_following_attributes_with_something_on_update_benchmark_ui_page(String notToUse, String valueType,List<List<String>> attributeValuePair) throws Throwable {
		for(int i=0;i<attributeValuePair.size();i++) {
			javaScript = "return document.querySelector(\"wf-input[label='"+attributeValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('input')";
	    	myElement2 = UpdateBenchmarkUI.getDynamicElementFromShadowRoot(javaScript);
			xpath = "//wf-input[@label='"+attributeValuePair.get(i).get(0)+"']";
			myElement = UpdateBenchmarkUI.findElementByDynamicXpath(xpath);
	    	 myValue =  myElement.getAttribute("value");
	    	 
	    	 myElement2.clear();
	    	if((valueType.contains("Valid")&&attributeValuePair.get(i).get(0).equals("Benchmark Code"))) {
	    		 myValue = attributeValuePair.get(i).get(1)+Calendar.getInstance().getTimeInMillis();
	    		 //locking for writing into excel		
	    		 UpdateBenchmarkUI.writerLock();
	    		 UpdateBenchmarkUI.sendKeysCharacterWise(myValue, myElement2);
	    		 UpdateBenchmarkUI.clickOnLink("Update Button");
	    		 Thread.sleep(1000);
	    		 UpdateBenchmarkUI.writeSearchTokenInExcel("benchmarkCode", "benchmark", myValue);
	    		 UpdateBenchmarkUI.writerUnlock();
	    		 //unlocking after writing into excel
	    	}
	    	
	    	else if(valueType.contains("Valid")){
	    		myValue = attributeValuePair.get(i).get(1);
	    		UpdateBenchmarkUI.sendKeysCharacterWise(myValue, myElement2);
	    		UpdateBenchmarkUI.clickOnLink("Update Button");
		    	Thread.sleep(1000);
	    	}
	    	else
	    	{
	    		UpdateBenchmarkUI.sendKeysCharacterWise(attributeValuePair.get(i).get(1), myElement2);
	    		UpdateBenchmarkUI.clickOnLink("Update Button");
		    	Thread.sleep(1000);
	    	}
	    	
	    	 myElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
	    
	    	UpdateBenchmarkUI.highlightElementWithScroll(myElement);
	    	Assert.assertEquals(myElement.getAttribute("value"), myValue);
	    	Reporter.addScreenCapture(); 
			
			}
   }
   	
	@Then("^User should be able to see and select the following attributes with the respective options on Update Benchmark UI Page$")
    public void user_should_be_able_to_see_and_select_the_following_attributes_with_the_respective_options_on_update_benchmark_ui_page(List<List<String>> attributeValuePair) throws Throwable {
		for(int i=0;i<attributeValuePair.size();i++) {
    		myFlag=false;
    		xpath="//*[text()='"+attributeValuePair.get(i).get(0)+"']/following-sibling::div/select";
    		dropdown = new Select(UpdateBenchmarkUI.findElementByDynamicXpath(xpath));
    	String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
    	for(int j=0;j<listOfValues.length;j++) {

    		dropdown.selectByVisibleText(listOfValues[j]);
    		UpdateBenchmarkUI.clickOnLink("Update Button");
    		Thread.sleep(1000);
	    	myElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
	    	//Boolean some = wait.until(ExpectedConditions.attributeToBeNotEmpty(UpdateBenchmarkUI.findElementByDynamicXpath(xpathForStaleElement), "value"));
	    	dropdown = new Select(myElement);
	    	UpdateBenchmarkUI.highlightElementWithScroll(myElement);
	    	
    		Assert.assertEquals(dropdown.getFirstSelectedOption().getText(), listOfValues[j]);
    		Reporter.addStepLog(listOfValues[j]+" option got selected");
    		Reporter.addScreenCapture();
    	}
    	Reporter.addStepLog(attributeValuePair.get(i).get(0)+" is getting updated");
        }
    }

	
	@And("^The text written in \"([^\"]*)\" should match with the value of \"([^\"]*)\" attribute on Update Benchmark UI Page$")
    public void the_text_written_in_something_should_match_with_the_value_of_something_attribute_on_update_benchmark_ui_page(String actualkey, String expectedkey) throws Throwable {
		Assert.assertEquals(UpdateBenchmarkUI.getText(actualkey), UpdateBenchmarkUI.getElement(expectedkey).getAttribute("value"));
		Reporter.addStepLog("The text written in "+actualkey+" is matching with "+expectedkey);
    }
	
	
	@Then("^The Following attributes should have the following \"([^\"]*)\" in the Update Benchmark UI$")
    public void the_following_attributes_should_have_the_following_something_in_the_update_benchmark_ui(String attributeName, List<List<String>> attributeValuePair) throws Throwable {
		for(int i=0;i<attributeValuePair.size();i++) {
	    	xpath="//wf-input[@label='"+attributeValuePair.get(i).get(0)+"']";
	    	
	   	 myElement = UpdateBenchmarkUI.findElementByDynamicXpath(xpath);
	   	 myValue =  myElement.getAttribute(attributeName);
	   	 Reporter.addStepLog("verifying the "+attributeName+" attribute for "+attributeValuePair.get(i).get(0));
	   	 Assert.assertEquals(myValue, attributeValuePair.get(i).get(1));
	    	}
    }
	
	
	@And("^User should not be able to update the following attributes on Update Benchmark UI Page$")
    public void user_should_not_be_able_to_update_the_following_attributes_on_update_benchmark_ui_page(List<String> Attribute) throws Throwable {
		for(int i=0;i<Attribute.size();i++) {
	    	 xpath="//wf-input[@label='"+Attribute.get(i)+"']";;
	    	myElement = UpdateBenchmarkUI.findElementByDynamicXpath(xpath);
	    	Assert.assertEquals( myElement.getAttribute("disabled"), "true");
	    	Reporter.addStepLog(Attribute.get(i)+" is not updatable");
	    	}
    }
	@Then("^User should not have the option to update the following attributes on Update Benchmark UI Page$")
    public void user_should_not_have_the_option_to_update_the_following_attributes_on_update_benchmark_ui_page(List<String> Attribute) throws Throwable {
		for(int i=0;i<Attribute.size();i++) {
    		myFlag = false;
	    	 xpath="//*[text()='"+Attribute.get(i)+"']/ancestor::p/following-sibling::span";
	    	 myElement = UpdateBenchmarkUI.findElementByDynamicXpath(xpath);
	    	 myValue =  myElement.getText();
	    	 try
	    	 {myElement.sendKeys("daksjfds");
	    	 }
	    	 catch (ElementNotInteractableException e) {
				myFlag = true;
				Assert.assertTrue(myFlag);
				Reporter.addStepLog(Attribute.get(i)+" is not editable");
			}
	    	 
	    	 Assert.assertTrue(myFlag);
	    	 Reporter.addScreenCapture();
	    	}
    }
	@And("^user clicks the \"([^\"]*)\" on Update Benchmark UI Page$")
    public void user_clicks_the_something_on_update_benchmark_ui_page(String key) throws Throwable {
		UpdateBenchmarkUI.clickOnLink(key);
		Reporter.addStepLog("clicked on "+key);
    }
	@Then("^User should be able to see the \"([^\"]*)\" on Update Benchmark UI Page$")
    public void user_should_be_able_to_see_the_something_on_update_benchmark_ui_page(String key) throws Throwable {
		UpdateBenchmarkUI.verifyElement(key);
		Reporter.addStepLog("verified that "+key+" is present");
    }
	@And("^User should be able to see the \"([^\"]*)\" inside Update Benchmark UI Page$")
    public void user_should_be_able_to_see_the_something_inside_update_benchmark_ui_page(String key) throws Throwable {
        UpdateBenchmarkUI.verifyElement(UpdateBenchmarkUI.getElementFromShadowRoot(key));
        Reporter.addStepLog("verified that "+key+" is present");
    }

    @And("^The \"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Update Benchmark UI Page$")
    public void the_something_should_be_displayed_in_something_color_inside_update_benchmark_ui_page(String key, String expectedColor) throws Throwable {
    	expectedColorCode = Action.getTestData(expectedColor);
		UpdateBenchmarkUI.verifyColor( UpdateBenchmarkUI.getElementFromShadowRoot(key),expectedColorCode);
		Reporter.addStepLog("verified that "+key+" has "+expectedColor+" color");
    }

    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Update Benchmark UI Page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_update_benchmark_ui_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
    	UpdateBenchmarkUI.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = UpdateBenchmarkUI.getElementsFromShadowRoot(key);
   		UpdateBenchmarkUI.verifyTextInListOfElements( items.get(i),listOfElements);  
        } 
    }
	@Then("^User should be able to see the \"([^\"]*)\" header on Update Benchmark UI Page$")
    public void user_should_be_able_to_see_the_something_header_on_update_benchmark_ui_page(String key) throws Throwable {
		UpdateBenchmarkUI.verifyHeader(key);
		Reporter.addStepLog("verified that "+key+" header is present");
    }
	
	
	@And("^The \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Update Benchmark UI Page$")
    public void the_something_should_be_displayed_in_something_color_on_update_benchmark_ui_page(String key, String expectedColor) throws Throwable {
		expectedColorCode = Action.getTestData(expectedColor);
		UpdateBenchmarkUI.verifyColor( key,expectedColorCode);
    }
	
	@And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Update Benchmark UI Page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_on_update_benchmark_ui_page(String ghostText, String searchBox) throws Throwable {
		UpdateBenchmarkUI.verifyGhostText(ghostText, UpdateBenchmarkUI.getElementFromShadowRoot(searchBox));
		Reporter.addStepLog("verified that the ghostText for "+searchBox+" is "+ghostText);
    }
	
	
	@And("^The \"([^\"]*)\" on the Update Benchmark UI Page should contain all the following options$")
    public void the_something_on_the_update_benchmark_ui_page_should_contain_all_the_following_options(String key,List<String> options) throws Throwable {
		listOfElements = UpdateBenchmarkUI.getElements(key);
        for(int i=0;i<options.size();i++) {
        	UpdateBenchmarkUI.verifyTextInListOfElements(options.get(i), listOfElements);
        	Reporter.addStepLog("verified that the text "+options.get(i)+" is present");
        }
    }
	
	
	
	
	
		@And("^user will update below textfields with their respective values and store it in list on Update Benchmark UI$")
    public void user_will_update_below_textfields_with_their_respective_values_and_store_it_in_list_on_update_benchmark_ui(List<List<String>> attributeValuePair) throws  Throwable {
       for(int i=0;i<attributeValuePair.size();i++) {
    	   javaScript = "return document.querySelector(\"wf-input[label='"+attributeValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('input')";
	    	myElement2 = UpdateBenchmarkUI.getDynamicElementFromShadowRoot(javaScript);
			xpath = "//wf-input[@label='"+attributeValuePair.get(i).get(0)+"']";
			myElement = UpdateBenchmarkUI.findElementByDynamicXpath(xpath);
	    	 myValue =  myElement.getAttribute("value");
	    	 
	    	 myElement2.clear();
        
       if(attributeValuePair.get(i).get(0).equals("Benchmark Code")) {
               myValue = attributeValuePair.get(i).get(1)+Calendar.getInstance().getTimeInMillis();
                            UpdateBenchmarkUI.sendKeysCharacterWise(myValue, myElement2);
       }
       else {
              myValue = attributeValuePair.get(i).get(1);
              UpdateBenchmarkUI.sendKeysCharacterWise(myValue, myElement2);
       }
       Reporter.addStepLog(myValue+ " is send in the textfield of "+attributeValuePair.get(i).get(0));
       IntegrationGeneric.UIPassedValues.put(attributeValuePair.get(i).get(0), myValue);
       
}
    }

    @And("^user will update below dropdowns with their respective values and store it in list on Update Benchmark UI$")
    public void user_will_update_below_dropdowns_with_their_respective_values_and_store_it_in_list_on_update_benchmark_ui(List<List<String>> attributeValuePair) {
       for(int i=0;i<attributeValuePair.size();i++) {
              myFlag=false;
              xpath="//*[text()='"+attributeValuePair.get(i).get(0)+"']/following-sibling::div/select";
              dropdown = new Select(UpdateBenchmarkUI.findElementByDynamicXpath(xpath));
              dropdown.selectByVisibleText(attributeValuePair.get(i).get(1));
              Reporter.addStepLog(attributeValuePair.get(i).get(1)+" option got selected for "+attributeValuePair.get(i).get(0));
              IntegrationGeneric.UIPassedValues.put(attributeValuePair.get(i).get(0), attributeValuePair.get(i).get(1));
       }
    }

   @And("^user will update below radio buttons with their respective values and store it in list on Update Benchmark UI$")
    public void user_will_update_below_radio_buttons_with_their_respective_values_and_store_it_in_list_on_update_benchmark_ui(List<List<String>> attributeValuePair) {
       for(int i=0;i<attributeValuePair.size();i++) {
              myValue=null;
              xpath="//*[text()='"+attributeValuePair.get(i).get(0)+"']/following-sibling::input";
              listOfElements=UpdateBenchmarkUI.findElementsByDynamicXpath(xpath);
              if(attributeValuePair.get(i).get(1).equalsIgnoreCase("Yes")) {
                     listOfElements.get(0).click();
                     myValue = "true";
              }
              else if(attributeValuePair.get(i).get(1).equalsIgnoreCase("No")) {
                    listOfElements.get(1).click();
                     myValue = "false";
              }
              else
              {
                     Reporter.addStepLog("choice not available");
                     Assert.assertTrue(false);
              }
              Reporter.addStepLog(attributeValuePair.get(i).get(1)+" option got selected for "+attributeValuePair.get(i).get(0));
              IntegrationGeneric.UIPassedValues.put(attributeValuePair.get(i).get(0), myValue);
       }
    }
   */

	  }

	
	


