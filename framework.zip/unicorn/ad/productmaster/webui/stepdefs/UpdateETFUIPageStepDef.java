package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.awt.Robot;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

//import qa.unicorn.ad.productmaster.webui.pages.UpdateMutualFundUIPage;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.And;

public class UpdateETFUIPageStepDef {

	List<DBRowTO> PageElementList = SQLDriver.getEleObjData("AD_PM_LandingPage,AD_PM_UpdateETFUIPage");
	Action action =  new Action(PageElementList);
	PMPageGeneric landingPage = new PMPageGeneric("AD_PM_LandingPage");
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	String expectedColorCode,searchValue,myValue;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/etf/edit/";

	WebDriver driver;
	XSSFSheet sheet;
	String excelPathForReference = "./src/test/resources/ad/productmaster/api/excel/ReferenceDetails.xlsx";
	ExcelUtils myReferenceFile = new ExcelUtils(ExcelOperation.LOAD, excelPathForReference);
	WebElement myElement,myElement2;
	List<String> searchTokens ;
	
	List<WebElement> listOfElements,listOfElements2 = new ArrayList<WebElement>();
	 

	    @When("^User search the ETF with the \"([^\"]*)\" taken from \"([^\"]*)\" in the Search TextBox on landing page$")
	    public void user_search_the_etf_with_the_something_taken_from_something_in_the_search_textbox_on_landing_page(String attribute, String sheetName) throws Throwable {
	        //search etf
	    	  landingPage.readLock(); 
				searchValue=landingPage.readSearchTokenFromExcel(attribute, sheetName);
				landingPage.readUnlock();
				//unlocking after reading from excel
		         if(searchValue.length()>20) {
		         searchValue =searchValue.substring(searchValue.length()-20) ;
		         }
		         myElement = (WebElement) action.getElementByJavascript("Search_TextBox");
		        Thread.sleep(5000);
		        Reporter.addStepLog("searching with "+searchValue);
	            myElement.click();
		        action.sendkeysClipboard( myElement,searchValue);
		        Thread.sleep(5000);
		        int i=0;
				
				  while(i<5) { 
					  action.sendKeys(Keys.ENTER); i++; 
					  }
				 
		        
		        Thread.sleep(10000);
	    	
	    }

	    @Then("^User should be able to go Update ETF UI screen$")
	    public void user_should_be_able_to_go_update_etf_ui_screen() throws Throwable {
	       
	    	Assert.assertTrue(action.getCurrentURL().contains(pageURL), "We are in UpdateMutualFundUIPage");
	    	action.TakeScreenshot();
			Reporter.addScreenCapture();
	    }

	    @And("^User clicks on the first element of ETF Searches on the suggestion box on landing page$")
	    public void user_clicks_on_the_first_element_of_etf_searches_on_the_suggestion_box_on_landing_page() throws Throwable {
	        
	    	action.click(action.getElement("Search_Result"));
	        Reporter.addStepLog("clicking on the first element of Mutual Fund search");
	        Thread.sleep(10000); 
	    }

	    @And("^User clicks the Edit Button on ETF Detail page$")
	    public void user_clicks_the_edit_button_on_etf_detail_page() throws Throwable {
	        
	    	action.click(action.getElement("Edit_Button"));
	        Reporter.addStepLog("clicked on Edit button");
	        Thread.sleep(10000);
	    }
	    @Then("^user should be able to see the following Column Headers in the Update ETF UI$")
	    public void user_should_be_able_to_see_the_following_column_headers_in_the_update_etf_ui(List<String> items) throws Throwable {
	    	//verify user can see column header
			
			  listOfElements = action.getElements("Column Headers");
				// storing all the labels in the list
				List<String> list = new ArrayList<String>();
				for (int i = 0; i < listOfElements.size(); i++) {
					
					
					list.add(listOfElements.get(i).getAttribute("label"));
					
				}

				for (int i = 0; i < items.size(); i++) {
					Assert.assertTrue(list.contains(items.get(i)));

					Reporter.addStepLog("The header " + items.get(i) + " is present");
				}
				Reporter.addScreenCapture();
	    }
	    
	
}
