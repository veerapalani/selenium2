package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreatePMPStrategyBenchmarkStepDef {

	CreatePMPStrategyBenchmarkPage benchmarkPage = new CreatePMPStrategyBenchmarkPage("AD_PM_CreatePMPStrategyBenchmarkPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
	String mandatorydetails, sheetName, uiValue = "";
	int rowIndex,columnIndex;
	
	public static int count;
	
	@And("^User selects Custom in Benchmark Page in PMP Flow$")
    public void user_selects_custom_in_benchmark_page_in_pmp_flow() {
    	benchmarkPage.selectCustom();
    }
    
    @And("^User inputs (.+) in Benchmark Page in PMP Flow$")
    public void user_inputs_in_benchmark_page_in_pmp_flow(String mandatorydetails) throws SQLException, IOException {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}
		
		String benchmarkCategory,benchmark,benchmarkPercentage,customBenchmarkReason = "";
		String locatorValueCustomBenchmark,locatorValueCustomBenchmarkHighlight,locatorValueCustomBenchmarkPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			
			benchmarkCategory = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 19);
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 20);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 21);
			customBenchmarkReason = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 22);
		}
			if(benchmarkCategory != "") {
				switch (benchmarkCategory) {
					case "Custom":
						benchmarkPage.selectCustom();
						if(benchmark != "") {
							
							int i =0;
							sheetName = "VariablePaths";
							tName = Thread.currentThread().getName();
							synchronized (tName) {
							locatorValueCustomBenchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 1, 1);
							locatorValueCustomBenchmarkHighlight = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 2, 1);
							locatorValueCustomBenchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 3, 1);
							}
							
							if(benchmark.contains(",")) {
								String[] customBenchmark = benchmark.split(",");
								String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
								int size = customBenchmark.length;

								
								
								while(size > 0) {

									benchmarkPage.enterCustomBenchmark(locatorValueCustomBenchmark.replace("@data",i+"'"), locatorValueCustomBenchmarkHighlight.replace("@data",i+"'"), customBenchmark[i], benchmarkCategory, i);
									benchmarkPage.enterCustomBenchmarkPercentage(locatorValueCustomBenchmarkPercentage.replace("@data",i+"'"), customBenchmarkPercentage[i], benchmarkCategory, i);
									i++;
									size--;
									if(size>0) {
										benchmarkPage.addNewBenchmark();
									}
								}
							}
							else {
								
								benchmarkPage.enterCustomBenchmark(locatorValueCustomBenchmark.replace("@data",i+"'"), locatorValueCustomBenchmarkHighlight.replace("@data",i+"'"), benchmark, benchmarkCategory, i);
								benchmarkPage.enterCustomBenchmarkPercentage(locatorValueCustomBenchmarkPercentage.replace("@data",i+"'"), benchmarkPercentage, benchmarkCategory, i);
						
							}
						}
						if(customBenchmarkReason != "") {
							benchmarkPage.enterCustomBenchmarkReason(customBenchmarkReason);
						}
						break;
					case "PMP Default":
						
						benchmarkPage.clickOnViewDetails();
						String defaultValue = benchmarkPage.getDefaultValueAutopopulated();
						String[] value = defaultValue.split(":");
						if (mandatorydetails.contains("Test")) {
							sheetName = "Test";
						}
						tName = Thread.currentThread().getName();
						synchronized (tName) {
						rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
						PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 20, value[0]);
						PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 21, value[1]);
						}
						benchmarkPage.clickOnCrossIcon();
						break;
			
					default:
						break;
				}
			}
			
		
		Reporter.addScreenCapture();
    }

    @And("^User clicks on Next in Benchmark details Page$")
    public void user_clicks_on_next_in_benchmark_details_page() {
        benchmarkPage.clickOnNext();
    }
    
    @And("^User should be able to see Benchmark details Page in PMP Flow$")
    public void user_should_be_able_to_see_benchmark_details_page_in_pmp_flow() {
        assertTrue(benchmarkPage.isUserOnBenchmarkPage());
    }
    
    @Then("^User should be able to see PMP Approved and Active Benchmarks$")
    public void user_should_be_able_to_see_pmp_approved_and_active_benchmarks() {
        
    }

    @And("^User clicks on Benchmark Dropdown$")
    public void user_clicks_on_benchmark_dropdown() throws SQLException, IOException {
    	int i =0;
		sheetName = "VariablePaths";
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
		String locatorValueCustomBenchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 1, 1);
		String locatorValueCustomBenchmarkHighlight = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 2, 1);
		
        int countInUI = benchmarkPage.clickOnBenchmarkDropdown(locatorValueCustomBenchmark.replace("@data",i+"'"), locatorValueCustomBenchmarkHighlight.replace("@data",i+"'"));
        pmdb.DBConnectionStart();
        
        sheetName = "Query";
        String dbDataIterator = "testnull";
        int cellnum = 4;
    	ResultSet rs;
    	
    	String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		//SQLquery = SQLquery.replace("@data", "'"+replaceData+"'");
		rs= DBManager.executeSelectQuery(SQLquery);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
		int count = 1;
		while(rs.next()) {
			
				dbDataIterator = rs.getString(labelname);
				if(rs.wasNull() || dbDataIterator.isEmpty()) {
    				dbDataIterator = "0";
    			}
				
		 }
		//to handle Zero records from DB 
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "0";
		}
        int countInDB = Integer.parseInt(dbDataIterator);
        
        if(countInUI != countInDB) {
        	Assert.fail();
        }else {
        	Reporter.addStepLog("User is able to see Active and PMP Approved benchmarks in Dropdown");
        }
        }
    }
    
    @Then("^User should be able to see added benchmarks from (.+) are sorted in descending order in Benchmark Page in PMP Flow$")
    public void user_should_be_able_to_see_added_benchmarks_from_are_sorted_in_descending_order_in_benchmark_page_in_pmp_flow(String mandatorydetails) {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String benchmarkCategory,benchmark,benchmarkPercentage,customBenchmarkReason = "";
		String locatorValueCustomBenchmark,locatorValueCustomBenchmarkHighlight,locatorValueCustomBenchmarkPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 20);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 21);
			
		}
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			benchmarkfromUI = benchmarkPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = benchmarkPage.getPercentageithValuefromUI(j);
			
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey));
			j++;
			
		}
		
    }

    private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
    	
    	Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().split(" - ")[1].trim().compareTo(o2.getKey().split(" - ")[1].trim()));
		
		//sort based on benchmark percentage
		Collections.sort(entryList, (o1, o2) -> {
			if(o1.getValue() > o2.getValue()) {
				return -1;
			}else if(o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});
		
		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
			@Override
			public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
				if(o1.getValue() > o2.getValue()) {
					return -1;
				}else if(o1.getValue() < o2.getValue()) {
					return 1;
				}
				return 0;
			}
		});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		  for (String countryKey : sortedHashMap.keySet()) {
		  System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		  
		  }*/
		 
		return sortedHashMap;
	}

	@And("^User Edits the Benchmarks in Benchmark page in PMP Flow$")
    public void user_edits_the_benchmarks_in_benchmark_page_in_pmp_flow() {
        benchmarkPage.deleteallcustomBenchmarks();
    }

    @And("^User clicks on Previous Button in Benchmark page in PMP Flow$")
    public void user_clicks_on_previous_button_in_benchmark_page_in_pmp_flow() {
        benchmarkPage.clickOnPrevious();
    }
    
    @Then("^User input fields from (.+) should be visible in Benchmark Details Page in PMP Flow$")
    public void user_input_fields_from_should_be_visible_in_benchmark_details_page_in_pmp_flow(String mandatorydetails) {
    	

    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String benchmarkfromUI,userGivenBenchmark,userGivenPercentage,percentagefromUI;
		userGivenBenchmark = "";
		userGivenPercentage = "";
		benchmarkfromUI = "";
		percentagefromUI = "";

		if(benchmarkPage.getBenchmarkCategory().equalsIgnoreCase("Custom")) {
	    	String benchmark,benchmarkPercentage = "";
			
			
			String tName = Thread.currentThread().getName();
			synchronized (tName) {
				
				rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
				
				benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 20);
				benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 21);
				
			}
			
			HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
			LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
			
			if(benchmark.contains(",")) {
				String[] customBenchmark = benchmark.split(",");
				String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
				int size = customBenchmark.length;
				
				for (int i = 0; i < size; i++) {
					customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
				}
				
				sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
			}else {
				sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
			}
			
			Iterator<Entry<String, Float>> iterator = sortedHashMap.entrySet().iterator();
			
			int benchcount = benchmarkPage.getbenchmarkscount();
			for (int i = 0; i < benchcount; i++) {
				
				Entry<String, Float> entry = iterator.next();
				
				userGivenBenchmark = userGivenBenchmark+entry.getKey() +",";
				userGivenPercentage = userGivenPercentage+entry.getValue().toString()+",";
				
				benchmarkfromUI = benchmarkfromUI + benchmarkPage.getBenchmarkithValuefromUI(i) + ",";
				percentagefromUI = percentagefromUI + benchmarkPage.getPercentageithValuefromUI(i).toString() + ",";
				
			}
			/*
			for (String benchmarkKey : sortedHashMap.keySet()) {
				
				userGivenBenchmark = userGivenBenchmark+benchmarkKey +",";
				userGivenPercentage = userGivenPercentage+sortedHashMap.get(benchmarkKey).toString()+",";
				
				benchmarkfromUI = benchmarkfromUI + benchmarkPage.getBenchmarkithValuefromUI(j) + ",";
				percentagefromUI = percentagefromUI + benchmarkPage.getPercentageithValuefromUI(j).toString() + ",";
				j++;
				
			}
			*/
			
			}
	
	
    	
		
    	String label, attributeValue, userGivenValue = null;
		   //sheet = exlObj.getSheet(sheetName);
		   int columnnum = 19;
		   count = 0;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnnum);
				   //(String) exlObj.getCellData(sheet, 0, columnnum);
		   
		   if((label == "") || (label.contains("Document Type_onlysort")))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")) {
						columnnum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnnum);
			    					//(String) exlObj.getCellData(sheet, 0, columnnum).toString();
			    			
			    			if((label == "") ||(label.contains("Document Type_onlysort")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromBenchmarkPage(label);
						rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
						userGivenValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, columnnum);
						
						//Handling the Exceptions
						if(label.contains("Benchmark Name")) {
							if(benchmarkPage.getBenchmarkCategory().equalsIgnoreCase("Custom")) {
								attributeValue = benchmarkfromUI.substring(0, benchmarkfromUI.length()-1);
								userGivenValue = userGivenBenchmark.substring(0, userGivenBenchmark.length()-1);
							}else if (benchmarkPage.getBenchmarkCategory().equalsIgnoreCase("PMP Default")) {
								benchmarkPage.clickOnViewDetails();
								String[] data = benchmarkPage.getDefaultValueAutopopulated().split(":");
								attributeValue = data[0];
								benchmarkPage.clickOnCrossIcon();
							}
						}
						if(label.contains("Percentage_onlysort")) {
							if(benchmarkPage.getBenchmarkCategory().equalsIgnoreCase("Custom")) {
								attributeValue = percentagefromUI.substring(0, percentagefromUI.length()-1);
								userGivenValue = userGivenPercentage.substring(0, userGivenPercentage.length()-1);
							}else if (benchmarkPage.getBenchmarkCategory().equalsIgnoreCase("PMP Default")) {
								benchmarkPage.clickOnViewDetails();
								String[] data = benchmarkPage.getDefaultValueAutopopulated().split(":");
								attributeValue = data[1];
								benchmarkPage.clickOnCrossIcon();
							}
						}

						
						if(userGivenValue.isEmpty())
							userGivenValue = "isEmpty";
							
						
						
						if(userGivenValue.equalsIgnoreCase(attributeValue)) {
							//Value in UI Matches with value given by user
						}else {
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Label: "+label+" -- Uservalue: "+userGivenValue);
							Reporter.addStepLog("For Label: "+label+" -- UIvalue: "+attributeValue);
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Value given as input by user");
							count++;
							
						}
						
						
						columnnum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnnum);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("Document Type_onlysort")))
								label = "isEmpty";
					
					}
			}
			
			if(count > 0) {
				Assert.fail("Prepopulated Values are not same as values stored in DB");
			}
			
    }

	private String getDataFromBenchmarkPage(String label) {
			switch (label) {
			case "BenchmarkCategory":
				
				uiValue = benchmarkPage.getBenchmarkCategory();
				
				break;
			case "Custom Benchmark Reason":
				
				uiValue = benchmarkPage.getBenchmarkReason();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if((uiValue == null) || (uiValue.isEmpty()))
			uiValue = "isEmpty";
	
		return uiValue;
	}
	
	@Then("^User should be able to see below label in Benchmark Page$")
    public void user_should_be_able_to_see_below_label_in_benchmark_page(List<String> data) {
        for (String label : data) {
			Assert.assertTrue(benchmarkPage.isLabelVisibleinBenchmarkPage(label));
		}
    }
	
	@Then("^user input fields should all be cleared in Benchmark Page in PMP Flow$")
    public void user_input_fields_should_all_be_cleared_in_benchmark_page_in_pmp_flow() {
        benchmarkPage.isUserOnBenchmarkPage();
        
        Assert.assertTrue(benchmarkPage.getBenchmarkCategory().equals("PMP Default"));
        benchmarkPage.selectCustom();
        String benchmarkfromUI,percentagefromUI;
		
		benchmarkfromUI = "";
		percentagefromUI = "";
        int benchcount = benchmarkPage.getbenchmarkscount();
		for (int i = 0; i < benchcount; i++) {
			
			benchmarkfromUI = benchmarkfromUI + benchmarkPage.getBenchmarkithValuefromUI(i) + ",";
			percentagefromUI = percentagefromUI + benchmarkPage.getPercentageithValuefromUI(i).toString() + ",";
			
		}
		
    	
    		sheetName = "SQLquerywithCode";
    	
    	
    	String label, attributeValue, expectedDefaultValue = null;
		   //sheet = exlObj.getSheet(sheetName);
		   int rownum = 19;
		   count = 0;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
				   
		   
		   if((label == "") || (label.contains("Document Type_onlysort")))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")) {
						rownum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
			    					
			    			
			    			if((label == "") ||(label.contains("Document Type_onlysort")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromBenchmarkPage(label);
						expectedDefaultValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 3);
						if(expectedDefaultValue == "")
							expectedDefaultValue = "isEmpty";
						
						//Handling the Exceptions
						if(label.contains("Benchmark Name")) {
							if(benchmarkPage.getBenchmarkCategory().equalsIgnoreCase("Custom")) {
								attributeValue = benchmarkfromUI.substring(0, benchmarkfromUI.length()-1);
							}
						}
						if(label.contains("Percentage_onlysort")) {
							if(benchmarkPage.getBenchmarkCategory().equalsIgnoreCase("Custom")) {
								attributeValue = percentagefromUI.substring(0, percentagefromUI.length()-1);
								attributeValue = attributeValue+"0";
								
							}
						}
						
						Assert.assertTrue("For "+label +" :: UI Value ::--" +attributeValue+"  --:: Excel Value ::"+expectedDefaultValue, attributeValue.equals(expectedDefaultValue));
						rownum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("Document Type_onlysort")))
								label = "isEmpty";
					
					}
			}
		
    
    }

    @And("^User clicks on Reset Button in Benchmark Page in PMP Flow$")
    public void user_clicks_on_reset_button_in_benchmark_page_in_pmp_flow() {
        benchmarkPage.clickOnResetButton();
    }
    
    @Then("^\"([^\"]*)\" Radio button should be selected in Benchmark page in PMP Flow$")
    public void something_radio_button_should_be_selected_in_benchmark_page_in_pmp_flow(String benchCategory) {
        Assert.assertTrue(benchmarkPage.getBenchmarkCategory().equals(benchCategory));
    }
    
    @Then("^in Benchmark Page in PMP Flow user should not be able to add more Custom Benchmarks than the max limit$")
    public void in_benchmark_page_in_pmp_flow_user_should_not_be_able_to_add_more_custom_benchmarks_than_the_max_limit() {
    	assertTrue(benchmarkPage.isAddNewBenchmarkOptionNotVisible());
    }
    
    @Then("^in Benchmark Page all Active Benchmarks should be populated in Benchmark dropdown in PMP Flow$")
    public void in_benchmark_page_all_active_benchmarks_should_be_populated_in_benchmark_dropdown_in_pmp_flow() throws SQLException {
		
        benchmarkPage.selectCustom();
        
        sheetName = "VariablePaths";
        
		
		
				//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String locatorValueCustomBenchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 1, 1); 
				//(String) exlObj.getCellData(sheet, 1, 1);
		String locatorValueCustomBenchmarkHighlight = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 2, 1); 
				//(String) exlObj.getCellData(sheet, 2, 1);
		int i=0;
        
        
        assertTrue(benchmarkPage.checkActiveBenchmarkCount(locatorValueCustomBenchmark.replace("@data",i+"'"),locatorValueCustomBenchmarkHighlight.replace("@data",i+"'")));
    }
    
    @Then("^Benchmark displayed under PMP Default should match with DB Data for CAPS Style in PMP Flow for (.+)$")
    public void benchmark_displayed_under_pmp_default_should_match_with_db_data_for_caps_style_in_pmp_flow_for(String mandatorydetails) throws Throwable {
        
    	if(mandatorydetails.contains("Test"))
    		sheetName = "Test";
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    	String investmentStyleGiven = PMPageGeneric.getCellDataSync(excelFilePath, mandatorydetails, rowIndex, 2);
    	
    	benchmarkPage.clickOnViewDetails();
    	String defaultValue = benchmarkPage.getDefaultValueAutopopulated();
		String[] value = defaultValue.split(":");
    	benchmarkPage.clickOnCrossIcon();
    	
    	int cellnum = 11;
		pmdb.DBConnectionStart();
		String dbDataIterator;
		
		ResultSet rs;

			

				dbDataIterator = "testnull";
				ArrayList<String> tempData = new ArrayList<String>();

				String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
				String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
				SQLquery = SQLquery.replace("@data", "'" + investmentStyleGiven + "'");
				rs = DBManager.executeSelectQuery(SQLquery);
				
				while (rs.next()) {

					dbDataIterator = rs.getString(labelname);
					if (rs.wasNull() || dbDataIterator.isEmpty()) {
						dbDataIterator = "isEmpty";
					}
					tempData.add(dbDataIterator);

				}
				// to handle Zero records from DB
				if (dbDataIterator.equalsIgnoreCase("testnull")) {
					dbDataIterator = "isEmpty";
				}
				if (tempData.size() > 1) {
					Collections.sort(tempData);
					dbDataIterator = "";
					for (String G : tempData) {
						dbDataIterator = dbDataIterator + G + ":";
					}
					tempData.clear();

				}
				
				Assert.assertTrue(value[0].equals(dbDataIterator));
	
    }
	
    @And("^On Benchmark page under PMP default the CASP Style of the investment style selected should be displayed for (.+)$")
    public void on_benchmark_page_under_pmp_default_the_casp_style_of_the_investment_style_selected_should_be_displayed(String mandatorydetails) throws Throwable {
        
    	if(mandatorydetails.contains("Test"))
    		sheetName = "Test";
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    	String investmentStyleGiven = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 2);
    	System.out.println("investmentStyleGiven :"+investmentStyleGiven);
    	String benchmarkvalueGiven = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 28);
    	benchmarkPage.clickOnViewDetails();
    	String benchmarkValue = benchmarkPage.getBenchmarkName();
    	String benchmarkPercentage = benchmarkPage.getBenchmarkPercentage();
    	Assert.assertTrue(benchmarkvalueGiven.contains(benchmarkValue));
    	Assert.assertTrue(benchmarkvalueGiven.contains(benchmarkPercentage));
    	Reporter.addScreenCapture();
    	benchmarkPage.clickOnCrossIcon();
    }
}
