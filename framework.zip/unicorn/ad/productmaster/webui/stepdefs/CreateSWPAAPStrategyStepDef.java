package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.fail;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Flags.Flag;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.codoid.products.fillo.Select;
import com.google.gson.Gson;
import com.hp.lft.sdk.mobile.DropDown;
import com.ibm.db2.jcc.a.i;
import com.ibm.db2.jcc.am.s;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.remote.NewAppiumSessionPayload;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateEntitySWPUIPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.SaveAsDraftAllUIPage;
import qa.unicorn.ad.productmaster.webui.pages.StrategyDetailPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategySMADualUIPage;

public class CreateSWPAAPStrategyStepDef 
	{
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleSWPAAP1.xlsx";
		String sheetName = "";
		String myValue,myValue1;
		XSSFSheet sheet;
		int rowIndex, cellIndex;
		WebElement myElement,myElement1;
		List<WebElement> myElements,myElements1;
		String proxyDetails[]= {"Proxy Address","Voluntary Reorg Address","Interim"};
		String scenario[]= {"0","2","4"};
		int num;
		String timeStamp = new SimpleDateFormat("dd-MM-yyyy(HH:mm)").format(new Date());
		List<List<String>> attributeLists = new ArrayList<List<String>>();
		List<String> dataList = new ArrayList<String>() ;
		
		WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
		
		Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategySMADualUIPage"));		

		CreateEntitySWPUIPage createSWPUIPage = new CreateEntitySWPUIPage();
		
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		
		StrategyDetailPage strDtl = new StrategyDetailPage();
		
		SoftAssert sftAst = new SoftAssert();
		
		ProductMasterDBManager pmdb = new ProductMasterDBManager();
		
		HashMap<String, String> DropDownValues = new HashMap<String, String>();
		HashMap<String, String> InputValues = new HashMap<String, String>();
		HashMap<String, String> DropDownValuesId = new HashMap<String, String>();
		HashMap<String, String> InputValuesId = new HashMap<String, String>();
		HashMap<String, String> DataBaseValues = new HashMap<String, String>();
		HashMap<String, String> ProxyValues = new HashMap<String, String>();
		
		String applicationPropertyFilePath = "./application.properties";

		PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
		//String UIEnvironment = property.getProperty("ProductMaster_UI_Environment").trim().toUpperCase();
		 String UIEnvironment = SSOLoginPage.UIEnvironment.trim().toUpperCase();
		
	@When("^User clicks on Create New Dropdown Button on landing page of Create SWPAAP Strategy flow$")
	public void user_clicks_on_create_new_dropdown_button_on_landing_page_of_create_swpaap_strategy_flow() throws Throwable
	{
		try
		{
			createSWPUIPage.clickCreateNew();
		}
		catch(Exception e)
		{
			Assert.fail("Unable to access Create New button");
		}
	}
		

    @And("^User clicks on \"([^\"]*)\" option from the dropdown of Create SWPAAP Strategy flow$")
    public void user_clicks_on_something_option_from_the_dropdown_of_create_swpaap_strategy_flow(String strArg1) throws Throwable
	    {
	    	try
	    	{
	    		createSWPUIPage.clickCreateNewOption(strArg1);
	    	}
	    	
	    	catch (Exception e) 
	    	{
				Assert.fail("Unable to access "+ strArg1 +" option");
			}	    
	    }
	    
    @Then("^User should be able to see the \"([^\"]*)\" header of Create SWPAAP Strategy flow$")
    public void user_should_be_able_to_see_the_something_header_of_create_swpaap_strategy_flow(String strArg1) throws Throwable
	    {
	    	try
	    	{
	    		createSWPUIPage.checkHeader(strArg1);

	    	}
	    	catch (Exception e) {

	    		Assert.fail(strArg1+" header is not present");
	    	}
	    }
    

    @And("^User clicks on the \"([^\"]*)\" Button of Create SWPAAP Strategy flow$")
    public void user_clicks_on_the_something_button_of_create_swpaap_strategy_flow(String strArg1) throws Throwable
    {
    	try
    	{
    		createSWPUIPage.clickButton(strArg1);
    	}
    	catch (Exception e) 
    	{
    		Assert.fail("Unable to access global search Results");
    	}	
    }
		
    @Then("^User clicks on \"([^\"]*)\" on strategy window of Create SWPAAP Strategy flow$")
    public void user_clicks_on_something_on_strategy_window_of_create_swpaap_strategy_flow(String strArg1) throws Throwable
    {
    	try 
    	{
			Thread.sleep(2000);
			myElement = (WebElement)createSWPUIPage.executeJavaScript(
					"return document.querySelector(\"#program > wf-radio-option:nth-child(3)\").shadowRoot.querySelector(\"button\")");
			myElement.click();
			Thread.sleep(2000);
			myElement = createSWPUIPage.findElementByDynamicXpath("//brml-button[@variant='primary']");
			myElement.click();
		}
		catch(Exception e) 
    	{
			Assert.fail("Unable to access Strategy");
    	}
    }
    
    @And("^Edit all the below drop down fields of (.+) with \"([^\"]*)\" data of Create SWPAAP Strategy flow$")
    public void edit_all_the_below_drop_down_fields_of_with_something_data_of_create_swpaap_strategy_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
	    {
    		createSWPUIPage.editDropDownFields(entity, strArg1, attribute);
	    }
	    
    @Then("^Edit all the below input fields of (.+) with \"([^\"]*)\" data of Create SWPAAP Strategy flow$")
    public void edit_all_the_below_input_fields_of_with_something_data_of_create_swpaap_strategy_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
	{
   		createSWPUIPage.editInputFields(entity, strArg1, attribute);
    }

    @And("^Edit all the below check boxes of (.+) with \"([^\"]*)\" data of Create SWPAAP Strategy flow$")
    public void edit_all_the_below_check_boxes_of_with_something_data_of_create_swpaap_strategy_flow(String entity, String strArg1,List<List<String>> attribute) throws Throwable
    {
    	createSWPUIPage.editCheckBox(entity, strArg1, attribute);
    }
	   
    @And("^Store all the below feilds values of Enter Details Page for Create SWPAAP Strategy flow$")
    public void store_all_the_below_feilds_values_of_enter_details_page_for_create_swpaap_strategy_flow(List<List<String>> attribute) throws Throwable
    {
    	createSWPUIPage.storeValuesDetailsPage(attribute);
    }
    
    @Then("^Store all the below fields of Benchmark Page for Create SWPAAP Strategy flow$")
    public void store_all_the_below_fields_of_benchmark_page_for_create_swpaap_strategy_flow(List<Map<String,String>> attribute) throws Throwable
    {
    	createSWPUIPage.storeBenchmarkDetails(attribute);
    }
    
    @And("^Store all the below checkbox values of Enter Details Page for Create SWPAAP Strategy flow$")
    public void store_all_the_below_checkbox_values_of_enter_details_page_for_create_swpaap_strategy_flow(List<List<String>> attribute) throws Throwable
    {
    	createSWPUIPage.storeCheckBoxDeatilsPage(attribute);
    }
    
    @Then("^Store all the below fields of Proxy Page for Create SWPAAP Strategy flow$")
    public void store_all_the_below_fields_of_proxy_page_for_create_swpaap_strategy_flow(List<List<String>> attribute) throws Throwable
    {
    	createSWPUIPage.storeProxyDetails(attribute);
    }
    
    @Then("^Store all the fields of Documents Page for Create SWPAAP Strategy flow$")
    public void store_all_the_fields_of_documents_page_for_create_swpaap_strategy_flow() throws Throwable
    {
    	createSWPUIPage.storeDocumentsDetails();
    }
	    
    @Then("^Store all the fields of Comments Page for Create SWPAAP Strategy flow$")
    public void store_all_the_fields_of_comments_page_for_create_swpaap_strategy_flow() throws Throwable
    {
    	createSWPUIPage.storeCommentsDetails();
    }
    
    @Then("^Check if all the edits made to the input feilds for (.+) are reflected on View page of Create flow$")
    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_view_page_of_create_flow(String entity) throws Throwable
    {
    	createSWPUIPage.checkInputEdits();
    }
    
    @Then("^Check if all the edits made to the Benchmark feilds for (.+) are reflected on View page of Create flow$")
    public void check_if_all_the_edits_made_to_the_benchmark_feilds_for_are_reflected_on_view_page_of_create_flow(String entity) throws Throwable
    {
    	createSWPUIPage.checkBenchmarkEdits();
    }
    
    @Then("^Check if all the edits made to the input and text feilds on Proxy Details page are reflected on View page of Create flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_proxy_details_page_are_reflected_on_view_page_of_create_flow() throws Throwable
    {
    	createSWPUIPage.checkProxyEdits();
    }
    
    @Then("^Check if all the edits made to the input and text feilds on Documents page are reflected on View page of Create flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_documents_page_are_reflected_on_view_page_of_create_flow() throws Throwable
    {
    	createSWPUIPage.checkDocumentEdits();
    }
    
    @Then("^Check if all the edits made to the input and text feilds on Comments page are reflected on View page of Create flow$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_comments_page_are_reflected_on_view_page_of_create_flow() throws Throwable
    {
    	createSWPUIPage.checkCommentsEdits();
    }
    
    @And("^Check if all the edits made to the input and text feilds for (.+) match with the DB of Create flow for \"([^\"]*)\"$")
    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_for_match_with_the_db_of_create_flow_for_something(String entity, String strArg1) throws Throwable 
    {
    	createSWPUIPage.DBRetriveSC1(entity,strArg1);
    }
    

    @And("^Check if all the edits made to the Benchmark feilds for (.+) match with the DB of Create flow$")
    public void check_if_all_the_edits_made_to_the_benchmark_feilds_for_match_with_the_db_of_create_flow(String entity) throws Throwable
    {
    	createSWPUIPage.DBRetriveSC2(entity);
    }
    
    @And("^Check if all the edits made to the Proxy Details feilds for (.+) match with the DB of Create flow$")
    public void check_if_all_the_edits_made_to_the_proxy_details_feilds_for_match_with_the_db_of_create_flow(String entity) throws Throwable 
    {
    	createSWPUIPage.DBProxyCheck();
    }
    
    @And("^Check if all the edits made to the Documents Details feilds for (.+) match with the DB of Create flow$")
    public void check_if_all_the_edits_made_to_the_documents_details_feilds_for_match_with_the_db_of_create_flow(String entity) throws Throwable
    {
    	createSWPUIPage.DBRetriveSC3(entity);
    }
    
    @And("^Check if all the edits made to the Comments Details feilds for (.+) match with the DB of Create flow$")
    public void check_if_all_the_edits_made_to_the_comments_details_feilds_for_match_with_the_db_of_create_flow(String entity) throws Throwable
    {
    	createSWPUIPage.DBRetriveSC4(entity);
    }
    
    @And("^User stores the generated FOA code in excel on Create flow$")
    public void user_stores_the_generated_foa_code_in_excel_on_create_flow() throws Throwable
    {
    	try 
    	{    		
    		myValue1 = (String)createSWPUIPage.executeJavaScript("return document.querySelector(\"h6\").textContent");			
			System.out.println(myValue1);
			myValue1 = myValue1.substring(myValue1.trim().length() - 4 ).trim();
			
			System.out.println(myValue1);

			
			if(myValue1 != null)
			{
				createSWPUIPage.writeIntoExcel("SMASingleSWPAAP", "SearchCode2", myValue1);
			}
		}
		catch(Exception e) 
    	{
    		Assert.fail("Unable to access the FOA Code");
    	}
    }
    
    @When("^User searches with the (.+) taken from (.+) in the Search TextBox with \"([^\"]*)\" for Create flow$")
    public void user_searches_with_the_taken_from_in_the_search_textbox_with_something_for_create_flow(String searchcode, String entity, String strArg1) throws Throwable
    {
		createSWPUIPage.globalSearch(searchcode, entity, strArg1);
    }
    

    @Then("^User clicks on the suggestion which matches with (.+) and (.+) search token for Create flow with \"([^\"]*)\"$")
    public void user_clicks_on_the_suggestion_which_matches_with_and_search_token_for_create_flow_with_something(String searchcode, String entity, String strArg1) throws Throwable 
    {
    	createSWPUIPage.clickMatchingSuggestion(searchcode,entity,strArg1);
    }
    
    public void scroll_to_bottom() throws Throwable
	{
		try 
		{
			Object lastHeight = (Object)action.executeJavaScript("return document.body.scrollHeight");
			while(true) 
			{
				Action.scrollToBottom();
				Thread.sleep(5000);
				Object newHeight = (Object)action.executeJavaScript("return document.body.scrollHeight");
				
				if(newHeight.equals(lastHeight)) 
				{
					break;
				}
				lastHeight = newHeight;
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}
	   
   
	    @Then("^Connect with DataBase to get search code for (.+) on Create SWPAAP Strategy flow$")
	    public void connect_with_database_to_get_search_code_for_on_create_swpaap_strategy_flow(String entity) throws Throwable
	    {
	    	createSWPUIPage.DBRetriveSearchCode(entity);
	    }
	    
	    @Then("^User searches with the Access FOA code for Create SWPAAP Strategy flow$")
	    public void user_searches_with_the_access_foa_code_for_create_swpaap_strategy_flow() throws Throwable
	    {
	    	createSWPUIPage.searchAccessFOACode();
	    }
	    
	    @Then("^Check if all the edits made to the input and text feilds for (.+) are reflected on Create flow$")
	    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_for_are_reflected_on_create_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	createSWPUIPage.checkInputEditsOnEnterDetailsPage(entity,attribute);
	    }
	    
	    @Then("^Check if all the edits made to the drop down feilds for (.+) are reflected on Enter Details page of Create flow$")
	    public void check_if_all_the_edits_made_to_the_drop_down_feilds_for_are_reflected_on_enter_details_page_of_create_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	createSWPUIPage.checkDropdownEditsOnEnterDetailsPage(entity,attribute);
	    }
	    
	    @Then("^Check if all the edits made to the check box feilds for (.+) are reflected on Enter Details page of Create flow$")
	    public void check_if_all_the_edits_made_to_the_check_box_feilds_for_are_reflected_on_enter_details_page_of_create_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	createSWPUIPage.checkCheckBoxEditsOnUpdatePage(entity, attribute);
	    }

	    @Then("^Check if all the edits made the below fields of Benchmark Page for (.+) are reflected on Create flow$")
	    public void check_if_all_the_edits_made_the_below_fields_of_benchmark_page_for_are_reflected_on_create_flow(String entity,List<Map<String,String>> attribute) throws Throwable
	    {
	    	createSWPUIPage.checkBenchmarkEditsOnUpdateFlow(entity, attribute);
	    }
	    
	    @Then("^Check if all the edits made to the input feilds for (.+) are reflected on Proxy Page of Create flow$")
	    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_proxy_page_of_create_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	createSWPUIPage.checkProxyEditsOnUpdatePage(attribute);
	    }
	    
	    @Then("^Check if all the edits made to the input feilds for (.+) are reflected on Documents Page of Create flow$")
	    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_documents_page_of_create_flow(String entity) throws Throwable
	    {
	    	createSWPUIPage.checkDocumentEditsOnUpdatePage();
	    }
	    
	    @Then("^Check if all the edits made to the input feilds for (.+) are reflected on Comments Page of Create flow$")
	    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_comments_page_of_create_flow(String entity) throws Throwable
	    {
	    	createSWPUIPage.checkCommentsEditsOnUpdatePage();
	    }
	    

	    @Then("^User waits for the suggestion which matches with (.+) search token with \"([^\"]*)\" for Create flow$")
	    public void user_waits_for_the_suggestion_which_matches_with_search_token_with_something_for_create_flow(String entity, String strArg1) throws Throwable
	    {
	    	createSWPUIPage.waitMatchingSuggestion(entity);
	    }
	    
	    @And("^User should be able to \"([^\"]*)\" details of the (.+) taken from (.+) using the column \"([^\"]*)\" with \"([^\"]*)\" for Create flow$")
	    public void user_should_be_able_to_something_details_of_the_taken_from_using_the_column_something_with_something_for_create_flow(String option, String searchCode,  String entity, String columnName,String strArg1) throws Throwable
	    {

	    	try
	    	{
	        	createSWPUIPage.viewEdit(entity, searchCode, columnName, option);
	    		
	    	}
	    	catch (Exception e) 
	    	{
	    		Assert.fail("Unable to access global search Results");
	    	}    
	    }
	    
	    @And("^Click on Edit link to jump to \"([^\"]*)\" page of Create flow$")
	    public void click_on_edit_link_to_jump_to_something_page_of_create_flow(String strArg1) throws Throwable
	    {
	    	try
	    	{
	        	createSWPUIPage.clickEditLink(strArg1);
	    	}
	    	catch (Exception e) 
	    	{
	    		Assert.fail("Unable to access Edit link");
	    	}		    
	    }
	    
	    @And("^Apply the Assertion for Create flow$")
	    public void apply_the_assertion_for_create_flow() throws Throwable
	    {
	    	createSWPUIPage.SoftAssertion();
	    }
	    
	}