package qa.unicorn.ad.productmaster.webui.stepdefs;
import cucumber.api.java.en.Then;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.framework.utils.Action;

public class BenchmarkConfirmationPageStepDef {
	
	PMPageGeneric benconfirmation = new PMPageGeneric("AD_PM_BenchmarkConfirmationPage");
	Action action;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	

	CreateBenchmarkConfirmationPage con=new CreateBenchmarkConfirmationPage("AD_PM_CreateBenchmarkConfirmationPage");
	
	@Then("^User should be able to see the below fields on Create Benchmark Confirmation page$")
    public void user_should_be_able_to_see_the_below_fields_on_create_manager_confirmation_page(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			con.verifyElementsoncreatebenchmarkconfirmationpage(
					con.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
    }
	
	
	@And("^User clicks on the \"([^\"]*)\" on Benchmark Confirmation Page$")
    public void user_clicks_on_the_something_on_benchmark_confirmation_page(String key) throws Throwable {
		benconfirmation.clickOnLink(key);
		Reporter.addScreenCapture();
    }
	@Then("^User should be able to see the \"([^\"]*)\" on Benchmark Confirmation page$")
    public void user_should_be_able_to_see_the_something_on_benchmark_confirmation_page(String Key) throws Throwable {
		Thread.sleep(1000);
		benconfirmation.verifyElement(Key);
    	Thread.sleep(2000);
    	Reporter.addScreenCapture();
    }
	@And("^User clicks on the (.+) attributes on Create New Benchmark Confirmation Page$")
    public void user_clicks_on_the_attributes_on_create_new_benchmark_confirmation_page(String elementKey) throws Throwable {
        con.clickOntheelementsoncreatebenchmarkconfirmationpage(elementKey);
    }
	@Then("^User should be able to see the Confirmation Header on Create New Benchmark Confirmation page$")
    public void user_should_be_able_to_see_the_confirmation_header_on_create_new_benchmark_confirmation_page() throws Throwable {
		con.verifyconfirmationheaderinCreateStyleConfPage();
    }
	@Then("^User should be able to see the below fields on Create New Benchmark Confirmation page$")
    public void user_should_be_able_to_see_the_below_fields_on_create_new_benchmark_confirmation_page(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			con.verifyElementsoncreatebenchmarkconfirmationpage(
					con.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
    }
}
