package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdatePMPStrategyEnterStrategyDetailsPage;

public class GlobalSearchStepDefnition {

	LandingPage lp = new LandingPage("AD_PM_LandingPage");
	UpdatePMPStrategyEnterStrategyDetailsPage UPESDP = new UpdatePMPStrategyEnterStrategyDetailsPage(
			"AD_PM_updatePMPStrategyEnterStrategyDetailsPage");

	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/GlobalSearchUI.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError;
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();

	@When("^User search with the (.+) in the Search TextBox on PM landing page$")
	public void user_search_with_the_in_the_search_textbox_on_landing_page(String searchtoken) throws Throwable {
		if (searchtoken.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + searchtoken);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, searchtoken);

		String searchToken = (String) exlObj.getCellData(sheet, rowIndex, 1);

		exlObj.closeWorkBook();

		if (searchToken != "") {
			lp.enterSearchToken(searchToken);
		}
	}

	@When("^User search with the (.+) with less than a minimum of 3 alphanumeric characters in the Search TextBox$")
	public void user_search_with_the_with_less_than_a_minimum_of_3_alphanumeric_characters_in_the_search_textbox_on_pm_landing_page(
			String searchtoken4) throws Throwable {
		if (searchtoken4.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + searchtoken4);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, searchtoken4);

		String searchToken4 = (String) exlObj.getCellData(sheet, rowIndex, 1);

		exlObj.closeWorkBook();

		if (searchToken4 != "") {
			lp.enterSearchToken(searchToken4);
		}
	}

	@Then("^User search with the (.+) with a minimum of 3 alphanumeric characters in the Search TextBox$")
	public void user_search_with_the_with_a_minimum_of_3_alphanumeric_characters_in_the_search_textbox_on_pm_landing_page(
			String searchtoken5) throws Throwable {
		if (searchtoken5.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + searchtoken5);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, searchtoken5);

		String searchToken5 = (String) exlObj.getCellData(sheet, rowIndex, 1);

		exlObj.closeWorkBook();

		if (searchToken5 != "") {
			lp.enterSearchToken(searchToken5);
		}
	}

	@And("^User clicks on Global Search Icon inside PM landing page$")
	public void user_clicks_on_global_search_icon_inside_landing_page() throws Throwable {
		lp.clickOnSearchIcon();
	}

	@When("^User clicks on SEE ALL RESULTS button on PM landing page$")
	public void user_clicks_on_see_all_results_button_on_landing_page() throws Throwable {
		lp.clickOnSeeAllResultsButton();
	}

	@Then("^user should be able to see all search results in all results tab$")
	public void user_should_be_able_to_see_all_search_results_in_all_results_tab() throws Throwable {
		lp.verifyUserIsOSeeAllResultsTab();
	}

	@When("^User clicks on Cancel button on view page of searched entity$")
	public void user_clicks_on_cancel_button_on_view_page_of_searched_entity() throws Throwable {
		lp.clickOnStyleViewCancelButton();
	}

	@And("^User clicks on style tab on PM landing page$")
	public void user_clicks_on_style_tab_on_pm_landing_page() throws Throwable {
		lp.clickOnStyleTab();
	}

	@Then("^User should be able to see desired search result in style tab flyout page$")
	public void user_should_be_able_to_see_desired_search_result_in_style_tab_flyout_page() throws Throwable {
		lp.clickOnStyleGridEllipsesIcon();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User clicks on PMP tab on PM landing page$")
	public void user_clicks_on_pmp_tab_on_pm_landing_page() throws Throwable {
		lp.clickOnPMPTab();
	}

	@Then("^User should be able to see desired search result in PMP tab flyout page$")
	public void user_should_be_able_to_see_desired_search_result_in_pmp_tab_flyout_page() throws Throwable {
		lp.clickOnStyleGridEllipsesIcon();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User clicks on Benchmark tab on PM landing page$")
	public void user_clicks_on_benchmark_tab_on_pm_landing_page() throws Throwable {
		lp.clickOnBenchmarkTab();
	}

	@Then("^User should be able to see desired search result in Benchmark tab flyout page$")
	public void user_should_be_able_to_see_desired_search_result_in_benchmark_tab_flyout_page() throws Throwable {
		lp.clickOnStyleGridEllipsesIcon();
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User should be able to see View Benchmark header$")
	public void user_should_be_able_to_see_view_benchmark_header() throws Throwable {
		lp.verifyUserIsOnViewBenchmarkPage();
	}

	@And("^User clicks on SMA tab on PM landing page$")
	public void user_clicks_on_sma_tab_on_pm_landing_page() throws Throwable {
		lp.clickOnSMATab();
	}

	@Then("^User should be able to see desired search result in SMA flyout page$")
	public void user_should_be_able_to_see_desired_search_result_in_sma_flyout_page() throws Throwable {
		lp.clickOnStyleGridEllipsesIcon();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User clicks on FA tab on PM landing page$")
	public void user_clicks_on_fa_tab_on_pm_landing_page() throws Throwable {
		lp.clickOnFATab();
	}

	@Then("^User should be able to see desired search result in FA tab flyout page$")
	public void user_should_be_able_to_see_desired_search_result_in_fa_tab_flyout_page() throws Throwable {
		lp.clickOnStyleGridEllipsesIcon();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User clicks on Manager tab on PM landing page$")
	public void user_clicks_on_manager_tab_on_pm_landing_page() throws Throwable {
		lp.clickOnManagerTab();
	}

	@Then("^User should be able to see View PMP header$")
	public void user_should_be_able_to_see_view_pmp_header() throws Throwable {
		lp.verifyUserIsOnViewPMPPage();
	}

	@Then("^User should be able to see View FA header$")
	public void user_should_be_able_to_see_view_fa_header() throws Throwable {
		lp.verifyUserIsOnViewFAPage();
	}

	@Then("^User should be able to see View Manager header$")
	public void user_should_be_able_to_see_view_manager_header() throws Throwable {
		lp.verifyUserIsOnViewManagersPage();
	}

	@Then("^user should be able to see All the results should contain the (.+) in it in Global Search Page under all results tab$")
	public void user_should_be_able_to_see_all_the_results_should_contain_the_in_it_in_global_search_page_under_all_results_tab(
			String searchtoken) throws Throwable {
		lp.verifyUserIsOSeeAllResultsTab();
		lp.collapseallpanelsonSeeAllResultsTab();
	}

	@Then("^User should be able to see No Results Found message on the landing screen$")
	public void user_should_be_able_to_see_no_results_found_message_on_the_landing_screen() throws Throwable {
		lp.verifyNoResultsFoundMessage();
	}

	@When("^User is on PM landing page$")
	public void user_is_on_pm_landing_page() throws Throwable {
		lp.verifyProductMasterheaderonlandingpage();
	}

	@Then("^User should be able to verify the display of count of all tabs present in PM landing page on searching with (.+)$")
	public void user_should_be_able_to_verify_the_display_of_count_of_all_tabs_present_in_pm_landing_page_on_searching_with_and(
			String tagvalue) throws Throwable {
		if (tagvalue.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + tagvalue);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, tagvalue);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.verifyCountOfAllTabsPresentOnLandingPage(tagvalue1);

		}
	}

	@When("^User inputs desired fateam attribute (.+) in global search$")
	public void user_inputs_desired_fateam_attribute_in_global_search(String fateamattribute) throws Throwable {
		if (fateamattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + fateamattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, fateamattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}

	}

	@When("^User inputs desired fa attribute (.+) in global search$")
	public void user_inputs_desired_fa_attribute_in_global_search(String faattribute) throws Throwable {
		if (faattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + faattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, faattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired fa attribute (.+) in global search with any status$")
	public void user_inputs_desired_fa_attribute_in_global_search_with_any_status(String faattribute) throws Throwable {
		if (faattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + faattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, faattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired invalid FA ID(.+) in global search$")
	public void user_inputs_desired_invalid_fa_id_in_global_search(String faattribute) throws Throwable {
		if (faattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + faattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, faattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired Style attribute (.+) in global search$")
	public void user_inputs_desired_style_attribute_in_global_search(String styleattribute) throws Throwable {
		if (styleattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + styleattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, styleattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired Manager attribute (.+) in global search$")
	public void user_inputs_desired_manager_attribute_in_global_search(String managerattribute) throws Throwable {
		if (managerattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + managerattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, managerattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired MF attribute (.+) in global search$")
	public void user_inputs_desired_mf_attribute_in_global_search(String mfattribute) throws Throwable {
		if (mfattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + mfattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mfattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}

	}

	@When("^User inputs desired ETF attribute (.+) in global search$")
	public void user_inputs_desired_etf_attribute_in_global_search(String etfattribute) throws Throwable {
		if (etfattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + etfattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, etfattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired PMP Strategy attribute (.+) in global search$")
	public void user_inputs_desired_pmp_strategy_attribute_in_global_search(String pmpstrategyattribute)
			throws Throwable {
		if (pmpstrategyattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + pmpstrategyattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, pmpstrategyattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired SMA Single Access strategy attribute (.+) in global search$")
	public void user_inputs_desired_sma_single_access_strategy_attribute_in_global_search(
			String smasingleaccessstrategyattribute) throws Throwable {
		if (smasingleaccessstrategyattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + smasingleaccessstrategyattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, smasingleaccessstrategyattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired SMA Dual MAC Strategy attribute (.+) in global search$")
	public void user_inputs_desired_sma_dual_mac_strategy_attribute_in_global_search(String smadualmacstrategyattribute)
			throws Throwable {
		if (smadualmacstrategyattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + smadualmacstrategyattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, smadualmacstrategyattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired SMA SWP Strategy attribute (.+) in global search$")
	public void user_inputs_desired_sma_swp_strategy_attribute_in_global_search(String smaswpaapstrategyattribute)
			throws Throwable {
		if (smaswpaapstrategyattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + smaswpaapstrategyattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, smaswpaapstrategyattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired benchmark attribute (.+) in global search$")
	public void user_inputs_desired_benchmark_attribute_in_global_search(String benchmarkattribute) throws Throwable {
		if (benchmarkattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + benchmarkattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, benchmarkattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User inputs desired searchtoken attribute (.+) in global search$")
	public void user_inputs_desired_searchtoken_attribute_in_global_search(String searchtokenattribute)
			throws Throwable {
		if (searchtokenattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + searchtokenattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, searchtokenattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}

	}

	@And("^User clicks on search icon in PM landing page$")
	public void user_clicks_on_search_icon_in_pm_landing_page() throws Throwable {
		lp.clickOnSearchIcon();
	}

	@Then("^User should be able to see desired search result in global flyout$")
	public void user_should_be_able_to_see_desired_search_result_in_global_flyout() throws Throwable {
		lp.verifySeeAllResultsButton();
		lp.clickOnSeeAllResultsButton();
		lp.verifyUserIsOSeeAllResultsTab();
	}

	@When("^User enter valid keyword (.+) for any entity$")
	public void user_enter_valid_keyword_for_any_entity(String resultsentityattribute) throws Throwable {
		if (resultsentityattribute.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + resultsentityattribute);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, resultsentityattribute);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@When("^User enter invalid keyword (.+) for any entity$")
	public void user_enter_invalid_keyword_for_any_entity(String resultsentityattribute2) throws Throwable {
		if (resultsentityattribute2.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("TagValue : " + resultsentityattribute2);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, resultsentityattribute2);

		String tagvalue1 = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("tagvalue1= " + tagvalue1);

		exlObj.closeWorkBook();

		if (tagvalue1 != "") {
			lp.enterSearchToken(tagvalue1);

		}
	}

	@Then("^User should see that Results header in Search Popup as \"([^\"]*)\" format$")
	public void user_should_see_that_results_header_in_search_popup_as_something_format(String strArg1)
			throws Throwable {
		lp.compareSearchResultsFormat(strArg1);
	}

	@Then("^User should see that Results header in Search Popup as \"([^\"]*)\" format2$")
	public void user_should_see_that_results_header_in_search_popup_as_something_format2(String strArg1)
			throws Throwable {
		lp.compareSearchResultsFormat2(strArg1);
	}

	@Then("^User should be able to see only latest maximum 5 records in Global search flyout of the landing page$")
	public void user_should_be_able_to_see_only_latest_maximum_5_records_in_global_search_flyout_of_the_landing_page()
			throws Throwable {
		lp.verifyLatestMaximum5records();
	}

	@Then("^User should be able to go to the details page on clicking on any of the result$")
	public void user_should_be_able_to_go_to_the_details_page_on_clicking_on_any_of_the_result() throws Throwable {
		lp.clickOnSearchedResultNavigatetoDetailsPage();
		lp.verifyContinueEditingButton();
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User should be able to see the style in the following format \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_style_in_the_following_format_something_something_something(
			String strArg1, String strArg2, String strArg3) throws Throwable {
		lp.compareStyleGlobalSearchResultsFormat(strArg1, strArg2, strArg3);
	}

	@Then("^User should be able to see the manager in the following format \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_manager_in_the_following_format_something_something_something(
			String strArg1, String strArg2, String strArg3) throws Throwable {
		lp.compareManagerGlobalSearchResultsFormat(strArg1, strArg2, strArg3);
	}

	@Then("^User should be able to see the benchmark in the following format \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_benchmark_in_the_following_format_something_something_something(
			String strArg1, String strArg2, String strArg3) throws Throwable {
		lp.compareBenchmarkGlobalSearchResultsFormat(strArg1, strArg2, strArg3);
	}

	@Then("^User should be able to see the benchmark in the following format \"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_benchmark_in_the_following_format_something(String strArg1)
			throws Throwable {
		lp.compareProgramGlobalSearchResultsFormat(strArg1);
	}

	@Then("^User should be able to see the financial advisor in the following format \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_financial_advisor_in_the_following_format_something_something_something(
			String strArg1, String strArg2, String strArg3) throws Throwable {
		lp.compareFAGlobalSearchResultsFormat(strArg1, strArg2, strArg3);
	}

	@Then("^User should be able to see the PMP Strategy in the following format \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_pmp_strtaegy_in_the_following_format_something_something_something(
			String strArg1, String strArg2, String strArg3) throws Throwable {
		lp.comparePMPStrategyGlobalSearchResultsFormat(strArg1, strArg2, strArg3);
	}

	@Then("^User should be able to see the SMA Strategy in the following format \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_sma_strategy_in_the_following_format_something_something_something(
			String strArg1, String strArg2, String strArg3) throws Throwable {
		lp.compareSMAStrategyGlobalSearchResultsFormat(strArg1, strArg2, strArg3);
	}

	@When("^User clicks on Continue Editing button on View page of searched entity$")
	public void user_clicks_on_continue_editing_button_on_view_page_of_searched_entity() throws Throwable {
		lp.clickOnStyleViewEditButton();
	}

	@Then("^User should be able to see enter Strategy details header$")
	public void user_should_be_able_to_see_enter_strategy_details_header() throws Throwable {
		UPESDP.isUserOnEnterStrategyDetailsPage();
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User should be able to see the results count and search results in global search flyout$")
	public void user_should_be_able_to_see_the_results_count_and_search_results_in_global_search_flyout()
			throws Throwable {
		lp.highlightSearchResultsFormat();
		lp.clickOnDisplayedFirstSearchResult();
	}

	@And("^User should be able to verify the \"([^\"]*)\" headers displayed under Style tab$")
	public void user_should_be_able_to_verify_the_something_headers_displayed_under_style_tab(String key,
			List<String> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			System.out.println("Key=" + key);
			Reporter.addStepLog("verifying for " + items.get(i));
			lp.verifyStyleTabHeaders(key, items.get(i));
		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to verify the \"([^\"]*)\" headers displayed under PMP tab$")
	public void user_should_be_able_to_verify_the_something_headers_displayed_under_pmp_tab(String key,
			List<String> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			System.out.println("Key=" + key);
			Reporter.addStepLog("verifying for " + items.get(i));
			lp.verifyPMPTabHeaders(key, items.get(i));
		}
		Reporter.addScreenCapture();

	}

	@Then("^User should be able to verify the \"([^\"]*)\" headers displayed under SMA tab$")
	public void user_should_be_able_to_verify_the_something_headers_displayed_under_sma_tab(String key,
			List<String> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			System.out.println("Key=" + key);
			Reporter.addStepLog("verifying for " + items.get(i));
			lp.verifySMATabHeaders(key, items.get(i));
		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to verify the \"([^\"]*)\" headers displayed under Manager tab$")
	public void user_should_be_able_to_verify_the_something_headers_displayed_under_manager_tab(String key,
			List<String> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			System.out.println("Key=" + key);
			Reporter.addStepLog("verifying for " + items.get(i));
			lp.verifyManagerTabHeaders(key, items.get(i));
		}
		Reporter.addScreenCapture();
	}

	@And("^User verifies fa status on View FA details Page$")
	public void user_verifies_fa_status_on_view_fa_details_page() throws Throwable {
		lp.verifyFAStatusonViewFADetailsPage();
	}

	@Then("^User should be able to see Enter Financial Advisor Details header$")
	public void user_should_be_able_to_see_enter_financial_advisor_details_header() throws Throwable {
		lp.verifyEnterFinancialAdvisorDetailsheader();
	}

	@Then("^User should not be able to see \"([^\"]*)\" option in dropdown$")
	public void user_should_not_be_able_to_see_something_option_in_dropdown(String managerOptionHidden)
			throws Throwable {
		lp.isManagerOptionHidden(managerOptionHidden);
	}

	@Then("^User should be able to see desired search result in Manager tab flyout page$")
	public void user_should_be_able_to_see_desired_search_result_in_manager_tab_flyout_page() throws Throwable {
		lp.clickOnStyleGridEllipsesIcon();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User should be able to see that Continue Editing button is hidden & restricted from updating the searched manager entity$")
	public void user_should_be_able_to_see_that_continue_editing_button_is_hidden_restricted_from_updating_the_searched_manager_entity()
			throws Throwable {
		lp.isContinueEditingButtonHidden();
	}

}
