package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class CreateStyleFlyoutStepDef {
	
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	List<String> listOfString ;
	Action action;
	Alert alert;
	Select dropdown;
	PMPageGeneric CreateStyleFlyout = new PMPageGeneric("AD_PM_CreateStyleFlyout");
	@And("^User should be able to go to the Create Style Flyout$")
	public void user_should_be_able_to_go_to_the_create_style_flyout() throws Throwable {
		String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		CreateStyleFlyout.verifyElement("Create New Style Header");
		Reporter.addStepLog("Able to go to Create StyleFlyout");
		Reporter.addScreenCapture();
	}
	
	@Then("^User should be able to go back to the Create Style Flyout$")
    public void user_should_be_able_to_go_back_to_the_create_style_flyout() throws Throwable {
		CreateStyleFlyout.verifyElement("Create New Style Header");
		Reporter.addStepLog("Able to go to Create StyleFlyout");
    }

	@Then("^User should be able to see the \"([^\"]*)\" on Create Style Flyout$")
	public void user_should_be_able_to_see_the_something_on_create_style_flyout(String key) throws Throwable {
		CreateStyleFlyout.verifyElement(key);
	}

	@Then("^User should be able to see the bottom-border below \"([^\"]*)\" headers on Create Style Flyout$")
	public void user_should_be_able_to_see_the_bottomborder_below_something_headers_on_create_new_style_flyout(
			String strArg1) throws Throwable {
			
	}

	@Then("^User should be able to see the following fields with \"([^\"]*)\" symbol on Create Style Flyout$")
    public void user_should_be_able_to_see_the_following_text_fields_with_something_symbol_on_create_style_flyout(String attribute,List<String> entity) throws Throwable {
        for(int i =0;i<entity.size();i++) {
        	myElement = CreateStyleFlyout.findElementByDynamicXpath("//*[@label="+entity.get(i)+"] ");
        	CreateStyleFlyout.verifyAttribute("true", myElement, attribute);
        }
        
    }

    
	@Then("^user should be able to see the below attributes on Create Style flyout$")
	public void user_should_be_able_to_see_the_below_attributes_on_create_style_flyout(List<String> entity) throws Throwable {
		for(int i =0;i<entity.size();i++) {
		CreateStyleFlyout.verifyElement(CreateStyleFlyout.findElementByDynamicXpath("//*[@label='"+entity.get(i)+"']"));
		Reporter.addStepLog("able to see "+entity.get(i)+" header");
		}
		Reporter.addScreenCapture();
	}

	@Then("^the attributes on Create Style Flyout should contain all of the below following values$")
	public void the_attributes_on_create_style_flyout_should_contain_all_of_the_below_following_values(List<List<String>> entityValuePair)
			throws Throwable {	
		for(int i=0;i<entityValuePair.size();i++) {
			String[] listOfValues ;
			listOfString = new ArrayList<String>();
			listOfValues = entityValuePair.get(i).get(1).split(",");
			listOfElements = CreateStyleFlyout.findElementsByDynamicXpath("//*[@label='"+entityValuePair.get(i).get(0)+"']/wf-select-option");
			
			for(int j=0;j<listOfElements.size();j++) {
				listOfString.add(listOfElements.get(j).getAttribute("name"));
				
			}
			for(int j=0;j<listOfValues.length;j++) {
				Assert.assertTrue(listOfString.contains(listOfValues[j]));
				Reporter.addStepLog("the value "+listOfValues[j]+" is present in "+entityValuePair.get(i).get(0));
			}
			
		}
		
	}

	@Then("^the below attributes on Create Style Flyout should have Yes and No Options in Create Style Flyout$")
	public void the_below_attributes_on_create_style_flyout_should_have_yes_and_no_options_in_create_style_flyout(List<String>entity)
			throws Throwable {
		String[] listOfValues = {"yes","no"};
		for(int i = 0;i<entity.size();i++){
			listOfString = new ArrayList<String>();
			Reporter.addStepLog("//*[@label='"+entity.get(i)+"']/wf-radio-option");
			listOfElements = CreateStyleFlyout.findElementsByDynamicXpath("//*[@label='"+entity.get(i)+"']/wf-radio-option");
			Reporter.addStepLog(Integer.toString(listOfElements.size()));
			Reporter.addStepLog(listOfElements.get(0).getAttribute("value"));
			for(int j=0;j<listOfElements.size();j++) {
				listOfString.add(listOfElements.get(j).getAttribute("value"));
			}
			for(int j=0;j<listOfValues.length;j++) {
				Assert.assertTrue(listOfString.contains(listOfValues[j]));
				Reporter.addStepLog("the value "+listOfValues[j]+" is present in "+entity.get(i));
			}
		}
	}

	@Then("^User should be able the message containing \"([^\"]*)\" below \\\"([^\\\"]*)\\\" on Create Style Flyout$")
	public void user_should_be_able_the_message_containing_something_something_on_create_style_flyout(
			String messageKey, String entity) throws Throwable {
		String message = Action.getTestData(messageKey);
		myElement = CreateStyleFlyout.findElementByDynamicXpath("//*[@label='"+entity+"']/following-sibling::p");
		Assert.assertTrue(myElement.getText().contains(message));
		Reporter.addStepLog("verified the msg "+myElement.getText());
		
	}

	
	
	@And("^User enters the following values in the following text fields on Create Style Flyout$")
    public void user_enters_the_following_values_in_the_following_text_fields_on_create_style_flyout(List<List<String>> entityValuePair) throws Throwable {
		Long time = Calendar.getInstance().getTimeInMillis();
		for(int i=0;i<entityValuePair.size();i++) {
			myElement = CreateStyleFlyout.getDynamicElementFromShadowRoot("return document.querySelector(\"[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('input')");
			
			if(entityValuePair.get(i).get(0).equals("Style Code")) {
        		
				value  = entityValuePair.get(i).get(1)+time;	
        	}
			else {
				value  = entityValuePair.get(i).get(1);
			}
			CreateStyleFlyout.sendKeys(value, myElement);
        	PMPageGeneric.UIPassedValues.put(entityValuePair.get(i).get(0),value);
        }
    }

    @And("^User enters the following values in the following dropdowns on Create Style Flyout$")
    public void user_enters_the_following_values_in_the_following_dropdowns_on_create_style_flyout(List<List<String>> entityValuePair) throws Throwable {
    	for(int i=0;i<entityValuePair.size();i++) {
    		//Reporter.addStepLog("return document.querySelector(\"[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('button')");
        	myElement = CreateStyleFlyout.getDynamicElementFromShadowRoot("return document.querySelector(\"[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('button')");
        	CreateStyleFlyout.scrollAndClickOnLink(myElement);
        	//Reporter.addStepLog("return document.querySelector(\"[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"li[data-value='\\\""+entityValuePair.get(i).get(1)+"\\\"']\")");
        	CreateStyleFlyout.getDynamicElementFromShadowRoot("return document.querySelector(\"[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"li[data-value='\\\""+entityValuePair.get(i).get(1)+"\\\"']\")").click();
        	PMPageGeneric.UIPassedValues.put(entityValuePair.get(i).get(0),entityValuePair.get(i).get(1));
    	}
    	}

    @And("^User enters the following values in the following radio buttons on Create Style Flyout$")
    public void user_enters_the_following_values_in_the_following_radio_buttons_on_create_style_flyout(List<List<String>> entityValuePair) throws Throwable {
    	Thread.sleep(1000);
    	for(int i=0;i<entityValuePair.size();i++) {
    		if (entityValuePair.get(i).get(1).equals("yes")) {
    			Reporter.addStepLog("return document.querySelector(\"wf-radio[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"wf-tooltip div div button[data-index='0']\")");
    			myElement = CreateStyleFlyout.getDynamicElementFromShadowRoot("return document.querySelector(\"wf-radio[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"wf-tooltip div div button[data-index='0']\")");
    			myElement.click();
    		}
    		else if(entityValuePair.get(i).get(1).equals("no")) {
    			Reporter.addStepLog("return document.querySelector(\"wf-radio[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"wf-tooltip div div button[data-index='1']\")");
    			myElement = CreateStyleFlyout.getDynamicElementFromShadowRoot("return document.querySelector(\"wf-radio[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"wf-tooltip div div button[data-index='1']\")");
    			myElement.click();
    		}
    	}
    	
    }
    
    @And("^User enters the following values in the following date calenders on Create Style Flyout$")
    public void user_enters_the_following_values_in_the_following_date_calenders_on_create_style_flyout(List<String> entityValuePair) throws Throwable {
    	for(int i=0;i<entityValuePair.size();i++) {
    		Reporter.addStepLog("return document.querySelector(\"[label='"+entityValuePair.get(i)+"']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
    		WebElement date=CreateStyleFlyout.getDynamicElementFromShadowRoot("return document.querySelector(\"[label='"+entityValuePair.get(i)+"']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
    		CreateStyleFlyout.scrollAndClickOnLink(date);
    		Reporter.addStepLog("return document.querySelector(\"[label='"+entityValuePair.get(i)+"']\").shadowRoot.querySelectorAll('div.pmu-days div')");
    		listOfElements = CreateStyleFlyout.getDynamicElementsFromShadowRoot("return document.querySelector(\"[label='"+entityValuePair.get(i)+"']\").shadowRoot.querySelectorAll('div.pmu-days div')");
    		   
    		   for (int j=0;j<listOfElements.size();j++) {
    			   if(listOfElements.get(j).getText().equals("22"))
    			   {
    				   listOfElements.get(j).click();
    				   Reporter.addStepLog("clicked on date ");
    				   Reporter.addScreenCapture();
    				   break;
    			   }
    		   }
    	}
    }

    @And("^User clicks on \"([^\"]*)\" on Create Style Flyout$")
    public void user_clicks_on_something_on_create_style_flyout(String key) throws Throwable {
        CreateStyleFlyout.clickOnLink(key);
        
    }

    
    
    @Then("^User should be able to the \"([^\"]*)\" with the same value as selected in the dropdown in the wizard$")
    public void user_should_be_able_to_the_something_with_the_same_value_as_selected_in_the_dropdown_in_the_wizard(String key) throws Throwable {
        Assert.assertEquals(PMPageGeneric.storeForUse, CreateStyleFlyout.getElementFromShadowRoot(key).getText());
        
    }
    
    @Then("^User checks the \"([^\"]*)\" for the following attributes on Create Style Flyout$")
    public void user_checks_the_something_for_the_following_attributes_on_create_style_flyout(String attribute,List<List<String>>entityValuePair) throws Throwable {
       for (int i=0;i<entityValuePair.size();i++) {
    	value = CreateStyleFlyout.findElementByDynamicXpath("//*[@label='"+entityValuePair.get(i).get(0)+"']").getAttribute(attribute);
       Assert.assertEquals(entityValuePair.get(i).get(1), value);
       }
    }
    
    @And("^User enters the \"([^\"]*)\" in the \"([^\"]*)\" on Create Style Flyout$")
    public void user_enters_the_something_in_the_something_on_create_style_flyout( String charToSend, String entity) throws Throwable {
        myElement = CreateStyleFlyout.getDynamicElementFromShadowRoot("return document.querySelector(\"[label='"+entity+"']\").shadowRoot.querySelector('input')");
        CreateStyleFlyout.sendKeys(charToSend, myElement);
        Reporter.addStepLog("sent "+charToSend+" to "+entity);
    }
    
    

}
