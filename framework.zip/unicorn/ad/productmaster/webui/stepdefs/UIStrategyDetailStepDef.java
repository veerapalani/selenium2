package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.StrategyDetailPage;


public class UIStrategyDetailStepDef {
	String expectedColorCode;
	String xpath,myValue;
	Boolean myFlag;
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(),20);
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL=SSOLoginPage.URL+"#/strategy/view/";
	WebElement myElement,myElement2;
	StrategyDetailPage strategyDetailPage = new StrategyDetailPage() ;
	PMPageGeneric StrategyDetail=new PMPageGeneric("AD_PM_StrategyDetailPage");
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_StrategyDetailPage"));
    
	@And("^user clicks the Edit Button on Strategy Detail page$")
    public void user_clicks_the_edit_button_on_strategy_detail_page() throws Throwable {
		Thread.sleep(1000);
		strategyDetailPage.waitUntilStrategyCodeVisible();
		action.click(action.getElement("Continue_edit_strategy"));
        Reporter.addStepLog("clicked on the edit button");
        Thread.sleep(5000);
    }
	
	@Then("^User should be able to see the \"([^\"]*)\" header on Strategy Detail page$")
    public void user_should_be_able_to_see_the_something_header_on_strategy_detail_page(String key)  {
        StrategyDetail.scrollToElement(key);
		StrategyDetail.verifyHeader(key);
    }



    @Then("^user should be able to see the following attributes on Strategy Detail page$")
    public void user_should_be_able_to_see_the_following_attributes_on_strategy_detail_page(List<String> attributes){
        listOfElements = StrategyDetail.getElements("Attributes");
       for(int i=0;i<attributes.size();i++)
    	   {
    	   StrategyDetail.verifyTextInListOfElements(attributes.get(i), listOfElements);
    	   Reporter.addStepLog("verified for "+attributes.get(i)+" attribute");
    	   }
    }

    @Then("^The attributes on Strategy Detail page should contain either true or false or blank value$")
    public void the_attributes_on_strategy_detail_page_should_contain_either_true_or_false_or_blank_value(List<String> attributes) {
        String myValue=null;
    	for(int i=0;i<attributes.size();i++) {
    	String xpath="//small[contains(text(),'"+attributes.get(i)+"')]/ancestor::p/following-sibling::input";
    	myElement=StrategyDetail.findElementByDynamicXpath(xpath);
    	myValue=myElement.getAttribute("value");
    	Reporter.addStepLog("The value for "+attributes.get(i)+" is "+myValue);
    	if(myValue.equals("true")||myValue.equals("false")||myValue.equals("")) {
    		Assert.assertTrue(true);
    		StrategyDetail.highlightElement(myElement);
    	}
    	else {
    		Assert.assertFalse(true);
    	}
        }
    	Reporter.addScreenCapture();
    }

    @Then("^The attributes on Strategy Detail page should contain one of the following values$")
    public void the_attributes_on_strategy_detail_page_should_contain_one_of_the_following_values(List<List<String>> attributeValuePair)  {
    	String myValue=null;
    	
    	for(int i=0;i<attributeValuePair.size();i++) {
    		myFlag=false;
    	 xpath="//small[contains(text(),'"+attributeValuePair.get(i).get(0)+"')]/ancestor::p/following-sibling::span";
    	myValue=StrategyDetail.findElementByDynamicXpath(xpath).getText();
    	Reporter.addStepLog("The value for "+attributeValuePair.get(i).get(0)+" is "+myValue);
    	String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
    	for(int j=0;j<listOfValues.length;j++) 
    	if(myValue.equals(listOfValues[j]))
    		{myFlag=true;
    		break;}
    	
    	Assert.assertTrue(myFlag);
    	
        }
    }

    @Then("^The value on Strategy Detail page of the following attributes should be in \"([^\"]*)\" format$")
    public void the_value_on_strategy_detail_page_of_the_following_attributes_should_be_in_something_format(String format,List<String> attributes)  {
    	String myValue=null;
    	for(int i=0;i<attributes.size();i++) {
    	 xpath="//small[contains(text(),'"+attributes.get(i)+"')]/ancestor::p/following-sibling::span";
    	 myElement=StrategyDetail.findElementByDynamicXpath(xpath);
    	 myValue = myElement.getText();
    	Reporter.addStepLog("validating for "+attributes.get(i)+" with value "+myValue);
    	StrategyDetail.highlightElement(myElement);
    	if(!myValue.equals(""))
    	StrategyDetail.verifyFormat(myValue, Action.getTestData(format));
    	
    	}
    	Reporter.addScreenCapture();
    }

   

    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Strategy Detail page$")
    public void something_should_be_displayed_in_something_color_on_strategy_detail_page(String key, String expectedColor) {
    	expectedColorCode = Action.getTestData(expectedColor);
    	StrategyDetail.verifyColor( key,expectedColorCode);
    }
    
    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Strategy Detail page$")
    public void something_should_be_displayed_in_something_color_inside_strategy_detail_page(String key, String expectedColor) throws Throwable {
    	expectedColorCode = Action.getTestData(expectedColor);
    	StrategyDetail.verifyColor( StrategyDetail.getElementFromShadowRoot(key),expectedColorCode);
    }
    
    @And("^\"([^\"]*)\" should have \"([^\"]*)\" background color on Strategy Detail page$")
    public void something_should_have_something_background_color_on_strategy_detail_page(String key, String backgroundColor) {
    	expectedColorCode = Action.getTestData(backgroundColor);
    	StrategyDetail.verifyBackgroundColor(key,expectedColorCode);
    }

    @And("^Format of the \"([^\"]*)\" on Strategy Detail page should be \"([^\"]*)\"$")
    public void format_of_the_something_on_strategy_detail_page_should_be_something(String key, String format) throws Throwable {
    	String myTimeStamp = StrategyDetail.getElement(key).getText().substring(0,19); 
    	Reporter.addStepLog(myTimeStamp);
    	StrategyDetail.verifyFormat(myTimeStamp, Action.getTestData(format));
    }
    
    @Then("^User should be able to see the \"([^\"]*)\" inside Strategy Detail page$")
    public void user_should_be_able_to_see_the_something_inside_strategy_detail_page(String key) throws Throwable {
        StrategyDetail.verifyElement(StrategyDetail.getElementFromShadowRoot(key));
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Strategy Detail page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_inside_strategy_detail_page(String ghostText, String key) throws Throwable {
    	StrategyDetail.verifyGhostText(ghostText, StrategyDetail.getElementFromShadowRoot(key));
    }
    

    
    @And("^User should be able to see the \"([^\"]*)\" on Strategy Detail page$")
    public void user_should_be_able_to_see_the_something_on_strategy_detail_page(String key) throws Throwable {
    	
    	StrategyDetail.verifyElement(key);       
    }

   

    @And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Strategy Detail page$")
    public void that_something_should_be_displayed_in_something_color_on_strategy_detail_page(String strArg1, String expectedColor) {
    	expectedColorCode = Action.getTestData(expectedColor);
    	StrategyDetail.verifyCurrentElementColor(expectedColorCode);
    }
    
    
    
    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Strategy Detail page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_strategy_detail_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
     
    	StrategyDetail.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = StrategyDetail.getElementsFromShadowRoot(key);
   		 Reporter.addStepLog(listOfElements.get(0).getText());
   	 StrategyDetail.verifyTextInListOfElements( items.get(i),listOfElements);  
        }
        
    }

    @And("^user should be able to see the following attributes below \"([^\"]*)\" header on Strategy Detail page$")
    public void user_should_be_able_to_see_the_following_attributes_below_something_header_on_strategy_detail_page(String key,List<String> attributes) {
        listOfElements = StrategyDetail.getElements(key);
        for(int i=0;i<attributes.size();i++)
 	   {
 	   StrategyDetail.verifyTextInElement(attributes.get(i), listOfElements.get(i));
 	   
 	   Reporter.addStepLog("validated for "+attributes.get(i));
 	   }
        
        
    }

    @And("^The text written in \"([^\"]*)\" should match with the value of \"([^\"]*)\" attribute on Strategy Detail page$")
    public void the_text_written_in_something_should_match_with_the_value_of_something_attribute_on_strategy_detail_page(String actualkey, String expectedkey) {
       Assert.assertEquals(StrategyDetail.getText(actualkey), StrategyDetail.getText(expectedkey));
    }

    @And("^user clicks the \"([^\"]*)\" on Strategy Detail page$")
    public void user_clicks_the_something_on_strategy_detail_page(String key) throws Throwable {
        StrategyDetail.clickOnLink(key);
    }
    @Then("^User should be able to see the bottom-border below \"([^\"]*)\" on Strategy Detail page$")
    public void user_should_be_able_to_see_the_bottomborder_below_something_on_strategy_detail_page(String key) throws Throwable {
       String widthInPixel= StrategyDetail.giveCssValue(StrategyDetail.getElement(key), "border-bottom-width");
       String width = widthInPixel.substring(0, widthInPixel.length()-2);
       Assert.assertTrue(Integer.parseInt(width)>0);
    }
    @Then("^User should not be able to see the \"([^\"]*)\" in the \"([^\"]*)\" on Strategy Detail page$")
    public void user_should_not_be_able_to_see_the_something_in_the_something_on_strategy_detail_page(String text, String key) {
    	StrategyDetail.verifyTextNotPresentInListOfElements(text, StrategyDetail.getElements(key));
    	Reporter.addStepLog(text+" is not present");
    	Reporter.addScreenCapture();
    }
    @And("^compare the string values given in API and the values displayed in UI in Strategy Detail page$")
    public void compare_the_string_values_given_in_api_and_the_values_displayed_in_ui_in_strategy_detail_page(List<List<String>> APIUIAttributePair) {
    	 String APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().get(APIUIAttributePair.get(i).get(0));
		  xpath="//small[text()='"+APIUIAttributePair.get(i).get(1)+"']/ancestor::p/following-sibling::span";
		 UIValue=StrategyDetail.findElementByDynamicXpath(xpath).getText();
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+APIValue); 
		 }
		 Reporter.addScreenCapture();
    }

    @And("^compare the numeric values given in API and the values displayed in UI in Strategy Detail page$")
    public void compare_the_numeric_values_given_in_api_and_the_values_displayed_in_ui_in_strategy_detail_page(List<List<String>> APIUIAttributePair) {
    	 float APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().getFloat(APIUIAttributePair.get(i).get(0));
		  xpath="//small[text()='"+APIUIAttributePair.get(i).get(1)+"']/ancestor::p/following-sibling::span";
		 UIValue=Float.parseFloat(StrategyDetail.findElementByDynamicXpath(xpath).getText());
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+APIValue); 
		 }
		 Reporter.addScreenCapture();
    }

    @And("^compare the boolean values given in API and the values displayed in UI in Strategy Detail page$")
    public void compare_the_boolean_values_given_in_api_and_the_values_displayed_in_ui_in_strategy_detail_page(List<List<String>> APIUIAttributePair) {
    	 Boolean APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().getBoolean(APIUIAttributePair.get(i).get(0));
		  xpath="//small[contains(text(),'"+APIUIAttributePair.get(i).get(1)+"')]/ancestor::p/following-sibling::input";
		 UIValue=Boolean.parseBoolean(StrategyDetail.findElementByDynamicXpath(xpath).getAttribute("value"));
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+APIValue); 
		 }
		 Reporter.addScreenCapture();
    }
    
    @Then("^user should be able to go to Strategy Detail page$")
    public void user_should_be_able_to_go_to_strategy_detail_page() throws Throwable {
    	
    	Assert.assertTrue(StrategyDetail.getPageURL().contains(pageURL), "We are in StrategyDetailPage");
    	Reporter.addScreenCapture();
    }
    

}
