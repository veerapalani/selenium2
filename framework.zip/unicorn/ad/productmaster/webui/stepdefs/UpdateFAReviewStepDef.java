package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAReviewPage;

public class UpdateFAReviewStepDef {
	
	UpdateFAReviewPage reviewPage = new UpdateFAReviewPage("AD_PM_UpdateFAReviewPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
	XSSFSheet sheet;
	int rowIndex;
	String sheetName;
	String label, attributeValue, uiValue,dbValue = null;
	
	@And("^User should be able to see Review Page in Update FA Flow$")
    public void user_should_be_able_to_see_review_page_in_update_fa_flow() {
		
		Assert.assertTrue(reviewPage.isUserOnReviewPage());
    }

    @And("^User Clicks on Previous button in Review page in Update FA Flow$")
    public void user_clicks_on_previous_button_in_review_page_in_update_fa_flow() {
    	reviewPage.clickOnPreviousButton();
    }
    
	@And("^with FA code from UI store the data related to FA from review page in Excel for (.+) in Update FA Flow$")
    public void with_fa_code_from_ui_store_the_data_related_to_fa_from_review_page_in_excel_for_in_update_fa_flow(String mandatorydetails) throws IOException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		//mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
        
        rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        
    	int reviewPageDataRowIndex = rowIndex+4;
    	String managerCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex+1, 45);
		getDataFromreviewPageandStoreInExcel(managerCode, reviewPageDataRowIndex);
    }

	private void getDataFromreviewPageandStoreInExcel(String managerCode, int reviewPageDataRowIndex) throws IOException {
		sheetName = "Test";
		   
		   int columNum = 3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
		   
		   //Boolean bool = reviewPage.areContactsDisplayed();
		   //Boolean bool2 = reviewPage.isDocumentHeaderDisplayed();
		  
		   ArrayList<String> pageHeaders = reviewPage.getHeadersInReviewPage(); 
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columNum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						 
						if(label.contains("Document")) {
							if(pageHeaders.size() > 2)
								attributeValue = getDataFromReviewPage(label);
							else
								attributeValue = "";
								
						}else if (label.contains("Contact")) {
							if(pageHeaders.size() > 1)
								attributeValue = getDataFromReviewPage(label);
							else
								attributeValue = "";
						}
						else
							attributeValue = getDataFromReviewPage(label);
						
						if(label.split(" - ")[0].equals("radiobutton"))
						{
							switch (attributeValue.toLowerCase().trim()) {
							case "yes":
								attributeValue = "t";
								break;
							case "no":
								attributeValue = "f";
								break;
							default:
								break;
							}
						}
						
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex-1, columNum);
						
						//To Handle AUM Value comparision
						if(label.contains("txtint")) {
							attributeValue = String.valueOf(Float.parseFloat(attributeValue+"f"));
							dbValue = String.valueOf(Float.parseFloat(dbValue+"f"));
							}
						
						if(label.contains("Document")) {
							if(dbValue.equalsIgnoreCase(attributeValue)) {
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue);
							}
						}else if(dbValue.equals(attributeValue)) {
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue);
						}else {
							
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue+" -Review Page Value is not same as Flow Page Value in UI");
								Reporter.addEntireScreenCaptured();
								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Value Displayed in Flow Pages");
							
						}
						
						columNum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
							if(label == "")
								label = "isEmpty";
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
		
	}

	private String getDataFromReviewPage(String data) {
			switch (data) {
			case "txt - Branch Manager/Market Head":
				
				uiValue = reviewPage.getManagerHeadValue();
				
				break;
			case "txt - FA Name":
				
				uiValue = reviewPage.getFANameValue();
				
				break;
			case "txt - FA Email":
				
				uiValue = reviewPage.getFAEmailValue();
				
				break;
			case "grey - FA ID(s)":
				
				uiValue = reviewPage.getFAIDValue();
				
				break;
			case "grey - Universal ID(s)":
				
				uiValue = reviewPage.getUniversalIDValue();
				
				break;
			case "grey - CRD#(s)":
				
				uiValue = reviewPage.getCRDValue();
				
				break;
			case "radiobutton - Is nomination for a recruit?":
				
				uiValue = reviewPage.getNominationForRecruitValue();
				
				break;
			case "date - Recruit Hire Date":
				
				uiValue = reviewPage.getRecruitHireDataValue();
				
				break;
			case "txt - Prior Firm":
				
				uiValue = reviewPage.getPriorFirmValue();
				
				break;
			case "radiobutton - Previously Approved for FA Discretionary Program?":
				
				uiValue = reviewPage.getPreviouslyApprovedorNotForFADiscretionaryProgramValue();
				
				break;
			case "drp - FA Discretionary Program Name":
				
				uiValue = reviewPage.getFADiscretionaryProgramValue();
				
				break;
			case "drp - FA Segment":
				
				uiValue = reviewPage.getFASegmentValue();
				
				break;
			case "radiobutton - Re-Nomination":
				
				uiValue = reviewPage.getRenominationValue();
				
				break;
			case "date - Re-Nomination Date":
				
				uiValue = reviewPage.getRenominationDateValue();
				
				break;
			case "txtint - Length of Series 7 Registration":
				
				uiValue = reviewPage.getSeries7RegistrationValue();
				
				break;
			case "txtint - Length of Series 65 or 66 Registration":
				
				uiValue = reviewPage.getSeries65RegistrationValue();
				
				break;
			case "txtint - Length of Service as a FA":
				
				uiValue = reviewPage.getLenghtOfServiceAsFAValue();
				
				break;
			case "txtint - FA Assets Under Management (AUM in $)":
				
				uiValue = reviewPage.getAUMValue();
				
				break;
			case "txtint - Anticipated Percentage of Overall Business in PMP/AAP":
							
				uiValue = reviewPage.getAnticipatedPercentageValue();
							
				break;
			case "txt - Branch":
				
				uiValue = reviewPage.getBranchValue();
				
				break;
			case "txt - Complex":
				
				uiValue = reviewPage.getComplexValue();
				
				break;
			case "txt - Division":
				
				uiValue = reviewPage.getDivisionValue();
				
				break;
			case "txt - Region":
				
				uiValue = reviewPage.getRegionValue();
				
				break;
			case "radiobutton - CFA or ACPM Charter Holder?":
				
				uiValue = reviewPage.getCFAorACPMValue();
				
				break;
			case "radiobutton - Waive / completed course work":
				
				uiValue = reviewPage.getWaiverorCompletedCourseValue();
				
				break;
			case "date - Zoologic course work registration date":
				
				uiValue = reviewPage.getZoologicCourseRegistrationValue();
				
				break;
			case "date - Zoologic course work completed date":
				
				uiValue = reviewPage.getZoologicCourseCompletedValue();
				
				break;
			case "txt - Awards/Citations/Certifications":
				
				uiValue = reviewPage.getAwardsValue();
				
				break;
			case "txt - Additonal Information":
				
				uiValue = reviewPage.getAdditionalInformationValue();
				
				break;
			case "drp - Document Type":
				
				uiValue = reviewPage.getDocumentTypeValue();
				
				break;
			case "txt - Document Link":
				
				uiValue = reviewPage.getDocumentLinkValue();
				
				break;
			case "txt - Document Comment":
				
				uiValue = reviewPage.getDocumentCommentValue();
				
				break;
			case "radiobutton - Exception / Conditional Approval":
				
				uiValue = reviewPage.getExceptionorConditionApprovalValue();
				
				break;
			case "date - Expiration Date":
				
				uiValue = reviewPage.getExpirationDateValue();
				
				break;
			case "txt - Home Office Comments":
				
				uiValue = reviewPage.getHomeOfficeCommentsValue();
				
				break;
			case "grey - Approver Name":
				
				uiValue = reviewPage.getApproverNameValue();
				
				break;
			case "drp - FA Status":
				
				uiValue = reviewPage.getFAStatusValue();
				
				break;
			case "date - Status Date":
				
				uiValue = reviewPage.getStatusDateValue();
				
				break;
			case "date - Follow-up Date":
				
				uiValue = reviewPage.getFollowUpDateValue();
				
				break;
			case "txt - Follow-up":
				
				uiValue = reviewPage.getFollowUpValue();
				
				break;
				
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
	}

}
