package qa.unicorn.ad.productmaster.webui.stepdefs;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkFlyoutPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerFlyoutPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;
public class CreateManagerFlyoutStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateManager.xlsx";
	String option, sheetName = "";
	int rowIndex;
 ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	CreateManagerFlyoutPage createfly = new CreateManagerFlyoutPage("AD_PM_CreateManagerFlyoutPage");
	
	@And("^User clicks on Continue Button on Manager Flyout Page$")
    public void user_clicks_on_continue_button_on_manager_flyout_page() throws Throwable {
		createfly.clickOncontinuebutton();
    }
	@And("^User clicks on Cancel Button on Manager Flyout Page$")
    public void user_clicks_on_cancel_button_on_manager_flyout_page() throws Throwable {
		createfly.clickOnCancelButton();
    }
	@Then("^User should be able to see the Save as draft button will be in disabled state on Create New Manager Flyout$")
    public void user_should_be_able_to_see_the_save_as_draft_button_will_be_in_disabled_state_on_create_new_manager_flyout() throws Throwable {
        createfly.verifysaveasdraftbuttonincreatemanagerpage();
    }
	
	@Then("^user should be able to see the below following fields with the \"([^\"]*)\" symbol on the Create Manager Flyout$")
    public void user_should_be_able_to_see_the_below_following_fields_with_the_something_symbol_on_the_create_manager_flyout(String attribute,List<String> entity) throws Throwable {
		for(int i =0;i<entity.size();i++) {
        	myElement = createfly.findElementByDynamicXpath("//*[@label='"+entity.get(i)+"']");
        	createfly.verifyAttribute("true", myElement, attribute);
        }
    }

}
