package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.codoid.products.exception.FilloException;

import qa.framework.utils.Reporter;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.Action;
import qa.framework.utils.GlobalVariables;
import qa.unicorn.ad.productmaster.api.stepdefs.CSVtoExcelConverter;
import qa.unicorn.ad.productmaster.api.stepdefs.ExportReports;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class UIManagerEntityStepDef {
	PMPageGeneric ManagerEntity=new PMPageGeneric("AD_PM_ManagerEntityPage");
	String activeLink = "Manager";
	String expectedColorCode,xpath;
	List<WebElement> listOfElements,listOfElements2 = new ArrayList<WebElement>();
	String pageURL = "http://10.49.116.4:8080/pmui/?#/manager";
	
    @Then("^Manager Link should be active$")
    public void Manager_link_should_be_something() throws Throwable {
        ManagerEntity.verifyAttribute("true", activeLink, "selected");
    }
    
    @Then("^User should be able to see \"([^\"]*)\" in \"([^\"]*)\" on Manager Entity page$")
    public void user_should_be_able_to_see_something_on_Manager_Entity_page(String list1, String key) throws Throwable {
    	String[] listArray = list1.split(",");
    	listOfElements =  ManagerEntity.getElements(key);
    	for(int i=0;i<listArray.length;i++) {
    		ManagerEntity.verifyTextInListOfElements(listArray[i], listOfElements);
    		Reporter.addStepLog(listArray[i]+" is displaying in " + key);
    	}
    }

    
	@And("^Order of the \"([^\"]*)\" should be \"([^\"]*)\" on Manager Entity page$")
    public void order_of_the_something_should_be_something_on_Manager_Entity_page(String key, String list1) throws Throwable {
		String[] listArray = list1.split(",");
     	listOfElements =  ManagerEntity.getElements(key);
     	for(int i=0;i<listArray.length;i++) {
     		Assert.assertEquals( listOfElements.get(i).getText(),listArray[i]);
     		Reporter.addStepLog(listOfElements.get(i).getText()+" is the "+i+" element in " + key);
     	}
    }

    @And("^All the \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Manager Entity page$")
    public void all_the_something_should_be_displayed_in_something_color_on_Manager_Entity_page(String key, String color) throws Throwable {
        listOfElements = ManagerEntity.getElements(key);
        expectedColorCode = Action.getTestData(color);
        for(int i=0;i<listOfElements.size();i++) {
        	ManagerEntity.verifyColor(listOfElements.get(i), expectedColorCode);
        }
        
        
    }
    
    @Then("^User should be able to see \"([^\"]*)\" in every row of \"([^\"]*)\" on Manager Entity page$")
    public void user_should_be_able_to_see_something_in_every_row_of_something_on_Manager_Entity(String insideElementKey, String key) throws Throwable {
    	listOfElements = ManagerEntity.getElements(key);        
        for(int i=1;i<=Math.min(listOfElements.size(),10);i++) {
        	xpath="//tr[@class='divider divider-top divider-03 divider-color-03']["+i+"]//wf-icon[@name='ellipsis-v-solid']";
        	ManagerEntity.verifyElement(ManagerEntity.findElementByDynamicXpath(xpath));
        	Reporter.addStepLog("verified "+insideElementKey+ " for element no "+(i));
        	ManagerEntity.scrollByPixel(100);
        }
    }
    
    @Then("^User should be able to see the Following \"([^\"]*)\" while \"([^\"]*)\" on the Ellipse Icon in every row of \"([^\"]*)\" on Manager Entity page$")
    public void user_should_be_able_to_see_something_while_hovering_on_the_something_in_every_row_of_something_on_Manager_Entity_page(String options, String insideElementKey, String parentElementKey) throws Throwable {
    	Thread.sleep(2000);
		ManagerEntity.hoverOnElement(ManagerEntity.getElementFromShadowRoot(insideElementKey));
		Thread.sleep(1000);
		ManagerEntity.verifyElement(options);
		Reporter.addStepLog("verified "+options+ " for element");
		ManagerEntity.scrollByPixel(100);   
    }

    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Manager Entity page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_manager_entity_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
    	ManagerEntity.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = ManagerEntity.getElementsFromShadowRoot(key);
   	 ManagerEntity.verifyTextInListOfElements( items.get(i),listOfElements);  
        } 
    }
    
    @Then("^User should be able to see the \"([^\"]*)\" header on Manager Entity page$")
    public void user_should_be_able_to_see_the_something_header_on_manager_entity_page(String key) throws Throwable {
        ManagerEntity.verifyHeader(key);
    }
    
    @Then("^User should be able to see the \"([^\"]*)\" at the \"([^\"]*)\" on Manager Entity page$")
    public void user_should_be_able_to_see_the_something_at_the_something_on_Manager_entity_page(String key, String shadowRootKey) throws Throwable {
    	ManagerEntity.verifyElement(ManagerEntity.fetchElementFromShadowRoot(key, shadowRootKey));
    }

    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Manager Entity page$")
    public void something_should_be_displayed_in_something_color_on_Manager_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	ManagerEntity.verifyColor(key,expectedColorCode);
    	
    }
    
    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Manager Entity page$")
    public void something_should_be_displayed_in_something_color_inside_Manager_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	ManagerEntity.verifyColor(ManagerEntity.getElementFromShadowRoot(key),expectedColorCode);
    	
    }
    
    @And("^\"([^\"]*)\" should have \"([^\"]*)\" background color on Manager Entity page$")
    public void something_should_have_something_background_color_on_Manager_entity_page(String key, String backgroundColor) throws Throwable {
    	expectedColorCode = Action.getTestData(backgroundColor);
    	ManagerEntity.verifyBackgroundColor(key,expectedColorCode);
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Manager Entity page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_on_Manager_entity_page(String ghostText, String searchBox) throws Throwable {
    	ManagerEntity.verifyGhostText(ghostText, ManagerEntity.getElementFromShadowRoot(searchBox));
    }

    @And("^User should be able to see the \"([^\"]*)\" on Manager Entity page$")
    public void user_should_be_able_to_see_the_something_on_Manager_entity_page(String key) throws Throwable {
    	ManagerEntity.verifyElement(key);
    }
    
    @And("^User should be able to see the \"([^\"]*)\" inside Manager Entity page$")
    public void user_should_be_able_to_see_the_something_inside_Manager_entity_page(String key) throws Throwable {
    	ManagerEntity.verifyElementFromShadowRoot(key);
    	}
    
    @And("^user clicks the \"([^\"]*)\" on Manager Entity page$")
	public void user_clicks_the_something_on_manager_entity_page(String key) throws Throwable {
		ManagerEntity.clickOnLink(key);
	}

    @And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Manager Entity page$")
    public void that_something_should_be_displayed_in_something_color_on_Manager_entity_page(String key, String expectedColor) throws Throwable {
    	expectedColorCode = Action.getTestData(expectedColor);
    	ManagerEntity.verifyCurrentElementColor(expectedColorCode);
    }

    @And("^The \"([^\"]*)\" on the Manager Entity page should contain all the following options$")
    public void the_something_on_the_Manager_Entity_page_should_contain_all_the_following_options(String key,List<String> items) throws Throwable {
    	for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   	 ManagerEntity.verifyTextInListOfElements( items.get(i), ManagerEntity.getElements(key)); 
   	 }
    }

    @Then("^User should be able to see only \"([^\"]*)\" \"([^\"]*)\" on Manager Entity Page$")
    public void user_should_be_able_to_see_only_something_something_on_program_entity_page(String numberOfItems, String key) throws Throwable {
        listOfElements = ManagerEntity.getElements(key);
        Assert.assertEquals( listOfElements.size(),Integer.parseInt(numberOfItems));
        Reporter.addStepLog("verified that "+numberOfItems+" "+key+" present");
    }
    
    @Then("^\"([^\"]*)\" should not be displayed in \"([^\"]*)\" on Manager Entity Page$")
    public void something_should_not_be_displayed_in_something_on_program_entity_page(String item, String key) throws Throwable {
    	listOfElements = ManagerEntity.getElements(key);
    	ManagerEntity.verifyTextNotPresentInListOfElements(item, listOfElements);
        Reporter.addStepLog("verified that "+item+" is not present in "+key);
    }
    
    @And("^user hover over the \"([^\"]*)\" of first element of \"([^\"]*)\" on Manager Entity page$")
	public void user_hover_over_the_something_of_first_element_of_something_on_manager_entity_page(
			String insideElementKey, String parentElementKey) throws Throwable {
		listOfElements = ManagerEntity.getElements(insideElementKey);
		ManagerEntity.hoverOnElement(listOfElements.get(0));
		Reporter.addStepLog("hovering on " + insideElementKey);
	}
    
    @Then("^user should be able to go to Manager Entity page$")
	public void user_should_be_able_to_go_to_manager_entity_page() throws Throwable {
		ManagerEntity.verifyPageURL(pageURL);
	}
    
    /**
     * @author PatelNim
     * @throws Throwable 
     */
    @And("^User clicks on \"([^\"]*)\" on Manager Entity Page$")
    public void user_clicks_on_button_on_manager_entity_page(String btnName) throws Throwable {
    	if(btnName.equals("Export Button")) {
    		ManagerEntity.clickOnLink("btnManagerExport");
    	}
    }
    
    ExportReports reports = new ExportReports();
    
    @And("^User delete previous \"([^\"]*)\" report from system$")
    public void user_delete_previous_report(String entityName) throws InterruptedException {
    	reports.DeletePreviousFile(entityName);
    }
    
    @Then("^User is able to download \"([^\"]*)\" report$")
    public void user_is_able_to_download_report(String entityName) throws InterruptedException {
    	Assert.assertTrue(reports.VerifyFileDownloaded());
    }
    
    @Then("^User is able to see \"([^\"]*)\" button for manager entity$")
    public void user_is_able_to_see_button_for_manager_entity(String entity){
    	Assert.assertTrue(ManagerEntity.isDisplayed("btnManagerExport"));
    }
    
    @And("^user verify data present for manager grid$")
    public void user_verify_data_present_for_manager_grid() throws IOException, FilloException {
    	Assert.assertTrue(reports.verifyDataPresent("tblManagerName"),"Data not matched");
    }
    
    @And("^count in file should be equal to count in excel report$")
    public void count_in_file_is_equal_to_count_in_excel_report() throws IOException {
    	Assert.assertTrue(reports.verifyCountInFileAndOnUI(),"Count Not Matched!!");
    	
    }
    
    @And("^User converts \"([^\"]*)\" csv report to excel file$")
    public void user_converts_something_csv_report_to_excel_file(String entityName) throws Throwable {
    	reports.CSVtoExcel(entityName);
    }
    
    @And("^user is able to see below attributes for manager in report$")
    public void user_is_able_to_see_below_attributes_for_manager_in_reports(List<String> expectedAttributes) throws IOException {
    	reports.verifyAttributes(expectedAttributes, "Manager");
    }
    
    @And("^User validate the downloaded report for manager$")
    public void user_validate_the_downloaded_report_for_manager() throws Throwable {
        reports.verifyAttributesData();
    }
}
