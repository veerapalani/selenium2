package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.ExportReportsPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAViewPage;

public class FAExportStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	UpdateFAViewPage viewPage = new UpdateFAViewPage("AD_PM_UpdateFAViewPage");
	ExportReportsPage reports = new ExportReportsPage();
	String sheetName, sheetName2 = "";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/FAExport.xlsx";
	String attributeValue,label = "";
	int rowIndex,columNum,cellCount = 0;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;

	@Then("^user verifies the FA export functionality using (.+)$")
	public void user_verifies_the_fa_export_fucntionality(String entityName) throws IOException, InterruptedException {
		int count = viewPage.getFaCount();
		System.out.println("count: " + count);
		if (count < 1) {
			Reporter.addStepLog("There are no FA Entities associated with search value in the Grid");
			Reporter.addScreenCapture();
		} else {
			reports.DeletePreviousFile(entityName);
			viewPage.clickOnFATeamExport();
			Assert.assertTrue(reports.VerifyFileDownloaded());
			// verifying the grid count and csv file count
			Assert.assertTrue(count == reports.getNumberOfRecordsInFile(entityName));
			landingPage.movetoFirstElementinFilteredrecords();
			landingPage.clickOnEllipsesIcon();
			landingPage.verifyOnViewDetailsLink();

			landingPage.clickOnViewDetailsLink();
			Assert.assertTrue(viewPage.isUserOnViewFAPage());

			excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/FAExport.xlsx";

			sheetName = entityName;
			Boolean flag = false;
			if(viewPage.areDocumentsDisplayedInUI()) {
				flag = true;
			}
			System.out.println("flag:"+flag);
			sheet = exlObj.getSheet(entityName);
			cellCount=exlObj.getCellCount(sheet, 0);
			System.out.println("cellcount:"+cellCount);
			while(columNum<cellCount) {
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
				if(flag == true && label.contains("Document")) {
					attributeValue = viewPage.getDataFromViewPageforExport(label);
					//attributeValue = "";
				}else if(flag == false && label.contains("Document")){
					attributeValue = "";
				}else {
					attributeValue = viewPage.getDataFromViewPageforExport(label);
				}
				
				if(attributeValue.equals("isEmpty")) {
					attributeValue ="";
				}
				System.out.println(attributeValue);
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, columNum, attributeValue);
				columNum++;
			}
			
			// Make sure sheet name same as entity name i.e same as downloaded file name
		reports.verifyAttributesForFirstEntityforFA(entityName, excelFilePath);
		exlObj.closeWorkBook();

		}
	}

	@Then("^user verifies the FA export tooltip$")
	public void user_verifies_the_fateam_export_tooltip() {
		Assert.assertTrue(viewPage.verifyTooltipOfFATeamExport());
	}

}
