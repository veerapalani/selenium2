package qa.unicorn.ad.productmaster.webui.stepdefs;
import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyEnterStrategyDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
public class CreatePMPStrategyEnterStrategyDetailsStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	CreatePMPStrategyEnterStrategyDetailsPage strategyDetailsPage = new CreatePMPStrategyEnterStrategyDetailsPage("AD_PM_CreatePMPStrategyEnterStrategyDetailsPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex,columnIndex;
	String expError,userInfo;
	String strategyName, uiValue = null;
	
	public static int count;
	
	@When("^(.+) follows steps to create PMP Strategy with (.+) in Landing Page$")
    public void follows_steps_to_create_pmp_strategy_with_in_landing_page(String typeofuser, String mandatorydetails) throws IOException{
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		
		String data = mandatorydetails;
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		
		}
		
		
		String tName = Thread.currentThread().getName();
		//setting a unique strategy name
		synchronized (tName) {	
			strategyName = RandomStringUtils.randomAlphabetic(10)+data.substring(9, data.length());
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			columnIndex = 1;
	        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, columnIndex, strategyName);
		}
		
        userInfo = typeofuser;
        //HO User creates a PMP Strategy
        if (typeofuser.contains("HO")) {
        	Action.pause(2000);
        	landingPage.clickOncreatenewdropdownicon();
        	Action.pause(2000);
        	landingPage.clickOnstrategydropdownmenu();
        	
        	assertTrue(strategyDetailsPage.isUserOnCreateStrategyWizardPage());
        	strategyDetailsPage.clickOnPMPRadioButton();
        	strategyDetailsPage.enterStrategyName(strategyName);
        	strategyDetailsPage.clickOnCreateButton();
		}
        
        //Branch User creates a PMP Strategy
        if(typeofuser.contains("Branch") || typeofuser.toLowerCase().contains("bruser")) {
			landingPage.clickOnCreateNewStrategyButtonBU();
		}
    }

    @And("^User inputs (.+) in Enter Strategy details Page$")
    public void user_inputs_in_enter_strategy_details_page(String mandatorydetails) throws IOException, InterruptedException {
    	
    	
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}
		
		String investmentStyleName,faName,faTeamName,changeFaSegment,faSegment,changeStrategyTier,strategyTier,marginEligible,structuredProductsStrategy = ""; 
		String concentratedStrategyIndicator,shortTermMaturity,hedgeCoreIndicator,sustainableInvestmentStrategy,alternativeStrategy,nonPmpApprovedTeamEmails = ""; 
		String dvpKeyTrustTemplate,displayStrategyCompositeOnAdvisoryFrontEnd,hideStrategy = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			columnIndex = 1;
			
			investmentStyleName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 2);
			faName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 3); 
			faTeamName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 4); 
			changeFaSegment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 5); 
			faSegment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 6); 
			changeStrategyTier = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 7); 
			strategyTier = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 8); 
			marginEligible = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 9); 
			structuredProductsStrategy = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 10); 
			concentratedStrategyIndicator = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 11); 
			shortTermMaturity = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 12); 
			hedgeCoreIndicator = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 13); 
			sustainableInvestmentStrategy = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 14); 
			alternativeStrategy = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 15); 
			nonPmpApprovedTeamEmails = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 16); 
			dvpKeyTrustTemplate = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 17); 
			//displayStrategyCompositeOnAdvisoryFrontEnd = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 18); 
			hideStrategy = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 18);
		}
			if (userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
			
				strategyDetailsPage.enterStrategyNameBU(strategyName);
			}
			String test = strategyDetailsPage.getStrategyName();
			
			//assertTrue(test.equals(strategyName));
			
			if (investmentStyleName != "") {
				strategyDetailsPage.enterInvestmentStyleName(investmentStyleName);
			}
			if (faName != "") {
					
					strategyDetailsPage.selectFARadioButton();
					strategyDetailsPage.enterFaName(faName, "fa");
				
			}
			if (faTeamName != "") {

					strategyDetailsPage.selectFATeamRadioButton();
					strategyDetailsPage.enterFaName(faTeamName, "faTeam");
				
			}
//			synchronized (tName) {
//				switch (strategyDetailsPage.checkFAorFATeamRadiobuttonselected()) {
//				case "FA":
//					PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 4, ""); 
//					System.out.println("FA Selected");
//					break;
//				case "FA Team":
//					PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 3, "");
//					System.out.println("FA Team Selected");
//					break;
//				default:
//					break;
//				}
//			}
			
			//to be deleted work around for now
		/*
		 * if (investmentStyleName != "") {
		 * strategyDetailsPage.enterInvestmentStyleName(investmentStyleName); }
		 */
			if (faSegment != "") {
				
				if(userInfo.contains("HO")) {
					switch (changeFaSegment) {
					case "Yes":
						strategyDetailsPage.enterFaSegment(faSegment,userInfo);
						break;
					case "No":
						//HO User chose not to change FA Segment
						break;
					default:
						//HO User gave invalid value for FA Segment selection
						break;
					}
				}
			}
			if(strategyDetailsPage.getFaSegmentValue() != faSegment) {
				Reporter.addStepLog("User do not have access to change FA Segement - Modifying the FA Segment value in Excel data given");
				tName = Thread.currentThread().getName();
				synchronized (tName) {
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 6, strategyDetailsPage.getFaSegmentValue());
				}
			}
			if (strategyTier != "") {
				
				
					switch (changeStrategyTier) {
					case "Yes":
						strategyDetailsPage.enterstrategyTier(strategyTier);
						break;
					case "No":
						//HO User chose not to change FA Segment
						break;
					default:
						//HO User gave invalid value for FA Segment selection
						break;
					}
				
			}
			if(strategyDetailsPage.getStrategyTierValue() != strategyTier) {
				Reporter.addStepLog("User do not have access to change Strategy Tier - Modifying the FA Segment value in Excel data given");
				tName = Thread.currentThread().getName();
				synchronized (tName) {
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 8, strategyDetailsPage.getStrategyTierValue());
				}
			}
			if (marginEligible != "") {
				strategyDetailsPage.enterMarginEligible(marginEligible);
			}
			if (structuredProductsStrategy != "") {
				strategyDetailsPage.enterStructuredProductsStrategy(structuredProductsStrategy);
			}
			//Repeating below as Strategy Tier value is auto populated by Structured Products Strategy
			if(strategyDetailsPage.getStrategyTierValue() != strategyTier) {
				Reporter.addStepLog("User do not have access to change Strategy Tier - Modifying the FA Segment value in Excel data given");
				tName = Thread.currentThread().getName();
				synchronized (tName) {
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 8, strategyDetailsPage.getStrategyTierValue());
				}
			}
			if (concentratedStrategyIndicator != "") {
				strategyDetailsPage.enterConcentratedStrategyIndicator(concentratedStrategyIndicator);
			}
			if (shortTermMaturity != "") {
				strategyDetailsPage.enterShortTermMaturity(shortTermMaturity);
			}
			if (hedgeCoreIndicator != "") {
				strategyDetailsPage.enterHedgeCoreIndicator(hedgeCoreIndicator);
			}
			if (sustainableInvestmentStrategy != "") {
				strategyDetailsPage.enterSustainableInvestmentStrategy(sustainableInvestmentStrategy);
			}
			if (alternativeStrategy != "") {
				strategyDetailsPage.enterAlternativeStrategy(alternativeStrategy);
			}
			if (nonPmpApprovedTeamEmails != "") {
				strategyDetailsPage.enterNonPmpApprovedTeamEmails(nonPmpApprovedTeamEmails);
			}
			if (dvpKeyTrustTemplate != "") {
				strategyDetailsPage.enterDvpKeyTrustTemplate(dvpKeyTrustTemplate);
			}
			/*
			if (displayStrategyCompositeOnAdvisoryFrontEnd != "") {
				strategyDetailsPage.enterdisplayStrategyCompositeOnAdvisoryFrontEnd(displayStrategyCompositeOnAdvisoryFrontEnd);
			}
			*/
			if (hideStrategy != "") {
				if(userInfo.contains("HO")) {
					strategyDetailsPage.enterHideStrategy(hideStrategy);
				}else if(userInfo.contains("Branch") || userInfo.contains("bruser")) {
					//Hide Strategy Field is Hidden in UI For Branch User
					//default value for it is set to false in Data Base as its not interactable for Branch User
					tName = Thread.currentThread().getName();
					synchronized (tName) {
					PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 18, "No");
					}
					
				}
			}
			
		
		
		Reporter.addScreenCapture();
    }

    @And("^User clicks on Next in Enter Strategy details Page$")
    public void user_clicks_on_next_in_enter_strategy_details_page() {
        strategyDetailsPage.clickOnNext();
    }

    @And("^User should be able to see Enter Strategy details Page in PMP Flow$")
    public void user_should_be_able_to_see_enter_strategy_details_page_in_pmp_flow() {
    	Reporter.addStepLog(Thread.currentThread().getName());
    	assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailsPage());
    }
    
    @Then("^User should be able to see \"([^\"]*)\" attribute Header in  Enter Starategy Deatils page$")
    public void user_should_be_able_to_see_something_attribute_header_in_enter_starategy_deatils_page(String label) {
        
        Assert.assertTrue(strategyDetailsPage.istheAttributeHeaderVisible(label));
    }
    
    @Then("^User input fields from (.+) should be visible in Enter Strategy Details Page in PMP Flow$")
    public void user_input_fields_from_should_be_visible_in_enter_strategy_details_page_in_pmp_flow(String mandatorydetails) {
    	if(mandatorydetails.contains("Test")) {
    		sheetName = "Test";
    	}
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String label, attributeValue, userGivenValue = null;
		   //sheet = exlObj.getSheet(sheetName);
		   int columnnum = 1;
		   count = 0;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnnum);
				   //(String) exlObj.getCellData(sheet, 0, columnnum);
		   
		   if((label == "") || (label.contains("BenchmarkCategory")))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || (label.contains("NIESDP"))) {
						columnnum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnnum);
			    					//(String) exlObj.getCellData(sheet, 0, columnnum).toString();
			    			
			    			if((label == "") ||(label.contains("BenchmarkCategory")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterStrategyDetailsPage(label);
						rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
						userGivenValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, columnnum);
						
						//Handling the Exceptions
						if(label.contains("noemptyvalue"))
							if(userGivenValue.isEmpty())
								userGivenValue = "Not Defined";
						
						if(label.contains("specialdata"))
							if(userGivenValue.isEmpty())
								userGivenValue = "No";
						
						if(userGivenValue.isEmpty())
							userGivenValue = "isEmpty";
							
						
						
						if(userGivenValue.equalsIgnoreCase(attributeValue)) {
							//Value in UI Matches with value given by user
						}else {
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Label: "+label+" -- Uservalue: "+userGivenValue);
							Reporter.addStepLog("For Label: "+label+" -- UIvalue: "+attributeValue);
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Value given as input by user");
							count++;
							
						}
						
						
						columnnum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnnum);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("BenchmarkCategory")))
								label = "isEmpty";
					
					}
			}
			
			if(count > 0) {
				Assert.fail("Prepopulated Values are not same as values stored in DB");
			}
			
    }

	private String getDataFromEnterStrategyDetailsPage(String label) {

			switch (label) {
			case "strategyName":

				uiValue = strategyDetailsPage.getStrategyName();
				
				break;
			case "Investment Style Name":
				
				uiValue = strategyDetailsPage.getInvestmentStyleNameValue();
				
				break;
			case "FA Name":
				
				uiValue = strategyDetailsPage.getFANameValue();
				
				break;
			case "FA Team Name":
				
				uiValue = strategyDetailsPage.getFATeamNameValue();
				
				break;
			case "FA Segment":
				
				uiValue = strategyDetailsPage.getFaSegmentValue();
				
				break;
			case "Strategy_Tier":
				
				uiValue = strategyDetailsPage.getStrategyTierValue();
				
				break;
			case "Margin Eligible_specialdata":
				
				uiValue = strategyDetailsPage.getMarginEligibleValue();
				
				break;
			case "Structured Products Strategy_noemptyvalue":
				
				uiValue = strategyDetailsPage.getStructuredProductsStrategyValue();
				
				break;
			case "Concentarted Strategy Indicator_noemptyvalue":
				
				uiValue = strategyDetailsPage.getConcentratedStrategyIndicator();
				
				break;
			case "Short term Maturity_noemptyvalue":
				
				uiValue = strategyDetailsPage.getShortTermMaturityValue();
				
				break;
			case "Hedge Core Indicator_noemptyvalue":
				
				uiValue = strategyDetailsPage.getHedgeCoreIndicatorValue();
				
				break;
			case "Sustainable Investment Strategy_noemptyvalue":
				
				uiValue = strategyDetailsPage.getSustainableInvestmentStrategyValue();
				
				break;
			case "Alternatives Strategy_noemptyvalue":
				
				uiValue = strategyDetailsPage.getAlternativesStrategyValue();
				
				break;
			case "Non PMP Approved Team Member Emails":
							
				uiValue = strategyDetailsPage.getNonPMPApprovedTeamMemberEmailsValue();
							
				break;
			case "DVP Key Trust Template":
				
				uiValue = strategyDetailsPage.getDVPKeyTrustTemplate();
				
				break;
			case "Hide Strategy_specialdata":
				
				uiValue = strategyDetailsPage.getHideStrategyValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if((uiValue == null) || (uiValue.isEmpty()))
			uiValue = "isEmpty";
	
		return uiValue;		
		
	}
	
	@And("^User clicks on Reset Button in Enter Strategy details Page in PMP Flow$")
    public void user_clicks_on_reset_button_in_enter_strategy_details_page_in_pmp_flow() {
        strategyDetailsPage.clickOnResetButton();
    }
	
	@Then("^user input fields should all be cleared in Enter Strategy details Page in PMP Flow$")
    public void user_input_fields_should_all_be_cleared_in_enter_strategy_details_page_in_pmp_flow() {
		
		Assert.assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailsPage());
		
    	
    		sheetName = "SQLquerywithCode";
    	
    	
    	String label, attributeValue, expectedDefaultValue = null;
		   //sheet = exlObj.getSheet(sheetName);
		   int rownum = 1;
		   count = 0;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
				   
		   
		   if((label == "") || (label.contains("BenchmarkCategory")))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || (label.contains("NIESDP"))) {
						rownum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
			    					
			    			
			    			if((label == "") ||(label.contains("BenchmarkCategory")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterStrategyDetailsPage(label);
						expectedDefaultValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 3);
						if(expectedDefaultValue == "")
							expectedDefaultValue = "isEmpty";
						if(label.equals("strategyName"))
							expectedDefaultValue = strategyName;
						Assert.assertTrue(attributeValue.equals(expectedDefaultValue), "For "+label +" :: UI Value ::--" +attributeValue+"  --:: Excel Value ::"+expectedDefaultValue);
						rownum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("BenchmarkCategory")))
								label = "isEmpty";
					
					}
			}
		
    }
	
	@And("^value for attribute \"([^\"]*)\" should be null/blank value$")
    public void value_for_attribute_something_should_be_nullblank_value(String label) {
        
		String attributeValue = strategyDetailsPage.getattributeValuebylabel(label);
        
		if(label.equalsIgnoreCase("FOA Code"))
			Assert.assertTrue(attributeValue.equalsIgnoreCase("N - system-generated"));
		else
			Assert.assertFalse(Optional.ofNullable(attributeValue).isPresent(), "Attribute Value for label "+label+" is not null");
        
    }
	
	@And("^Program \"([^\"]*)\" header should be visible in Enter Strategy details page in PMP Flow$")
    public void program_something_header_should_be_visible_in_enter_strategy_details_page_in_pmp_flow(String program) {
        Assert.assertTrue(strategyDetailsPage.isProgramheaderVisible(program));
    }
	
	@When("^HO User follows steps to create a Strategy in Landing Page$")
    public void ho_user_follows_steps_to_create_a_strategy_in_landing_page() {
		landingPage.clickOncreatenewdropdownicon();
    	landingPage.clickOnstrategydropdownmenu();
    	
    	
    }

    @Then("^User should be able to see (.+) in Create Strateg Wizard Page$")
    public void user_should_be_able_to_see_in_create_strateg_wizard_page(String errormessage) {
    	assertTrue(strategyDetailsPage.error(errormessage));
    }

    @And("^User is in Create Strategy wizard page$")
    public void user_is_in_create_strategy_wizard_page() {
    	assertTrue(strategyDetailsPage.isUserOnCreateStrategyWizardPage());
    	
    	
    }

    @And("^User clicks on Create Button in Create Strategy Wizard Page$")
    public void user_clicks_on_create_button_in_create_strategy_wizard_page() {
    	strategyDetailsPage.clickOnCreateButton();
    }
    
    @Then("^in Enter Strategy details page user should be able to select FA or FA Team Radio button$")
    public void in_enter_strategy_details_page_user_should_be_able_to_select_fa_or_fa_team_radio_button() {
        Action.pause(1000);
    	switch (strategyDetailsPage.checkFAorFATeamRadiobuttonselected()) {
		case "FA":
			Reporter.addStepLog("FA Radio button is selected and FA Team Radio button is not selected");
			break;
			
		case "FA Team":
			Reporter.addStepLog("FA Team is selected as default value for FA Selection");
			Assert.fail("FA Team is selected as default value for FA Selection");
			break;
			
		default:
			Reporter.addStepLog("FA or FA Tea Radio button is not selected");
			Assert.fail("FA or FA Tea Radio button is not selected");
			break;
		}
    	
    	strategyDetailsPage.selectFATeamRadioButton();
    	Action.pause(1000);
    	switch (strategyDetailsPage.checkforchangedFAorFATeamRadiobuttonselected()) {
		case "FA":
			Reporter.addStepLog("FA Team is not selected for FA Selection");
			Assert.fail("FA Team is not selected for FA Selection");
			break;
			
		case "FA Team":
			Reporter.addStepLog("FA Team is selected and FA Radio button is not selected");
			break;
			
		default:
			Reporter.addStepLog("FA or FA Tea Radio button is not selected");
			Assert.fail("FA or FA Tea Radio button is not selected");
			break;
		}
    	
    }

    @And("^FA or FA Team Name for (.+) for FA value should be unique$")
    public void fa_or_fa_team_name_for_for_fa_value_should_be_unique(String mandatorydetails) {
    	String uiValue = strategyDetailsPage.getFAValue("fa");
    	if(mandatorydetails.contains("Test")) {
    		sheetName = "Test";
    	}
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    	String givenValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 3);
    	Assert.assertTrue(uiValue.equals(givenValue));
    }

    @And("^FA or FA Team Name for (.+) for FA Team value should be unique$")
    public void fa_or_fa_team_name_for_for_fa_team_value_should_be_unique(String mandatorydetails) {
    	String uiValue = strategyDetailsPage.getFAValue("faTeam");
    	if(mandatorydetails.contains("Test")) {
    		sheetName = "Test";
    	}
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    	String givenValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 4);
    	Assert.assertTrue(uiValue.equals(givenValue));
    }
    
    @Then("^\"([^\"]*)\" should be autopopulated in Enter Strategy details Page in PMP Flow$")
    public void something_should_be_autopopulated_in_enter_strategy_details_page_in_pmp_flow(String label) {
    	String attributeValue = strategyDetailsPage.getattributeValuebylabel(label);
    	
    	Assert.assertTrue(Optional.ofNullable(attributeValue).isPresent(), "Attribute Value for label "+label+" is null");
    }
    
    @Then("^default value \"([^\"]*)\" should be autopopulated for \"([^\"]*)\" attribute Header in  Enter Starategy Deatils page$")
    public void default_value_something_should_be_autopopulated_for_something_attribute_header_in_enter_starategy_deatils_page(String defaultValue, String label) {
    	String attributeValue = strategyDetailsPage.getattributeValuebylabel(label);
    	
    	Assert.assertTrue(attributeValue.equals(defaultValue));
    }
    
    @Then("^value for \"([^\"]*)\" label should be \"([^\"]*)\" in Enter Strategy details Page$")
    public void value_for_something_label_should_be_something_in_enter_strategy_details_page(String label, String value) {
        String attributeValue = strategyDetailsPage.getattributeValuebylabel(label);
        Assert.assertTrue(attributeValue.toLowerCase().trim().equalsIgnoreCase(value.toLowerCase().trim()));
    }
    
    @Then("^FA Segment should be autopopulated based on (.+) in Enter Strategy details Page$")
    public void fa_segment_should_be_autopopulated_based_on_in_enter_strategy_details_page(String mandatorydetails) {
        String faSegmentfromUI = strategyDetailsPage.getFaSegmentValue();
        String faSegmentGiven = "";
        if(mandatorydetails.contains("FYPM")) {
        	faSegmentGiven = "1st Year PM";
        }
        if(mandatorydetails.contains("FAPM")) {
        	faSegmentGiven = "PM";
        }
        if(mandatorydetails.contains("SPM")) {
        	faSegmentGiven = "Senior PM";
        }
        if(mandatorydetails.contains("SeniorPMT")) {
        	faSegmentGiven = "Senior PM (Title Only)";
        }
        
        Assert.assertTrue(faSegmentfromUI.equals(faSegmentGiven));
    }
    
    @Then("^fa team count from DB and UI should match in Enter Strategy details Page$")
    public void fa_team_count_from_db_and_ui_should_match_in_enter_strategy_details_page() throws SQLException {
    	
    	Action.pause(1000);
    	strategyDetailsPage.selectFATeamRadioButton();
    	pmdb.DBConnectionStart();
    	
    	sheetName = "Query";
        String dbDataIterator = "testnull";
        
    	ResultSet rs;
    	
    	String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 8, 1);
		//SQLquery = SQLquery.replace("@data", "'"+replaceData+"'");
		rs= DBManager.executeSelectQuery(SQLquery);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 8, 2);
		
		while(rs.next()) {
			
				dbDataIterator = rs.getString(labelname);
				if(rs.wasNull() || dbDataIterator.isEmpty()) {
    				dbDataIterator = "0";
    			}
				
		 }
		//to handle Zero records from DB 
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "0";
		}
		
		int countInDB = Integer.parseInt(dbDataIterator);
    	int countInUI = strategyDetailsPage.getFATeamDropdownCount("faTeam");
    	
    	if(countInUI != countInDB) {
        	Assert.fail();
        }else {
        	Reporter.addStepLog("User is able to see FA Teams with discretionary Program name as PMP in Dropdown");
        }
    }
    
    @Then("^fa and fa team count from DB and UI should match in Enter Strategy details Page$")
    public void fa_and_fa_team_count_from_db_and_ui_should_match_in_enter_strategy_details_page() throws SQLException {
    	Action.pause(1000);
    	strategyDetailsPage.selectFARadioButton();
    	pmdb.DBConnectionStart();
    	
    	sheetName = "Query";
        String dbDataIterator = "testnull";
        
    	ResultSet rs;
    	String labelname = null, SQLquery = null;
    	if(SSOLoginPage.getRepCodes().equals("('AAA,999')")) {
    		SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 15, 1);
    		//SQLquery = SQLquery.replace("@data", SSOLoginPage.getRepCodes());
    		rs= DBManager.executeSelectQuery(SQLquery);
    		labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 15, 2);
    	}else {
    		SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 13, 1);
    		SQLquery = SQLquery.replace("@data", SSOLoginPage.getRepCodes());
    		System.out.println(SQLquery);
    		rs= DBManager.executeSelectQuery(SQLquery);
    		labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 13, 2);
    	}
		
		while(rs.next()) {
			
				dbDataIterator = rs.getString(labelname);
				if(rs.wasNull() || dbDataIterator.isEmpty()) {
    				dbDataIterator = "0";
    			}
				
		 }
		//to handle Zero records from DB 
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "0";
		}
		
		int countInDB = Integer.parseInt(dbDataIterator);
    	int countInUI = strategyDetailsPage.getFATeamDropdownCount("fa");
    	System.out.println("DB :" +countInDB);
    	System.out.println("UI :" +countInUI);
    	if(countInUI != countInDB) {
        	Assert.fail();
        }else {
        	Reporter.addStepLog("User is able to see FA Names with discretionary Program name as PMP in Dropdown");
        }
    	
    	Action.pause(1000);
    	strategyDetailsPage.selectFATeamRadioButton();
    	
    	sheetName = "Query";
        dbDataIterator = "testnull";
    	if(SSOLoginPage.getRepCodes().equals("('AAA,999')")) {
    		SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 8, 1);
    		//SQLquery = SQLquery.replace("@data", SSOLoginPage.getRepCodes());
    		rs= DBManager.executeSelectQuery(SQLquery);
    		labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 8, 2);
    	}else {
    		SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 14, 1);
    		SQLquery = SQLquery.replace("@data", SSOLoginPage.getRepCodes());
    		rs= DBManager.executeSelectQuery(SQLquery);
    		labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 14, 2);
    	}
    	
		
		while(rs.next()) {
			
				dbDataIterator = rs.getString(labelname);
				if(rs.wasNull() || dbDataIterator.isEmpty()) {
    				dbDataIterator = "0";
    			}
				
		 }
		//to handle Zero records from DB 
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "0";
		}
		
		countInDB = Integer.parseInt(dbDataIterator);
    	countInUI = strategyDetailsPage.getFATeamDropdownCount("faTeam");
    	System.out.println("DB :" +countInDB);
    	System.out.println("UI :" +countInUI);
    	if(countInUI != countInDB) {
        	Assert.fail();
        }else {
        	Reporter.addStepLog("User is able to see FA Teams with discretionary Program name as PMP in Dropdown");
        }
    }
    
    @Then("^FA Segment autopopulated should be highest default value among all FAs which are part of FA Team from (.+)$")
    public void fa_segment_autopopulated_should_be_highest_default_value_among_all_fas_which_are_part_of_fa_team_from(String mandatorydetails) throws SQLException {
    	if(mandatorydetails.contains("Test"))
    		sheetName = "Test";
    	
    	mandatorydetails = mandatorydetails + "_" + SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
    	String givenFATeamName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 4);
    	
    	String replaceData = givenFATeamName.trim();
    	
    	pmdb.DBConnectionStart();
    	
    	sheetName = "Query";
    	String dbDataIterator = "testnull";
		ArrayList<String> tempData = new ArrayList<String>();
		ResultSet rs;
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 10, 1);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 10, 2);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		rs = DBManager.executeSelectQuery(SQLquery);
		
		while (rs.next()) {

			dbDataIterator = rs.getString(labelname);
			if (rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
			tempData.add(dbDataIterator);

		}
		// to handle Zero records from DB
		if (dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		
		  if (tempData.size() > 1) { Collections.sort(tempData); dbDataIterator = "";
		  for (String G : tempData) {
			  
		        if(G.trim().toLowerCase().equals("PM")) {
		        	G = "FAPM";
		        }
		        if(mandatorydetails.equals("1st Year PM")) {
		        	G = "FYPM";
		        }
		        if(mandatorydetails.contains("Senior PM (Title Only)")) {
		        	G = "T-SeniorPMT";
		        }
		        
			  dbDataIterator = dbDataIterator + G + ",";
			  
		  }
		  
		  dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
		  
		  }
		 String valuefromDB = "";
		if(dbDataIterator.contains("Senior PM"))
	    {
				valuefromDB = "Senior PM";
	    }
		else if(dbDataIterator.contains("T-SeniorPMT"))
	    {
				valuefromDB = "Senior PM (Title Only)";
	    }
		else if(dbDataIterator.contains("FAPM"))
	    {
				valuefromDB = "PM";
	    }
		else if(dbDataIterator.contains("FYPM"))
	    {
				valuefromDB = "1st Year PM";
	    }
			  
		  
		String valueFromUI = strategyDetailsPage.getFaSegmentValue();
		
		 //System.out.println(valueFromUI); System.out.println(valuefromDB);
		
		Assert.assertTrue(valueFromUI.equals(valuefromDB));
    }
    
    @Then("^value for Structured Products Strategy label should be Yes in Enter Strategy details Page$")
    public void value_for_structured_products_strategy_label_should_be_yes_in_enter_strategy_details_page() {
    	String attributeValue = strategyDetailsPage.getStructuredProductsStrategyValue();
        Assert.assertTrue(attributeValue.toLowerCase().trim().equalsIgnoreCase("yes"));
    }
    
    @Then("^user should be able to see that the Label \"([^\"]*)\" is changed to \"([^\"]*)\" on Create PMP Enter Strategy Details page $")
    public void user_should_be_able_to_see_that_the_label_something_is_changed_to_something_on_create_pmp_enter_strategy_details_page(String strArg1, String strArg2) throws Throwable {
    	strategyDetailsPage.CheckingPMPTitle();
    }
    
}
