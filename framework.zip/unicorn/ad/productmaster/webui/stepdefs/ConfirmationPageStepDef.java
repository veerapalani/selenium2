package qa.unicorn.ad.productmaster.webui.stepdefs;
import cucumber.api.java.en.Then;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.validation.constraints.AssertTrue;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.framework.utils.Action;

public class ConfirmationPageStepDef {

	PMPageGeneric createdoclink = new PMPageGeneric("AD_PM_CreateDocumentLinkPage");
	PMPageGeneric viewdoclink = new PMPageGeneric("AD_PM_ViewDocumentLinkPage");
	PMPageGeneric viewcomment = new PMPageGeneric("AD_PM_ViewCommentPage");
	PMPageGeneric createcomment = new PMPageGeneric("AD_PM_CreateCommentsPage");
	PMPageGeneric review = new PMPageGeneric("AD_PM_ReviewPage");
	PMPageGeneric confirmation = new PMPageGeneric("AD_PM_ConfirmationPage");
	Action action =  new Action(SQLDriver.getEleObjData("AD_PM_ConfirmationPage"));;
	
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	
	@Then("^User should be able to see the \"([^\"]*)\" on Confirmation page$")
    public void user_should_be_able_to_see_the_something_on_confirmation_page(String Key) throws Throwable {
    	confirmation.verifyElement(Key);
    	Thread.sleep(1000);
    }
	

    @Then("^User should be able to see the Your request has been submitted on Confirmation page$")
    public void user_should_be_able_to_see_the_your_request_has_been_submitted_on_confirmation_page() throws Throwable {
        Assert.assertTrue(action.getElement("Your request has been submitted").isDisplayed());
        
    }
	
	@And("^User clicks on the \"([^\"]*)\" on Confirmation Page$")
    public void user_clicks_on_the_something_on_confirmation_page(String key) throws Throwable {
		confirmation.clickOnLink(key);
    }
}
