package qa.unicorn.ad.productmaster.webui.stepdefs;

import qa.unicorn.ad.productmaster.webui.pages.HOApprovalConfirmationPage;

public class HOApprovalConfirmationStepDef {
	
	HOApprovalConfirmationPage confirmationPage = new HOApprovalConfirmationPage("AD_PM_HOApprovalConfirmationPage");

}
