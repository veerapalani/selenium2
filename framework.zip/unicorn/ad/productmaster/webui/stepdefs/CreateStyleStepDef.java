package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;
public class CreateStyleStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString ;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	Alert alert;
	public static String styleName1, styleCode1 = null;
	
	CreateStylePage createstylepage = new CreateStylePage("AD_PM_CreateStylePage");
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	@Then("^User should be able to see the \"([^\"]*)\" on Create New Style page$")
    public void user_should_be_able_to_see_the_something_on_create_new_style_page(String Key) throws Throwable {
		createstylepage.verifyAttributesinCreateStylePage(Key);
    }
	
	@Then("^User should be able to see the below fields on Create New Style page$")
    public void user_should_be_able_to_see_the_below_fields_on_create_new_style_page(List<String> entity) throws Throwable {
		for(int i =0;i<entity.size();i++) {
			 createstylepage.verifyElementsoncreatestylepage(createstylepage.findElementByDynamicXpath("//*[text()='"+entity.get(i)+"']"));
			 Reporter.addScreenCapture();
		}
    }
	@And("^User clicks on Next Button on Create New Style Page$")
    public void user_clicks_on_next_button_on_create_new_style_page() throws Throwable {
		createstylepage.clickOnnextbuttononcreatestylepage();
    }
	@And("^User clicks on the (.+) attributes on Create New Style Page$")
	public void user_clicks_on_the_attributes_on_create_new_style_page(String key) throws Throwable {
		createstylepage.clickOntheelementsoncreatestylepage(key);
    }
	 @And("^User clicks on \"([^\"]*)\" on Create New Style Page$")
	    public void user_clicks_on_something_on_create_new_style_page(String key) throws Throwable {
		 createstylepage.clickOntheelementsoncreatestylepage(key);
	    }
	 @Then("^User should see maxlength for the following attributes should be according to the values mentioned$")
	    public void user_should_see_maxlength_for_the_following_attributes_should_be_according_to_the_values_mentioned(List<List<String>>entityValuePair) throws Throwable {
		 for (int i=0;i<entityValuePair.size();i++) {
		    	value = createstylepage.findElementByDynamicXpath("//*[@label='"+entityValuePair.get(i).get(0)+"']").getAttribute("maxlength");
		       Assert.assertEquals(entityValuePair.get(i).get(1), value);
		       Reporter.addStepLog("Actual value is" +entityValuePair.get(i).get(1));
		       Reporter.addStepLog("Expected value is" +value);
		       }
	 }
	 @Then("^User should be able to see the bottom-border below \"([^\"]*)\" on Create New Style page$")
	    public void user_should_be_able_to_see_the_bottomborder_below_something_on_create_new_style_page(String key) throws Throwable {
		 String widthInPixel = createstylepage.giveCssValuehere(createstylepage.getElement(key),
					"border-bottom-width");
			String width = widthInPixel.substring(0, widthInPixel.length() - 2);
			Assert.assertTrue(Integer.parseInt(width) > 0);
	    }
	 @Then("^User should be able to see the Timestamp on Create New Style page$")
	    public void user_should_be_able_to_see_the_timestamp_on_create_new_style_page() throws Throwable {
		 createstylepage.verifytimestampinCreateStylePage();
	    }
	 @Then("^User should be able to see the \"([^\"]*)\" should be in disabled state on Create New Style page$")
	    public void user_should_be_able_to_see_the_something_should_be_in_disabled_state_on_create_new_style_page(String key) throws Throwable {
		 //createstylepage.verifyElementFromShadowRootdisabled(key);
	    }
	 @Then("^User should be able to see the Status field should be in disabled state on Create New Style page$")
	    public void user_should_be_able_to_see_the_status_field_should_be_in_disabled_state_on_create_new_style_page() throws Throwable {
		 createstylepage.verifystatusfieldincreatestylepage();
	    }
	 @Then("^user should be able to see the following attributes below the header on Create New Style page$")
	    public void user_should_be_able_to_see_the_following_attributes_below_the_header_on_create_new_style_page(List<String> entity) throws Throwable {
		 for(int i =0;i<entity.size();i++) {
			 createstylepage.verifyElementsoncreatestylepage(createstylepage.findElementByDynamicXpath("//p[contains(text(),'"+entity.get(i)+"')]"));
			 Reporter.addScreenCapture();
		}
	    }
	 @Then("^user should be able to see the below attributes on Create New Style page$")
	    public void user_should_be_able_to_see_the_below_attributes_on_create_new_style_page(List<String> entity) throws Throwable {
		 for(int i =0;i<entity.size();i++) {
			 createstylepage.verifyElementsoncreatestylepage(createstylepage.findElementByDynamicXpath("//*[@label='"+entity.get(i)+"']"));
				Reporter.addStepLog("able to see "+entity.get(i)+" header");
				}
				Reporter.addScreenCapture();
	    }
	 @Then("^User should be able to see following fields with the \"([^\"]*)\" symbol on Create Style page$")
	    public void user_should_be_able_to_see_following_fields_with_the_something_symbol_on_create_style_page(String attribute,List<String> entity) throws Throwable {
		 for(int i =0;i<entity.size();i++) {
	        	myElement = createstylepage.findElementByDynamicXpath("//*[@label='\"+entity.get(i)+\"']");
	        	createstylepage.verifyAttribute("true", myElement, attribute);
	        }
	    }
	 @Then("^the below attributes on Create Style Flyout should have Yes and No Options in Create Style Page$")
	    public void the_below_attributes_on_create_style_flyout_should_have_yes_and_no_options_in_create_style_page(List<String>entity) throws Throwable {
		 String[] listOfValues = {"yes","no"};
			for(int i = 0;i<entity.size();i++){
				listOfString = new ArrayList<String>();
				Reporter.addStepLog("//*[@label='"+entity.get(i)+"']/wf-radio-option");
				listOfElements = createstylepage.findElementsByDynamicXpath("//*[@label='"+entity.get(i)+"']/wf-radio-option");
				Reporter.addStepLog(Integer.toString(listOfElements.size()));
				Reporter.addStepLog(listOfElements.get(0).getAttribute("value"));
				for(int j=0;j<listOfElements.size();j++) {
					listOfString.add(listOfElements.get(j).getAttribute("value"));
				}
				for(int j=0;j<listOfValues.length;j++) {
					Assert.assertTrue(listOfString.contains(listOfValues[j]));
					Reporter.addStepLog("the value "+listOfValues[j]+" is present in "+entity.get(i));
				}
			}
	    }
	 @And("^User enters the following values in the following text fields on Create Style Page$")
	    public void user_enters_the_following_values_in_the_following_text_fields_on_create_style_page(List<List<String>> entityValuePair) throws Throwable {
		 Long time = Calendar.getInstance().getTimeInMillis();
			for(int i=0;i<entityValuePair.size();i++) {
				myElement = createstylepage.getDynamicElementFromShadowRoot("return document.querySelector(\"[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('input')");
				
				if(entityValuePair.get(i).get(0).equals("Style Code")) {
					
					value  = entityValuePair.get(i).get(1)+time;
					styleCode1 = value;
	        	}
				else if(entityValuePair.get(i).get(0).equals("Min Amount"))
				{
					value  = entityValuePair.get(i).get(1);
				}else if(entityValuePair.get(i).get(0).equalsIgnoreCase("style name")) {
					value  = entityValuePair.get(i).get(1)+time;
					styleName1 = value;
				}
				else{
					
					value  = entityValuePair.get(i).get(1)+time;
					//styleName1 = value+time;
				}
				createstylepage.sendKeys(value, myElement);
				createstylepage.UIPassedValues.put(entityValuePair.get(i).get(0),value);
	        }
	    }
	 @And("^User enters the following values in the following dropdowns on Create Style Page$")
	    public void user_enters_the_following_values_in_the_following_dropdowns_on_create_style_page(List<List<String>> entityValuePair) throws Throwable {
		 for(int i=0;i<entityValuePair.size();i++) {
	    		Reporter.addStepLog("return document.querySelector(\"brml-select[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('wf-input')");
	        	myElement = createstylepage.getDynamicElementFromShadowRoot("return document.querySelector(\"brml-select[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('wf-input')");
	        	createstylepage.scrollAndClickOnLink(myElement);
	        	Reporter.addStepLog("return document.querySelector(\"[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"li[data-value='\\\""+entityValuePair.get(i).get(1)+"\\\"']\")");
	        	createstylepage.getDynamicElementFromShadowRoot("return document.querySelector(\"brml-select[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('wf-tooltip > div > div > wf-dropdown > ul > li:nth-child(2) > a')").click();
	        	createstylepage.UIPassedValues.put(entityValuePair.get(i).get(0),entityValuePair.get(i).get(1));
	    	}  
	    }
	 
	 @And("^user clicks the \"([^\"]*)\" icon from dropdown of Create Style Page$")
	    public void user_clicks_the_something_icon_from_dropdown_of_create_style_page(String key) throws Throwable {
		 createstylepage.clickOnjsLink(createstylepage.getElementFromShadowRoot(key));

			Thread.sleep(1000);
	    }
	 @And("^user selects the Program Value from dropdown of Create Style Page$")
	    public void user_selects_the_program_value_from_dropdown_of_create_style_page() throws Throwable {
		 landingPage1.clickOnprogdropdownlink();
		 landingPage1.selectprogramvalue();
	    }
	    @And("^user selects the \"([^\"]*)\" from dropdown of Create Style Page$")
	    public void user_selects_the_something_from_dropdown_of_create_style_page(String key) throws Throwable {
	    	createstylepage.clickOnjsLink(createstylepage.getElementFromShadowRoot(key));

			Thread.sleep(1000);
	    }
	 @And("^User enters the following values in the following radio buttons on Create Style Page$")
	    public void user_enters_the_following_values_in_the_following_radio_buttons_on_create_style_page(List<List<String>> entityValuePair) throws Throwable {
		 Thread.sleep(1000);
	    	for(int i=0;i<entityValuePair.size();i++) {
	    		if (entityValuePair.get(i).get(1).equals("yes")) {
	    			Reporter.addStepLog("return document.querySelector(\"wf-radio[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"wf-tooltip div div button[data-index='0']\")");
	    			myElement = createstylepage.getDynamicElementFromShadowRoot("return document.querySelector(\"brml-radio[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"wf-tooltip div div div button\")");
	    			myElement.click();
	    		}
	    		else if(entityValuePair.get(i).get(1).equals("no")) {
	    			Reporter.addStepLog("return document.querySelector(\"wf-radio[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"wf-tooltip div div button[data-index='1']\")");
	    			myElement = createstylepage.getDynamicElementFromShadowRoot("return document.querySelector(\"brml-radio[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"wf-tooltip div div div button\")");
	    			myElement.click();
	    		}
	    	}
	    }
	 @And("^User enters the following values in the following date calenders on Create Style Page$")
	    public void user_enters_the_following_values_in_the_following_date_calenders_on_create_style_page(List<String> entityValuePair) throws Throwable {
		 for(int i=0;i<entityValuePair.size();i++) {
	    		Reporter.addStepLog("return document.querySelector(\"[label='"+entityValuePair.get(i)+"']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
	    		WebElement date=createstylepage.getDynamicElementFromShadowRoot("return document.querySelector(\"[label='"+entityValuePair.get(i)+"']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
	    		createstylepage.scrollAndClickOnLink(date);
	    		Reporter.addStepLog("return document.querySelector(\"[label='"+entityValuePair.get(i)+"']\").shadowRoot.querySelectorAll('div.pmu-days div')");
	    		listOfElements = createstylepage.getDynamicElementsFromShadowRoot("return document.querySelector(\"[label='"+entityValuePair.get(i)+"']\").shadowRoot.querySelectorAll('div.pmu-days div')");
	    		   
	    		   for (int j=0;j<listOfElements.size();j++) {
	    			   if(listOfElements.get(j).getText().equals("21"))
	    			   {
	    				   listOfElements.get(j).click();
	    				   Reporter.addStepLog("clicked on date ");
	    				   Reporter.addScreenCapture();
	    				   break;
	    			   }
	    		   }
	    	}
	    }
	 @Then("^the attributes on Create Style Page should contain all of the below following values$")
	    public void the_attributes_on_create_style_page_should_contain_all_of_the_below_following_values(List<List<String>> entityValuePair) throws Throwable {
		 for(int i=0;i<entityValuePair.size();i++) {
				String[] listOfValues ;
				listOfString = new ArrayList<String>();
				listOfValues = entityValuePair.get(i).get(1).split(",");
				listOfElements = createstylepage.findElementsByDynamicXpath("//*[@label='"+entityValuePair.get(i).get(0)+"']/wf-select-option");
				
				for(int j=0;j<listOfElements.size();j++) {
					listOfString.add(listOfElements.get(j).getAttribute("name"));
					
				}
				for(int j=0;j<listOfValues.length;j++) {
					Assert.assertTrue(listOfString.contains(listOfValues[j]));
					Reporter.addStepLog("the value "+listOfValues[j]+" is present in "+entityValuePair.get(i).get(0));
				}
				
			}
	    }
    }

