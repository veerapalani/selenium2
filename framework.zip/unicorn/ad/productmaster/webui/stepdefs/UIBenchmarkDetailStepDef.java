package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class UIBenchmarkDetailStepDef {

	Action action = new Action(SQLDriver.getEleObjData("AD_PM_BenchmarkDetailPage"));
	PMPageGeneric BenchmarkDetail = new PMPageGeneric("AD_PM_BenchmarkDetailPage");
	String activeLink = "Strategy";
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL=SSOLoginPage.URL+"#/benchmark/view";
	String expectedColorCode, xpath;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	
	
	@And("^User clicks the Edit Button on Benchmark Detail page$")
    public void user_clicks_the_edit_button_on_benchmark_detail_page() throws Throwable {
        action.click(action.getElement("Edit Button"));
        Reporter.addStepLog("clicked on Edit button");
    }

	 @Then("^user should be able to go to Benchmark Detail page$")
	    public void user_should_be_able_to_go_to_benchmark_detail_page() throws Throwable {
	    	Assert.assertTrue(action.getCurrentURL().contains(pageURL));
	    	Reporter.addStepLog("We are in BenchmarkDetailPage");
	    	Reporter.addScreenCapture();
	    }
	
	

	@Then("^User should be able to see the \"([^\"]*)\" header on Benchmark Detail page$")
	public void user_should_be_able_to_see_the_something_header_on_benchmark_detail_page(String key) {
		BenchmarkDetail.verifyHeader(key);
	}

	@And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Benchmark Detail page$")
	public void something_should_be_displayed_in_something_color_on_benchmark_detail_page(String key,
			String expectedColor) {
		expectedColorCode = Action.getTestData(expectedColor);
		BenchmarkDetail.verifyColor(key, expectedColorCode);
	}
	
	@And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Benchmark Detail page$")
    public void something_should_be_displayed_in_something_color_inside_benchmark_detail_page(String key,
			String expectedColor) throws Throwable {
		expectedColorCode = Action.getTestData(expectedColor);
		BenchmarkDetail.verifyColor(BenchmarkDetail.getElementFromShadowRoot(key), expectedColorCode);
    }

	@And("^User should be able to see the \"([^\"]*)\" on Benchmark Detail page$")
	public void user_should_be_able_to_see_the_something_on_benchmark_detail_page(String key) throws Throwable {

		BenchmarkDetail.verifyElement(key);

	}
	
	@Then("^User should be able to see the \"([^\"]*)\" inside Benchmark Detail page$")
    public void user_should_be_able_to_see_the_something_inside_benchmark_detail_page(String key) throws Throwable {
		BenchmarkDetail.verifyElement(BenchmarkDetail.getElementFromShadowRoot(key));
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Benchmark Detail page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_inside_benchmark_detail_page(String ghostText, String searchBox) throws Throwable {
    	BenchmarkDetail.verifyGhostText(ghostText, BenchmarkDetail.getElementFromShadowRoot(searchBox));
    }

	@And("^Format of the \"([^\"]*)\" on Benchmark Detail page should be \"([^\"]*)\"$")
	public void format_of_the_on_benchmark_details_page_should_be(String key, String format) {
		String actualFormat = BenchmarkDetail.getElement(key).getText().substring(0, 19);
		Reporter.addStepLog("Actual TIme Stamp- " + actualFormat);

		BenchmarkDetail.verifyFormat(actualFormat, Action.getTestData(format));
	}


    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Benchmark Detail page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_benchmark_detail_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
    	BenchmarkDetail.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = BenchmarkDetail.getElementsFromShadowRoot(key);
   	 BenchmarkDetail.verifyTextInListOfElements( items.get(i),listOfElements);  
        } 
    }

	@Then("^User should be able to see the bottom-border below \"([^\"]*)\" on Benchmark Detail page$")
	public void user_should_be_able_to_see_the_bottomborder_below_something_on_benchmark_detail_page(String key)
			throws Throwable {
		String widthInPixel = BenchmarkDetail.giveCssValue(BenchmarkDetail.getElement(key), "border-bottom-width");
		String width = widthInPixel.substring(0, widthInPixel.length() - 2);
		Assert.assertTrue(Integer.parseInt(width) > 0);
	}

	@And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Benchmark Detail page$")
	public void that_something_should_be_displayed_in_something_color_on_benchmark_detail_page(String strArg1,
			String expectedColor) {
		expectedColorCode = Action.getTestData(expectedColor);
		BenchmarkDetail.verifyCurrentElementColor(expectedColorCode);
	}

	@Then("^user should be able to see the following attributes on Benchmark Detail page$")
	public void user_should_be_able_to_see_the_following_attributes_on_benchmark_detail_page(List<String> attributes) {
		listOfElements = BenchmarkDetail.getElements("Attributes");
		for (int i = 0; i < attributes.size(); i++) {
			BenchmarkDetail.verifyTextInListOfElements(attributes.get(i), listOfElements);
		}
	}

	@And("^user clicks the \"([^\"]*)\" on Benchmark Detail page$")
	public void user_clicks_the_something_on_benchmark_detail_page(String key) throws Throwable {
		
		BenchmarkDetail.clickOnLink(key);
		Reporter.addStepLog("clicked on "+key);
	}

	@Then("^The attributes on Benchmark Detail page should contain one of the following values$")
	public void the_attributes_on_benchmark_detail_page_should_contain_one_of_the_following_values(
			List<List<String>> attributeValuePair) {
		String myValue = null;

		for (int i = 0; i < attributeValuePair.size(); i++) {
			String xpath = "//small[contains(text(),'" + attributeValuePair.get(i).get(0)
					+ "')]/ancestor::p/following-sibling::span";
			myValue = BenchmarkDetail.findElementByDynamicXpath(xpath).getText();
			Reporter.addStepLog("The value for " + attributeValuePair.get(i).get(0) + " is " + myValue);
			String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
			for (int j = 0; j < listOfValues.length; j++) {
				if (myValue.equals(listOfValues[j])) {
					Assert.assertTrue(true);
					break;
				}

				else
					Assert.assertFalse(true);

			}
		}
	}

	@Then("^The value on Benchmark Detail page of the following attributes should be in \"([^\"]*)\" format$")
	public void the_value_on_benchmark_detail_page_of_the_following_attributes_should_be_in_something_format(
			String format, List<String> attributes) {
		String myValue = null;
		for (int i = 0; i < attributes.size(); i++) {
			String xpath = "//small[contains(text(),'" + attributes.get(i) + "')]/ancestor::p/following-sibling::span";
			myValue = BenchmarkDetail.findElementByDynamicXpath(xpath).getText();
			Reporter.addStepLog("validating for " + attributes.get(i) + " with value " + myValue);
			if (!myValue.equals(""))
				BenchmarkDetail.verifyFormat(myValue, Action.getTestData(format));

		}
	}
	
	 @And("^compare the string values given in API and the values displayed in UI in Benchmark Detail page$")
	    public void compare_the_string_values_given_in_api_and_the_values_displayed_in_ui_in_benchmark_detail_page(List<List<String>> APIUIAttributePair) throws Throwable {
		 String APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().get(APIUIAttributePair.get(i).get(0));
		  xpath="//small[text()='"+APIUIAttributePair.get(i).get(1)+"']/ancestor::p/following-sibling::span";
		 UIValue=BenchmarkDetail.findElementByDynamicXpath(xpath).getText();
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value for "+APIUIAttributePair.get(i).get(1)+"  is "+UIValue); 
		 }
		 Reporter.addScreenCapture();
	    }
	 
	 @And("^compare the numeric values given in API and the values displayed in UI in Benchmark Detail page$")
	    public void compare_the_numeric_values_given_in_api_and_the_values_displayed_in_ui_in_benchmark_detail_page(List<List<String>> APIUIAttributePair) throws Throwable {
		 float APIValue,UIValue;
		 for(int i=0;i<APIUIAttributePair.size();i++) {
		APIValue = ProductMasterGeneric.response.jsonPath().getFloat(APIUIAttributePair.get(i).get(0));
		  xpath="//small[text()='"+APIUIAttributePair.get(i).get(1)+"']/ancestor::p/following-sibling::span";
		 UIValue=Float.parseFloat(BenchmarkDetail.findElementByDynamicXpath(xpath).getText());
		 Assert.assertEquals(UIValue, APIValue);
		 Reporter.addStepLog("verified that the value for "+APIUIAttributePair.get(i).get(1)+"  is "+UIValue); 
		 }
		 Reporter.addScreenCapture();
	    }
	 
	 @Then("^User should not be able to see the \"([^\"]*)\" in the \"([^\"]*)\" on Benchmark Detail page$")
	    public void user_should_not_be_able_to_see_the_something_in_the_something_on_benchmark_detail_page(String text, String key) throws Throwable {
		 BenchmarkDetail.verifyTextNotPresentInListOfElements(text, BenchmarkDetail.getElements(key));
	    }
//	    @And("^\"([^\"]*)\" should have \"([^\"]*)\" background color on Benchmark Detail page$")
//	    public void something_should_have_something_background_color_on_benchmark_detail_page(String key, String backgroundColor) {
//	    	expectedColorCode = Action.getTestData(backgroundColor);
//	    	BenchmarkDetail.verifyBackgroundColor(key,expectedColorCode);
//	    }
	 
	 @And("^The text written in \"([^\"]*)\" should match with the value of \"([^\"]*)\" attribute on Benchmark Detail page$")
	    public void the_text_written_in_something_should_match_with_the_value_of_something_attribute_on_benchmark_detail_page(String actualKey, String expectedKey) throws Throwable {
		 Assert.assertEquals(BenchmarkDetail.getText(actualKey), BenchmarkDetail.getText(expectedKey));
		 Reporter.addStepLog("validated the "+actualKey);
	    }
	 
	 @Then("^User should be able to go to Benchmark Details page$")
	    public void user_should_be_able_to_go_to_benchmark_details_page() throws Throwable {
		 Thread.sleep(1000);
		 Reporter.addStepLog("the page URL is "+BenchmarkDetail.getPageURL());
	       Assert.assertTrue(BenchmarkDetail.getPageURL().contains(pageURL));
	       Reporter.addStepLog("We have landed to Benchmark Detail page");
	       Reporter.addScreenCapture();
	    }

}
