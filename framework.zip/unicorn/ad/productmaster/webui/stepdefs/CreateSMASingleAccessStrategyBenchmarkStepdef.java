package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreateSMASingleAccessStrategyBenchmarkStepdef {
	
	CreateSMASingleAccessStrategyBenchmarkPage benchmarkPage = new CreateSMASingleAccessStrategyBenchmarkPage("AD_PM_CreateSMASingleAccessStrategyBenchmarkPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	
	public static int defaultbenchmarkcount;
	
	@And("^User inputs (.+) in Benchmark Page$")
    public void user_inputs_in_benchmark_page(String mandatorydetails) throws SQLException, IOException {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		//sheet = exlObj.getSheet(sheetName);
		
		//String environment = property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		
		String unbundledNodeId = (String) exlObj.getCellData(sheet, rowIndex, 43);
		String unbundledNodeIdPercentage = (String) exlObj.getCellData(sheet, rowIndex, 44).toString();
		String benchmarkCategory = (String) exlObj.getCellData(sheet, rowIndex, 45);
		String benchmark = (String) exlObj.getCellData(sheet, rowIndex, 46).toString();
		String benchmarkPercentage = (String) exlObj.getCellData(sheet, rowIndex, 47).toString();
		String customBenchmarkReason = (String) exlObj.getCellData(sheet, rowIndex, 48);
		exlObj.closeWorkBook();
		
		
		
		
		if(unbundledNodeId != "") {
			
			int i =0;
			sheetName = "VariablePaths";
			sheet = exlObj.getSheet(sheetName);
			String locatorValueUnbundledNodeId = (String) exlObj.getCellData(sheet, 7, 1);
			String locatorValueUnbundledNodeIdHighlight = (String) exlObj.getCellData(sheet, 8, 1);
			String locatorValueUnbundledNodeIdPercentage = (String) exlObj.getCellData(sheet, 9, 1);
			
			if(unbundledNodeId.contains(",")) {
				
				String[] unBundle = unbundledNodeId.split(",");
				String[] percent = unbundledNodeIdPercentage.split(",");
				int size = unBundle.length;
				
				
				
				while(size > 0) {
					benchmarkPage.enterUnbundledNodeId(locatorValueUnbundledNodeId.replace("@data",i+"'"), locatorValueUnbundledNodeIdHighlight.replace("@data",i+"'"), unBundle[i], i);
					benchmarkPage.enterUnbundledNodeIdPercentage(locatorValueUnbundledNodeIdPercentage.replace("@data",i+"'"), percent[i], i);
					i++;
					size--;
					if(size>0) {
						benchmarkPage.addAssetClassification();
					}
				}
			}
			else {
				
					benchmarkPage.enterUnbundledNodeId(locatorValueUnbundledNodeId.replace("@data",i+"'"), locatorValueUnbundledNodeIdHighlight.replace("@data",i+"'"), unbundledNodeId, i);
					benchmarkPage.enterUnbundledNodeIdPercentage(locatorValueUnbundledNodeIdPercentage.replace("@data",i+"'"), unbundledNodeIdPercentage, i);
					
			}
			
		}
		
		if(benchmarkCategory != "") {
			
			switch (benchmarkCategory) {
			case "Custom":
				benchmarkPage.selectCustom();
				if(benchmark != "") {
					
					int i =0;
					sheetName = "VariablePaths";
					sheet = exlObj.getSheet(sheetName);
					
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
					String locatorValueCustomBenchmark = (String) exlObj.getCellData(sheet, 4, 1);
					String locatorValueCustomBenchmarkHighlight = (String) exlObj.getCellData(sheet, 5, 1);
					String locatorValueCustomBenchmarkPercentage = (String) exlObj.getCellData(sheet, 6, 1);
					
					if(benchmark.contains(",")) {
						String[] customBenchmark = benchmark.split(",");
						String[] customBenchmarkPercentage = benchmarkPercentage.split(",");
						int size = customBenchmark.length;

						
						while(size > 0) {
							benchmarkPage.enterCustomBenchmark(locatorValueCustomBenchmark.replace("@data",i+"'"), locatorValueCustomBenchmarkHighlight.replace("@data",i+"'"), customBenchmark[i], benchmarkCategory, i);
							benchmarkPage.enterCustomBenchmarkPercentage(locatorValueCustomBenchmarkPercentage.replace("@data",i+"'"), customBenchmarkPercentage[i], benchmarkCategory, i);
							i++;
							size--;
							if(size>0) {
								benchmarkPage.addNewBenchmark();
							}
						}
					}
					else {
					
						benchmarkPage.enterCustomBenchmark(locatorValueCustomBenchmark.replace("@data",i+"'"), locatorValueCustomBenchmarkHighlight.replace("@data",i+"'"), benchmark, benchmarkCategory, i);
						benchmarkPage.enterCustomBenchmarkPercentage(locatorValueCustomBenchmarkPercentage.replace("@data",i+"'"), benchmarkPercentage, benchmarkCategory, i);
				
					}
					
				}
				
				if(customBenchmarkReason != "") {
					benchmarkPage.enterCustomBenchmarkReason(customBenchmarkReason);
				}
				break;
				
			case "Default":
				
				benchmarkPage.clickOnViewDetails();
				assertTrue(benchmarkPage.isDefaultValueAutopopulated(mandatorydetails));
				benchmarkPage.clickOnCrossIcon();
				break;

			default:
				break;
			}
			
		}
    }
	
	@When("User Clicks on Next in Benchmark page")
	public void user_Clicks_on_Next_in_Benchmark_page() {
	    benchmarkPage.clickOnNext();
	}
	
	@And("^User selects Custom Benchmark in Benchmark Page$")
    public void user_selects_custom_benchmark_in_benchmark_page() {
		benchmarkPage.selectCustom();
        
    }
	
	@Then("^User should not be able to move to next page from Benchmark Page$")
    public void user_should_not_be_able_to_move_to_next_page_from_benchmark_page() {
        assertTrue(benchmarkPage.isUserOnBenchmarkPage());
    }
	
	@And("^User is in Benchmark page of Create SMA Single Access flow$")
    public void user_is_in_benchmark_page_of_create_sma_single_access_flow() {
		assertTrue(benchmarkPage.isUserOnBenchmarkPage());
    }
	
	@Then("^in Benchmark Page all Active Benchmarks should be populated in Benchmark dropdown$")
    public void in_benchmark_page_all_active_benchmarks_should_be_populated_in_benchmark_dropdown() throws SQLException, IOException {
		
        benchmarkPage.selectCustom();
        
        sheetName = "VariablePaths";
        sheet = exlObj.getSheet(sheetName);
		
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String locatorValueCustomBenchmark = (String) exlObj.getCellData(sheet, 4, 1);
		String locatorValueCustomBenchmarkHighlight = (String) exlObj.getCellData(sheet, 5, 1);
		int i=0;
        
        
        assertTrue(benchmarkPage.checkActiveBenchmarkCount(locatorValueCustomBenchmark.replace("@data",i+"'"),locatorValueCustomBenchmarkHighlight.replace("@data",i+"'")));
    }
	
	@Then("^in Benchmark Page with (.+) Unbundled NodeID Filed should be User determined$")
    public void in_benchmark_page_with_unbundled_nodeid_filed_should_be_user_determined(String mandatorydetails) throws IOException {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
        benchmarkPage.clickOnNext();
        
        assertTrue(benchmarkPage.isUserOnBenchmarkPage());
        Reporter.addStepLog("User after Clicking on Next is not moving to next page");
        
        String expError = (String) exlObj.getCellData(sheet, rowIndex, 81);
    	assertTrue(benchmarkPage.error(expError));
    	
    	Reporter.addEntireScreenCaptured();
        
    }
	@Then("^in Benchmark Page user should not be able to add more unbundled node ids than the max limit$")
    public void in_benchmark_page_user_should_not_be_able_to_add_more_unbundled_node_ids_than_the_max_limit() {
        assertTrue(benchmarkPage.isAddNewAssetClassificaationOptionNotVisible());
    }
	
	@Then("^in Benchmark Page user should not be able to add more Custom Benchmarks than the max limit$")
    public void in_benchmark_page_user_should_not_be_able_to_add_more_custom_benchmarks_than_the_max_limit() {
        assertTrue(benchmarkPage.isAddNewBenchmarkOptionNotVisible());
    }
	
	@Then("^User with (.+) should be able to see Default Benchmarks autopopulated under Benchmark$")
    public void user_with_should_be_able_to_see_default_benchmarks_autopopulated_under_benchmark(String mandatorydetails) throws SQLException {
		/*
		benchmarkPage.clickOnViewDetails();
		assertTrue(benchmarkPage.isDefaultValueAutopopulated(mandatorydetails +"_"+ SSOLoginPage.UIEnvironment.trim().toLowerCase()));
		benchmarkPage.clickOnCrossIcon();
		*/

		
		String primaryBenchmarkValue = benchmarkPage.getPrimaryBenchmarkValue();
		//System.out.println("CreateSMASingleAccessStrategyReviewStepdef::"+primaryBenchmarkValue);
		String defaultBenchmarkName ="";
		defaultbenchmarkcount = 0;
		if(primaryBenchmarkValue.contains(",")) {
			Reporter.addStepLog("In SMA Single Access - Default Benchmark cannot have two Benchmarks associated");
			defaultbenchmarkcount++;
		}
		else {
			String[] data = primaryBenchmarkValue.split("-#-");
			defaultBenchmarkName = data[2];
		}
		//get DB Query
		sheetName = "Query";
		sheet = exlObj.getSheet(sheetName);
		String SQLquery = (String) exlObj.getCellData(sheet, 1, 1);
		String labelname = (String) exlObj.getCellData(sheet, 1, 2);
		
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
			mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		}
		
		//get investment style name
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		
		pmdb.DBConnectionStart();
		SQLquery = SQLquery.replace("@data", "'"+investmentStyleName+"'");
		ResultSet rs;
		rs= DBManager.executeSelectQuery(SQLquery);
		String dbDataIterator = null;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			
		 }
		pmdb.DBConnectionClose();
		exlObj.closeWorkBook();
		
		//comparing only Benchmark Name as Percentage will be 100 for default
		if(dbDataIterator.equals(defaultBenchmarkName)) {
			Reporter.addStepLog("Default Benchmark Name Value displayed in Review Page matches with Value in DB");
		}
		else {
			defaultbenchmarkcount++;
			Reporter.addStepLog("Default Benchmark Name Value displayed in Review Page does not match with Value in DB");
		}
		
		
        
    
    }
	
	@And("^User with the (.+) inputs other than benchmark details in Benchmark Page$")
    public void user_with_the_inputs_other_than_benchmark_details_in_benchmark_page(String mandatorydetails) throws IOException {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		//sheet = exlObj.getSheet(sheetName);
		
		//String environment = property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}
		
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		
		String unbundledNodeId = (String) exlObj.getCellData(sheet, rowIndex, 43);
		String unbundledNodeIdPercentage = (String) exlObj.getCellData(sheet, rowIndex, 44).toString();
		exlObj.closeWorkBook();
		
		
		
		
		if(unbundledNodeId != "") {
			
			int i =0;
			sheetName = "VariablePaths";
			sheet = exlObj.getSheet(sheetName);
			
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
			String locatorValueUnbundledNodeId = (String) exlObj.getCellData(sheet, 7, 1);
			String locatorValueUnbundledNodeIdHighlight = (String) exlObj.getCellData(sheet, 8, 1);
			String locatorValueUnbundledNodeIdPercentage = (String) exlObj.getCellData(sheet, 9, 1);
			
			if(unbundledNodeId.contains(",")) {
				
				String[] unBundle = unbundledNodeId.split(",");
				String[] percent = unbundledNodeIdPercentage.split(",");
				int size = unBundle.length;
				
				
				
				while(size > 0) {
					benchmarkPage.enterUnbundledNodeId(locatorValueUnbundledNodeId.replace("@data",i+"'"), locatorValueUnbundledNodeIdHighlight.replace("@data",i+"'"), unBundle[i], i);
					benchmarkPage.enterUnbundledNodeIdPercentage(locatorValueUnbundledNodeIdPercentage.replace("@data",i+"'"), percent[i], i);
					i++;
					size--;
					if(size>0) {
						benchmarkPage.addAssetClassification();
					}
				}
			}
			else {
				
					benchmarkPage.enterUnbundledNodeId(locatorValueUnbundledNodeId.replace("@data",i+"'"), locatorValueUnbundledNodeIdHighlight.replace("@data",i+"'"), unbundledNodeId, i);
					benchmarkPage.enterUnbundledNodeIdPercentage(locatorValueUnbundledNodeIdPercentage.replace("@data",i+"'"), unbundledNodeIdPercentage, i);
					
			}
			
		}
    }
	
	@And("^User should be able to see Benchmark details Page in Create SMA SA Flow$")
    public void user_should_be_able_to_see_benchmark_details_page_in_create_sma_sa_flow() {
		Assert.assertTrue(benchmarkPage.isUserOnBenchmarkPage());
    }

    @And("^User Edits the Benchmarks in Benchmark page in Create SMA SA Flow$")
    public void user_edits_the_benchmarks_in_benchmark_page_in_create_sma_sa_flow() {
    	benchmarkPage.deleteallcustomBenchmarks();
    }

    @And("^User clicks on Previous Button in Benchmark page in Create SMA SA Flow$")
    public void user_clicks_on_previous_button_in_benchmark_page_in_create_sma_sa_flow() {
    	benchmarkPage.clickOnPrevious();
    }
    
    @Then("^User should be able to see added benchmarks from (.+) are sorted in descending order in Benchmark Page in Create SMA SA Flow$")
    public void user_should_be_able_to_see_added_benchmarks_from_are_sorted_in_descending_order_in_benchmark_page_in_create_sma_sa_flow(String mandatorydetails) {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String benchmark,benchmarkPercentage= "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 46);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 47);
		}
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			benchmarkfromUI = benchmarkPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = benchmarkPage.getPercentageithValuefromUI(j);
			
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey));
			j++;
			
		}
    }

	private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
		Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		//sort based on benchmark names first to handle Equal Percentage scenario in ascending order
		Collections.sort(entryList, (o1, o2) -> o1.getKey().split(" - ")[1].trim().compareTo(o2.getKey().split(" - ")[1].trim()));
		
		//sort based on benchmark percentage in descending order
		Collections.sort(entryList, (o1, o2) -> {
			if(o1.getValue() > o2.getValue()) {
				return -1;
			}else if(o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});
		
		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
			@Override
			public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
				if(o1.getValue() > o2.getValue()) {
					return -1;
				}else if(o1.getValue() < o2.getValue()) {
					return 1;
				}
				return 0;
			}
		});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		  for (String countryKey : sortedHashMap.keySet()) {
		  System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		  
		  }*/
		 
		return sortedHashMap;
	}
	
	@Then("^User should be able to view DVP/Key Trust template field on Benchmark and Asset Classification page while creating SMA single access$")
    public void user_should_able_to_view_dvpKey_trust_template_field_on_benchmark_and_asset_classification_page_while_creating_sma_single_access() {
        assertTrue(benchmarkPage.isDvpKeyTrustTemplateVisible());
    }
	
	@Then("^User should be able to see added Unbundled Node Ids from (.+) are sorted in descending order in Benchmark Page in Create SMA SA Flow$")
    public void user_should_be_able_to_see_added_unbundled_node_ids_from_are_sorted_in_descending_order_in_benchmark_page_in_create_sma_sa_flow(String mandatorydetails) {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String unBundledNodeID,unBundledNodeIDPercentage= "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			unBundledNodeID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 43);
			unBundledNodeIDPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 44);
		}
		
		HashMap<String, Float> unbundledNodeIdMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(unBundledNodeID.contains(",")) {
			String[] custom = unBundledNodeID.split(",");
			String[] customPercentage = unBundledNodeIDPercentage.split(",");		
			int size = custom.length;
			
			for (int i = 0; i < size; i++) {
				unbundledNodeIdMap.put(custom[i], Float.parseFloat(customPercentage[i]));
			}
			
			sortedHashMap = sortUnbundledNodeIds(unbundledNodeIdMap);
		}else {
			sortedHashMap.put(unBundledNodeID, Float.parseFloat(unBundledNodeIDPercentage));
		}
		
		String unbundledNodeIdfromUI;
		Float unbundledNodeIdPercentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			unbundledNodeIdfromUI = benchmarkPage.getUnbundledithValuefromUI(j);
			unbundledNodeIdPercentagefromUI = benchmarkPage.getUnbundledPercentageithValuefromUI(j);
			
			Assert.assertTrue(unbundledNodeIdPercentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(unbundledNodeIdfromUI.equals(benchmarkKey));
			j++;
			
		}
    }
	
	private LinkedHashMap<String, Float> sortUnbundledNodeIds(HashMap<String, Float> unbundledNodeIdMap) {
		Set<Entry<String, Float>> customBenchmarkEntrySet = unbundledNodeIdMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		//sort based on benchmark names first to handle Equal Percentage scenario in ascending order
		Collections.sort(entryList, (o1, o2) -> o1.getKey().substring(0, o1.getKey().length()-5).trim().compareTo(o2.getKey().substring(0, o2.getKey().length()-5).trim()));
		
		//sort based on benchmark percentage in descending order
		Collections.sort(entryList, (o1, o2) -> {
			if(o1.getValue() > o2.getValue()) {
				return -1;
			}else if(o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});
		
		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
			@Override
			public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
				if(o1.getValue() > o2.getValue()) {
					return -1;
				}else if(o1.getValue() < o2.getValue()) {
					return 1;
				}
				return 0;
			}
		});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		  for (String countryKey : sortedHashMap.keySet()) {
		  System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		  
		  }*/
		 
		return sortedHashMap;
	}
	 
	@Then("^User should observe that Benchmark and Asset Allocation Page Unbundled Node ID field should act as a mandatory field$")
    public void user_should_observe_that_benchmark_and_asset_allocation_page_unbundled_node_id_field_should_act_as_a_mandattory_field() {
        assertTrue(benchmarkPage.isUnbundledNodeidMandatory());
    }
}
