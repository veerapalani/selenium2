package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStyleDetailsPage;

public class CreateStyleStepDefnition {

	LandingPage lp = new LandingPage("AD_PM_LandingPage");
	CreateStyleDetailsPage EISD = new CreateStyleDetailsPage("AD_PM_CreateStylePage");
	CreateStyleReviewPage RP = new CreateStyleReviewPage("AD_PM_CreateStyleReviewPage");
	CreateStyleConfirmationPage CP = new CreateStyleConfirmationPage("AD_PM_CreateStyleConfirmationPage");
	UpdateStyleDetailsPage UEISD = new UpdateStyleDetailsPage("AD_PM_UpdateStyleUIPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();

	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateStyleUI.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	String searchToken, token1 = null;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError;

	@When("^User clicks on Create New Dropdown Icon inside landing page$")
	public void user_clicks_on_create_new_dropdown_icon_inside_landing_page() throws Throwable {
		lp.clickOncreatenewdropdownicon();
	}

	@When("^User verifies Create New Dropdown on landing page$")
	public void user_verifies_create_new_dropdown_on_landing_page() throws Throwable {
		lp.verifyCreateNewDropdownonlandingpage();
	}

	@Then("^User clicks on Create New Dropdown button inside PM landing page$")
	public void user_clicks_on_create_new_dropdown_button_inside_PM_landing_page() throws Throwable {
		lp.clickOncreatenewdropdownbutton();
	}

	@And("^User clicks on Style from dropdown Menu$")
	public void user_clicks_on_style_from_dropdown_menu() throws Throwable {
		lp.clickOnstyledropdownmenu();
	}

	@Then("^User should be able to see Enter Investment Style Details header$")
	public void user_should_be_able_to_see_enter_investment_style_details_header() throws Throwable {
		EISD.isUserOnCreateStyleEnterInvestmentStyleDetailsPage();
	}

	@And("^User inputs all the (.+) for radio button attributes PIV Style on Style Details page$")
	public void user_inputs_all_the_for_radio_button_attributes_piv_style_on_style_details_page(String mandatorydetails)
			throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String piv_Y = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String piv_N = (String) exlObj.getCellData(sheet, rowIndex, 4);
		exlObj.closeWorkBook();
		if (investmentStyleName != "") {
			EISD.enterInvestmentStyleName(investmentStyleName);
		}
		if (piv_Y != piv_N) {
			EISD.enterFeeScheduleType(piv_Y, piv_N);
		}
	}

	@And("^User inputs all the (.+) on Enter Investment Style Details page$")
	public void user_inputs_all_the_on_enter_investment_style_details_page(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String hocomments = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String piv_Y = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String piv_N = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String sb = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();

		if (investmentStyleName != "") {
			EISD.enterInvestmentStyleName(investmentStyleName);
		}
		EISD.enterRiskCategory();
		EISD.enterBaseTemplate();
		if (piv_Y != piv_N) {
			EISD.enterFeeScheduleType(piv_Y, piv_N);
		}
		EISD.enterStyleCategory();
		EISD.enterBalancedAllocation();
		EISD.enterComparativeUniverse();
		EISD.enterGeographicIndicator();
		EISD.enterMarketCap();
		if (investmentStyleName != "") {
			EISD.enterHomeOfficeComments(hocomments);
		}
	}

	@And("^User clicks on Style Category dropdown input box$")
	public void user_clicks_on_style_category_dropdown_input_box() throws Throwable {
		EISD.clickOnStyleCategoryDropdownbox();
	}

	@Then("^User On clicking on Style Category \"([^\"]*)\" Dropdown on the Style Entity page should contain all the following options$")
	public void user_on_clicking_on_style_category_something_dropdown_on_the_style_entity_page_should_contain_all_the_following_options(
			String key, List<String> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			Reporter.addStepLog("verifying for " + items.get(i));
			listOfElements = EISD.getElementsFromShadowRoot(key);
			Reporter.addStepLog(listOfElements.get(i).getText());
			EISD.verifyTextInListOfElements(items.get(i), listOfElements);
		}
		Reporter.addScreenCapture();
	}

	@And("^User inputs draft name (.+) and click on Save button$")
	public void user_inputs_draft_name_and_click_on_save_button(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String draftName = (String) exlObj.getCellData(sheet, rowIndex, 7);
		System.out.println("draft Name= " + draftName);
		exlObj.closeWorkBook();
		if (draftName != "") {
			EISD.enterdraftName(draftName);
		}
		EISD.clickOnDraftSaveButton();
	}

	@And("^User inputs draft name (.+) and click on Save button in the Wizard on benchmark page$")
	public void user_inputs_draft_name_and_click_on_save_button_in_the_wizard_on_benchmark_page(String mandatorydetails)
			throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String draftName2 = (String) exlObj.getCellData(sheet, rowIndex, 7);
		System.out.println("draft Name= " + draftName2);
		exlObj.closeWorkBook();
		if (draftName2 != "") {
			EISD.enterdraftNameBenchmarkPage(draftName2);
		}
		EISD.clickOnDraftSaveButtonBenchmarkPage();
	}

	@And("^User inputs draft name (.+) and click on Cancel button$")
	public void user_inputs_draft_name_and_click_on_cancel_button(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String draftName = (String) exlObj.getCellData(sheet, rowIndex, 7);
		System.out.println("draft Name= " + draftName);
		exlObj.closeWorkBook();
		if (draftName != "") {
			EISD.enterdraftName(draftName);
		}
		EISD.clickOnDraftCancelButton();
	}

	@Then("^User should be able to click on OK on alert popup box$")
	public void user_should_be_able_to_click_on_ok_on_alert_popup_box() throws Throwable {
		EISD.acceptAlertMessage();
	}

	@When("^User clicks on Next button in Enter Investment Style Details page$")
	public void user_clicks_on_next_button_in_enter_investment_style_details_page() throws Throwable {
		EISD.clickOnNextButton1();
	}

	@Then("^User should be able to see Benchmark and Asset Classification header$")
	public void user_should_be_able_to_see_benchmark_and_asset_classification_header() throws Throwable {
		EISD.isUserOnBenchmarkandAssetClassificationHeaderPage();
	}

	@And("^User inputs all the (.+) with style benchmarks on Benchmark and Asset Classification page$")
	public void user_inputs_all_the_with_style_benchmarks_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			EISD.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@When("^User clicks on Next button1 in Benchmark and Asset Classification page$")
	public void user_clicks_on_next_button1_in_benchmark_and_asset_classification_page() throws Throwable {
		Reporter.addCompleteScreenCapture();
		EISD.clickOnNextButton3();
	}

	@And("^User verifies Save as draft button must be visible at the UI$")
	public void user_verifies_save_as_draft_button_must_be_visible_at_the_ui() throws Throwable {
		EISD.verifySaveASDraftButton();
	}

	@When("^User clicks on Save Draft button in Enter Investment Style Details page$")
	public void user_clicks_on_save_draft_button_in_enter_investment_style_details_page() throws Throwable {
		EISD.clickOnSaveDraftButton();
	}

	@When("^User clicks on Save Draft button in Benchmark and Asset Classification page$")
	public void user_clicks_on_save_draft_button_in_benchmark_and_asset_classification_page() throws Throwable {
		EISD.clickOnSaveDraftButton();
	}

	@When("^User clicks on Save Draft button in Review page$")
	public void user_clicks_on_save_draft_button_in_review_page() throws Throwable {
		EISD.clickOnSaveDraftButton();
	}

	@Then("^User should be able to see the \"([^\"]*)\" Save as a draft header in the Wizard$")
	public void user_should_be_able_to_see_the_something_save_as_a_draft_header_in_the_wizard(String Saveasadraftheader)
			throws Throwable {
		EISD.verifySaveASDraftHeader(Saveasadraftheader);
	}

	@Then("^User should be able to see the \"([^\"]*)\" Save as a draft header in the Wizard on benchmark page$")
	public void user_should_be_able_to_see_the_something_save_as_a_draft_header_in_the_wizard_on_benchmark_page(
			String Saveasadraftheader2) throws Throwable {
		EISD.verifySaveASDraftHeaderBenchmarkPage(Saveasadraftheader2);
	}

	@And("^User should be able to see the \"([^\"]*)\" Draft Name subheader in the Wizard$")
	public void user_should_be_able_to_see_the_something_draft_name_subheader_in_the_wizard(String DraftNameheader)
			throws Throwable {
		EISD.verifyDraftNameHeader(DraftNameheader);
	}

	@And("^User should be able to see the \"([^\"]*)\" Draft Name subheader in the Wizard on benchmark page$")
	public void user_should_be_able_to_see_the_something_draft_name_subheader_in_the_wizard_on_benchmark_page(
			String DraftNameheader2) throws Throwable {
		EISD.verifyDraftNameHeaderBenchmarkPage(DraftNameheader2);
	}

	@And("^User inputs all the (.+) with single custom benchmarks on Benchmark and Asset Classification page$")
	public void user_inputs_all_the_with_single_custom_benchmarks_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			EISD.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@And("^User inputs all the (.+) with single custom benchmarks without benchmark name and percentage alone selected on Benchmark and Asset Classification page$")
	public void user_inputs_all_the_with_single_custom_benchmarks_without_benchmark_name_and_percentage_alone_selected_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			EISD.enterSingleComparativeBenchmarkWithoutBenchmarkName(sb_1, cb_2);
		}
	}

	@And("^User inputs all the (.+) with Multiple UnBundled Asset Classification data and Custom based benchmarks on Benchmark and Asset Classification page$")
	public void user_inputs_all_the_with_multiple_unbundled_asset_classification_data_and_custom_based_benchmarks_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterMultipleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			EISD.enterMultipleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@And("^User inputs all the (.+) with Multiple UnBundled Asset Classification data and Custom based benchmarks with duplicate benchmarks selected on Benchmark and Asset Classification page$")
	public void user_inputs_all_the_with_multiple_unbundled_asset_classification_data_and_custom_based_benchmarks_with_duplicate_benchmarks_selected_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterMultipleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			EISD.enterMultipleComparativeBenchmarkWithDuplicateBenchmarkNames(sb_1, cb_2);
		}
	}

	@And("^User inputs all the (.+) with Multiple UnBundled Asset Classification data and style based benchmarks on Benchmark and Asset Classification page$")
	public void user_inputs_all_the_with_multiple_unbundled_asset_classification_data_and_style_based_benchmarks_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterMultipleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			EISD.enterMultipleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@When("^User clicks on Next button2 in Benchmark and Asset Classification page$")
	public void user_clicks_on_next_button2_in_benchmark_and_asset_classification_page() throws Throwable {
		EISD.clickOnNextButton2();
	}

	@Then("^User should be able to see Review header$")
	public void user_should_be_able_to_see_review_header() throws Throwable {
		RP.verifyreviewheaderinCreateStyleReviewPage();
	}

	@And("^User reviews all the details provided earlier on Review page$")
	public void user_reviews_all_the_details_provided_earlier_on_review_page() throws Throwable {
		RP.verifyreviewpagedetailsinCreateStyleReviewPage();
	}

	@When("^User clicks on Submit button in Review page$")
	public void user_clicks_on_submit_button_in_review_page() throws Throwable {
		RP.verifysubmitButtoninCreateStyleReviewPage();
	}

	@Then("^User should be able to see Confirmation header$")
	public void user_should_be_able_to_see_confirmation_header() throws Throwable {
		CP.verifyconfirmationheaderinCreateStyleConfPage();
	}

	@And("^User should be able to see Your Investment Style Creation Request Has Been Submitted message getting displayed on Confirmation page$")
	public void user_should_be_able_to_see_your_investment_style_creation_request_has_been_submitted_message_getting_displayed_on_confirmation_page()
			throws Throwable {
		CP.verifyRequestSubmittedMessageinCreateStyleConfPage();
		CP.verifystyleidinCreateStyleconfPage();
	}

	@When("^User clicks on Done button in Confirmation page$")
	public void user_clicks_on_done_button_in_confirmation_page() throws Throwable {
		CP.verifyDoneButtoninCreateStyleConfPage();
	}

	@Then("^User Should be able to see Product Master landing page$")
	public void user_should_be_able_to_see_product_master_landing_page() throws Throwable {
		lp.verifyProductMasterheaderonlandingpage();
	}

	@Then("^User should be able to see Benchmark and Asset Classification header under Benchmark and Asset Classification page$")
	public void user_should_be_able_to_see_benchmark_and_asset_classification_header_under_benchmark_and_asset_classification_page()
			throws Throwable {
		EISD.clickOnNextButton1();
	}

	@When("^User clicks on Previous button in Benchmark and Asset Classification page$")
	public void user_clicks_on_previous_button_in_benchmark_and_asset_classification_page() throws Throwable {
		EISD.clickOnPreviousButton1();
	}

	@When("^User clicks on Cancel button in Enter Investment Style Details page$")
	public void user_clicks_on_cancel_button_in_enter_investment_style_details_page() throws Throwable {
		EISD.clickOnCancelButton1();
	}

	@Then("^User should see an inline error message1 as \"([^\"]*)\" in Benchmark page$")
	public void user_should_see_an_inline_error_message1_as_something_in_benchmark_page(String benchmarkError1)
			throws Throwable {
		EISD.compareBenchmarkError1(benchmarkError1);
	}

	@Then("^User should see an inline error message2 as \"([^\"]*)\" in Benchmark page$")
	public void user_should_see_an_inline_error_message2_as_something_in_benchmark_page(String benchmarkError2)
			throws Throwable {
		EISD.compareBenchmarkError2(benchmarkError2);
	}

	@And("^User should also see an inline error message3 as \"([^\"]*)\" in Benchmark page$")
	public void user_should_also_see_an_inline_error_message3_as_something_in_benchmark_page(String benchmarkError3)
			throws Throwable {
		EISD.compareBenchmarkError3(benchmarkError3);
	}

	@When("^User enters (.+) search token on Global Serach input box on PM landing page in create style flow$")
	public void user_enters_search_token_on_global_serach_input_box_on_pm_landing_page(String mandatorydetails)
			throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		searchToken = (String) exlObj.getCellData(sheet, rowIndex, 1);
		if (searchToken != "") {
			lp.enterStyleSearchToken(searchToken);
		}
	}

	@And("^User able to verify the PMP Style and Custom Options on Style View Details page in create style flow$")
	public void user_able_to_verify_the_pmp_style_and_custom_options_on_style_view_details_page() throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "TDR10_DataValidation";
		String SQLquery9, labelname = null;
		String label9;
		ResultSet rs9;

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;
		// style_name
		label9 = (String) exlObj.getCellData(sheet, 10, cellnum - 1).toString();
		System.out.println(label9);
		pmdb.DBConnectionStart();
		SQLquery9 = (String) exlObj.getCellData(sheet, 10, cellnum);
		SQLquery9 = SQLquery9.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs9 = DBManager.executeSelectQuery(SQLquery9);
		while (rs9.next()) {
			token1 = rs9.getString(1);
			if (rs9.wasNull()) {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}

		lp.verifyComparativeBenchmarkSelection(token1);
	}

	@And("^user selects drafts from the landing page accordion$")
	public void user_selects_drafts_from_the_landing_page_accordion() throws Throwable {
		lp.clickOnDraftsTab();
	}

	@And("^user selects drafts2 from the landing page accordion$")
	public void user_selects_drafts2_from_the_landing_page_accordion() throws Throwable {
		lp.clickOnDraftsTab2();
	}

	@And("^from Draft user selects the draft which had been worked upon (.+)$")
	public void from_draft_user_selects_the_draft_which_had_been_worked_upon(String mandatorydetails) throws Throwable {
		lp.clickOnStyleNameFilterIcon();
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String draftName = (String) exlObj.getCellData(sheet, rowIndex, 7);
		System.out.println("draft Name= " + draftName);
		exlObj.closeWorkBook();

		if (draftName != "") {
			lp.provideInputForFilterConditions(draftName);
		}
		lp.clickOnApplyButton();
		lp.clickOnStyleGridEllipsesIconFilter();
		lp.clickOnStyleEditButton();
		lp.verifyUserIsOnViewDraftPage();
		lp.verifyDraftViewEditButton();
		Reporter.addCompleteScreenCapture();
	}

	@And("^from created Drafts user selects the draft which had been worked upon (.+) to validate error messages on benchmark page$")
	public void from_draft_user_selects_the_draft_which_had_been_worked_upon_to_validate_error_messages_on_benchmark_page(
			String mandatorydetails) throws Throwable {
		lp.clickOnStyleNameFilterIcon();
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String draftName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		System.out.println("draft Name= " + draftName);
		exlObj.closeWorkBook();
		if (draftName != "") {
			lp.provideInputForFilterConditions(draftName);
		}
		lp.clickOnApplyButton();
		lp.clickOnStyleGridEllipsesIconFilter();
		lp.clickOnStyleEditButton();
		lp.verifyUserIsOnViewDraftPage();
		lp.verifyDraftViewEditButton();
	}

	@And("^User inputs all the (.+) with single custom benchmarks without benchmark name and percentage details on Benchmark and Asset Classification page$")
	public void user_inputs_all_the_with_single_custom_benchmarks_without_benchmark_name_and_percentage_details_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			EISD.enterSingleComparativeBenchmarkWithoutBenchmarkNameAndPercentage(sb_1, cb_2);
		}
	}

	@And("^from Draft user deletes the draft which had been worked upon (.+)$")
	public void from_draft_user_deletes_the_draft_which_had_been_worked_upon(String mandatorydetails) throws Throwable {
		lp.clickOnStyleNameFilterIcon();
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String draftName = (String) exlObj.getCellData(sheet, rowIndex, 7);
		System.out.println("draft Name= " + draftName);
		exlObj.closeWorkBook();
		if (draftName != "") {
			lp.provideInputForFilterConditions(draftName);
		}
		lp.clickOnApplyButton();
		lp.clickOnStyleGridEllipsesIconFilter();
		lp.clickOnStyleDeleteButton();
		lp.verifyNoRowsToShowMessage();
	}

	@And("^at the edit page user clicks on edit button$")
	public void at_the_edit_page_user_clicks_on_edit_button() throws Throwable {
		lp.clickOnStyleViewEditButton();
		EISD.isUserOnCreateStyleEnterInvestmentStyleDetailsPage();
	}

	@And("^at the edit page user clicks on draft edit button$")
	public void at_the_edit_page_user_clicks_on_draft_edit_button() throws Throwable {
		lp.clickOnDraftViewEditButton();
		EISD.isUserOnCreateStyleEnterInvestmentStyleDetailsPage();
	}

	@And("^at the edit page user clicks on the reset button$")
	public void at_the_edit_page_user_clicks_on_the_reset_button() throws Throwable {
		EISD.verifyResetButton();
	}

	@Then("^the values which were previously saved must disappear$")
	public void the_values_which_were_previously_saved_must_disappear() throws Throwable {
		EISD.clickOnResetButton();
	}

	@When("^User clicks on Previous button in Review page$")
	public void user_clicks_on_previous_button_in_review_page() throws Throwable {
		EISD.clickOnPreviousButton1();
	}

	@And("^at the edit page user is able to see the added custom benchmarks displays under Benchmark and Asset Classification section of View Draft page$")
	public void at_the_edit_page_user_is_able_to_see_the_added_custom_benchmarks_displays_under_benchmark_and_asset_classification_section_of_view_draft_page()
			throws Throwable {
		lp.verifyBenchmarkHeaderOnStyleDraftViewPage();
	}

	@Then("^User should see an inline error message4 as \"([^\"]*)\" in Benchmark page$")
	public void user_should_see_an_inline_error_message4_as_something_in_benchmark_page(String benchmarkError4)
			throws Throwable {
		EISD.compareBenchmarkError4(benchmarkError4);
	}

	@And("^User inputs all the (.+) with Multiple UnBundled Asset Classification data with random percentages and style based benchmarks on Benchmark and Asset Classification page in create flow$")
	public void user_inputs_all_the_with_multiple_unbundled_asset_classification_data_with_random_percentages_and_style_based_benchmarks_on_benchmark_and_asset_classification_page_in_create_flow(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		UEISD.enterMultipleUnbundledAssetClassificationWithRandomPercentages();
		if (sb_1 != cb_2) {
			EISD.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User should be able to see Unbundled Node Ids added are retained based on percentage allocation in descending order on Review page in Create Style Flow$")
	public void user_should_be_able_to_see_unbundled_node_ids_added_are_retained_based_on_percentage_allocation_in_descending_order_on_review_page_in_create_style_flow()
			throws Throwable {
		RP.verifyCreateFlowUnbundledNodeIdDisplayedInDescOrder();
	}

	@Then("^User should be able to see Unbundled Node Ids added are retained based on percentage allocation in descending order on Benchmark page in Create Style Flow$")
	public void user_should_be_able_to_see_unbundled_node_ids_added_are_retained_based_on_percentage_allocation_in_descending_order_on_benchmark_page_in_create_style_flow()
			throws Throwable {
		EISD.verifyUnbundledNodeIdDisplayedInDescOrder();
	}

	@And("^User inputs all the (.+) with Single UnBundled Asset Classification and Custom based benchmarks data with random percentages on Benchmark and Asset Classification page in Create Style flow$")
	public void user_inputs_all_the_with_single_unbundled_asset_classification_and_custom_based_benchmarks_data_with_random_percentages_on_benchmark_and_asset_classification_page_in_create_style_flow(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			UEISD.enterMultipleComparativeBenchmarkWithRandomPercentages(sb_1, cb_2);
		}
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User should be able to see Custom Benchmarks added are retained based on percentage allocation in descending order on Review page in Create Style Flow$")
	public void user_should_be_able_to_see_custom_benchmarks_added_are_retained_based_on_percentage_allocation_in_descending_order_on_review_page_in_create_style_flow()
			throws Throwable {
		RP.verifyCustomBenchmarksDisplayedInDescOrder();
	}

	@Then("^User should be able to see Custom Benchmarks added are retained based on percentage allocation in descending order on Benchmark page in Create Style Flow$")
	public void user_should_be_able_to_see_custom_benchmarks_added_are_retained_based_on_percentage_allocation_in_descending_order_on_benchmark_page_in_create_style_flow()
			throws Throwable {
		EISD.verifyCustomBenchmarksDisplayedInDescOrder();
	}

	@When("^User inputs all the (.+) with selected bundled node id, then default style based benchmark must be correctly displayed on Benchmark and Asset Classification page$")
	public void user_inputs_all_the_with_selected_bundled_node_id_then_default_style_based_benchmark_must_be_correctly_displayed_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		EISD.enterBundledAssetClassification();
		EISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			EISD.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
		EISD.verifyStyleBenchmarkbasedOnSelectedBundledNodeID();
	}
}
