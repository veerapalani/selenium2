package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import freemarker.core.ReturnInstruction.Return;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyEnterStrategyDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStartegyReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.SaveAsDraftAllUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;

public class Validations_with_HO_approval {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	String expectedColorCode;
	String xpath, myValue;
	Select dropdown;
	Boolean myFlag;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/smaAccess/view/2053002";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	String excelFilePath1 = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategyvestmark_1.xlsx";
	CreatePMPStrategyEnterStrategyDetailsPage strategyDetailsPage = new CreatePMPStrategyEnterStrategyDetailsPage("AD_PM_UpdateStrategyUIPage");
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	ExcelUtils exlObj1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath1);
	RejectedStartegyReviewPage rw = new RejectedStartegyReviewPage("AD_PM_RejectedStartegyReviewPage");
	String StrategyName, InvestStyle, fAFAteamName, selection, StrategyStatus, submissiondate, Mcap,
riskcategory, feeschedule, PivStyle, FASegment, HideStrategy, GeographicIndicator, BalancedAllocation, InvestmentStyleCategory,
ComparativeUniverse, BundledNodeID, UnbundledNodeID, StylePairingCode, FOACode, MarginEligible, SingleStrategyOnly, StructuredProductsStrategy,
ConcentratedStrategyIndicator, ShortTermMaturity, HedgeCoreIndicator, SustainableInvestmentStrategy, AlternativesStrategy, FAEmail, 
NonPMPApprovedTeamMemberemails, DVPKeyTrustTemplate, BenchmarkCategory, BenchmarkCategoryCustom, Benchmark1, Benchmark1CustomBenchmarks, DocumentLink,
DocumentType, DocumentDescription, Comments, CommentType, hOApprovalReasonsString, FAPMPApprovedDate="";
	
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	UpdateStrategyPage UpdateStrategyUI = new UpdateStrategyPage();
	WebElement myElement, myElement1,myElement2;
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_LandingPage"));

	List<String> list = new ArrayList<String>();
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");

	
	SaveAsDraftAllUIPage ho = new SaveAsDraftAllUIPage();
	 @Then("^User clicks on (.+) tab on PM UI during approve reject flow$")
	    public void user_clicks_on_tab_on_pm_ui_during_approve_reject_flow(String entity) throws Throwable
	    {
		 
		 while(true)
		 {
		 try
		 {
		 myElement1 =(WebElement)action.executeJavaScript("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
			while (myElement1.isDisplayed()) {
		 action.highligthElement(myElement1);
		 myElement1.click();
		 Thread.sleep(2000);
			}}
		 catch (Throwable e)
		 {
		 break;
		 }
		 }



		 Thread.sleep(3000);

		 while(true)
		 {
		 try
		 {
		 myElement1 = (WebElement)action.executeJavaScript("return document.querySelector(\"#wftabs\").shadowRoot.querySelector(\"main > div.tab-bar > div > div > div > button.next-arrow.next-arrow-show > wf-action-icon\")");
		 action.highligthElement(myElement1);
		 myElement1.click();
		 Thread.sleep(2000);



		 }
		 catch (Throwable e)
		 {
		 break;
		 }
		 }
		 myElement = ho.findElementByDynamicXpath("//brml-tab-button[@tab=\""+entity+"\"]");
		 Thread.sleep(2000);
		 myElement.click();
		 Reporter.addStepLog("Draft tab is cicked");
		 action.waitForPageLoad();
		 Thread.sleep(3000);
	    }
	 
        @Then("^user chooses to click on the reject button.  $")
	    public void user_chooses_to_click_on_the_reject_button(String columnName) throws Throwable {
	    	
	    	myElement.click();
	       
	    }
	    


	    @Then("^User clicks to amend the strategy in terms of approving or rejecting$")
	    public void user_clicks_to_amend_the_strategy_in_terms_of_approving_or_rejecting() throws Throwable {
	    	
	    	Thread.sleep(5000);
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\"brml-active-icon[name='wf-action']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(5000);
			Reporter.addStepLog("Clicked on Next button");
	    }
	    
	    @And("^user clicks on the the ellipsis icon for approving or rejecting the strategy$")
	    public void user_clicks_on_the_the_ellipsis_icon_for_approving_or_rejecting_the_strategy() throws Throwable {
	    	Thread.sleep(5000);
	    	
	    	String HoApproval ="return document.querySelectorAll(\"div[col-id='strategyCode']\")[1]";
	    	myElement = (WebElement)ho.executeJavaScript(HoApproval);
	    	action.scrollToElement(myElement);
	    	myElement.click();
	    	myElement = (WebElement)ho.executeJavaScript("return document.querySelectorAll(\"div[col-id='strategyCode']\")[1].parentElement.querySelector(\"brml-action-menu\")");

	    	myElement.click();


	    	
	    }
	    @And("^User clicks upon the approve reject button$")
	    public void user_clicks_upon_the_approve_reject_button() throws Throwable {
	    	
	    	action.scrollToElement(myElement);
	    	
	    	Thread.sleep(5000);	
	    	
	    	String ApproveReject = "return document.querySelector(\"brml-action-menu\").shadowRoot.querySelector(\"wf-flyout >div >div >button\")";
	    	myElement = (WebElement)ho.executeJavaScript(ApproveReject);
	    	
	    	
	    	myElement.click();
	    	Thread.sleep(5000);
	    
	    	
	    	
	    }

	    @Then("^highlights the reason for the pending HO Approval$")
	    public void highlights_the_reason_for_the_pending_ho_approval() throws Throwable {
	    	Thread.sleep(2000);
	    	String HighlightReason ="return document.querySelector(\"#hoApprovalReason > label\")";
	    	myElement = (WebElement)ho.executeJavaScript(HighlightReason);
	    	action.scrollToElement(myElement);
	    	action.highligthElement(myElement);
	    	myElement.click();
	    	Thread.sleep(4000);
	    	landingPage1.highlightingreason();
	    	Thread.sleep(4000);
	    	
	    }
	    


	    @And("^Enters the relevant comments of own discretion$")
	    public void enters_the_relevant_comments_of_own_discretion(List<List<String>> attribute) throws Throwable {
	    
	    	sheetName = "Valid";
			sheet = exlObj.getSheet(sheetName);
			action.pause(1000);
			for (int i = 0; i < attribute.size(); i++) {

				rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "Valid_Data");
				cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

				System.out.println(attribute.get(i).get(0));
				myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-textarea[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('textarea')");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				action.clear(myElement);
				//action.sendkeysClipboard(myElement, myValue);
				action.sendKeys(myElement, myValue);
				Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
	    }
	    }
	    

	    @And("^User clicks on the button that rejects the PMP Strategy$")
	    public void user_clicks_on_the_button_that_rejects_the_pmp_strategy() throws Throwable {
	    	
	    	landingPage1.rejectingagivenstrategy();
	    }
	    
	    @And("^User chooses to approve the strategy$")
	    public void user_chooses_to_approve_the_strategy() throws Throwable {
	    	landingPage1.approvingstrategy();
	    }
	    
	    @And("^decides to create a new PMP strategy by clicking upon the create new strategy button$")
	    public void decides_to_create_a_new_pmp_strategy_by_clicking_upon_the_create_new_strategy_button() throws Throwable {
	    	landingPage1.BUusernewstrategycreate();
	    }
	    
	    
	    @And("^the flow proceeds by clicking at the next button$")
	    public void the_flow_proceeds_by_clicking_at_the_next_button() throws Throwable {
	    	strategyDetailsPage.clickonnext();
	    }
	    @And("^user provides the values for the text boxes which are mandatory for the UI$")
	    public void user_provides_the_values_for_the_text_boxes_which_are_mandatory_for_the_ui(List<List<String>> attribute) throws Throwable {
	    	sheetName = "CreatePMPBU";
			sheet = exlObj.getSheet(sheetName);
			Thread.sleep(2000);
			for (int i = 0; i < attribute.size(); i++) {

				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "valid_data");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

				System.out.println(attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				action.clear(myElement);
				System.out.println(attribute.get(i).get(0) + " value " + myValue);
				action.sendKeys(myElement, myValue);
				Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
				Thread.sleep(2000);
}
}

	    @And("^inputs the choices from the dropdown lists$")
	    public void inputs_the_choices_from_the_dropdown_lists(List<List<String>> attribute) throws Throwable{
	    	sheetName = "CreatePMPBU";
			sheet = exlObj.getSheet(sheetName);
			Thread.sleep(2000);
			for (int i = 0; i < attribute.size(); i++) {

				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "valid_data");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

				System.out.println(attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
						+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				action.click(myElement);
				Thread.sleep(2000);
				myElement = (WebElement) action
						.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
								+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				action.click(myElement);
				Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
				Thread.sleep(2000);
	    }
}
	    @Then("^user clicks on the check box which attests the strategy$")
	    public void user_clicks_on_the_check_box_which_attests_the_strategy() throws Throwable {
	    	strategyDetailsPage.attest();
	    }
	    
	    @And("^Hereby the flow is completed as the user clicks on submit button$")
	    public void hereby_the_flow_is_completed_as_the_user_clicks_on_submit_button() throws Throwable {
	    	strategyDetailsPage.submission();
	    }

	    @And("^the changes are highlighted as confirmation$")
	    public void the_changes_are_highlighted_as_confirmation() throws Throwable {
	    	strategyDetailsPage.highlightthechanges();
	    }

	    @And("^the confirmation page is highlighted$")
	    public void the_confirmation_page_is_highlighted() throws Throwable {
	    	strategyDetailsPage.closure();
	    }
	    
	    @And("^user clicks on the the ellipsis icon for viewing the details of the strategy$")
	    public void user_clicks_on_the_the_ellipsis_icon_for_viewing_the_details_of_the_strategy() throws Throwable {
	    	strategyDetailsPage.editingstrategydetails();
	    }
	    

	    @And("^The user checks on the exceptions button$")
	    public void the_user_checks_on_the_exceptions_button() throws Throwable {
	    rw.exception();
	    }

	    @Then("^user validates for the PMP Strategy submission date$")
	    public void user_validates_for_the_pmp_strategy_submission_date() throws Throwable {
	    	
	    	strategyDetailsPage.strategydate();
	      
	    }
	    
	    @When("^User click at the download button atop the landing page$")
	    public void user_click_at_the_download_button_atop_the_landing_page() throws Throwable {
	    	
	    	landingPage1.export();
	    	
	    }
	    @And("^the flow gets completed as the user clicks on the done button$")
	    public void the_flow_gets_completed_as_the_user_clicks_on_the_done_button() throws Throwable {
	    	
	    	Thread.sleep(2000);
	    	String db= "return document.querySelector(\"body > wf-bridge > product-master > div > div:nth-child(3) > div > div > brml-button\")";
	    	WebElement ele = (WebElement) action.getElementByJavascript(db);
	    	action.highligthElement(ele);
	    	Reporter.addCompleteScreenCapture();
	    	action.click(ele);
	    	Thread.sleep(5000);
	    }
	    
	    @When("^User clicks at the print button atop$")
	    public void user_clicks_at_the_print_button_atop() throws Throwable {
	     	//Thread.sleep(5000);
	     	String db1 = "return document.querySelector(\"brml-active-icon[name='print']\")";
	    	//String db1= "return document.querySelector(\"#form > div.container-fluid > div > div.col-1 > div > brml-tooltip:nth-child(4) > brml-active-icon\").shadowRoot.querySelector(\"brml-tooltip > div > button > span.overlay\")";
	    	WebElement ele = (WebElement) action.executeJavaScript(db1);
	    	action.scrollToElement(ele);
	    	action.highligthElement(ele);
	    	Reporter.addCompleteScreenCapture();
	    	action.click(ele);
	    	Thread.sleep(5000);
	    }
	    
	    @When("^the user clicks on the cancel button$")
	    public void the_user_clicks_on_the_cancel_button() throws Throwable {
	    	String db2 = "return document.querySelector(\"brml-button[proto='button']\")";
	    	//String db1= "return document.querySelector(\"#form > div.container-fluid > div > div.col-1 > div > brml-tooltip:nth-child(4) > brml-active-icon\").shadowRoot.querySelector(\"brml-tooltip > div > button > span.overlay\")";
	    	WebElement ele = (WebElement) action.executeJavaScript(db2);
	    	action.scrollToElement(ele);
	    	action.highligthElement(ele);
	    	Reporter.addCompleteScreenCapture();
	    	action.click(ele);
	    	Thread.sleep(5000);
	    }
	    }
	    
	    
	    
	    

	    

