package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.BenchmarkSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.ExportReportsPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class BenchmarkExportStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	BenchmarkSortAndFilterPage benchmarkPage = new BenchmarkSortAndFilterPage("AD_PM_BenchmarkSortAndFilterPage");
	ExportReportsPage reports = new ExportReportsPage();
	String sheetName, sheetName2 = "";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/BenchmarkExport.xlsx";
	String attributeValue, label = "";
	int rowIndex, columNum, cellCount = 0;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	PMPageGeneric pmPageGeneric = new PMPageGeneric("AD_PM_BenchmarkSortAndFilterPage");

	@Then("^user verifies the Benchmark export functionality using (.+)$")
	public void user_verifies_the_benchmark_export_fucntionality(String entityName)
			throws IOException, InterruptedException {
		int count = benchmarkPage.getBenchmarkCount();
		System.out.println("count: " + count);
		if (count < 1) {
			Reporter.addStepLog("There are no Benchmarks associated with search value in the Grid");
			Reporter.addScreenCapture();
		} else {
			reports.DeletePreviousFile(entityName);
			benchmarkPage.clickOnBenchmarkExport();
			Assert.assertTrue(reports.VerifyFileDownloaded());
			// verifying the grid count and csv file count
			Assert.assertTrue(count == reports.getNumberOfRecordsInFile(entityName));
			landingPage.movetoFirstElementinFilteredrecords();
			landingPage.clickOnEllipsesIcon();
			landingPage.verifyOnViewDetailsLink();

			landingPage.clickOnViewDetailsLink();
			Assert.assertTrue(benchmarkPage.verifyUserisOnViewBenchmarkPage());

			sheetName = entityName;

			sheet = exlObj.getSheet(entityName);
			cellCount = exlObj.getCellCount(sheet, 0);
			System.out.println("cellcount:" + cellCount);

			while (columNum < cellCount) {
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
				System.out.println(label);
				attributeValue = benchmarkPage.getTextWithLabel(label);
				if (attributeValue.equals("—")) {
					attributeValue = "";
				}
				System.out.println(attributeValue);
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, columNum, attributeValue);
				columNum++;
			}

			// Make sure sheet name same as entity name i.e same as downloaded file name
			reports.verifyAttributesForFirstEntityBenchmark(entityName, excelFilePath);

			exlObj.closeWorkBook();

		}
	}

	@Then("^user verifies the Benchmark export tooltip$")
	public void user_verifies_the_benchmark_export_tooltip() {
		Assert.assertTrue(benchmarkPage.verifyTooltipOfBenchmarkExport());
	}

	@Then("^user validates the Benchmark Print functionality for (.+)$")
	public void user_validates_the_benchmark_print_functionality(String entityName) throws Exception {
		// Assert.assertTrue(benchmarkPage.verifyTooltipOfBenchmarkPrint());
		/*
		 * landingPage.movetoFirstElementinFilteredrecords();
		 * landingPage.clickOnEllipsesIcon(); landingPage.verifyOnViewDetailsLink();
		 * 
		 * landingPage.clickOnViewDetailsLink();
		 * Assert.assertTrue(benchmarkPage.verifyUserisOnViewBenchmarkPage());
		 * 
		 * sheetName = entityName;
		 * 
		 * sheet = exlObj.getSheet(entityName); cellCount = exlObj.getCellCount(sheet,
		 * 0); // System.out.println("cellcount:" + cellCount);
		 * 
		 * while (columNum < cellCount) { label =
		 * PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum); //
		 * System.out.println(label); attributeValue =
		 * benchmarkPage.getTextWithLabel(label); if (attributeValue.equals("—")) {
		 * attributeValue = ""; } // System.out.println(attributeValue);
		 * PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, columNum,
		 * attributeValue); columNum++; }
		 */
		PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, 0, benchmarkPage.getTextforBenchmarkDescription());
		int i = 2;
		while (i <= 10) {
			PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, i-1,
					benchmarkPage.getTextfromGridforRow(String.valueOf(i)));
			i++;
		}
		benchmarkPage.clickOnBenchmarkPrint();
		pmPageGeneric.verifyPrintFunctionalityForFirstEntity(excelFilePath, entityName);
	}
	
	@Then("^user verifies the Benchmark print tooltip$")
	public void user_verifies_the_benchmark_print_tooltip() {
		Assert.assertTrue(benchmarkPage.verifyTooltipOfBenchmarkPrint());
	}

}
