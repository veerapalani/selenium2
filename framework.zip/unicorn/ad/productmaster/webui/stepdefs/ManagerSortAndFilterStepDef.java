package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.ManagerSortAndFilterPage;

public class ManagerSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	ManagerSortAndFilterPage managerSortAndFilterPage = new ManagerSortAndFilterPage("AD_PM_ManagerSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/ManagerSortAndFilter.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	WebElement myElement, myElement2;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ManagerSortAndFilterPage"));

	@When("^User enter valid (.+) in global search box for Manager$")
	public void user_enter_valid_in_global_search_box_for_manager(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String ManagerSearchValue = (String) exlObj.getCellData(sheet, rowIndex, 1);

		exlObj.closeWorkBook();
		if (ManagerSearchValue != "") {
			managerSortAndFilterPage.searchManagerValue(ManagerSearchValue);
		}
		Reporter.addScreenCapture();
	}

	@And("^user clicks on \"([^\"]*)\" on landing page for Manager$")
	public void user_clicks_on_something_on_landing_page_for_manager(String strArg1) throws Throwable {
		managerSortAndFilterPage.clickOnSeeAllResultsForManagerLayout();
		Reporter.addScreenCapture();
	}

	@And("^user is able to see search results in \"([^\"]*)\" tab under Manager accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_manager_accordion(String strArg1)
			throws Throwable {
		managerSortAndFilterPage.verifyTheSearchedResultInAllTabForManager();
		Reporter.addScreenCapture();
	}

	@And("^user click on \"([^\"]*)\" tab on landing page for Manager$")
	public void user_click_on_something_tab_on_landing_page_for_manager(String strArg1) throws Throwable {
		managerSortAndFilterPage.verifyAndClickManagerTab();
		Reporter.addScreenCapture();
	}

	@And("^User able to see searched grid view data for Manager grid view$")
	public void user_able_to_see_searched_grid_view_data_for_manager_grid_view() throws Throwable {
		String gridCountBeforeCondition = managerSortAndFilterPage
				.verifyTheGridCountBeforeApplyFilterAndSortCondition();
		// String gridCountBeforeCondition =
		// ManagerSortAndFilterPage.gridCountAfterGlobalSearch;
		int beforeApplyCondition = Integer.parseInt(gridCountBeforeCondition);
		if (beforeApplyCondition == 1)
			managerSortAndFilterPage.verifyTheNoResultsOnGridView();
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to search records for Manager View using the global search box on landing page$")
	public void user_should_be_able_to_search_records_for_manager_view_using_the_global_search_box_on_landing_page()
			throws Throwable {
		managerSortAndFilterPage.verifySearchedGridViewDisplay();
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design for Manager$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design_for_manager(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			managerSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			managerSortAndFilterPage.mouseHoverOnGridViewLabels(managerSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			managerSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			managerSortAndFilterPage.verifyGridViewLabelsWithSortIcons(
					managerSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for Manager$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_manager(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			managerSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			managerSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					managerSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for Manager$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_manager(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			managerSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			managerSortAndFilterPage.mouseHoverOnGridViewLabels(managerSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			managerSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			managerSortAndFilterPage.clickOnSortIcon(
					managerSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for Manager$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_manager() throws Throwable {
		String value = managerSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = ManagerSortAndFilterPage.ascSortValue;
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for Manager$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_manager(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			managerSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			managerSortAndFilterPage.mouseHoverOnGridViewLabels(managerSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			managerSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			managerSortAndFilterPage.clickOnSortIcon(
					managerSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for Manager$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_manager() throws Throwable {
		String value = managerSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = ManagerSortAndFilterPage.descSortValue;
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for Manager$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_manager(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			managerSortAndFilterPage.mouseHoverOnGridViewLabels(managerSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			managerSortAndFilterPage.clickOnSortIcon(
					managerSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for Manager$")
	public void user_should_able_to_sort_the_records_with_default_order_for_manager() throws Throwable {
		String value = managerSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = ManagerSortAndFilterPage.defaultSortValue;
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to click on the filter icon for below column for Manager$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_manager(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			managerSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			managerSortAndFilterPage.clickOnFilterIconForGridView(
					managerSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to validate the filter condition all options for Manager$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_manager(List<String> entity)
			throws Throwable {
		managerSortAndFilterPage.clickOnFilterCondition();
		for (int i = 0; i < entity.size(); i++) {
			managerSortAndFilterPage
					.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']");
			managerSortAndFilterPage.verifyValueOfFilterCondition(managerSortAndFilterPage.findElementByDynamicXpath(
					"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to see tab count as per searched keyword for before any condition for Manager$")
	public void user_able_to_see_tab_count_as_per_searched_keyword_for_before_any_condition_for_manager()
			throws Throwable {
		String beforeApplyFilterValue = managerSortAndFilterPage
				.verifyTheManagerGridCountAfterApplyFilterConditionOnTab();
		// String beforeApplyFilterValue =
		// ManagerSortAndFilterPage.tabCountAfterCondition;
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);
	}

	@And("^User able to select the (.+) from filter condition for Manager$")
	public void user_able_to_select_the_from_filter_condition_for_manager(String filtercondition) throws Throwable {
		managerSortAndFilterPage.clickOnFilterCondition();
		managerSortAndFilterPage
				.clickOnFilterConditionForManagerGridView(managerSortAndFilterPage.findElementByDynamicXpath(
						"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for Manager$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_manager(String filterconditionvalue)
			throws Throwable {
		managerSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button on Manager grid view$")
	public void user_able_to_click_on_the_apply_button_on_manager_grid_view() throws Throwable {
		managerSortAndFilterPage.clickOnApplyFilterIconForManagerGridView();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on Manager grid view$")
	public void user_should_able_to_verify_the_grid_count_on_manager_grid_view() throws Throwable {
		String countTabAfterFilter = managerSortAndFilterPage.verifyTheManagerGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter = ManagerSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = managerSortAndFilterPage.verifyTheStyleGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition / 10; i++) {
				action.waitForDomToComplete(WebDriverManager.getDriver());
				action.scrollToBottom();
				Action.pause(3000);
				String presentGridAllData = managerSortAndFilterPage.verifyTheStyleGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			managerSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The grid view and tab count mismatch");}
	}

	@And("^User should able to verify the Tab count on Manager grid view$")
	public void user_should_able_to_verify_the_tab_count_on_manager_grid_view() throws Throwable {
		String countTabAfterFilter = managerSortAndFilterPage.verifyTheManagerGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter = ManagerSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = managerSortAndFilterPage.verifyTheStyleGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= beforeApplyFiltertabCountValue; i++) {
				action.scrollToBottom();
				Action.pause(1000);
				String presentGridAllData = managerSortAndFilterPage.verifyTheStyleGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			managerSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The tab count and grid view count mismatch");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Reset Button on Manager grid view$")
	public void user_able_to_click_on_the_reset_button_on_manager_grid_view() throws Throwable {
		managerSortAndFilterPage.clickOnApplyFilterIconForManagerGridViewForReset();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button on Manager grid view$")
	public void user_able_to_click_on_the_cancel_button_on_manager_grid_view() throws Throwable {
		managerSortAndFilterPage.clickOnApplyFilterIconForManagerGridViewForCancel();
		Reporter.addScreenCapture();
	}

}
