package qa.unicorn.ad.productmaster.webui.stepdefs;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerPage;
import qa.unicorn.ad.productmaster.webui.pages.ManagerSaveAsDraftPage;
public class ManagerSaveAsDraftStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString ;
	String value;
	
	ManagerSaveAsDraftPage saveasdraft = new ManagerSaveAsDraftPage("AD_PM_CreateManagerSaveasdraftPage");
	
	@Then("^User should be able to see the Save as Draft button on Enter Manager Details Page$")
    public void user_should_be_able_to_see_the_save_as_draft_button_on_enter_manager_details_page() throws Throwable {
		saveasdraft.verifySaveAsdraftbuttoninCreateMManagerPage();
    }
	@And("^user clicks on the Save as Draft button in Create Manager Page$")
    public void user_clicks_on_the_save_as_draft_button_in_create_manager_page() throws Throwable {
		saveasdraft.clickOnSaveAsdraftbuttoninCreateManagerPage();
    }
	@And("^User should be able to enter the draft name in the Draft Wizard$")
    public void user_should_be_able_to_enter_the_draft_name_in_the_draft_wizard() throws Throwable {
		String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		Reporter.addStepLog("the window handle is" + winHandleBefore);
		saveasdraft.enterdraftnameindraftwizard();
		 }
	@And("^user clicks on the Cancel button in the Draft Wizard$")
    public void user_clicks_on_the_cancel_button_in_the_draft_wizard() throws Throwable {
		saveasdraft.clickoncancelbuttonindraftwizard();
    }
    @And("^user clicks on the Save as Draft button in the Draft Wizard$")
    public void user_clicks_on_the_save_as_draft_button_in_the_draft_wizard() throws Throwable {
    	saveasdraft.clickonsaveasdraftbuttonindraftwizard();
    }
    @Then("^User should be able to see the Min length complexity error message in the Draft Wizard$")
    public void user_should_be_able_to_see_the_min_length_complexity_error_message_in_the_draft_wizard() throws Throwable {
    	saveasdraft.validaterrormsgforlessthan3charindraftwizard();
    }
    @Then("^User should be able to see the Draft name can't be empty error message in the Draft Wizard$")
    public void user_should_be_able_to_see_the_draft_name_cant_be_empty_error_message_in_the_draft_wizard() throws Throwable {
    	saveasdraft.validaterrormsgfordraftnameasblankindraftwizard();
    }
    @And("^User enters the draft name which is of less than 3 characters in the Draft Wizard$")
    public void user_enters_the_draft_name_which_is_of_less_than_3_characters_in_the_draft_wizard() throws Throwable {
    	String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		Reporter.addStepLog("the window handle is" + winHandleBefore);
		saveasdraft.enterdraftnameoflessthan3charindraftwizard();
		 
    }
    @Then("^User should be able to see the save as a draft heading in the Draft Wizard$")
    public void user_should_be_able_to_see_the_save_as_a_draft_heading_in_the_draft_wizard() throws Throwable {
        
    }
    
    @Then("^user should be able to see an Alert messaage stating the Draft has been created$")
    public void user_should_be_able_to_see_an_alert_messaage_stating_the_draft_has_been_created() throws Throwable {
    	Thread.sleep(2000);
        Alert alt=WebDriverManager.getDriver().switchTo().alert();
      String actualmsg=alt.getText();
      Reporter.addStepLog("the alert handle is" + actualmsg);
        //String expmsg="createdraft@ manager was saved successfully";
        //Assert.assertEquals(actualmsg, expmsg);
        alt.accept();
        
    }
}
