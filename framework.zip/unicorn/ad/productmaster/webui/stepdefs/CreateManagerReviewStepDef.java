package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerContactPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerReviewPage;
//import qa.unicorn.ad.productmaster.webui.pages.CreateManagerPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
public class CreateManagerReviewStepDef {
	CreateManagerReviewPage cr=new CreateManagerReviewPage("AD_PM_CreateManagerReviewPage");
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateManagerReviewPage"));
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL=SSOLoginPage.URL+"#/manager/reviewPage";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateManager3038.xlsx";
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	WebElement myElement;
	int rowIndex,cellIndex;
	SoftAssert sftAst = new SoftAssert();
	@And("^User clicks on the Submit Button on Manager Review Page$")
    public void user_clicks_on_the_submit_button_on_manager_review_page() throws Throwable {
		Reporter.addCompleteScreenCapture();
		Thread.sleep(1000);
        cr.clickOnSubmitButton();
        Thread.sleep(1000);
    }
	@Then("^The value for the following attributes in Review Manager Flyout should match what we have given earlier$")
    public void the_value_for_the_following_attributes_in_review_manager_flyout_should_match_what_we_have_given_earlier(List<String> entity) throws Throwable {
		for (int i=0;i<entity.size();i++) {
        	myElement = cr.findElementByDynamicXpath("//small[contains(text(),'"+entity.get(i)+"')]/parent::p/following-sibling::span");
        	cr.verifyTextInElement(PMPageGeneric.UIPassedValues.get(entity.get(i)), myElement);
        	
        	Reporter.addStepLog("verified the value for "+entity.get(i));
        }
        Reporter.addScreenCapture();
    }
	
	@And("^user clicks on the Save as Draft button in Create Manager Review Page$")
    public void user_clicks_on_the_save_as_draft_button_in_create_manager_review_page() throws Throwable {
        cr.clickOnSaveAsdraftbuttoninCreateManagerReviewPage();
    }
	@Then("^User should be able to go to Manager Review page$")
    public void user_should_be_able_to_go_to_manager_review_page() throws Throwable {
        Assert.assertEquals(action.getCurrentURL(),pageURL);
        Reporter.addStepLog("The current URL is "+pageURL);
        Reporter.addScreenCapture();
    }
	@And("^User clicks on the Back Link on Manager Review Page$")
    public void user_clicks_on_the_back_link_on_manager_review_page() throws Throwable {
        cr.clickOnBackLink();
    }
	@And("^User clicks on the previous button on Manager Review Page$")
    public void user_clicks_on_the_previous_button_on_manager_review_page() throws Throwable {
		cr.clickOnPreviousButton();
    }
	@Then("^User should be able to see the below attributes in Create Manager Review Page$")
    public void user_should_be_able_to_see_the_below_attributes_in_create_manager_review_page(List<String> entity) throws Throwable {
		for(int i =0;i<entity.size();i++) {
    		cr.verifyElementsoncreatemanagerreviewpage(cr.findElementByDynamicXpath("//*[text()='"+entity.get(i)+"']"));
			 Reporter.addScreenCapture();
		}
    }
	@Then("^User should be able to see the Back Link in Create Manager Review Page$")
    public void user_should_be_able_to_see_the_back_link_in_create_manager_review_page() throws Throwable {
        cr.verifyBackLink();
    }
	@Then("^User should be able to see the Review Header in Review Page$")
    public void user_should_be_able_to_see_the_review_header_in_review_page() throws Throwable {
        cr.verifyreviewheader();
    }
    @Then("^User should be able to see the updated values for the following attributes in Manager Review page$")
    public void user_should_be_able_to_see_the_updated_values_for_the_following_attributes_in_manager_review_page(List<String> attribute) throws Throwable {
    	 sheet = exlObj.getSheet("Valid");
			
			for (int i=0;i<attribute.size();i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myElement = cr.findElementByDynamicXpath("//small[text()='"+attribute.get(i)+"']/parent::p/following-sibling::*");
			Assert.assertTrue(myElement.getText().contains((String)exlObj.getCellData(sheet, rowIndex, cellIndex)));
			Reporter.addStepLog("verified the value for "+attribute.get(i));
		
					
			}
			Reporter.addScreenCapture();
    }
    
    @Then("^User should be able to see Review Header in Manager Review page$")
    public void user_should_be_able_to_see_review_header_in_manager_review_page() throws Throwable {
        action.getElement("Review Header").isDisplayed();
        Reporter.addStepLog("Verified that Review Header is getting displayed");
        Reporter.addScreenCapture();
    }
    
    @And("^User clicks on Previous Button in Manager Review page$")
    public void user_clicks_on_previous_button_in_manager_review_page() throws Throwable {
        action.click(action.getElement("Previous Button"));
        Reporter.addStepLog("clicked on Previous Button");
    }
    
    @And("^User clicks on Back Link in Manager Review page$")
    public void user_clicks_on_back_link_in_manager_review_page() throws Throwable {
    	action.click(action.getElement("Back Link"));
        Reporter.addStepLog("clicked on Back Link");
    }
    
	@Then("^User should able to verify the (.+) is same in Review Page$")
	public void user_should_able_to_verify_the_same_data_in_review_page(String data) throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateManager.xlsx";
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		if (data.contains("Valid")) {
			sheetName = "Test";
		}
		sheet = exlObj.getSheet(sheetName);
		int count = sheet.getRow(0).getLastCellNum();
		for(int i = 1; i < count; i++) {
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, data);
			String label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex - 1, i);
			cr.getcommonattributevalue(label);
		}
		cr.getcommonContactvalue();
		Reporter.addScreenCapture();
	}
}
