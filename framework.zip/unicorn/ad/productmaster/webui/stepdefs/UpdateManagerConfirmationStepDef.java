package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;
import qa.framework.utils.SystemProcess;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerConfirmationPage;

public class UpdateManagerConfirmationStepDef {
	
	UpdateManagerConfirmationPage confirmationPage = new UpdateManagerConfirmationPage("AD_PM_UpdateManagerConfirmationPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateManager.xlsx";
	String mandatorydetails, sheetName, managerCode = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue, vestmarkmanager,managerId = null;
	String testmucNHLogFilePath, testmucDHLogFilePath = "";
	String kafkaPath = "C://PM_SANITYTEST//kafka_2.13-3.2.1//bin//windows";
	Process p,p1 = null;
	Process p2 = null;
	Process p3 = null;
	Process p4 = null;
	BufferedReader br1 = null;
	BufferedReader br2 = null;
	
	@Then("^User should be able to see Confirmation Page in Update Manager Flow$")
    public void user_should_be_able_to_see_confirmation_page_in_update_manager_flow() {
        Assert.assertTrue(confirmationPage.isUserOnConfirmationPage());
        
    }

	@And("^Data given (.+) while updating Manager should be stored in Data Base$")
    public void data_given_while_updating_manager_should_be_stored_in_data_base(String mandatorydetails) throws SQLException {
        Assert.assertTrue(confirmationPage.isManagerUpdatedSuccessfully());
        String managerCode = confirmationPage.getManagerCode();

        managerCode = managerCode.substring(9);
        System.out.println(managerCode);
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		String[] temp = null;
		String tName = Thread.currentThread().getName();
		synchronized (tName) {

			mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			int reviewDataIndex = rowIndex+4;

			String excelData;
			List<String> excelDataGiven = new ArrayList<String>();
			int cellnum = 2;
			int i = 2;

			String label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
			if (label == "")
				label = "isEmpty";
			while (label != "isEmpty") {

				excelData = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, reviewDataIndex, i);

				if (excelData == "") {
					excelData = "isEmpty";
				} else if (excelData.equalsIgnoreCase("yes")) {
					excelData = "Yes";
				} else if (excelData.equalsIgnoreCase("no")) {
					excelData = "No";
				} 

				if(label.contains("Vestmark Manager Name"))
					vestmarkmanager = excelData;
				
				if (label.contains("ignore")) {
					cellnum++;
					i++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
					if (label == "")
						label = "isEmpty";
				} else {
					
					
					excelDataGiven.add(excelData);
					// System.out.println(excelData+"--"+label+ " -Data from Excel");

					cellnum++;
					i++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
					if (label == "")
						label = "isEmpty";

				}

			}

			pmdb.DBConnectionStart();

	    	String SQLquery, labelname = null;
	    	String dbDataIterator = "testNull";
	    	List<String> dbData = new ArrayList<String>();
	    	ResultSet rs;
	    	
	    	
	    	sheetName = "SQLQuery";
	    	
	    	cellnum = 1;
	    	label  =  PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
	    			//(String) exlObj.getCellData(sheet, cellnum, 0).toString();
	    	ArrayList<String> tempData = new ArrayList<String>();
	    	
			if(label == "")
				label = "isEmpty";
			
			while (label != "isEmpty") {
				
				if(label.contains("ignore")) {
					cellnum++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
							//(String) exlObj.getCellData(sheet, cellnum, 0);
						if(label == "")
							label = "isEmpty";
				}
				else {
					
					dbDataIterator = "testnull";
					SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
							//(String) exlObj.getCellData(sheet, cellnum, 1);
					labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
							//(String) exlObj.getCellData(sheet, cellnum, 2);
					
		    		SQLquery = SQLquery.replace("@data", "'"+managerCode+"'");
		    		rs= DBManager.executeSelectQuery(SQLquery);
		    		
		   
		    		while(rs.next()) {
		    			
		    				dbDataIterator = rs.getString(labelname);
		    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
			    					dbDataIterator = "isEmpty";
			    					if(label.contains("radiobutton")) {
				    					dbDataIterator = "Not defined";
				    				}
			    			}
		    				
		    				tempData.add(dbDataIterator);
		    				
		    		 }
		    		//to handle Zero records from DB 
		    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
		    			dbDataIterator = "isEmpty";
		    		}
		    		//to handle Eye check override value
		    		if(label.equals("4 Eye Check Override"))
		    		{
		    			switch (dbDataIterator) {
						case "t":
							dbDataIterator = "Yes";
							break;
						case "f":
							dbDataIterator = "No";
							break;
						default:
							dbDataIterator = "Unexpected Value";
							break;
						}
		    		}
		    		//to handle multiple values for same column
		    		if(tempData.size() > 1) {
		    			Collections.sort(tempData);
		    			dbDataIterator = "";
		    			for (String G : tempData) {
								dbDataIterator = dbDataIterator+G+",";
						}
		    			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
		    		}
		    		tempData.clear();
		    		
		    		dbData.add(dbDataIterator);
					cellnum++;
		    		label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
		    		if(label == "")
		    			label = "isEmpty";
				}
				
				
			}
			
			//exlObj.closeWorkBook();
			pmdb.DBConnectionClose();

			cellnum = 1;
			int listno = 1;
			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
			if (label == "")
				label = "isEmpty";
			while (label != "isEmpty") {

				if (label.contains("ignore")) {
					cellnum++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if (label == "")
						label = "isEmpty";
				} else {

					try {
						 //System.out.println(label +" :DB -- "+ dbData.get(listno - 1));
						 //System.out.println(label +" :Excel -- "+ excelDataGiven.get(listno - 1));
						String message = label + " :DB -- " + dbData.get(listno - 1) + "::::" + label + " :Excel -- "+ excelDataGiven.get(listno - 1)+" -- for Manager Code -- "+managerCode;
						assertTrue(dbData.get(listno - 1).equals(excelDataGiven.get(listno - 1)), message);
					} catch (Exception e) {
						// Data Base value is not same as value provided
						Reporter.addStepLog("Data Base value is not same as value provided");
					}

					cellnum++;
					listno++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if (label == "")
						label = "isEmpty";
				}
			}

		}
	
        
        
    }
	
	@And("^Notification Hub Process is started for Update Manager with (.+)$")
	public void notification_hub_process_is_started_for_update_manager_with(String mandatorydetails) throws IOException {
				
			String filename = mandatorydetails.split("_")[1];
			testmucNHLogFilePath = System.getProperty("user.dir") + "/temp/topic-NotiHub"+filename+".log";
			
			FileManager.getFileManagerObj().deleteFile(testmucNHLogFilePath);
			
			String command = "";
			String environment = SSOLoginPage.UIEnvironment.toLowerCase();
			
			if (environment.equalsIgnoreCase("dev")) {
				command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC";
			}
			if (environment.equalsIgnoreCase("qa")) {
				command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.QA.OUT.WMAP.TOPIC";
			}
			if (environment.equalsIgnoreCase("uat")) {
				command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.UAT.OUT.WMAP.TOPIC";
			}
		
			// Redirecting to a pipe and applying a filter with identifier as filter value
			String identifier = "ProductMaster";
			command = command + " | find /i \"" + identifier + "\" >>" + testmucNHLogFilePath;
			//command = command + " | find /i \"" + identifier + "\"";
		
			Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		
			ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
			pb.directory(new File(kafkaPath));
			p1 = pb.start();
			
	
		}

    @And("^Data Hub Process is started for Update Manager with (.+)$")
    public void data_hub_process_is_started_for_update_manager_with(String mandatorydetails) throws IOException {
        
			String filename = mandatorydetails.split("_")[1];
			testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-DataHub"+filename+".log";
		
		FileManager.getFileManagerObj().deleteFile(testmucDHLogFilePath);
		String command = "";
	
		String environment = SSOLoginPage.UIEnvironment;
		if (environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC";
		}
		if (environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.QA.OUT.WMAP.TOPIC";
		}
		if (environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.UAT.OUT.WMAP.TOPIC";
		}
	
		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier ="ProductMaster";

		command = command + " | find /i \"" + identifier + "\" >>" + testmucDHLogFilePath;
	
		Reporter.addStepLog("<b>Kafka Command: </b>" + command);
	
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p2 = pb.start();

    	
    }
    
    @And("^a notification is sent to Notification Hub after Update Manager$")
    public void a_notification_is_sent_to_notification_hub_after_update_manager() throws IOException, InterruptedException {
    	Thread.sleep(10000);

		managerCode = confirmationPage.getManagerCode().trim(); 
		managerCode = managerCode.substring(9).trim();
    	
		String identifier = "|| Id: @data || Code: null || Manager Updated!";
		identifier = identifier.replace("@data", managerCode);
		
		FileReader fr = new FileReader(testmucNHLogFilePath);
		BufferedReader br = new BufferedReader(fr);

		
		String line;

		while ((line = br.readLine()) != null) {

			if(line.contains(identifier)) {
				Action.pause(1000);
				p1.destroy();
				 System.out.println("Successful!!!!!!!");
				break;
			}
			
		}

		
		p1.destroyForcibly();
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucNHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Identifier: </b>" + identifier);

		
		if (line.contains(identifier)) {
			Reporter.addStepLog("<p style = 'color:green'>Identifier is Matched in Notification</p>");
			Assert.assertTrue(line.contains(identifier));
		}
		
		br.close();
		fr.close();
    }

    @And("^a Payload is sent to Data Hub after Update Manager$")
    public void a_payload_is_sent_to_data_hub_after_update_manager() throws InterruptedException, IOException {
    	Thread.sleep(10000);

		FileReader fr = new FileReader(testmucDHLogFilePath);
		BufferedReader br = new BufferedReader(fr);

		String line;

		while ((line = br.readLine()) != null) {

			if (line.contains(vestmarkmanager)) {
				Action.pause(1000);
				p2.destroy();
				 //System.out.println("Successful!!!!!!!");
				break;
			}
		}

		p2.destroyForcibly();
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Identifier: </b>" + vestmarkmanager);

		if (line.contains(vestmarkmanager)) {
			Reporter.addStepLog("<p style = 'color:green'>Identifier is Matched in Notification</p>");
			Assert.assertTrue(line.contains(vestmarkmanager));
		}
		
		
		br.close();
		fr.close();
    }
    
    @And("^Java command prompts and Processes should be closed$")
    public void java_command_prompts_and_processes_should_be_closed() throws IOException {
    	SystemProcess.killProcess("java.exe");
    	SystemProcess.killProcess("cmd.exe");
    }
    
    @And("^Test Notification Hub Process is started for Update Manager with (.+)$")
    public void test_notification_hub_process_is_started_for_update_manager_with(String mandatorydetails) throws IOException {
    	
				//String filename = mandatorydetails.split("_")[1];
				//testmucNHLogFilePath = System.getProperty("user.dir") + "/temp/topic-NotiHub"+filename+".log";
			
			//FileManager.getFileManagerObj().deleteFile(testmucNHLogFilePath);
			
			String command = "";
		
			String environment = SSOLoginPage.UIEnvironment.toLowerCase();
			if (environment.equalsIgnoreCase("dev")) {
				command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC";
			}
			if (environment.equalsIgnoreCase("qa")) {
				command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.QA.OUT.WMAP.TOPIC";
			}
			if (environment.equalsIgnoreCase("uat")) {
				command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.UAT.OUT.WMAP.TOPIC";
			}
		
			// Redirecting to a pipe and applying a filter with identifier as filter value
			String identifier = "ProductMaster";
			//command = command + " | find /i \"" + identifier + "\" >>" + testmucNHLogFilePath;
			command = command + " | find /i \"" + identifier + "\"";
		
			Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		
			ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
			
			pb.directory(new File(kafkaPath));
			p3 = pb.start();
			
			br1 = new BufferedReader(new InputStreamReader(p3.getInputStream()));
		
    }

    @And("^Test a notification is sent to Notification Hub after Update Manager$")
    public void test_a_notification_is_sent_to_notification_hub_after_update_manager() throws IOException, InterruptedException, AWTException {
	    	Thread.sleep(10000);

	    
			managerCode = confirmationPage.getManagerCode().trim(); 
			managerCode = managerCode.substring(9).trim();
	    	
	    	
			String identifier = "|| Id: @data || Code: null || Manager Updated!";
			//identifier = identifier.replace("@data", managerCode);
			
	
			
			String line;
	
			StringBuilder sb = new StringBuilder();
	
			int i=0;
			//(line = br1.readLine()) != null
			while (true) {
				
				if((br1.readLine().isEmpty())) {
					break;
				
				}
				else {
					line = br1.readLine();
					
					sb.append(line + "\n");
					System.out.println("Inside While Loop");
					System.out.println(line);
					if (line.contains(identifier)) {
						break;
					}else {
						continue;
					}
				}
				
				
				
			}
	
			System.out.println("Outside While loop");
			System.out.println(sb);
			p3.destroyForcibly();
			//Reporter.addStepLog("<b>Notification from NH: </b>" + line);
			Reporter.addStepLog("<b>Identifier: </b>" + identifier);
	
			/*
			if (line.contains(identifier)) {
				Reporter.addStepLog("<p style = 'color:green'>Identifier is Matched in Notification</p>");
				Assert.assertTrue(line.contains(managerCode));
			}
			*/
			br1.close();		
			//br.close();
			//fr.close();
    }
    
    @And("^Test Data Hub Process is started for Update Manager with (.+)$")
    public void test_data_hub_process_is_started_for_update_manager_with(String mandatorydetails) throws IOException {

				String filename = mandatorydetails.split("_")[1];
				testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-DataHub"+filename+".log";
			
			//FileManager.getFileManagerObj().deleteFile(testmucDHLogFilePath);
			String command = "";
		
			String environment = SSOLoginPage.UIEnvironment;
			if (environment.equalsIgnoreCase("dev")) {
				command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC";
			}
			if (environment.equalsIgnoreCase("qa")) {
				command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.QA.OUT.WMAP.TOPIC";
			}
			if (environment.equalsIgnoreCase("uat")) {
				command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.UAT.OUT.WMAP.TOPIC";
			}
		
			// Redirecting to a pipe and applying a filter with identifier as filter value
			String identifier ="ProductMaster";
		
			//command = command + " | find /i \"" + identifier + "\" >>" + testmucDHLogFilePath;
			command = command + " | find /i \"" + identifier + "\"";
		
			Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		
			ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
			pb.directory(new File(kafkaPath));
			p4 = pb.start();
			
			br2 = new BufferedReader(new InputStreamReader(p4.getInputStream()));

    }

    

    @And("^Test a Payload is sent to Data Hub after Update Manager$")
    public void test_a_payload_is_sent_to_data_hub_after_update_manager() throws InterruptedException, IOException {
	    	Thread.sleep(10000);
	
			//FileReader fr = new FileReader(testmucDHLogFilePath);
			//BufferedReader br = new BufferedReader(fr);
	
	    	
			p4.destroyForcibly();
			String line;
			StringBuilder sb = new StringBuilder();
			while ((line = br2.readLine()) != null) {
	
				sb.append(line + "\n");
				System.out.println("Inside While Loop");
				System.out.println(line);
//				if (line.contains(vestmarkmanager)) {
//					Action.pause(1000);
//					p4.destroy();
//					 //System.out.println("Successful!!!!!!!");
//					break;
//				}
			}
	
			System.out.println("Outside While loop");
			System.out.println(sb);
			//Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
			//Reporter.addStepLog("<b>Notification from NH: </b>" + line);
			Reporter.addStepLog("<b>Identifier: </b>" + vestmarkmanager);
	
			/*
			if (line.contains(vestmarkmanager)) {
				Reporter.addStepLog("<p style = 'color:green'>Identifier is Matched in Notification</p>");
				Assert.assertTrue(line.contains(vestmarkmanager));
			}
			*/
			br2.close();
			//br.close();
			//fr.close();
    }
    
    @And("^User clicks on Done button in Confirmation page in Update Manager flow$")
    public void user_clicks_on_done_button_in_confirmation_page_in_update_manager_flow() {
        confirmationPage.clickOnDoneButton();
    }
    @And("^Notification Hub Process is started for update Manager flow with (.+)$")
    public void notification_hub_process_is_started_for_update_manager_flow_with(String mandatorydetails) throws Throwable {
    	String filename = mandatorydetails.split("_")[1];
		testmucNHLogFilePath = System.getProperty("user.dir") + "/temp/topic-NotiHub" + filename + ".log";
		System.out.println(testmucNHLogFilePath);
		FileManager.getFileManagerObj().deleteFile(testmucNHLogFilePath);
		String command = "";
		// String environment =
		// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.QA.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.UAT.OUT.WMAP.TOPIC";
		}
		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier = "ProductMaster";
		command = command + " | find /i \"" + identifier + "\" >>" + testmucNHLogFilePath;
		Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		// Thread.sleep(10000);
    }

    @And("^Data Hub Process is started for update Manager flow with (.+)$")
    public void data_hub_process_is_started_for_update_manager_flow_with(String mandatorydetails) throws Throwable {
    	String filename = mandatorydetails.split("_")[1];
	    testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-DataHub" + filename + ".log";
		//String testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-testmucDataHub.log";
		FileManager.getFileManagerObj().deleteFile(testmucDHLogFilePath);
		String command = "";
		// String environment =
		// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment;
		if(environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.QA.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.UAT.OUT.WMAP.TOPIC";
		}
		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier = "Manager";
		command = command + " | find /i \"" + identifier + "\" >>" + testmucDHLogFilePath;
		Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();
    }

    @And("^a notification is sent to Notification Hub after Update Manager flow on UI$")
    public void a_notification_is_sent_to_notification_hub_after_update_manager_flow_on_ui() throws Throwable {
    	Thread.sleep(10000);
	     managerId = confirmationPage.getManagerId();
		FileReader fr = new FileReader(testmucNHLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		String line;
		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;
		while((line = br.readLine()) != null) {
			if(line.contains(managerId)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucNHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Manager Id: </b>" + managerId);
		if(line.contains(managerId)) {
			Reporter.addStepLog("<p style = 'color:green'>Manager Id is Matched in Notification</p>");
			Assert.assertTrue(line.contains(managerId));
		}
		else {
			Assert.fail("No Response from Notification Hub");
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
    }

    @And("^a Payload is sent to Data Hub after Update Manager flow on UI$")
    public void a_payload_is_sent_to_data_hub_after_update_manager_flow_on_ui() throws Throwable {
    	Thread.sleep(10000);
		managerId = confirmationPage.getManagerId();
		FileReader fr = new FileReader(testmucDHLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		String line;
		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;
		while((line = br.readLine()) != null) {
			if(line.contains(managerId)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
		Reporter.addStepLog("<b>Notification from DH: </b>" + line);
		Reporter.addStepLog("<b>Manager Id: </b>" + managerId);
		if(line.contains(managerId)) {
			Reporter.addStepLog("<p style = 'color:green'>Manager Id is Matched in Notification</p>");
			Assert.assertTrue(line.contains(managerId));
		}
		else {
			Assert.fail("No Payload is recieved from Data Hub");
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
    }


}
