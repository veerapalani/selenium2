package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.ETFSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.MutualFundsSortAndFilterPage;

public class ETFSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	MutualFundsSortAndFilterPage mutualFundsSortAndFilterPage = new MutualFundsSortAndFilterPage(
			"AD_PM_MutualFundsSortAndFilterPage");
	ETFSortAndFilterPage eTFSortAndFilterPage = new ETFSortAndFilterPage("AD_PM_ETFSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/ETFSortAndFilter.xlsx";
	String sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	WebElement myElement;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ETFSortAndFilterPage"));

	@When("^User enter valid (.+) in global search box for ETF$")
	public void user_enter_valid_in_global_search_box_for_etf(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String ETFSearchValue = (String) exlObj.getCellData(sheet, rowIndex, 1);

		exlObj.closeWorkBook();
		if (ETFSearchValue != "") {
			eTFSortAndFilterPage.searchETFValue(ETFSearchValue);
		}
		Reporter.addScreenCapture();
	}

	@And("^user clicks on \"([^\"]*)\" on landing page for ETF$")
	public void user_clicks_on_something_on_landing_page_for_etf(String strArg1) throws Throwable {
		mutualFundsSortAndFilterPage.clickOnSeeAllResultsForMFLayout();
		Reporter.addScreenCapture();
	}

	@And("^user is able to see search results in \"([^\"]*)\" tab under ETF accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_etf_accordion(String strArg1)
			throws Throwable {
		mutualFundsSortAndFilterPage.verifyTheSearchedResultInAllTabMF();
		Reporter.addScreenCapture();
	}

	@And("^user click on \"([^\"]*)\" tab on landing page for ETF$")
	public void user_click_on_something_tab_on_landing_page_for_etf(String strArg1) throws Throwable {
		eTFSortAndFilterPage.verifyETFTab();
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design for ETF$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design_for_etf(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage.mouseHoverOnMFGridViewLabels(mutualFundsSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			mutualFundsSortAndFilterPage.verifyMFGridViewLabelsWithSortIcons(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for ETF$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_etf(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage.mouseHoverOnMFGridViewLabels(mutualFundsSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			mutualFundsSortAndFilterPage.clickOnFundNameSortIcon(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for ETF$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_etf() throws Throwable {
		String value = mutualFundsSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = MutualFundsSortAndFilterPage.ascSortValue;
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for ETF$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_etf(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage.mouseHoverOnMFGridViewLabels(mutualFundsSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			mutualFundsSortAndFilterPage.clickOnFundNameSortIcon(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for ETF$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_etf() throws Throwable {
		String value = mutualFundsSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = MutualFundsSortAndFilterPage.descSortValue;
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for ETF$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_etf(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			mutualFundsSortAndFilterPage.mouseHoverOnMFGridViewLabels(mutualFundsSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			mutualFundsSortAndFilterPage.clickOnFundNameSortIcon(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for ETF$")
	public void user_should_able_to_sort_the_records_with_default_order_for_etf() throws Throwable {
		String value = mutualFundsSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = MutualFundsSortAndFilterPage.defaultSortValue;
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to see grid view of all records as per search for ETF$")
	public void user_able_to_see_grid_view_of_all_records_as_per_search_for_etf() {
		mutualFundsSortAndFilterPage.verifySearchedGridViewDisplay();
		Reporter.addScreenCapture();
	}

	@And("^User able to see tab count as per searched keyword for ETF$")
	public void user_able_to_see_tab_count_as_per_searched_keyword_for_etf() throws Throwable {
		String beforeApplyFilterValue = eTFSortAndFilterPage.verifyTheMFGridCountAfterApplyFilterConditionOnTabForETF();
		// String beforeApplyFilterValue = ETFSortAndFilterPage.tabCountAfterCondition;
		System.out.println("ETF search " + beforeApplyFilterValue);
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		System.out.println("Count of ETF" + beforeApplyFilterValue);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for ETF$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_etf(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			mutualFundsSortAndFilterPage.verifyMFGridViewLabelsWithFilterIcons(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to click on the filter icon for below column for ETF$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_etf(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			mutualFundsSortAndFilterPage.clickOnFilterIconForMFGridView(
					mutualFundsSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to validate the filter condition all options for ETF$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_etf(List<String> entity)
			throws Throwable {
		mutualFundsSortAndFilterPage.clickOnFilterSelection();
		for (int i = 0; i < entity.size(); i++) {
			mutualFundsSortAndFilterPage
					.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']");
			mutualFundsSortAndFilterPage
					.verifyValueOfFilterCondition(mutualFundsSortAndFilterPage.findElementByDynamicXpath(
							"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to select the (.+) from filter condition for ETF$")
	public void user_able_to_select_the_from_filter_condition_for_etf(String filtercondition) throws Throwable {
		mutualFundsSortAndFilterPage.clickOnFilterSelection();
		mutualFundsSortAndFilterPage
				.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']");
		mutualFundsSortAndFilterPage
				.clickOnFilterConditionForMFGridView(mutualFundsSortAndFilterPage.findElementByDynamicXpath(
						"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for ETF$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_etf(String filterconditionvalue)
			throws Throwable {
		mutualFundsSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button for ETF$")
	public void user_able_to_click_on_the_apply_button_for_etf() throws Throwable {
		mutualFundsSortAndFilterPage.clickOnApplyFilterIconForMFGridView();
		mutualFundsSortAndFilterPage.verifyFilteredGridDataViewDisplay();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on ETF grid view$")
	public void user_should_able_to_verify_the_grid_count_on_etf_grid_view() throws Throwable {

		String presentGridData = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		//System.out.println("parseValueOfGridCountAfterFilterCondition:" + parseValueOfGridCountAfterFilterCondition);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

		String countTabAfterFilter = eTFSortAndFilterPage.verifyTheMFGridCountAfterApplyFilterConditionOnTabForETF();
		// String countTabAfterFilter = ETFSortAndFilterPage.tabCountAfterCondition;

		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);
		//System.out.println("tabCountAfterFilterCondition:" + tabCountAfterFilterCondition);
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10) {
			for (int i = 0; i <= tabCountAfterFilterCondition/10; i++) {
				action.scrollToBottom();
				action.pause(2000);
				String presentGridAllData = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			mutualFundsSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
			Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
					"The grid view and tab count mismatch");
		}

	}

	@And("^User should able to verify the Tab count on ETF grid view$")
	public void user_should_able_to_verify_the_tab_count_on_etf_grid_view() throws Throwable {

		String presentGridData = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		String countTabAfterFilter = eTFSortAndFilterPage.verifyTheMFGridCountAfterApplyFilterConditionOnTabForETF();
		// String countTabAfterFilter = ETFSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);
		//System.out.println("tabCountAfterFilterCondition:::"+tabCountAfterFilterCondition);
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10) {
			for (int i = 0; i <= beforeApplyFiltertabCountValue; i++) {
				action.scrollToBottom();
				action.pause(1000);
				String presentGridAllData = mutualFundsSortAndFilterPage.verifyTheMFGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			mutualFundsSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The tab count and grid view count mismatch");
		}
	}

	@And("^User able to click on the Reset Button for ETF$")
	public void user_able_to_click_on_the_reset_button_for_etf() throws Throwable {
		mutualFundsSortAndFilterPage.clickOnApplyFilterIconForMFGridViewForReset();
		mutualFundsSortAndFilterPage.verifyFilteredGridDataViewDisplay();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button for ETF$")
	public void user_able_to_click_on_the_cancel_button_for_etf() throws Throwable {
		mutualFundsSortAndFilterPage.clickOnApplyFilterIconForMFGridViewForCancel();
		mutualFundsSortAndFilterPage.verifyFilteredGridDataViewDisplay();
		Reporter.addScreenCapture();
	}
}
