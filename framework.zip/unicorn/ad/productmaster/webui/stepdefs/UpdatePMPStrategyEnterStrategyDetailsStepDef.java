package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.UpdatePMPStrategyEnterStrategyDetailsPage;

public class UpdatePMPStrategyEnterStrategyDetailsStepDef {

	UpdatePMPStrategyEnterStrategyDetailsPage strategyDetailsPage = new UpdatePMPStrategyEnterStrategyDetailsPage("AD_PM_UpdatePMPStrategyEnterStrategyDetailsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
	
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName;
	String label, attributeValue, uiValue,dbValue = null;
	
	public static int count;
	
	@Then("^Values for Attributes in Enter Strategy Details Page of Update PMP Strategy Flow should match the values for attributes stored in DB$")
    public void values_for_attributes_in_enter_strategy_details_page_of_update_pmp_strategy_flow_should_match_the_values_for_attributes_stored_in_db() {
		sheetName = "Conversion_Validation";
		   sheet = exlObj.getSheet(sheetName);
		   int rownum = 1;
		   count = 0;
		   label = (String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if((label == "") || (label.contains("Primary Benchmark")))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || (label.contains("NIESDP"))) {
							rownum++;
			    			label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if((label == "") ||(label.contains("Primary Benchmark")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterStrategyDetailsPage(label);
						dbValue =(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							exlObj.setCellData(sheet, rownum, 5, attributeValue);
						}else {
							exlObj.setCellData(sheet, rownum, 5, attributeValue+"-UI Value is not same as Stored Value in DB");
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							count++;
							
						}
						
							rownum++;
							label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("Primary Benchmark")))
								label = "isEmpty";
					
					}
			}
			
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In Enter Strategy Details Page Values Stored in DB are Populated in UI");
			exlObj.closeWorkBook();
    }
	
	private String getDataFromEnterStrategyDetailsPage(String data) {
		
			switch (data) {
			case "Risk Category":
				
				uiValue = strategyDetailsPage.getRiskCategoryValue();
				
				break;
			case "PIV Style":
				
				uiValue = strategyDetailsPage.getPIVStyleValue();
				
				break;
			case "Geographic Indicator":
				
				uiValue = strategyDetailsPage.getGeographicIndicatorValue();
				
				break;
			case "Strategy Name":
				
				uiValue = strategyDetailsPage.getStrategyNameValue();
				
				break;
			case "Strategy Code":
				
				uiValue = strategyDetailsPage.getStrategyCodeValue();
				
				break;
			case "Balanced Allocation":
				
				uiValue = strategyDetailsPage.getBalancedAllocationValue();
				
				break;
			case "Concentrated Strategy Indicator_radiobutton":
				
				uiValue = strategyDetailsPage.getConcentratedStrategyIndicatorValue();
				
				break;
			case "Structured Products Strategy_radiobutton":
				
				uiValue = strategyDetailsPage.getStructuredProductsStrategyValue();
				
				break;
			case "Margins":
				
				uiValue = strategyDetailsPage.getMarginsValue();
				
				break;
			case "Status":
				
				uiValue = strategyDetailsPage.getStrategyStatusValue();
				
				break;
			case "Hedge Core Indicator_radiobutton":
				
				uiValue = strategyDetailsPage.getHedgeCoreIndicatorValue();
				
				break;
			case "Style Pairing Code":
				
				uiValue = strategyDetailsPage.getStylePairingCodeValue();
				
				break;
			case "Investment Style":
				
				uiValue = strategyDetailsPage.getInvestmentStyleValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if((uiValue == null) || (uiValue.isEmpty()))
			uiValue = "isEmpty";
	
		return uiValue;
	}

	@And("^User is in Enter Strategy Details Page in Update PMP Strategy Flow$")
    public void user_is_in_enter_strategy_details_page_in_update_pmp_strategy_flow() {
        Assert.assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailsPage());
    }
	
	@And("^User clicks on Next Button in Enter Startegy Details Page of Update PMP Strategy Flow$")
    public void user_clicks_on_next_button_in_enter_startegy_details_page_of_update_pmp_strategy_flow() {
        strategyDetailsPage.clickOnNext();
    }
}
