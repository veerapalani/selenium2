
package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerContactPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerDocLinkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;

public class CreateManagerDocLinkStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	
	CreateManagerDocLinkPage doc = new CreateManagerDocLinkPage("AD_PM_CreateManagerDocLinkPage");

	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateManager.xlsx";
	String option, sheetName = "";
	int rowIndex;

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;

	@And("^User clicks on Next Button on Manager Document Link Page$")
	public void user_clicks1_on_next_button_on_manager_document_link_page() throws Throwable {
       doc.clickOnNextButton();
	}
	@Then("^the attributes on Create Manager Doc Link Page should contain all of the below following values$")
    public void the_attributes_on_create_manager_doc_link_page_should_contain_all_of_the_below_following_values(List<List<String>> entityValuePair) throws Throwable {
		for (int i = 0; i < entityValuePair.size(); i++) {
			String[] listOfValues;
			listOfString = new ArrayList<String>();
			listOfValues = entityValuePair.get(i).get(1).split(",");
			listOfElements = doc
					.findElementsByDynamicXpath("//*[@label='" + entityValuePair.get(i).get(0) + "']/wf-select-option");

			for (int j = 0; j < listOfElements.size(); j++) {
				listOfString.add(listOfElements.get(j).getAttribute("name"));

			}
			for (int j = 0; j < listOfValues.length; j++) {
				Assert.assertTrue(listOfString.contains(listOfValues[j]));
				Reporter.addStepLog("the value " + listOfValues[j] + " is present in " + entityValuePair.get(i).get(0));
			}

		}
    }
	@When("^User enters valid data in the mandatory fields in Create Manager Document Link page$")
    public void user_enters_valid_data_in_the_mandatory_fields_in_create_manager_document_link_page() throws Throwable {
		//doc.enterdocumentcode();
        doc.selectdoctypevalue();
        doc.enterdocumentlink();
        doc.entercomments();
    }
	@Then("^User should be able to see the Manager Doc Link Page$")
    public void user_should_be_able_to_see_the_manager_doc_link_page() throws Throwable {
		Boolean br=doc.isUserOnDocLinkPage();
        if(br==true) {
        	Reporter.addScreenCapture();
        	Reporter.addStepLog("User has navigated to Create Manager Doc Link page");
        }
    }
	@And("^User clicks on Previous Button on Manager Document Link Page$")
    public void user_clicks_on_previous_button_on_manager_document_link_page() throws Throwable {
		doc.clickOnPreviousButton();
    }
}
