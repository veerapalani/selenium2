package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyCommentsPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreatePMPStrategyCommentsStepDef {

	CreatePMPStrategyCommentsPage commentsPage = new CreatePMPStrategyCommentsPage("AD_PM_CreatePMPStrategyCommentsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;

	@And("^User inputs (.+) in Comments Page in PMP Flow$")
	public void user_inputs_in_comments_page_in_pmp_flow(String mandatorydetails) throws IOException {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		// String environment =
		// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment;
		if (environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails + "_dev";
		}
		if (environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails + "_qa";
		}
		if (environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails + "_uat";
		}

		String commentType,comment = "";
		String tName = Thread.currentThread().getName();
		synchronized (tName) {

			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			commentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 26);
			comment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 27);

		}

		if (commentType != "" && comment != "") {

			if (commentType.contains(",") && comment.contains(",")) {
				String[] comType = commentType.split(",");
				String[] com = comment.split(",");

				int comTypeSize = comType.length;
				int comSize = com.length;
				int size = Math.min(comTypeSize, comSize);
				int i = 0;

				while (size > 0) {
					commentsPage.selectCommentsType(comType[i]);
					commentsPage.enterCommentsComment(com[i]);
					commentsPage.clickOnAddCommentsButton();
					size--;
					i++;
					if (size > 0) {
						commentsPage.clickOnAddAnotherComment();
					}
				}

			} else {

				commentsPage.selectCommentsType(commentType);
				commentsPage.enterCommentsComment(comment);
				commentsPage.clickOnAddCommentsButton();
			}

		}
	}

	@And("^User clicks on Next in Comments Page$")
	public void user_clicks_on_next_in_comments_page() {
		commentsPage.clickOnNext();
	}

	@And("^User should be able to see Comments Page in PMP Flow$")
	public void user_should_be_able_to_see_comments_page_in_pmp_flow() {
		assertTrue(commentsPage.isUserOnCommentsPage());
	}
	
	@And("^User clicks on Previous Button in Comments Page in PMP Flow$")
    public void user_clicks_on_previous_button_in_comments_page_in_pmp_flow() {
        commentsPage.clickOnPrevious();
    }
	
	@Then("^User input fields from (.+) should be visible in Comments Page in PMP Flow$")
    public void user_input_fields_from_should_be_visible_in_comments_page_in_pmp_flow(String mandatorydetails) {
        
    	if(mandatorydetails.contains("Test"))
    		sheetName = "Test";
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String tName = Thread.currentThread().getName();
    	String commentType,comment = "";
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			commentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 26);
			comment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 27);
			
		}
		String[] comTypefromUser = commentType.split(",");
		String[] comLinkfromUser = comment.split(",");
    	
    	ArrayList<ArrayList<String>> comments = new ArrayList<ArrayList<String>>();
		
    	int commentCount = commentsPage.getcountofComments();
    	
    	for (int i = 0; i < commentCount; i++) {
    		
    		comments.add(commentsPage.getithCommentInfo(i));
			
		}
    	int j = 0;
    	for (ArrayList<String> arrayList : comments) {
			Assert.assertTrue(comments.get(j).get(0).equalsIgnoreCase(comTypefromUser[j]));
			Assert.assertTrue(comments.get(j).get(1).equalsIgnoreCase(comLinkfromUser[j]));
			j++;
		}
    }
	
}
