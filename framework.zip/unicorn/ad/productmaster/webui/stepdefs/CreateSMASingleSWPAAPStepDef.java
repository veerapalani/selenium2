package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleSWPAAPPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreateSMASingleSWPAAPStepDef {
	LandingPage lp = new LandingPage("AD_PM_LandingPage");
	CreateSMASingleSWPAAPPage createSMASingleSWPAAPPage = new CreateSMASingleSWPAAPPage(
			"AD_PM_CreateSMASingleSWPAAPPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String strategyCode;
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleSWPAAP.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expectedErrorMessages;
	List<WebElement> myElements;

	@When("^User clicks on Create New Dropdown on Landing page$")
	public void user_clicks_on_create_new_dropdown_on_landing_page() throws Throwable {
		lp.clickOncreatenewdropdownicon();
	}

	@And("^User selects Strategy from dropdown on landing page$")
	public void user_selects_strategy_from_dropdown_on_landing_page() throws Throwable {
		lp.clickOnstrategydropdownmenu();
	}

	@And("^User selects SMA Single SWP APP Radio button$")
	public void user_selects_sma_single_swp_app_radio_button() throws Throwable {
		createSMASingleSWPAAPPage.clickOnSMASingleSWPAPPRadioButton();
	}

	@And("^User should be able to see Create New Strategy Wizard page for SMA SWP$")
	public void user_should_be_able_to_see_create_new_strategy_wizard_page_for_sma_swp() throws Throwable {
		assertTrue(createSMASingleSWPAAPPage.isUserOnCreateStrategyWizardPage());
	}

	@And("^User inputs (.+) into Strategy Name for SMA SWP$")
	public void user_inputs_into_strategy_name_for_sma_swp(String data) throws Throwable {
		createSMASingleSWPAAPPage.enterStrategyName(data);
	}

	@And("^User clicks on Create Button on Wizard page$")
	public void user_clicks_on_create_button_on_wizard_page() throws Throwable {
		createSMASingleSWPAAPPage.clickOnCreateButton();
	}

	@And("^User inputs (.+) in Enter Strategy deatils page for SMA SWP$")
	public void user_inputs_in_enter_strategy_deatils_page_for_sma_swp(String mandatoryDetails) throws Throwable {
		if(mandatoryDetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatoryDetails);
		String strategyCode = (String)exlObj.getCellData(sheet, rowIndex, 1);
		String aarBaseTemplate = (String)exlObj.getCellData(sheet, rowIndex, 3).toString();
		String strategyMin = (String)exlObj.getCellData(sheet, rowIndex, 4).toString();
		exlObj.closeWorkBook();
		if(strategyCode != "") {
			createSMASingleSWPAAPPage.strategyCode(strategyCode);
		}
		if(aarBaseTemplate != "") {
			createSMASingleSWPAAPPage.enterAARBaseTemplate(aarBaseTemplate);
		}
		if(strategyMin != "") {
			createSMASingleSWPAAPPage.enterstrategyMin(strategyMin);
		}
		Reporter.addScreenCapture();
	}

	@Then("^User Clicks on Next in Enter Strategy deatils SMA SWP page$")
	public void user_clicks_on_next_in_enter_strategy_deatils_sma_swp_page() throws Throwable {
		createSMASingleSWPAAPPage.clickOnNextButton();
	}

	@Then("^User should be able to see fields on Benchmark details page$")
	public void user_should_be_able_to_see_fields_on_benchmark_details_page(List<String> entity) throws Throwable {
		for(int i = 0; i < entity.size(); i++) {
			createSMASingleSWPAAPPage.verifyElementsOnBenchmarkAndAssectClassificationPage(
					createSMASingleSWPAAPPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User Clicks on Next in Benchmark page for SMA SWP$")
	public void user_clicks_on_next_in_benchmark_page_for_sma_swp() throws Throwable {
		createSMASingleSWPAAPPage.clickOnNextButton();
	}

	@And("^User should be able to see fields on Proxy details page$")
	public void user_should_be_able_to_see_fields_on_proxy_details_page(List<String> entity) throws Throwable {
		for(int i = 0; i < entity.size(); i++) {
			createSMASingleSWPAAPPage.verifyElementsOnProxyDetailsPage(
					createSMASingleSWPAAPPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User Clicks on Next in Proxy deatils SMA SWP page$")
	public void user_clicks_on_next_in_proxy_deatils_sma_swp_page() throws Throwable {
		createSMASingleSWPAAPPage.clickOnNextButton();
	}

	@And("^User should be able to see fields on Documents details page$")
	public void user_should_be_able_to_see_fields_on_documents_details_page(List<String> entity) throws Throwable {
		for(int i = 0; i < entity.size(); i++) {
			createSMASingleSWPAAPPage.verifyElementsOnDocumentsDetailsPage(
					createSMASingleSWPAAPPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User Clicks on Next in Documents deatils SMA SWP page$")
	public void user_clicks_on_next_in_documents_deatils_sma_swp_page() throws Throwable {
		createSMASingleSWPAAPPage.clickOnNextButton();
	}

	@And("^User should be able to see fields on Comments details page$")
	public void user_should_be_able_to_see_fields_on_comments_details_page(List<String> entity) throws Throwable {
		for(int i = 0; i < entity.size(); i++) {
			createSMASingleSWPAAPPage.verifyElementsOnCommentsDetailsPage(
					createSMASingleSWPAAPPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User Clicks on Next in Comments details SMA SWP page$")
	public void user_clicks_on_next_in_comments_details_sma_swp_page() throws Throwable {
		createSMASingleSWPAAPPage.clickOnNextButton();
	}

	@And("^User should be able to see fields on Review details page$")
	public void user_should_be_able_to_see_fields_on_review_details_page(List<String> entity) throws Throwable {
		for(int i = 0; i < entity.size(); i++) {
			createSMASingleSWPAAPPage.verifyElementsOnReviewDetailsPage(
					createSMASingleSWPAAPPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User Clicks on Submit in Comments Review SMA SWP page$")
	public void user_clicks_on_submit_in_comments_review_sma_swp_page() throws Throwable {
		createSMASingleSWPAAPPage.clickOnSubmitButton();
	}

	// Get Text from SMA Single Access confirmation page
	@And("^User should able to get (.+) Strategy Code from Confirmation page$")
	public void user_should_able_to_get_strategy_code_from_confirmation_page(String mandatorydetails) throws Throwable {
		if(mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		createSMASingleSWPAAPPage.getStrategyCodeFromSMAAccessConfirmationPage();
		exlObj.setCellData(sheet, rowIndex, 1, CreateSMASingleSWPAAPPage.value);
		exlObj.closeWorkBook();
		Reporter.addScreenCapture();
	}

	@And("^User should be able to see error message for SMA SWP$")
	public void user_should_be_able_to_see_error_message_for_sma_swp() throws Throwable {
		expectedErrorMessages = (String)exlObj.getCellData(sheet, rowIndex, 2);
		assertTrue(createSMASingleSWPAAPPage.errorMessages(expectedErrorMessages));
	}

	@Then("^User should be able to see (.+) in Confirmation Page in SMA Single SWPAPP flow$")
	public void user_should_be_able_to_see_in_confirmation_page_in_sma_single_swpapp_flow(String confirmationmessage)
			throws Throwable {
		assertTrue(createSMASingleSWPAAPPage.isStrategyCreatedSuccessfully());
		assertTrue(createSMASingleSWPAAPPage.isStrategyCreatedMessageDisplayed(confirmationmessage));
	}

	@And("^(.+) provided during create SMA Single SWP APP Strategy should be stored in Data base$")
	public void provided_during_create_sma_single_swp_app_strategy_should_be_stored_in_data_base(
			String mandatorydetails) throws Throwable {
		if(mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		String[] temp = null;
		sheet = exlObj.getSheet(sheetName);
		//String environment = property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment;
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails + "_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails + "_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails + "_uat";
		}
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String excelData;
		List<String> excelDataGiven = new ArrayList<String>();
		int cellnum = 1;
		int i = 1;
		Boolean flag = false;
		String label = (String)exlObj.getCellData(sheet, 0, cellnum).toString();
		if(label == "")
			label = "isEmpty";
		while(label != "isEmpty") {
			try {
				excelData = (String)exlObj.getCellData(sheet, rowIndex, i);
			}
			catch(Exception e) {
				excelData = (String)exlObj.getCellData(sheet, rowIndex, i).toString();
			}
			if(excelData == "") {
				excelData = "isEmpty";
			}
			else if(excelData.equalsIgnoreCase("yes")) {
				excelData = "t";
			}
			else if(excelData.equalsIgnoreCase("no")) {
				excelData = "f";
			}
			else if(label.contains("onlysort")) {
				if(excelData.contains(",")) {
					String[] percentages = excelData.split(",");
					// String[] temp = null;
					ArrayList<String> percent = new ArrayList<String>();
					for(String E: percentages) {
						temp = E.split("-");
						percent.add(temp[0]);
					}
					Collections.sort(percent);
					excelData = "";
					for(String F: percent) {
						excelData = excelData + F + ":";
					}
				}
			}
			else if(label.contains("UnbundledNodeIds")) {
				if(excelData.contains(",")) {
					String[] unbundledNodeIdName = excelData.split(",");
					// String[] temp = null;
					ArrayList<String> unbundle = new ArrayList<String>();
					for(String G: unbundledNodeIdName) {
						temp = G.split("-");
						unbundle.add(temp[0]);
					}
					Collections.sort(unbundle);
					excelData = "";
					for(String H: unbundle) {
						excelData = excelData + H + ":";
					}
				}
				else {
					String[] split = excelData.split("-");
					excelData = split[0];
				}
			}
			else if(label.contains("Benchmark Name")) {
				if(excelData.contains(",")) {
					String[] benchmarkNames = excelData.split(",");
					// String[] temp = null;
					ArrayList<String> benchmark = new ArrayList<String>();
					for(String G: benchmarkNames) {
						temp = G.split(" - ");
						benchmark.add(temp[1]);
					}
					Collections.sort(benchmark);
					excelData = "";
					for(String H: benchmark) {
						excelData = excelData + H + ":";
					}
				}
				else {
					String[] split2 = excelData.split(" - ");
					excelData = split2[1];
				}
			}
			if(label.contains("ignore")) {
				cellnum++;
				i++;
				label = (String)exlObj.getCellData(sheet, 0, cellnum).toString();
				if(label == "")
					label = "isEmpty";
			}
			else {
				excelDataGiven.add(excelData);
				// System.out.println(excelData+"--"+label+ " -Data from Excel");
				cellnum++;
				i++;
				label = (String)exlObj.getCellData(sheet, 0, cellnum).toString();
				if(label == "")
					label = "isEmpty";
			}
		}
		String temporaryLabel;
		cellnum = 1;
		pmdb.DBConnectionStart();
		List<String> dbData = new ArrayList<String>();
		String dbDataIterator;
		sheet = exlObj.getSheet("SQLquery");
		ResultSet rs;
		label = (String)exlObj.getCellData(sheet, cellnum, 0).toString();
		if(label == "")
			label = "isEmpty";
		// Voluntary Reorg address-Same as Proxy and Interim Address - Same as Proxy
		// both are UI derived not from backend
		// Ignoring both above - not geting any scripts for same
		while(label != "isEmpty") {
			if(label.contains("ignore")) {
				cellnum++;
				label = (String)exlObj.getCellData(sheet, cellnum, 0);
				if(label == "")
					label = "isEmpty";
			}
			else {
				temporaryLabel = null;
				dbDataIterator = null;
				ArrayList<String> tempData = new ArrayList<String>();
				String SQLquery = (String)exlObj.getCellData(sheet, cellnum, 1);
				SQLquery = SQLquery.replace("@data", "'" + strategyCode + "'");
				rs = DBManager.executeSelectQuery(SQLquery);
				String labelname = (String)exlObj.getCellData(sheet, cellnum, 2);
				int count = 1;
				while(rs.next()) {
					dbDataIterator = rs.getString(labelname);
					if(rs.wasNull() || dbDataIterator.isEmpty()) {
						dbDataIterator = "isEmpty";
					}
					tempData.add(dbDataIterator);
				}
				if(tempData.size() > 1) {
					Collections.sort(tempData);
					dbDataIterator = "";
					for(String G: tempData) {
						dbDataIterator = dbDataIterator + G + ":";
					}
					tempData.clear();
				}
				dbData.add(dbDataIterator);
				cellnum++;
				label = (String)exlObj.getCellData(sheet, cellnum, 0);
				if(label == "")
					label = "isEmpty";
			}
		}
		cellnum = 1;
		label = (String)exlObj.getCellData(sheet, cellnum, 0).toString();
		if(label == "")
			label = "isEmpty";
		while(label != "isEmpty") {
			if(label.contains("ignore")) {
				cellnum++;
				label = (String)exlObj.getCellData(sheet, cellnum, 0);
				if(label == "")
					label = "isEmpty";
			}
			else {
				try {
					// System.out.println(dbData.get(cellnum - 1));
					// System.out.println(excelDataGiven.get(cellnum - 1));
					assertTrue(dbData.get(cellnum - 1).contains(excelDataGiven.get(cellnum - 1)));
				}
				catch(Exception e) {
					// Data Base value is not same as value provided
					Reporter.addStepLog("Data Base value is not same as value provided");
				}
				cellnum++;
				label = (String)exlObj.getCellData(sheet, cellnum, 0).toString();
				if(label == "")
					label = "isEmpty";
			}
		}
		exlObj.closeWorkBook();
		pmdb.DBConnectionClose();
	}

	@And("^User should be able to view DVP/Key Trust template field on Benchmark and Asset Classification page while Updating SMA Single SWP/AAP Strategy$")
	public void user_should_be_able_to_view_dvp_trust_template_field_0n_benchmark_and_asset_classificatin_page_while_updateing_SMA_single_swp_aap_startegy() {
		assertTrue(createSMASingleSWPAAPPage.isDvpKeyTrustTemplateVisible());
	}
}
