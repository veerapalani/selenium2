package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerContactPage;
//import qa.unicorn.ad.productmaster.webui.pages.CreateManagerPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
public class CreateManagerContactPageStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString ;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateManagerContactPage"));
	Alert alert;
	public static String styleName1, styleCode1 = null;
	
	//CreateManagerPage createmanagerpage = new CreateManagerPage("AD_PM_CreateManagerPage");
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	CreateManagerContactPage cr=new CreateManagerContactPage("AD_PM_CreateManagerContactPage");
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateManager.xlsx";
	String option, sheetName = "";
	int rowIndex;

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;

	public static String benchmarkName1, benchmarkCode1 = null;
	
	@Then("^User should be able to see the Manager Contact Page$")
    public void user_should_be_able1_to_see1_manager_contact_page() throws Throwable {
        Boolean br=cr.isUserOnContactPage();
        if(br==true) {
        	Reporter.addScreenCapture();
        	Reporter.addStepLog("User has navigated to Create Manager Contact page");
        }
    }
	
	@Then("^User should be able to go to Manager Contact page$")
    public void user_should_be_able_to_go_to_manager_contact_page() throws Throwable {
        Assert.assertTrue(action.getCurrentURL().toLowerCase().contains("contact"));
        Reporter.addStepLog("The current URL is "+action.getCurrentURL()+"/n We are in Create Contact page");
        Reporter.addScreenCapture();
        
    }
	@Then("^User should be able to see the text \"([^\"]*)\" below horizontal line on Enter contact page$")
    public void user_should_be_able_to_see_the_text_something_below_horizontal_line_on_enter_contact_page(String strArg1) throws Throwable {
        cr.verifyTextEntercontactDetailsoncontactpage();
    }
	@When("^User clicks on the Back Link on Manager Add Contact Page$")
    public void user_clicks_on_the_back_link_on_manager_add_contact_page() throws Throwable {
        cr.clickOnBackLink();
    }

	/*
	 * @When("^User enters the valid data in all of the manadatory fields in Create Manager Contact page$"
	 * ) public void
	 * user_enters1_the_valid_data1_in_all1_of_the_manadatory_fields_in_create_manager_contact_page
	 * () throws Throwable { cr.selectmanagercontacttypevalue();
	 * //cr.entercontactcodeuniqueName(); cr.entermanagercontactdescription();
	 * cr.selectstatetypevalue(); cr.entermanagerfirstname();
	 * cr.entermanagermiddlename(); cr.entermanagerlastname(); cr.address();
	 * cr.city(); cr.selectstatetypevalue(); cr.postalcode();
	 * cr.selectcountrytypevalue(); cr.emailaddress(); cr.phoneno();
	 * //cr.clickOnAddContactButton(); //cr.clickOnNextButton();
	 * 
	 * }
	 */
	/*
	 * @When("^User enters the (.+) in all of the manadatory fields in Contact page$"
	 * ) public void
	 * user_enters_the_in_all_of_the_manadatory_fields_in_contact_page(String
	 * option) throws Throwable { if (option.contains("validdata")) { sheetName =
	 * "Contact"; }
	 * 
	 * sheet = exlObj.getSheet(sheetName);
	 * 
	 * rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
	 * 
	 * String contacttype = (String) exlObj.getCellData(sheet, rowIndex, 1); String
	 * contactcode = (String) exlObj.getCellData(sheet, rowIndex, 2); String
	 * contactdescrp= (String) exlObj.getCellData(sheet, rowIndex, 3);
	 * 
	 * exlObj.closeWorkBook();
	 * 
	 * 
	 * if (contacttype != "") { cr.selectcontacttypevalue(contacttype); }
	 * 
	 * if (contactcode != "") { cr.entercontactcodeName(contactcode); } if
	 * (contactdescrp != "") { cr.entercontactdescription(contactdescrp); }
	 * Reporter.addScreenCapture();
	 * 
	 * cr.entermanagerfirstname(); cr.entermanagermiddlename();
	 * cr.entermanagerlastname(); cr.address(); cr.city();
	 * cr.selectstatetypevalue(); cr.postalcode(); cr.selectcountrytypevalue();
	 * cr.emailaddress(); cr.phoneno();
	 * 
	 * }
	 */
	
	@And("^User clicks on Add Contact Button on Manager Contact Page$")
    public void user_clicks_on_add_contact_button_on_manager_contact_page() throws Throwable {
        cr.clickOnAddContactButton();
    }

    @And("^User clicks on Next Button on Manager Contact Page$")
    public void user_clicks_on_next_button_on_manager_contact_page() throws Throwable {
        cr.clickOnNextButton();
    }
    @And("^User clicks on Add Another Contact Button on Manager Contact Page$")
    public void user_clicks_on_add_another_contact_button_on_manager_contact_page() throws Throwable {
    	myElement = (WebElement)action.getElementByJavascript("Add Another Contact");
    	if(myElement!=null) {
    	action.click(myElement);
        Reporter.addStepLog("clicking on Add Another Contact Button");
    	}
    }
    @Then("^user should be able to see the following values in the following dropdown in Manager Contact page$")
    public void user_should_be_able_to_see_the_following_values_in_the_following_dropdown_in_manager_contact_page(List<List<String>> attributeValuePair) throws Throwable {
    	for (int i = 0; i < attributeValuePair.size(); i++) {
			listOfElements = cr.findElementsByDynamicXpath(
					"//wf-select[@label='" + attributeValuePair.get(i).get(0) + "']/wf-select-option");
			String[] options = attributeValuePair.get(i).get(1).split(",");
			for (int j = 0; j < options.length; j++) {
				Assert.assertEquals(listOfElements.get(j).getAttribute("name"), options[j]);
				Reporter.addStepLog(
						"verified that " + options[j] + " is present in " + attributeValuePair.get(i).get(0));
			}
		}
    }
    
    @Then("^User should not be able to see any error message while updating the following attributes with following values in Manager Contact page$")
    public void user_should_not_be_able_to_see_any_error_message_while_updating_the_following_attributes_with_following_values_in_manager_contact_page(List<List<String>> attributeValuePair) throws Throwable {
    	 Thread.sleep(2000);
			for (int i = 0; i < attributeValuePair.size(); i++) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
						+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
				action.clear(myElement);
				action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
				myElement.sendKeys(Keys.ENTER);
				String message = Action.getTestData("Invalid_Special_Character_Message");
				Assert.assertFalse(action.getPageSource().contains(message));
				Reporter.addStepLog("verified that there is no error message for " + attributeValuePair.get(i).get(0));
			}
    }
    
    @Then("^User should be able to see the Invalid Special Character Message while updating with the following values in following attributes in Manager Contact page$")
    public void user_should_be_able_to_see_the_invalid_special_character_message_while_updating_with_the_following_values_in_following_attributes_in_manager_contact_page(List<List<String>> attributeValuePair) throws Throwable {
    	Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Invalid_Special_Character_Message");
			Assert.assertFalse(action.getPageSource().contains(message));
			Reporter.addStepLog("verified that there is no error message for " + attributeValuePair.get(i).get(0));
		}
    }
    
    @Then("^User should be able to see the Add Contacts header in Manager Contact page$")
    public void user_should_be_able_to_see_the_add_contacts_header_in_manager_contact_page() throws Throwable {
        action.getElement("Add Contact").isDisplayed();
        action.highligthElement(action.getElement("Add Contact"));
        Reporter.addStepLog("verified that Add contacts header is present");
    }
    
    @Then("^The following attributes on Manager Contact page should be marked as mandatory$")
    public void the_following_attributes_on_manager_contact_page_should_be_marked_as_mandatory(List<String>items) throws Throwable {
    	for (int i = 0; i < items.size(); i++) {
			myElement =cr.findElementByDynamicXpath("//*[@label='" + items.get(i) + "']");
			Assert.assertEquals(action.getAttribute(myElement, "required"), "true");
			Reporter.addStepLog("validated that " + items.get(i) + " is mandatory");
		}
		Reporter.addScreenCapture();
    }
    
    @When("^User enters the (.+) in Create Manager Contact page$")
    public void user_enters_the_in_all_of_the_fields(String option) throws Throwable {
    	if (option.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
		String type = (String) exlObj.getCellData(sheet, rowIndex, 14);
		String description = (String) exlObj.getCellData(sheet, rowIndex, 15);
		String firstName = (String) exlObj.getCellData(sheet, rowIndex, 16);
		String middleName = (String) exlObj.getCellData(sheet, rowIndex, 17);
		String lastName= (String) exlObj.getCellData(sheet, rowIndex, 18);
		String address= (String) exlObj.getCellData(sheet, rowIndex, 19);
		String city= (String) exlObj.getCellData(sheet, rowIndex, 20);
		String state= (String) exlObj.getCellData(sheet, rowIndex, 21);
		String postalCode= (String) exlObj.getCellData(sheet, rowIndex,22);
		String country= (String) exlObj.getCellData(sheet, rowIndex, 23);
		String emailAddress= (String) exlObj.getCellData(sheet, rowIndex, 24);
		String phoneNumber= (String) exlObj.getCellData(sheet, rowIndex, 25);
		exlObj.closeWorkBook();

		if (type != "") {
			cr.selectcontacttypevalue(type);
		}
		if(description!="") {
			cr.entermanagercontactdescription(description);
		}
		if(firstName!="") {
			cr.entermanagerfirstname(firstName);
		}
		if(middleName!="") {
			cr.entermanagermiddlename(middleName);
		}
		if(lastName!="") {
			cr.entermanagerlastname(lastName);
		}
		if(address!="") {
			cr.enterAddress(address);
		}
		if(city!="") {
			cr.enterCity(city);
		}
		if(state!="") {
			cr.selectstatetypevalue();
		}
		
		  if(postalCode!="") { cr.postalcode(postalCode); }
		 
		if(country!="") {
			cr.selectcountrytypevalue();
		}
		if(emailAddress!="") {
			cr.emailaddress(emailAddress);
		}
		if(phoneNumber!="") {
			cr.phoneno(phoneNumber);
		}
		Reporter.addScreenCapture();
    }
}
