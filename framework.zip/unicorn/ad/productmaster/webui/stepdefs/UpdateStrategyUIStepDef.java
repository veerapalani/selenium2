package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.util.ObjectUtils;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.SaveAsDraftAllUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASWPAAPPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;

public class UpdateStrategyUIStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	String expectedColorCode;
	String xpath, myValue;
	Select dropdown;
	Boolean myFlag;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/smaAccess/view/2053002";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	String excelFilePath1 = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategyvestmark_1.xlsx";
	String excelFilePath2 = "./src/test/resources/ad/productmaster/webui/excel/UpdateSMASWPStrategy.xlsx";

	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	ExcelUtils exlObj1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath1);
	ExcelUtils exlObj2 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath2);
	List<WebElement> myElements;
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	UpdateStrategyPage UpdateStrategyUI = new UpdateStrategyPage();
	WebElement myElement, myElement1, myElement2;
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategyUIPage"));
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	UpdateSMASingleAccessUIPage updateSMASinglePage = new UpdateSMASingleAccessUIPage();
	UpdateSMASWPAAPPage updateSMASWPAAPPage = new UpdateSMASWPAAPPage("AD_PM_UpdateSMASWPAAPPage");
	UpdateStrategyPage pg = new UpdateStrategyPage();

	SaveAsDraftAllUIPage SAD = new SaveAsDraftAllUIPage();
	String strategyCode = null;
	String uiElementView, uiElementViewProxySection, uiElementViewBencharkAssetClassification,
			uiElementViewInterimAddressSection, uiElementViewVoluntaryReorgAddressSection, uiElementDetailsPageInput,
			uiElementDetailsPageDropdown, uIcheckBoxButton, uiElementBenchmarkPageDropdown,
			uiElementBenchmarkPercentage, uiElementProxyPageInput, uiElementProxyPageDropDown,
			uiElementInterimPageInput, uiElementInterimPageDropDown, uiElementVoluntaryReorgPageInput,
			uiElementVoluntaryReorgPageDropDown, uiElementReview;
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	Collection<Object> dbValues;
	List<String> uIElements = new ArrayList<String>();
	HashMap<String, Object> row = new HashMap<String, Object>();

	@Then("^user should be able to go Update Strategy UI screen$")
	public void user_should_be_able_to_go_update_strategy_ui_screen() throws Throwable {
		Assert.assertTrue(action.getCurrentURL().contains(pageURL), "We are in UpdateStrategyUIPage");
		Reporter.addScreenCapture();
	}

	@Then("^user should be able to see the following Column Headers in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_following_something_in_the_update_strategy_ui(List<String> items)
			throws Throwable {
		listOfElements = action.getElements("Column Headers");
		// storing all the labels in the list
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < listOfElements.size(); i++) {
			list.add(listOfElements.get(i).getAttribute("label"));
		}

		for (int i = 0; i < items.size(); i++) {
			Assert.assertTrue(list.contains(items.get(i)));

			Reporter.addStepLog("The header " + items.get(i) + " is present");
		}
		Reporter.addScreenCapture();
	}

	@Then("^user should be able to see certain (.+) in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_following_dropdown_headers_in_the_update_strategy_ui(
			String expected_value) throws Throwable {
		// listOfElements = action.getElements("Dropdown_Headers");
		boolean actual_value = pg.is_identifier_for_dropdown_being_displayed("Dropdown_Headers", expected_value);
		Assert.assertTrue(actual_value,
				"user should be able to see certain 'Strategy Status' in the Update Strategy UI");

		/*
		 * // storing all the labels in the list List<String> list = new
		 * ArrayList<String>(); for (int i = 0; i < listOfElements.size(); i++) {
		 * list.add(listOfElements.get(i).getAttribute("label")); }
		 * 
		 * for (int i = 0; i < items.size(); i++) {
		 * Assert.assertTrue(list.contains(items.get(i)));
		 * 
		 * Reporter.addStepLog("The header " + items.get(i) + " is present"); }
		 */
		Reporter.addScreenCapture();
	}

	@Then("^user should be able to see the following Radio Button Headers in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_following_radio_button_headers_in_the_update_strategy_ui(
			List<String> items) throws Throwable {
		listOfElements = action.getElements("Radio Button Headers");
		// storing all the labels in the list
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < listOfElements.size(); i++) {
			list.add(listOfElements.get(i).getAttribute("label"));
		}

		for (int i = 0; i < items.size(); i++) {
			Assert.assertTrue(list.contains(items.get(i)));

			Reporter.addStepLog("The header " + items.get(i) + " is present");
		}
		Reporter.addScreenCapture();
	}

	@Then("^user should be able to see the following Date Format Headers in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_following_date_format_headers_in_the_update_strategy_ui(
			List<String> items) throws Throwable {
		listOfElements = action.getElements("Date Format Headers");
		// storing all the labels in the list
		List<String> list = new ArrayList<String>();
		for (int i = 0; i < listOfElements.size(); i++) {
			list.add(listOfElements.get(i).getAttribute("label"));
		}

		for (int i = 0; i < items.size(); i++) {
			Assert.assertTrue(list.contains(items.get(i)));

			Reporter.addStepLog("The header " + items.get(i) + " is present");
		}
		Reporter.addScreenCapture();
	}

	@Then("^User should not have the option to update the following attributes in the Update Strategy UI$")
	public void user_should_not_have_the_option_to_update_the_following_attributes_in_the_update_strategy_ui(
			List<String> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			myValue = UpdateStrategyUI.findElementByDynamicXpath("//*[@label='" + items.get(i) + "']")
					.getAttribute("disabled");
			Assert.assertEquals(myValue, "true");
			Reporter.addStepLog(items.get(i) + " is disabled");

		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the message containing invalid special character message below \"([^\"]*)\" on Update Strategy$")
	public void user_should_be_able_the_message_containing_invalidspecialcharactermessage_below_something_on_update_strategy(
			String attribute) throws Throwable {
		String message = Action.getTestData("Invalid_Special_Character_Message");
		myElement = UpdateStrategyUI.findElementByDynamicXpath("//*[@label='" + attribute + "']/following-sibling::p");
		Assert.assertTrue(myElement.getText().contains(message));
		Reporter.addStepLog("verified the msg " + myElement.getText());
	}

	@And("^User enters the \"([^\"]*)\" in the \"([^\"]*)\" on Update Strategy$")
	public void user_enters_the_something_in_the_something_on_update_strategy(String invalidspecialcharacters,
			String attribute) throws Throwable {
		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='" + attribute
				+ "']\").shadowRoot.querySelector('input')");
		action.clear(myElement);
		action.sendkeysClipboard(myElement, invalidspecialcharacters);
		myElement.sendKeys(Keys.ENTER);
		Reporter.addStepLog("sent " + invalidspecialcharacters + " to " + attribute);
	}

	@Then("^User should not be able to see any error message  below \"([^\"]*)\" on Update Strategy$")
	public void user_should_not_be_able_to_see_any_error_message_below_something_on_update_strategy(String attribute)
			throws Throwable {

		String message = Action.getTestData("Invalid_Special_Character_Message");
		Assert.assertFalse(action.getPageSource().contains(message));
		Reporter.addStepLog("verified that there is no error message for " + attribute);
	}

	@Then("^User should be able to see the message containing less than minimum charater message below \"([^\"]*)\" on Update Strategy$")
	public void user_should_be_able_the_message_containing_less_than_minimum_charater_message_below_something_on_update_strategy(
			String attribute) throws Throwable {
		String message = Action.getTestData("Less_Than_Minimum_Message");
		myElement = UpdateStrategyUI.findElementByDynamicXpath("//*[@label='" + attribute + "']/following-sibling::p");
		Assert.assertTrue(myElement.getText().contains(message));
		Reporter.addStepLog("verified the msg " + myElement.getText());
	}

	@Then("^The following attributes should have the following maxlength on Update Strategy$")
	public void the_following_attributes_should_have_the_following_maxlength_on_update_strategy(
			List<List<String>> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			myElement = UpdateStrategyUI.findElementByDynamicXpath("//*[@label='" + items.get(i).get(0) + "']");
			Assert.assertEquals(action.getAttribute(myElement, "maxlength"), items.get(i).get(1));
		}
	}

	@Then("^The following attributes should be marked as mandatory on Update Strategy$")
	public void the_following_attributes_should_be_marked_as_mandatory_on_update_strategy(List<String> items)
			throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			myElement = UpdateStrategyUI.findElementByDynamicXpath("//*[@label='" + items.get(i) + "']");
			Assert.assertEquals(action.getAttribute(myElement, "required"), "true");
			Reporter.addStepLog("validated that " + items.get(i) + " is mandatory");
		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Enter Strategy Details header on Update Strategy page$")
	public void user_should_be_able_to_see_the_enter_strategy_details_header_on_update_strategy_page()
			throws Throwable {
		action.getElement("Enter Strategy Details").isDisplayed();
	}

	@Then("^User should be able to see and select the following attributes with the respective options in the Update Strategy UI$")
	public void user_should_be_able_to_see_and_select_the_following_attributes_with_the_respective_options_in_the_update_strategy_ui(
			List<List<String>> attributeValuePair) throws Throwable {
		for (int i = 0; i < attributeValuePair.size(); i++) {
			listOfElements = UpdateStrategyUI.findElementsByDynamicXpath(
					"//wf-select[@label='" + attributeValuePair.get(i).get(0) + "']/wf-select-option");
			String[] options = attributeValuePair.get(i).get(1).split(",");
			for (int j = 0; j < options.length; j++) {
				Assert.assertEquals(listOfElements.get(j).getAttribute("name"), options[j]);
				Reporter.addStepLog(
						"verified that " + options[j] + " is present in " + attributeValuePair.get(i).get(0));
			}
		}
	}

	@Then("^User should be able to see and select the following attributes with Yes or No radio button in the Update Strategy UI$")
	public void user_should_be_able_to_see_and_select_the_following_attributes_with_yesno_radio_button_in_the_update_strategy_ui(
			List<String> attribute) throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			listOfElements = UpdateStrategyUI
					.findElementsByDynamicXpath("//wf-radio[@label='" + attribute.get(i) + "']/wf-radio-option");
			Assert.assertEquals(listOfElements.get(0).getAttribute("label"), "Yes");
			Reporter.addStepLog("Yes is present in " + attribute.get(i));
			Assert.assertEquals(listOfElements.get(1).getAttribute("label"), "No");
			Reporter.addStepLog("No is present in " + attribute.get(i));
		}
		Reporter.addScreenCapture();

	}

	@And("^User should be able to see and click Calender Icon and select any date in the following attributes in the Update Strategy UI$")
	public void user_should_be_able_to_see_and_click_calender_icon_and_select_any_date_in_the_following_attributes_in_the_update_strategy_ui(
			List<String> attribute) throws Throwable {
		Thread.sleep(4000);
		for (int i = 0; i < attribute.size(); i++) {
			Reporter.addStepLog("document.querySelector(\"wf-calendar-picker[label='" + attribute.get(i)
					+ "']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\"wf-calendar-picker[label='" + attribute.get(i)
							+ "']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.click(myElement);
			// action.click(myElement);
			Reporter.addStepLog("return document.querySelector(\"wf-calendar-picker[label='" + attribute.get(i)
					+ "']\").shadowRoot.querySelector('div.calendar-wrapper')");
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\"wf-calendar-picker[label='" + attribute.get(i)
							+ "']\").shadowRoot.querySelector('div.calendar-wrapper')");
			Assert.assertTrue(myElement.isDisplayed());
			Reporter.addStepLog("The calender for " + attribute.get(i) + " is getting displayed");
		}

	}

	@Then("^User should not see any error while updating the following numeric values with following values in Update Strategy UI$")
	public void user_should_not_see_any_error_while_updating_the_following_numeric_values_with_following_values_in_update_strategy_ui(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(4000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			// verifying that no error message is there
			String message = Action.getTestData("Invalid_Numeric_Message");
			Assert.assertFalse(action.getPageSource().contains(message));
			Reporter.addStepLog("validated that no error message is there in " + attributeValuePair.get(i).get(0));

		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Invalid format error while updating the following numeric values with following values in Update Strategy UI$")
	public void user_should_be_able_to_see_the_invalid_format_error_while_updating_the_following_numeric_values_with_following_values_in_update_strategy_ui(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(4000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));

			String message = Action.getTestData("Invalid_Numeric_Message");
			myElement2 = null;
			myElement2 = UpdateStrategyUI.findElementByDynamicXpath(
					"//*[@label='" + attributeValuePair.get(i).get(0) + "']//following-sibling::p");
			Assert.assertTrue(myElement2.getText().contains(message));
			Reporter.addStepLog("validated that the error message is " + myElement2.getText() + " below "
					+ attributeValuePair.get(i).get(0));

		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Strategy header in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_strategy_header_in_the_update_strategy_ui() throws Throwable {
		Assert.assertTrue(action.getElement("Strategy").isDisplayed());
		Reporter.addStepLog("validated that the strategy header is present");
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Strategy Name Header on Update Strategy UI$")
	public void user_should_be_able_to_see_the_strategy_name_header_on_update_strategy_ui() throws Throwable {
		Assert.assertTrue(action.getElement("Strategy Name Header").isDisplayed());
		Reporter.addStepLog("validated that the strategy name header is present");
		Reporter.addScreenCapture();
	}

	@And("^The text written in Strategy Name Header should match with the value of Strategy Name attribute in the Update Strategy UI$")
	public void the_text_written_in_strategy_name_header_should_match_with_the_value_of_strategy_name_attribute_in_the_update_strategy_ui()
			throws Throwable {
		Assert.assertEquals(action.getElement("Strategy Name").getAttribute("value"),
				action.getElement("Strategy Name Header").getText());
		Reporter.addStepLog("validated that the strategy name header value matches with the strategy name");
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Minimal Amounts header in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_minimal_amounts_header_in_the_update_strategy_ui() throws Throwable {
		myElement = action.getElement("Minimal Amounts");
		action.scrollToElement(myElement);
		Assert.assertTrue(myElement.isDisplayed());
		Reporter.addStepLog("validated that the Minimal Amounts  header is present");
		Reporter.addScreenCapture();
	}

	@And("^user should be able to see the following attributes below Minimal Amounts header in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_following_attributes_below_minimal_amounts_header_in_the_update_strategy_ui(
			List<String> attribute) throws Throwable {
		Thread.sleep(3000);
		listOfElements = action.getElements("Minimal-Amounts");
		for (int i = 0; i < attribute.size(); i++) {
			Assert.assertEquals(listOfElements.get(i).getAttribute("label"), attribute.get(i));
			Reporter.addStepLog("verified that " + attribute.get(i) + " is present below Minimal Amounts header");
		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Fee Structure header in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_fee_structure_header_in_the_update_strategy_ui() throws Throwable {
		myElement = action.getElement("Fee Structure");
		action.scrollToBottom();
		Assert.assertTrue(myElement.isDisplayed());
		Reporter.addStepLog("validated that the Fee Structure header is present");
		Reporter.addScreenCapture();
	}

	@And("^user should be able to see the following attributes below Fee Structure header in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_following_attributes_below_fee_structure_header_in_the_update_strategy_ui(
			List<String> attribute) throws Throwable {
		Thread.sleep(3000);
		listOfElements = action.getElements("Fee-Structure");
		for (int i = 0; i < attribute.size(); i++) {
			Assert.assertEquals(listOfElements.get(i).getAttribute("label"), attribute.get(i));
			Reporter.addStepLog("verified that " + attribute.get(i) + " is present below Fee Structure header");
		}
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Time Stamp below the Strategy name header in the Update Strategy UI$")
	public void user_should_be_able_to_see_the_time_stamp_below_the_strategy_name_header_in_the_update_strategy_ui()
			throws Throwable {
		Assert.assertTrue(action.getElement("Time Stamp below Strategy Name").isDisplayed());
		Reporter.addStepLog("validated that the Time Stamp below Strategy Name is present");
		Reporter.addScreenCapture();
	}

	@Then("^User update the following textfields with (.+) in the Update Strategy page$")
	public void user_update_the_following_textfields_with_in_the_update_strategy_page(String option,
			List<String> attribute) throws Throwable {
		if (option.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(3000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			if (attribute.get(i).equals("Description"))
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector('textarea')");
			else
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector('input')");
			myElement.clear();
			if (attribute.get(i).equals("Code"))
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex)
						+ UpdateStrategyUI.getCurrentTimeStamp();

			else
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i));

		}
	}

	@And("^User update the following dopdown with (.+) in the Update Strategy page$")
	public void user_update_the_following_dopdown_with_in_the_update_strategy_page(String option,
			List<String> attribute) throws Throwable {
		if (option.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector('button')");
			action.scrollToElement(myElement);
			action.click(myElement);
			myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector(\"li[data-value='\\\""
					+ (String) exlObj.getCellData(sheet, rowIndex, cellIndex) + "\\\"']\")");
			action.click(myElement2);
		}
	}

	@And("^User update the following radio button with (.+) in the Update Strategy page$")
	public void user_update_the_following_radio_button_with_in_the_update_strategy_page(String option,
			List<String> attribute) throws Throwable {
		if (option.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			if (myValue.equalsIgnoreCase("yes")) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-radio[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector(\"button[data-index='0']\")");
				action.click(myElement);
			} else {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-radio[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector(\"button[data-index='0']\")");
				action.click(myElement);
			}
		}
	}

	@And("^User update the following date pickers with (.+) in the Update Strategy page$")
	public void user_update_the_following_date_pickers_with_in_the_update_strategy_page(String validata,
			List<String> attribute) throws Throwable {

	}

	@And("^User clicks on the Previous Button on Update Strategy page$")
	public void user_clicks_on_the_previous_button_on_update_strategy_page() throws Throwable {
		action.click(action.getElement("Previous Button"));
		Reporter.addStepLog("clicked on the previous button");
	}

	@Then("^User should be able to see the Required text in red color on Update Strategy UI$")
	public void user_should_be_able_to_see_the_required_text_in_red_color_on_update_strategy_ui() throws Throwable {
		Assert.assertTrue(action.getElement("* Required").isDisplayed());
		Reporter.addStepLog("validated that the * Required is present");
		Reporter.addScreenCapture();
	}

	@And("^User clicks on the Next Button on Update Strategy page$")
	public void user_clicks_on_the_next_button_on_update_strategy_page() throws Throwable {
		action.click(action.getElement("Next Button"));
		Reporter.addStepLog("clicked on the next button");
	}

	@And("^User update the following dropdown with (.+) in the Update Strategy page$")
	public void user_update_the_following_dopdown_with_in_the_update_strategy_page(String strategystatus)
			throws Throwable {

		// @SuppressWarnings("deprecation")
		WebElement dropdown1 = (WebElement) action.getElementByJavascript("Strategy_status_change");
		action.highligthElement(dropdown1);
		action.jsClick(dropdown1);
		action.getElementFromParentElement(dropdown1, strategystatus);

	}

	@When("^User search with the \"([^\"]*)\" taken from \"([^\"]*)\" in the Search TextBox on landing page while UpdateStrategyUI updation$")
	public void user_search_with_the_something_taken_from_something_in_the_search_textbox_on_landing_page_while_updatestrategyui_updation(
			String strArg1, String strArg2) throws Throwable {
		sheetName = strArg2;
		sheet = exlObj.getSheet(sheetName);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, strArg1);
		myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);

		boolean compareBoolean = action.isPresent("js",
				"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
		if (compareBoolean) {
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}

		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		myElement.click();

		action.sendkeysClipboard(myElement, myValue);

		Thread.sleep(2000);

		int i = 0;
		while (i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}

		Thread.sleep(2000);
	}

	@And("^User clicks on the first element of UpdateStrategy Searches on the suggestion box on landing page while UpdateStrategyUI updation$")
	public void user_clicks_on_the_first_element_of_updatestrategy_searches_on_the_suggestion_box_on_landing_page_while_updatestrategyui_updation()
			throws Throwable {
		Thread.sleep(5000);
		myElement = pg.findElementByDynamicXpath("(//p[@class='body-3 text-tertiary'])[1]");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(5000);
		myElement.click();
		Reporter.addStepLog("clicked on first suggestion ");
	}

	@And("^User clicks on the CONTINUE EDITING Button on UpdateStrategyUI Details page$")
	public void user_clicks_on_the_continue_editing_button_on_updatestrategyui_details_page() throws Throwable {
		myElement = pg.findElementByDynamicXpath("//brml-button[contains(text(),'CONTINUE EDITING')]");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("Clicked on Continue Editing Button");
		Thread.sleep(3000);
	}

	@And("^Edit all the below input fields with valid data for UpdateStrategyUI$")
	public void edit_all_the_below_input_fields_with_valid_data_for_updatestrategyui(List<List<String>> attribute)
			throws Throwable {
		sheetName = "Valid";
		sheet = exlObj1.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^Edit all the below text fields with valid data for UpdateStrategyUI$")
	public void edit_all_the_below_text_fields_with_valid_data_for_updatestrategyui(List<List<String>> attribute)
			throws Throwable {
		sheetName = "Valid";
		sheet = exlObj1.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-textarea[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('textarea')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^User clicks on the Next Button on UpdateStrategyUI page$")
	public void user_clicks_on_the_next_button_on_updatestrategyui_page() throws Throwable {

		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Reporter.addStepLog("Clicked on Next button");
		Thread.sleep(2000);
	}

	@And("^User takes a screen shot on UpdateStrategyUI page$")
	public void user_takes_a_screen_shot_on_updatestrategyui_page() throws Throwable {
		action.waitForPageLoad();
		action.TakeScreenshot();
		Thread.sleep(3000);
	}

	@And("^User checks on the given check box in the Strategy details page$")
	public void user_checks_on_the_given_check_box_in_the_strategy_details_page() throws Throwable {
		myElement = (WebElement) action
				.executeJavaScript("document.querySelector(\"brml-checkbox[id='collateralEligible']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Reporter.addStepLog("Clicked on button");
		Thread.sleep(2000);

	}

	@And("^User decides to edit the the drop down list for the (.+) in the update SWP Strategy flow$")
	public void user_decides_to_edit_the_the_drop_down_list_for_the_in_the_update_swp_strategy_flow(
			String strategystatus, List<String> attribute) throws Throwable {
		if (strategystatus.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, strategystatus);
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector('button')");
			action.scrollToElement(myElement);
			action.click(myElement);
			myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector(\"li[data-value='\\\""
					+ (String) exlObj.getCellData(sheet, rowIndex, cellIndex) + "\\\"']\")");
			action.click(myElement2);
		}
	}

	@Then("^User update the following dropdown with Valid Data in the Update StrategySWP page$")
	public void user_update_the_following_dropdown_with_valid_data_in_the_update_strategyswp_page(
			List<List<String>> attribute) throws Throwable {
		sheetName = "Valid";
		sheet = exlObj1.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			System.out.println(myValue + "");

			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.click(myElement);
			Thread.sleep(3000);
			System.out.println(myValue + "ghjgjhjjj");
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.click(myElement);
			Thread.sleep(3000);
		}
	}

	@And("^The update flow is complete when the user clicks on the submit button$")
	public void the_update_flow_is_complete_when_the_user_clicks_on_the_submit_button() throws Throwable {
		Thread.sleep(5000);
		myElement = pg.findElementByDynamicXpath("//brml-button[@type='submit']");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(5000);
		myElement.click();
		Reporter.addStepLog("clicked on first suggestion ");

	}

	@And("^user changes the value from the dropdown with respect to Comparative benchmark$")
	public void user_changes_the_value_from_the_dropdown_with_respect_to_comparative_benchmark(
			List<List<String>> attribute) throws Throwable {

		sheetName = "Valid";
		sheet = exlObj1.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);

			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.click(myElement);
			Thread.sleep(3000);

			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.click(myElement);
			Thread.sleep(3000);
		}

	}

	@And("^user switches the Investment style from the dropdown list$")
	public void user_switches_the_investment_style_from_the_dropdown_list(List<List<String>> attribute)
			throws Throwable {

		sheetName = "Valid";
		sheet = exlObj1.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);

			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.click(myElement);
			Thread.sleep(3000);

			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.click(myElement);
			Thread.sleep(3000);

		}
	}

	@And("^user clicks on \"([^\"]*)\" on landing page for SMA SWP$")
	public void user_clicks_on_something_on_landing_page_for_sma_swp(String strArg1) throws Throwable {
		updateSMASWPAAPPage.clickOnSeeAllResults();
	}

	@And("^user is able to see search results in \"([^\"]*)\" tab under SMA SWP APP accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_sma_swp_app_accordion(String strArg1)
			throws Throwable {
		updateSMASWPAAPPage.verifyTheSearchedResultInAllTab();
	}

	@And("^user clicks on \"([^\"]*)\" tab on landing page for SMA SWP APP Strategy$")
	public void user_clicks_on_something_tab_on_landing_page_for_sma_swp_app_strategy(String strArg1) throws Throwable {
		updateSMASWPAAPPage.clickOnSMATab();
	}

	@And("^user is able to see Strategy in SMA tab$")
	public void user_is_able_to_see_strategy_in_sma_tab() throws Throwable {
		updateSMASWPAAPPage.verifySMATab();
	}

	@And("^user clicks hover on ellipsis icon for Strategy grid view$")
	public void user_clicks_hover_on_ellipsis_icon_for_strategy_grid_view() throws Throwable {
		updateSMASWPAAPPage.mouseHoveOnSearchedRecordsOnGrid();
	}

	@And("^user is able to see \"([^\"]*)\" options for SMA SWP APP Strategy$")
	public void user_is_able_to_see_something_options_for_sma_swp_app_strategy(String strArg1) throws Throwable {
		updateSMASWPAAPPage.verifyOnViewDetailsLink();
	}

	@And("^clicks on \"([^\"]*)\" link SMA SWP APP Strategy$")
	public void clicks_on_something_link_sma_swp_app_strategy(String strArg1) throws Throwable {
		updateSMASWPAAPPage.clickOnViewDetailsLink();
	}

	@And("^user is able to navigate to view details page of SMA SWP APP strategy$")
	public void user_is_able_to_navigate_to_view_details_page_of_sma_swp_app_strategy(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			updateSMASWPAAPPage.verifyElementsOnViewFAage(
					updateSMASWPAAPPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to get the all data from Conversion Sql query from database for SMA SWP$")
	public void user_able_to_get_the_all_data_from_conversion_sql_query_from_database_for_sma_swp(int column)
			throws Throwable {
		// Read the data from DB as per sql query
		Assert.assertTrue(landingPage1.isUserOnLandingPage());
		pmdb.DBConnectionStart();
		sheet = exlObj2.getSheet("Sql");
		ResultSet rs;
		String SQLquery = (String) exlObj2.getCellData(sheet, 0, column);
		System.out.println("Sql Query--->" + SQLquery);
		rs = DBManager.executeSelectQuery(SQLquery);
		ResultSetMetaData md = rs.getMetaData();
		int columns = md.getColumnCount();
		System.out.println("Total col count----" + columns);
		while (rs.next()) {
			for (int i = 1; i <= columns; i++) {
				row.put(md.getColumnName(i), rs.getObject(i));
				if (md.getColumnName(i).trim().equalsIgnoreCase("strategy_code")) {
					strategyCode = (String) rs.getObject(i);
					System.out.println("Strategy Code from DB " + strategyCode);
				}
				if (md.getColumnName(i).equalsIgnoreCase("premium_fee_eligible") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("false")) {
					row.put(md.getColumnName(i), "No");
				} else if (md.getColumnName(i).equalsIgnoreCase("premium_fee_eligible") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("true")) {
					row.put(md.getColumnName(i), "Yes");
				}
				if (md.getColumnName(i).equalsIgnoreCase("concord_eligible") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("false")) {
					row.put(md.getColumnName(i), "No");
				} else if (md.getColumnName(i).equalsIgnoreCase("concord_eligible") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("true")) {
					row.put(md.getColumnName(i), "Yes");
				}
				if (md.getColumnName(i).equalsIgnoreCase("is_manager_profile_available") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("false")) {
					row.put(md.getColumnName(i), "No");
				} else if (md.getColumnName(i).equalsIgnoreCase("is_manager_profile_available")
						&& rs.getObject(i) != null && rs.getObject(i).toString().equalsIgnoreCase("true")) {
					row.put(md.getColumnName(i), "Yes");
				}
				if (md.getColumnName(i).equalsIgnoreCase("deleted_flag") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("false")) {
					row.put(md.getColumnName(i), "No");
				} else if (md.getColumnName(i).equalsIgnoreCase("deleted_flag") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("true")) {
					row.put(md.getColumnName(i), "Yes");
				} else if (ObjectUtils.isEmpty(rs.getObject(i))) {
					row.put(md.getColumnName(i), "—");
				}
			}
		}

		row.entrySet().stream().forEach(S -> System.out.println(S));

		exlObj2.closeWorkBook();
		pmdb.DBConnectionClose();

	}

	@Then("^User should able validate the Conversion attribute on view details page for SMA SWP APP Details section$")
	public void user_should_able_validate_the_conversion_attribute_on_view_details_page_for_sma_swp_app_details_section(
			List<String> entity) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < entity.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"(//label[text()='" + entity.get(i) + "']//parent::div//following::div)[1]");
			action.scrollToElement(check);
			uiElementView = check.getText().trim();
			uIElements.add(uiElementView);
		}
	}

	@And("^User should able validate the Conversion attribute on view details page for SMA SWP APP Benchmark and Asset Classification section$")
	public void user_should_able_validate_the_conversion_attribute_on_view_details_page_for_sma_swp_app_benchmark_and_asset_classification_section(
			String entity) throws Throwable {
		// Get the elements on UI
		Action.pause(1000);
		WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
				"//div[contains(text(),'" + entity + "')]//following::div[@class='body-3 mb6']");
		action.scrollToElement(check);
		uiElementViewBencharkAssetClassification = check.getText().trim();

		String[] splitBundled = uiElementViewBencharkAssetClassification.split("-");
		String bundledName = splitBundled[0].trim();
		String bundledPercent = splitBundled[1].trim();
		String percentage = StringUtils.substring(bundledPercent, 0, bundledPercent.length() - 1);
		percentage = percentage.indexOf(".") < 0 ? percentage
				: percentage.replaceAll("0*$", "").replaceAll("\\.$", "").trim();
		uIElements.add(bundledName);
		uIElements.add(percentage);

	}

	@And("^User should able validate the Conversion attribute on view details page for SMA SWP APP Proxy Details section$")
	public void user_should_able_validate_the_conversion_attribute_on_view_details_page_for_sma_swp_app_proxy_details_section(
			List<String> entity) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < entity.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"(//h6[contains(text(),'Proxy Address')]//following::label[contains(text(),'" + entity.get(i)
							+ "')]//following::div)[1]");
			action.scrollToElement(check);
			uiElementViewProxySection = check.getText().trim();
			uIElements.add(uiElementViewProxySection);
		}
	}

	@And("^User should able validate the Conversion attribute on view details page for SMA SWP APP Interim Details section$")
	public void user_should_able_validate_the_conversion_attribute_on_view_details_page_for_sma_swp_app_interim_details_section(
			List<String> entity) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < entity.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"(//h6[contains(text(),'Interim Address')]//following::label[contains(text(),'" + entity.get(i)
							+ "')]//following::div)[1]");
			action.scrollToElement(check);
			uiElementViewInterimAddressSection = check.getText().trim();
			uIElements.add(uiElementViewInterimAddressSection);
		}
	}

	@And("^User should able validate the Conversion attribute on view details page for SMA SWP APP Voluntary Reorg Address Details section$")
	public void user_should_able_validate_the_conversion_attribute_on_view_details_page_for_sma_swp_app_voluntary_reorg_address_details_section(
			List<String> entity) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < entity.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"(//h6[contains(text(),'Voluntary Reorg Address')]//following::label[contains(text(),'"
							+ entity.get(i) + "')]//following::div)[1]");
			action.scrollToElement(check);
			uiElementViewVoluntaryReorgAddressSection = check.getText().trim();
			uIElements.add(uiElementViewVoluntaryReorgAddressSection);
		}
	}

	@And("^User should able validate the Conversion attribute on view details page and db attributes are same for SMA SWP APP Update$")
	public void user_should_able_validate_the_conversion_attribute_on_view_details_page_and_db_attributes_are_same_for_sma_swp_app_update()
			throws Throwable {

		System.out.println("UI elements -------" + uIElements);

		// comparing the DB and UI elements
		Action.pause(2000);
		Iterator<Entry<String, Object>> itr = row.entrySet().iterator();
		String ele = null;
		for (int i = 0; i < uIElements.size(); i++) {
			ele = uIElements.get(i);

			while (itr.hasNext()) {
				Entry<String, Object> entry = itr.next();
				if (entry.getValue() != null)

					if (ele.equalsIgnoreCase(entry.getValue().toString().trim())) {
						Assert.assertEquals(ele, entry.getValue());
						Reporter.addScreenCapture();
					}
			}
		}
	}

	@When("^user queries the FOA Code (.+)  for an already created Strategy as a search token (.+)$")
	public void user_queries_the_foa_code_for_an_already_created_strategy_as_a_search_token(String entity,
			String searchcode) throws Throwable {

		Thread.sleep(5000);
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "data");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchcode);

		myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
		searchcode = myValue;
		System.out.println(myValue);

		Boolean compareBoolean = action.isPresent("js",
				"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");

		if (compareBoolean) {

			Thread.sleep(5000);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}

		Thread.sleep(5000);

		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		Thread.sleep(5000);
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;

		while (i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);

	}

	@Then("^User clicks on the first element of SMA_SWP Searches on the suggestion box on landing page while SMA_SWP updation$")
	public void user_clicks_on_the_first_element_of_smaswp_searches_on_the_suggestion_box_on_landing_page_while_smaswp_updation()
			throws Throwable {

		myElements = updateSMASinglePage
				.findElementsByDynamicXpath("//label[contains(text(),'SMA Strategy')]//parent::div//div[2]");

		String status = "FAIL";

		for (WebElement E : myElements) {
			if (E.getText().toUpperCase().contains(myValue.toUpperCase())) {
				status = "PASS";
				action.scrollToElement(E);
				action.highligthElement(E);
				// Thread.sleep(5000);
				E.click();
				Reporter.addStepLog("clicking on the matching suggestion");

				break;
			}

		}

		if (status.contentEquals("FAIL")) {
			myElement.sendKeys(Keys.ENTER);

			myElements = updateSMASinglePage
					.findElementsByDynamicXpath("//label[contains(text(),'SMA Strategy')]//parent::div//div[2]");

			for (WebElement E : myElements) {
				if (E.getText().toUpperCase().contains(myValue.toUpperCase())) {
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();

					action.waitForPageLoad();

					Reporter.addStepLog("clicking on the matching suggestion");

					break;
				}

			}
		}
	}

	@Then("^User proceeds with the execution by clicking upon the continue edit button in the UI$")
	public void user_proceeds_with_the_execution_by_clicking_upon_the_continue_edit_button_in_the_ui()
			throws Throwable {
		Thread.sleep(3000);
		myElement = updateSMASinglePage.findElementByDynamicXpath("//span[contains(text(),'CONTINUE EDITING')]");

		action.highligthElement(myElement);
		Thread.sleep(2000);

		myElement.click();
		Reporter.addStepLog("Clicked on Continue Editing Button");
		Thread.sleep(3000);

	}

	@And("^the user makes the following amends to the below fields which are categorised as dropdown list choices$")
	public void the_user_makes_the_following_amends_to_the_below_fields_which_are_categorised_as_dropdown_list_choices(
			List<List<String>> attribute) throws Throwable {
		sheetName = "sma_swp";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);

			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(3000);

			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.click(myElement);
			action.highligthElement(myElement);
			Thread.sleep(3000);

		}

	}

	@Then("^User continues to the next page by clicking on the next button$")
	public void user_continues_to_the_next_page_by_clicking_on_the_next_button() throws Throwable {

		// Thread.sleep(2000);

		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector(\"brml-button[type='submit']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		// Thread.sleep(2000);
	}

	@Then("^as the coverage gets complete the user finishes the process by clicking at the submit button$")
	public void as_the_coverage_gets_complete_the_user_finishes_the_process_by_clicking_at_the_submit_button()
			throws Throwable {
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector(\"brml-button[type='submit']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
	}

	@And("^the user chooses to change certain fields below which are inputs as text boxes$")
	public void the_user_chooses_to_change_certain_fields_below_which_are_inputs_as_text_boxes(
			List<List<String>> attribute) throws Throwable {
		sheetName = "sma_swp";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-textarea[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('textarea')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			action.sendkeysClipboard(myElement, myValue);

			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);

		}
	}

	@And("^the user check on the boxes to further enhance the strategy$")
	public void the_user_check_on_the_boxes_to_further_enhance_the_strategy() throws Throwable {
		Thread.sleep(3000);
		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector(\"brml-checkbox[id='optionEligible']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector(\"brml-checkbox[id='collateralEligible']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
//    Thread.sleep(2000);
//    myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-checkbox[id='concordEligible']\")");
//    action.scrollToElement(myElement);
//    action.highligthElement(myElement);
//    action.click(myElement);
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector(\"brml-checkbox[id='nraEligibility']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector(\"brml-checkbox[id='foreignSecurities']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector(\"brml-checkbox[id='premiumFee']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
	}

	@When("^User enter the Conversion data strategy code in global search on landing page$")
	public void user_enter_the_conversion_data_strategy_code_in_global_search_on_landing_page() throws Throwable {
		Action.pause(1000);
		updateSMASWPAAPPage.searchAndEnterStrategyCode(strategyCode);
	}

	@And("^User clicks on Continue Editing Option in View Details page in Update SMA Single SWP APP Flow$")
	public void user_clicks_on_continue_editing_option_in_view_details_page_in_update_sma_single_swp_app_flow()
			throws Throwable {
		updateSMASWPAAPPage.clickOnContinueEditingButton();
	}

	@And("^User able to get the data from input fields on Enter Strategy Details page$")
	public void user_able_to_get_the_data_from_input_fields_on_enter_strategy_details_page(List<String> entity)
			throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < entity.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage
					.findElementByDynamicXpath("//brml-input[@label='" + entity.get(i) + "']");
			action.scrollToElement(check);
			uiElementDetailsPageInput = check.getAttribute("value").trim();
			System.out.println("Details page Input ---" + uiElementDetailsPageInput);
			uIElements.add(uiElementDetailsPageInput);
		}
	}

	@And("^User able to get the data from drop down fields on Enter Strategy Details page$")
	public void user_able_to_get_the_data_from_drop_down_fields_on_enter_strategy_details_page(List<String> entity)
			throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < entity.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage
					.findElementByDynamicXpath("//brml-select[@label='" + entity.get(i) + "']");
			action.scrollToElement(check);
			uiElementDetailsPageDropdown = check.getAttribute("value").trim();
			System.out.println("Details page Drop Down ---" + uiElementDetailsPageDropdown);
			uIElements.add(uiElementDetailsPageDropdown);
		}
	}

	@And("^User able to get the data from checkbox fields on Enter Strategy Details page$")
	public void user_able_to_get_the_data_from_checkbox_fields_on_enter_strategy_details_page(
			List<String> attributeValuePair) throws Throwable {
		// Get the radio button elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(2000);
			WebElement check = updateSMASWPAAPPage.getDynamicElementFromShadowRoot("return document.querySelector('"
					+ attributeValuePair.get(i) + "').shadowRoot.querySelector('wf-tooltip > div > div')");
			action.scrollToElement(check);
			action.highligthElement(check);
			uIcheckBoxButton = check.getAttribute("class");
			Action.pause(2000);

			if (uIcheckBoxButton.contains("checked"))
				uIcheckBoxButton = "Yes";
			else
				uIcheckBoxButton = "No";
			System.out.println("Details page checkbox ---" + uIcheckBoxButton);
			uIElements.add(uIcheckBoxButton);
		}
	}

	@And("^User clicks on Next in Enter Strategy Details page in Update SMA Single SWP AAP Flow$")
	public void user_clicks_on_next_in_enter_strategy_details_page_in_update_sma_single_swp_aap_flow()
			throws Throwable {
		updateSMASWPAAPPage.clickOnNext();
	}

	@Then("^the user clicks on the dropdown that suggests Asset Classification for a given Unbundled Node ID$")
	public void the_user_clicks_on_the_dropdown_that_suggests_asset_classification_for_a_given_unbundled_node_id()
			throws Throwable {
		// throw new PendingException();
	}

	@And("^User able to get the data from grayout input fields on Benchmark and Asset Classification page$")
	public void user_able_to_get_the_data_from_grayout_input_fields_on_benchmark_and_asset_classification_page(
			List<String> attributeValuePair) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath("//brml-select[@label='"
					+ attributeValuePair.get(i) + "']/child::brml-select-option[@selected='true']");
			uiElementBenchmarkPageDropdown = check.getAttribute("name").trim();
			String[] splitBundled = uiElementBenchmarkPageDropdown.split("-");
			String bundledName = splitBundled[0].trim();
			System.out.println("Benchmark Asset ---" + bundledName);
			uIElements.add(bundledName);
		}
	}

	@And("^User able to get the grayout Percentage input fields on Benchmark and Asset Classification page$")
	public void user_able_to_get_the_grayout_percentage_input_fields_on_benchmark_and_asset_classification_page(
			List<String> attributeValuePair) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage
					.findElementByDynamicXpath("//brml-stepper-input[@label='" + attributeValuePair.get(i) + "']");
			uiElementBenchmarkPercentage = check.getAttribute("max-value").trim();
			action.scrollToElement(check);
			System.out.println("Benchmark Percentage ---" + uiElementBenchmarkPercentage);
			uIElements.add(uiElementBenchmarkPercentage);
		}
	}

	@And("^User clicks on Next in Benchmark Page in Update SMA Single SWP APP Flow$")
	public void user_clicks_on_next_in_benchmark_page_in_update_sma_single_swp_app_flow() throws Throwable {
		updateSMASWPAAPPage.clickOnNext();
	}

	@And("^User able to get the data from Proxy Addresses section from Proxy Details page$")
	public void user_able_to_get_the_data_from_proxy_addresses_section_from_proxy_details_page(
			List<String> attributeValuePair) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"//brml-input[@name='proxy'][@label='" + attributeValuePair.get(i) + "']");
			action.scrollToElement(check);
			uiElementProxyPageInput = check.getAttribute("value");
			System.out.println("Proxy Input ---" + uiElementProxyPageInput);
			uIElements.add(uiElementProxyPageInput);
		}
	}

	@And("^User able to get the data from State field from Proxy Details page$")
	public void user_able_to_get_the_data_from_state_field_from_proxy_details_page(List<String> attributeValuePair)
			throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"//brml-select[@name='proxy'][@label='" + attributeValuePair.get(i) + "']");
			action.scrollToElement(check);
			uiElementProxyPageDropDown = check.getAttribute("value").trim();
			System.out.println("Proxy Drop Down ---" + uiElementProxyPageDropDown);
			uIElements.add(uiElementProxyPageDropDown);
		}
	}

	@And("^User able to get the data from Interim Addresses section from Proxy Details page$")
	public void user_able_to_get_the_data_from_interim_addresses_section_from_proxy_details_page(
			List<String> attributeValuePair) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"//brml-input[@name='interim'][@label='" + attributeValuePair.get(i) + "']");
			action.scrollToElement(check);
			uiElementInterimPageInput = check.getAttribute("value").trim();
			System.out.println("Interim Input ---" + uiElementInterimPageInput);
			uIElements.add(uiElementInterimPageInput);
		}
	}

	@And("^User able to get the data from State Interim field from Proxy Details page$")
	public void user_able_to_get_the_data_from_state_interim_field_from_proxy_details_page(
			List<String> attributeValuePair) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"//brml-select[@name='interim'][@label='" + attributeValuePair.get(i) + "']");
			action.scrollToElement(check);
			uiElementInterimPageDropDown = check.getAttribute("value").trim();
			System.out.println("Interim Drop Down ---" + uiElementInterimPageDropDown);
			uIElements.add(uiElementInterimPageDropDown);
		}
	}

	@And("^User able to get the data from Voluntary Reorg Addresses section from Proxy Details page$")
	public void user_able_to_get_the_data_from_voluntary_reorg_addresses_section_from_proxy_details_page(
			List<String> attributeValuePair) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"//brml-input[@name='voluntaryReorg'][@label='" + attributeValuePair.get(i) + "']");
			action.scrollToElement(check);
			uiElementVoluntaryReorgPageInput = check.getAttribute("value").trim();
			System.out.println("Interim Input ---" + uiElementVoluntaryReorgPageInput);
			uIElements.add(uiElementVoluntaryReorgPageInput);
		}
	}

	@And("^user makes amends to the effective benchmarks$")
	public void user_makes_amends_to_the_effective_benchmarks() throws InterruptedException {

	}

	@And("^User able to get the data from State Voluntary Reorg field from Proxy Details page$")
	public void user_able_to_get_the_data_from_state_voluntary_reorg_field_from_proxy_details_page(
			List<String> attributeValuePair) throws Throwable {
		// Get the elements on UI
		for (int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateSMASWPAAPPage.findElementByDynamicXpath(
					"//brml-select[@name='voluntaryReorg'][@label='" + attributeValuePair.get(i) + "']");
			action.scrollToElement(check);
			uiElementVoluntaryReorgPageDropDown = check.getAttribute("value").trim();
			System.out.println("Interim Drop Down ---" + uiElementVoluntaryReorgPageDropDown);
			uIElements.add(uiElementVoluntaryReorgPageDropDown);
		}
	}

	@Then("^User should able validate the Conversion attribute on update details page and db attributes are same for SMA SWP APP Update$")
	public void user_should_able_validate_the_conversion_attribute_on_update_details_page_and_db_attributes_are_same_for_sma_swp_app_update()
			throws Throwable {
		System.out.println("UI elements -------" + uIElements);

		// comparing the DB and UI elements
		Action.pause(2000);
		String ele = null;
		for (int i = 0; i < uIElements.size(); i++) {
			ele = uIElements.get(i);

			Iterator<Entry<String, Object>> itr = row.entrySet().iterator();
			while (itr.hasNext()) {
				Entry<String, Object> entry = itr.next();
				if (entry.getValue() != null)

					if (ele.equalsIgnoreCase(entry.getValue().toString())) {
						Assert.assertEquals(ele, entry.getValue());
					}
			}
		}
	}

	@And("^User is in Enter Strategy Details Page of Update SMA Single SWP AAP flow$")
	public void user_is_in_enter_strategy_details_page_of_update_sma_single_swp_aap_flow() throws Throwable {
		Assert.assertTrue(updateSMASWPAAPPage.isUserOnEnterStrategyDetailspage());
	}

	@And("^User clicks on Next in Enter Strategy Details page in Update SMA Single SMA SWP AAP Flow$")
	public void user_clicks_on_next_in_enter_strategy_details_page_in_update_sma_single_sma_swp_aap_flow()
			throws Throwable {
		updateSMASWPAAPPage.clickOnNext();
	}

	@And("^User is in Bnechmark Page in Update SMA Single SMA SWP Flow$")
	public void user_is_in_bnechmark_page_in_update_sma_single_sma_swp_flow() throws Throwable {
		Assert.assertTrue(updateSMASWPAAPPage.isUserOnBenchmarkPage());
	}

	@And("^User clicks on Next in Proxy Details Page in Update SMA Single SWP APP Flow$")
	public void user_clicks_on_next_in_proxy_details_page_in_update_sma_single_swp_app_flow() throws Throwable {
		updateSMASWPAAPPage.clickOnNext();
	}

	@And("^User is in Documents Page in Update SMA Single SWP APP Flow$")
	public void user_is_in_documents_page_in_update_sma_single_swp_app_flow() throws Throwable {
		Assert.assertTrue(updateSMASWPAAPPage.isUserOnDocumentspage());
	}

	@And("^User clicks on Next in Documents Page in Update SMA Single SWP APP Flow$")
	public void user_clicks_on_next_in_documents_page_in_update_sma_single_swp_app_flow() throws Throwable {
		updateSMASWPAAPPage.clickOnNext();
	}

	@And("^User is in Comments Page in Update SMA Single SWP APP Flow$")
	public void user_is_in_comments_page_in_update_sma_single_swp_app_flow() throws Throwable {
		Assert.assertTrue(updateSMASWPAAPPage.isUserOnCommentsPage());
	}

	@And("^User clicks on Next in Comments Page in Update SMA Single SWP APP Flow$")
	public void user_clicks_on_next_in_comments_page_in_update_sma_single_swp_app_flow() throws Throwable {
		updateSMASWPAAPPage.clickOnNext();
	}

	@And("^User is in Review Page in Update SMA Single SWP APP Flow$")
	public void user_is_in_review_page_in_update_sma_single_swp_app_flow() throws Throwable {
		Assert.assertTrue(updateSMASWPAAPPage.isUserOnReviewPage());
	}

	@Then("^User clicks on the status dropdown list$")
	public void user_clicks_on_the_status_dropdown_list() throws Throwable {
		updateSMASWPAAPPage.clicksonthestatusddl();

	}

	@And("^further expands the ddl$")
	public void further_expands_the_ddl() throws Throwable {

		updateSMASWPAAPPage.expandsddl();
	}

	@And("^decides to make the voluntary reorg addres same as the proxy address$")
	public void decides_to_make_the_voluntary_reorg_addres_same_as_the_proxy_address() throws Throwable {
		pg.clicksonsameasproxyaddress();
	}

	@And("^further makes the interim address the same as the proxy address$")
	public void further_makes_the_interim_address_the_same_as_the_proxy_address() throws Throwable {
		pg.clicksonsameasproxyaddress();
	}

	@And("^the fields for Description node id, unbundled id are highlighted for validation purposes$")
	public void the_fields_for_description_node_id_unbundled_id_are_highlighted_for_validation_purposes()
			throws Throwable {

		updateSMASWPAAPPage.highlightbundled();

	}

	@When("^User search with the (.+) taken from (.+) in the Search TextBox on landing page while SMASwp updation$")
	public void user_search_with_the_taken_from_in_the_search_textbox_on_landing_page_while_smasingleaccess_updation(
			String entity, String searchcode) throws Throwable {
		// action.waitForPageLoad();
		Thread.sleep(5000);
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "data");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchcode);

		myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
		searchcode = myValue;
		//System.out.println(myValue);

		Boolean compareBoolean = action.isPresent("js",
				"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");

		if (compareBoolean) {

			Thread.sleep(5000);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}

		Thread.sleep(5000);
		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		Thread.sleep(5000);
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;

		while (i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);
	}

}
