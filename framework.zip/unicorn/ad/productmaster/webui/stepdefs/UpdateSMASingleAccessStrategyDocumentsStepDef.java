package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.junit.Assert;

import cucumber.api.java.en.And;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessStrategyDocumentsPage;

public class UpdateSMASingleAccessStrategyDocumentsStepDef {

	UpdateSMASingleAccessStrategyDocumentsPage documentsPage = new UpdateSMASingleAccessStrategyDocumentsPage("AD_PM_UpdateSMASingleAccessStrategyDocumentsPage");
	
	@And("^User is in Documents Page in Update SMA Single Access Flow$")
    public void user_is_in_documents_page_in_update_sma_single_access_flow() {
        Assert.assertTrue(documentsPage.isUserOnDocumentspage());
    }

    @And("^User clicks on Next in Documents Page in Update SMA Single Access Flow$")
    public void user_clicks_on_next_in_documents_page_in_update_sma_single_access_flow() {
        documentsPage.clickOnNext();
    }
}
