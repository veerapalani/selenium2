package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.FATeamSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;

public class FATeamSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	FATeamSortAndFilterPage fATeamSortAndFilterPage = new FATeamSortAndFilterPage("AD_PM_FATeamSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/FAAndFATeamSortAndFilter.xlsx";
	String sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError, countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_FATeamSortAndFilterPage"));

	@When("^User enter valid (.+) in global search box for FA Team$")
	public void user_enter_valid_in_global_search_box_for_fa_team(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String FATeamSearchValue = (String) exlObj.getCellData(sheet, rowIndex, 1);

		exlObj.closeWorkBook();
		if (FATeamSearchValue != "") {
			// fATeamSortAndFilterPage.searchFATeamValue(FATeamSearchValue);
			landingPage.enterSearchToken(FATeamSearchValue);
			landingPage.clickOnSearchIcon();
		}
		Reporter.addScreenCapture();
	}

	@And("^user clicks on \"([^\"]*)\" on landing page for FA Team$")
	public void user_clicks_on_something_on_landing_page_for_fa_team(String strArg1) throws Throwable {
		// fATeamSortAndFilterPage.clickOnSeeAllResultsForFATeamLayout();
		landingPage.clickOnSeeAllResultsButton();
	}

	@And("^user is able to see search results in \"([^\"]*)\" tab under FA Team accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_fa_team_accordion(String strArg1)
			throws Throwable {
		fATeamSortAndFilterPage.verifyTheSearchedResultInAllTabForFATeam();
	}

	@And("^user click on \"([^\"]*)\" tab on landing page for FA Team$")
	public void user_click_on_something_tab_on_landing_page_for_fa_team(String strArg1) throws Throwable {
		fATeamSortAndFilterPage.verifyAndClickManagerTab();
	}

	@And("^User able to see searched grid view data for FA Team grid view$")
	public void user_able_to_see_searched_grid_view_data_for_fa_team_grid_view() throws Throwable {
		String gridCountBeforeCondition = fATeamSortAndFilterPage.verifyTheGridCountBeforeApplyFilterAndSortCondition();
		// String gridCountBeforeCondition =
		// fATeamSortAndFilterPage.getGridCountAfterGlobalSearch();
		int beforeApplyCondition = Integer.parseInt(gridCountBeforeCondition);
		if (beforeApplyCondition == 1)
			fATeamSortAndFilterPage.verifyTheNoResultsOnGridView();
	}

	@Then("^User should be able to search records for FA Team View using the global search box on landing page$")
	public void user_should_be_able_to_search_records_for_fa_team_view_using_the_global_search_box_on_landing_page()
			throws Throwable {
		fATeamSortAndFilterPage.verifySearchedGridViewDisplay();
	}

	@Then("^Validate to check updated Sort icon  Criteria on Text on Column 'FA Team Name' of FA Team grid view$")
	public void validate_to_check_updated_sort_icon_criteria_on_text_on_column_fa_team_name_of_fa_team_grid_view(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fATeamSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			fATeamSortAndFilterPage.mouseHoverOnGridViewLabels(fATeamSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			fATeamSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			fATeamSortAndFilterPage.verifyGridViewLabelsWithSortIcons(
					fATeamSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();

		}
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for FA Team$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_fa_team(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fATeamSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			fATeamSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					fATeamSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for FA Team$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_fa_team(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fATeamSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			fATeamSortAndFilterPage.mouseHoverOnGridViewLabels(fATeamSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			fATeamSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			fATeamSortAndFilterPage.clickOnSortIcon(
					fATeamSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for FA Team$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_fa_team() throws Throwable {
		String value = fATeamSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = fATeamSortAndFilterPage.getAscSortValue();
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for FA Team$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_fa_team(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fATeamSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			fATeamSortAndFilterPage.mouseHoverOnGridViewLabels(fATeamSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			fATeamSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			fATeamSortAndFilterPage.clickOnSortIcon(
					fATeamSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for FA Team$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_fa_team() throws Throwable {
		String value = fATeamSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = fATeamSortAndFilterPage.getDescSortValue();
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for FA Team$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_fa_team(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fATeamSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			fATeamSortAndFilterPage.mouseHoverOnGridViewLabels(fATeamSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			fATeamSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]");
			fATeamSortAndFilterPage.clickOnSortIcon(
					fATeamSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for FA Team$")
	public void user_should_able_to_sort_the_records_with_default_order_for_fa_team() throws Throwable {
		String value = fATeamSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = fATeamSortAndFilterPage.getDefaultSortValue();
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to see tab count as per searched keyword for before any condition for FA Team$")
	public void user_able_to_see_tab_count_as_per_searched_keyword_for_before_any_condition_for_fa_team()
			throws Throwable {
		String beforeApplyFilterValue = fATeamSortAndFilterPage
				.verifyTheFATeamGridCountAfterApplyFilterConditionOnTab();
		// String beforeApplyFilterValue =
		// fATeamSortAndFilterPage.getTabCountAfterCondition();
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);
	}

	@And("^User able to click on the filter icon for below column for FA Team$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_fa_team(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			fATeamSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			fATeamSortAndFilterPage.clickOnFilterIconForGridView(
					fATeamSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to select the (.+) from filter condition for FA Team$")
	public void user_able_to_select_the_from_filter_condition_for_fa_team(String filtercondition) throws Throwable {
		fATeamSortAndFilterPage.clickOnFilterCondition();
		fATeamSortAndFilterPage
				.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']");
		fATeamSortAndFilterPage
				.clickOnFilterConditionForFATeamGridView(fATeamSortAndFilterPage.findElementByDynamicXpath(
						"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for FA Team$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_fa_team(String filterconditionvalue)
			throws Throwable {
		fATeamSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button on FA Team grid view$")
	public void user_able_to_click_on_the_apply_button_on_fa_team_grid_view() throws Throwable {
		fATeamSortAndFilterPage.clickOnApplyFilterIconForFATeamGridView();
		action.scrollToUp();
		Action.pause(1000);
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on FA Team grid view$")
	public void user_should_able_to_verify_the_grid_count_on_fa_team_grid_view() throws Throwable {
		String countTabAfterFilter = fATeamSortAndFilterPage.verifyTheFATeamGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// fATeamSortAndFilterPage.getTabCountAfterCondition();
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = fATeamSortAndFilterPage.verifyTheFATeamGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition / 10; i++) {
				action.waitForDomToComplete(WebDriverManager.getDriver());
				action.scrollToBottom();
				Action.pause(2000);
				String presentGridAllData = fATeamSortAndFilterPage.verifyTheFATeamGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			fATeamSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
			Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
					"The grid view and tab count mismatch");
		}
	}

	// Below is a Repeated step def for above, same code --
	/*
	 * @And("^User should able to verify the Tab count on FA Team grid view$")
	 * public void user_should_able_to_verify_the_tab_count_on_fa_team_grid_view()
	 * throws Throwable { fATeamSortAndFilterPage.
	 * verifyTheFATeamGridCountAfterApplyFilterConditionOnTab(); String
	 * countTabAfterFilter = fATeamSortAndFilterPage.getTabCountAfterCondition();
	 * countTabValue =
	 * countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
	 * countTabAfterFilter.length() - 1); tabCountAfterFilterCondition =
	 * Integer.parseInt(countTabValue);
	 * 
	 * String presentGridData =
	 * fATeamSortAndFilterPage.verifyTheFATeamGridCountAfterScroll();
	 * parseValueOfGridCountAfterFilterCondition =
	 * Integer.parseInt(presentGridData); parseValueOfGridCountAfterFilterCondition
	 * = parseValueOfGridCountAfterFilterCondition - 1;
	 * 
	 * if (parseValueOfGridCountAfterFilterCondition >= 10) for (int i = 0; i <=
	 * beforeApplyFiltertabCountValue; i++) { action.scrollToBottom();
	 * Action.pause(1000); String presentGridAllData =
	 * fATeamSortAndFilterPage.verifyTheFATeamGridCountAfterScroll();
	 * parseValueOfGridCountAfterFilterCondition =
	 * Integer.parseInt(presentGridAllData);
	 * parseValueOfGridCountAfterFilterCondition =
	 * parseValueOfGridCountAfterFilterCondition - 1;
	 * 
	 * if (parseValueOfGridCountAfterFilterCondition ==
	 * tabCountAfterFilterCondition) break; } if
	 * (parseValueOfGridCountAfterFilterCondition == 0) {
	 * fATeamSortAndFilterPage.verifyTheNoResultsOnGridView(); }
	 * Assert.assertEquals(parseValueOfGridCountAfterFilterCondition,
	 * tabCountAfterFilterCondition, "The tab count and grid view mismatch");
	 * Reporter.addScreenCapture(); }
	 */

	@And("^User able to click on the Reset Button on FA Team grid view$")
	public void user_able_to_click_on_the_reset_button_on_fa_team_grid_view() throws Throwable {
		fATeamSortAndFilterPage.clickOnApplyFilterIconForFATeamGridViewForReset();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button on FA Team grid view$")
	public void user_able_to_click_on_the_cancel_button_on_fa_team_grid_view() throws Throwable {
		fATeamSortAndFilterPage.clickOnApplyFilterIconForFATeamGridViewForCancel();
		action.scrollToUp();
		Action.pause(1000);
		Reporter.addScreenCapture();
	}

}
