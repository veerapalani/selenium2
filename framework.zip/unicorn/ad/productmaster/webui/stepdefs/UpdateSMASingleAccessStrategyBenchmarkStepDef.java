package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessStrategyBenchmarkPage;

public class UpdateSMASingleAccessStrategyBenchmarkStepDef {

	UpdateSMASingleAccessStrategyBenchmarkPage benchmarkPage = new UpdateSMASingleAccessStrategyBenchmarkPage("AD_PM_UpdateSMASingleAccessStrategyBenchmarkPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName;
	String label, attributeValue, uiValue,dbValue = null;
	
	public static int count;
	public static int defaultbenchmarkcount;
	
	@And("^User is in Bnechmark Page in Update SMA Single Access Flow$")
    public void user_is_in_bnechmark_page_in_update_sma_single_access_flow() {
        Assert.assertTrue(benchmarkPage.isUserOnBenchmarkPage());
    }

    @And("^Stored Values in DB should be prepopulated in Benchmark Page in Update SMA Single Access Flow$")
    public void stored_values_in_db_should_be_prepopulated_in_benchmark_page_in_update_sma_single_access_flow() {
    	sheetName = "Conversion_Validation";
		   sheet = exlObj.getSheet(sheetName);
		   int rownum = 13;
		   count = 0;
		   label = (String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if((label == "") ||(label.contains("Proxy Manager")) )
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")) {
							rownum++;
			    			label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if((label == "") ||(label.contains("Proxy Manager")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromBenchmarkAndAssetClassificationPage(label);
						dbValue =(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							exlObj.setCellData(sheet, rownum, 5, attributeValue);
						}else {
							exlObj.setCellData(sheet, rownum, 5, attributeValue+"-UI Value is not same as Stored Value in DB");
							
							Reporter.addCompleteScreenCapture();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							count++;
							
						}
						
							rownum++;
							label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("Proxy Manager")))
								label = "isEmpty";
					
					}
			}
			
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addEntireScreenCaptured();
			//Reporter.addStepLog("In Benchmark And Asset Classification Page Values Stored in DB are Populated in UI");
			exlObj.closeWorkBook();
    }

    private String getDataFromBenchmarkAndAssetClassificationPage(String data) {
    	
    	switch (data) {
		case "Node ID - Bundled":
			
			uiValue = benchmarkPage.getBundledNodeIdValue();
			/*
			 * int timeperiodscount = benchmarkPage.getTimePeriodsCount(); ArrayList<String>
			 * tempData = new ArrayList<String>(); uiValue = ""; String[] value; for (int i
			 * = 1; i <= timeperiodscount; i++) { value =
			 * benchmarkPage.getBundledNodeIdValue().split("-");
			 * tempData.add(value[0].trim()); benchmarkPage.clickOnNextTimePeriod(i+1); }
			 * if(tempData.size() > 1) { Collections.sort(tempData); for (String G :
			 * tempData) { uiValue = uiValue+G+":"; } } tempData.clear();
			 */
			//uiValue = benchmarkPage.getBundledNodeIdValue();
			
			break;
		case "Assets":
//			String sheetName2 = "Variable_Paths";
//			XSSFSheet sheet2 = exlObj.getSheet(sheetName2);
//			
//			String locatorValue = "";//"//brml-select[@id='ddlBenchmarkunBundledNode-@data]/child::brml-select-option[@selected='true']";
//			int count = 0;
//			String temp;
//			uiValue="";
//			while(count > -1) {
//				
//				
//				locatorValue = (String) exlObj.getCellData(sheet2, 1, 1);
//				locatorValue = locatorValue.replace("@data",count+"'");
//				temp = benchmarkPage.getUnbundledNodeIdValues(locatorValue);
//				if(temp == "nomoreUnbundledValues")
//					break;
//				uiValue = uiValue+temp+":";
//				count++;
//				
//			}
//			
//			if(count == 1) {
//				uiValue = uiValue.substring(0, uiValue.length()-1);
//			}
			
			//uiValue = benchmarkPage.getUnbundledNodeIdValues();
			uiValue = "";
			break;
		default:
			uiValue = "NotChanged";
			break;
		}
    	if((uiValue == null) || (uiValue.isEmpty()))
			uiValue = "isEmpty";

    	return uiValue;
}


	@And("^User clicks on Next in Benchmark Page in Update SMA Single Acces Flow$")
    public void user_clicks_on_next_in_benchmark_page_in_update_sma_single_acces_flow() throws Throwable {
        benchmarkPage.clickOnNext();
    }
	
	@Then("^User should be able to see Benchmark value matching as per value in DB in Update SMA Access AssetClassification Page with (.+)$")
    public void user_should_be_able_to_see_benchmark_value_matching_as_per_value_in_db_in_update_sma_access_assetclassification_page_with(String mandatorydetails) throws SQLException {
		String primaryBenchmarkValue = benchmarkPage.getPrimaryBenchmarkValue();
		//System.out.println("CreateSMASingleAccessStrategyReviewStepdef::"+primaryBenchmarkValue);
		String defaultBenchmarkName ="";
		defaultbenchmarkcount = 0;
		if(primaryBenchmarkValue.contains(",")) {
			Reporter.addStepLog("In SMA Single Access - Default Benchmark cannot have two Benchmarks associated");
			defaultbenchmarkcount++;
		}
		else {
			String[] data = primaryBenchmarkValue.split("-#-");
			defaultBenchmarkName = data[2];
		}
		
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
		String sheetName = "";
		int rowIndex;
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet;
		//get DB Query
		sheetName = "Query";
		sheet = exlObj.getSheet(sheetName);
		String SQLquery = (String) exlObj.getCellData(sheet, 1, 1);
		String labelname = (String) exlObj.getCellData(sheet, 1, 2);
		
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
			mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		}
		
		//get investment style name
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		
		pmdb.DBConnectionStart();
		SQLquery = SQLquery.replace("@data", "'"+investmentStyleName+"'");
		ResultSet rs;
		rs= DBManager.executeSelectQuery(SQLquery);
		String dbDataIterator = null;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			
		 }
		pmdb.DBConnectionClose();
		exlObj.closeWorkBook();
		
		//comparing only Benchmark Name as Percentage will be 100 for default
		if(dbDataIterator.equals(defaultBenchmarkName)) {
			Reporter.addStepLog("Default Benchmark Name Value displayed in Benchmark Page matches with Value in DB");
		}
		else {
			defaultbenchmarkcount++;
			Reporter.addStepLog("Default Benchmark Name Value displayed in Benchmark Page does not match with Value in DB");
		}
    }
	
	@Then("^User should be able to view DVP/Key Trust template field on Benchmark and Asset Classification page while updating SMA single access startegy$")
    public void user_should_able_to_view_dvpKey_trust_template_field_on_benchmark_and_asset_classification_page_while_updating_sma_single_access() {
        assertTrue(benchmarkPage.isDvpKeyTrustTemplateVisible());
    }
}
