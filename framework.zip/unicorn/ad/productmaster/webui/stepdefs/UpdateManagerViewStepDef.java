package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerViewPage;

public class UpdateManagerViewStepDef {

	UpdateManagerViewPage viewPage = new UpdateManagerViewPage("AD_PM_UpdateManagerViewPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateManager.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue = null;
	
	@And("^user clicks on the Continue Editing on Manager Detail page$")
    public void user_clicks_on_the_continue_editing_on_manager_detail_page() {
		//action.click(action.getElement("Edit Button"));
		viewPage.clickOnContinueEditing();
        Reporter.addStepLog("clicked on Edit button");
    }
	
	@Then("^User should be able to see View Details page in Update Manager Flow$")
    public void user_should_be_able_to_see_view_details_page_in_update_manager_flow() {
        Assert.assertTrue(viewPage.isUserOnViewDetailsPage());
    }
	
	@And("^with Manager code from UI store the data related to manager in Excel for (.+) in Update Manager Flow$")
    public void with_manager_code_from_ui_store_the_data_related_to_manager_in_excel_for_in_update_manager_flow(String mandatorydetails) throws IOException, SQLException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
        String managerCode = viewPage.getManagerCode();
        rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 28, managerCode);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex+1, 28, managerCode);
        
        int updateDataRowIndex = rowIndex;
    	int dBDataRowIndex = rowIndex+1;

		getDataFromDBandStoreInExcel(managerCode, dBDataRowIndex);
    
        
    }

	private void getDataFromDBandStoreInExcel(String managerCode, int dBDataRowIndex) throws IOException, SQLException {

		pmdb.DBConnectionStart();

    	String SQLquery, labelname = null;
    	String dbDataIterator = "testNull";
    	ResultSet rs;
    	
    	
    	sheetName = "SQLQuery";
    	
    	int cellnum = 1;
    	String label  =  PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
    			//(String) exlObj.getCellData(sheet, cellnum, 0).toString();
    	ArrayList<String> tempData = new ArrayList<String>();
    	
		if(label == "")
			label = "isEmpty";
		
		while (label != "isEmpty") {
			
			if(label.contains("ignore")) {
				cellnum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
						//(String) exlObj.getCellData(sheet, cellnum, 0);
					if(label == "")
						label = "isEmpty";
			}
			else {
				
				dbDataIterator = "testnull";
				SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
						//(String) exlObj.getCellData(sheet, cellnum, 1);
				labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
						//(String) exlObj.getCellData(sheet, cellnum, 2);
				
	    		SQLquery = SQLquery.replace("@data", "'"+managerCode+"'");
	    		rs= DBManager.executeSelectQuery(SQLquery);
	    		
	   
	    		while(rs.next()) {
	    			
	    				dbDataIterator = rs.getString(labelname);
	    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    					dbDataIterator = "isEmpty";
		    					if(label.contains("radiobutton")) {
			    					dbDataIterator = "Not defined";
			    				}
		    			}
	    				
	    				tempData.add(dbDataIterator);
	    				
	    		 }
	    		//to handle Zero records from DB 
	    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
	    			dbDataIterator = "isEmpty";
	    		}
	    		//to handle Eye check override value
	    		if(label.equals("4 Eye Check Override"))
	    		{
	    			switch (dbDataIterator) {
					case "t":
						dbDataIterator = "Yes";
						break;
					case "f":
						dbDataIterator = "No";
						break;
					default:
						dbDataIterator = "Unexpected Value";
						break;
					}
	    		}
	    		//to handle multiple values for same column
	    		if(tempData.size() > 1) {
	    			Collections.sort(tempData);
	    			dbDataIterator = "";
	    			for (String G : tempData) {
							dbDataIterator = dbDataIterator+G+",";
					}
	    			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
	    		}
	    		tempData.clear();
	    		
	    		//setting data into excel for validation
	    		sheetName = "Test";
	    		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, dBDataRowIndex, cellnum+1, dbDataIterator);
	    		//exlObj.setCellData(sheet, cellnum, 3, dbDataIterator);
	    		sheetName = "SQLQuery";
				cellnum++;
	    		label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
	    		if(label == "")
	    			label = "isEmpty";
			}
			
			
		}
		
		//exlObj.closeWorkBook();
		pmdb.DBConnectionClose();
	
	}
	
	@And("^with Manager code from UI store the data related to manager from view page in Excel for (.+) in Update Manager Flow$")
    public void with_manager_code_from_ui_store_the_data_related_to_manager_from_view_page_in_excel_for_in_update_manager_flow(String mandatorydetails) throws IOException, SQLException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
        String managerCode = viewPage.getManagerCode();
        rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 28, managerCode);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex+2, 28, managerCode);
        
    	int viewPageDataRowIndex = rowIndex+2;
    	
		getDataFromViewPageandStoreInExcel(managerCode, viewPageDataRowIndex);
    }

	private void getDataFromViewPageandStoreInExcel(String managerCode, int viewPageDataRowIndex) throws IOException {
		
		
		sheetName = "Test";
		   
		   //count = 0;
		   int columNum = 2;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columNum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						
						
						if(label.contains("Contact")) {
							Boolean bool = viewPage.isContactsDisplayedInUI();
							
							if (bool) {
								attributeValue = getDataFromViewPage(label);
							}else {
								attributeValue = "isEmpty";
							}
						}else if(label.contains("Document")) {
							Boolean bool = viewPage.isDocumentsDisplayedInUI();
							
							if (bool) {
								attributeValue = getDataFromViewPage(label);
							}else {
								attributeValue = "isEmpty";
							}
						}else
							attributeValue = getDataFromViewPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex-1, columNum);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex, columNum, attributeValue);
							//exlObj.setCellData(sheet, rownum, 4, attributeValue);
						}else {
							
							if(label.contains("4 Eye Check Override")) {
								if(dbValue.trim().equalsIgnoreCase(attributeValue.trim()))
									PMPageGeneric.setCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex, columNum, attributeValue);
							}else {
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, viewPageDataRowIndex, columNum, attributeValue+" -UI Value is not same as Stored Value in DB");
								Reporter.addEntireScreenCaptured();
								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
								
							}
						}
						columNum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
    
		
	}

		private String getDataFromViewPage(String data) {
	    	switch (data) {
			case "Manager Name":
				
				uiValue = viewPage.getManagerNameValue();
				
				break;
			case "Firm Name":
				
				uiValue = viewPage.getFirmNameValue();
				
				break;
			case "Firm Website":
				
				uiValue = viewPage.getFirmWebsiteValue();
				
				break;
			case "Vestmark Manager Name":
				
				uiValue = viewPage.getVestmarkManagerNameValue();
				
				break;
			case "Taxpayer Identification Number":
				
				uiValue = viewPage.getTaxPayerIdentificationNumberValue();
				
				break;
			case "Large Trader ID":
				
				uiValue = viewPage.getLargeTraderIDValue();
				
				break;
			case "DTCC ID":
				
				uiValue = viewPage.getdtccIDValue();
				
				break;
			case "Status":
				
				uiValue = viewPage.getStatusValue();
				
				break;
			case "4 Eye Check Override":
				
				uiValue = viewPage.get4EyeCheckOverrideValue();
				
				break;
			case "UBS Subsidiary":
				
				uiValue = viewPage.getUBSSubsidiaryValue();
				
				break;
			case "Contact Type":
				
				uiValue = viewPage.getContactTypeValue();
				
				break;
			case "Contact Description":
				
				uiValue = viewPage.getContactDescriptionValue();
				
				break;
			case "Contact First Name":
				
				uiValue = viewPage.getContactFirstNameValue();
				
				break;
			case "Contact Middle Name":
				
				uiValue = viewPage.getContactMiddleNameValue();
				
				break;
			case "Contact Last Name":
				
				uiValue = viewPage.getContactLastNameValue();
				
				break;
			case "Contact Address":
				
				uiValue = viewPage.getContactAddressValue();
				
				break;
			case "Contact City":
				
				uiValue = viewPage.getContactCityValue();
				
				break;
			case "Contact State":
				
				uiValue = viewPage.getContactStateValue();
				
				break;
			case "Contact Postal Code":
							
				uiValue = viewPage.getContactPostalCodeValue();
							
				break;
			case "Contact Country":
				
				uiValue = viewPage.getContactCountryValue();
				
				break;
			case "Contact Email Address":
				
				uiValue = viewPage.getContactEmailAddressValue();
				
				break;
			case "Contact Phone Number":
				
				uiValue = viewPage.getContactPhoneNumberValue();
				
				break;
			case "Document Type":
				
				uiValue = viewPage.getDocumentTypeValue();
				
				break;
			case "Document Link":
				
				uiValue = viewPage.getDocumentLinkValue();
				
				break;
			case "Document Comment":
				
				uiValue = viewPage.getDocumentCommentValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
		}
		
		@And("^strategies linked to manager should be displayed in View Page in Update Manager Flow$")
	    public void strategies_linked_to_manager_should_be_displayed_in_view_page_in_update_manager_flow() throws SQLException {
	        
		String managerCode = viewPage.getManagerCode();
		Boolean bool = viewPage.isAssociatedStrategiesGridDisplayed();
		
		if (bool) {
			
			HashMap<String, ArrayList<String>> accessStrategiesMap = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> dualStrategiesMap = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> swpStrategiesMap = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> pmpStrategiesMap = new HashMap<String, ArrayList<String>>();
			
			accessStrategiesMap = viewPage.getSortedAccessStrategyData();
			dualStrategiesMap = viewPage.getSortedDualStrategyData();
			swpStrategiesMap = viewPage.getSortedSWPStrategyData();
			pmpStrategiesMap = viewPage.getSortedPMPStrategyData();
			
			/*
			 * Program codes
			 * 
			 * SMA Access -- 15
			 * SMA SWP -- 36
			 * PMP -- 12
			 * Dual -- 13,39
			 *
			 * */
			
			HashMap<String, ArrayList<String>> accessStrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> dualStrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> swpStrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			HashMap<String, ArrayList<String>> pmpStrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			
			accessStrategiesMapFromDB = getAssociatedStrategiesData("15", managerCode);
			dualStrategiesMapFromDB = getAssociatedStrategiesData("13,39", managerCode);
			swpStrategiesMapFromDB = getAssociatedStrategiesData("36", managerCode);
			pmpStrategiesMapFromDB = getAssociatedStrategiesData("12", managerCode);
			
			Assert.assertTrue(accessStrategiesMapFromDB.equals(accessStrategiesMap));
			Assert.assertTrue(swpStrategiesMapFromDB.equals(swpStrategiesMap));
			Assert.assertTrue(pmpStrategiesMapFromDB.equals(pmpStrategiesMap));
			Assert.assertTrue(dualStrategiesMapFromDB.equals(dualStrategiesMap));
			
			
			}else {
				Reporter.addStepLog("No associated strategies in UI");
			}
		}

		private HashMap<String, ArrayList<String>> getAssociatedStrategiesData(String programCode, String managerCode) throws SQLException {
			
			HashMap<String, ArrayList<String>> StrategiesMapFromDB = new HashMap<String, ArrayList<String>>();
			ArrayList<String> rowData = new ArrayList<String>();
			
			pmdb.DBConnectionStart();
			
			String SQLquery, labelname = null;
	    	String dbDataIterator = "testNull";
	    	ResultSet rs;
	    	
	    	
	    	sheetName = "Query";
	    		
				dbDataIterator = "testnull";
				SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 2, 1);
				labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 2, 2);
				
				String[] columnName = labelname.split(",");
				
				SQLquery = SQLquery.replace("@data", "'"+managerCode+"'");
				if(programCode.contains(",")) {
					String[] data = programCode.split(",");
					programCode = "in ('"+data[0]+"','"+data[1]+"')";
				}else
				{
					programCode = "= '"+programCode+"'";
				}
					
				SQLquery = SQLquery.replace("@programcode", programCode);
				
				rs= DBManager.executeSelectQuery(SQLquery);
		   
		    		while(rs.next()) {
		    			
		    				for (String iterator : columnName) {
		    					dbDataIterator = rs.getString(iterator);
		    					if(rs.wasNull() || dbDataIterator.isEmpty()) {
			    					dbDataIterator = "isEmpty";
		    					}
		    					rowData.add(dbDataIterator);
		    					
							}
		    				StrategiesMapFromDB.put(rowData.get(2), rowData);
		    				rowData.clear();
		    				
		    		 }
		    		
		    		//to handle Zero records from DB 
		    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
		    			
		    			switch (programCode) {
						case "15":
							rowData.add("No SMA Single-Access strategy associated");
							StrategiesMapFromDB.put("No FOA Code", rowData);
							break;
						case "12":
							rowData.add("No PMP Strategy associated");
							StrategiesMapFromDB.put("No FOA Code", rowData);
							break;
						case "36":
							rowData.add("No SMA Single - SWP/AAP Strategy associated");
							StrategiesMapFromDB.put("No FOA Code", rowData);
							break;
						case "13,39":
							rowData.add("No SMA Dual Strategy associated");
							StrategiesMapFromDB.put("No FOA Code", rowData);
							break;

						default:
							break;
						}
		    			
		    			
		    		}
		    		
		    		
		    		//exlObj.closeWorkBook();
					pmdb.DBConnectionClose();
					
					return sortHashMapBasedOnFOACode(StrategiesMapFromDB);
				
				
			}
		
		private HashMap<String, ArrayList<String>> sortHashMapBasedOnFOACode(HashMap<String, ArrayList<String>> accessStrategiesMap) {
			
			Set<Entry<String, ArrayList<String>>> customBenchmarkEntrySet = accessStrategiesMap.entrySet();
			List<Entry<String, ArrayList<String>>> entryList = new ArrayList<Entry<String, ArrayList<String>>>(customBenchmarkEntrySet);

			//sort based on benchmark names first to handle Equal Percentage scenario
			Collections.sort(entryList, (o1, o2) -> o1.getKey().compareTo(o2.getKey()));
			

			// Using LinkedHashMap to keep entries in sorted order
			LinkedHashMap<String, ArrayList<String>> sortedHashMap = new LinkedHashMap<String, ArrayList<String>>();
			for (Entry<String, ArrayList<String>> entry : entryList) {
				sortedHashMap.put(entry.getKey(), entry.getValue());
			}
			/*
			  for (String countryKey : sortedHashMap.keySet()) {
			  System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
			  
			  }
			 */
			return sortedHashMap;
		}
			
}
