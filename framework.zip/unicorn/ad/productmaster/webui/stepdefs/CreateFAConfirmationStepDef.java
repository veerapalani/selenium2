package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateFAConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreateFAConfirmationStepDef {
	WebElement myElement, myElement2;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateFAConfirmationPage"));
	CreateFAConfirmationPage createobj = new CreateFAConfirmationPage("AD_PM_CreateFAConfirmationPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	XSSFSheet sheet;
	int rowIndex;
	String sheetName;
	String faId = "";
	String label, attributeValue, uiValue, dbValue = null;
	String faCode;
	String testmucNHLogFilePath, testmucDHLogFilePath = "";
	String kafkaPath = "D://kafka_2.13-2.4.0//bin//windows";
	Process p1 = null;
	Process p2 = null;
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateFA.xlsx";

	@Then("^User should be able to see the below fields on Create New FA Confirmation page$")
	public void user_should_be_able_to_see_the_below_fields_on_create_new_fa_confirmation_page(List<String> entity)
			throws Throwable {
		action.fluentWaitWebElement("Confirmation");
		for (int i = 0; i < entity.size(); i++) {
			// createobj.waitForWebElement("//*[text()='" + entity.get(i) + "']");
			createobj.verifyElementsonconfirmationpage(
					createobj.findElementByDynamicXpath("//*[contains(text(),'" + entity.get(i) + "')]"));
		}
		Reporter.addScreenCapture();
	}

	@And("^User clicks on the (.+) attributes on Create New FA Confirmation Page$")
	public void user_clicks_on_the_attributes_on_create_new_fa_confirmation_page(String key) throws Throwable {
		Reporter.addCompleteScreenCapture();
		createobj.clickon2buttons(key);
	}

	@And("^User should be able to see the FA Name$")
	public void user_should_be_able_to_see_the_fa_name() throws Throwable {
		action.highligthElement(action.getElement("FAName"));
		action.isDisplayed(action.getElement("FAName"));
	}

	@And("^Notification Hub Process is started for Create$")
	public void notification_hub_process_is_started_for_create() throws IOException {
		String filename = "CreateFA";
		testmucNHLogFilePath = System.getProperty("user.dir") + "/temp/topic-NotiHub" + filename + ".log";

		FileManager.getFileManagerObj().deleteFile(testmucNHLogFilePath);

		String command = "";
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();

		if (environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC";
		}
		if (environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.QA.OUT.WMAP.TOPIC";
		}
		if (environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.UAT.OUT.WMAP.TOPIC";
		}

		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier = "ProductMaster";
		command = command + " | find /i \"" + identifier + "\" >>" + testmucNHLogFilePath;
		// command = command + " | find /i \"" + identifier + "\"";

		Reporter.addStepLog("<b>Kafka Command: </b>" + command);

		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p1 = pb.start();
	}

	@And("^Data Hub Process is started for Create FA$")
	public void data_hub_process_is_started_for_create_fa() throws IOException {
		String filename = "CreateFA";
		testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-DataHub" + filename + ".log";

		FileManager.getFileManagerObj().deleteFile(testmucDHLogFilePath);
		String command = "";

		String environment = SSOLoginPage.UIEnvironment;
		if (environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC";
		}
		if (environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.QA.OUT.WMAP.TOPIC";
		}
		if (environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.UAT.OUT.WMAP.TOPIC";
		}

		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier = "ProductMaster";

		command = command + " | find /i \"" + identifier + "\" >>" + testmucDHLogFilePath;

		Reporter.addStepLog("<b>Kafka Command: </b>" + command);

		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p2 = pb.start();
	}

	@And("^a notification is sent to Notification Hub after Create FA$")
	public void a_notification_is_sent_to_notification_hub_after_create_fa()
			throws IOException, InterruptedException, SQLException {
		Thread.sleep(10000);
		String line;
		faCode = createobj.getFACodeFromConfirmationPage();
		String faID = getFAIDBasedOnFOACodefromDB(faCode);

		String identifier = "|| Id: @faID || Code: @faCode || FinancialAdvisor Updated!";
		identifier = identifier.replace("@faCode", faCode);
		identifier = identifier.replace("@faID", faID);
		System.out.println(identifier);
		FileReader fr = new FileReader(testmucNHLogFilePath);
		BufferedReader br = new BufferedReader(fr);

		while ((line = br.readLine()) != null) {

			if (line.contains(identifier)) {
				p1.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}

		}

		p1.destroyForcibly();
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucNHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Identifier: </b>" + identifier);

		if (line.contains(identifier)) {
			Reporter.addStepLog("<p style = 'color:green'>Identifier is Matched in Notification</p>");
			Assert.assertTrue(line.contains(identifier));
		}

		br.close();
		fr.close();
	}

	private String getFAIDBasedOnFOACodefromDB(String data) throws SQLException {

		pmdb.DBConnectionStart();

		String SQLquery, labelname = null;
		String dbDataIterator = "testNull";
		ResultSet rs;

		dbDataIterator = "testnull";
		SQLquery = "select fa_id from financial_advisor where fa_code = @data";
		labelname = "fa_id";

		SQLquery = SQLquery.replace("@data", "'" + data + "'");
		rs = DBManager.executeSelectQuery(SQLquery);

		while (rs.next()) {

			dbDataIterator = rs.getString(labelname);
			if (rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}

		}
		// to handle Zero records from DB
		if (dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}

		// exlObj.closeWorkBook();
		pmdb.DBConnectionClose();

		return dbDataIterator;
	}

	@And("^a Payload is sent to Data Hub after Create FA$")
	public void a_payload_is_sent_to_data_hub_after_create_fa() throws IOException, InterruptedException {
		Thread.sleep(10000);

		faCode = createobj.getFACodeFromConfirmationPage();

		FileReader fr = new FileReader(testmucDHLogFilePath);
		BufferedReader br = new BufferedReader(fr);

		String line;

		while ((line = br.readLine()) != null) {

			if (line.contains(faCode)) {
				p2.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}

		p2.destroyForcibly();
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Identifier: </b>" + faCode);

		if (line.contains(faCode)) {
			Reporter.addStepLog("<p style = 'color:green'>Identifier is Matched in Notification</p>");
			Assert.assertTrue(line.contains(faCode));
		}

		br.close();
		fr.close();
	}

	@And("^User clicks on the done button on Create New FA Confirmation Page$")
	public void user_clicks_on_the_done_button_on_create_new_fa_confirmation_page() {
		createobj.clickonDonebutton();
		Reporter.addScreenCapture();
	}

	@And("^User stores the FAID in update sheet with (.+)$")
	public void user_stores_the_faid_in_update_sheet(String valid_data) throws IOException {
		faId = createobj.getFACodeFromConfirmationPage();
		System.out.println(faId);
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
		if (valid_data.contains("Valid")) {
			sheetName = "Valid";
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, valid_data);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 1, faId);
		}
	}

	@And("^with FA ID from UI store the data related to FA from DB in Excel for (.+) in Create FA Flow$")
	public void with_fa_id_from_ui_store_the_data_related_to_fa_from_db_in_excel_for_in_create_fa_flow(
			String valid_data) throws IOException, SQLException {
		if (valid_data.contains("DbTest"))
			sheetName = "DbTest";
		String facode = createobj.getFACodeFromConfirmationPage();
		pmdb.DBConnectionStart();
		System.out.println(facode);
		ResultSet rs;
		rs = DBManager.executeSelectQuery("select fa_id from financial_advisor where fa_code='" + facode + "'");
		while (rs.next()) {
			faId = rs.getString(1);
			System.out.println(faId);
		}
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, valid_data);
		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 45, faId);
		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex + 1, 45, faId);
		int createDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex + 1;
		getDataFromDBandStoreInExcel(faId, dBDataRowIndex);
	}

	private void getDataFromDBandStoreInExcel(String faID, int dBDataRowIndex) throws IOException, SQLException {
		pmdb.DBConnectionStart();
		String SQLquery, labelname = null;
		String dbDataIterator = "testNull";
		ResultSet rs;
		sheetName = "SQLQuery";
		int cellnum = 1;
		String label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
		// (String) exlObj.getCellData(sheet, cellnum, 0).toString();
		ArrayList<String> tempData = new ArrayList<String>();
		if (label == "")
			label = "isEmpty";
		while (label != "isEmpty") {
			if (label.contains("ignore")) {
				cellnum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
				// (String) exlObj.getCellData(sheet, cellnum, 0);
				if (label == "")
					label = "isEmpty";
			} else {
				dbDataIterator = "testnull";
				SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
				// (String) exlObj.getCellData(sheet, cellnum, 1);
				labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
				// (String) exlObj.getCellData(sheet, cellnum, 2);
				SQLquery = SQLquery.replace("@data", "'" + faID + "'");
				System.out.println(SQLquery);
				rs = DBManager.executeSelectQuery(SQLquery);
				while (rs.next()) {
					dbDataIterator = rs.getString(labelname);
					if (rs.wasNull() || dbDataIterator.isEmpty()) {
						dbDataIterator = "isEmpty";
						if (label.contains("radiobutton")) {
							dbDataIterator = "f";
						}
					}
					tempData.add(dbDataIterator);
				}
				// to handle Zero records from DB
				if (dbDataIterator.equalsIgnoreCase("testnull")) {
					dbDataIterator = "isEmpty";
				}
				// to handle multiple values for same column
				if (tempData.size() > 1) {
					Collections.sort(tempData);
					dbDataIterator = "";
					for (String G : tempData) {
						dbDataIterator = dbDataIterator + G + ",";
					}
					dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length() - 1);
				}
				tempData.clear();
				// setting data into excel for validation
				sheetName = "DbTest";
				PMPageGeneric.setCellDataSync(excelFilePath, sheetName, dBDataRowIndex, cellnum + 2, dbDataIterator);
				// exlObj.setCellData(sheet, cellnum, 3, dbDataIterator);
				sheetName = "SQLQuery";
				cellnum++;
				label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
				if (label == "")
					label = "isEmpty";
			}
		}
		// exlObj.closeWorkBook();
		pmdb.DBConnectionClose();
	}

}
