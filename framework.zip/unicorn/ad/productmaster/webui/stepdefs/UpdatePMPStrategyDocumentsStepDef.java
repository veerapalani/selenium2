package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.junit.Assert;

import cucumber.api.java.en.And;
import qa.unicorn.ad.productmaster.webui.pages.UpdatePMPStrategyDocumentsPage;

public class UpdatePMPStrategyDocumentsStepDef {

	UpdatePMPStrategyDocumentsPage documentsPage = new UpdatePMPStrategyDocumentsPage("AD_PM_UpdatePMPStrategyDocumentsPage");
	
	@And("^User is in Documents Page in Update PMP Strategy Flow$")
    public void user_is_in_documents_page_in_update_pmp_strategy_flow() {
        Assert.assertTrue(documentsPage.isUserOnDocumentsPage());
    }

	@And("^User clicks on Next in Documents Page in Update PMP Strategy Flow$")
    public void user_clicks_on_next_in_documents_page_in_update_pmp_strategy_flow() {
        documentsPage.clickOnNext();
    }
}
