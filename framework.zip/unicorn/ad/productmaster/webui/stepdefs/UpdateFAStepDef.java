package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.springframework.util.ObjectUtils;

import com.hp.lft.sdk.internal.common.MessageFieldNames.Report;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateFinancialAdvisorPage;
import qa.unicorn.ad.productmaster.webui.pages.CreatenewFAPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAPage;

public class UpdateFAStepDef {
	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	UpdateFAPage updateFAPage = new UpdateFAPage("AD_PM_UI_UpdateFAPage");
	CreatenewFAPage createobj1 = new CreatenewFAPage("AD_PM_CreateEnterFAPage");
	CreateFinancialAdvisorPage createobj = new CreateFinancialAdvisorPage("AD_PM_CreateFAPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFA.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError;
	Action action;
	String dateAll, grayOutAll, inputAll, dropDownAll, radioButton, viewPageAllElements, reviewPageAllElements;
	WebElement myElement2;
	String faCode = null;
	Collection<Object> dbValues;
	HashMap<String, Object> row = new HashMap<String, Object>();
	List<String> uIElements = new ArrayList<String>();
	List<String> uIElementsApproval = new ArrayList<String>();
	List<String> uIElementsReview = new ArrayList<String>();

	@When("^User enter valid (.+) in global search box$")
	public void user_enter_valid_in_global_search_box(String mandatoryDetails) throws Throwable {
		String FAIDorFAName = "";
		if(mandatoryDetails.contains("Valid")) {
			sheetName = "Valid";
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatoryDetails);
			FAIDorFAName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
		}
		if(mandatoryDetails.contains("Test")) {
			sheetName = "Test";
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatoryDetails);
			FAIDorFAName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 2);
		}
		if(FAIDorFAName != "") {
			landingPage.enterSearchToken(FAIDorFAName);
			landingPage.clickOnSearchIcon();
			//updateFAPage.searchFACode(FAIDorFAName);
		}
	}

	@When("^user clicks on \"([^\"]*)\" on landing page$")
	public void user_clicks_on_something_on_landing_page(String strArg1) throws Throwable {
		updateFAPage.clickOnSeeAllResults();
	}

	@Then("^user is able to see search results in \"([^\"]*)\" tab under FA accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_fa_accordion(String strArg1)
			throws Throwable {
		updateFAPage.verifyTheSearchedResultInAllTab();
	}

	@Then("^user is able to see FAs in FA tab$")
	public void user_is_able_to_see_fas_in_fa_tab() throws Throwable {
		updateFAPage.verifyFATab();
	}

	@When("^user clicks on \"([^\"]*)\" tab on landing page$")
	public void user_clicks_on_something_tab_on_landing_page(String strArg1) throws Throwable {
		updateFAPage.clickOnFAsTab();
	}

	@When("^user clicks hover on ellipsis icon$")
	public void user_clicks_hover_on_ellipsis_icon() throws Throwable {
		updateFAPage.mouseHoveOnSearchedRecordsOnGrid();
	}

	@Then("^user is able to see \"([^\"]*)\" options$")
	public void user_is_able_to_see_something_options(String strArg1) throws Throwable {
		updateFAPage.verifyOnViewDetailsLink();
	}

	@And("^clicks on \"([^\"]*)\" link$")
	public void clicks_on_something_link(String strArg1) throws Throwable {
		updateFAPage.clickOnViewDetailsLink();
	}

	@And("^User should able to get (.+) FA Name from Confirmation page$")
	public void user_should_able_to_get_fa_name_from_confirmation_page(String mandatorydetails) throws Throwable {
		if(mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		updateFAPage.getFANameFromFAConfirmationPage();
		exlObj.setCellData(sheet, rowIndex, 1, UpdateFAPage.value);
		exlObj.closeWorkBook();
		Reporter.addScreenCapture();
	}

	@And("^User enters the details required on the FA Update Review Page$")
	public void user_enters_the_details_required_on_the_fa_update_review_page() throws Throwable {
		updateFAPage.enterSubmitterPosition();
	}

	@And("^User Clicks on the Submit button in the FA Update Review page$")
	public void user_clicks_on_the_submit_button_in_the_fa_update_review_page() throws Throwable {
		updateFAPage.clickonSubmitButonInReviewpage();
	}

	@Then("^User should be able to see the below fields on Update FA Confirmation page$")
	public void user_should_be_able_to_see_the_below_fields_on_update_fa_confirmation_page(List<String> entity)
			throws Throwable {
		for(int i = 0; i < entity.size(); i++) {
			updateFAPage.verifyElementsOnConfirmationPage(
					updateFAPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to get the all data from Conversion Sql query from database$")
	public void user_able_to_get_the_all_data_from_conversion_sql_query_from_database() throws Throwable {
		// Read the data from DB as per sql query
		Assert.assertTrue(landingPage1.isUserOnLandingPage());
		pmdb.DBConnectionStart();
		sheet = exlObj.getSheet("Sql");
		ResultSet rs;
		String SQLquery = (String)exlObj.getCellData(sheet, 0, 0);
		System.out.println("Sql Query--->" + SQLquery);
		rs = DBManager.executeSelectQuery(SQLquery);
		ResultSetMetaData md = rs.getMetaData();
		int columns = md.getColumnCount();
		System.out.println("Total col count----" + columns);
		while(rs.next()) {
			for(int i = 1; i <= columns; i++) {
				row.put(md.getColumnName(i), rs.getObject(i));
				if(md.getColumnName(i).trim().equalsIgnoreCase("fa_code")) {
					faCode = (String)rs.getObject(i);
					System.out.println("FA Code from DB " + faCode.trim());
					Assert.assertEquals(faCode, rs.getObject(i));
				}
				if(md.getColumnName(i).equalsIgnoreCase("exceptional_approval") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("false")) {
					row.put(md.getColumnName(i), "No");
				}
				else if(md.getColumnName(i).equalsIgnoreCase("exceptional_approval") && rs.getObject(i) != null
						&& rs.getObject(i).toString().equalsIgnoreCase("true")) {
					row.put(md.getColumnName(i), "Yes");
				}
				if(ObjectUtils.isEmpty(rs.getObject(i))) {
					row.put(md.getColumnName(i), "—");
				}
			}
		}
		row.entrySet().stream().forEach(S -> System.out.println(S));
		exlObj.closeWorkBook();
		pmdb.DBConnectionClose();
	}

	@And("^User should able to get the Conversion attribute on view details page for FA Update$")
	public void user_should_able_to_get_the_conversion_attribute_on_view_details_page_for_fa_update(List<String> entity)
			throws Throwable {
		// Get the UI date from View Details page
		for(int i = 0; i < entity.size(); i++) {
			Action.pause(1000);
			WebElement check = updateFAPage.findElementByDynamicXpath(
					"(//label[text()='" + entity.get(i) + "']//parent::div//following::div)[1]");
			viewPageAllElements = check.getText().trim();
			uIElements.add(viewPageAllElements);
		}
	}

	@And("^User should able validate the Conversion attribute on view details page for FA Update$")
	public void user_should_able_to_get_the_conversion_attribute_on_view_details_page_for_fa_update() throws Throwable {
		System.out.println("UI elements-----" + uIElements);
		// comparing the DB and UI elements
		Action.pause(2000);
		String ele = null;
		for(int i = 0; i < uIElements.size(); i++) {
			ele = uIElements.get(i);
			Iterator<Entry<String, Object>> itr = row.entrySet().iterator();
			while(itr.hasNext()) {
				Map.Entry<String, Object> entry = itr.next();
				if(entry.getValue() != null)
					if(ele.equalsIgnoreCase(entry.getValue().toString())) {
						dbValues = row.values();
						System.out.println("UI elements on view= " + ele + " are matched with DB elements " + entry);
						Assert.assertTrue("View FA page UI and DB values are not match on View Details FA",
								uIElements.containsAll(dbValues));
						Reporter.addScreenCapture();
					}
			}
		}
		System.out.println("All DB elements----" + dbValues);
	}

	@When("^User enter the FA code in global search$")
	public void user_enter_the_fa_code_in_global_search() throws Throwable {
		Action.pause(2000);
		updateFAPage.searchAndEnterFACode(faCode);
	}

	@And("^User should able validate the Conversion attribute Input text on update details page for FA Update$")
	public void user_should_able_validate_the_conversion_attribute_input_text_on_update_details_page_for_fa_update(
			List<String> attributeValuePair) throws Throwable {
		// Get the input text elements on UI
		for(int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateFAPage
					.findElementByDynamicXpath("//brml-input[@label='" + attributeValuePair.get(i) + "']");
			inputAll = check.getAttribute("value").trim();
			uIElements.add(inputAll);
		}
	}

	@And("^User should able to validate the Conversion attribute drop down on update details page for FA Update$")
	public void user_should_able_to_validate_the_conversion_attribute_drop_down_on_update_details_page_for_fa_update(
			List<String> attributeValuePair) throws Throwable {
		// Get the drop down elements on UI
		for(int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateFAPage
					.findElementByDynamicXpath("//brml-select[@label='" + attributeValuePair.get(i) + "']");
			grayOutAll = check.getAttribute("value").trim();
			uIElements.add(grayOutAll);
		}
	}

	@And("^User should able to validate the Conversion attribute date on update details page for FA Update$")
	public void user_should_able_to_validate_the_conversion_attribute_date_on_update_details_page_for_fa_update(
			List<String> attributeValuePair) throws Throwable {
		for(int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateFAPage
					.findElementByDynamicXpath("//brml-calendar-picker[@label='" + attributeValuePair.get(i) + "']");
			dateAll = check.getAttribute("date").trim();
			uIElements.add(dateAll);
		}
	}

	@And("^User should able validate the Conversion data on update details page for FA Update$")
	public void user_should_able_validate_the_conversion_data_on_update_details_page_for_fa_update() throws Throwable {
		// comparing the DB and UI elements
		Action.pause(1000);
		System.out.println("All UI elements----" + uIElements);
		String ele = null;
		for(int i = 0; i < uIElements.size(); i++) {
			ele = uIElements.get(i);
			Iterator<Entry<String, Object>> itr = row.entrySet().iterator();
			while(itr.hasNext()) {
				Map.Entry<String, Object> entry = itr.next();
				if(entry.getValue() != null)
					if(ele.equalsIgnoreCase(entry.getValue().toString())) {
						dbValues = row.values();
						Assert.assertTrue("Enter FA details page UI and DB values are not match on Update FA page",
								dbValues.containsAll(uIElements));
						System.out.println("UI elements= " + ele + " are matched with DB elements " + entry);
					}
			}
		}
		System.out.println("All DB elements----" + dbValues);
	}

	@And("^User should able to validate the Conversion attribute drop down on Approval update details page for FA Update$")
	public void user_should_able_to_validate_the_conversion_attribute_drop_down_on_approval_update_details_page_for_fa_update(
			List<String> attributeValuePair) throws Throwable {
		// Get the drop down elements on UI
		for(int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			dropDownAll = updateFAPage
					.findElementByDynamicXpath("//brml-select[@label='" + attributeValuePair.get(i) + "']")
					.getAttribute("value").trim();
			uIElementsApproval.add(dropDownAll);
		}
	}

	@And("^User should able to validate the Conversion attribute radio button on Approval update details page for FA Update$")
	public void user_should_able_to_validate_the_conversion_attribute_radio_button_on_approval_update_details_page_for_fa_update(
			List<String> attributeValuePair) throws Throwable {
		// Get the radio button elements on UI
		for(int i = 0; i < attributeValuePair.size(); i++) {
			Action.pause(1000);
			WebElement check = updateFAPage
					.findElementByDynamicXpath("//brml-radio[@label='" + attributeValuePair.get(i) + "']");
			radioButton = check.getAttribute("value").trim();
			if(radioButton.equals("false")) {
				radioButton = "No";
			}
			else {
				radioButton = "Yes";
			}
			uIElementsApproval.add(radioButton);
		}
	}

	@And("^User should able validate the Conversion data on Approval update details page for FA Update$")
	public void user_should_able_validate_the_conversion_data_on_approval_update_details_page_for_fa_update()
			throws Throwable {
		// comparing the DB and UI elements
		Action.pause(1000);
		System.out.println("All UI elements----" + uIElementsApproval);
		String ele = null;
		for(int i = 0; i < uIElementsApproval.size(); i++) {
			ele = uIElementsApproval.get(i);
			Iterator<Entry<String, Object>> itr = row.entrySet().iterator();
			while(itr.hasNext()) {
				Map.Entry<String, Object> entry = itr.next();
				if(entry.getValue() != null)
					if(ele.equalsIgnoreCase(entry.getValue().toString())) {
						dbValues = row.values();
						Assert.assertTrue("Approval page UI and DB values are not match on Update FA Approval page",
								dbValues.containsAll(uIElementsApproval));
						System.out.println("UI elements Approval = " + ele + " are matched with DB elements " + entry);
					}
			}
		}
		System.out.println("All DB elements----" + dbValues);
	}

	@And("^User should able to get the review page attributes for Conversion data of FA Update$")
	public void user_should_able_to_get_the_review_page_attributes_for_conversion_data_of_fa_update(List<String> entity)
			throws Throwable {
		// Get the UI date from View Details page
		for(int i = 0; i < entity.size(); i++) {
			Action.pause(1000);
			WebElement check = updateFAPage.findElementByDynamicXpath(
					"(//label[text()='" + entity.get(i) + "']//parent::small//following::div)[1]");
			reviewPageAllElements = check.getText().trim();
			uIElementsReview.add(reviewPageAllElements);
		}
	}

	@Then("^User should able validate the Conversion attribute on Review details page for FA Update$")
	public void user_should_able_validate_the_conversion_attribute_on_review_details_page_for_fa_update()
			throws Throwable {
		System.out.println("UI elements-----" + uIElementsReview);
		// comparing the DB and UI elements
		Action.pause(2000);
		String ele = null;
		for(int i = 0; i < uIElementsReview.size(); i++) {
			ele = uIElementsReview.get(i);
			Iterator<Entry<String, Object>> itr = row.entrySet().iterator();
			while(itr.hasNext()) {
				Map.Entry<String, Object> entry = itr.next();
				if(entry.getValue() != null)
					if(ele.equalsIgnoreCase(entry.getValue().toString())) {
						dbValues = row.values();
						System.out.println(
								"Review page UI elements on view= " + ele + " are matched with DB elements " + entry);
						Assert.assertTrue("The UI and DB values are not match on View Details FA",
								uIElementsReview.containsAll(dbValues));
						Reporter.addScreenCapture();
					}
			}
		}
		System.out.println("All DB elements----" + dbValues);
	}

	@When("^User search for FA code in DB with different (.+) and (.+)$")
	public void user_search_for_fa_code_in_db_with_different_status(String faStatus, String mandatorydetails)
			throws Throwable {
		faCode = updateFAPage.getFaCodeFromDbWithStatus(faStatus);
		if(faCode.equalsIgnoreCase("isEmpty")) {
			Reporter.addStepLog("There is no FA id associated with the " + faStatus + " in DB");
		}
		sheetName = "Valid";
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 1, faCode);
		System.out.println("facode: " + faCode);
	}
}
