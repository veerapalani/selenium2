package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateFATeamConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateFATeamDocumentPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateFATeamPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateFATeamReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateFinancialAdvisorPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateEntityUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessUIPage;

public class CreateFATeamStepDef {

	private static final Object[] arguments = null;
	PMPageGeneric FAEntity = new PMPageGeneric("AD_PM_UI_FATeamPage");
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");
	CreateFATeamPage createFATeamPage = new CreateFATeamPage("AD_PM_UI_FATeamWizardPage");
	CreateFinancialAdvisorPage fateamAdvisorPage = new CreateFinancialAdvisorPage("AD_PM_CreateFAPage");
	CreateFATeamPage createFATeamPage1 = new CreateFATeamPage("AD_PM_UI_FATeamPage");
	CreateFATeamDocumentPage createFATeamDocumentPage = new CreateFATeamDocumentPage("AD_PM_UI_FATeamDocumentPage");
	CreateFATeamReviewPage createFATeamReviewPage = new CreateFATeamReviewPage("AD_PM_UI_FATeamReviewPage");
	CreateFATeamConfirmationPage createFATeamConfirmationPage = new CreateFATeamConfirmationPage(
			"AD_PM_FATeamConfirmationPage");
	UpdateEntityUIPage updateEntityPage = new UpdateEntityUIPage();
	UpdateSMASingleAccessUIPage updateSMASinglePage = new UpdateSMASingleAccessUIPage();
	String expectedColorCode, searchValue, myValue;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/all";
	String sheetName = "";
	int rowIndex, cellIndex;
	WebDriver driver;
	List<WebElement> myElements;
	XSSFSheet sheet;
	String excelPathForReference = "./src/test/resources/ad/productmaster/api/excel/ReferenceDetails.xlsx";
	String excelFilePath1 = "./src/test/resources/ad/productmaster/webui/excel/CreateFA.xlsx";
	ExcelUtils exlObj1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath1);
	ExcelUtils myReferenceFile = new ExcelUtils(ExcelOperation.LOAD, excelPathForReference);
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateFATeam.xlsx";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	WebElement myElement, myElement2;
	List<String> searchTokens;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_LandingPage"));
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();

	@When("^User clicks on Create New drop down on Product Master landing page$")
	public void user_clicks_on_create_new_drop_down_on_product_master_landing_page() throws Throwable {
		landingPage1.clickOncreatenewdropdownicon();
	}

	@Then("^On clicking on Create New Dropdown The \"([^\"]*)\" on the FA Entity page should contain all the following options$")
	public void on_clicking_on_create_new_dropdown_the_something_on_the_fa_entity_page_should_contain_all_the_following_options(
			String key, List<String> items) throws Throwable {
		for (int i = 0; i < items.size(); i++) {
			Reporter.addStepLog("verifying for " + items.get(i));
			listOfElements = FAEntity.getElementsFromShadowRoot(key);
			Reporter.addStepLog(listOfElements.get(0).getText());
			FAEntity.verifyTextInListOfElements(items.get(i), listOfElements);
		}
	}

	@When("^ User chooses to click on the dropdown list which creates a new entity in UI$")
	public void user_chooses_to_click_on_the_dropdown_list_which_creates_a_new_entity_in_ui() throws Throwable {
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector(\"brml-select[id='create-strategy-dropdown']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
	}

	@Then("^afterwhich the user proceeds with the flow by clicking on the FA Team radio button$")
	public void afterwhich_the_user_proceeds_with_the_flow_by_clicking_on_the_fa_team_radio_button() throws Throwable {
		Thread.sleep(2000);
		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector(\"brml-radio-option[label='Financial Advisor Team']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
	}

	@When("^User search with the (.+) taken from (.+) in the Search TextBox on landing page with FA team attribute$")
	public void user_search_with_the_taken_from_in_the_search_textbox_on_landing_page_with_fa_team_attribute(
			String entity, String searchcode) throws Throwable {
		Thread.sleep(5000);
		sheetName = entity;
		sheet = exlObj1.getSheet(sheetName);
		rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "Valid_Data");
		cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, searchcode);

		myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
		searchcode = myValue;
		System.out.println(myValue);

		Boolean compareBoolean = action.isPresent("js",
				"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");

		if (compareBoolean) {

			Thread.sleep(5000);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}

		Thread.sleep(5000);

		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		Thread.sleep(5000);
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;

		while (i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);
	}

	@Then("^user clicks at the fateam name which comes up$")
	public void user_clicks_at_the_fateam_name_which_comes_up() throws InterruptedException {
		// Thread.sleep(5000);
		myElements = updateSMASinglePage
				.findElementsByDynamicXpath("//label[contains(text(),'FA TEAM')]//parent::div//div[1]");
		System.out.println("//label[contains(text(),'" + myValue + "')]//parent::div//div[1]");
		// myElements =
		// updateSMASinglePage.findElementsByDynamicXpath("//label[contains(text(),'" +
		// myValue + "')]//parent::div//div[1]");

		String status = "FAIL";

		for (WebElement E : myElements) {
			System.out.println(myValue + E.getText());
			if (E.getText().toUpperCase().contains(myValue.toUpperCase())) {
				status = "PASS";
				Thread.sleep(4000);
				action.scrollToElement(E);
				action.highligthElement(E);
				Thread.sleep(5000);
				E.click();
				Reporter.addStepLog("clicking on the matching suggestion");

				break;
			}

		}

		if (status.contentEquals("FAIL")) {
			myElement.sendKeys(Keys.ENTER);

			myElements = updateSMASinglePage
					.findElementsByDynamicXpath("//label[contains(text(),'FA TEAM')]//parent::div//div[2]");

			for (WebElement E : myElements) {
				if (E.getText().toUpperCase().contains(myValue.toUpperCase())) {
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();

					action.waitForPageLoad();

					Reporter.addStepLog("clicking on the matching suggestion");
					// Thread.sleep(4000);

					break;
				}

			}
		}
	}

	@And("^the user chooses FA from the choices provided at the dropdown$")
	public void the_user_chooses_fa_from_the_choices_provided_at_the_dropdown() throws Throwable {

		Thread.sleep(2000);
		myElement = (WebElement) action.executeJavaScript(
				" return document.querySelector(\"#create-strategy-dropdown\").shadowRoot.querySelector(\"wf-tooltip > div > div > wf-dropdown > div > div.os-padding > div > div > ul > li:nth-child(5)\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);

	}

	@And("^user goes into the accordion and highlight the number of active Fa teams$")
	public void user_goes_into_the_accordion_and_highlight_the_number_of_active_fa_teams() throws Throwable {

		landingPage1.fateamacount();

	}

	@And("^aptly clicks on the create button to further proceed with the flow$")
	public void aptly_clicks_on_the_create_button_to_further_proceed_with_the_flow() throws Throwable {

		Thread.sleep(2000);
		myElement = (WebElement) action.executeJavaScript(
				" return document.querySelector(\"#nonDetachedModal > footer > div > div.col-2 > brml-button > span\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
	}

	@And("^the user provides the inputs to the fields that are text boxes$")
	public void the_user_provides_the_inputs_to_the_fields_that_are_text_boxes(List<List<String>> attribute)
			throws Throwable {

		sheetName = "Valid";
		sheet = exlObj1.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "Create_flow");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			System.out.println(attribute.get(i).get(0) + " value " + myValue);
			action.sendKeys(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@Then("^by user discretion clicks at the cancel button$")
	public void by_user_discretion_clicks_at_the_cancel_button() throws Throwable {
		// document.querySelector("brml-button")
		Thread.sleep(2000);
		myElement = (WebElement) action.executeJavaScript(" return document.querySelector(\"brml-button\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
	}

	@And("^the user provides additional information and HO User discretionary comments$")
	public void the_user_provides_additional_information_and_ho_user_discretionary_comments(
			List<List<String>> attribute) throws Throwable {
		sheetName = "CreateFATeam";
		sheet = exlObj1.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "data1");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-textarea[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('textarea')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			// myElement.sendKeys(Keys.ENTER);
			Thread.sleep(2000);
		}
	}

	@And("^user chooses to select the manadatory attributes which are as dropdown list$")
	public void user_chooses_to_select_the_manadatory_attributes_which_are_as_dropdown_list() throws Throwable {
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript(" return document.querySelector(\"brml-multiselect-dropdown\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);
		myElement = (WebElement) updateEntityPage.executeJavaScript(
				"return document.querySelector(\"#faId\").shadowRoot.querySelector(\"wf-input\").shadowRoot.querySelector(\"div > wf-icon\")");
		myElement.click();
		myElement = (WebElement) updateEntityPage.executeJavaScript(
				"return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[0].shadowRoot.querySelector(\"button\")");
		myElement.click();
		Thread.sleep(5000);
		myElement = (WebElement) updateEntityPage.executeJavaScript(
				"return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[0].shadowRoot.querySelector(\"button\")");
		myElement.click();
		myElement = (WebElement) updateEntityPage.executeJavaScript(
				"return document.querySelector(\"#faId\").shadowRoot.querySelector(\"wf-input\").shadowRoot.querySelector(\"input\")");
		myElement.click();
		myElement.sendKeys("a");
		Thread.sleep(5000);
		myElement = (WebElement) updateEntityPage.executeJavaScript(
				"return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[1].shadowRoot.querySelector(\"button\")");
		myElement.click();
		Thread.sleep(1000);
		myElement = (WebElement) updateEntityPage.executeJavaScript(
				"return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[2].shadowRoot.querySelector(\"button\")");
		myElement.click();
		Thread.sleep(1000);
		myElement = (WebElement) updateEntityPage.executeJavaScript(
				"return document.querySelector(\"#faId\").shadowRoot.querySelectorAll(\"div.multiselect-dropdown-option > wf-checkbox\")[3].shadowRoot.querySelector(\"button\")");
		myElement.click();
		Thread.sleep(1000);
		myElement = (WebElement) updateEntityPage.executeJavaScript(
				"return document.querySelector(\"#faId\").shadowRoot.querySelector(\"div.multiselect-dropdown-footer > slot > div > wf-button:nth-child(2)\")");
		myElement.click();

	}

	@Then("^User clicks upon the three dotted button for the first strategy in the list$")
	public void user_clicks_upon_the_three_dotted_button_for_the_first_strategy_in_the_list() throws Throwable {

		Thread.sleep(2000);
		myElement = (WebElement) action.executeJavaScript(
				" return document.querySelector(\"#ag-grid-wrapper > div > div > div.ag-root-wrapper-body.ag-layout-auto-height.ag-focus-managed > div.ag-root.ag-unselectable.ag-layout-auto-height > div.ag-body-viewport.ag-layout-auto-height.ag-row-no-animation > div.ag-center-cols-clipper > div > div > div.ag-row.ag-row-no-focus.ag-row-even.ag-row-level-0.ag-row-position-absolute.ag-row-first > div:nth-child(6)\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);

	}

	@And("^user chooses from the checkboxes which FA must constituent the FA Team$")
	public void user_chooses_from_the_checkboxes_which_fa_must_constituent_the_fa_team() throws Throwable {
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript(" return document.querySelector(\"brml-multiselect-dropdown\")");
		// myElement = (WebElement) action.executeJavaScript(" return
		// document.querySelector(\"#faId\").shadowRoot.querySelector(\"div > div >
		// wf-dropdown > div > div >
		// div.multiselect-dropdown-options-wrapper.os-host-flexbox.wf-custom-scrollbar.os-host.os-theme-dark.os-host-resize-disabled.os-host-scrollbar-horizontal-hidden.os-host-transition.os-host-overflow.os-host-overflow-y
		// > div.os-padding > div > div > div > div:nth-child(4) >
		// wf-checkbox\").shadowRoot.querySelector(\"wf-tooltip > div > div >
		// button\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		myElement = (WebElement) action.executeJavaScript(
				" return document.querySelector(\"#faId\").shadowRoot.querySelector(\"div > div > wf-dropdown > div > div > div.multiselect-dropdown-options-wrapper.os-host-flexbox.wf-custom-scrollbar.os-host.os-theme-dark.os-host-resize-disabled.os-host-scrollbar-horizontal-hidden.os-host-transition.os-host-overflow.os-host-overflow-y > div.os-padding > div > div > div > div:nth-child(4) > wf-checkbox\").shadowRoot.querySelector(\"wf-tooltip > div > div > button\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Thread.sleep(2000);

	}

	@Then("^clicks on the check boxes that determine the FA which would compromise the team$")
	public void clicks_on_the_check_boxes_that_determine_the_fa_which_would_compromise_the_team() throws Throwable {

		myElement = (WebElement) action.executeJavaScript(
				" return document.querySelector(\"#faId\").shadowRoot.querySelector(\"div > div > wf-dropdown > div > div > div.multiselect-dropdown-options-wrapper.os-host-flexbox.wf-custom-scrollbar.os-host.os-theme-dark.os-host-resize-disabled.os-host-scrollbar-horizontal-hidden.os-host-transition.os-host-overflow.os-host-overflow-y > div.os-padding > div > div > div > div:nth-child(2) > wf-checkbox\").shadowRoot.querySelector(\"wf-tooltip > div > div > button\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);

	}

	@And("^the user chooses to put the desired strategy in the below ddl$")
	public void the_user_chooses_to_put_the_desired_strategy_in_the_below_ddl(List<List<String>> attribute)
			throws Throwable {
		sheetName = "CreateFATeam";
		sheet = exlObj1.getSheet(sheetName);
	//	Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "data1");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(2000);
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}

	}

	@And("^user proceeds with the flow by clicking on the next button$")
	public void user_proceeds_with_the_flow_by_clicking_on_the_next_button() throws Throwable {
		Thread.sleep(2000);
		myElement = (WebElement) action
				.executeJavaScript(" return document.querySelector(\"brml-button[type='submit']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);

	}

	@And("^user on the documents page selects from the dropdown the type for the doc$")
	public void user_on_the_documents_page_selects_from_the_dropdown_the_type_for_the_doc(List<List<String>> attribute)
			throws Throwable {

		sheetName = "CreateFATeam";
		sheet = exlObj1.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "data1");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			//Thread.sleep(2000);
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			//Thread.sleep(2000);
		}
	}

	@And("^the user clicks on the Apply button to make the changes permanent$")
	public void the_user_clicks_on_the_apply_button_to_make_the_changes_permanent() throws Throwable {
		myElement = (WebElement) action.executeJavaScript(
				" return document.querySelector(\"brml-multiselect-dropdown\").shadowRoot.querySelector(\"div > div > div > slot > div > wf-button:nth-child(2)\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@And("^gives the value for the link for the above doc$")
	public void gives_the_value_for_the_link_for_the_above_doc(List<List<String>> attribute) throws Throwable {

		sheetName = "CreateFATeam";
		sheet = exlObj1.getSheet(sheetName);
		//Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "data1");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			System.out.println(attribute.get(i).get(0) + " value " + myValue);
			action.sendKeys(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			//Thread.sleep(2000);
		}

	}

	@And("^gives the comment which supports the document$")
	public void gives_the_comment_which_supports_the_document(List<List<String>> attribute) throws Throwable {

		sheetName = "CreateFATeam";
		sheet = exlObj1.getSheet(sheetName);
		//Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, "data1");
			cellIndex = exlObj1.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj1.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-textarea[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('textarea')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			// myElement.sendKeys(Keys.ENTER);
			//Thread.sleep(2000);
		}

	}

	@When("^User clicks on FA option on Create New drop down landing pages$")
	public void user_clicks_on_fa_option_on_create_new_drop_down_landing_pages() throws Throwable {
		Reporter.addScreenCapture();
		landingPage1.clickOnFAEntity();
	}

	@Then("^User should able to see \"([^\"]*)\" on Create Financial Advisor wizard page$")
	public void user_should_able_to_see_something_on_create_financial_advisor_wizard_page(String key) throws Throwable {
		Thread.sleep(1000);
		createFATeamPage.verifyFATeamWizardPage();
	}

	@And("^User able to see \"([^\"]*)\" on Create Financial Advisor wizard page$")
	public void user_able_to_see_something_on_create_financial_advisor_wizard_page(String key) throws Throwable {
		createFATeamPage.verifyFATeamWizardPage();
	}

	@When("^User clicks on Financial Advisor Team radio button on Create Financial Advisor wizard page$")
	public void user_clicks_on_financial_advisor_team_radio_button_on_create_financial_advisor_wizard_page()
			throws Throwable {
		createFATeamPage.clickOnFATeamRadioButtonOnFATeamWizardPage();
	}

	@Then("^User should able to select the Financial Advisor Team on Create Financial Advisor wizard page$")
	public void user_should_able_to_select_the_financial_advisor_team_on_create_financial_advisor_wizard_page()
			throws Throwable {
		createFATeamPage.clickOnFATeamRadioButtonOnFATeamWizardPage();
	}

	@When("^User clicks on CREATE link on Create Financial Advisor wizard page$")
	public void user_clicks_on_create_link_on_create_financial_advisor_wizard_page() throws Throwable {
		createFATeamPage.clickOnCreateButtonOnFAWizardPage();
	}

	@Then("^User should able see \"([^\"]*)\" on Create Financial Advisor wizard page$")
	public void user_should_able_see_something_on_create_financial_advisor_wizard_page(String strArg1)
			throws Throwable {
		createFATeamPage1.verifyFATeamPage();
	}

	@And("^User able to see \"([^\"]*)\" button Financial Advisor Team Page$")
	public void user_able_to_see_something_button_financial_advisor_team_page(String strArg1) throws Throwable {
		createFATeamPage.verifyCreateButtonOnFAWizardPage();
	}

	@When("^User clicks on \"([^\"]*)\" link on Create Financial Advisor wizard page$")
	public void user_clicks_on_something_link_on_create_financial_advisor_wizard_page(String strArg1) throws Throwable {
		createFATeamPage.clickOnCancelButtonOnFATeamWizardPage();
	}

	@Then("^User should able to navigate \"([^\"]*)\" landing page$")
	public void user_should_able_to_navigate_something_landing_page(String strArg1) throws Throwable {
		Thread.sleep(1000);
		createFATeamPage1.verifyProductMasterHeaderOnlandingPage();
	}

	@When("^User clicks on \"([^\"]*)\" hyperlink on Create Financial Advisor Team page$")
	public void user_clicks_on_something_hyperlink_on_create_financial_advisor_team_page(String strArg1)
			throws Throwable {
		createFATeamPage1.clickOnProductMasterhyperlinkOnFATeamPage();
	}

	@And("^User clicks on Cancel Button on the Create FA Page$")
	public void user_clicks_on_cancel_button_on_the_create_fa_page() throws Throwable {

	}

	@When("^User clicks on \"([^\"]*)\" button on Create Financial Advisor Team page$")
	public void user_clicks_on_something_button_on_create_financial_advisor_team_page(String strArg1) throws Throwable {
		createFATeamPage1.clickOnCancelButtonOnFATeamPage();
	}

	@And("^User enters the following values in the following text fields on Create FA Team Page$")
	public void user_enters_the_following_values_in_the_following_text_fields_on_create_fa_team_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement,
					attributeValuePair.get(i).get(1) + Calendar.getInstance().getTimeInMillis());
			myElement.sendKeys(Keys.ENTER);
		}
	}

	@And("^User enters the following values in the following Email text on Create FA Team Page$")
	public void user_enters_the_following_values_in_the_following_email_text_on_create_fa_team_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement,
					attributeValuePair.get(i).get(1) + Calendar.getInstance().getTimeInMillis() + ".com");
			myElement.sendKeys(Keys.ENTER);
		}
	}

	@And("^User enters the following values in the following optional text fields on Create FA Team Page$")
	public void user_enters_the_following_values_in_the_following_optional_text_fields_on_create_fa_team_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-textarea[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('textarea')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
		}
	}

	@And("^User enters the following values in the following dropdowns on Create FA Team Page$")
	public void user_enters_the_following_values_in_the_following_dropdowns_on_create_fa_team_page(
			List<List<String>> entityValuePair) throws Throwable {
		for (int i = 0; i < entityValuePair.size(); i++) {
			Reporter.addStepLog("return document.querySelector(\"brml-multiselect-dropdown[label='"
					+ entityValuePair.get(i).get(0)
					+ "']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('wf-tooltip > div > div > div')");
			myElement = createFATeamPage1.getDynamicElementFromShadowRoot(
					"return document.querySelector(\"brml-multiselect-dropdown[label='" + entityValuePair.get(i).get(0)
							+ "']\").shadowRoot.querySelector('wf-input').shadowRoot.querySelector('wf-tooltip > div > div > div')");
			createFATeamPage1.scrollAndClickOnLink(myElement);
			Thread.sleep(20000);
			Reporter.addStepLog("return document.querySelector(\"[label='" + entityValuePair.get(i).get(0)
					+ "']\").shadowRoot.querySelector(\"li[data-value='\\\"" + entityValuePair.get(i).get(1)
					+ "\\\"']\")");
			createFATeamPage1
					.getDynamicElementFromShadowRoot("return document.querySelector(\"brml-multiselect-dropdown[label='"
							+ entityValuePair.get(i).get(0)
							+ "']\").shadowRoot.querySelector('wf-checkbox').shadowRoot.querySelector('wf-tooltip >div > div:nth-child(2) > button')")
					.click();
			createFATeamPage1.getDynamicElementFromShadowRoot(
					"return document.querySelector(\"brml-multiselect-dropdown[label='" + entityValuePair.get(i).get(0)
							+ "']\").shadowRoot.querySelector('wf-button:nth-child(2)')")
					.click();
			createFATeamPage1.UIPassedValues.put(entityValuePair.get(i).get(0), entityValuePair.get(i).get(1));
		}
	}

//	    @And("^User select the following values in the following dropdowns on Create FA Team Page$")
//	    public void user_select_the_following_values_in_the_following_dropdowns_on_create_fa_team_page(List<List<String>> entityValuePair) throws Throwable {
//	    	for(int i=0;i<entityValuePair.size();i++) {
//	    		Reporter.addStepLog("return document.querySelector(\"brml-multiselect-dropdown[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('wf-input')");
//	        	myElement = createFATeamPage1.getDynamicElementFromShadowRoot("return document.querySelector(\"brml-select[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('wf-input')");
//	        	createFATeamPage1.scrollAndClickOnLink(myElement);
//	        	Reporter.addStepLog("return document.querySelector(\"[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector(\"li[data-value='\\\""+entityValuePair.get(i).get(1)+"\\\"']\")");
//	        	createFATeamPage1.getDynamicElementFromShadowRoot("return document.querySelector(\"brml-select[label='"+entityValuePair.get(i).get(0)+"']\").shadowRoot.querySelector('wf-dropdown > div > ul >li:nth-child(2) >a')").click();
//	        	createFATeamPage1.UIPassedValues.put(entityValuePair.get(i).get(0),entityValuePair.get(i).get(1));
//	    	}  
//	    }
//	    
	@And("^User clicks on Next Button on Create New FA Team Page$")
	public void user_clicks_on_next_button_on_create_new_fa_team_page() throws Throwable {
		createFATeamPage1.clickOnNextButtonOnFATeamPage();
	}

	@Then("^User should be able to see the Documents Header on Create New FA Team page$")
	public void user_should_be_able_to_see_the_documents_header_on_create_new_fa_team_page() throws Throwable {
		Thread.sleep(2000);
		createFATeamPage1.verifyFATeamDocumentHeaderonDocumentsPage();
	}

	@And("^User clicks on the (.+) attributes on Create New FA Team Page$")
	public void user_clicks_on_the_attributes_on_create_new_fa_team_page(String below) throws Throwable {
		createFATeamPage1.clickOnElementsOnAddDocumentsPage();
	}

	@Then("^User should be able to see the below fields on Create New FA Team page$")
	public void user_should_be_able_to_see_the_below_fields_on_create_new_fa_team_page(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			createFATeamPage1.verifyElementsOnCreateFATeamPage(
					createFATeamPage1.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^user write the following attributes with following values on Add Document Link page$")
	public void user_write_the_following_attributes_with_following_values_on_add_document_link_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
		}

	}

	@And("^user write the following textarea attributes with following values on Add Document Link page$")
	public void user_write_the_following_textarea_attributes_with_following_values_on_add_document_link_page(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-textarea[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('textarea')");
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
		}
	}

	@And("^user should be able to select the following dropdown with following values on Add Document Link page$")
	public void user_should_be_able_to_select_the_following_dropdown_with_following_values_on_add_document_link_page(
			List<List<String>> entityValuePair) throws Throwable {
		for (int i = 0; i < entityValuePair.size(); i++) {
			Reporter.addStepLog("return document.querySelector(\"brml-multiselect-dropdown[label='"
					+ entityValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('wf-input')");
			myElement = createFATeamPage1
					.getDynamicElementFromShadowRoot("return document.querySelector(\"brml-select[label='"
							+ entityValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('wf-input')");
			createFATeamPage1.scrollAndClickOnLink(myElement);
			Reporter.addStepLog("return document.querySelector(\"[label='" + entityValuePair.get(i).get(0)
					+ "']\").shadowRoot.querySelector(\"li[data-value='\\\"" + entityValuePair.get(i).get(1)
					+ "\\\"']\")");
			createFATeamPage1
					.getDynamicElementFromShadowRoot(
							"return document.querySelector(\"brml-select[label='" + entityValuePair.get(i).get(0)
									+ "']\").shadowRoot.querySelector('wf-dropdown >div > ul >li:nth-child(2) >a')")
					.click();
			createFATeamPage1.UIPassedValues.put(entityValuePair.get(i).get(0), entityValuePair.get(i).get(1));
		}
	}

	@And("^user clicks on \"([^\"]*)\" on Add Document Link page$")
	public void user_clicks_on_something_on_add_document_link_page(String strArg1) throws Throwable {
		createFATeamDocumentPage.clickOnAddDocumentLinkOnFATeamDocumentPage();
		Thread.sleep(2000);
	}

	@Then("^user should be able to see the same document add in Document Link Details page$")
	public void user_should_be_able_to_see_the_same_document_add_in_document_link_details_page() throws Throwable {
		myElement = createFATeamDocumentPage.findElementByDynamicXpath("//span[text()='FA Team']/parent::div");
		Assert.assertTrue(myElement.isDisplayed());
	}

	@Then("^user should be able to see the following Column Headers in Document Link Details page$")
	public void user_should_be_able_to_see_the_following_column_headers_in_document_link_details_page(
			List<String> attribute) throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			myElement = createFATeamDocumentPage.findElementByDynamicXpath("//th[text()='" + attribute.get(i) + "']");
			Assert.assertTrue(myElement.isDisplayed());
			Thread.sleep(2000);
			Reporter.addStepLog("Verified that " + attribute.get(i) + " is present");
		}
		Reporter.addScreenCapture();
	}

	@And("^user clicks on \"([^\"]*)\" on Document Link Details page$")
	public void user_clicks_on_something_on_document_link_details_page(String strArg1) throws Throwable {
		createFATeamDocumentPage.clickOnAddAnotherDocumentLinkOnFATeamDocumentPage();
	}

	@And("^User clicks on Next Button on Add Document Page$")
	public void user_clicks_on_next_button_on_add_document_page() throws Throwable {
		createFATeamDocumentPage.clickOnNextButtonOnAddDocumentFATeamPage();
	}

	@Then("^User should be able to see following attributes on Create FA Team Review Page$")
	public void user_should_be_able_to_see_following_attributes_on_create_fa_team_review_page(List<String> attribute)
			throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			myElement = createFATeamReviewPage.findElementByDynamicXpath("//*[text()='" + attribute.get(i) + "']");
			Assert.assertTrue(myElement.isDisplayed());
			Reporter.addStepLog("Verified that " + attribute.get(i) + " is present");
		}
		Reporter.addScreenCapture();
		/*
		 * for(int i=0;i<attribute.size();i++) {
		 * myElement=createFATeamReviewPage.findElementByDynamicXpath("//label[text()='"
		 * +attribute.get(i)+"']"); Assert.assertTrue(myElement.isDisplayed());
		 * Reporter.addStepLog("Verified that "+attribute.get(i)+" is present"); }
		 * Reporter.addScreenCapture();
		 */
	}

	@And("^user should be able to see the following Column Headers in Review page$")
	public void user_should_be_able_to_see_the_following_column_headers_in_review_page(List<String> attribute)
			throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			myElement = createFATeamReviewPage.findElementByDynamicXpath("//*[text()='" + attribute.get(i) + "']");
			// action.scrollToBottom();
			Assert.assertTrue(myElement.isDisplayed());
			Reporter.addStepLog("Verified that " + attribute.get(i) + " is present");
		}
		Reporter.addScreenCapture();
	}

	@And("^User clicks on Submit Button on Create New FA Team Review Page$")
	public void user_clicks_on_submit_button_on_create_new_fa_team_review_page() throws Throwable {
		createFATeamReviewPage.clickOnSubmitButtonOnFATeamReviewPage();
	}

	@Then("^User should be able to see the Confirmation Header on Create New FA Team Confirmation page$")
	public void user_should_be_able_to_see_the_confirmation_header_on_create_new_fa_team_confirmation_page()
			throws Throwable {
		createFATeamConfirmationPage.verifyFinancialAdvisorConfirmationHeaderonConfirmationPage();
	}

	@And("^User should be able to see the FA Id on Create New FA Team Confirmation page$")
	public void user_should_be_able_to_see_the_fa_id_on_create_new_fa_team_confirmation_page() throws Throwable {
		createFATeamConfirmationPage.verifyFinancialAdvisorConfirmationFAIDOnConfirmationPage();
	}

	@And("^User should be able to see the below fields on Create New FA Team Confirmation page$")
	public void user_should_be_able_to_see_the_below_fields_on_create_new_fa_team_confirmation_page(
			List<String> attribute) throws Throwable {
		for (int i = 0; i < attribute.size(); i++) {
			myElement = createFATeamConfirmationPage
					.findElementByDynamicXpath("//*[text()='" + attribute.get(i) + "']");
			Thread.sleep(10000);
			Assert.assertTrue(myElement.isDisplayed());
			Reporter.addStepLog("Verified that " + attribute.get(i) + " is present");
		}
		Reporter.addScreenCapture();
	}

	@And("^User clicks on the Done Button on Create New FA Team Confirmation Page$")
	public void user_clicks_on_the_done_button_on_create_new_fa_team_confirmation_page() throws Throwable {
		createFATeamConfirmationPage.clickOnDoneButtOnConfirmationPage();
	}

	@And("^User clicks on the Create Another Financial Advisor Button on Create New FA Team Confirmation Page$")
	public void user_clicks_on_the_create_another_financial_advisor_button_on_create_new_fa_team_confirmation_page()
			throws Throwable {
		createFATeamConfirmationPage.clickOnCreateAnotherFinancialAdvisorButtonOnConfirmationPage();
	}

	@And("^User should able to navigate Enter FA Team Details page$")
	public void user_should_able_to_navigate_enter_fa_team_details_page() throws Throwable {
		createFATeamPage1.verifyFATeamEnterFADetailsHeaderonDocumentsPage();
	}

	@And("^User clicks on Save as Draft Button on Create New FA Team Page$")
	public void user_clicks_on_save_as_draft_button_on_create_new_fa_team_page() throws Throwable {
		createFATeamPage1.clickOnSaveAsDraftButtonOnFATeamPage();
	}

	@Then("^User should able to see Save as Draft popup$")
	public void user_should_able_to_see_save_as_draft_popup() throws Throwable {
		createFATeamPage1.verifyFATeamEnterSaveAsDraftHeaderOnFaTeamPage();
	}

	@And("^User should able to enter the Draft name and click on Save as a draft button$")
	public void user_should_able_to_enter_the_draft_name_and_click_on_save_as_a_draft_button(
			List<List<String>> attributeValuePair) throws Throwable {
		Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"brml-input[label='" + attributeValuePair.get(i).get(0)
							+ "']\").shadowRoot.querySelector('wf-tooltip > div > div >input')");
			action.jsClick(myElement);
			action.sendkeysClipboard(myElement,
					attributeValuePair.get(i).get(0) + Calendar.getInstance().getTimeInMillis());
		}
	}

	@And("^User should able to click on the Save button on the save as Draft popup$")
	public void user_should_able_to_click_on_the_save_button_on_the_save_as_draft_popup() throws Throwable {
		Thread.sleep(3000); // Changing the wait 18/06
		createFATeamPage1.clickOnSaveAsDraftSaveButtonFATeamPage();
	}

	@And("^User clicks on Save as Draft Button on Document Page$")
	public void user_clicks_on_save_as_draft_button_on_document_page() throws Throwable {
		createFATeamPage1.clickOnSaveAsDraftButtonOnFATeamPage();
	}

	@And("^User clicks on Save as Draft Button on Review Page$")
	public void user_clicks_on_save_as_draft_button_on_review_page() throws Throwable {
		createFATeamPage1.clickOnSaveAsDraftButtonOnFATeamPage();
	}

	@And("^User able to see review page$")
	public void user_able_to_see_review_page() throws Throwable {
		createFATeamReviewPage.verifyFATeamEnterSaveAsDraftHeaderOnFaTeamReviewPage();
	}

	/*
	 * @And("^following which the user clicks on the add link button $") public void
	 * following_which_the_user_clicks_on_the_add_link_button() throws Throwable {
	 * 
	 * updateEntityPage.add_link(); } // throw new PendingException();
	 * 
	 * @Then("^the UI must highlight the section to validate that the doc link has been correctly selected $"
	 * ) public void
	 * the_ui_must_highlight_the_section_to_validate_that_the_doc_link_has_been_correctly_selected
	 * () throws Throwable {
	 * 
	 * updateEntityPage.highlighting_the_added_doc(); }
	 */

	@And("^User enters (.+) in all the fields for FA team details page$")
	public void user_enters_in_all_the_fields_for_FA_team_details_page(String mandatoryDetails) throws Throwable {
		if (mandatoryDetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatoryDetails);
		String faTeamName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String faEmail = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String nameOfFADiscretionaryProgram = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String additionalInformation = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String homeOfficeComments = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		if (faTeamName != "") {
			createFATeamPage1.enterFATeamName(faTeamName);
		}
		createFATeamPage1.selectFaId();
		if (faEmail != "") {
			createFATeamPage1.enterFaEmail(faEmail);
		}
		if (nameOfFADiscretionaryProgram != "") {
			createFATeamPage1.selectNameOfFaDiscretionaryProgram();
		}
		if (additionalInformation != "") {
			createFATeamPage1.enterAdditionalInformation(additionalInformation);
		}
		if (homeOfficeComments != "") {
			createFATeamPage1.enterHomeOfficeComments(homeOfficeComments);
		}
		Reporter.addScreenCapture();
	}

	@Then("^User verifies the details on the Review Page is displayed as entered with (.+)$")
	public void user_verifies_the_details_on_the_review_page_is_displayed_as_enetered(String mandatoryDetails)
			throws Throwable {
		if (mandatoryDetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatoryDetails);
		String faTeamName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String faIds = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String faEmail = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String nameOfFADiscretionaryProgram = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String additionalInformation = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String homeOfficeComments = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String documentType = (String) exlObj.getCellData(sheet, rowIndex, 7);
		String documentLink = (String) exlObj.getCellData(sheet, rowIndex, 8);
		String documentComment = (String) exlObj.getCellData(sheet, rowIndex, 9);
		exlObj.closeWorkBook();
		if (faTeamName != "") {
			Assert.assertTrue(createFATeamReviewPage.getDataFromReviewPage("FA Team Name").contains(faTeamName));
		}

		if (faIds != "") {
			Assert.assertTrue(createFATeamReviewPage.getDataFromReviewPage("FAIDs").equals(faIds));
		}

		/*
		 * if(faEmail!="") {
		 * Assert.assertTrue(createFATeamReviewPage.getDataFromReviewPage("FA Email").
		 * equalsIgnoreCase(faEmail)); }
		 */
		if (nameOfFADiscretionaryProgram != "") {
			Assert.assertTrue(createFATeamReviewPage.getDataFromReviewPage("Name of FA Discretionary Program")
					.equals(nameOfFADiscretionaryProgram));
		}
		if (additionalInformation != "") {
			Assert.assertTrue(createFATeamReviewPage.getDataFromReviewPage("Additional Information")
					.equals(additionalInformation));
		}
		if (homeOfficeComments != "") {
			Assert.assertTrue(
					createFATeamReviewPage.getDataFromReviewPage("Home Office Comments").equals(homeOfficeComments));
		}
		if (documentType != "") {
			Assert.assertTrue(createFATeamReviewPage.getDataFromReviewPage("Document Type").equals(documentType));
		}
		if (documentLink != "") {
			Assert.assertTrue(createFATeamReviewPage.getDataFromReviewPage("Document Link").contains(documentLink));
		}
		if (documentComment != "") {
			Assert.assertTrue(createFATeamReviewPage.getDataFromReviewPage("Document Comment").equals(documentComment));
		}
		Reporter.addScreenCapture();
	}

	@And("^User clicks on Previous button in fateam review page$")
	public void user_clicks_on_previous_button_in_fateam_review_page() {
		createFATeamReviewPage.clickOnPreviousButtonOnFATeamReviewPage();
	}

	@And("^User verifies (.+) in FA team details page$")
	public void user_verifies_in_FA_team_details_page(String mandatoryDetails) throws Throwable {
		if (mandatoryDetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatoryDetails);
		String faTeamName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String faEmail = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String nameOfFADiscretionaryProgram = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String additionalInformation = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String homeOfficeComments = (String) exlObj.getCellData(sheet, rowIndex, 6);
		exlObj.closeWorkBook();
		if (faTeamName != "") {
			Assert.assertTrue(createFATeamPage1.getFATeamName().contains(faTeamName));
		}
		if (additionalInformation != "") {
			Assert.assertTrue(additionalInformation.equals(createFATeamPage1.getAdditionalInformation()));
		}
		if (homeOfficeComments != "") {
			Assert.assertTrue(homeOfficeComments.equals(createFATeamPage1.getHomeOfficeComments()));
		}
		Reporter.addScreenCapture();
	}

    @And("^in the review page user highlights certain key attributes$")
    public void in_the_review_page_user_highlights_certain_key_attributes() throws Throwable {
    	fateamAdvisorPage.highlightfateam();
    }

    @And("^further user decides not to proceed futher and clicks on the draft button$")
    public void further_user_decides_not_to_proceed_futher_and_clicks_on_the_draft_button() throws Throwable {
    	fateamAdvisorPage.highlightfateam();
    	
    }
    @Then("^gives a suitable name to the draft$")
    public void gives_a_suitable_name_to_the_draft(List<List<String>> attribute) throws Throwable {
    	 sheetName = "Valid";
			sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
			for (int i = 0; i < attribute.size(); i++)
			{

				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Create_flow");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
				
				System.out.println(attribute.get(i).get(0));
				myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-textarea[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('textarea')");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				action.clear(myElement);
				action.sendkeysClipboard(myElement, myValue);
				Reporter.addStepLog(myValue+" sent for "+ attribute.get(i).get(0));
    	
    	
    }
}
}
