package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.SystemProcess;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerReviewPage;

public class UpdateManagerReviewStepDef {
	
	UpdateManagerReviewPage reviewPage = new UpdateManagerReviewPage("AD_PM_UpdateManagerReviewPage");
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateManager.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue = null;
	
	@Then("^User should be able to see Review Page in Update Manager Flow$")
    public void user_should_be_able_to_see_review_page_in_update_manager_flow() {
		Assert.assertTrue(reviewPage.isUserOnReviewPage());
    }
	
	@And("^with Manager code from UI store the data related to manager from review page in Excel for (.+) in Update Manager Flow$")
    public void with_manager_code_from_ui_store_the_data_related_to_manager_from_review_page_in_excel_for_in_update_manager_flow(String mandatorydetails) throws IOException {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
        
        rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
        
    	int reviewPageDataRowIndex = rowIndex+4;
    	String managerCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex+1, 28);
		getDataFromreviewPageandStoreInExcel(managerCode, reviewPageDataRowIndex);
    }

	private void getDataFromreviewPageandStoreInExcel(String managerCode, int reviewPageDataRowIndex) throws IOException {
		

		sheetName = "Test";
		   
		   int columNum = 2;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
		   
		   //Boolean bool = reviewPage.areContactsDisplayed();
		   //Boolean bool2 = reviewPage.isDocumentHeaderDisplayed();
		  
		   ArrayList<String> pageHeaders = reviewPage.getHeadersInReviewPage(); 
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columNum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						 
						if(label.contains("Document")) {
							if(pageHeaders.size() > 2)
								attributeValue = getDataFromReviewPage(label);
							else
								attributeValue = "";
								
						}else if (label.contains("Contact")) {
							if(pageHeaders.size() > 1) {
								if(reviewPage.areContactsDisplayed()) {
									attributeValue = getDataFromReviewPage(label);
								}else
									attributeValue = "";
							}
							else
								attributeValue = "";
						}
						else
							attributeValue = getDataFromReviewPage(label);
						
						
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex-1, columNum);
								
						if(label.contains("Document")) {
							if(dbValue.equalsIgnoreCase(attributeValue)) {
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue);
							}
						}else if(dbValue.equals(attributeValue)) {
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue);
						}else {
							
							if(label.contains("4 Eye Check Override")) {
								if(attributeValue.equals("true")) {
									attributeValue = "Yes";
								}else {
									attributeValue = "No";
								}
								if(dbValue.trim().equalsIgnoreCase(attributeValue.trim()))
									PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue);
							}else {
								PMPageGeneric.setCellDataSync(excelFilePath, sheetName, reviewPageDataRowIndex, columNum, attributeValue+" -Review Page Value is not same as Flow Page Value in UI");
								Reporter.addEntireScreenCaptured();
								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Value Displayed in Flow Pages");
								
							}
							
						}
						
						columNum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columNum);
							if(label == "")
								label = "isEmpty";
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
    
		
	}

	private String getDataFromReviewPage(String data) {
	    	switch (data) {
			case "Manager Name":
				
				uiValue = reviewPage.getManagerNameValue();
				
				break;
			case "Firm Name":
				
				uiValue = reviewPage.getFirmNameValue();
				
				break;
			case "Firm Website":
				
				uiValue = reviewPage.getFirmWebsiteValue();
				
				break;
			case "Vestmark Manager Name":
				
				uiValue = reviewPage.getVestmarkManagerNameValue();
				
				break;
			case "Taxpayer Identification Number":
				
				uiValue = reviewPage.getTaxPayerIdentificationNumberValue();
				
				break;
			case "Large Trader ID":
				
				uiValue = reviewPage.getLargeTraderIDValue();
				
				break;
			case "DTCC ID":
				
				uiValue = reviewPage.getdtccIDValue();
				
				break;
			case "Status":
				
				uiValue = reviewPage.getStatusValue();
				
				break;
			case "4 Eye Check Override":
				
				uiValue = reviewPage.get4EyeCheckOverrideValue();
				
				break;
			case "UBS Subsidiary":
				
				uiValue = reviewPage.getUBSSubsidiaryValue();
				
				break;
			case "Contact Type":
				
				uiValue = reviewPage.getContactTypeValue();
				
				break;
			case "Contact Description":
				
				uiValue = reviewPage.getContactDescriptionValue();
				
				break;
			case "Contact First Name":
				
				uiValue = reviewPage.getContactFirstNameValue();
				
				break;
			case "Contact Middle Name":
				
				uiValue = reviewPage.getContactMiddleNameValue();
				
				break;
			case "Contact Last Name":
				
				uiValue = reviewPage.getContactLastNameValue();
				
				break;
			case "Contact Address":
				
				uiValue = reviewPage.getContactAddressValue();
				
				break;
			case "Contact City":
				
				uiValue = reviewPage.getContactCityValue();
				
				break;
			case "Contact State":
				
				uiValue = reviewPage.getContactStateValue();
				
				break;
			case "Contact Postal Code":
							
				uiValue = reviewPage.getContactPostalCodeValue();
							
				break;
			case "Contact Country":
				
				uiValue = reviewPage.getContactCountryValue();
				
				break;
			case "Contact Email Address":
				
				uiValue = reviewPage.getContactEmailAddressValue();
				
				break;
			case "Contact Phone Number":
				
				uiValue = reviewPage.getContactPhoneNumberValue();
				
				break;
			case "Document Type":
				
				uiValue = reviewPage.getDocumentTypeValue();
				
				break;
			case "Document Link":
				
				uiValue = reviewPage.getDocumentLinkValue();
				
				break;
			case "Document Comment":
				
				uiValue = reviewPage.getDocumentCommentValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;

	}
	@And("^User clicks on Submit Button in Review Page in Update Manager Flow$")
    public void user_clicks_on_submit_button_in_review_page_in_update_manager_flow() throws IOException {
        reviewPage.clickOnSubmitButton();
        Action.pause(10000);
    }
	
	@And("^User clicks on Previous button in Review Page in Update Manager Flow$")
    public void user_clicks_on_previous_button_in_review_page_in_update_manager_flow() {
        reviewPage.clickOnPrevious();
    }
	
	@And("^User clicks on Back Link in Review Page in Update Manager Flow$")
    public void user_clicks_on_back_link_in_review_page_in_update_manager_flow() {
        reviewPage.clickOnBackLink();
    }

}
