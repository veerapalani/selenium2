package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.codoid.products.exception.FilloException;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.DataConversions;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class UILoginStepDef {
	PMPageGeneric loginPage = new PMPageGeneric("AD_PM_LoginPage");
	SSOLoginPage ssoLoginPage = new SSOLoginPage();
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> list1 = new ArrayList<WebElement>();
	String expectedColorCode;
	WebElement myElement;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_SSOLoginPage"));
	SSOLoginPage slp = new SSOLoginPage();
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	// String excelFilePath =
	// "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	// ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;


	@When("^User gives the valid credentials in the Username and Password and click on login button in login page$")
	public void user_gives_the_valid_credentials_in_the_username_and_password_in_login_page() throws Throwable {
		action.sendKeys(action.getElement("UsernameField"), property.getProperty("pm_dev_username"));
		action.sendKeys(action.getElement("PasswordField"), property.getProperty("pm_dev_password"));
		action.click(action.getElement("LoginButton"));
	}

	@When("^User gives the Invalid credentials in the Username and Password and click on login button in login page$")
	public void user_gives_the_invalid_credentials_in_the_username_and_password_and_click_on_login_button_in_login_page()
			throws Throwable {
		action.sendKeys(action.getElement("UsernameField"), "abc123");
		action.sendKeys(action.getElement("PasswordField"), "abc123");
		action.click(action.getElement("LoginButton"));
		Reporter.addStepLog("clicked on login button");
	}

	@When("^User gives the Blank credentials in the Username and Password and click on login button in login page$")
	public void user_gives_the_blank_credentials_in_the_username_and_password_and_click_on_login_button_in_login_page()
			throws Throwable {
		action.click(action.getElement("LoginButton"));
		Reporter.addStepLog("clicked on login button");
	}

	@Then("^User should be able to see the Error Message of Incorrect Username or Password$")
	public void user_should_be_able_to_see_the_error_message_of_incorrect_username_or_password() throws Throwable {
		myElement = action.getElement("Error Message");
		Assert.assertTrue(myElement.getText().contains("User ID / Password combination is wrong"));
		Reporter.addStepLog("error message is validated");
		Reporter.addScreenCapture();

	}

	@Then("^User should be able to see the Invalid Message of Incorrect Username or Password$")
	public void user_should_be_able_to_see_the_invalid_message_of_incorrect_username_or_password() throws Throwable {
		myElement = action.getElement("Invalid Message");
		Assert.assertTrue(myElement.getText().contains("Invalid username or password"));
		Reporter.addStepLog("Invalid username or password is present");
		Reporter.addScreenCapture();
	}

	GlobalSearchPage globalsearchpage = new GlobalSearchPage();
	SSOLoginPage ssologin = new SSOLoginPage();

	@Given("^User login to product master application with credentials for \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_login_to_product_master_application_with_credentials_for_something_as_something_and_something_as_something(
			String elementKey, String elementValue, String elementKey2, String elementValue2) throws Throwable {
		loginPage.launch_PM_URL();
		loginPage.sendKeysCharacterWise(elementValue, loginPage.getElementFromShadowRoot(elementKey));
		loginPage.sendKeysCharacterWise(elementValue2, loginPage.getElementFromShadowRoot(elementKey2));
	}

	@Given("^User login to product master application with unique credentials for \"([^\"]*)\" as \"([^\"]*)\" and \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_login_to_product_master_application_with_unique_credentials_for_something_as_something_and_something_as_something(
			String elementKey, String elementValue, String elementKey2, String elementValue2) throws Throwable {
		loginPage.launch_PM_URL();
		Long time = Calendar.getInstance().getTimeInMillis();
		loginPage.sendKeys(elementValue + Long.toString(time), loginPage.getElementFromShadowRoot(elementKey));
		loginPage.sendKeys(elementValue2 + Long.toString(time), loginPage.getElementFromShadowRoot(elementKey2));
	}

	@Given("^User login to product master application with credentials Username as (.+) and Password as (.+)$")
	public void user_login_to_product_master_application_with_credentials_username_as_and_password_as(String username,
			String password) throws Throwable {

	}

	@Given("^User has logged into Product Master portal$")
	public void user_has_logged_into_product_master_portal() throws Throwable {
		ssologin.login("");

	}

	@Given("^User login to product master application with unique (.+) and (.+)$")
	public void user_login_to_product_master_application_with_unique_and(String username, String password)
			throws Throwable {

	}

	@Given("^user Launches product master URL successfully$")
	public void user_launches_product_master_url_successfully_() throws Throwable {
		loginPage.launch_PM_URL();
	}

//	    @When("^user enters valid login credentials for (.+) and (.+)$")
//	    public void user_enters_valid_login_credentials_for_PM_and_(String userKey, String passwordkey) throws Throwable {
//	    	loginPage.enter_PM_login_Details(userKey, passwordkey);
//	    	
//	    }
	@And("^User clicks on \"([^\"]*)\" on Login Page$")
	public void user_clicks_on_something_on_login_page(String key) throws Throwable {
		loginPage.clickOnLink(key);
	}

	@And("^User clicks on Login Button$")
	public void user_clicks_on_login_button(String key) throws Throwable {

	}
//	    @Given("^that user logged into product master application with valid credentials as LoginUserName and LoginPassword$")
//	    public void that_user_logged_into_product_master_application_with_valid_credentials_as_loginusername_and_loginpassword(String Username,String Password) throws Throwable {
//	    	loginPage.launch_PM_URL();
//	    	loginPage.enter_PM_login_Details(Username, Password);
//	    	loginPage.click_On_Login();
//	    }

	@When("^User types (.+) in search bar$")
	public void user_types_in_search_bar(String searchtoken) throws Throwable {
		globalsearchpage.enter_token_in_searchbox(searchtoken);
	}

	@Then("^it should throw an error message as (.+) in the UI$")
	public void it_should_throw_an_error_message_as_in_the_ui(String errormessage) throws Throwable {
		Assert.assertEquals(globalsearchpage.getTheErrorMessage(), errormessage);
	}

	@And("^User clicks on Global Search Button$")
	public void user_clicks_on_global_search_button() throws Throwable {
		globalsearchpage.click_on_Search_icon();

	}

	@Then("^it should display 'showing x Results for (.+)'$")
	public void it_should_display_showing_x_results_for_(String key) throws Throwable {
		// listOfElements = globalsearchpage.getElements1(key);
		// for(int i=0;i<listOfElements.size();i++) {
		// System.out.println(listOfElements.size()+123);
		// System.out.println();
		globalsearchpage.getThetextMessage_Showingtext();
		Assert.assertTrue(globalsearchpage.getThetextMessage_Showingtext().contains(key));
	}

	@Then("^it should throw the error message as (.+) in the UI$")
	public void it_should_throw_the_error_message_as_in_the_ui(String errormessage) throws Throwable {
		Assert.assertEquals(globalsearchpage.getTheErrorMessage_Nosearch(), errormessage);
	}

	@Then("^User should observe searched results pertaining from each of the entities \"([^\"]*)\" for every row in table under the \"([^\"]*)\" Header on Global search screen$")
	public void user_should_observe_searched_results_pertaining_from_each_of_the_entities_something_header_on_global_search_screen(
			List<String> list1, String elementsKey) throws Throwable {
		listOfElements = globalsearchpage.getElements(elementsKey);

		for (int i = 0; i < listOfElements.size(); i++) {
			list1.contains(listOfElements.get(i).getText());
		}
	}

	@Then("^it should throw the error message as <ErrorMessage> in the UI for spl characters$")
	public void it_should_throw_the_error_message_as_in_the_ui_for_spl_characters(String errormessage)
			throws Throwable {
		Assert.assertEquals(globalsearchpage.getTheErrorMessage_splchar(), errormessage);
	}

	@Then("^User should observe searched results pertaining to the \"([^\"]*)\" Header on Global search screen$")
	public void user_should_observe_searched_results_pertaining_to_the_something_header_on_global_search_screen(
			String key) throws Throwable {

	}

	@Then("^it should throw the error message in the UI for the limited special characters$")
	public void it_should_throw_the_error_message_as_in_the_ui_for_the_limited_special_characters() throws Throwable {
		String errormessage = "Search input should not be allowed to enter the below Spl. Characters($ {} & # ^ * ; \" | ? > <)";
		Assert.assertEquals(globalsearchpage.getTheErrorMessage_splchar_limited(), errormessage);
	}

	@And("^User clicks on Global Search Icon$")
	public void user_clicks_on_global_search_icon() throws Throwable {
		globalsearchpage.click_on_Search_icon_();
	}

	@Then("^search results should be displayed$")
	public void search_results_should_be_displayed() throws Throwable {

		globalsearchpage.Search_text();
	}

	@And("^All the \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Global Search page$")
	public void all_the_something_should_be_displayed_in_something_color_on_global_search_page(String key, String color)
			throws Throwable {
		listOfElements = globalsearchpage.getElements(key);
		expectedColorCode = Action.getTestData(color);
		for (int i = 0; i < listOfElements.size(); i++) {
			globalsearchpage.verifyColor(listOfElements.get(i), expectedColorCode);
		}
	}

	@Then("^it should only allow the user to enter upto 20 characters$")
	public void it_should_only_allow_the_user_to_enter_upto_20_characters() throws Throwable {
		System.out.println("User");
	}

	@And("^User clicks on the Global Search icon$")
	public void user_clicks_on_the_global_search_icon() throws Throwable {
		globalsearchpage.click_on_Search_icon1();

	}

	@Given("^(.+) has logged into the Product Master application$")
	public void has_logged_into_the_product_master_application(String typeofuser)
			throws InterruptedException, FilloException, SQLException {
		String type = "";
		if (typeofuser.contains("HO")) {
			type = "HO";
		} else if (typeofuser.contains("BU")) {
			type = "BU";
		} else if (typeofuser.toLowerCase().contains("branch")) {
			type = "BU";
		} else if (typeofuser.toLowerCase().contains("bruser1")) {
			type = "BrUser1";
		} else if (typeofuser.toLowerCase().contains("bruser2")) {
			type = "BrUser2";
		} else if (typeofuser.toLowerCase().contains("aa")) {
			type = "AA";
		}
//
//	public void has_logged_into_the_product_master_application(String typeofuser) {
//
//		// Giving Implicit wait of 3 seconds
//		WebDriverManager.getDriver().manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
//		String username = null;
//		String password = null;
//		// switch (property.getProperty("ProductMaster_UI_Environment").toLowerCase()) {
//		switch (SSOLoginPage.UIEnvironment.toLowerCase()) {
//		case "dev":
//			if (typeofuser.equalsIgnoreCase("HO_Edit")) {
//				username = property.getProperty("pm_dev_hoedituser");
//				password = property.getProperty("pm_dev_hoeditpassword");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit1")) {
//				username = property.getProperty("pm_dev_hoedituser1");
//				password = property.getProperty("pm_dev_hoeditpassword1");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit2")) {
//				username = property.getProperty("pm_dev_hoedituser2");
//				password = property.getProperty("pm_dev_hoeditpassword2");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit3")) {
//				username = property.getProperty("pm_dev_hoedituser3");
//				password = property.getProperty("pm_dev_hoeditpassword3");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit4")) {
//				username = property.getProperty("pm_dev_hoedituser4");
//				password = property.getProperty("pm_dev_hoeditpassword4");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit5")) {
//				username = property.getProperty("pm_dev_hoedituser5");
//				password = property.getProperty("pm_dev_hoeditpassword5");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit6")) {
//				username = property.getProperty("pm_dev_hoedituser6");
//				password = property.getProperty("pm_dev_hoeditpassword6");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit7")) {
//				username = property.getProperty("pm_dev_hoedituser7");
//				password = property.getProperty("pm_dev_hoeditpassword7");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit8")) {
//				username = property.getProperty("pm_dev_hoedituser8");
//				password = property.getProperty("pm_dev_hoeditpassword8");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser1")) {
//				username = property.getProperty("pm_dev_branchuser1");
//				password = property.getProperty("pm_dev_bupassword1");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser2")) {
//				username = property.getProperty("pm_dev_branchuser2");
//				password = property.getProperty("pm_dev_bupassword2");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser3")) {
//				username = property.getProperty("pm_dev_branchuser3");
//				password = property.getProperty("pm_dev_bupassword3");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser4")) {
//				username = property.getProperty("pm_dev_branchuser4");
//				password = property.getProperty("pm_dev_bupassword4");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser5")) {
//				username = property.getProperty("pm_dev_branchuser5");
//				password = property.getProperty("pm_dev_bupassword5");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser6")) {
//				username = property.getProperty("pm_dev_branchuser6");
//				password = property.getProperty("pm_dev_bupassword6");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser7")) {
//				username = property.getProperty("pm_dev_branchuser7");
//				password = property.getProperty("pm_dev_bupassword7");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser8")) {
//				username = property.getProperty("pm_dev_branchuser8");
//				password = property.getProperty("pm_dev_bupassword8");
//			} else if (typeofuser.equalsIgnoreCase("ProgramManagementUser")) {
//				username = property.getProperty("pm_dev_programmanagementuser");
//				password = property.getProperty("pm_dev_pmpassword");
//			} else if (typeofuser.equalsIgnoreCase("AAUser")) {
//				username = property.getProperty("pm_dev_advisoryadminuser");
//				password = property.getProperty("pm_dev_aapassword");
//			}
//			break;
//		case "qa":
//			if (typeofuser.equalsIgnoreCase("HO_Edit")) {
//				username = property.getProperty("pm_qa_username");
//				password = property.getProperty("pm_qa_password");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit1")) {
//				username = property.getProperty("pm_qa_hoedituser1");
//				password = property.getProperty("pm_qa_hoeditpassword1");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit2")) {
//				username = property.getProperty("pm_qa_hoedituser2");
//				password = property.getProperty("pm_qa_hoeditpassword2");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit3")) {
//				username = property.getProperty("pm_qa_hoedituser3");
//				password = property.getProperty("pm_qa_hoeditpassword3");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit4")) {
//				username = property.getProperty("pm_qa_hoedituser4");
//				password = property.getProperty("pm_qa_hoeditpassword4");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit5")) {
//				username = property.getProperty("pm_qa_hoedituser5");
//				password = property.getProperty("pm_qa_hoeditpassword5");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit6")) {
//				username = property.getProperty("pm_qa_hoedituser6");
//				password = property.getProperty("pm_qa_hoeditpassword6");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit7")) {
//				username = property.getProperty("pm_qa_hoedituser7");
//				password = property.getProperty("pm_qa_hoeditpassword7");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit8")) {
//				username = property.getProperty("pm_qa_hoedituser8");
//				password = property.getProperty("pm_qa_hoeditpassword8");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser1")) {
//				username = property.getProperty("pm_qa_branchuser1");
//				password = property.getProperty("pm_qa_bupassword1");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser2")) {
//				username = property.getProperty("pm_qa_branchuser2");
//				password = property.getProperty("pm_qa_bupassword2");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser3")) {
//				username = property.getProperty("pm_qa_branchuser3");
//				password = property.getProperty("pm_qa_bupassword3");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser4")) {
//				username = property.getProperty("pm_qa_branchuser4");
//				password = property.getProperty("pm_qa_bupassword4");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser5")) {
//				username = property.getProperty("pm_qa_branchuser5");
//				password = property.getProperty("pm_qa_bupassword5");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser6")) {
//				username = property.getProperty("pm_qa_branchuser6");
//				password = property.getProperty("pm_qa_bupassword6");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser7")) {
//				username = property.getProperty("pm_qa_branchuser7");
//				password = property.getProperty("pm_qa_bupassword7");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser8")) {
//				username = property.getProperty("pm_qa_branchuser8");
//				password = property.getProperty("pm_qa_bupassword8");
//			} else if (typeofuser.equalsIgnoreCase("ProgramManagementUser")) {
//				username = property.getProperty("pm_qa_programmanagementuser");
//				password = property.getProperty("pm_qa_pmpassword");
//			} else if (typeofuser.equalsIgnoreCase("AAUser")) {
//				username = property.getProperty("pm_qa_advisoryadminuser");
//				password = property.getProperty("pm_qa_aapassword");
//			}
//			break;
//		case "uat":
//			if (typeofuser.contains("HO_Edit1")) {
//				username = property.getProperty("pm_uat_username");
//				password = property.getProperty("pm_uat_password");
//			} else if (typeofuser.contains("BranchUser1")) {
//				username = property.getProperty("pm_uat_branchuser");
//				password = property.getProperty("pm_uat_bupassword");
//			} else if (typeofuser.contains("ProgramManagementUser")) {
//				username = property.getProperty("pm_uat_programmanagementuser");
//				password = property.getProperty("pm_uat_pmpassword");
//			} else if (typeofuser.equalsIgnoreCase("AAUser")) {
//				username = property.getProperty("pm_uat_advisoryadminuser");
//				password = property.getProperty("pm_uat_aapassword");
//			}
//			break;
//
//		default:
//			break;
		WebDriverManager.getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		slp.login(type);

		// Giving Implicit wait of 3 seconds
//		WebDriverManager.getDriver().manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
//		String username = null;
//		String password = null;
//		// switch (property.getProperty("ProductMaster_UI_Environment").toLowerCase()) {
//		switch (SSOLoginPage.UIEnvironment.toLowerCase()) {
//		case "dev":
//			if (typeofuser.equalsIgnoreCase("HO_Edit")) {
//				username = property.getProperty("pm_dev_hoedituser");
//				password = property.getProperty("pm_dev_hoeditpassword");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit1")) {
//				username = property.getProperty("pm_dev_hoedituser1");
//				password = property.getProperty("pm_dev_hoeditpassword1");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit2")) {
//				username = property.getProperty("pm_dev_hoedituser2");
//				password = property.getProperty("pm_dev_hoeditpassword2");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit3")) {
//				username = property.getProperty("pm_dev_hoedituser3");
//				password = property.getProperty("pm_dev_hoeditpassword3");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit4")) {
//				username = property.getProperty("pm_dev_hoedituser4");
//				password = property.getProperty("pm_dev_hoeditpassword4");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit5")) {
//				username = property.getProperty("pm_dev_hoedituser5");
//				password = property.getProperty("pm_dev_hoeditpassword5");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit6")) {
//				username = property.getProperty("pm_dev_hoedituser6");
//				password = property.getProperty("pm_dev_hoeditpassword6");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit7")) {
//				username = property.getProperty("pm_dev_hoedituser7");
//				password = property.getProperty("pm_dev_hoeditpassword7");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit8")) {
//				username = property.getProperty("pm_dev_hoedituser8");
//				password = property.getProperty("pm_dev_hoeditpassword8");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser1")) {
//				username = property.getProperty("pm_dev_branchuser1");
//				password = property.getProperty("pm_dev_bupassword1");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser2")) {
//				username = property.getProperty("pm_dev_branchuser2");
//				password = property.getProperty("pm_dev_bupassword2");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser3")) {
//				username = property.getProperty("pm_dev_branchuser3");
//				password = property.getProperty("pm_dev_bupassword3");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser4")) {
//				username = property.getProperty("pm_dev_branchuser4");
//				password = property.getProperty("pm_dev_bupassword4");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser5")) {
//				username = property.getProperty("pm_dev_branchuser5");
//				password = property.getProperty("pm_dev_bupassword5");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser6")) {
//				username = property.getProperty("pm_dev_branchuser6");
//				password = property.getProperty("pm_dev_bupassword6");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser7")) {
//				username = property.getProperty("pm_dev_branchuser7");
//				password = property.getProperty("pm_dev_bupassword7");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser8")) {
//				username = property.getProperty("pm_dev_branchuser8");
//				password = property.getProperty("pm_dev_bupassword8");
//			} else if (typeofuser.equalsIgnoreCase("ProgramManagementUser")) {
//				username = property.getProperty("pm_dev_programmanagementuser");
//				password = property.getProperty("pm_dev_pmpassword");
//			}
//			break;
//		case "qa":
//			if (typeofuser.equalsIgnoreCase("HO_Edit")) {
//				username = property.getProperty("pm_qa_username");
//				password = property.getProperty("pm_qa_password");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit1")) {
//				username = property.getProperty("pm_qa_hoedituser1");
//				password = property.getProperty("pm_qa_hoeditpassword1");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit2")) {
//				username = property.getProperty("pm_qa_hoedituser2");
//				password = property.getProperty("pm_qa_hoeditpassword2");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit3")) {
//				username = property.getProperty("pm_qa_hoedituser3");
//				password = property.getProperty("pm_qa_hoeditpassword3");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit4")) {
//				username = property.getProperty("pm_qa_hoedituser4");
//				password = property.getProperty("pm_qa_hoeditpassword4");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit5")) {
//				username = property.getProperty("pm_qa_hoedituser5");
//				password = property.getProperty("pm_qa_hoeditpassword5");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit6")) {
//				username = property.getProperty("pm_qa_hoedituser6");
//				password = property.getProperty("pm_qa_hoeditpassword6");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit7")) {
//				username = property.getProperty("pm_qa_hoedituser7");
//				password = property.getProperty("pm_qa_hoeditpassword7");
//			} else if (typeofuser.equalsIgnoreCase("HO_Edit8")) {
//				username = property.getProperty("pm_qa_hoedituser8");
//				password = property.getProperty("pm_qa_hoeditpassword8");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser1")) {
//				username = property.getProperty("pm_qa_branchuser1");
//				password = property.getProperty("pm_qa_bupassword1");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser2")) {
//				username = property.getProperty("pm_qa_branchuser2");
//				password = property.getProperty("pm_qa_bupassword2");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser3")) {
//				username = property.getProperty("pm_qa_branchuser3");
//				password = property.getProperty("pm_qa_bupassword3");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser4")) {
//				username = property.getProperty("pm_qa_branchuser4");
//				password = property.getProperty("pm_qa_bupassword4");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser5")) {
//				username = property.getProperty("pm_qa_branchuser5");
//				password = property.getProperty("pm_qa_bupassword5");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser6")) {
//				username = property.getProperty("pm_qa_branchuser6");
//				password = property.getProperty("pm_qa_bupassword6");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser7")) {
//				username = property.getProperty("pm_qa_branchuser7");
//				password = property.getProperty("pm_qa_bupassword7");
//			} else if (typeofuser.equalsIgnoreCase("BranchUser8")) {
//				username = property.getProperty("pm_qa_branchuser8");
//				password = property.getProperty("pm_qa_bupassword8");
//			} else if (typeofuser.equalsIgnoreCase("ProgramManagementUser")) {
//				username = property.getProperty("pm_qa_programmanagementuser");
//				password = property.getProperty("pm_qa_pmpassword");
//			}
//			break;
//		case "uat":
//			if (typeofuser.contains("HO_Edit")) {
//				username = property.getProperty("pm_uat_username");
//				password = property.getProperty("pm_uat_password");
//			} else if (typeofuser.contains("BranchUser")) {
//				username = property.getProperty("pm_uat_branchuser");
//				password = property.getProperty("pm_uat_bupassword");
//			} else if (typeofuser.contains("ProgramManagementUser")) {
//				username = property.getProperty("pm_dev_programmanagementuser");
//				password = property.getProperty("pm_dev_pmpassword");
//			}
//			break;
//
//		default:
//			break;
//		}
//
//		// Login to Product Master
//		ssologin.userLogin(username, password);
	}
	
    @Given("^user generates jwt token for productMaster PM - (.+)$")
    public void user_generates_jwt_token_for_productmaster_pm_(String userId) throws Throwable {
		ssoLoginPage.generateJWTToken();
				
    }

    @And("^system is checking repcodes and branch numbers for given user (.+)$")
    public void system_is_checking_repcodes_and_branch_numbers_for_given_user(String userid) throws ParseException {
    	
    	ssoLoginPage.setRepCodes();
    	
    }

}
