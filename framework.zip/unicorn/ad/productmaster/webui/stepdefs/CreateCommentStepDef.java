package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.framework.utils.Action;
public class CreateCommentStepDef {
	
	
	
	PMPageGeneric viewcomment = new PMPageGeneric("AD_PM_ViewCommentPage");
	PMPageGeneric createcomment = new PMPageGeneric("AD_PM_CreateCommentsPage");
	PMPageGeneric review = new PMPageGeneric("AD_PM_ReviewPage");
	PMPageGeneric confirmation = new PMPageGeneric("AD_PM_ConfirmationPage");
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ViewCommentPage"));
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	int rowIndex,cellIndex;
	WebElement myElement,myElement2;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	@Then("^User should be able to go to Comment page$")
    public void user_should_be_able_to_go_to_comment_page() throws Throwable {
       
    }
	@And("^User enters the \"([^\"]*)\" as \"([^\"]*)\" in the Textbox of Create Comment Page$")
    public void user_enters_the_something_as_something_in_the_textbox_of_create_comment_page(String elementKey, String elementValue) throws Throwable {
    	createcomment.sendKeys(elementValue+Calendar.getInstance().getTimeInMillis(),createcomment.getElementFromShadowRoot(elementKey));
		 Reporter.addScreenCapture();
    }
	@And("^User clicks on the \"([^\"]*)\" on Create Comment Page$")
    public void user_clicks_on_the_something_on_create_comment_page(String key) throws Throwable {
    	createcomment.clickOnLink(key);
    }
	@And("^User clicks on the \"([^\"]*)\" on View Comment Page$")
    public void user_clicks_on_the_something_on_view_comment_page(String key) throws Throwable {
    	viewcomment.clickOnLink(key);
    }
	@And("^User clicks on the Next Button on View Comment Page$")
    public void user_clicks_on_the_next_button_on_view_comment_page() throws Throwable {
        
		action.click(action.getElement("Next Button"));
        Reporter.addStepLog("clicked on Next Button on Comment page");
    }
	
	@Then("^user should be able to see the following attributes on View Comment page$")
    public void user_should_be_able_to_see_the_following_attributes_on_doc_link_page(List<String> attributes) throws Throwable {
    	listOfElements = viewcomment.getElements("Attributes_Comment");
        for(int i=0;i<attributes.size();i++)
     	   {
        	viewcomment.verifyTextInListOfElements(attributes.get(i), listOfElements);
     	   Reporter.addStepLog("verified for "+attributes.get(i)+" attribute");
     	   }
    }

    @Then("^User clicks on Add Comment$")
    public void user_clicks_on_add_comment() throws Throwable {
    	action.click(action.getElement("Add Comment"));
        Reporter.addStepLog("clicking on Add Comment"); 
    }

    @And("^User clicks on Add Another Comment on View Comment Page$")
    public void user_clicks_on_add_another_comment_on_view_comment_page() throws Throwable {
    	myElement = null;
    	myElement =(WebElement) action.getElementByJavascript("Add Another Comment");
    	if(myElement!=null) {
    	action.click(myElement);
        Reporter.addStepLog("clicking on Add Another Comment Button");
    	}
    }

    @And("^User enters the valid values in all the fields of Comment$")
    public void user_enters_the_valid_values_in_all_the_fields_of_comment(List<String> attribute) throws Throwable {
    	sheet = exlObj.getSheet("Valid");
    	for (int i=0;i<attribute.size();i++) {
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_Mandatory");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
		if(attribute.get(i).equalsIgnoreCase("Comment Type")) {
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"wf-select[label='Type']\").shadowRoot.querySelector('button')");
			action.scrollToElement(myElement);
			action.click(myElement);
			myElement2 = (WebElement)action.executeJavaScript("return document.querySelector(\"wf-select[label='Type']\").shadowRoot.querySelector(\"li[data-value='\\\""+(String) exlObj.getCellData(sheet, rowIndex, cellIndex)+"\\\"']\")");
			action.click(myElement2);	
		}
		
		else {
		myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"[label='"+attribute.get(i)+"']\").shadowRoot.querySelector('textarea')");
		
		action.sendkeysClipboard(myElement,(String) exlObj.getCellData(sheet, rowIndex, cellIndex)+Calendar.getInstance().getTimeInMillis()); 
		}
    }
    }
}
