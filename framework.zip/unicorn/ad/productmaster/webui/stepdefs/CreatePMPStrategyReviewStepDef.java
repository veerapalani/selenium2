package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreatePMPStrategyReviewStepDef {
	CreatePMPStrategyReviewPage reviewPage = new CreatePMPStrategyReviewPage("AD_PM_CreatePMPStrategyReviewPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex, columnIndex;

	@And("^User clicks on Submit in Review Page$")
	public void user_clicks_on_submit_in_review_page() {
		reviewPage.selectCheckBox();
		reviewPage.clickOnSubmit();
	}

	@And("^User should be able to see Review Page in PMP Flow$")
	public void user_should_be_able_to_see_review_page_in_pmp_flow() {
		Assert.assertTrue(reviewPage.isUserOnReviewPage());
	}

	@Then("^User should be able to see added benchmarks from (.+) are sorted in descending order in Review Page in PMP Flow$")
	public void user_should_be_able_to_see_added_benchmarks_from_are_sorted_in_descending_order_in_review_page_in_pmp_flow(
			String mandatorydetails) {
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		mandatorydetails = mandatorydetails + "_" + SSOLoginPage.UIEnvironment.trim().toLowerCase();
		String benchmarkCategory, benchmark, benchmarkPercentage, customBenchmarkReason = "";
		String locatorValueCustomBenchmark, locatorValueCustomBenchmarkHighlight,
				locatorValueCustomBenchmarkPercentage = "";
		String tName = Thread.currentThread().getName();
		synchronized(tName) {
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 20);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 21);
		}
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");
			int size = customBenchmark.length;
			for(int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}
		else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for(String benchmarkKey: sortedHashMap.keySet()) {
			benchmarkfromUI = reviewPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = reviewPage.getPercentageithValuefromUI(j);
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey.split(" - ")[1].trim()));
			j++;
		}
	}

	private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
		Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);
		//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().split(" - ")[1].trim().compareTo(o2.getKey().split(" - ")[1].trim()));
		//sort based on benchmark percentage
		Collections.sort(entryList, (o1, o2) -> {
			if(o1.getValue() > o2.getValue()) {
				return -1;
			}
			else if(o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});
		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
		 * 
		 * @Override public int compare(Entry<String, Float> o1, Entry<String, Float>
		 * o2) { if(o1.getValue() > o2.getValue()) { return -1; }else if(o1.getValue() <
		 * o2.getValue()) { return 1; } return 0; } });
		 */
		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for(Entry<String, Float> entry: entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}
		/*
		 * for (String countryKey : sortedHashMap.keySet()) {
		 * System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		 * 
		 * }
		 */
		return sortedHashMap;
	}

	@And("^User clicks on Edit Button at Benchmark Header in Review Page in Create PMP Flow$")
	public void user_clicks_on_edit_button_at_benchmark_header_in_review_page_in_create_pmp_flow() {
		reviewPage.clickOnBenchmarkEditLink();
	}

	@And("^User clicks on Previous Button in Review Page in PMP Flow$")
	public void user_clicks_on_previous_button_in_review_page_in_pmp_flow() {
		reviewPage.clickOnPrevious();
	}

	@Then("^Submit button should not be enabled in Review Page in PMP Flow$")
	public void submit_button_should_not_be_enabled_in_review_page_in_pmp_flow() {
		Assert.assertTrue("Submit Button is not disabled", reviewPage.isSubmitButtonDisabled());
	}

	@Then("^below label fields should be disabled in Review Page in PMP Flow$")
	public void below_label_fields_should_be_disabled_in_review_page_in_pmp_flow(List<String> data) {
		for(String label: data) {
			Assert.assertTrue(reviewPage.isLableDisabled(label));
		}
	}

	@Then("^\"([^\"]*)\" value in Review page should be visible to user in PMP Flow for (.+)$")
	public void something_value_in_review_page_should_be_visible_to_user_in_pmp_flow_for(String label,
			String mandatorydetails) {
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		mandatorydetails = mandatorydetails + "_" + SSOLoginPage.UIEnvironment.trim().toLowerCase();
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		String givenData = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 6);
		Assert.assertTrue(reviewPage.getcommonattributevalue(label).equals(givenData));
	}

	@Then("^User should be able to see FA Team member names of FA Team value from given (.+) in Review Page$")
	public void user_should_be_able_to_see_fa_team_member_names_of_fa_team_value_from_given_in_review_page(
			String mandatorydetails) throws Throwable {
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails + "_" + SSOLoginPage.UIEnvironment.trim().toLowerCase();
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		String givenFATeamName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 4);
		String replaceData = givenFATeamName.trim();
		pmdb.DBConnectionStart();
		sheetName = "Query";
		String dbDataIterator = "testnull";
		ArrayList<String> tempData = new ArrayList<String>();
		ResultSet rs;
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 9, 1);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 9, 2);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		rs = DBManager.executeSelectQuery(SQLquery);
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			if(rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
			tempData.add(dbDataIterator);
		}
		// to handle Zero records from DB
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		if(tempData.size() > 1) {
			Collections.sort(tempData);
			dbDataIterator = "";
			for(String G: tempData) {
				dbDataIterator = dbDataIterator + G + ", ";
			}
			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length() - 2);
		}
		String fATeamMemberNamesfromUI = reviewPage.getcommonattributevalue("FA Team Members");
		String fATeamMemberNamesfromDB = dbDataIterator;
		if(fATeamMemberNamesfromDB.length() == fATeamMemberNamesfromUI.length()) {
			for(String string: tempData) {
				Assert.assertTrue(fATeamMemberNamesfromUI.contains(string));
			}
		}
		else {
			Assert.fail("FA Team Member Names in UI and DB do not match");
		}
	}

	@Then("User should able to see same CASP style in review page for (.+)$")
	public void user_should_be_able_to_see_same_casp_style_in_review_page(String mandatorydetails) {
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		mandatorydetails = mandatorydetails + "_" + SSOLoginPage.UIEnvironment.trim().toLowerCase();
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		String givenData = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 28);
		String pmpDefaultValue = reviewPage.getBenchmarkValues(0);
		String percentage = reviewPage.getBenchmarkValues(2);
		String percentageTotal = percentage.substring(0, percentage.length()-1);
		Assert.assertTrue(givenData.contains(pmpDefaultValue));
		Assert.assertTrue(givenData.contains(percentageTotal));
	}
}
