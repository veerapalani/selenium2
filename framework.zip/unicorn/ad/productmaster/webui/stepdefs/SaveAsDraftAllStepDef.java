package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.fail;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat; 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Flags.Flag;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.codoid.products.fillo.Select;
import com.google.gson.Gson;
import com.hp.lft.sdk.mobile.DropDown;
import com.ibm.db2.jcc.a.i;
import com.ibm.db2.jcc.am.s;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.remote.NewAppiumSessionPayload;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.SaveAsDraftAllUIPage;
import qa.unicorn.ad.productmaster.webui.pages.StrategyDetailPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategySMADualUIPage;

public class SaveAsDraftAllStepDef 
	{
		
		String pageURL = SSOLoginPage.URL + "#/smaDualMac/view/";
		String pageURL2 = SSOLoginPage.URL + "#/smaDualMac/edit/";
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/SaveAsDraftAll.xlsx";
		String sheetName = "";
		String myValue,myValue1;
		String draftName = "SaveAsDraftRgow";
		XSSFSheet sheet;
		int rowIndex, cellIndex;
		WebElement myElement,myElement1;
		List<WebElement> myElements,myElements1;
		String proxyDetails[]= {"Proxy Address","Voluntary Reorg Address","Interim"};
		String scenario[]= {"0","2","4"};
		int num;
		String timeStamp = new SimpleDateFormat("dd-MM-yyyy(HH:mm)").format(new Date());
		List<List<String>> attributeLists = new ArrayList<List<String>>();
		List<String> dataList = new ArrayList<String>() ;
		
		WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
		
		Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategySMADualUIPage"));		

		SaveAsDraftAllUIPage saveAsDraftAllPage = new SaveAsDraftAllUIPage();
		
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		
		StrategyDetailPage strDtl = new StrategyDetailPage();
		
		SoftAssert sftAst = new SoftAssert();
		
		ProductMasterDBManager pmdb = new ProductMasterDBManager();
		
		HashMap<String, String> DropDownValues = new HashMap<String, String>();
		HashMap<String, String> InputValues = new HashMap<String, String>();
		HashMap<String, String> DropDownValuesId = new HashMap<String, String>();
		HashMap<String, String> InputValuesId = new HashMap<String, String>();
		HashMap<String, String> DataBaseValues = new HashMap<String, String>();
		HashMap<String, String> ProxyValues = new HashMap<String, String>();
		HashMap<String, Double> BenchmarkValues = new HashMap<String, Double>();
		HashMap<String ,HashMap<String,Double>> BenchmarkDetails = new HashMap<String ,HashMap<String,Double>>();		
		String applicationPropertyFilePath = "./application.properties";

		PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
		//String UIEnvironment = property.getProperty("ProductMaster_UI_Environment").trim().toUpperCase();
		 String UIEnvironment = SSOLoginPage.UIEnvironment.trim().toUpperCase();
		
		@When("^User clicks on Create New Dropdown Button on landing page of SaveAsDraft flow$")
	    public void user_clicks_on_create_new_dropdown_button_on_landing_page_of_saveasdraft_flow() throws Throwable
	    {
			try
			{
				saveAsDraftAllPage.clickCreateNew();
		    }
			catch (Exception e)
			{
				Assert.fail("Unable to access Create New button");
			}
	    }
		

	    @And("^User clicks on \"([^\"]*)\" option from the dropdown of SaveAsDraft flow$")
	    public void user_clicks_on_something_option_from_the_dropdown_of_saveasdraft_flow(String strArg1) throws Throwable
	    {
	    	try
	    	{
		    	saveAsDraftAllPage.clickCreateNewOption(strArg1);
	    	}
	    	
	    	catch (Exception e) 
	    	{
				Assert.fail("Unable to access "+ strArg1 +" option");
			}
	    
	    }
	    
	    @Then("^User should be able to see the \"([^\"]*)\" header of SaveAsDraft flow$")
	    public void user_should_be_able_to_see_the_something_header_of_saveasdraft_flow(String strArg1) throws Throwable
	    {
	    	try
	    	{
				saveAsDraftAllPage.checkHeader(strArg1);

	    	}
	    	catch (Exception e) {

	    		Assert.fail(strArg1+" header is not present");
	    	}
	    }
		
	    @And("^Edit all the below drop down fields of (.+) with (.+)  data of SaveAsDraft flow$")
	    public void edit_all_the_below_drop_down_fields_of_with_data_of_saveasdraft_flow(String entity, String scenario, List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.editDropDownFields(entity, scenario, attribute);
	    }
	    
	    @Then("^Edit all the below input fields of (.+) with (.+) data of SaveAsDraft flow$")
	    public void edit_all_the_below_input_fields_of_with_data_of_saveasdraft_flow(String entity, String scenario, List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.editInputFields(entity, scenario, attribute);
	    }
	    
	    @And("^Edit the PIV Style radio button to \"([^\"]*)\"$")
	    public void edit_the_piv_style_radio_button_to_something(String strArg1) throws Throwable
	    {
	    	try
	    	{
		    	if(strArg1.equalsIgnoreCase("yes"))
		    	{
		    		myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#pivStyle > brml-radio-option:nth-child(1)\").shadowRoot.querySelector(\"button\")");
		    		myElement.click();
		    	}
		    	else 
		    	{
		    		myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#pivStyle > brml-radio-option:nth-child(2)\").shadowRoot.querySelector(\"button\")");
		    		myElement.click();
		    	}
	    	}
	    	catch (Exception e)
	    	{
				Assert.fail("Unable to access PIV Style" );
			}
	   	}
	    
	    @Then("^Edit all the below text fields of (.+) with (.+) data of SaveAsDraft flow$")
	    public void edit_all_the_below_text_fields_of_with_data_of_saveasdraft_flow(String entity, String scenario, List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.editTextFields(entity, scenario, attribute);
	    }
	    
	    @And("^Edit all the below radio button fields of (.+) with (.+) data of SaveAsDraft flow$")
	    public void edit_all_the_below_radio_button_fields_of_with_data_of_saveasdraft_flow(String entity, String scenario, List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.editRadioButton(entity, scenario, attribute);
	    }
	    
	    @And("^User clicks the Save As Draft Button of SaveAsDraft flow$")
	    public void user_clicks_the_save_as_draft_button_of_saveasdraft_flow() throws Throwable
	    {
	    	try 
	    	{
	    		saveAsDraftAllPage.clickSaveAsDraft();
	    	}
	    	catch (Exception e)
	    	{
				Assert.fail("Unable to access Save As Draft button" );
				
			}
	    }
	    
	    @Then("^User should be able to enter the draft name on the Save As Draft window$")
	    public void user_should_be_able_to_enter_the_draft_name_on_the_save_as_draft_window() throws Throwable
	    {
	    	try 
	    	{
	    		saveAsDraftAllPage.enterDraftName();
			}
	    	catch (Exception e)
			{
				Assert.fail("Unable to save the Draft" );
				
			}
	    }	    
	    
	    @Then("^User checks if the saved draft is displayed in draft view$")
	    public void user_checks_if_the_saved_draft_is_displayed_in_draft_view() throws Throwable
	    {
	    	saveAsDraftAllPage.checkInDraftView();
	    }
	    
	    public void scroll_to_bottom() throws Throwable
	    {	
		   
		   try
		   {
			   Object lastHeight = (Object) action.executeJavaScript("return document.body.scrollHeight");
			   
			   while(true)
			   {
				   Action.scrollToBottom();
				   Thread.sleep(5000);
				   
				   Object newHeight = (Object) action.executeJavaScript("return document.body.scrollHeight");
				   if(newHeight.equals(lastHeight))
				   {
					   break;
				   }
				   
				   lastHeight = newHeight;
			   }

		   }
		   
		   catch (Exception e) 
		   {
			   e.printStackTrace();
		   }
	    }
	    

	    @And("^User should be able to \"([^\"]*)\" details of the newly created draft$")
	    public void user_should_be_able_to_something_details_of_the_newly_created_draft(String strArg1) throws Throwable
	    {
	    	saveAsDraftAllPage.viewDetailsOfNewDraft(strArg1);
	    }
	    
	    @Then("^Check if all the edits made to the drop down feilds for (.+) are reflected on View page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_drop_down_feilds_for_are_reflected_on_view_page_of_saveasdraft_flow(String entity) throws Throwable 
	    {
	    	saveAsDraftAllPage.checkDropdownEdits();
	    }
	    	    
	    @Then("^Check if all the edits made to the input and text feilds for (.+) are reflected on View page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_for_are_reflected_on_view_page_of_saveasdraft_flow(String entity) throws Throwable
	    {
	    	saveAsDraftAllPage.checkInputEdits();
	    }
	    
	    @Then("^User clicks the Next Button on SaveAsDraft flow$")
	    public void user_clicks_the_next_button_on_saveasdraft_flow() throws Throwable 
	    {
	    	try
	    	{
				myElement = (WebElement)saveAsDraftAllPage
						.executeJavaScriptWithRefresh("return document.querySelector('brml-button[type=\"submit\"]')");
				action.scrollToElement(myElement);
				action.click(myElement);
				Reporter.addStepLog("Clicked on Next button");
				action.waitForPageLoad();
	    	}
	    	catch (Exception e) 
	    	{
	    		Assert.fail("Unable to access the Next button");
			}
	    }
	    
	    @Then("^User clicks the Submit Button on SaveAsDraft flow$")
	    public void user_clicks_the_submit_button_on_saveasdraft_flow() throws Throwable 
	    {
	    	try
	    	{
				Thread.sleep(2000);
				myElement = (WebElement)action
						.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
				action.scrollToElement(myElement);
				action.click(myElement);
				Reporter.addStepLog("Clicked on Submit button");
				Thread.sleep(3000);
				action.waitForPageLoad();
	    	}
	    	catch (Exception e) 
	    	{
	    		Assert.fail("Unable to access the Submit button");
			}
	    }
	    
	    @Then("^User clicks the Done Button on SaveAsDraft flow$")
	    public void user_clicks_the_done_button_on_saveasdraft_flow() throws Throwable
	    {
	    	try
	    	{
				myElement = (WebElement)saveAsDraftAllPage
						.findElementByDynamicXpath("//span[contains(text(),'DONE')]|//brml-button[contains(text(),'DONE')]");
				action.scrollToElement(myElement);
				action.click(myElement);
				Reporter.addStepLog("Clicked on Done button");
				Thread.sleep(3000);
				action.waitForPageLoad();
	    	}
	    	catch (Exception e) 
	    	{
	    		Assert.fail("Unable to access the Done button");
			}
	    }
	    
	    @And("^User clicks on the \"([^\"]*)\" Button of SaveAsDraft flow$")
	    public void user_clicks_on_the_something_button_of_saveasdraft_flow(String strArg1) throws Throwable
	    {
	    	saveAsDraftAllPage.clickButton(strArg1);
	    }
	    
	    @And("^User stores the generated FOA code in excel on SaveAsDraft flow$")
	    public void user_stores_the_generated_foa_code_in_excel_on_saveasdraft_flow() throws Throwable 
	    {
	    	try 
	    	{
	    		saveAsDraftAllPage.checkHeader("Your SMA Single Creation Request Has Been Submitted");
	    		
	    		myValue1 = (String)saveAsDraftAllPage.executeJavaScriptWithoutWait("return document.querySelector(\"h5\").textContent");
				Thread.sleep(2000);
				
				System.out.println(myValue1);
				myValue1 = myValue1.substring(myValue1.length() - 4 );
				
				System.out.println(myValue1);

				
				if(myValue1 != null)
				{
					//saveAsDraftAllPage.writeIntoExcel("SMASingleSWPAAP", "Search for Access FOA Code", myValue1);
				}
			}
			catch(Exception e) 
	    	{
	    		Assert.fail("Unable to access the FOA Code");

	    	}
	    }
	    
	    @And("^Edit all the below drop down fields with index for (.+) with (.+)  data of SaveAsDraft flow$")
	    public void edit_all_the_below_drop_down_fields_with_index_for_with_data_of_saveasdraft_flow(String entity, String scenario, List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.selectDropdownByIndex(entity, scenario, attribute);
	    }
	    
	    @Then("^Edit the below fields of Benchmark Page for (.+) with (.+) entity of SaveAsDraft flow$")
	    public void edit_the_below_fields_of_benchmark_page_for_with_entity_of_saveasdraft_flow(String entity, String scenario, List<Map<String,String>> attribute) throws Throwable
	    {/*
//	    	myElement = (WebElement)saveAsDraftAllPage.executeJavaScript(
//					"return document.querySelector(\"#benchmark\").shadowRoot.querySelectorAll(\"input[name='benchmarl_1']\" && \"input[type='radio']\")[1].parentElement.querySelector('button')");
			
	    	myElement = (WebElement)saveAsDraftAllPage.executeJavaScript(
					"return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(2)\").shadowRoot.querySelector(\"button\")");
	    	action.scrollToElement(myElement);
			
			if(!myElement.isSelected())
			{
				myElement.click();
				saveAsDraftAllPage.deleteAllBins(attribute.size());
			}
			else 
			{
				saveAsDraftAllPage.deleteAllBins(attribute.size());
			}
			
			sheetName = entity;
			sheet = exlObj.getSheet(sheetName);
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_"+UIEnvironment);
			
			if(!entity.equalsIgnoreCase("Style"))
			{
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0,"Custom BM Reason");
				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
				myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector('brml-textarea[id=\"txtCustomReasonSet1\"]').shadowRoot.querySelector('textarea')");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				action.clear(myElement);
				saveAsDraftAllPage.sendKeysWithCheck(myElement, myValue);
			}
				
			for(int i = 0; i < attribute.size(); i++)
			{
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get("Dropdown Name"));
				String dropdownValues = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get("Dropdown Percentage"));
				String dropdownPercentages = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
				
				if(dropdownValues.contains(",")) 
				{
					String[] ddValue = dropdownValues.split(",");
					String[] ddpercent = dropdownPercentages.split(",");
					
					if(ddValue.length != ddpercent.length) 
					{
						Assert.fail("The number of benchmarks & percentages don't match");
					}
					
					int size = ddValue.length;
					int j = 0;
					int sum = 0;
					
					
					while(size > 0 && size <= 10) 
					{
						String id = attribute.get(i).get("Percentage ID") + j;
						myValue = ddpercent[j];
						sum = sum + Integer.parseInt(myValue);
						
						if(sum != 100 && size == 1) 
						{
							myValue = "100";
						}
						
						saveAsDraftAllPage.enterPercentage(id, myValue);
						Reporter.addStepLog(
								"send keys " + myValue + " for " + attribute.get(i).get("Dropdown Percentage"));
						
						myValue = ddValue[j];
						id = attribute.get(i).get("Dropdown ID") + j;
						myValue1 = saveAsDraftAllPage.selectBMDropdown(id, myValue);
						
						Reporter.addStepLog("Drop down for" + attribute.get(i).get("Dropdown Name") + "selected");
						
						j++;
						size--;
						
						if(sum >= 100 && size !=0)
						{
							break;
						}
						
						if(size > 0 && size != 0)
						{
							if(entity.equalsIgnoreCase("SMASingleAccess") || entity.equalsIgnoreCase("SMADual"))
							{
								if(attribute.get(i).get("Dropdown Name").contentEquals("UnBundled Node ID BM"))
								{
									//updateStrategyPage.clickOnNewAsset();
									saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@id='btnAddunBundledNode']").click();

								}
								else if(attribute.get(i).get("Dropdown Name").contentEquals("Custom Benchmark BM")) 
								{
									//updateStrategyPage.clickOnNewBenchmark();
									saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@id='btnAddSet1']").click();

								}
							}
							
						else
							{
								if(attribute.get(i).get("Dropdown Name").contentEquals("UnBundled Node ID BM"))
								{
									//updateStrategyPage.clickOnNewAsset();
									saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@id='btnAddAssetSet2']").click();
	
								}
								else if(attribute.get(i).get("Dropdown Name").contentEquals("Custom Benchmark BM")) 
								{
									//updateStrategyPage.clickOnNewBenchmark();
									saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@id='btnAddSet1']").click();
	
								}
							}
						}
					}
				}
						else 
						{
							String id = attribute.get(i).get("Percentage ID") + 0;
							saveAsDraftAllPage.enterPercentage(id, "100");
							
							myValue = dropdownValues;
							id = attribute.get(i).get("Dropdown ID") + 0;
							myValue1 = saveAsDraftAllPage.selectBMDropdown(id, myValue);

						}
					}*/
	    	

	    	BenchmarkDetails.clear();
	    	/*excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/Update"+entity+".xlsx";
			this.sheetName = sheetName;
			sheet = new ExcelUtils(ExcelOperation.LOAD, excelFilePath).getSheet(sheetName);*/
	    	
	    	sheetName = entity;
			sheet = exlObj.getSheet(sheetName);	
			saveAsDraftAllPage.deleteAllBins(attribute.size());
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, scenario + UIEnvironment);
		
			/*	if(!entity.equalsIgnoreCase("Style"))
			{
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0,"Custom BM Reason");
				myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
				myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector('brml-textarea[id=\"txtCustomReasonSet1\"]').shadowRoot.querySelector('textarea')");
				action.scrollToElement(myElement);
				action.highligthElement(myElement);
				action.clear(myElement);
				saveAsDraftAllPage.sendKeysWithCheck(myElement, myValue);
			}*/
				
			for(int i = 0; i < attribute.size(); i++)
			{
				if(attribute.get(i).get("Dropdown Name").contentEquals("Custom Benchmark BM"))
				{
					myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(2)\")");
					myElement.click();
				}
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get("Dropdown Name"));
				String dropdownValues = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get("Dropdown Percentage"));
				String dropdownPercentages = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
				
				if(dropdownValues.contains(",")) 
				{
					String[] ddValue = dropdownValues.split(",");
					String[] ddpercent = dropdownPercentages.split(",");
					
					if(ddValue.length != ddpercent.length) 
					{
						Assert.fail("The number of benchmarks & percentages don't match");
					}
					
					int size = ddValue.length;
					int j = 0;
					float sum = 0;
					
					
					while(size > 0 && size <= 10) 
					{
						String id = attribute.get(i).get("Percentage ID") + j;
						myValue = ddpercent[j];
						sum = sum + Float.parseFloat(myValue);
						
						if(sum != 100 && size == 1) 
						{
							myValue = "100";
						}
						
						double percentage = Double.parseDouble((String)saveAsDraftAllPage.enterPercentage(id, myValue));
						Reporter.addStepLog(
								"send keys " + myValue + " for " + attribute.get(i).get("Dropdown Percentage"));
						
						myValue = ddValue[j];
						id = attribute.get(i).get("Dropdown ID") + j;
						myValue1 = saveAsDraftAllPage.selectBMDropdown(id, myValue);
						
						BenchmarkValues.put(myValue1, percentage);
						
						Reporter.addStepLog("Drop down for" + attribute.get(i).get("Dropdown Name") + "selected");
						
						j++;
						size--;
						
						if(sum >= 100 && size !=0)
						{
							break;
						}
						
						if(size > 0 && size != 0)
						{
							if(entity.equalsIgnoreCase("SMASingleAccess") || entity.equalsIgnoreCase("SMADual"))
							{
								if(attribute.get(i).get("Dropdown Name").contentEquals("UnBundled Node ID BM"))
								{
									//updateStrategyPage.clickOnNewAsset();
									//saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@id='btnAddunBundledNode']").click();
									myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#btnAddunBundledNode\")");
									action.jsClick(myElement);
								}
								else if(attribute.get(i).get("Dropdown Name").contentEquals("Custom Benchmark BM")) 
								{
									//updateStrategyPage.clickOnNewBenchmark();
									//saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@id='btnAddSet1']").click();
									myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#btnAddSet1\")");
									action.jsClick(myElement);
								}
							}
							
						else
							{
								if(attribute.get(i).get("Dropdown Name").contentEquals("UnBundled Node ID BM"))
								{
									//updateStrategyPage.clickOnNewAsset();
									//saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@id='btnAddAssetSet2']").click();
									myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#btnAddAssetSet2\")");
									action.jsClick(myElement);
								}
								else if(attribute.get(i).get("Dropdown Name").contentEquals("Custom Benchmark BM")) 
								{
									//updateStrategyPage.clickOnNewBenchmark();
									//saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@id='btnAddSet1']").click();
									myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#btnAddSet1\")");
									action.jsClick(myElement);
								}
							}
						}
					}
				}
						
				else 
				{
					String id = attribute.get(i).get("Percentage ID") + 0;
					saveAsDraftAllPage.enterPercentage(id, "100");
					
					myValue = dropdownValues;
					id = attribute.get(i).get("Dropdown ID") + 0;
					myValue1 = saveAsDraftAllPage.selectBMDropdown(id, myValue);
					
					BenchmarkValues.put(myValue1, 100d);

				}
						
			BenchmarkDetails.put(attribute.get(i).get("Dropdown Name"), saveAsDraftAllPage.addValues1(BenchmarkDetails,attribute.get(i).get("Dropdown Name"), BenchmarkValues));
			BenchmarkValues.clear();					
			}
			System.out.println("final Map "+Arrays.asList(BenchmarkDetails));
	    }
	    

	    @And("^User selects the benchmark category as \"([^\"]*)\" during SaveAsDraft flow$")
	    public void user_selects_the_benchmark_category_as_something_during_saveasdraft_flow(String strArg1) throws Throwable
	    {
	    	saveAsDraftAllPage.selectBenchmarkType(strArg1);
	    }
	    
	    @Then("^User clicks on the Cancel Button on the Save As Draft wizard$")
	    public void user_clicks_on_the_cancel_button_on_the_save_as_draft_wizard() throws Throwable 
	    {
	    	try
	    	{
		    	myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector('brml-button[variant=\"secondary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");
				action.jsClick(myElement);
				Reporter.addStepLog("Cancel button is clicked on the draft window");
	    	}
	    	catch (Exception e)
	    	{
	    		Assert.fail("Unable to access the Cancel button");
			}
	    }
	    
	    @Then("^user should be redirected to \"([^\"]*)\" Page$")
	    public void user_should_be_redirected_to_something_page(String strArg1) throws Throwable
	    {
	    	saveAsDraftAllPage.checkHeader(strArg1);
	    	Thread.sleep(3000);
	    }
	    

	    @Then("^if user enters a invalid draft name \"([^\"]*)\" error message stating \"([^\"]*)\" should be displayed$")
	    public void if_user_enters_a_invalid_draft_name_something_error_message_stating_something_should_be_displayed(String strArg1, String strArg2) throws Throwable 
	    {
	    	try
	    	{				
		    	myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"brml-input[label='Draft Name']\").shadowRoot.querySelector('wf-tooltip > div > div >input')");
				action.jsClick(myElement); 
				saveAsDraftAllPage.myClear(myElement);
				//action.sendKeyCharterWise(myElement, strArg1);
				saveAsDraftAllPage.sendKeysWithCheck(myElement, strArg1);
				
				myElement = (WebElement) saveAsDraftAllPage.executeJavaScript("return document.querySelector('brml-button[variant=\"primary\"]').shadowRoot.querySelector('button[type=\"submit\"]')");
				action.jsClick(myElement);
				
				myElement = (WebElement) saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#provideDraftName\").shadowRoot.querySelector(\"wf-tooltip > div > wf-conditional-animate> div\")");
				System.out.println(myElement.getText());
				System.out.println(strArg2);
			
				Assert.assertTrue(myElement.getText().contains(strArg2), "Error message is valid");
				Reporter.addStepLog("The correct error message is displayed");

	    	}
	    	catch (Exception e)
	    	{
				Assert.fail("Unable to get the error message" );
				
			}
	    }
	    
	    @Then("^user should see that it will hardstop the user from entering more than 255 char length for draft name$")
	    public void user_should_see_that_it_will_hardstop_the_user_from_entering_more_than_255_char_length_for_draft_name() throws Throwable
	    {
	    	myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"brml-input[label='Draft Name']\").shadowRoot.querySelector('wf-tooltip > div > div >input')");
			action.jsClick(myElement);
			
			while(true)
			{
				draftName = draftName + draftName;
				//System.out.println(draftName);
				
				if(draftName.length()>256)
				{
					draftName = draftName.substring(0, 255);
					break;
				}
			}
			
			saveAsDraftAllPage.sendKeysWithCheck(myElement, draftName);
			myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#provideDraftName\")");
			Assert.assertTrue(myElement.getAttribute("value").length()==255, "Max lenght complexity is valid");
	    }
	    
	    @Then("^the created draft should not be shown via Global search$")
	    public void the_created_draft_should_not_be_shown_via_global_search() throws Throwable
	    {
	    	saveAsDraftAllPage.globalSearchDraft();
	    }
	    

	    @And("^the created draft should not be shown in \"([^\"]*)\" tab view$")
	    public void the_created_draft_should_not_be_shown_in_something_tab_view(String strArg1) throws Throwable
	    {
	    	saveAsDraftAllPage.checkDraftInTab(strArg1);
	    }
	    
	    
	    @Then("^User clicks on \"([^\"]*)\" Button of SaveAsDraft flow$")
	    public void user_clicks_on_something_button_of_saveasdraft_flow(String strArg1) throws Throwable 
	    {
	    	try
	    	{
		    	saveAsDraftAllPage.clickButton(strArg1);
	    	}
	    	catch (Exception e) 
	    	{
	    		Assert.fail("Unable to access "+strArg1);
	    	}
	    }
	    
	    @Then("^User clicks on financial advisor on create financial advisor window$")
	    public void user_clicks_on_financial_advisor_on_create_financial_advisor_window() throws Throwable
	    {
	    	try 
	    	{
				myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#financialAdvisor > brml-radio-option:nth-child(1)\").shadowRoot.querySelector(\"button\")");
				myElement.click();
				Thread.sleep(2000);
				myElement = saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@variant='primary']");
				myElement.click();
			}
			catch(Exception e) 
	    	{
				Assert.fail("Unable to access financial advisor");
	    	}
	    }
	    
	    @Then("^User clicks on financial advisor team on create financial advisor window$")
	    public void user_clicks_on_financial_advisor_team_on_create_financial_advisor_window() throws Throwable 
	    {
	    	try 
	    	{
				myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#financialAdvisor > brml-radio-option:nth-child(2)\").shadowRoot.querySelector(\"button\")");
				myElement.click();
				Thread.sleep(2000);
				myElement = saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@variant='primary']");
				myElement.click();
			}
			catch(Exception e) 
	    	{
				Assert.fail("Unable to access financial advisor team");
	    	}
	    }
	    
	    @And("^Edit all the below date fields with valid data for (.+) entity of SaveAsDraft flow$")
	    public void edit_all_the_below_date_fields_with_valid_data_for_entity_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.editDateFields(entity, attribute);
	    }
	    
	    @Given("^User is accessing DB for verifying the data$")
	    public void user_is_accessing_db_for_verifying_the_data() throws Throwable
	    {
	    	try
	    	{
		    	saveAsDraftAllPage.verifyDBValues();
			}
			catch(Exception e)
	    	{
				Assert.fail("Something went wrong while accessing Data" );
			}
			
	    }
	    
	    public static Map<String, Object> parseJSONObjectToMap (JSONObject jsonObject)  
	    {
	    	Map<String, Object> mapData = new HashMap<String, Object>();
			Iterator<String> keysIterator = jsonObject.keys();
			
			while(keysIterator.hasNext())
			{
				String key = keysIterator.next();
				Object value = jsonObject.get(key);
				
				if(value instanceof JSONArray )
				{
					value = parseJSONArrayToList((JSONArray) value);
				}
				
				else if(value instanceof JSONObject )
				{
					value = parseJSONObjectToMap((JSONObject) value);
				}
				
				mapData.put(key, value);
			}
			
			return mapData;
	    }
	    
	    public static List<Object> parseJSONArrayToList (JSONArray array)  
	    {
			List<Object> list = new ArrayList<Object>();
			
			for(int i=0; i < array.size();i++)
			{
				Object value = array.get(i);
				
				if(value instanceof JSONArray )
				{
					value = parseJSONArrayToList((JSONArray) value);
				}
				
				else if(value instanceof JSONObject )
				{
					value = parseJSONObjectToMap((JSONObject) value);
				}
				
				list.add(value);
			}
			
			return list;
	    }

	    @And("^Edit FAIDs feild with search \"([^\"]*)\" of SaveAsDraft flow$")
	    public void edit_faids_feild_with_search_something_of_saveasdraft_flow(String strArg1) throws Throwable
	    {
	    	saveAsDraftAllPage.editFAIDs(strArg1);
	    }
	    
	    @Then("^User should see the Save as a draft header on the Save as draft window$")
	    public void user_should_see_the_save_as_a_draft_header_on_the_save_as_draft_window() throws Throwable 
	    {
	    	try 
	    	{
	    		myValue = (String)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#nonDetachedModal > header > span\").textContent");
	    		Assert.assertEquals(myValue, "Save as a draft","Save as a draft header is not displayed");
				Reporter.addStepLog("The correct header message is displayed");		
			}
			catch(Exception e) 
	    	{
				Assert.fail("Unable to access Save as a draft header");
			}
	    }
	    
	    @And("^User clicks the Continue Editing Button of SaveAsDraft flow$")
	    public void user_clicks_the_continue_editing_button_of_saveasdraft_flow() throws Throwable
	    {
	    	myElement = saveAsDraftAllPage.findElementByDynamicXpathWithRefresh("//span[contains(text(),'CONTINUE EDITING')]");
	    	action.scrollToElement(myElement);
	    	action.highligthElement(myElement);
	    	myElement.click();
			action.waitForPageLoad();
	    }
	    
	    @Then("^Check if all the edits made to the input and text feilds for (.+) are reflected on Enter Details page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_for_are_reflected_on_enter_details_page_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {    	
	    	saveAsDraftAllPage.checkInputEditsOnEnterDetailsPage(entity, attribute);
	    }
	    
	    @Then("^Check if all the edits made to the drop down feilds for (.+) are reflected on Enter Details page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_drop_down_feilds_for_are_reflected_on_enter_details_page_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.checkDropdownEditsOnEnterDetailsPage(entity, attribute);
	    }
	    
	    @Then("^Check if all the edits made to the check box feilds for (.+) are reflected on Enter Details page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_check_box_feilds_for_are_reflected_on_enter_details_page_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.checkCheckBoxEditsOnUpdatePage(entity,attribute);
	    }
	    
	    @Then("^Check if all the edits made the below fields of Benchmark Page for (.+) are reflected on SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_the_below_fields_of_benchmark_page_for_are_reflected_on_saveasdraft_flow(String entity,List<Map<String,String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.checkBenchmarkEditsOnUpdateFlow(BenchmarkDetails,entity, attribute);
	    }
	    
	    @Then("^Check if all the edits made to the input feilds for (.+) are reflected on Proxy Page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_proxy_page_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.checkProxyEditsOnUpdatePage(attribute);
	    }
	    
	    @Then("^Check if all the edits made to the input feilds for (.+) are reflected on Documents Page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_documents_page_of_saveasdraft_flow(String entity) throws Throwable
	    {
	    	saveAsDraftAllPage.checkDocumentEditsOnUpdatePage();
	    }
	    
	    @Then("^Check if all the edits made to the input feilds for (.+) are reflected on Comments Page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_input_feilds_for_are_reflected_on_comments_page_of_saveasdraft_flow(String entity) throws Throwable
	    {
	    	saveAsDraftAllPage.checkCommentsEditsOnUpdatePage();
	    }
	    
	    @And("^Now the draft should not be displayed on draft view$")
	    public void now_the_draft_should_not_be_displayed_on_draft_view() throws Throwable 
	    {
	    	try 
	    	{
		    	saveAsDraftAllPage.draftNotVisible();
			}
	    	
	    	catch(Exception e)
		    {
				Assert.fail("Unable to access draft view");
		    }

	    }
	    
	    @Then("^User clicks on (.+) on create strategy window$")
	    public void user_clicks_on_on_create_strategy_window(String entity) throws Throwable
	    {
	    	try 
	    	{
	    		switch(entity) 
	    		{
					case "PMP":
					{
						myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#program > wf-radio-option:nth-child(1)\").shadowRoot.querySelector(\"button\")");
						myElement.click();
						Thread.sleep(2000);
						break;
					}
					
					case "SMASingleAccess":
					{
						myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#program > wf-radio-option:nth-child(2)\").shadowRoot.querySelector(\"button\")");
						myElement.click();
						Thread.sleep(2000);
						break;
					}
					
					case "SMASingleSWPAAP":
					{
						myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#program > wf-radio-option:nth-child(3)\").shadowRoot.querySelector(\"button\")");
						myElement.click();
						Thread.sleep(2000);
						break;
					}
					
					case "SMADual":
					{
						myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#program > wf-radio-option:nth-child(4)\").shadowRoot.querySelector(\"button\")");
						myElement.click();
						Thread.sleep(2000);
						break;
					}

					default:
						break;
				}
			
				myElement = saveAsDraftAllPage.findElementByDynamicXpath("//brml-button[@variant='primary']");
				myElement.click();
			}
			catch(Exception e) 
	    	{
				Assert.fail("Unable to access Strategy");
	    	}

	    }
	    
	    @And("^User checks the attestation check box$")
	    public void user_checks_the_attestation_check_box() throws Throwable 
	    {
	    	myElement = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector(\"#acceptedCheckBox\").shadowRoot.querySelector(\"button\")");
			action.highligthElement(myElement);
	    	myElement.click();
			Thread.sleep(2000);
	    }
	    
	    @Then("^Update all the below input fields with valid data for (.+) entity of SaveAsDraft flow$")
	    public void update_all_the_below_input_fields_with_valid_data_for_entity_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	//saveAsDraftAllPage.updateInputFields(entity, attribute);
	    }
	    
	    @And("^Update all the below drop down fields with valid data for (.+) entity of SaveAsDraft flow$")
	    public void update_all_the_below_drop_down_fields_with_valid_data_for_entity_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.updateDropdownFields(entity, attribute);
	    }
	    
	    @Then("^Update all the below dropdown fields with valid data using index for (.+) entity of SaveAsDraft flow$")
	    public void update_all_the_below_dropdown_fields_with_valid_data_using_index_for_entity_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.updateDropdownFieldsByIndex(entity, attribute);
	    }
	    @And("^Update all the text fields with valid data for (.+) entity of SaveAsDraft flow$")
	    public void update_all_the_text_fields_with_valid_data_for_entity_of_saveasdraft_flow(String entity,List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.updateTextFields(entity, attribute);
	    }
	    
	    @And("^User saves the draft of SaveAsDraft flow$")
	    public void user_saves_the_draft_of_saveasdraft_flow() throws Throwable 
	    {
	    	try
	    	{			
	    		saveAsDraftAllPage.saveDraftSecond();

	    	}
	    	catch (Exception e)
	    	{
				Assert.fail("Unable to save the Draft" );
				
			}
	    }
	    
	    @Then("^User Edits all the below fields of Proxy Details for (.+) with \"([^\"]*)\" data of SaveAsDraft flow$")
	    public void user_edits_all_the_below_fields_of_proxy_details_for_with_something_data_of_saveasdraft_flow(String entity, String strArg1, List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.editProxyDetails(entity, strArg1, attribute);
	    }
	 
	    @And("^Edit all the below check boxes of (.+) with (.+) data of SaveAsDraft flow$")
	    public void edit_all_the_below_check_boxes_of_with_data_of_saveasdraft_flow(String entity, String scenario, List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.editCheckBox(entity, scenario, attribute);
	    }
	    
	    @Then("^Check if all the edits made to the input and text feilds on Proxy Details page are reflected on View page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_proxy_details_page_are_reflected_on_view_page_of_saveasdraft_flow() throws Throwable
	    {
	    	saveAsDraftAllPage.checkProxyEdits();	    
	    }
	    
	    @Then("^User searches with the Access FOA code of SaveAsDraft flow$")
	    public void user_searches_with_the_access_foa_code_of_saveasdraft_flow() throws Throwable 
	    {
	    	saveAsDraftAllPage.searchAccessFOACode();
	    }
	    
	    @Then("^Store all the below fields of Benchmark Page of SaveAsDraft flow$")
	    public void store_all_the_below_fields_of_benchmark_page_of_saveasdraft_flow(List<Map<String,String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.storeBenchmarkDetails(attribute);
	    }
	    
	    @Then("^Store all the below fields of Proxy Page of SaveAsDraft flow$")
	    public void store_all_the_below_fields_of_proxy_page_of_saveasdraft_flow(List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.storeProxyDetails(attribute);
	    }
	    
		@Then("^User edits all the details of Documents Page of (.+) with (.+) data of SaveAsDraft flow$")
		public void user_edits_all_the_details_of_documents_page_of_with_data_of_saveasdraft_flow(String entity,String scenario) throws Throwable 
		{
			dataList.clear();
			attributeLists.clear();
			myElement = saveAsDraftAllPage.findElementByDynamicXpath("//*[contains(text(),'DOCUMENT LINK')]");
			
			if(myElement.isEnabled())
			{
				myElement.click();
			}
			
			dataList.add(0, "Document Type");
			dataList.add(1, "documentType");
			attributeLists.add(0, dataList);
			saveAsDraftAllPage.editDropDownFields(entity, scenario, attributeLists);
			
			dataList.set(0, "Document Link");
			dataList.set(1, "documentLink");
			attributeLists.set(0, dataList);
			saveAsDraftAllPage.editInputFields(entity, scenario, attributeLists);
			
			dataList.set(0, "Document Description");
			dataList.set(1, "documentDescription");
			attributeLists.set(0, dataList);
			saveAsDraftAllPage.editTextFields(entity, scenario, attributeLists);
			
			myElement = saveAsDraftAllPage.findElementByDynamicXpath("//wf-button[contains(text(),'DOCUMENT LINK')]");
			myElement.click();
		}
	    
		@Then("^User edits all the details of Comments Page of (.+) with (.+) data of SaveAsDraft flow$")
		public void user_edits_all_the_details_of_comments_page_of_with_data_of_saveasdraft_flow(String entity,String scenario) throws Throwable
		{
			dataList.clear();
			attributeLists.clear();
			myElement = saveAsDraftAllPage.findElementByDynamicXpath("//*[contains(text(),'COMMENT')]");
			
			if(myElement.isEnabled()) 
			{
				myElement.click();
			}
			
			dataList.add(0, "Comment Type");
			dataList.add(1, "commentType");
			attributeLists.add(0, dataList);
			saveAsDraftAllPage.editDropDownFields(entity, scenario, attributeLists);
			
			dataList.set(0, "Comment Description");
			dataList.set(1, "comments");
			attributeLists.set(0, dataList);
			saveAsDraftAllPage.editTextFields(entity, scenario, attributeLists);
			
			myElement = saveAsDraftAllPage.findElementByDynamicXpath("//wf-button[contains(text(),'COMMENT')]");
			myElement.click();
		}
	    
	    @Then("^Store all the fields of Documents Page for SaveAsDraft flow$")
	    public void store_all_the_fields_of_documents_page_for_saveasdraft_flow() throws Throwable 
	    {
	    	saveAsDraftAllPage.storeDocumentsDetails();
	    }
	    
	    @Then("^Store all the fields of Comments Page for SaveAsDraft flow$")
	    public void store_all_the_fields_of_comments_page_for_saveasdraft_flow() throws Throwable
	    {
	    	saveAsDraftAllPage.storeCommentsDetails();
	    }
	    
	    @Then("^Check if all the edits made to the input and text feilds on Documents page are reflected on View page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_documents_page_are_reflected_on_view_page_of_saveasdraft_flow() throws Throwable
	    {
	    	saveAsDraftAllPage.checkDocumentEdits();
	    }
	    
	    @Then("^Check if all the edits made to the input and text feilds on Comments page are reflected on View page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_comments_page_are_reflected_on_view_page_of_saveasdraft_flow() throws Throwable
	    {
	    	saveAsDraftAllPage.checkCommentsEdits();
	    }
	    
	    @Then("^Check if all the edits made to the Benchmark feilds for (.+) are reflected on View page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_benchmark_feilds_for_are_reflected_on_view_page_of_saveasdraft_flow(String entity) throws Throwable 
	    {
	    	try 
	    	{
//	    		if(!BenchmarkDetails.isEmpty()) 
//	    		{
	    			saveAsDraftAllPage.checkBenchmarkEdits(BenchmarkDetails,entity);
//				}
//	    		else
//	    		{
//	    			saveAsDraftAllPage.checkNonCustomBenchmarkEdits(entity);
//				}
			}
			catch(Exception e) 
	    	{
				Assert.fail("Unable to access Benchmark Details");
			}
	    }
	    
	    @Then("^Edit all the below fields of Contact Details page for (.+) with (.+) data of SaveAsDraft flow$")
	    public void edit_all_the_below_fields_of_contact_details_page_for_with_data_of_saveasdraft_flow(String entity, String scenario,List<List<String>> attribute) throws Throwable
	    {
	    	saveAsDraftAllPage.editContactDetails(entity, scenario,attribute);
	    }
	    
	    @Then("^Check if all the edits made to the contact feilds for (.+) are reflected on View page of SaveAsDraft flow$")
	    public void check_if_all_the_edits_made_to_the_contact_feilds_for_are_reflected_on_view_page_of_saveasdraft_flow(String entity) throws Throwable
	    {
	    	saveAsDraftAllPage.checkContactEdits();
	    }
	    
	    @Then("^Store the \"([^\"]*)\" in the (.+) for \"([^\"]*)\" of (.+) on the SaveAsDraft flow$")
	    public void store_the_something_in_the_for_something_of_on_the_saveasdraft_flow(String strArg1, String searchcode, String strArg2, String scenario) throws Throwable
	    {
	    	saveAsDraftAllPage.writeIntoExcel(strArg2, searchcode, InputValues.get(strArg1), scenario);
	    }
	    
	    @Then("^User clicks on \"([^\"]*)\" tab of SaveAsDraft flow$")
	    public void user_clicks_on_something_tab_of_saveasdraft_flow(String strArg1) throws Throwable
	    {
	    	saveAsDraftAllPage.clickTabs(strArg1);
	    }
	    
	    @And("^User should be able to \"([^\"]*)\" details of the (.+) taken from (.+) draft using the column \"([^\"]*)\" with (.+)$")
	    public void user_should_be_able_to_something_details_of_the_taken_from_draft_using_the_column_something_with(String option, String searchCode,  String entity, String columnName,String scenario) throws Throwable
	    {
        	saveAsDraftAllPage.viewEdit(entity, searchCode, columnName, option,scenario);
	    }
	    
	    @Then("^User checks for benchmark elements$")
	    public void user_checks_for_benchmark_elements() throws Throwable 
	    {
	    	Thread.sleep(10000);
	    	myElement = (WebElement)saveAsDraftAllPage.executeJavaScript(
					"return document.querySelector(\"#benchmark-mode-selectionbenchmark1 > wf-radio-option:nth-child(2)\").shadowRoot.querySelector(\"button\")");
	    	myElement.click();
	    	Thread.sleep(5000);
	    	myElement1 = (WebElement)saveAsDraftAllPage.executeJavaScript("return document.querySelector('brml-select[id=\"ddlBenchmarkSet1-0\"]').shadowRoot.querySelector('wf-input')");
	    	myElement1.click();
	    	Thread.sleep(5000);
	    	
	    	String[] benchStrings= {"Cash - Barclays Sht Trsy 1-3mth",
	    			"Cash - Barclays Treasury 5-7Y",
	    			"Cash - BofA Trsy 0-3 Month",
	    			"Cash - US Treasury Bill - 3 Mos",	
	    			"Commodities - DJ UBS Commodity",
	    			"Commodities - DJ UBS Precious Metals",
	    			"Commodities - Goldman Sachs Commodity",
	    			"Commodities - NYSE Arca Gld Miners",
	    			"Equity - Alerian MLP Index - PR",
	    			"Equity - Alerian MLP Index - TR",
	    			"Equity - Bloomberg Prec Metals-PR",
	    			"Equity - DJ Global US Technology",
	    			"Equity - DJ Select Dividend",
	    			"Equity - Dow Jones Ind Avg",
	    			"Equity - FTSE EPRA/NAREIT Dev REIT",
	    			"Equity - FTSE EPRA/NAREIT Dev xUS",
	    			"Equity - MSCI ACWI xUSA-NR",
	    			"Equity - MSCI AC World - GR",
	    			"Equity - MSCI AC World - NR",
	    			"Equity - MSCI AC World xUS",
	    			"Equity - MSCI Canada-NR",
	    			"Equity - MSCI EAFE-Gr",
	    			"Equity - MSCI EAFE-NR",
	    			"Equity - MSCI Emerging Markets-GR",
	    			"Equity - MSCI Emerging Markets-NR",
	    			"Equity - MSCI EMU-NR",
	    			"Equity - MSCI UK-NR",
	    			"Equity - MSCI US Broad Mkt",
	    			"Equity - MSCI US SmlCap Val-PR",
	    			"Equity - MSCI World",
	    			"Equity - MSCI World-NR",
	    			"Equity - MSCI World xUSA-NR",
	    			"Equity - NAREIT Equity",
	    			"Equity - NASDAQ 100-PR",
	    			"Equity - NASDAQ 100 Tech",
	    			"Equity - NASDAQ Biotech",
	    			"Equity - NASDAQ Composite",
	    			"Equity (Real Estate) - DJ US Select REIT",
	    			"Equity (Real Estate) - FTSE NAREIT RealEst50-PR",
	    			"Equity (Real Estate) - S&P United States REIT",
	    			"Equity - Russell 1000",
	    			"Equity - Russell 1000 Growth",
	    			"Equity - Russell 1000 Value",
	    			"Equity - Russell 2000",
	    			"Equity - Russell 2500",
	    			"Equity - Russell 2500 Growth",
	    			"Equity - Russell 3000",
	    			"Equity - Russell 3000 Growth",
	    			"Equity - Russell 3000 Healthcare",
	    			"Equity - Russell 3000 Tech",
	    			"Equity - Russell 3000 Value",
	    			"Equity - Russell Mid Cap",
	    			"Equity - Russell Mid Cap Growth",
	    			"Equity - S&P 400 Mid Cap",
	    			"Equity - S&P 500",
	    			"Equity - S&P 500 NET",
	    			"Equity - S&P 500 Value",
	    			"Equity - S&P ADR",
	    			"Equity - S&P Energy",
	    			"Equity - S&P Financials",
	    			"Equity - S&P Gbl 1200/Info Tech",
	    			"Equity - S&P Gbl BMI/Energy-PR",
	    			"Equity - S&P Global 1200",
	    			"Equity - S&P Global 1200 Sec/Fin",
	    			"Equity - S&P Health Care",
	    			"Equity - S&P HghYl Div Aristocrats",
	    			"Equity - S&P Info Tech",
	    			"Equity - S&P NAmerican Tech",
	    			"Equity - S&P US Preferred Stk",
	    			"Equity - S&P Utilities",
	    			"Fixed Income - Barclays Agg Bond",
	    			"Fixed Income - Barclays Agg Gov/Cd 5-10Y",
	    			"Fixed Income - Barclays Corp 1-3Y",
	    			"Fixed Income - Barclays Emerg Mkt Agg",
	    			"Fixed Income - Barclays Euro Aggregate",
	    			"Fixed Income - Barclays Gbl Ag Can FA 30",
	    			"Fixed Income - Barclays Gbl Agg Bond xUS",
	    			"Fixed Income - Barclays Global Agg",
	    			"Fixed Income - Barclays Govt/Credit",
	    			"Fixed Income - Barclays Govt/Credit 1-3Y",
	    			"Fixed Income - Barclays Govt/Credit 1-5Y",
	    			"Fixed Income - Barclays Govt/Credit Int",
	    			"Fixed Income - Barclays Govt  Interm",
	    			"Fixed Income - Barclays Muni 1-10Y BL",
	    			"Fixed Income - Barclays Muni 20Y",
	    			"Fixed Income - Barclays Muni 3-15Y BL",
	    			"Fixed Income - Barclays Muni 3Y",
	    			"Fixed Income - Barclays Muni 5Y",
	    			"Fixed Income - Barclays Muni 7Y",
	    			"Fixed Income - Barclays Municipal Bond",
	    			"Fixed Income - Barclays Municipal Long",
	    			"Fixed Income - Barclays Muni Mgd Mny 1-5",
	    			"Fixed Income - Barclays Treasury 1-3Y",
	    			"Fixed Income - Barclays US Agg 1-5Y",
	    			"Fixed Income - Barclays US Agg Cd/Cp HY",
	    			"Fixed Income - Barclays US Agg Credit",
	    			"Fixed Income - Barclays US Agg Govt",
	    			"Fixed Income - Barclays US Agg Interm",
	    			"Fixed Income - Barclays US Ag G/T 7-10Y",
	    			"Fixed Income - Barclays US Ag G/T Interm",
	    			"Fixed Income - Barclays US Corp HY",
	    			"Fixed Income - Barclays US Gov 1-3Y",
	    			"Fixed Income - Barclays US Sec MBS",
	    			"Fixed Income - Barclays US Universal",
	    			"Fixed Income - BofA Corp 1-5Y AAA-A",
	    			"Fixed Income - BofA HYield Cash Pay",
	    			"Fixed Income - BofA HY Master II",
	    			"Fixed Income - BofA Muni 7-12Y",
	    			"Fixed Income - BofA Muni Core Cal",
	    			"Fixed Income - BofA MuniSecurities 1-12Y",
	    			"Fixed Income - BofA Pref Stk Fixed Rt",
	    			"Fixed Income - BofA US Corp 1-10A-AAA",
	    			"Fixed Income - JP Morgan EMBI Gbl Dvsfd",
	    			"Fixed Income - S&P National Muni Bd",
	    			"Non-Traditional - HFRX Global Hedge Fund",
	    			"Non-Traditional - HFRX Macro"};
	    	
	    	List<String> bmList = Arrays.asList(benchStrings);
			myElements = saveAsDraftAllPage.getDynamicElementsFromShadowRoot("return document.querySelector('brml-select[id=\"ddlBenchmarkSet1-0\"]').shadowRoot.querySelectorAll('li')");

			System.out.println(benchStrings.length);
	    	System.out.println(bmList);
	    	System.out.println(myElements.size());
	    	
	    	int i=0,j=0;
	    	
	    	for(WebElement E : myElements) 
			{
	    		
				if(bmList.contains(E.getText()))
				{
					System.out.println("contains     "+E.getText());
			    	Thread.sleep(1000);
			    	i++;
				}
				else 
				{
					System.out.println("doesn't contains "+E.getText());
			    	Thread.sleep(1000);
			    	j++;
				}
			}
	    	Thread.sleep(5000);
	    	System.out.println("contains this number "+i);
	    	System.out.println("doesnot contains this number "+j);

	    }
	}
