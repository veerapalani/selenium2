package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStrategyConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStrategyEnterStrategyDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class RejectedStrategyConfirmationStepDef {

	RejectedStrategyConfirmationPage confirmationPage = new RejectedStrategyConfirmationPage("AD_PM_RejectedStrategyConfirmationPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
	XSSFSheet sheet;
	int rowIndex;
	String sheetName;
	String strategyId,category = "";
	String userInfo = "";
	String label, attributeValue, uiValue,dbValue = null;
	String strategyStatus = "";
	
	@Then("^(.+) should be able to see Confirmation Page in Rejected Strategy Resubmission Flow$")
    public void should_be_able_to_see_confirmation_page_in_rejected_strategy_resubmission_flow(String typeofuser) {
		Assert.assertTrue(confirmationPage.isUserOnConfirmationPage());
		strategyStatus = "Eligible";
		userInfo = typeofuser;
    }
	

	@And("^Data given (.+) while Resubmitting a Rejected Strategy should be stored in Data Base$")
    public void data_given_while_resubmitting_a_rejected_strategy_should_be_stored_in_data_base(String mandatorydetails) throws SQLException {
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		
				//confirmationPage.getFAID();
		String[] temp = null;
		String tName = Thread.currentThread().getName();
		synchronized (tName) {

			mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			strategyId = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 48);
			int reviewDataIndex = rowIndex+4;

			String excelData;
			List<String> excelDataGiven = new ArrayList<String>();
			int cellnum = 3;
			int i = 3;

			String label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
			if (label == "")
				label = "isEmpty";
			while (label != "isEmpty") {

				excelData = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, reviewDataIndex, i);

				if (excelData == "") {
					excelData = "isEmpty";
				}
				
				if(label.contains("checkbox - Hide Strategy"))
				{
					if(userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
						label = "ignore";
					}
				}
				if(label.contains("FA Email"))
				{
						label = "ignore";
				}
				
				if (label.contains("ignore")) {
					cellnum++;
					i++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
					if (label == "")
						label = "isEmpty";
				} else {
					
					
					excelDataGiven.add(excelData);
					// System.out.println(excelData+"--"+label+ " -Data from Excel");

					cellnum++;
					i++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
					if (label == "")
						label = "isEmpty";

				}

			}

			pmdb.DBConnectionStart();

	    	String SQLquery, labelname = null;
	    	String dbDataIterator = "testNull";
	    	List<String> dbData = new ArrayList<String>();
	    	ResultSet rs;
	    	
	    	
	    	sheetName = "SQLQuery";
	    	
	    	cellnum = 1;
	    	label  =  PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
	    			//(String) exlObj.getCellData(sheet, cellnum, 0).toString();
	    	ArrayList<String> tempData = new ArrayList<String>();
	    	
			if(label == "")
				label = "isEmpty";
			
			while (label != "isEmpty") {
				
				if(label.contains("Hide Strategy"))
				{
					if(userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
						label = "ignore";
					}
				}
				if(label.contains("FA Email"))
				{
						label = "ignore";
				}
				
				if(label.contains("ignore")) {
					cellnum++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
							//(String) exlObj.getCellData(sheet, cellnum, 0);
						if(label == "")
							label = "isEmpty";
				}
				else {
					
					dbDataIterator = "testnull";
					SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
							//(String) exlObj.getCellData(sheet, cellnum, 1);
					labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
							//(String) exlObj.getCellData(sheet, cellnum, 2);
					
		    		SQLquery = SQLquery.replace("@data", "'"+strategyId+"'");
		    		rs= DBManager.executeSelectQuery(SQLquery);
		    		
		   
		    		while(rs.next()) {
		    			
		    				dbDataIterator = rs.getString(labelname);
		    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
			    					dbDataIterator = "isEmpty";
			    					if(label.contains("radiobutton")) {
				    					dbDataIterator = "Not defined";
				    				}
			    			}
		    				tempData.add(dbDataIterator);
		    				
//		    				if(label.contains("BenchmarkCategory")) {
//		    					category = dbDataIterator;
//		    				}
		    				
		    		 }
		    		//to handle Zero records from DB 
		    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
		    			dbDataIterator = "isEmpty";
		    		}
		    		
		    		//to handle DB value if Change of FA Selection happens
		    		if(label.contains("FA Name")) {
		    			if(RejectedStrategyEnterStrategyDetailsPage.getFASelection().equals("faTeam"))
		    				dbDataIterator = "isEmpty";
		    		}
		    		if(label.contains("FA Team Name")) {
		    			if(RejectedStrategyEnterStrategyDetailsPage.getFASelection().equals("fa"))
		    				dbDataIterator = "isEmpty";
		    		}
		    		
		    		//to handle multiple values for same column
		    		if(tempData.size() > 1) {
		    			if(label.contains("Benchmark Name") || label.contains("Percentage")) {
		    				
				    				String benchmark = "",benchmarkPercentage = "";
				    				
				    				dbDataIterator = "";
					    			for (String G : tempData) {
					    				benchmark = benchmark+G.split("-#-")[0]+",";
					    				benchmarkPercentage = benchmarkPercentage+G.split("-#-")[1]+"f,";
									}
					    			benchmark = benchmark.substring(0, benchmark.length()-1);
					    			benchmarkPercentage = benchmarkPercentage.substring(0, benchmarkPercentage.length()-1);
				    				
					    			System.out.println("Final Bechmark :"+benchmark);
					    			System.out.println("Final Percentage :"+ benchmarkPercentage);
				    				//Sorting the Benchmakrs or Percentages
				    				HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
				    				LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
				    				
				    				if(benchmark.contains(",")) {
				    					String[] customBenchmark = benchmark.split(",");
				    					String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
				    					int size = customBenchmark.length;
				    					
				    					for (int j = 0; j < size; j++) {
				    						customBenchmarkMap.put(customBenchmark[j], Float.parseFloat(customBenchmarkPercentage[j]));
				    					}
				    					
				    					sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
				    				}else {
				    					sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
				    				}
				    				
				    				
				    				
				    				if(label.contains("Benchmark Name")) {
				    					
				    					for (String countryKey : sortedHashMap.keySet()) {
					    					  //System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
					    					  dbDataIterator = dbDataIterator+countryKey+",";
										}
						    			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
				    					
				    				}
				    				if(label.contains("Percentage")) {
				    					
				    					for (String countryKey : sortedHashMap.keySet()) {
					    					  //System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
					    					  dbDataIterator = dbDataIterator+String.format("%.2f", sortedHashMap.get(countryKey))+",";
										}
						    			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
				    					
				    				}
				    				
				    				if(category.equalsIgnoreCase("default")) {
				    					dbDataIterator = dbDataIterator.split(",")[0];
				    				}
		    			}else {
				    			Collections.sort(tempData);
				    			dbDataIterator = "";
				    			for (String G : tempData) {
				    				if(label.contains("FA Team Members Detail"))
			    						dbDataIterator = dbDataIterator+G+":";
			    					else
			    						dbDataIterator = dbDataIterator+G+",";
								}
				    			dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
				    	}
		    		}else {
		    			if(label.contains("Benchmark Name")) {
		    				dbDataIterator = dbDataIterator.split("-#-")[0];
		    			}
		    			if(label.contains("Percentage")) {
		    				dbDataIterator = dbDataIterator.split("-#-")[1];
		    			}
		    		}
		    		tempData.clear();
		    		
		    		dbData.add(dbDataIterator);
					cellnum++;
		    		label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
		    		if(label == "")
		    			label = "isEmpty";
				}
				
				
			}
			
			//exlObj.closeWorkBook();
			//pmdb.DBConnectionClose();

			cellnum = 1;
			int listno = 1;
			Boolean flag = true;
			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
			if (label == "")
				label = "isEmpty";
			while (label != "isEmpty") {

				if(label.contains("Hide Strategy"))
				{
					if(userInfo.contains("Branch") || userInfo.toLowerCase().contains("bruser")) {
						label = "ignore";
					}
				}
				if(label.contains("FA Email"))
				{
						label = "ignore";
				}
				
				flag = true;
				if (label.contains("ignore")) {
					cellnum++;
					//listno++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if (label == "")
						label = "isEmpty";
				} else {

					try {
						 System.out.println(label +" :DB -- "+ dbData.get(listno - 1));
						 System.out.println(label +" :Excel -- "+ excelDataGiven.get(listno - 1));
						String message = label + " :DB -- " + dbData.get(listno - 1) + "::::" + label + " :Excel -- "+ excelDataGiven.get(listno - 1)+" -- for FA ID -- "+strategyId;
						
						if(label.contains("FA Team Members Detail") && !dbValue.equalsIgnoreCase("isEmpty")) {
							String fATeamMemberNamesfromUI = attributeValue;
							String fATeamMemberNamesfromDB = dbValue;
							String[] temporaryValues = dbValue.split(":");
							if(fATeamMemberNamesfromDB.replace(":", ", ").length() == fATeamMemberNamesfromUI.length()) {
								for(String string: temporaryValues) {
									if(!fATeamMemberNamesfromUI.contains(string));
										flag = false;
								}
								if (flag == true) {
									excelDataGiven.set(listno - 1, dbData.get(listno - 1));
								}
							}
							
						}
						
						if(label.equalsIgnoreCase("Status")) {
							
							if(strategyStatus.equalsIgnoreCase("eligible")) {
								assertTrue(dbData.get(listno - 1).equals("Eligible"), message);
							}else if(strategyStatus.equalsIgnoreCase("pending ho approval")) {
								assertTrue(dbData.get(listno - 1).equals("Pending HO Approval"), message);
							}
							
						}else if(label.equalsIgnoreCase("PMP Submission Date")) {
							//Not Comparing the value just ignoring it
						}else
							assertTrue(dbData.get(listno - 1).equals(excelDataGiven.get(listno - 1)), message);
					} catch (Exception e) {
						// Data Base value is not same as value provided
						Reporter.addStepLog("Data Base value is not same as value provided");
					}

					cellnum++;
					listno++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if (label == "")
						label = "isEmpty";
				}
			}

		}
    }
	
//	@Then("^Branch User should be able to see (.+) in Confirmation Page in Rejected Strategy Resubmission Flow$")
//    public void branch_user_should_be_able_to_see_in_confirmation_page_in_rejected_strategy_resubmission_flow(String confirmationmessage) {
//        
//    }
	
	private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
		Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		//System.out.println(entryList.get(0).getKey());
		//System.out.println(entryList.get(0).getKey().split(" - ")[0].trim());
		
		//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().trim().compareTo(o2.getKey().trim()));
		
		//sort based on benchmark percentage
		Collections.sort(entryList, (o1, o2) -> {
			if(o1.getValue() > o2.getValue()) {
				return -1;
			}else if(o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});
		
		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
			@Override
			public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
				if(o1.getValue() > o2.getValue()) {
					return -1;
				}else if(o1.getValue() < o2.getValue()) {
					return 1;
				}
				return 0;
			}
		});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		
		  for (String countryKey : sortedHashMap.keySet()) {
		  //System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		  
		  }
		  
		  //System.out.println("----------------##---------------");
		 
		return sortedHashMap;
	}


	@Then("^(.+) should be able to see (.+) in Confirmation Page in Rejected Strategy Resubmission Flow$")
    public void should_be_able_to_see_in_confirmation_page_in_rejected_strategy_resubmission_flow(String typeofuser, String confirmationmessage) {
		Action.pause(5000);
        userInfo = typeofuser;
        if(confirmationmessage.equals("Your Strategy Has Been Successfully Updated"))
        	strategyStatus = "Eligible";
        else
        	strategyStatus = "Pending HO Approval";
        Assert.assertTrue(confirmationPage.isUserOnConfirmationPage());
        Assert.assertTrue(confirmationPage.isConfirmationMessageDisplayed(confirmationmessage));
        
    }
}
