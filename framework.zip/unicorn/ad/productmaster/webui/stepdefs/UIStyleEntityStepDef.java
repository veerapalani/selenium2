package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.Action;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.RestApiHelperMethods;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class UIStyleEntityStepDef {
	PMPageGeneric StyleEntity=new PMPageGeneric("AD_PM_StyleEntityPage");
	String activeLink = "Style";
	String expectedColorCode,xpath;
	String pageURL = "http://10.49.116.4:8080/pmui/?#/style";
	List<WebElement> listOfElements,listOfElements2 = new ArrayList<WebElement>();
    @Then("^Style Link should be active$")
    public void Style_link_should_be_something() throws Throwable {
        StyleEntity.verifyAttribute("true", activeLink, "selected");
    }
    

    
    @Then("^User should be able to see \"([^\"]*)\" in \"([^\"]*)\" on Style Entity page$")
    public void user_should_be_able_to_see_something_on_Style_Entity_page(String list1, String key) throws Throwable {
    	String[] listArray = list1.split(", ");
    	listOfElements =  StyleEntity.getElements(key);
    	for(int i=0;i<listArray.length;i++) {
    		StyleEntity.verifyTextInListOfElements(listArray[i], listOfElements);
    		Reporter.addStepLog(listArray[i]+" is displaying in " + key);
    	}
    }

    @And("^Order of the \"([^\"]*)\" should be \"([^\"]*)\" on Style Entity page$")
    public void order_of_the_something_should_be_something_on_Style_Entity_page(String key, String list1) throws Throwable {
    	String[] listArray = list1.split(", ");
     	listOfElements =  StyleEntity.getElements(key);
     	for(int i=0;i<listArray.length;i++) {
     		Assert.assertEquals( listOfElements.get(i).getText(),listArray[i]);
     		Reporter.addStepLog(listOfElements.get(i).getText()+" is the "+i+" element in " + key);
     	}
    }

    @And("^All the \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Style Entity page$")
    public void all_the_something_should_be_displayed_in_something_color_on_Style_Entity_page(String key, String color) throws Throwable {
        listOfElements = StyleEntity.getElements(key);
        expectedColorCode = Action.getTestData(color);
        for(int i=0;i<listOfElements.size();i++) {
        	StyleEntity.verifyColor(listOfElements.get(i), expectedColorCode);
        }
        
        
    }
    @Then("^User should be able to see \"([^\"]*)\" in every row of \"([^\"]*)\" on Style Entity page$")
    public void user_should_be_able_to_see_something_in_every_row_of_something_on_Style_Entity(String insideElementKey, String key) throws Throwable {
    	listOfElements = StyleEntity.getElements(key);        
        for(int i=1;i<=Math.min(listOfElements.size(),10);i++) {
        	xpath="//tr[@class='divider divider-top divider-03 divider-color-03']["+i+"]//wf-icon[@name='ellipsis-v-solid']";
        	StyleEntity.verifyElement(StyleEntity.findElementByDynamicXpath(xpath));
        	Reporter.addStepLog("verified "+insideElementKey+ " for element no "+(i));
        	StyleEntity.scrollByPixel(100);
        }
    }
    @And("^user hover over the \"([^\"]*)\" of valid element of \"([^\"]*)\" and click on \"([^\"]*)\" on Style Entity page$")
    public void user_hover_over_the_something_of_valid_element_of_something_and_click_on_something_on_style_entity_page(String insideElementKey, String parentElementKey, String clickOnElement) throws Throwable {
    	Thread.sleep(3000);
    	listOfElements = StyleEntity.getElements(insideElementKey);
    	listOfElements2 = StyleEntity.getElements(clickOnElement);
    	String programCode;
    	for(int i=1;i<=listOfElements.size();i++) {
    		xpath= "//tr[@class='divider divider-top divider-03 divider-color-03']["+i+"]/td";
    	 programCode=StyleEntity.findElementByDynamicXpath(xpath+"[6]").getText();
    	 
    	 Reporter.addStepLog("programCode is "+programCode);
    		if((programCode.length()>0)) {
    			StyleEntity.hoverOnElement(listOfElements.get(i-1));
    			Reporter.addStepLog("hovering on "+insideElementKey);
    			StyleEntity.clickOnLink(listOfElements2.get(i-1));
    			Reporter.addStepLog("clicking on "+clickOnElement);
    			break;
    		}
    	}
    }

    @Then("^User should be able to see the Following \"([^\"]*)\" while \"([^\"]*)\" on the Ellipse Icon in first row of \"([^\"]*)\" on Style Entity page$")
    public void user_should_be_able_to_see_the_following_something_while_something_on_the_ellipse_icon_in_every_row_of_something_on_style_entity_page(String options, String insideElementKey, String strArg2) throws Throwable {
    	Thread.sleep(3000);
		StyleEntity.hoverOnElement(StyleEntity.getElementFromShadowRoot(insideElementKey));
		Thread.sleep(1000);
		StyleEntity.verifyElement(options);
		Reporter.addStepLog("verified "+options+ " for element");
		StyleEntity.scrollByPixel(100);  
    }

    
    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Style Entity page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_style_entity_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
    	StyleEntity.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = StyleEntity.getElementsFromShadowRoot(key);
   	 StyleEntity.verifyTextInListOfElements( items.get(i),listOfElements);  
        }   
    }
    @Then("^User should be able to see the \"([^\"]*)\" header on Style Entity page$")
    public void user_should_be_able_to_see_the_something_header_on_style_entity_page(String key) throws Throwable {
        StyleEntity.verifyHeader(key);
    }
    @Then("^User should be able to see the \"([^\"]*)\" at the \"([^\"]*)\" on Style Entity page$")
    public void user_should_be_able_to_see_the_something_at_the_something_on_Style_entity_page(String key, String shadowRootKey) throws Throwable {
    	StyleEntity.verifyElement(StyleEntity.fetchElementFromShadowRoot(key, shadowRootKey));
    }

    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Style Entity page$")
    public void something_should_be_displayed_in_something_color_on_Style_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	StyleEntity.verifyColor(key,expectedColorCode);
    	
    }
    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Style Entity page$")
    public void something_should_be_displayed_in_something_color_inside_style_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	StyleEntity.verifyColor(StyleEntity.getElementFromShadowRoot(key),expectedColorCode);
    }

    @And("^\"([^\"]*)\" should have \"([^\"]*)\" background color on Style Entity page$")
    public void something_should_have_something_background_color_on_Style_entity_page(String key, String backgroundColor) throws Throwable {
    	expectedColorCode = Action.getTestData(backgroundColor);
    	StyleEntity.verifyBackgroundColor(key,expectedColorCode);
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Style Entity page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_on_Style_entity_page(String ghostText, String searchBox) throws Throwable {
    	StyleEntity.verifyGhostText(ghostText, StyleEntity.getElementFromShadowRoot(searchBox));
    }

    @And("^User should be able to see the \"([^\"]*)\" on Style Entity page$")
    public void user_should_be_able_to_see_the_something_on_Style_entity_page(String key) throws Throwable {
    	StyleEntity.verifyElement(key);
    }

    @And("^User should be able to see the \"([^\"]*)\" inside Style Entity page$")
    public void user_should_be_able_to_see_the_something_inside_style_entity_page(String key) throws Throwable {
        StyleEntity.verifyElementFromShadowRoot(key);
    }

    @And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Style Entity page$")
    public void that_something_should_be_displayed_in_something_color_on_Style_entity_page(String key, String expectedColor) throws Throwable {
    	expectedColorCode = Action.getTestData(expectedColor);
    	StyleEntity.verifyCurrentElementColor(expectedColorCode);
    }

    @And("^The \"([^\"]*)\" on the Style Entity page should contain all the following options$")
    public void the_something_on_the_Style_Entity_page_should_contain_all_the_following_options(String key,List<String> items) throws Throwable {
    	for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   	 StyleEntity.verifyTextInListOfElements( items.get(i), StyleEntity.getElements(key)); 
   	 }
    }
    
    @Then("^User should be able to see only \"([^\"]*)\" \"([^\"]*)\" on Style Entity Page$")
    public void user_should_be_able_to_see_only_something_something_on_program_entity_page(String numberOfItems, String key) throws Throwable {
        listOfElements = StyleEntity.getElements(key);
        
        Assert.assertEquals(listOfElements.size(),Integer.parseInt(numberOfItems) );
        Reporter.addStepLog("verified that "+numberOfItems+" "+key+" present");
    }
    
    @Then("^\"([^\"]*)\" should not be displayed in \"([^\"]*)\" on Style Entity Page$")
    public void something_should_not_be_displayed_in_something_on_program_entity_page(String item, String key) throws Throwable {
    	listOfElements = StyleEntity.getElements(key);
    	StyleEntity.verifyTextNotPresentInListOfElements(item, listOfElements);
        Reporter.addStepLog("verified that "+item+" is not present in "+key);
    }
    @And("^user clicks the \"([^\"]*)\" on Style Entity page$")
    public void user_clicks_the_something_on_style_entity_page(String key) throws Throwable {
        StyleEntity.clickOnLink(key);
    }
    @Then("^user should be able to go to Style Entity page$")
    public void user_should_be_able_to_go_to_style_entity_page() throws Throwable {
    	Thread.sleep(2000);
    	StyleEntity.verifyPageURL(pageURL);
    }
}
