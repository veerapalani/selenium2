package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList; 
import java.util.List;


import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterGeneric;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.StyleDetailsPage;

public class StyleDetailsStepDef {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_StyleDetailPage"));
	PMPageGeneric StyleDetail=new PMPageGeneric("AD_PM_StyleDetailPage");
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL=SSOLoginPage.URL+"#/style/view";
	
	
	String xpath;
	
	//PMPageGeneric StyleDetail=new PMPageGeneric("AD_PM_ProgramDetailsPage");

	@And("^User clicks the Edit Button on Style Detail page$")
    public void user_clicks_the_edit_button_on_style_detail_page() throws Throwable {
        action.click(action.getElement("Edit Button"));
        Reporter.addStepLog("clicked on Edit button");
    }

	@Then("^the below attributes on Style Details Page should contain either true or false or blank value$")
	    public void the_below_attributes_on_style_details_page_should_contain_either_true_or_false_or_blank_value(List<String> attributes) throws Throwable {
		 String myValue=null;
	    	for(int i=0;i<attributes.size();i++) {
	    	String xpath="//small[contains(text(),'"+attributes.get(i)+"')]/ancestor::p/following-sibling::input";
	    	myValue=StyleDetail.findElementByDynamicXpath(xpath).getAttribute("value");
	    	Reporter.addStepLog("The value for "+attributes.get(i)+" is "+myValue);
	    	if(myValue.equals("true")||myValue.equals("false")||myValue.equals("")) {
	    		Assert.assertTrue(true);
	    		
	    	}
	    	else {
	    		Assert.assertFalse(true);
	    	}
	        }
	        }
	 
	 @And("^The value on Style Details Page of the following attributes should be in \"([^\"]*)\" format$")
	    public void the_value_on_style_details_page_of_the_following_attributes_should_be_in_something_format(String format,List<String> attributes) throws Throwable {
		 String myValue=null;
	    	for(int i=0;i<attributes.size();i++) {
	    	String xpath="//small[contains(text(),'"+attributes.get(i)+"')]/ancestor::p/following-sibling::span";
	    	myValue=StyleDetail.findElementByDynamicXpath(xpath).getText();
	    	Reporter.addStepLog("validating for "+attributes.get(i)+" with value "+myValue);
	    	if(!myValue.equals(""))
	    		StyleDetail.verifyFormat(myValue, Action.getTestData(format));
	   
	    	
	    }
	 }
	 
	 @Then("^the attributes on Style Details Page should contain one of the below following values$")
	    public void the_attributes_on_style_details_page_should_contain_one_of_the_below_following_values(List<List<String>> attributeValuePair) throws Throwable {
		 String myValue=null;
	    	
	    	for(int i=0;i<attributeValuePair.size();i++) {
	    	String xpath="//small[contains(text(),'"+attributeValuePair.get(i).get(0)+"')]/ancestor::p/following-sibling::span";
	    	myValue=StyleDetail.findElementByDynamicXpath(xpath).getText();
	    	Reporter.addStepLog("The value for "+attributeValuePair.get(i).get(0)+" is "+myValue);
	    	String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
	    	for(int j=0;j<listOfValues.length;j++) {
	    	if(myValue.equals(listOfValues[j]))
	    		{Assert.assertTrue(true);
	    		break;}
	    	
	    	else 
	    		Assert.assertFalse(false);
	    	
	    	}
	        }
	    }
	
	@Then("^User should be able to see the \"([^\"]*)\" header on Style Details page$")
	public void user_should_be_able_to_see_the_something_header_on_style_details_page(String key) throws Throwable {
		StyleDetail.verifyHeader(key);
		// StyleDetail.verifyHeader(key);
	}
	@Then("^user should be able to see the below attributes on Style Details page$")
    public void user_should_be_able_to_see_the_below_attributes_on_style_details_page(List<String> attributes) throws Throwable {
		listOfElements = StyleDetail.getElements("Attributes");
	       for(int i=0;i<attributes.size();i++)
	    	   {
	    	   StyleDetail.verifyTextInListOfElements(attributes.get(i), listOfElements);
	    	   }
    }

	

	@And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Style Details page$")
	public void something_should_be_displayed_in_something_color_on_style_details_page(String key, String color)
			throws Throwable {
		String expectedColorCode = Action.getTestData(color);
		StyleDetail.verifyColor(key, expectedColorCode);
	}

	@And("^\"([^\"]*)\" should have \"([^\"]*)\" background color on Style Details page$")
	public void something_should_have_something_background_color_on_style_details_page(String key,
			String backgroundColor) throws Throwable {
		String expectedColorCode = Action.getTestData(backgroundColor);
		StyleDetail.verifyBackgroundColor(key, expectedColorCode);
	}

	 @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Style Details page$")
	    public void something_should_be_displayed_in_something_color_inside_style_details_page(String key, String color) throws Throwable {
		 String expectedColorCode = Action.getTestData(color);
			StyleDetail.verifyColor(StyleDetail.getElementFromShadowRoot(key), expectedColorCode);
	    }

	    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Style Details page should contain all the following options$")
	    public void on_clicking_on_something_the_something_on_the_style_details_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
	    	StyleDetail.clickOnLink(clickKey);
	        for(int i=0;i<items.size();i++) {
	   		 Reporter.addStepLog("verifying for "+items.get(i));
	   		 listOfElements = StyleDetail.getElementsFromShadowRoot(key);
	   		 Reporter.addStepLog(listOfElements.get(0).getText());
	   		StyleDetail.verifyTextInListOfElements( items.get(i),listOfElements);  
	        }
	    }

	@Then("^User should be able to see the \"([^\"]*)\" on Style Details page$")
	public void user_should_be_able_to_see_the_something_on_style_details_page(String key) throws Throwable {

		StyleDetail.verifyElement(key);
	}
	@And("^User should be able to see the \"([^\"]*)\" inside Style Details page$")
    public void user_should_be_able_to_see_the_something_inside_details_page(String key) throws Throwable {
		StyleDetail.verifyElement(StyleDetail.getElementFromShadowRoot(key));
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Style Details page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_inside_style_details_page(String ghostText, String searchBox) throws Throwable {
    	StyleDetail.verifyGhostText(ghostText, StyleDetail.getElementFromShadowRoot(searchBox));
    }
	

    @And("^user clicks the \"([^\"]*)\" on Style Details page$")
    public void user_clicks_the_something_on_style_details_page(String key) throws Throwable {
        StyleDetail.clickOnLink(key);
    }

	@And("^User should be able to see the \"([^\"]*)\" at the \"([^\"]*)\" on Style Details page$")
	public void user_should_be_able_to_see_the_something_at_the_something_on_style_details_page(String key,
			String shadowRootKey) throws Throwable {
		StyleDetail.verifyElement(StyleDetail.fetchElementFromShadowRoot(key, shadowRootKey));
	}

	@And("^The text written in \"([^\"]*)\" should match with the value of \"([^\"]*)\" attribute on Style Details page$")
    public void the_text_written_in_something_should_match_with_the_value_of_something_attribute_on_style_details_page(String actualkey, String expectedkey) throws Throwable {
		 Assert.assertEquals(StyleDetail.getText(actualkey), StyleDetail.getText(expectedkey));
    }
	@Then("^User should be able to see the bottom-border below \"([^\"]*)\" on Style Details page$")
    public void user_should_be_able_to_see_the_bottomborder_below_something_on_style_details_page(String key) throws Throwable {
		String widthInPixel= StyleDetail.giveCssValue(StyleDetail.getElement(key), "border-bottom-width");
	       String width = widthInPixel.substring(0, widthInPixel.length()-2);
	       Assert.assertTrue(Integer.parseInt(width)>0); 
    }

	@And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Style Details page$")
	public void that_something_should_be_displayed_in_something_color_on_style_details_page(String insideElementKey, String parentElementKey) throws Throwable {

	}
	@Then("^user hover over the \"([^\"]*)\" of first element of \"([^\"]*)\" on Style Entity page$")
    public void user_hover_over_the_something_of_first_element_of_something_on_style_entity_page(String insideElementKey, String parentElementKey) throws Throwable {
		listOfElements = StyleDetail.getElements(insideElementKey);
		StyleDetail.hoverOnElement(listOfElements.get(0));
Reporter.addStepLog(listOfElements.get(1).getText());
		Reporter.addStepLog("hovering on "+insideElementKey);
    }
	
	@And("^The \"([^\"]*)\" on the Style Details page should contain all the following options$")
	public void the_something_on_the_style_details_page_should_contain_all_the_following_options(String key,List<String> options) throws Throwable {
		listOfElements = StyleDetail.getElements(key);
        for(int i=0;i<options.size();i++) {
        	StyleDetail.verifyTextInListOfElements(options.get(i), listOfElements);
        }
	}
	@Then("^User should not be able to see the \"([^\"]*)\" in the \"([^\"]*)\" on Style Detail page$")
    public void user_should_not_be_able_to_see_the_something_in_the_something_on_style_detail_page(String text, String key) throws Throwable {
		StyleDetail.verifyTextNotPresentInListOfElements(text, StyleDetail.getElements(key));
    }
	 @And("^compare the string values given in API and the values displayed in UI in Style Detail page$")
	    public void compare_the_string_values_given_in_api_and_the_values_displayed_in_ui_in_Style_detail_page(List<List<String>> APIUIAttributePair) {
	    	 String APIValue,UIValue;
			 for(int i=0;i<APIUIAttributePair.size();i++) {
			APIValue = ProductMasterGeneric.response.jsonPath().get(APIUIAttributePair.get(i).get(0));
			  xpath="//small[text()='"+APIUIAttributePair.get(i).get(1)+"']/ancestor::p/following-sibling::span";
			 UIValue=StyleDetail.findElementByDynamicXpath(xpath).getText();
			 Assert.assertEquals(UIValue, APIValue);
			 Reporter.addStepLog("verified that the value for "+APIUIAttributePair.get(i).get(1)+"  is "+UIValue);  
			 }
			 Reporter.addScreenCapture();
	    }

	    @And("^compare the numeric values given in API and the values displayed in UI in Style Detail page$")
	    public void compare_the_numeric_values_given_in_api_and_the_values_displayed_in_ui_in_Style_detail_page(List<List<String>> APIUIAttributePair) {
	    	 float APIValue,UIValue;
			 for(int i=0;i<APIUIAttributePair.size();i++) {
			APIValue = ProductMasterGeneric.response.jsonPath().getFloat(APIUIAttributePair.get(i).get(0));
			  xpath="//small[text()='"+APIUIAttributePair.get(i).get(1)+"']/ancestor::p/following-sibling::span";
			 UIValue=Float.parseFloat(StyleDetail.findElementByDynamicXpath(xpath).getText());
			 Assert.assertEquals(UIValue, APIValue);
			 Reporter.addStepLog("verified that the value for "+APIUIAttributePair.get(i).get(1)+"  is "+UIValue); 
			 }
			 Reporter.addScreenCapture();
	    }

	    @And("^compare the boolean values given in API and the values displayed in UI in Style Detail page$")
	    public void compare_the_boolean_values_given_in_api_and_the_values_displayed_in_ui_in_Style_detail_page(List<List<String>> APIUIAttributePair) {
	    	 Boolean APIValue,UIValue;
			 for(int i=0;i<APIUIAttributePair.size();i++) {
			APIValue = ProductMasterGeneric.response.jsonPath().getBoolean(APIUIAttributePair.get(i).get(0));
			  xpath="//small[text()='"+APIUIAttributePair.get(i).get(1)+"']/ancestor::p/following-sibling::input";
			 UIValue=Boolean.parseBoolean(StyleDetail.findElementByDynamicXpath(xpath).getAttribute("value"));
			 Assert.assertEquals(UIValue, APIValue);
			 Reporter.addStepLog("verified that the value for "+APIUIAttributePair.get(i).get(1)+"  is "+UIValue); 
			 }
			 Reporter.addScreenCapture();
	    }
	    
	    @Then("^user should be able to go to Style Detail page$")
	    public void user_should_be_able_to_go_to_style_detail_page() throws Throwable {
	    	Assert.assertTrue(action.getCurrentURL().contains(pageURL));
	    	Reporter.addStepLog("We are in StyleDetailPage");
	    	Reporter.addScreenCapture();
	    }
	    
	    @And("^user clicks the \"([^\"]*)\" on Style Detail page$")
	    public void user_clicks_the_something_on_style_detail_page(String key) throws Throwable {
	        StyleDetail.clickOnLink(key);
	        Reporter.addStepLog("clicked on "+key);
	    }
}
