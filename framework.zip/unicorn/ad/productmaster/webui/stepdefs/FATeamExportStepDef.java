package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.util.List;

import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.ExportReportsPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAViewPage;

public class FATeamExportStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	UpdateFAViewPage updateFaPage = new UpdateFAViewPage("AD_PM_UpdateFAViewPage");
	PMPageGeneric pmPageGeneric = new PMPageGeneric("AD_PM_BenchmarkSortAndFilterPage");
	ExportReportsPage reports = new ExportReportsPage();
	String sheetName, sheetName2 = "";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/FATeamExport.xlsx";
	String faTeamName, faId, universalIds, faEmail, additionalInfo, homeOffice, nameOfProgram, docLink, docType,
			docDescription, documentType, documentLink, documentComment = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);

	@Then("^user verifies the FATeam export functionality using (.+)$")
	public void user_verifies_the_fateam_export_fucntionality(String entityName)
			throws IOException, InterruptedException {
		int count = updateFaPage.getFaTeamCount();
		System.out.println("count: " + count);
		if (count < 1) {
			Reporter.addStepLog("There are no FA Team Entities associated with search value in the Grid");
			Reporter.addScreenCapture();
		} else {
			reports.DeletePreviousFile(entityName);
			updateFaPage.clickOnFATeamExport();
			Assert.assertTrue(reports.VerifyFileDownloaded());
			// verifying the grid count and csv file count
			Assert.assertTrue(count == reports.getNumberOfRecordsInFile(entityName));
			landingPage.movetoFirstElementinFilteredrecords();
			landingPage.clickOnEllipsesIcon();
			landingPage.verifyOnViewDetailsLink();

			landingPage.clickOnViewDetailsLink();
			Assert.assertTrue(updateFaPage.isUserOnViewFATeamPage());

			excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/FATeamExport.xlsx";

			sheetName = entityName;

			faTeamName = updateFaPage.getFaTeamDetailsText("FA Team Name");
			// System.out.println("faTeamName:" + faTeamName);
			faId = updateFaPage.getFaTeamDetailsText("FA ID(s)");
			// System.out.println("faId:" + faId);
			universalIds = updateFaPage.getFaTeamDetailsText("Universal ID(s)");
			// System.out.println("universalIds:" + universalIds);
			faEmail = updateFaPage.getFaTeamDetailsText("FA Email");
			// System.out.println("faEmail:" + faEmail);
			additionalInfo = updateFaPage.getFaTeamDetailsText("Additional Information");
			// System.out.println("additionalInfo:" + additionalInfo);
			homeOffice = updateFaPage.getFaTeamDetailsText("Home Office Comments");
			// System.out.println("homeOffice:" + homeOffice);
			nameOfProgram = updateFaPage.getFaTeamDetailsText("Name of FA Discretionary Program");
			// System.out.println("nameOfProgram:" + nameOfProgram);
			documentType = updateFaPage.getDocumentValuesAsExport(0);
			// System.out.println(updateFaPage.getDocumentValuesAsExport(0));
			documentLink = updateFaPage.getDocumentValuesAsExport(1);
			// System.out.println(updateFaPage.getDocumentValuesAsExport(1));
			documentComment = updateFaPage.getDocumentValuesAsExport(2);
			// System.out.println(updateFaPage.getDocumentValuesAsExport(2));
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 0, faTeamName);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 1, faId);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 2, universalIds);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 3, faEmail);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 4, additionalInfo);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 5, homeOffice);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 6, nameOfProgram);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 7, documentLink);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 8, documentType);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, 1, 9, documentComment);

			// Make sure sheet name same as entity name i.e same as downloaded file name
			reports.verifyAttributesForFirstEntity(entityName, excelFilePath);

		}
	}

	@Then("^user verifies the FATeam export tooltip$")
	public void user_verifies_the_fateam_export_tooltip() {
		Assert.assertTrue(updateFaPage.verifyTooltipOfFATeamExport());
	}
	
	@Then("^user validates the FA Team Print functionality for (.+)$")
    public void user_validates_the_fa_team_print_functionality_for(String entityName) throws Exception {
		//PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, 0, updateFaPage.getTextforBenchmarkDescription());
		int i = 1;
		while (i <= 6) {
			PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, i-1,
					updateFaPage.getTextfromGridforRow(String.valueOf(i)));
			i++;
		}
		updateFaPage.clickOnPrintButton();
		pmPageGeneric.verifyPrintFunctionalityForFirstEntity(excelFilePath, entityName);
    }
	
}
