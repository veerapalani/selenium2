package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkFlyoutPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateBenchmarkFlyoutStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	Alert alert;

	CreateBenchmarkFlyoutPage createbenchmarkfly = new CreateBenchmarkFlyoutPage("AD_PM_CreateBenchmarkFlyoutPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateBenchmark.xlsx";
	String option, sheetName = "";
	int rowIndex;

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;

	@Then("^User should be able to go to the Create Benchmark Flyout$")
	public void user_should_be_able_to_go_to_the_create_benchmark_flyout() throws Throwable {
		String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		createbenchmarkfly.verifyheaderinbenchmarkflyout();
		Reporter.addStepLog("Able to go to Create benchmarkFlyout");
		Reporter.addScreenCapture();
	}
	@When("^User changes the Benchmark Description field on Create Benchmark Flyout page$")
    public void user_changes_the_benchmark_description_field_on_create_benchmark_flyout_page() throws Throwable {
		createbenchmarkfly.editdecriptionfieldincreatebenchmarkflyoutscreen();
    }
	@Then("^user should be able to see the below attributes on Create Benchmark flyout$")
	public void user_should_be_able_to_see_the_below_attributes_on_create_benchmark_flyout(List<String> entity)
			throws Throwable {
		Thread.sleep(1000);
		for (int i = 0; i < entity.size(); i++) {
			createbenchmarkfly.verifyElementsoncreatebenchmarkflyout(
					createbenchmarkfly.findElementByDynamicXpath("//*[@label='" + entity.get(i) + "']"));
			Reporter.addStepLog("able to see " + entity.get(i) + " header");
		}
		Reporter.addScreenCapture();
	}
	@Then("^User should be able to see the bottom border below Headers on Create Benchmark Flyout page$")
    public void user_should_be_able_to_see_the_bottom_border_below_headers_on_create_benchmark_flyout_page() throws Throwable {
		String widthInPixel = createbenchmarkfly.giveCssValuehere(createbenchmarkfly.getHorizontalLineElement(),
				"border-bottom-width");
		String width = widthInPixel.substring(0, widthInPixel.length() - 2);
		Assert.assertTrue(Integer.parseInt(width) > 0);
    }
	@Then("^User should see maxlength for the following attributes on Create Benchmark Flyout page should be according to the values mentioned$")
    public void user_should_see_maxlength_for_the_following_attributes_on_create_benchmark_flyout_page_should_be_according_to_the_values_mentioned(List<List<String>>entityValuePair) throws Throwable {
		for (int i=0;i<entityValuePair.size();i++) {
	    	value = createbenchmarkfly.findElementByDynamicXpath("//*[@label='"+entityValuePair.get(i).get(0)+"']").getAttribute("maxlength");
	       Assert.assertEquals(entityValuePair.get(i).get(1), value);
	       Reporter.addStepLog("Actual value is" +entityValuePair.get(i).get(1));
	       Reporter.addStepLog("Expected value is" +value);
	       }
 
    }
	@Then("^User is able to see the error message on Create Benchmark Flyout page$")
    public void user_is_able_to_see_the_error_message_on_create_benchmark_flyout_page() throws Throwable {
		//String expError = (String) exlObj.getCellData(sheet, rowIndex, 7);
		String expError = "Benchmark Description should not be less than 3 characters";
		String errKey = (String) exlObj.getCellData(sheet, rowIndex, 6);
		createbenchmarkfly.validatingErrorMessage(errKey, expError);
		assertTrue(createbenchmarkfly.validatingErrorMessage(errKey, expError));
    
    }
	@And("^User clicks on Cancel Button on Create Benchmark Flyout$")
    public void user_clicks_on_cancel_button_on_create_benchmark_flyout() throws Throwable {
		createbenchmarkfly.clickOncancelbutton();
    }
    @And("^User clicks on Continue Button on Create Benchmark Flyout$")
    public void user_clicks_on_continue_button_on_create_benchmark_flyout() throws Throwable {
    	createbenchmarkfly.clickOncontinuebutton();
    }
	@Then("^User should be able to see the status field will be in disabled state on Create Benchmark Flyout$")
    public void user_should_be_able_to_see_the_status_field_will_be_in_disabled_state_on_create_benchmark_flyout() throws Throwable {
		createbenchmarkfly.verifystatusfieldoncreatebenchmarkflyout();
    }
	@Then("^the attributes on Create Benchmark Flyout should contain all of the below following values$")
	public void the_attributes_on_create_benchmark_flyout_should_contain_all_of_the_below_following_values(
			List<List<String>> entityValuePair) throws Throwable {
		for (int i = 0; i < entityValuePair.size(); i++) {
			String[] listOfValues;
			listOfString = new ArrayList<String>();
			listOfValues = entityValuePair.get(i).get(1).split(",");
			listOfElements = createbenchmarkfly
					.findElementsByDynamicXpath("//*[@label='" + entityValuePair.get(i).get(0) + "']/wf-select-option");

			for (int j = 0; j < listOfElements.size(); j++) {
				listOfString.add(listOfElements.get(j).getAttribute("name"));

			}
			for (int j = 0; j < listOfValues.length; j++) {
				Assert.assertTrue(listOfString.contains(listOfValues[j]));
				Reporter.addStepLog("the value " + listOfValues[j] + " is present in " + entityValuePair.get(i).get(0));
			}

		}
	}

	@Then("^User should be able to see the below fields on Create Benchmark Flyout$")
	public void user_should_be_able_to_see_the_below_fields_on_create_benchmark_flyout(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			createbenchmarkfly.verifyElementsoncreatebenchmarkflyout(
					createbenchmarkfly.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}
}
