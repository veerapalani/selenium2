package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkReviewFlyoutPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStrategyPage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;
public class CreateStrategyStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);

	WebElement myElement,myElement2;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateStrategyPage"));;
	Alert alert;
	
	PMPageGeneric createdoclink = new PMPageGeneric("AD_PM_CreateDocumentLinkPage");
	CreateStrategyPage createstrategypageobj = new CreateStrategyPage("AD_PM_CreateStrategyPage");
	public static String strategyName, StrategyCode = null;
	
	String pageURL = "https://pm.uat.bpsuspm.prd.bfsaws.net/pmui/#/pmp/addPMPStrategy";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateStrategy2106.xlsx";
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	String myValue;
	XSSFSheet sheet;
	int rowIndex, cellIndex;

	@Then("^User should be able to go to Create Strategy page$")
	    public void user_should_be_able_to_go_to_create_strategy_page() throws Throwable {
		Thread.sleep(1000);
	        Assert.assertEquals(action.getCurrentURL(), pageURL);
	        Reporter.addStepLog("Validated that we are in Create Strategy page");
	    }
	@Then("^User should be navigated to Create Strategy page$")
    public void user_should_be_navigated_to_create_strategy_page() throws Throwable {
		Assert.assertEquals(createstrategypageobj.getCreateStrategyPageURL(), pageURL);
        Reporter.addStepLog("Validated that we are in Create Strategy page");
		
    }
	
	@Then("^User should be able to see the benchmark name would be shown under the benchmark drop down in the create new Strategy page$")
    public void user_should_be_able_to_see_the_benchmark_name_would_be_shown_under_the_benchmark_drop_down_in_the_create_new_strategy_page() throws Throwable {
		createstrategypageobj.assertbenchmarknamevalue();
    }

	
	@Then("^User should be able to see the Create New Benchmark link on Create New Strategy page$")
    public void user_should_be_able_to_see_the_create_new_benchmark_link_on_create_new_strategy_page() throws Throwable {
		createstrategypageobj.verifycreatenewbenchmarklink();
    }
	
	 @And("^User clicks on Cancel Button inside the Wizard$")
	    public void user_clicks_on_cancel_button_inside_the_wizard() throws Throwable {
		 myElement = action.fluentWaitWebElement("Cancel Button");
		 action.highligthElement(myElement);
		 action.click(myElement);
		 Reporter.addStepLog("clicked on cancel button");
	 }
	 
	 @And("^User clicks on Cancel Button on Create New Strategy Page$")
	    public void user_clicks_on_previous_button_on_create_new_strategy_page() throws Throwable {
		 action.click(action.getElement("CancelButton"));
		 Reporter.addStepLog("clicked on previous button");
	    }
	 
	 @And("^User clicks on PM Link on Create New Strategy Page$")
	    public void user_clicks_on_back_link_on_create_new_strategy_page() throws Throwable {
		 action.click(action.getElement("Product Master Link"));
		 Reporter.addStepLog("clicked on Product Master Link");
	    }
	 
	 @Then("^User should be able to see the Strategy Name Header on Create New Strategy page$")
	    public void user_should_be_able_to_see_the_strategy_name_header_on_create_new_strategy_page() throws Throwable {
	        action.getElement("Strategy Name Header").isDisplayed();
	        action.highligthElement(action.getElement("Strategy Name Header"));
	    }
	 
	 @And("^The text written in Strategy Name Header should match with the value of Strategy Name Value attribute on Create New Strategy page$")
	    public void the_text_written_in_strategy_name_header_should_match_with_the_value_of_strategy_name_value_attribute_on_create_new_strategy_page() throws Throwable {
		 Assert.assertEquals(action.getElement("Strategy Name").getAttribute("value"),
					action.getElement("Strategy Name Header").getText());
			Reporter.addStepLog("validated that the strategy name header value matches with the strategy name");
			Reporter.addScreenCapture();
	    }
	 	
	 @Then("^user should be able to see following attributes marked as mandatory attributes in Create New Strategy PMP page$")
	    public void user_should_be_able_to_see_the_following_attributes_marked_as_mandatory_in_create_strategy_page(List<String> items) throws Throwable {
		 for (int i = 0; i < items.size(); i++) {
				myElement = createstrategypageobj.findElementByDynamicXpath("//*[@label='" + items.get(i) + "']");
				Assert.assertEquals(action.getAttribute(myElement, "required"), "true");
				Reporter.addStepLog("validated that " + items.get(i) + " is mandatory");
			}
			Reporter.addScreenCapture();
	    }
	 
	 @Then("^User should be able to see the bottom-border below Headers on Create New Strategy page$")
	    public void user_should_be_able_to_see_the_bottomborder_below_headers_on_create_new_strategy_page() throws Throwable {
	        String myWidth = action.getElement("DividerLine").getCssValue("border-bottom-width");
	        Integer width = Integer.parseInt(myWidth.substring(0,myWidth.length()-2));
	        Assert.assertTrue(width>0);
	        Reporter.addStepLog("able to see the bottom border");
	        Reporter.addScreenCapture();
	    }
	 
	 @And("^user enters the mandatory details in Strategy Wizard$")
	    public void user_enters_the_mandatory_details_in_strategy_wizard() throws Throwable {
	    	String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
			WebDriverManager.getDriver().switchTo().window(winHandleBefore);
			Reporter.addStepLog("the window handle is" + winHandleBefore);
			createstrategypageobj.enterstrategynameinstrategywizard();
			createstrategypageobj.clickOnprogdropdowninstrategywizard();
			//createstrategypageobj.selectsprogvalueinstrategywizard();
			
			Thread.sleep(1000);
	    }
	 
	 @Then("^User should be able to see the Create New Strategy Wizard on landing screen$")
	    public void user_should_be_able_to_see_the_create_new_strategy_wizard_on_landing_screen() throws Throwable {
		 WebElement styleelement=(WebElement) action.getElementByJavascript("Create New Strategy Wizard");
			action.highligthElement(styleelement);
	        Thread.sleep(500);
	        Reporter.addStepLog("able to see create new strategy wizard");
	        Reporter.addScreenCapture();
	    }
	    
	    @Then("^User should be able to see the Create New Strategy header on landing screen$")
	    public void user_should_be_able_to_see_the_create_new_strategy_header_on_landing_screen() throws Throwable {
	    	//String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
			//WebDriverManager.getDriver().switchTo().window(winHandleBefore);
			//WebElement styleelement=(WebElement) action.getElementByJavascript("Create New Strategy");
			//action.highligthElement(styleelement);
	    	//action.getElement("Create New Strategy").isDisplayed();
	        //Reporter.addStepLog("able to see create new strategy header on the strategy wizard");
	        //Reporter.addScreenCapture();
	    	WebElement styleelement=(WebElement) action.getElementByJavascript("Create New Strategy");
			action.highligthElement(styleelement);
	        Thread.sleep(500);
	        Reporter.addStepLog("able to see create new strategy header");
	        Reporter.addScreenCapture();
	    }
	    
	    
	    
    @And("^user enters the mandatory details in Strategy Wizard and click Create Strategy button$")
    public void user_enters_the_mandatory_details_in_strategy_wizard_and_click_Create_Strategy_button() throws Throwable {
    	String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		Reporter.addStepLog("the window handle is" + winHandleBefore);
		createstrategypageobj.enterstrategynameinstrategywizard();
		createstrategypageobj.clickOnprogdropdowninstrategywizard();
		//createstrategypageobj.selectsprogvalueinstrategywizard();
		Thread.sleep(1000);
		createstrategypageobj.clickOnstrategybutton();
		Thread.sleep(1000);
    }

    @And("^user clicks the Benchmark Dropdown icon from dropdown of Create Strategy Page$")
    public void user_clicks_the_style_dropdown_icon_from_dropdown_of_create_strategy_page() throws Throwable {
    	createstrategypageobj.clickonbenchmarkdropdownincreatestrategypage();
    }
    @And("^user clicks the Manager Dropdown icon from dropdown of Create Strategy Page$")
    public void user_clicks_the_manager_dropdown_icon_from_dropdown_of_create_strategy_page() throws Throwable {
    	createstrategypageobj.clickonmanagerdropdownincreatestrategypage();
    }
	

	
	
	@And("^User clicks on the Create New Benchmark link on Create New Strategy Page$")
    public void user_clicks_on_the_create_new_benchmark_link_on_create_new_strategy_page() throws Throwable {
		createstrategypageobj.clickOncreatenewbenchmarkLink();
    }
	
	@And("^User clicks on the Create New Manager link on Create New Strategy Page$")
    public void user_clicks_on_the_create_new_manager_link_on_create_new_strategy_page() throws Throwable {
		createstrategypageobj.clickOncreatenewmanagerLink();
    }
	


    @Then("^User should be able to see the Enter Strategy Details Header on Create New Strategy page$")
    public void user_should_be_able_to_see_the_enter_strategy_details_header_on_create_new_strategy_page() throws Throwable {
        action.getElement("Enter Strategy Details Header").isDisplayed();
        Reporter.addStepLog("Able to see Enter Strategy Details Header");
        Reporter.addScreenCapture();
    }
    
    @Then("^User should be able to see the Product Master Link on Create New Strategy page$")
    public void user_should_be_able_to_see_the_back_link_on_create_new_strategy_page() throws Throwable {
    	action.getElement("Product Master Link").isDisplayed();
        Reporter.addStepLog("Able to see Product Master Link");
        Reporter.addScreenCapture();
    }
    
    @Then("^User should be able to see the Timestamp on Create New Strategy page$")
    public void user_should_be_able_to_see_the_timestamp_on_create_new_strategy_page() throws Throwable {
    	action.getElement("Timestamp").isDisplayed();
        Reporter.addStepLog("Able to see Timestamp");
        Reporter.addScreenCapture();
    }
    
    
    
    @Then("^User enters in the following textfields with Valid Data in the Create Strategy page$")
    public void user_enters_in_the_following_textfields_with_valid_data_in_the_create_strategy_page(List<String> attribute) throws Throwable {
    	sheetName = "Valid";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_Mandatory");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			if (attribute.get(i).equals("Description"))
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector('textarea')");
			else
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector('input')");
			myElement.clear();

			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			action.sendkeysClipboard(myElement, myValue);
			if(attribute.get(i).equals("Style")|| attribute.get(i).equals("Manager")||attribute.get(i).equals("Benchmark")||attribute.get(i).equals("FA"))
			{
				myElement2 = createstrategypageobj.findElementByDynamicXpath("//*[@label='"+attribute.get(i)+"']/following-sibling::div/div/uL/li");
				action.click(myElement2);
				
			}
			Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i));

		}
    }

    @And("^User selects in the following dropdown with Valid Data in the Create Strategy page$")
    public void user_selects_in_the_following_dopdown_with_valid_data_in_the_create_strategy_page(List<String> attribute) throws Throwable {
    	sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_Mandatory");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector('button')");
			action.scrollToElement(myElement);
			action.click(myElement);
			myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-select[label='"
					+ attribute.get(i) + "']\").shadowRoot.querySelector(\"li[data-value='\\\""
					+ (String) exlObj.getCellData(sheet, rowIndex, cellIndex) + "\\\"']\")");
			action.click(myElement2);
		}
    }

    @And("^User selects the following radio button with Valid Data in the Create Strategy page$")
    public void user_selects_the_following_radio_button_with_valid_data_in_the_create_strategy_page(List<String> attribute) throws Throwable {
    	sheet = exlObj.getSheet(sheetName);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_Mandatory");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			if (myValue.equalsIgnoreCase("Yes")) {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-radio[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector(\"button[data-index='0']\")");
				action.click(myElement);
			} else {
				myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-radio[label='"
						+ attribute.get(i) + "']\").shadowRoot.querySelector(\"button[data-index='1']\")");
				action.click(myElement);
			}
		}
    }
    
    @And("^User clicks on the Next Button on Create New Strategy Page$")
    public void user_clicks_on_the_next_button_on_create_new_strategy_page() throws Throwable {
        action.click(action.getElement("Next Button"));
        Reporter.addStepLog("clicked on Next Button");
    }
    
    @Then("^User should be able to see the Required Text on Create New Strategy page$")
    public void user_should_be_able_to_see_the_required_text_on_create_new_strategy_page() throws Throwable {
        action.getElement("Required Text").isDisplayed();
        Reporter.addStepLog("verified the Required * symbol present");
        Reporter.addScreenCapture();
    }

    @And("^User fills the following textfields with following values in Create Strategy page$")
    public void user_fills_the_following_textfields_with_following_values_in_create_strategy_page(List<List<String>> attributeValuePair) throws Throwable {
    	Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			
		}
    }
    
    @And("^User can see the format error in the following textfields with following invalid values in Create Strategy page$")
    public void user_can_see_the_format_error_in_the_following_textfields_with_following_invalid_values_in_create_strategy_page(List<List<String>> attributeValuePair) throws Throwable {
    	Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Invalid_Numeric_Message");
			myElement2 = createstrategypageobj.findElementByDynamicXpath(
					"//*[@label='" + attributeValuePair.get(i).get(0) + "']/following-sibling::p");
			Assert.assertTrue(myElement2.getText().contains(message));
			Reporter.addStepLog("verified the msg " + myElement2.getText());
		}
    }
    
    @Then("^user should be able to select the first Style Value from the dropdown of Create Strategy Page$")
    public void user_should_be_able_to_select_the_first_style_value_from_the_dropdown_of_create_strategy_page() throws Throwable {
    	action.click(action.getElement("Style Value"));
    	Reporter.addStepLog("Selected the first value");
    }

    

    @And("^User enters under the Style Box as \"([^\"]*)\" in the Textbox$")
    public void user_enters_under_the_style_box_as_something_in_the_textbox(String keysToSend) throws Throwable {
        myElement = action.getElement("Style Box");
        action.click(myElement);
        action.sendkeysClipboard(myElement,keysToSend );
//        action.sendKeys(myElement, ""+Keys.ENTER);
        Reporter.addStepLog("Sent keys "+keysToSend);
    }
    
    @Then("^user should be able to select the first Manager Value from the dropdown of Create Strategy Page$")
    public void user_should_be_able_to_select_the_first_manager_value_from_the_dropdown_of_create_strategy_page() throws Throwable {
        action.click(action.getElement("Manager Value"));
        Reporter.addStepLog("Selected the first value");
    }

    

    @And("^User enters under the Manager Box as \"([^\"]*)\" in the Textbox$")
    public void user_enters_under_the_manager_box_as_something_in_the_textbox(String keysToSend) throws Throwable {
    	myElement = action.getElement("Manager Box");
    	action.click(myElement);
        action.sendkeysClipboard(myElement,keysToSend );
//        action.sendKeys(myElement, ""+Keys.ENTER);
        Reporter.addStepLog("Sent keys "+keysToSend);
    }
    
    @Then("^user should be able to select the first Benchmark Value from the dropdown of Create Strategy Page$")
    public void user_should_be_able_to_select_the_first_benchmark_value_from_the_dropdown_of_create_strategy_page() throws Throwable {
    	action.click(action.getElement("Benchmark Value"));
    	Reporter.addStepLog("Selected the first value");
    }

    

    @And("^User enters under the Benchmark Box as \"([^\"]*)\" in the Textbox$")
    public void user_enters_under_the_benchmark_box_as_something_in_the_textbox(String keysToSend) throws Throwable {
    	myElement = action.getElement("Benchmark Box");
    	action.click(myElement);
        action.sendkeysClipboard(myElement,keysToSend );
//        action.sendKeys(myElement, ""+Keys.ENTER);
        Reporter.addStepLog("Sent keys "+keysToSend);
    }
    
  
	@Then("^User should be able to see and select all the mandatory values in the Create New Strategy Page$")
	public void user_should_be_able_to_see_and_select_all_the_mandatory_values_in_the_create_new_strategy_page()
			throws Throwable {
		// createstrategypage.clickOnLink1(createstrategypage.getElementFromShadowRoot(key));

		Thread.sleep(1000);

	}

@Then("^user should be able to see following Attributes on Create New Strategy page$")
	    public void user_should_be_able_to_see_the_following_attributes_on_create_new_strategy_page(List<String> attribute) throws Throwable {
	     	for(int i=0;i<attribute.size();i++) {
	     		myElement=createstrategypageobj.findElementByDynamicXpath("//*[@label='"+attribute.get(i)+"']");
	     		Assert.assertTrue(myElement.isDisplayed());
	     		Reporter.addStepLog("Verified that "+attribute.get(i)+" is present");
	     	}
	     	Reporter.addScreenCapture();
	    }

	 @Then("^User should be able to see the Status field should be in disabled state on Create New Strategy page$")
	    public void user_should_be_able_to_see_the_status_field_should_be_in_disabled_state_on_create_new_strategy_page() throws Throwable {
		 myElement = (WebElement) action.getElementByJavascript("Statusfield");
		 Assert.assertEquals(myElement.getAttribute("disabled"), "true");
		 Reporter.addStepLog("verified that status field is disabled");
	 }
}
