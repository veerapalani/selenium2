package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStrategyBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class RejectedStrategyBenchmarkStepDef {

	RejectedStrategyBenchmarkPage benchmarkPage = new RejectedStrategyBenchmarkPage("AD_PM_RejectedStrategyBenchmarkPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
	int rowIndex;
	//ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName, userInfo;
	String label, attributeValue, uiValue,dbValue = null;
	
	//public static int count;
	
	@Then("^Values for Attributes in Benchmark Page of Rejected Strategies Resubmission Flow should match the values for attributes stored in DB$")
    public void values_for_attributes_in_benchmark_page_of_rejected_strategies_resubmission_flow_should_match_the_values_for_attributes_stored_in_db() throws IOException {
		sheetName = "Conversion_Validation";
		   //sheet = exlObj.getSheet(sheetName);
		   int rownum = 18;
		   //count = 0;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if((label == "") ||(label.contains("Proxy Manager")) )
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")) {
							rownum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if((label == "") ||(label.contains("Proxy Manager")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromBenchmarkAndAssetClassificationPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 3);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							//exlObj.setCellData(sheet, rownum, 5, attributeValue);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 5, attributeValue);
						}else {
							//exlObj.setCellData(sheet, rownum, 5, attributeValue+"-UI Value is not same as Stored Value in DB");
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 5, attributeValue);
							
							Reporter.addCompleteScreenCapture();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							//count++;
							
						}
						
							rownum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("Proxy Manager")))
								label = "isEmpty";
					
					}
			}
			
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addEntireScreenCaptured();
			Reporter.addStepLog("In Benchmark And Asset Classification Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
    }

    private String getDataFromBenchmarkAndAssetClassificationPage(String data) {
		switch (data) {
		case "Primary Benchmark":
			
			uiValue = benchmarkPage.getPrimaryBenchmarkValue();

			break;

		default:
			break;
		}
		if((uiValue == null) || (uiValue.isEmpty()))
			uiValue = "isEmpty";
		return uiValue;
	}

	@And("^User is in Benchmark Page of Rejected Strategies Resubmission Flow$")
    public void user_is_in_benchmark_page_of_rejected_strategies_resubmission_flow() {
        Assert.assertTrue(benchmarkPage.isUserOnBenchmarkPage());
    }
	
	@And("^(.+) is in Benchmark Page of Rejected Strategies Resubmission Flow$")
    public void is_in_benchmark_page_of_rejected_strategies_resubmission_flow(String typeofuser) {
		
		Assert.assertTrue(benchmarkPage.isUserOnBenchmarkPage());
		userInfo = typeofuser;
    }
	
	@And("^User clicks on Next in Benchmark Page in Rejected Strategies Resubmission Flow$")
    public void user_clicks_on_next_in_benchmark_page_in_rejected_strategies_resubmission_flow() {
        benchmarkPage.clickOnNext();
    }
	
	@And("^Data prepopulated in Benchmark page should match with DB Data in Rejected Strategy Resubmission flow for (.+)$")
    public void data_prepopulated_in_benchmark_page_should_match_with_db_data_in_rejected_strategy_resubmission_flow_for(String mandatorydetails) throws IOException {
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		DecimalFormat df = new DecimalFormat("0.##");
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 36;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int dbDataRowIndex = rowIndex+1;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   String category = "";
		   if(label == "" || label.contains("Delete Documents_ignore"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIBP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "" || label.contains("Delete Documents_ignore"))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromBenchmarkPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
						
						if(label.equals("radiobutton - BenchmarkCategory")) {
							if(attributeValue.equalsIgnoreCase("Default"))
								category = "Default";
						}

						/*
						if(label.equals("txt - Percentage")) {
							System.out.println(category);
							if(category.equalsIgnoreCase("Default"))
								dbValue = dbValue+"0";
						}
						*/
						
						System.out.println(attributeValue);
						System.out.println(dbValue);
						if(!dbValue.equals(attributeValue)) {
							
							if(label.equals("txt - Percentage")) {
								if(!(Float.parseFloat(dbValue + "f") == Float.parseFloat(attributeValue + "f"))) {
									Reporter.addEntireScreenCaptured();
									Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
									Assert.fail(label);
								}
							}else if(label.equals("drp - Benchmark Name")){
								if(!(dbValue.split("-#-")[0].equals(attributeValue))) {
									Reporter.addEntireScreenCaptured();
									Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
									Assert.fail(label);
								}
							}else {
								
								Reporter.addEntireScreenCaptured();
								Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
								Assert.fail(label);
							}
							
						}
						
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "" || label.contains("Delete Documents_ignore"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }

    private String getDataFromBenchmarkPage(String data) {
	    	switch (data) {
	    	case "radiobutton - BenchmarkCategory":
				
				uiValue = benchmarkPage.getBenchmarkCategoryValue();
				
				break;
			case "drp - Benchmark Name":
				
				uiValue = benchmarkPage.getBenchmarkNameValue();
				
				break;
			case "txt - Percentage":
				
				uiValue = benchmarkPage.getPercentageValue();
				
				break;
			case "txt - Custom Benchmark Reason":
				
				uiValue = benchmarkPage.getCustomBenchmarkReasonValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
		if(uiValue.isEmpty())
			uiValue = "isEmpty";
	
		return uiValue;
	}

	@And("^User inputs the values from (.+) in Benchmark page in Rejected Strategy Resubmission Flow$")
    public void user_inputs_the_values_from_in_benchmark_page_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		int rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		//exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		int updateDataRowIndex = rowIndex;
		int dBDataRowIndex = rowIndex+1;
    	
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		String benchmarkCategory,benchmark,benchmarkPercentage,customBenchmarkReason = "";
		String locatorValueCustomBenchmark,locatorValueCustomBenchmarkHighlight,locatorValueCustomBenchmarkPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			benchmarkCategory = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 36);
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 37);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 38);
			customBenchmarkReason = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, updateDataRowIndex, 39);
		}
			if(benchmarkCategory != "") {
				
				
				switch (benchmarkCategory) {
					case "Custom":
						
						if(benchmarkPage.getBenchmarkCategoryValue().equals("Custom"))
							benchmarkPage.deleteallcustomBenchmarks();
						
						benchmarkPage.selectCustom();
						if(benchmark != "") {
							
							int i =0;
							sheetName = "Variable_Paths";
							tName = Thread.currentThread().getName();
							synchronized (tName) {
							locatorValueCustomBenchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 2, 1);
							locatorValueCustomBenchmarkHighlight = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 3, 1);
							locatorValueCustomBenchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 4, 1);
							}
							
							if(benchmark.contains(",")) {
								String[] customBenchmark = benchmark.split(",");
								String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
								int size = customBenchmark.length;

								
								
								while(size > 0) {

									benchmarkPage.enterCustomBenchmark(locatorValueCustomBenchmark.replace("@data",i+"'"), locatorValueCustomBenchmarkHighlight.replace("@data",i+"'"), customBenchmark[i], benchmarkCategory);
									benchmarkPage.enterCustomBenchmarkPercentage(locatorValueCustomBenchmarkPercentage.replace("@data",i+"'"), customBenchmarkPercentage[i], benchmarkCategory, i);
									i++;
									size--;
									if(size > 0) {
										benchmarkPage.addNewBenchmark();
									}
								}
							}
							else {
								
								benchmarkPage.enterCustomBenchmark(locatorValueCustomBenchmark.replace("@data",i+"'"), locatorValueCustomBenchmarkHighlight.replace("@data",i+"'"), benchmark, benchmarkCategory);
								benchmarkPage.enterCustomBenchmarkPercentage(locatorValueCustomBenchmarkPercentage.replace("@data",i+"'"), benchmarkPercentage, benchmarkCategory, i);
						
							}
						}
						if(customBenchmarkReason != "") {
							benchmarkPage.enterCustomBenchmarkReason(customBenchmarkReason);
						}
						break;
					case "PMP Default":
					
						benchmarkPage.selectpmpDefault();
						benchmarkPage.clickOnViewDetails();
						String defaultValue = benchmarkPage.getDefaultValueAutopopulated();
						String[] value = defaultValue.split(":");
						if (mandatorydetails.contains("Test")) {
							sheetName = "Test";
						}
						tName = Thread.currentThread().getName();
						synchronized (tName) {
						rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
						PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex+3, 37, value[0]);
						PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex+3, 38, value[1]);
						}
						benchmarkPage.clickOnCrossIcon();
						break;
			
					default:
						break;
				}
			}
			
		
		Reporter.addScreenCapture();
    }

    @And("^data from Benchmark page should be stored in Excel for (.+) in Rejected Strategy Resubmission Flow$")
    public void data_from_benchmark_page_should_be_stored_in_excel_for_in_rejected_strategy_resubmission_flow(String mandatorydetails) throws IOException {
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
//    	benchmarkPage.refreshThePage();
//    	Assert.assertTrue(benchmarkPage.isUserOnBenchmarkPage());
    	
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 36;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int flowPageDataRowIndex = rowIndex+3;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
		   
		   if(label == "" || label.contains("Delete Documents_ignore"))
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIBP")) {
							columnIndex++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    			if(label == "" || label.contains("Delete Documents_ignore"))
			    				label = "isEmpty";
					}else {
							attributeValue = getDataFromBenchmarkPage(label);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
							columnIndex++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
							if(label == "" || label.contains("Delete Documents_ignore"))
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
    }
    
    @And("^User clicks on Previous Button in Benchmark Page in Rejected Strategy Resubmission Flow$")
    public void user_clicks_on_previous_button_in_benchmark_page_in_rejected_strategy_resubmission_flow() {
        benchmarkPage.clickOnPrevious();
    }
    
    @Then("^User should be able to see benchmarks from DB are sorted in descending order in Benchmark Page in Rejected Strategy Resubmission Flow for (.+)$")
    public void user_should_be_able_to_see_benchmarks_from_db_are_sorted_in_descending_order_in_benchmark_page_in_rejected_strategy_resubmission_flow_for(String mandatorydetails) {
		
    	if(benchmarkPage.getBenchmarkCategoryValue().equals("Cstom")) {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String benchmark,benchmarkPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			int dBDataRowIndex = rowIndex+1;
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dBDataRowIndex, 37);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dBDataRowIndex, 38);
			
		}
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			benchmarkfromUI = benchmarkPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = benchmarkPage.getPercentageithValuefromUI(j);
			
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.split(" - ")[1].equals(benchmarkKey));
			j++;
			
		}
    	}else {
    		//Custom Benchmark is not selected so ignoring the DB validation
    	}
    }
    
    @Then("^User should be able to see benchmarks are sorted in descending order in Benchmark Page in Rejected Strategy Resubmission Flow for (.+)$")
    public void user_should_be_able_to_see_benchmarks_are_sorted_in_descending_order_in_benchmark_page_in_rejected_strategy_resubmission_flow_for(String mandatorydetails) {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	String benchmarkCategory,benchmark,benchmarkPercentage,customBenchmarkReason = "";
		String locatorValueCustomBenchmark,locatorValueCustomBenchmarkHighlight,locatorValueCustomBenchmarkPercentage = "";
		
		String tName = Thread.currentThread().getName();
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 37);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 38);
			
		}
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			benchmarkfromUI = benchmarkPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = benchmarkPage.getPercentageithValuefromUI(j);
			
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey));
			j++;
			
		}
    }
    
    private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
    	Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().split(" - ")[1].trim().compareTo(o2.getKey().split(" - ")[1].trim()));
		
		//sort based on benchmark percentage
		Collections.sort(entryList, (o1, o2) -> {
			if(o1.getValue() > o2.getValue()) {
				return -1;
			}else if(o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});
		
		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
			@Override
			public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
				if(o1.getValue() > o2.getValue()) {
					return -1;
				}else if(o1.getValue() < o2.getValue()) {
					return 1;
				}
				return 0;
			}
		});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		  for (String countryKey : sortedHashMap.keySet()) {
		  System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		  
		  }*/
		 
		return sortedHashMap;
	}
    
    @Then("^in Benchmark Page user should not be able to add more Custom Benchmarks than the max limit for Rejected Strategy Resubmission flow$")
    public void in_benchmark_page_user_should_not_be_able_to_add_more_custom_benchmarks_than_the_max_limit_for_rejected_strategy_resubmission_flow() {
    	assertTrue(benchmarkPage.isAddNewBenchmarkOptionNotVisible());
    }

}
