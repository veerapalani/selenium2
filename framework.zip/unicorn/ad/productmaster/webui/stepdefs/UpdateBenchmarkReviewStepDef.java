package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.ReviewBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateBenchmarkPage;

public class UpdateBenchmarkReviewStepDef {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateBenchmarkReviewPage"));
	ReviewBenchmarkPage reviewStylePage = new ReviewBenchmarkPage();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateBenchmark3037.xlsx";
	String sheetName = "";
	UpdateBenchmarkPage updateBenchmarkPage = new UpdateBenchmarkPage();
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	int rowIndex,cellIndex;
	WebElement myElement;
	
	@And("^User clicks on Submit Button on Update Benchmark Review page$")
    public void user_clicks_on_submit_button_on_update_Benchmark_review_page() throws Throwable {
      action.click(action.getElement("Submit Button"));
      Reporter.addStepLog("clicked on submit button");
    }
	
	@Then("^User should be able to see the Review header in Update Benchmark Review page$")
    public void user_should_be_able_to_see_the_review_header_in_update_Benchmark_review_page() throws Throwable {
       Assert.assertTrue(action.getElement("Review Header").isDisplayed());
    }
	
	@And("^User clicks on Previous Button on Update Benchmark Review page$")
    public void user_clicks_on_previous_button_on_update_Benchmark_review_page() throws Throwable {
        action.click(action.getElement("Previous Button"));
        Reporter.addStepLog("clicked on Previous button");
	}
	
	@And("^User click on Edit Button on Update Benchmark Review page$")
    public void user_click_on_edit_button_on_update_Benchmark_review_page() throws Throwable {
		action.click(action.getElement("Edit Button"));
        Reporter.addStepLog("clicked on Edit button");
    }
	
	
	  @Then("^user should be able to see the following Column Headers in the Benchmark Review Page$")
			public void user_should_be_able_to_see_the_following_column_headers_in_the_update_benchmark_ui(List<String> items)
					throws Throwable {
				Thread.sleep(2000);
				for (int i = 0; i < items.size(); i++) {
					myElement = updateBenchmarkPage.findElementByDynamicXpath("//small[text()='"+items.get(i)+"']");
					
					Assert.assertTrue(action.isDisplayed(myElement));
					Reporter.addStepLog(items.get(i) + " is present in Upate Benchmark Review  page");
				}
				
		  }
	
	  @Then("^User should be able to see the Benchmark Descripton below Benchmark header on  Benchmark Review page$")
		public void user_should_be_able_to_see_the_style_name_below_style_header_on_update_strategy_page()
				throws Throwable {
			Assert.assertTrue(
					action.getElement("Benchmark |").getText().contains(action.getElement("Benchmark Description").getAttribute("value")));
			Reporter.addStepLog("validated that the Benchmark header value matches with the Benchmark Description");
			Reporter.addScreenCapture();
		}
	  
	  
	  @And("^User clicks on Back Link on Review Benchmark page$")
	    public void user_clicks_on_back_link_on_review_benchmark_page() throws Throwable {
		 action.click(action.getElement("Back Link"));
		 Reporter.addStepLog("clicked on Back Link");

	    }
	 
	
	 @Then("^User should be able to see the updated values for the following attributes in Update Benchmark Review page$")
	    public void user_should_be_able_to_see_the_updated_values_for_the_following_attributes_in_update_Benchmark_review_page(List<String> attribute) throws Throwable {
		 sheet = exlObj.getSheet("Valid");
			
			for (int i=0;i<attribute.size();i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myElement = reviewStylePage.findElementByDynamicXpath("//small[text()='"+attribute.get(i)+"']/parent::p/following-sibling::span");
			Assert.assertTrue(myElement.getText().equalsIgnoreCase((String)exlObj.getCellData(sheet, rowIndex, cellIndex)));
			Reporter.addStepLog("verified the value for "+attribute.get(i));
		
					
			}
			Reporter.addScreenCapture();
	    }
	

}