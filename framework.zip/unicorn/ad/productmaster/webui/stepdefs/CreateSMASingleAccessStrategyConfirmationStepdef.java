package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreateSMASingleAccessStrategyConfirmationStepdef {

	CreateSMASingleAccessStrategyConfirmationPage confirmationPage = new CreateSMASingleAccessStrategyConfirmationPage("AD_PM_CreateSMASingleAccessStrategyConfirmationPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String strategyCode = "6FKB";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	
	@Then("^User should be able to see confirmation message in Confirmation Page$")
    public void user_should_be_able_to_see_confirmation_message_in_confirmation_page() throws Throwable {
		Action.pause(3000);
    	assertTrue(confirmationPage.isUserOnConfirmatioPage());
    	strategyCode = confirmationPage.getStrategyCode();	
    }
	
	@Then("User should be able to see the confirmation page")
	public void user_should_be_able_to_see_the_confirmation_page() {
		Action.pause(3000);
		assertTrue(confirmationPage.isUserOnConfirmatioPage());
	}
	
	@And("^(.+) provided during create SMA Single Access Strategy should be stored in Data base$")
    public void provided_during_create_sma_single_access_strategy_should_be_stored_in_data_base(String mandatorydetails) throws Throwable {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

    	String[] temp = null;
		
		//String environment = property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}
		
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String excelData;
		List<String> excelDataGiven = new ArrayList<String>();
		int cellnum = 1;
		int i =1;
		
		String label = (String) exlObj.getCellData(sheet, 0, cellnum).toString(); 
				//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
				
		if(label == "")
			label = "isEmpty";
		while (label != "isEmpty") {
			
			
			
				excelData = (String) exlObj.getCellData(sheet, rowIndex, i).toString();
						//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, i);
				//System.out.println(excelData);
			
			if(excelData == "") {
				excelData = "isEmpty";
			}else if(excelData.equalsIgnoreCase("yes")) {
				excelData = "t";
			}else if(excelData.equalsIgnoreCase("no")) {
				excelData = "f";
			}else if(label.contains("onlysort")) {
				
				if(excelData.contains(",")) {
					String[] percentages = excelData.split(",");
					
					//String[] temp = null;
					ArrayList<String> percent = new ArrayList<String>();
					for(String E : percentages) {
						temp = E.split("-");
						percent.add(temp[0]);
					}
					Collections.sort(percent);
					excelData = ""; 
					for (String F : percent) {
						excelData = excelData+F+":";
					}
					
				}
				
			}else if(label.contains("UnbundledNodeIds")) {
				
				if(excelData.contains(",")) {
					String[] unbundledNodeIdName = excelData.split(",");
					
					//String[] temp = null;
					ArrayList<String> unbundle = new ArrayList<String>();
					for(String G : unbundledNodeIdName) {
						temp = G.split("-");
						unbundle.add(temp[0]);
					}
					Collections.sort(unbundle);
					excelData = ""; 
					for (String H : unbundle) {
						excelData = excelData+H+":";
					}
					
				}else {
						String[] split = excelData.split("-");
						excelData = split[0];	
				}
				
			}else if(label.contains("Benchmark Name")) {
				
				if(excelData.contains(",")) {
					String[] benchmarkNames = excelData.split(",");
					
					//String[] temp = null;
					ArrayList<String> benchmark = new ArrayList<String>();
					for(String G : benchmarkNames) {
						temp = G.split(" - ");
						benchmark.add(temp[1]);
					}
					Collections.sort(benchmark);
					excelData = ""; 
					for (String H : benchmark) {
						excelData = excelData+H+":";
					}
					
				}else {
					String[] split2 = excelData.split(" - ");
					excelData = split2[1];
				}
			}
					
			if(label.contains("ignore")) {
			    		cellnum++;
			    		i++;
			    		label = (String) exlObj.getCellData(sheet, 0, cellnum);
			    				//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
			    		if(label == "")
			    			label = "isEmpty";
			}else {
				
				//Handling Checkboxes
				if(label.contains("specialdata")) {
					if(excelData.contains("f") || excelData.contains("isEmpty")) {
						excelData = "specialfalse";
					}
				}
				excelDataGiven.add(excelData);
				//System.out.println(excelData+"--"+label+ " -Data from Excel");
				
			cellnum++;
			i++;
			label = (String) exlObj.getCellData(sheet, 0, cellnum);
			if(label == "")
				label = "isEmpty";
			}
			
		}
		
		String temporaryLabel;
		cellnum = 1;		
    	pmdb.DBConnectionStart();
    	
    	List<String> dbData = new ArrayList<String>();
    	String dbDataIterator;
    	sheetName = "SQLquery";
    	sheet = exlObj.getSheet("SQLquery");
    	ResultSet rs;
    	label  = (String) exlObj.getCellData(sheet, cellnum, 0);
    			//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
		if(label == "")
			label = "isEmpty";
		
		//Voluntary Reorg address-Same as Proxy and Interim Address - Same as Proxy both are UI derived not from backend
		//Ignoring both above - not geting any scripts for same
		
		while (label != "isEmpty") {
			
			
			if(label.contains("ignore")) {
    		cellnum++;
    		label = (String) exlObj.getCellData(sheet, cellnum, 0);
    		if(label == "")
    			label = "isEmpty";
			}
			else {
				temporaryLabel = null;
				dbDataIterator = "testnull";
				ArrayList<String> tempData = new ArrayList<String>();
				
				String SQLquery = (String) exlObj.getCellData(sheet, cellnum, 1); 
						//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
	    		SQLquery = SQLquery.replace("@data", "'"+strategyCode+"'");
	    		rs= DBManager.executeSelectQuery(SQLquery);
	    		String labelname = (String) exlObj.getCellData(sheet, cellnum, 2); 
	    				//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
	    		int count = 1;
	    		while(rs.next()) {
	    			
	    				dbDataIterator = rs.getString(labelname);
	    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    				dbDataIterator = "isEmpty";
		    			}
	    				
	    				
	    				tempData.add(dbDataIterator);
	    				
	    		 }
	    		//to handle Zero records from DB 
	    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
	    			dbDataIterator = "isEmpty";
	    		}
	    		if(tempData.size() > 1) {
	    			Collections.sort(tempData);
	    			dbDataIterator = "";
	    			for (String G : tempData) {
						dbDataIterator = dbDataIterator+G+":";
					}
	    			tempData.clear();
	    			
	    		}
	    		
	    		//Handling Checkboxes
	    		if(label.contains("_specialdata")) {
    				if(dbDataIterator.equals("f")) {
    					dbDataIterator = "specialfalse";
    				}
	    		}
	    		dbData.add(dbDataIterator);
				cellnum++;
	    		label = (String) exlObj.getCellData(sheet, cellnum, 0);
	    		if(label == "")
	    			label = "isEmpty";
			}
		}
		
		
    	cellnum = 1;
    	int listno = 1;
    	label  = (String) exlObj.getCellData(sheet, cellnum, 0);
		if(label == "")
			label = "isEmpty";
		while (label != "isEmpty") {
			
					if(label.contains("ignore")) {
							cellnum++;
							label = (String) exlObj.getCellData(sheet, cellnum, 0);
									if(label == "")
										label = "isEmpty";
					}
					else {
    				
						try {
							//System.out.println("DB Data -- "+label+" -- "+dbData.get(listno - 1) + " for Strategy code :: "+strategyCode);
							//System.out.println("Excel Data -- "+label+" -- "+excelDataGiven.get(listno - 1) + " for Strategy code :: "+strategyCode);
							assertTrue(dbData.get(listno - 1).contains(excelDataGiven.get(listno - 1)));
						} catch (Exception e) {
							// Data Base value is not same as value provided
							Reporter.addStepLog("Data Base value is not same as value provided");
						}
    			
    			
    			cellnum++;
    			listno++;
        		label = (String) exlObj.getCellData(sheet, cellnum, 0);
        		if(label == "")
        			label = "isEmpty";
					}
		}
    	
    	pmdb.DBConnectionClose();
    }
	
	@And("^a notification is sent to Notification Hub after Create SMA Single Access flow$")
    public void a_notification_is_sent_to_notification_hub_after_create_sma_single_access_flow() throws Throwable {
        
    }

    @And("^Payload is sent to Data Hub after Create SMA Single Access flow$")
    public void payload_is_sent_to_data_hub_after_create_sma_single_access_flow() throws Throwable {
    	
    }
    
    @Then("^User should be able to see (.+) in Confirmation Page in SMA Single Access flow$")
    public void user_should_be_able_to_see_in_confirmation_page_in_sma_single_access_flow(String confirmationmessage) {
        
    	Action.pause(3000);
    	assertTrue(confirmationPage.isStrategyCreatedSuccessfully());
    	assertTrue(confirmationPage.isStrategyCreatedMessageDisplayed(confirmationmessage));
    	
    }
    
    @And("^(.+) text should be displayed in \"([^\"]*)\" color on Confirmation Page$")
    public void text_should_be_displayed_in_something_color_on_confirmation_page(String confirmationmessage, String strArg1) {
        assertTrue(confirmationPage.isConfirmationMessageDisplayedInBlack(strArg1));
    }
    
    @And("^Status of Created SMA Single Access should be Pending$")
    public void status_of_created_sma_single_access_should_be_pending() throws SQLException, IOException {
    	pmdb.DBConnectionStart();
    	
    	//List<String> dbData = new ArrayList<String>();
    	String dbDataIterator;
    	//sheet = exlObj.getSheet("SQLquery");
    	sheetName = "SQLquery";
    	sheet = exlObj.getSheet(sheetName);
    	ResultSet rs;
    	//String label  = (String) exlObj.getCellData(sheet, cellnum, 0).toString();
		
			
			
			
				//temporaryLabel = null;
				dbDataIterator = "testnull";
				
				
				String SQLquery = (String) exlObj.getCellData(sheet, 82, 1);
						//(String) exlObj.getCellData(sheet, 82, 1);
	    		SQLquery = SQLquery.replace("@data", "'"+strategyCode+"'");
	    		rs= DBManager.executeSelectQuery(SQLquery);
	    		String labelname = (String) exlObj.getCellData(sheet, 82, 2);
	    		int count = 1;
	    		while(rs.next()) {
	    			
	    				dbDataIterator = rs.getString(labelname);
	    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    				dbDataIterator = "isEmpty";
		    			}
	    				
	    		}
	    		//to handle Zero records from DB 
	    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
	    			dbDataIterator = "isEmpty";
	    		}
	    		
					//System.out.println(dbDataIterator);
					assertTrue(dbDataIterator.equals("Pending"));
					
			    	pmdb.DBConnectionClose();
				
			}
    
    @And("^User clicks on Close Button in Confirmation page$")
    public void user_clicks_on_close_button_in_confirmation_page() {
    	confirmationPage.clickOnDoneButton();
    }
    
    @And("^Strategy code from Confirmation page is stored with  (.+) in Excel$")
    public void strategy_code_from_confirmation_page_is_stored_with_in_excel(String mandatorydetails) throws IOException {
    	//set the FOA Code in Excel
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	mandatorydetails = mandatorydetails +"_"+ SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		exlObj.setCellData(sheet, rowIndex, 82, strategyCode);
    	//PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 82, strategyCode);
    }
    
    @And("^selected_benchmark_type value should be \"([^\"]*)\" in DB for Create SMA SA$")
    public void selectedbenchmarktype_value_should_be_something_in_db_for_create_sma_sa(String benchmarkType) throws SQLException {
    	pmdb.DBConnectionStart();

		String dbDataIterator = "testnull";
		String replaceData = null;
		// Selecting the Sheet based on User

		sheetName = "Query";
		replaceData = strategyCode;

		int cellnum = 4;
		ResultSet rs;

		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		rs = DBManager.executeSelectQuery(SQLquery);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
		int count = 1;
		while (rs.next()) {

			dbDataIterator = rs.getString(labelname);
			if (rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}

		}
		// to handle Zero records from DB
		if (dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		assertTrue(dbDataIterator.equalsIgnoreCase(benchmarkType));
		Reporter.addStepLog("Selected Benchmark Type is stored as " +benchmarkType+ " in DB");
    }
		
    
}
