package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.ResultSet;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStyleReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStyleConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStyleDetailsPage;

public class UpdateStyleStepDef {

	LandingPage lp = new LandingPage("AD_PM_LandingPage");
	CreateStyleDetailsPage EISD = new CreateStyleDetailsPage("AD_PM_CreateStylePage");
	UpdateStyleDetailsPage UEISD = new UpdateStyleDetailsPage("AD_PM_UpdateStyleUIPage");
	CreateStyleReviewPage SRP = new CreateStyleReviewPage("AD_PM_CreateStyleReviewPage");
	UpdateStyleConfirmationPage UCP = new UpdateStyleConfirmationPage("AD_PM_UpdateStyleConfirmationPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
	String mandatorydetails, sheetName = "TDR10_DataValidation";
	PMPageGeneric pmPageGeneric = new PMPageGeneric("AD_PM_BenchmarkSortAndFilterPage");
	int rowIndex;
	String searchToken;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError;
	String token1, token2, token3, token4, token5, token6, token7, token8, token9, token10, token11, token12, token13,
			token14, token15, token16 = null;
	Process p = null;
	String kafkaPath = "C://PM_SANITYTEST//kafka_2.13-3.2.1//bin//windows";
	String testmucNHLogFilePath, testmucDHLogFilePath = "";
	String styleId = null;
	String styleName="";
	
	@When("^User enters (.+) search token on Global Serach input box on PM landing page$")
	public void user_enters_search_token_on_global_serach_input_box_on_pm_landing_page(String mandatorydetails)
			throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		searchToken = (String) exlObj.getCellData(sheet, rowIndex, 1);
		if (searchToken != "") {
			lp.enterStyleSearchToken(searchToken);
		}

	}

	@And("^User clicks on search icon$")
	public void user_clicks_on_search_icon() throws Throwable {
		lp.clickOnSearchIcon();
	}

	@Then("^User should be able to see Results button with search results$")
	public void user_should_be_able_to_see_results_button_with_search_results() throws Throwable {
		lp.verifySeeAllResultsButton();
	}

	@When("^User clicks on see Results button$")
	public void user_clicks_on_see_results_button() throws Throwable {
		lp.clickOnSeeAllResultsButton();
	}

	@Then("^User should navigate to See All Results tab$")
	public void user_should_navigate_to_see_all_results_tab() throws Throwable {
		lp.verifyUserIsOnStyleSearchResultsTab();
	}

	@And("^User clicks on ellipses icon present right to Style Name attribute$")
	public void user_clicks_on_ellipses_icon_present_right_to_style_name_attribute() throws Throwable {
		lp.clickOnStyleGridEllipsesIcon();
		// lp.mouseHoveOnSearchedRecordsOnGrid();
		// lp.clickOnEllipsesIcon();
	}

	@When("^User clicks on Edit Details icon$")
	public void user_clicks_on_edit_details_icon() throws Throwable {
		lp.clickOnStyleEditButton();
		// lp.verifyOnViewDetailsLink();
		// lp.clickOnViewDetailsLink();
	}

	@Then("^User should be able to see View Style header$")
	public void user_should_be_able_to_see_view_style_header() throws Throwable {
		lp.verifyUserIsOnViewStylePage();
	}

	@Then("^User should be able to see View Draft header$")
	public void user_should_be_able_to_see_view_Draft_header() throws Throwable {
		lp.verifyUserIsOnViewDraftPage();
	}

	@When("^User clicks on Continue Editing button on View Style page$")
	public void user_clicks_on_continue_editing_button_on_view_style_page() throws Throwable {
		lp.clickOnStyleViewEditButton();
	}

	@When("^User clicks on Cancel button on view style page$")
	public void user_clicks_on_cancel_button_on_view_style_page() throws Throwable {
		lp.clickOnStyleViewCancelButton();
	}

	@Then("^User should be able to see Enter Investment Style Details header in update flow$")
	public void user_should_be_able_to_see_enter_investment_style_details_header_in_update_flow() throws Throwable {
		UEISD.isUserOnCreateStyleEnterInvestmentStyleDetailsPage();
	}

	@And("^User updates all the (.+) on  Enter Investment Style Details page$")
	public void user_updates_all_the_on_enter_investment_style_details_page(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String hocomments = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String piv_Y = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String piv_N = (String) exlObj.getCellData(sheet, rowIndex, 5);

		exlObj.closeWorkBook();

		if (investmentStyleName != "") {
			UEISD.enterInvestmentStyleName(investmentStyleName);
		}

		UEISD.enterRiskCategory();
		UEISD.enterBaseTemplate();
		if (piv_Y != piv_N) {
			UEISD.enterFeeScheduleType(piv_Y, piv_N);
		}
		UEISD.enterStyleCategory();
		UEISD.enterBalancedAllocation();
		UEISD.enterComparativeUniverse();
		UEISD.enterGeographicIndicator();
		UEISD.enterMarketCap();
		if (hocomments != "") {
			UEISD.enterHomeOfficeComments(hocomments);
		}

	}

	@And("^User inputs all the (.+) for radio button attributes PIV Style on Style Details page in update flow$")
	public void user_inputs_all_the_for_radio_button_attributes_piv_style_on_style_details_page(String mandatorydetails)
			throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String piv_Y = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String piv_N = (String) exlObj.getCellData(sheet, rowIndex, 5);
		exlObj.closeWorkBook();
		if (investmentStyleName != "") {
			UEISD.enterInvestmentStyleName(investmentStyleName);
		}
		if (piv_Y != piv_N) {
			UEISD.enterFeeScheduleType(piv_Y, piv_N);
		}
		Reporter.addCompleteScreenCapture();
	}

	@Then("^user validates the Style Print functionality for (.+)$")
    public void user_validates_the_style_print_functionality_for(String entityName) throws Throwable {
		int i = 1;
		while (i <= 6) {
			PMPageGeneric.setCellDataSync(excelFilePath, entityName, 1, i-1,
					SRP.getTextfromGridforRow(String.valueOf(i)));
			i++;
		}
		SRP.clickOnPrintButton();
		pmPageGeneric.verifyPrintFunctionalityForFirstEntity(excelFilePath, entityName);
    }
    
	
	@When("^User clicks on Nextbutton1 in Enter Investment Style Details page$")
	public void user_clicks_on_nextbutton1_in_enter_investment_style_details_page() throws Throwable {
		UEISD.clickOnNextButton1();
	}

	@Then("^User should be able to see Benchmark and Asset Classification header in update flow$")
	public void user_should_be_able_to_see_benchmark_and_asset_classification_header_in_update_flow() throws Throwable {
		UEISD.isUserOnBenchmarkandAssetClassificationHeaderPage();
	}

	@When("^User changes benchmark category from Since Inception to Cap n Go and adds multiple timeperiods with multiple custom benchmarks$")
	public void user_changes_benchmark_category_from_since_inception_to_cap_n_go() throws Throwable {
		UEISD.enterBundledAssetClassification();
		UEISD.enterSingleUnbundledAssetClassification();
		UEISD.enterCapnGoComparativeBenchmark();
	}

	@And("^User able to verify the selection of comparative benchmark type on Style benchmark page as seen in DB$")
	public void user_able_to_verify_the_selection_of_comparative_benchmark_type_on_style_benchmark_page_as_seen_in_db()
			throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "TDR10_DataValidation";
		String SQLquery10, labelname = null;
		String label10;
		ResultSet rs10;
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;
		// style_name
		label10 = (String) exlObj.getCellData(sheet, 10, cellnum - 1).toString();
		System.out.println(label10);
		pmdb.DBConnectionStart();
		SQLquery10 = (String) exlObj.getCellData(sheet, 10, cellnum);
		SQLquery10 = SQLquery10.replace("@data", "'" + searchToken + "'") + " limit 1";
		System.out.println("SQLquery10= " + SQLquery10);
		rs10 = DBManager.executeSelectQuery(SQLquery10);
		while (rs10.next()) {
			token1 = rs10.getString(1);
			if (rs10.wasNull()) {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}

		UEISD.verifyComparativeBenchmarkSelection(token1);
	}

	@And("^User updates all the (.+) with style benchmarks on Benchmark and Asset Classification page in update flow$")
	public void user_updates_all_the_with_style_benchmarks_on_benchmark_and_asset_classification_page(
			String mandatorydetails) throws Throwable {

		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 7);
		exlObj.closeWorkBook();
		UEISD.enterBundledAssetClassification();
		UEISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			UEISD.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@When("^User clicks on Nextbutton1 in Benchmark and Asset Classification page in update flow$")
	public void user_clicks_on_next_button1_in_benchmark_and_asset_classification_page() throws Throwable {
		UEISD.clickOnNextButton3();
	}

	@When("^User clicks on Previous button in Benchmark and Asset Classification page in update flow$")
	public void user_clicks_on_previous_button_in_benchmark_and_asset_classification_page_in_update_flow()
			throws Throwable {
		UEISD.clickOnPreviousButton1InBenchmarkPage();
	}

	@Then("^User should be able to see Review header in update flow$")
	public void user_should_be_able_to_see_review_header() throws Throwable {
		SRP.verifyreviewheaderinCreateStyleReviewPage();
	}

	@And("^User reviews all the details provided earlier on Review page in update flow$")
	public void user_reviews_all_the_details_provided_earlier_on_review_page() throws Throwable {
		SRP.verifyreviewpagedetailsinCreateStyleReviewPage();
	}

	@Then("^User should be able to see the same data while navigating pages using the previous button$")
	public void user_should_be_able_to_see_the_same_data_while_navigating_pages_using_the_previous_button()
			throws Throwable {
		SRP.verifyreviewpagedetailsinCreateStyleReviewPage();
	}

	@When("^User clicks on Previous button in Review page in update flow$")
	public void user_clicks_on_previous_button_in_review_page_in_update_flow() throws Throwable {
		SRP.clickOnPreviousButton2InReviewPage();
	}

	@When("^User clicks on Submit button in Review page in update flow$")
	public void user_clicks_on_submit_button_in_review_page() throws Throwable {
		SRP.verifysubmitButtoninCreateStyleReviewPage();
	}

	@Then("^User should be able to see Confirmation header in update flow$")
	public void user_should_be_able_to_see_confirmation_header() throws Throwable {
		UCP.verifyconfirmationheaderinUpdateStyleConfPage();
	}

	@And("^User should be able to see Your Investment Style Updation Request Has Been Submitted message getting displayed on Confirmation page$")
	public void user_should_be_able_to_see_your_investment_style_updation_request_has_been_submitted_message_getting_displayed_on_confirmation_page()
			throws Throwable {
		UCP.verifyUpdateRequestSubmittedMessageinUpdateStyleConfPage();
		UCP.verifystyleidinUpdateStyleconfPage();
	}

	@When("^User clicks on Done button in Confirmation page in update flow$")
	public void user_clicks_on_done_button_in_confirmation_page() throws Throwable {
		UCP.verifyDoneButtoninUpdateStyleConfPage();
	}

	@Then("^User Should be able to see Product Master landing page in update flow$")
	public void user_should_be_able_to_see_product_master_landing_page() throws Throwable {
		lp.verifyProductMasterheaderonlandingpage();
	}

	@And("^User updates all the (.+) with single custom benchmarks on Benchmark and Asset Classification page in update flow$")
	public void user_updates_all_the_with_custom_benchmarks_on_benchmark_and_asset_classification_page_in_update_flow(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 7);
		exlObj.closeWorkBook();
		UEISD.enterBundledAssetClassification();
		UEISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			UEISD.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@And("^User updates all the (.+) with Multiple UnBundled Asset Classification data and Custom based benchmarks on Benchmark and Asset Classification page in update flow$")
	public void user_updates_all_the_with_multiple_unbundled_asset_classification_data_and_custom_based_benchmarks_on_benchmark_and_asset_classification_page_in_update_flow(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 7);
		exlObj.closeWorkBook();
		UEISD.enterBundledAssetClassification();
		UEISD.enterMultipleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			UEISD.enterMultipleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@When("^User clicks on Nextbutton2 in Benchmark and Asset Classification page in update flow$")
	public void user_clicks_on_nextbutton2_in_benchmark_and_asset_classification_page_in_update_flow()
			throws Throwable {
		UEISD.clickOnNextButton2();
	}

	@And("^User updates all the (.+) with Multiple UnBundled Asset Classification data and Style based benchmarks on Benchmark and Asset Classification page in update flow$")
	public void user_updates_all_the_with_multiple_unbundled_asset_classification_data_and_style_based_benchmarks_on_benchmark_and_asset_classification_page_in_update_flow(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 7);
		exlObj.closeWorkBook();
		UEISD.enterBundledAssetClassification();
		UEISD.enterMultipleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			UEISD.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@And("^User should be able to see \"([^\"]*)\" label$")
	public void user_should_be_able_to_see_something_label(String capsStyleLabel) throws Throwable {
		lp.compareCapsStyleLabel(capsStyleLabel);
	}

	@And("^User should be able to see \"([^\"]*)\" label in benchmark page$")
	public void user_should_be_able_to_see_something_label_in_benchmark_page(String capsStyleLabel2) throws Throwable {
		lp.compareCapsStyleLabel2(capsStyleLabel2);
	}

	@And("^User should be able to see \"([^\"]*)\" label in review page$")
	public void user_should_be_able_to_see_something_label_in_review_page(String capsStyleLabel3) throws Throwable {
		lp.compareCapsStyleLabel3(capsStyleLabel3);
	}

	@Then("^User should not be able to see \"([^\"]*)\" Option$")
	public void user_should_not_be_able_to_see_something_option(String deleteOptionHidden) throws Throwable {
		lp.isDeleteOptionHidden(deleteOptionHidden);
	}

	@And("^User should be able to see \"([^\"]*)\" label getting displayed in View Details page of Style entity$")
	public void user_should_be_able_to_see_something_label_getting_displayed_in_view_details_page_of_style_entity(
			String customLabel1) throws Throwable {
		lp.compareCustomLabel1(customLabel1);
	}

	@And("^User should be able to see \"([^\"]*)\" label getting displayed in benchmark page of Style entity$")
	public void user_should_be_able_to_see_something_label_getting_displayed_in_benchmark_page_of_style_entity(
			String customLabel2) throws Throwable {
		lp.compareCustomLabel2(customLabel2);
	}

	@And("^User should be able to see \"([^\"]*)\" label getting displayed in Review Details page of Style entity$")
	public void user_should_be_able_to_see_something_label_getting_displayed_in_review_details_page_of_style_entity(
			String customLabel3) throws Throwable {
		lp.compareCustomLabel3(customLabel3);
	}

	@When("^User inputs the style name from conversion data in landing page in global search text box$")
	public void user_inputs_the_style_name_from_conversion_data_in_landing_page_in_global_search_text_box()
			throws Throwable {
		lp.verifyProductMasterheaderonlandingpage();
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "TDR10_DataValidation";
		String SQLquery, labelname = null;

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;
		String label0 = (String) exlObj.getCellData(sheet, 0, cellnum - 1).toString();
		System.out.println(label0);
		pmdb.DBConnectionStart();
		SQLquery = (String) exlObj.getCellData(sheet, 0, cellnum) + " limit 1";
		ResultSet rs0, rs;
		rs0 = DBManager.executeSelectQuery(SQLquery);
		while (rs0.next()) {
			token1 = rs0.getString(1);
			System.out.println(token1);
		}
		String label = (String) exlObj.getCellData(sheet, 1, cellnum - 1).toString();
		System.out.println(label);
		SQLquery = (String) exlObj.getCellData(sheet, 1, cellnum);
		SQLquery = SQLquery.replace("@data", "'" + token1 + "'") + " limit 1";
		System.out.println(SQLquery);
		rs = DBManager.executeSelectQuery(SQLquery);
		while (rs.next()) {
			token1 = rs.getString(1);
			System.out.println(token1);
		}
		lp.enterStyleSearchToken(token1);
		pmdb.DBConnectionClose();

	}

	@And("^User selects the first record from style grid view in landing page$")
	public void user_selects_the_first_record_from_style_grid_view_in_landing_page() throws Throwable {

		lp.verifyUserIsOnStyleSearchResultsTab();
		lp.isUserOnStyleResultsTab();
		lp.clickOnStyleGridEllipsesIcon();
		lp.clickOnStyleEditButton();
	}

	@Then("^User should see View Style Page in Update Style flow$")
	public void user_should_see_view_style_page_in_update_style_flow() throws Throwable {
		lp.verifyUserIsOnViewStylePage();
		// lp.clickOnStyleViewEditButton();
	}

	@And("^User should be able to compare style entity attributes present in db should match with value on UI$")
	public void user_should_be_able_to_compare_stylename_attribute_present_in_db_should_match_with_value_on_ui()
			throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "TDR10_DataValidation";
		String SQLquery1, SQLquery2, SQLquery3, SQLquery4, SQLquery5, SQLquery6, SQLquery7, SQLquery8, labelname = null;
		String label1, label2, label3, label4, label5, label6, label7, label8;
		ResultSet rs1, rs2, rs3, rs4, rs5, rs6, rs7, rs8;

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;
		// style_name
		label1 = (String) exlObj.getCellData(sheet, 2, cellnum - 1).toString();
		System.out.println(label1);
		pmdb.DBConnectionStart();
		SQLquery1 = (String) exlObj.getCellData(sheet, 2, cellnum);
		SQLquery1 = SQLquery1.replace("@data", "'" + token1 + "'") + " limit 1";
		rs1 = DBManager.executeSelectQuery(SQLquery1);
		while (rs1.next()) {
			token1 = rs1.getString(1);
			if (rs1.wasNull()) {
				token1 = "isempty";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
			}
			System.out.println("token2=" + token1);
		}
		UEISD.compareStyleSearchToken(token1);
		// exlObj.setCellData(sheet, 2, cellnum + 2, token1);
		// risk_category
		label2 = (String) exlObj.getCellData(sheet, 3, cellnum - 1).toString();
		System.out.println(label2);
		SQLquery2 = (String) exlObj.getCellData(sheet, 3, cellnum);
		SQLquery2 = SQLquery2.replace("@data", "'" + token1 + "'") + " limit 1";
		rs2 = DBManager.executeSelectQuery(SQLquery2);
		token2 = "testnull";
		while (rs2.next()) {
			token2 = rs2.getString(1);
			if (rs2.wasNull()) {
				token2 = "isempty";
			}
			System.out.println("token3=" + token2);
		}
		if (token2 == "testnull") {
			token2 = "null";
			if (token2 == "null") {
				token2 = "isempty";
			}
			System.out.println("token3=" + token2);
		}
		UEISD.compareRiskCategoryToken(token2);
		// piv_style
		label3 = (String) exlObj.getCellData(sheet, 4, cellnum - 1).toString();
		System.out.println(label3);
		SQLquery3 = (String) exlObj.getCellData(sheet, 4, cellnum);
		SQLquery3 = SQLquery3.replace("@data", "'" + token1 + "'") + " limit 1";
		rs3 = DBManager.executeSelectQuery(SQLquery3);
		token3 = "testnull";
		boolean token31;
		while (rs3.next()) {
			token31 = rs3.getBoolean(1);
			token3 = new Boolean(token31).toString();
			if (rs3.wasNull()) {
				token3 = "isempty";
			}
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 1, token3);
		}
		if (token3 == "testnull") {
			token3 = "null";
			if (token3 == "null") {
				token3 = "isempty";
			}
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 1, token3);
		}
		UEISD.comparePIVStyleToken(token3);
		// fee_schedule_type
		label4 = (String) exlObj.getCellData(sheet, 5, cellnum - 1).toString();
		System.out.println(label4);
		SQLquery4 = (String) exlObj.getCellData(sheet, 5, cellnum);
		SQLquery4 = SQLquery4.replace("@data", "'" + token1 + "'") + " limit 1";
		rs4 = DBManager.executeSelectQuery(SQLquery4);
		token4 = "testnull";
		while (rs4.next()) {
			token4 = rs4.getString(1);
			if (rs4.wasNull()) {
				token4 = "isempty";
			}
			System.out.println("token5=" + token4);
		}
		if (token4 == "testnull") {
			token4 = "null";
			if (token4 == "null") {
				token4 = "isempty";
			}
			System.out.println("token5=" + token4);
		}
		UEISD.compareFeeScheduleTypeToken(token4);
		// style_category
		label5 = (String) exlObj.getCellData(sheet, 6, cellnum - 1).toString();
		System.out.println(label5);
		SQLquery5 = (String) exlObj.getCellData(sheet, 6, cellnum);
		SQLquery5 = SQLquery5.replace("@data", "'" + token1 + "'") + " limit 1";
		rs5 = DBManager.executeSelectQuery(SQLquery5);
		token5 = "testnull";
		while (rs5.next()) {
			token5 = rs5.getString(1);
			if (rs5.wasNull()) {
				token5 = "isempty";
			}
			System.out.println("token6=" + token5);
		}
		if (token5 == "testnull") {
			token5 = "null";
			if (token5 == "null") {
				token5 = "isempty";
			}
			System.out.println("token6=" + token5);
		}
		UEISD.compareStyleCategoryToken(token5);
		// comparative_universe
		label6 = (String) exlObj.getCellData(sheet, 7, cellnum - 1).toString();
		System.out.println(label6);
		SQLquery6 = (String) exlObj.getCellData(sheet, 7, cellnum);
		SQLquery6 = SQLquery6.replace("@data", "'" + token1 + "'") + " limit 1";
		token6 = "testnull";
		rs6 = DBManager.executeSelectQuery(SQLquery6);
		while (rs6.next()) {
			token6 = rs6.getString(1);
			if (rs6.wasNull()) {
				token6 = "isempty";
			}
			System.out.println("token7=" + token6);
		}
		if (token6 == "testnull") {
			token6 = "null";
			if (token6 == "null") {
				token6 = "isempty";
			}
			System.out.println("token7=" + token6);
		}
		UEISD.compareCompUniverseToken(token6);
		// geographic_indicator
		label7 = (String) exlObj.getCellData(sheet, 8, cellnum - 1).toString();
		System.out.println(label7);
		SQLquery7 = (String) exlObj.getCellData(sheet, 8, cellnum);
		SQLquery7 = SQLquery7.replace("@data", "'" + token1 + "'") + " limit 1";
		rs7 = DBManager.executeSelectQuery(SQLquery7);
		token7 = "testnull";
		while (rs7.next()) {
			token7 = rs7.getString(1);
			if (rs7.wasNull()) {
				token7 = "isempty";
			}
			System.out.println("token8=" + token7);
		}
		if (token7 == "testnull") {
			token7 = "null";
			if (token7 == "null") {
				token7 = "isempty";
			}
			System.out.println("token8=" + token7);
		}
		UEISD.compareGeographicIndicatorToken(token7);
		// market_cap
		label8 = (String) exlObj.getCellData(sheet, 9, cellnum - 1).toString();
		System.out.println(label8);
		SQLquery8 = (String) exlObj.getCellData(sheet, 9, cellnum);
		SQLquery8 = SQLquery8.replace("@data", "'" + token1 + "'") + " limit 1";
		rs8 = DBManager.executeSelectQuery(SQLquery8);
		token8 = "testnull";
		while (rs8.next()) {
			token8 = rs8.getString(1);
			if (rs8.wasNull()) {
				token8 = "isempty";
			}
			System.out.println("token9=" + token8);
		}
		if (token8 == "testnull") {
			token8 = "null";
			if (token8 == "null") {
				token8 = "isempty";
			}
			System.out.println("token9=" + token8);
		}
		UEISD.compareMarketCapToken(token8);
		UEISD.compareTokenCount();
		pmdb.DBConnectionClose();
	}

	@And("^User should be able to compare style entity attributes present in db should match with value on PMUI Style View page$")
	public void user_should_be_able_to_compare_style_entity_attributes_present_in_db_should_match_with_value_on_pmui_style_view_page()
			throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "TDR10_DataValidation";
		String SQLquery1, SQLquery2, SQLquery3, SQLquery4, SQLquery5, SQLquery6, SQLquery7, SQLquery8, labelname = null;
		String label1, label2, label3, label4, label5, label6, label7, label8;
		ResultSet rs1, rs2, rs3, rs4, rs5, rs6, rs7, rs8;

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;
		// style_name
		label1 = (String) exlObj.getCellData(sheet, 2, cellnum - 1).toString();
		System.out.println(label1);
		pmdb.DBConnectionStart();
		SQLquery1 = (String) exlObj.getCellData(sheet, 2, cellnum);
		SQLquery1 = SQLquery1.replace("@data", "'" + token1 + "'") + " limit 1";
		rs1 = DBManager.executeSelectQuery(SQLquery1);
		while (rs1.next()) {
			token1 = rs1.getString(1);
			if (rs1.wasNull()) {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		UEISD.compareViewStyleSearchToken(token1);
		// exlObj.setCellData(sheet, 2, cellnum + 2, token1);
		// risk_category
		label2 = (String) exlObj.getCellData(sheet, 3, cellnum - 1).toString();
		System.out.println(label2);
		SQLquery2 = (String) exlObj.getCellData(sheet, 3, cellnum);
		SQLquery2 = SQLquery2.replace("@data", "'" + token1 + "'") + " limit 1";
		rs2 = DBManager.executeSelectQuery(SQLquery2);
		token2 = "testnull";
		while (rs2.next()) {
			token2 = rs2.getString(1);
			if (rs2.wasNull()) {
				token2 = "isempty";
				token2 = "—";
			}
			System.out.println("token3=" + token2);
		}
		if (token2 == "testnull") {
			token2 = "null";
			if (token2 == "null") {
				token2 = "isempty";
				token2 = "—";
			}
			System.out.println("token3=" + token2);
		}
		UEISD.compareViewRiskCategoryToken(token2);
		// piv_style
		label3 = (String) exlObj.getCellData(sheet, 4, cellnum - 1).toString();
		System.out.println(label3);
		SQLquery3 = (String) exlObj.getCellData(sheet, 4, cellnum);
		SQLquery3 = SQLquery3.replace("@data", "'" + token1 + "'") + " limit 1";
		rs3 = DBManager.executeSelectQuery(SQLquery3);
		token3 = "testnull";
		boolean token31;
		while (rs3.next()) {
			token31 = rs3.getBoolean(1);
			token3 = new Boolean(token31).toString();
			if (rs3.wasNull()) {
				token3 = "isempty";
				token3 = "—";
			}
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "testnull") {
			token3 = "null";
			if (token3 == "null") {
				token3 = "isempty";
				token3 = "—";
			}
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "true") {
			token3 = "Yes";
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "false") {
			token3 = "No";
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		UEISD.compareViewPIVStyleToken(token3);
		// fee_schedule_type
		label4 = (String) exlObj.getCellData(sheet, 5, cellnum - 1).toString();
		System.out.println(label4);
		SQLquery4 = (String) exlObj.getCellData(sheet, 5, cellnum);
		SQLquery4 = SQLquery4.replace("@data", "'" + token1 + "'") + " limit 1";
		rs4 = DBManager.executeSelectQuery(SQLquery4);
		token4 = "testnull";
		while (rs4.next()) {
			token4 = rs4.getString(1);
			if (rs4.wasNull()) {
				token4 = "isempty";
				token4 = "—";
			}
			System.out.println("1 If -> token5=" + token4);
		}
		if (token4 == "testnull") {
			token4 = "null";
			if (token4 == "null") {
				token4 = "isempty";
				token4 = "—";
			}
			System.out.println("2 If -> token5=" + token4);
		}
		UEISD.compareViewFeeScheduleTypeToken(token4);
		// style_category
		label5 = (String) exlObj.getCellData(sheet, 6, cellnum - 1).toString();
		System.out.println(label5);
		SQLquery5 = (String) exlObj.getCellData(sheet, 6, cellnum);
		SQLquery5 = SQLquery5.replace("@data", "'" + token1 + "'") + " limit 1";
		rs5 = DBManager.executeSelectQuery(SQLquery5);
		token5 = "testnull";
		while (rs5.next()) {
			token5 = rs5.getString(1);
			if (rs5.wasNull()) {
				token5 = "isempty";
				token5 = "—";
			}
			System.out.println("token6=" + token5);
		}
		if (token5 == "testnull") {
			token5 = "null";
			if (token5 == "null") {
				token5 = "isempty";
				token5 = "—";
			}
			System.out.println("token6=" + token5);
		}
		UEISD.compareViewStyleCategoryToken(token5);
		// comparative_universe
		label6 = (String) exlObj.getCellData(sheet, 7, cellnum - 1).toString();
		System.out.println(label6);
		SQLquery6 = (String) exlObj.getCellData(sheet, 7, cellnum);
		SQLquery6 = SQLquery6.replace("@data", "'" + token1 + "'") + " limit 1";
		token6 = "testnull";
		rs6 = DBManager.executeSelectQuery(SQLquery6);
		while (rs6.next()) {
			token6 = rs6.getString(1);
			if (rs6.wasNull()) {
				token6 = "isempty";
				token6 = "—";
			}
			System.out.println("token7=" + token6);
		}
		if (token6 == "testnull") {
			token6 = "null";
			if (token6 == "null") {
				token6 = "isempty";
				token6 = "—";
			}
			System.out.println("token7=" + token6);
		}
		UEISD.compareViewCompUniverseToken(token6);
		// geographic_indicator
		label7 = (String) exlObj.getCellData(sheet, 8, cellnum - 1).toString();
		System.out.println(label7);
		SQLquery7 = (String) exlObj.getCellData(sheet, 8, cellnum);
		SQLquery7 = SQLquery7.replace("@data", "'" + token1 + "'") + " limit 1";
		rs7 = DBManager.executeSelectQuery(SQLquery7);
		token7 = "testnull";
		while (rs7.next()) {
			token7 = rs7.getString(1);
			if (rs7.wasNull()) {
				token7 = "isempty";
				token7 = "—";
			}
			System.out.println("token8=" + token7);
		}
		if (token7 == "testnull") {
			token7 = "null";
			if (token7 == "null") {
				token7 = "isempty";
				token7 = "—";
			}
			System.out.println("token8=" + token7);
		}
		UEISD.compareViewGeographicIndicatorToken(token7);
		// market_cap
		label8 = (String) exlObj.getCellData(sheet, 9, cellnum - 1).toString();
		System.out.println(label8);
		SQLquery8 = (String) exlObj.getCellData(sheet, 9, cellnum);
		SQLquery8 = SQLquery8.replace("@data", "'" + token1 + "'") + " limit 1";
		rs8 = DBManager.executeSelectQuery(SQLquery8);
		token8 = "testnull";
		while (rs8.next()) {
			token8 = rs8.getString(1);
			if (rs8.wasNull()) {
				token8 = "isempty";
				token8 = "—";
			}
			System.out.println("token9=" + token8);
		}
		if (token8 == "testnull") {
			token8 = "null";
			if (token8 == "null") {
				token8 = "isempty";
				token8 = "—";
			}
			System.out.println("token9=" + token8);
		}
		UEISD.compareViewMarketCapToken(token8);
		UEISD.compareTokenCount();
		pmdb.DBConnectionClose();
	}

	@And("^User should be able to compare style entity attributes present in db should match with value on UI without tdr checks for stylebenchmarks$")
	public void user_should_be_able_to_compare_style_entity_attributes_present_in_db_should_match_with_value_on_ui_without_tdr_checks_for_stylebenchmarks()
			throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "Style_DBValidation";
		String SQLquery1, SQLquery2, SQLquery3, SQLquery4, SQLquery5, SQLquery6, SQLquery7, SQLquery8, SQLquery9,
				SQLquery10, SQLquery11, SQLquery12, SQLquery13, SQLquery14, SQLquery15, SQLquery16 = null;
		String label1, label2, label3, label4, label5, label6, label7, label8, label9, label10, label11, label12,
				label13, label14, label15, label16;
		ResultSet rs1, rs2, rs3, rs4, rs5, rs6, rs7, rs8, rs9, rs10, rs11, rs12, rs13, rs14, rs15, rs16;
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;

		// style_name
		label1 = (String) exlObj.getCellData(sheet, 2, cellnum - 1).toString();
		System.out.println(label1);
		pmdb.DBConnectionStart();
		SQLquery1 = (String) exlObj.getCellData(sheet, 2, cellnum);
		SQLquery1 = SQLquery1.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs1 = DBManager.executeSelectQuery(SQLquery1);
		while (rs1.next()) {
			token1 = rs1.getString(1);
			if (rs1.wasNull()) {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		UEISD.compareViewStyleSearchToken(token1);

		// risk_category
		label2 = (String) exlObj.getCellData(sheet, 3, cellnum - 1).toString();
		System.out.println(label2);
		SQLquery2 = (String) exlObj.getCellData(sheet, 3, cellnum);
		SQLquery2 = SQLquery2.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs2 = DBManager.executeSelectQuery(SQLquery2);
		token2 = "testnull";
		while (rs2.next()) {
			token2 = rs2.getString(1);
			if (rs2.wasNull()) {
				token2 = "isempty";
				token2 = "—";
			}
			System.out.println("token3=" + token2);
		}
		if (token2 == "testnull") {
			token2 = "null";
			if (token2 == "null") {
				token2 = "isempty";
				token2 = "—";
			}
			System.out.println("token3=" + token2);
		}
		UEISD.compareViewRiskCategoryToken(token2);

		// piv_style
		label3 = (String) exlObj.getCellData(sheet, 4, cellnum - 1).toString();
		System.out.println(label3);
		SQLquery3 = (String) exlObj.getCellData(sheet, 4, cellnum);
		SQLquery3 = SQLquery3.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs3 = DBManager.executeSelectQuery(SQLquery3);
		token3 = "testnull";
		boolean token31;
		while (rs3.next()) {
			token31 = rs3.getBoolean(1);
			token3 = new Boolean(token31).toString();
			if (rs3.wasNull()) {
				token3 = "isempty";
				token3 = "—";
			}
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "testnull") {
			token3 = "null";
			if (token3 == "null") {
				token3 = "isempty";
				token3 = "—";
			}
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "true") {
			token3 = "Yes";
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "false") {
			token3 = "No";
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		UEISD.compareViewPIVStyleToken(token3);

		// fee_schedule_type
		label4 = (String) exlObj.getCellData(sheet, 5, cellnum - 1).toString();
		System.out.println(label4);
		SQLquery4 = (String) exlObj.getCellData(sheet, 5, cellnum);
		SQLquery4 = SQLquery4.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs4 = DBManager.executeSelectQuery(SQLquery4);
		token4 = "testnull";
		while (rs4.next()) {
			token4 = rs4.getString(1);
			if (rs4.wasNull()) {
				token4 = "isempty";
				token4 = "—";
			}
			System.out.println("1 If -> token5=" + token4);
		}
		if (token4 == "testnull") {
			token4 = "null";
			if (token4 == "null") {
				token4 = "isempty";
				token4 = "—";
			}
			System.out.println("2 If -> token5=" + token4);
		}
		UEISD.compareViewFeeScheduleTypeToken(token4);

		// style_category
		label5 = (String) exlObj.getCellData(sheet, 6, cellnum - 1).toString();
		System.out.println(label5);
		SQLquery5 = (String) exlObj.getCellData(sheet, 6, cellnum);
		SQLquery5 = SQLquery5.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs5 = DBManager.executeSelectQuery(SQLquery5);
		token5 = "testnull";
		while (rs5.next()) {
			token5 = rs5.getString(1);
			if (rs5.wasNull()) {
				token5 = "isempty";
				token5 = "—";
			}
			System.out.println("token6=" + token5);
		}
		if (token5 == "testnull") {
			token5 = "null";
			if (token5 == "null") {
				token5 = "isempty";
				token5 = "—";
			}
			System.out.println("token6=" + token5);
		}
		UEISD.compareViewStyleCategoryToken(token5);

		// comparative_universe
		label6 = (String) exlObj.getCellData(sheet, 7, cellnum - 1).toString();
		System.out.println(label6);
		SQLquery6 = (String) exlObj.getCellData(sheet, 7, cellnum);
		SQLquery6 = SQLquery6.replace("@data", "'" + searchToken + "'") + " limit 1";
		token6 = "testnull";
		rs6 = DBManager.executeSelectQuery(SQLquery6);
		while (rs6.next()) {
			token6 = rs6.getString(1);
			if (rs6.wasNull()) {
				token6 = "isempty";
				token6 = "—";
			}
			System.out.println("token7=" + token6);
		}
		if (token6 == "testnull") {
			token6 = "null";
			if (token6 == "null") {
				token6 = "isempty";
				token6 = "—";
			}
			System.out.println("token7=" + token6);
		}
		UEISD.compareViewCompUniverseToken(token6);

		// geographic_indicator
		label7 = (String) exlObj.getCellData(sheet, 8, cellnum - 1).toString();
		System.out.println(label7);
		SQLquery7 = (String) exlObj.getCellData(sheet, 8, cellnum);
		SQLquery7 = SQLquery7.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs7 = DBManager.executeSelectQuery(SQLquery7);
		token7 = "testnull";
		while (rs7.next()) {
			token7 = rs7.getString(1);
			if (rs7.wasNull()) {
				token7 = "isempty";
				token7 = "—";
			}
			System.out.println("token8=" + token7);
		}
		if (token7 == "testnull") {
			token7 = "null";
			if (token7 == "null") {
				token7 = "isempty";
				token7 = "—";
			}
			System.out.println("token8=" + token7);
		}
		UEISD.compareViewGeographicIndicatorToken(token7);

		// market_cap
		label8 = (String) exlObj.getCellData(sheet, 9, cellnum - 1).toString();
		System.out.println(label8);
		SQLquery8 = (String) exlObj.getCellData(sheet, 9, cellnum);
		SQLquery8 = SQLquery8.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs8 = DBManager.executeSelectQuery(SQLquery8);
		token8 = "testnull";
		while (rs8.next()) {
			token8 = rs8.getString(1);
			if (rs8.wasNull()) {
				token8 = "isempty";
				token8 = "—";
			}
			System.out.println("token9=" + token8);
		}
		if (token8 == "testnull") {
			token8 = "null";
			if (token8 == "null") {
				token8 = "isempty";
				token8 = "—";
			}
			System.out.println("token9=" + token8);
		}
		UEISD.compareViewMarketCapToken(token8);

		// base_template
		label9 = (String) exlObj.getCellData(sheet, 10, cellnum - 1).toString();
		System.out.println(label9);
		SQLquery9 = (String) exlObj.getCellData(sheet, 10, cellnum);
		SQLquery9 = SQLquery9.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs9 = DBManager.executeSelectQuery(SQLquery9);
		token9 = "testnull";
		while (rs9.next()) {
			token9 = rs9.getString(1);
			if (rs9.wasNull()) {
				token9 = "isempty";
				token9 = "—";
			}
			System.out.println("token10=" + token9);
		}
		if (token9 == "testnull") {
			token9 = "null";
			if (token9 == "null") {
				token9 = "isempty";
				token9 = "—";
			}
			System.out.println("token10=" + token9);
		}
		UEISD.compareViewBaseTemplateToken(token9);

		// balanced_allocation
		label10 = (String) exlObj.getCellData(sheet, 11, cellnum - 1).toString();
		System.out.println(label10);
		SQLquery10 = (String) exlObj.getCellData(sheet, 11, cellnum);
		SQLquery10 = SQLquery10.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs10 = DBManager.executeSelectQuery(SQLquery10);
		token10 = "testnull";
		while (rs10.next()) {
			token10 = rs10.getString(1);
			if (rs10.wasNull()) {
				token10 = "isempty";
				token10 = "—";
			}
			System.out.println("token11=" + token10);
		}
		if (token10 == "testnull") {
			token10 = "null";
			if (token10 == "null") {
				token10 = "isempty";
				token10 = "—";
			}
			System.out.println("token11=" + token10);
		}
		UEISD.compareViewBalancedAllocationToken(token10);

		// homeoffice_comments
		label11 = (String) exlObj.getCellData(sheet, 12, cellnum - 1).toString();
		System.out.println(label11);
		SQLquery11 = (String) exlObj.getCellData(sheet, 12, cellnum);
		SQLquery11 = SQLquery11.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs11 = DBManager.executeSelectQuery(SQLquery11);
		token11 = "testnull";
		while (rs11.next()) {
			token11 = rs11.getString(1);
			if (rs11.wasNull()) {
				token11 = "isempty";
				token11 = "—";
			}
			System.out.println("token12=" + token11);
		}
		if (token11 == "testnull") {
			token11 = "null";
			if (token11 == "null") {
				token11 = "isempty";
				token11 = "—";
			}
			System.out.println("token12=" + token11);
		}
		UEISD.compareViewHOCommentsToken(token11);

		// bundlednodeid
		label12 = (String) exlObj.getCellData(sheet, 13, cellnum - 1).toString();
		System.out.println(label12);
		SQLquery12 = (String) exlObj.getCellData(sheet, 13, cellnum);
		SQLquery12 = SQLquery12.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs12 = DBManager.executeSelectQuery(SQLquery12);
		token12 = "testnull";
		while (rs12.next()) {
			token12 = rs12.getString(1);
			if (rs12.wasNull()) {
				token12 = "isempty";
				token12 = "—";
			}
			System.out.println("token13=" + token12);
		}
		if (token12 == "testnull") {
			token12 = "null";
			if (token12 == "null") {
				token12 = "isempty";
				token12 = "—";
			}
			System.out.println("token13=" + token12);
		}
		UEISD.compareViewBundledNodeIDToken(token12);

		// unbundlednodeid
		label13 = (String) exlObj.getCellData(sheet, 14, cellnum - 1).toString();
		System.out.println(label13);
		SQLquery13 = (String) exlObj.getCellData(sheet, 14, cellnum);
		SQLquery13 = SQLquery13.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs13 = DBManager.executeSelectQuery(SQLquery13);
		token13 = "testnull";
		while (rs13.next()) {
			token13 = rs13.getString(1);
			if (rs13.wasNull()) {
				token13 = "isempty";
				token13 = "—";
			}
			System.out.println("token14=" + token13);
		}
		if (token13 == "testnull") {
			token13 = "null";
			if (token13 == "null") {
				token13 = "isempty";
				token13 = "—";
			}
			System.out.println("token14=" + token13);
		}
		UEISD.compareViewUnBundledNodeIDToken(token13);

		// style benchmark name
		label14 = (String) exlObj.getCellData(sheet, 15, cellnum - 1).toString();
		System.out.println(label14);
		SQLquery14 = (String) exlObj.getCellData(sheet, 15, cellnum);
		SQLquery14 = SQLquery14.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs14 = DBManager.executeSelectQuery(SQLquery14);
		token14 = "testnull";
		while (rs14.next()) {
			token14 = rs14.getString(1);
			if (rs14.wasNull()) {
				token14 = "isempty";
				token14 = "—";
			}
			System.out.println("token15=" + token14);
		}
		if (token14 == "testnull") {
			token14 = "null";
			if (token14 == "null") {
				token14 = "isempty";
				token14 = "—";
			}
			System.out.println("token15=" + token14);
		}
		UEISD.compareViewStyleBenchmarkNameToken(token14);

		// style benchmark percentage
		label15 = (String) exlObj.getCellData(sheet, 16, cellnum - 1).toString();
		System.out.println(label15);
		SQLquery15 = (String) exlObj.getCellData(sheet, 16, cellnum);
		SQLquery15 = SQLquery15.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs15 = DBManager.executeSelectQuery(SQLquery15);
		token15 = "testnull";
		while (rs15.next()) {
			token15 = rs15.getString(1);
			if (rs15.wasNull()) {
				token15 = "isempty";
				token15 = "—";
			}
			System.out.println("token16=" + token15);
		}
		if (token15 == "testnull") {
			token15 = "null";
			if (token15 == "null") {
				token15 = "isempty";
				token15 = "—";
			}
			System.out.println("token16=" + token15);
		}
		UEISD.compareViewStyleBenchmarkPercentageToken(token15);

		// style_selection
		label16 = (String) exlObj.getCellData(sheet, 19, cellnum - 1).toString();
		System.out.println(label16);
		SQLquery16 = (String) exlObj.getCellData(sheet, 19, cellnum);
		SQLquery16 = SQLquery16.replace("@data", "'" + searchToken + "'") + " limit 1";
		System.out.println(SQLquery16);
		rs16 = DBManager.executeSelectQuery(SQLquery16);
		while (rs16.next()) {
			token16 = rs16.getString(1);
			if (rs16.wasNull()) {
				token16 = "isempty";
				token16 = "—";
			}
			System.out.println("token17=" + token16);
		}
		if (token16 == "testnull") {
			token16 = "null";
			if (token16 == "null") {
				token16 = "isempty";
				token16 = "—";
			}
			System.out.println("token17=" + token16);
		}

		lp.verifyComparativeBenchmarkSelection(token16);
		UEISD.compareTokenCount();
		pmdb.DBConnectionClose();
	}

	@And("^User should be able to compare style entity attributes present in db should match with value on UI without tdr checks for custombenchmarks$")
	public void user_should_be_able_to_compare_style_entity_attributes_present_in_db_should_match_with_value_on_ui_without_tdr_checks_for_custombenchmarks()
			throws Throwable {

		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "Style_DBValidation";
		String SQLquery1, SQLquery2, SQLquery3, SQLquery4, SQLquery5, SQLquery6, SQLquery7, SQLquery8, SQLquery9,
				SQLquery10, SQLquery11, SQLquery12, SQLquery13, SQLquery14, SQLquery15, SQLquery16 = null;
		String label1, label2, label3, label4, label5, label6, label7, label8, label9, label10, label11, label12,
				label13, label14, label15, label16;
		ResultSet rs1, rs2, rs3, rs4, rs5, rs6, rs7, rs8, rs9, rs10, rs11, rs12, rs13, rs14, rs15, rs16;
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;

		// style_name
		label1 = (String) exlObj.getCellData(sheet, 2, cellnum - 1).toString();
		System.out.println(label1);
		pmdb.DBConnectionStart();
		SQLquery1 = (String) exlObj.getCellData(sheet, 2, cellnum);
		SQLquery1 = SQLquery1.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs1 = DBManager.executeSelectQuery(SQLquery1);
		while (rs1.next()) {
			token1 = rs1.getString(1);
			if (rs1.wasNull()) {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		UEISD.compareViewStyleSearchToken(token1);

		// risk_category
		label2 = (String) exlObj.getCellData(sheet, 3, cellnum - 1).toString();
		System.out.println(label2);
		SQLquery2 = (String) exlObj.getCellData(sheet, 3, cellnum);
		SQLquery2 = SQLquery2.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs2 = DBManager.executeSelectQuery(SQLquery2);
		token2 = "testnull";
		while (rs2.next()) {
			token2 = rs2.getString(1);
			if (rs2.wasNull()) {
				token2 = "isempty";
				token2 = "—";
			}
			System.out.println("token3=" + token2);
		}
		if (token2 == "testnull") {
			token2 = "null";
			if (token2 == "null") {
				token2 = "isempty";
				token2 = "—";
			}
			System.out.println("token3=" + token2);
		}
		UEISD.compareViewRiskCategoryToken(token2);

		// piv_style
		label3 = (String) exlObj.getCellData(sheet, 4, cellnum - 1).toString();
		System.out.println(label3);
		SQLquery3 = (String) exlObj.getCellData(sheet, 4, cellnum);
		SQLquery3 = SQLquery3.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs3 = DBManager.executeSelectQuery(SQLquery3);
		token3 = "testnull";
		boolean token31;
		while (rs3.next()) {
			token31 = rs3.getBoolean(1);
			token3 = new Boolean(token31).toString();
			if (rs3.wasNull()) {
				token3 = "isempty";
				token3 = "—";
			}
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "testnull") {
			token3 = "null";
			if (token3 == "null") {
				token3 = "isempty";
				token3 = "—";
			}
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "true") {
			token3 = "Yes";
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		if (token3 == "false") {
			token3 = "No";
			System.out.println("token4=" + token3);
			exlObj.setCellData(sheet, 4, cellnum + 5, token3);
		}
		UEISD.compareViewPIVStyleToken(token3);

		// fee_schedule_type
		label4 = (String) exlObj.getCellData(sheet, 5, cellnum - 1).toString();
		System.out.println(label4);
		SQLquery4 = (String) exlObj.getCellData(sheet, 5, cellnum);
		SQLquery4 = SQLquery4.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs4 = DBManager.executeSelectQuery(SQLquery4);
		token4 = "testnull";
		while (rs4.next()) {
			token4 = rs4.getString(1);
			if (rs4.wasNull()) {
				token4 = "isempty";
				token4 = "—";
			}
			System.out.println("1 If -> token5=" + token4);
		}
		if (token4 == "testnull") {
			token4 = "null";
			if (token4 == "null") {
				token4 = "isempty";
				token4 = "—";
			}
			System.out.println("2 If -> token5=" + token4);
		}
		UEISD.compareViewFeeScheduleTypeToken(token4);

		// style_category
		label5 = (String) exlObj.getCellData(sheet, 6, cellnum - 1).toString();
		System.out.println(label5);
		SQLquery5 = (String) exlObj.getCellData(sheet, 6, cellnum);
		SQLquery5 = SQLquery5.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs5 = DBManager.executeSelectQuery(SQLquery5);
		token5 = "testnull";
		while (rs5.next()) {
			token5 = rs5.getString(1);
			if (rs5.wasNull()) {
				token5 = "isempty";
				token5 = "—";
			}
			System.out.println("token6=" + token5);
		}
		if (token5 == "testnull") {
			token5 = "null";
			if (token5 == "null") {
				token5 = "isempty";
				token5 = "—";
			}
			System.out.println("token6=" + token5);
		}
		UEISD.compareViewStyleCategoryToken(token5);

		// comparative_universe
		label6 = (String) exlObj.getCellData(sheet, 7, cellnum - 1).toString();
		System.out.println(label6);
		SQLquery6 = (String) exlObj.getCellData(sheet, 7, cellnum);
		SQLquery6 = SQLquery6.replace("@data", "'" + searchToken + "'") + " limit 1";
		token6 = "testnull";
		rs6 = DBManager.executeSelectQuery(SQLquery6);
		while (rs6.next()) {
			token6 = rs6.getString(1);
			if (rs6.wasNull()) {
				token6 = "isempty";
				token6 = "—";
			}
			System.out.println("token7=" + token6);
		}
		if (token6 == "testnull") {
			token6 = "null";
			if (token6 == "null") {
				token6 = "isempty";
				token6 = "—";
			}
			System.out.println("token7=" + token6);
		}
		UEISD.compareViewCompUniverseToken(token6);

		// geographic_indicator
		label7 = (String) exlObj.getCellData(sheet, 8, cellnum - 1).toString();
		System.out.println(label7);
		SQLquery7 = (String) exlObj.getCellData(sheet, 8, cellnum);
		SQLquery7 = SQLquery7.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs7 = DBManager.executeSelectQuery(SQLquery7);
		token7 = "testnull";
		while (rs7.next()) {
			token7 = rs7.getString(1);
			if (rs7.wasNull()) {
				token7 = "isempty";
				token7 = "—";
			}
			System.out.println("token8=" + token7);
		}
		if (token7 == "testnull") {
			token7 = "null";
			if (token7 == "null") {
				token7 = "isempty";
				token7 = "—";
			}
			System.out.println("token8=" + token7);
		}
		UEISD.compareViewGeographicIndicatorToken(token7);

		// market_cap
		label8 = (String) exlObj.getCellData(sheet, 9, cellnum - 1).toString();
		System.out.println(label8);
		SQLquery8 = (String) exlObj.getCellData(sheet, 9, cellnum);
		SQLquery8 = SQLquery8.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs8 = DBManager.executeSelectQuery(SQLquery8);
		token8 = "testnull";
		while (rs8.next()) {
			token8 = rs8.getString(1);
			if (rs8.wasNull()) {
				token8 = "isempty";
				token8 = "—";
			}
			System.out.println("token9=" + token8);
		}
		if (token8 == "testnull") {
			token8 = "null";
			if (token8 == "null") {
				token8 = "isempty";
				token8 = "—";
			}
			System.out.println("token9=" + token8);
		}
		UEISD.compareViewMarketCapToken(token8);

		// base_template
		label9 = (String) exlObj.getCellData(sheet, 10, cellnum - 1).toString();
		System.out.println(label9);
		SQLquery9 = (String) exlObj.getCellData(sheet, 10, cellnum);
		SQLquery9 = SQLquery9.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs9 = DBManager.executeSelectQuery(SQLquery9);
		token9 = "testnull";
		while (rs9.next()) {
			token9 = rs9.getString(1);
			if (rs9.wasNull()) {
				token9 = "isempty";
				token9 = "—";
			}
			System.out.println("token10=" + token9);
		}
		if (token9 == "testnull") {
			token9 = "null";
			if (token9 == "null") {
				token9 = "isempty";
				token9 = "—";
			}
			System.out.println("token10=" + token9);
		}
		UEISD.compareViewBaseTemplateToken(token9);

		// balanced_allocation
		label10 = (String) exlObj.getCellData(sheet, 11, cellnum - 1).toString();
		System.out.println(label10);
		SQLquery10 = (String) exlObj.getCellData(sheet, 11, cellnum);
		SQLquery10 = SQLquery10.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs10 = DBManager.executeSelectQuery(SQLquery10);
		token10 = "testnull";
		while (rs10.next()) {
			token10 = rs10.getString(1);
			if (rs10.wasNull()) {
				token10 = "isempty";
				token10 = "—";
			}
			System.out.println("token11=" + token10);
		}
		if (token10 == "testnull") {
			token10 = "null";
			if (token10 == "null") {
				token10 = "isempty";
				token10 = "—";
			}
			System.out.println("token11=" + token10);
		}
		UEISD.compareViewBalancedAllocationToken(token10);

		// homeoffice_comments
		label11 = (String) exlObj.getCellData(sheet, 12, cellnum - 1).toString();
		System.out.println(label11);
		SQLquery11 = (String) exlObj.getCellData(sheet, 12, cellnum);
		SQLquery11 = SQLquery11.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs11 = DBManager.executeSelectQuery(SQLquery11);
		token11 = "testnull";
		while (rs11.next()) {
			token11 = rs11.getString(1);
			if (rs11.wasNull()) {
				token11 = "isempty";
				token11 = "—";
			}
			System.out.println("token12=" + token11);
		}
		if (token11 == "testnull") {
			token11 = "null";
			if (token11 == "null") {
				token11 = "isempty";
				token11 = "—";
			}
			System.out.println("token12=" + token11);
		}
		UEISD.compareViewHOCommentsToken(token11);

		// bundlednodeid
		label12 = (String) exlObj.getCellData(sheet, 13, cellnum - 1).toString();
		System.out.println(label12);
		SQLquery12 = (String) exlObj.getCellData(sheet, 13, cellnum);
		SQLquery12 = SQLquery12.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs12 = DBManager.executeSelectQuery(SQLquery12);
		token12 = "testnull";
		while (rs12.next()) {
			token12 = rs12.getString(1);
			if (rs12.wasNull()) {
				token12 = "isempty";
				token12 = "—";
			}
			System.out.println("token13=" + token12);
		}
		if (token12 == "testnull") {
			token12 = "null";
			if (token12 == "null") {
				token12 = "isempty";
				token12 = "—";
			}
			System.out.println("token13=" + token12);
		}
		UEISD.compareViewBundledNodeIDToken(token12);

		// unbundlednodeid
		label13 = (String) exlObj.getCellData(sheet, 14, cellnum - 1).toString();
		System.out.println(label13);
		SQLquery13 = (String) exlObj.getCellData(sheet, 14, cellnum);
		SQLquery13 = SQLquery13.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs13 = DBManager.executeSelectQuery(SQLquery13);
		token13 = "testnull";
		while (rs13.next()) {
			token13 = rs13.getString(1);
			if (rs13.wasNull()) {
				token13 = "isempty";
				token13 = "—";
			}
			System.out.println("token14=" + token13);
		}
		if (token13 == "testnull") {
			token13 = "null";
			if (token13 == "null") {
				token13 = "isempty";
				token13 = "—";
			}
			System.out.println("token14=" + token13);
		}
		UEISD.compareViewUnBundledNodeIDToken(token13);

		// custom benchmark name
		label14 = (String) exlObj.getCellData(sheet, 17, cellnum - 1).toString();
		System.out.println(label14);
		SQLquery14 = (String) exlObj.getCellData(sheet, 17, cellnum);
		SQLquery14 = SQLquery14.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs14 = DBManager.executeSelectQuery(SQLquery14);
		token14 = "testnull";
		while (rs14.next()) {
			token14 = rs14.getString(1);
			if (rs14.wasNull()) {
				token14 = "isempty";
				token14 = "—";
			}
			System.out.println("token15=" + token14);
		}
		if (token14 == "testnull") {
			token14 = "null";
			if (token14 == "null") {
				token14 = "isempty";
				token14 = "—";
			}
			System.out.println("token15=" + token14);
		}
		UEISD.compareViewCustomBenchmarkNameToken(token14);

		// style benchmark percentage
		label15 = (String) exlObj.getCellData(sheet, 18, cellnum - 1).toString();
		System.out.println(label15);
		SQLquery15 = (String) exlObj.getCellData(sheet, 18, cellnum);
		SQLquery15 = SQLquery15.replace("@data", "'" + searchToken + "'") + " limit 1";
		rs15 = DBManager.executeSelectQuery(SQLquery15);
		token15 = "testnull";
		while (rs15.next()) {
			token15 = rs15.getString(1);
			if (rs15.wasNull()) {
				token15 = "isempty";
				token15 = "—";
			}
			System.out.println("token16=" + token15);
		}
		if (token15 == "testnull") {
			token15 = "null";
			if (token15 == "null") {
				token15 = "isempty";
				token15 = "—";
			}
			System.out.println("token16=" + token15);
		}
		UEISD.compareViewCustomBenchmarkPercentageToken(token15);

		// style_selection
		label16 = (String) exlObj.getCellData(sheet, 19, cellnum - 1).toString();
		System.out.println(label16);
		SQLquery16 = (String) exlObj.getCellData(sheet, 19, cellnum);
		SQLquery16 = SQLquery16.replace("@data", "'" + searchToken + "'") + " limit 1";
		System.out.println(SQLquery16);
		rs16 = DBManager.executeSelectQuery(SQLquery16);
		while (rs16.next()) {
			token16 = rs16.getString(1);
			if (rs16.wasNull()) {
				token16 = "isempty";
				token16 = "—";
			}
			System.out.println("token17=" + token16);
		}
		if (token16 == "testnull") {
			token16 = "null";
			if (token16 == "null") {
				token16 = "isempty";
				token16 = "—";
			}
			System.out.println("token17=" + token16);
		}

		lp.verifyComparativeBenchmarkSelection(token16);
		UEISD.compareTokenCount();
		pmdb.DBConnectionClose();
	}

	@And("^User able to verify the PMP Style and Custom Options on Style View Details page in update style flow$")
	public void user_able_to_verify_the_pmp_style_and_custom_options_on_style_view_details_page() throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "TDR10_DataValidation";
		String SQLquery9, labelname = null;
		String label9;
		ResultSet rs9;

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;
		// style_name
		label9 = (String) exlObj.getCellData(sheet, 10, cellnum - 1).toString();
		System.out.println(label9);
		pmdb.DBConnectionStart();
		SQLquery9 = (String) exlObj.getCellData(sheet, 10, cellnum);
		SQLquery9 = SQLquery9.replace("@data", "'" + searchToken + "'") + " limit 1";
		System.out.println("SQLquery9=" + SQLquery9);
		rs9 = DBManager.executeSelectQuery(SQLquery9);
		while (rs9.next()) {
			token1 = rs9.getString(1);
			if (rs9.wasNull()) {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}

		lp.verifyComparativeBenchmarkSelection(token1);
	}

	@And("^User able to verify the PMP Style and Custom Options on Style Review page$")
	public void user_able_to_verify_the_pmp_style_and_custom_options_on_style_review_page() throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStyleUI.xlsx";
		String sheetName = "TDR10_DataValidation";
		String SQLquery11, labelname = null;
		String label11;
		ResultSet rs11;

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);
		int cellnum = 1;
		// style_name
		label11 = (String) exlObj.getCellData(sheet, 10, cellnum - 1).toString();
		System.out.println(label11);
		pmdb.DBConnectionStart();
		SQLquery11 = (String) exlObj.getCellData(sheet, 10, cellnum);
		SQLquery11 = SQLquery11.replace("@data", "'" + searchToken + "'") + " limit 1";
		System.out.println("SQLquery11= " + SQLquery11);
		rs11 = DBManager.executeSelectQuery(SQLquery11);
		while (rs11.next()) {
			token1 = rs11.getString(1);
			if (rs11.wasNull()) {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		if (token1 == "testnull") {
			token1 = "null";
			if (token1 == "null") {
				token1 = "isempty";
				token1 = "—";
			}
			System.out.println("token2=" + token1);
		}
		lp.verifyComparativeBenchmarkSelection2(token1);
	}

	@And("^User should be able to see that Save as Draft button should not be present and be hidden in any of the updation pages of style$")
	public void user_should_be_able_to_see_that_save_as_draft_button_should_not_be_present_and_be_hidden_in_any_of_the_updation_pages_of_style()
			throws Throwable {
		EISD.verifySaveDraftButtonIsHidden();
	}

	@And("^User selects Timeperiod for the Bundled node id$")
	public void user_selects_timeperiod_for_the_bundled_node_id() throws Throwable {
		UEISD.clickOnHistoricalTimeperiodForAssetClassification();
	}

	@Then("^Bundled node id % should always be greyed out and set to 100%$")
	public void bundled_node_id_should_always_be_greyed_out_and_set_to_100() throws Throwable {
		UEISD.verifyGreyedoutPercentageForBundledNodeId();
		UEISD.clickOnCurrentTimeperiodForAssetClassification();
		UEISD.verifyGreyedoutPercentageForBundledNodeId();
	}

	@And("^User clicks on delete button of currently added timeperiod under benchmarks$")
	public void user_clicks_on_delete_button_of_currently_added_timeperiod_under_benchmarks() throws Throwable {
		UEISD.clickOnCurrentTimeperiodBenchmarkDeleteIcon();
	}

	@Then("^User should be able to delete the added time periods$")
	public void user_should_be_able_to_delete_the_added_time_periods() throws Throwable {
		Reporter.addCompleteScreenCapture();
	}

	@And("^User cicks on edit button on one of the added timeperiod$")
	public void user_cicks_on_edit_button_on_one_of_the_timeperiod() throws Throwable {
		UEISD.clickOnCurrentTimeperiodBenchmarkEditIcon();
	}

	@Then("^User should see From Date and To Date in Add Time Period pop up window$")
	public void user_should_see_from_date_and_to_date_in_add_time_period_pop_up_window() throws Throwable {
		UEISD.verifyFromAndToDatetextintimeperiodpopupwindow();
	}

	@Then("^User should be able to see newly added historical timeperiod with Inception Date to Current Date Along with Edit button option for Node Ids under Asset Classification$")
	public void user_should_be_able_to_see_newly_added_historical_timeperiod_with_inception_date_to_current_date_along_with_edit_button_option_for_node_ids_under_asset_classification()
			throws Throwable {
		UEISD.verifyInceptionToCurrentDateoption();
		UEISD.verifyHistoricalNodeIdTimeperiodEditIcon();
	}

	@And("^also User should be able to see ADD NEW TIME PERIOD option along with \"([^\"]*)\" button for Node Ids under Asset Classification$")
	public void also_user_should_be_able_to_see_add_new_time_period_option_along_with_something_button_for_node_ids_under_asset_classification(
			String strArg1) throws Throwable {
		UEISD.verifyAddNewtimePeriodwithPlusButton();
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User should be able to edit the date feilds and apply it$")
	public void user_should_be_able_to_edit_the_date_feilds_and_apply_it() throws Throwable {
		UEISD.editAddedTimePeriodDateFields();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User selected date should be displayed on UI$")
	public void user_selected_date_should_be_displayed_on_ui() throws Throwable {
		UEISD.clickOnNextButton3();
		SRP.verifyreviewheaderinCreateStyleReviewPage();
		SRP.verifyreviewpagedetailsinCreateStyleReviewPage();
		Reporter.addCompleteScreenCapture();
	}

	@When("^User Updates and deletes previously added timeperiods and its constituents on benchmark page in update flow$")
	public void user_updates_and_deletes_previously_added_timeperiods_and_its_constituents_on_benchmark_page_in_update_flow()
			throws Throwable {
		UEISD.clickOnCurrentTimeperiodBenchmarkEditIcon();
		UEISD.editAddedTimePeriodDateFields();
		Reporter.addCompleteScreenCapture();
		UEISD.clickOnCurrentTimeperiodBenchmarkDeleteIcon();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User should verify investmentstyle name and benchmarks getting displayed on style view page$")
	public void user_should_verify_investmentstyle_name_and_benchmarks_getting_displayed_on_style_view_page()
			throws Throwable {
		UEISD.verifyStyleNameAndBenchmarkdetails();
	}

	@And("^User should see same timeperiods and benchmarks which are added or persisted or deleted under PMP style page must be present on present PMP strategy linked with same Style$")
	public void user_should_see_same_timeperiods_and_benchmarks_which_are_added_or_persisted_or_deleted_under_pmp_style_page_must_be_present_on_present_pmp_strategy_linked_with_same_style()
			throws Throwable {
		UEISD.verifyPMPStrategyStyleNameAndBenchmarkdetails();
	}

	@And("^User cicks on Add New TimePeriod option under Asset Classification in update flow$")
	public void user_cicks_on_add_new_timeperiod_option_under_asset_classification_in_update_flow() throws Throwable {
		UEISD.clickAddNewtimePeriodwithPlusButton();
	}

	@Then("^User should be provided with a Date picker to select a date accordingly$")
	public void user_should_be_provided_with_a_date_picker_to_select_a_date_accordingly() throws Throwable {
		UEISD.provideDatePickertoSelectDate();
	}

	@Then("^User should be provided with a Date picker to select a date accordingly to update NodeId timeperiods under Asset Classification in update flow$")
	public void user_should_be_provided_with_a_date_picker_to_select_a_date_accordingly_to_update_nodeid_timeperiods_under_asset_classification_in_update_flow()
			throws Throwable {
		UEISD.clickOnCurrentTimeperiodNodeIDEditIcon();
		UEISD.provideDatePickertoSelectDate2();
	}

	@And("^User should be able to add new time period after for Node Ids under Asset Classification in update flow$")
	public void user_should_be_able_to_add_new_time_period_after_for_node_ids_under_asset_classification_in_update_flow()
			throws Throwable {
		UEISD.addNodeIDTimePeriodBenchmarks();
		UEISD.addCapnGoComparativeBenchmarks();
	}

	@And("^User should be able to see the newly added timeperiod under Timeperiod column of Node Ids under Review Page in update flow$")
	public void user_should_be_able_to_see_the_newly_added_timeperiod_under_timeperiod_column_of_node_ids_under_review_page_in_update_flow()
			throws Throwable {
		UEISD.verifyReviewPageNodeIDTimeperiodBenchmarks();
	}

	@And("^User should be able to see the newly added timeperiod under Timeperiod column of Node Ids under View Page in update flow$")
	public void user_should_be_able_to_see_the_newly_added_timeperiod_under_timeperiod_column_of_node_ids_under_view_page_in_update_flow()
			throws Throwable {
		UEISD.verifyViewPageNodeIDTimeperiodBenchmarks();
	}

	@Then("^User should be able to see Edit and Delete options should be available on all the newly added time periods$")
	public void user_should_be_able_to_see_edit_and_delete_options_should_be_available_on_all_the_newly_added_time_periods()
			throws Throwable {
		UEISD.verifyCurrentTimePeriodEditandDeleteIcons();
	}

	@Then("^User should get correct date picker with existing date selected and when user changes date value should persist$")
	public void user_should_get_correct_date_picker_with_existing_date_selected_and_when_user_changes_date_value_should_persist()
			throws Throwable {
		UEISD.verifyFromAndToDatetextintimeperiodpopupwindow();
		UEISD.editAddedTimePeriodDateFields();
		UEISD.verifyPreviousModifiedBenchmarkTimeperiods();
		Reporter.addCompleteScreenCapture();
	}

	@And("^When user modifies date the previous timeperiods having this date should also get modified$")
	public void when_user_modifies_date_the_previous_timeperiods_having_this_date_should_also_get_modified()
			throws Throwable {
		UEISD.clickOnNextButton3();
		SRP.verifyreviewheaderinCreateStyleReviewPage();
		SRP.verifyreviewpagedetailsinCreateStyleReviewPage();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User changes the Bundled Node Id and Unbundled Node Id under the desired time period$")
	public void user_changes_the_bundled_node_id_and_unbundled_node_id_under_the_desired_time_period()
			throws Throwable {
		// UEISD.clickOnHistoricalTimeperiodForAssetClassification();
		UEISD.clickOnCurrentTimeperiodForAssetClassification();
		UEISD.updateNodeIDTimePeriodBenchmarks();
		Reporter.addCompleteScreenCapture();
	}

	@And("^User should be able to see \"([^\"]*)\" header displayed in the Update Style UI$")
	public void user_should_be_able_to_see_something_header_displayed_in_the_update_style_ui(String strArg1)
			throws Throwable {
		UEISD.verifyStyleformatheader();
	}

	@And("^User should be able to observe that the \"([^\"]*)\" status field will be in disabled state$")
	public void user_should_be_able_to_observe_that_the_something_status_field_will_be_in_disabled_state(String strArg1)
			throws Throwable {
		UEISD.verifyDisabledStyleStatusField();
	}

	@And("^User updates all the (.+) with Multiple UnBundled Asset Classification data with random percentages and Style based benchmarks on Benchmark and Asset Classification page in update flow$")
	public void user_updates_all_the_with_multiple_unbundled_asset_classification_data_with_random_percentages_and_style_based_benchmarks_on_benchmark_and_asset_classification_page_in_update_flow(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 7);
		exlObj.closeWorkBook();
		UEISD.enterBundledAssetClassification();
		UEISD.enterMultipleUnbundledAssetClassificationWithRandomPercentages();
		if (sb_1 != cb_2) {
			UEISD.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@Then("^User should be able to see Unbundled Node Ids added are retained based on percentage allocation in descending order on Review page in Update Style Flow$")
	public void user_should_be_able_to_see_unbundled_node_ids_added_are_retained_based_on_percentage_allocation_in_descending_order_on_review_page_in_update_style_flow()
			throws Throwable {
		SRP.verifyUnbundledNodeIdDisplayedInDescOrder();
	}

	@Then("^User should be able to see Unbundled Node Ids added are retained based on percentage allocation in descending order on Benchmark page in Update Style Flow$")
	public void user_should_be_able_to_see_unbundled_node_ids_added_are_retained_based_on_percentage_allocation_in_descending_order_on_benchmark_page_in_update_style_flow()
			throws Throwable {
		UEISD.verifyUnbundledNodeIdDisplayedInDescOrder();
	}

	@Then("^User should be able to see Unbundled Node Ids added are retained based on percentage allocation in descending order on View page in Update Style Flow$")
	public void user_should_be_able_to_see_unbundled_node_ids_added_are_retained_based_on_percentage_allocation_in_descending_order_on_view_page_in_update_style_flow()
			throws Throwable {
		lp.verifyUnbundledNodeIdDisplayedInDescOrder();
	}

	@And("^User updates all the (.+) with Single UnBundled Asset Classification and Custom based benchmarks data with random percentages on Benchmark and Asset Classification page in update flow$")
	public void user_updates_all_the_with_single_unbundled_asset_classification_and_custom_based_benchmarks_data_with_random_percentages_on_benchmark_and_asset_classification_page_in_update_flow(
			String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		System.out.println("Mandatory Details : " + mandatorydetails);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 7);
		exlObj.closeWorkBook();
		UEISD.enterBundledAssetClassification();
		UEISD.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			UEISD.enterMultipleComparativeBenchmarkWithRandomPercentages(sb_1, cb_2);
		}
		Reporter.addCompleteScreenCapture();
	}

	@Then("^User should be able to see Custom Benchmarks added are retained based on percentage allocation in descending order on Review page in Update Style Flow$")
	public void user_should_be_able_to_see_custom_benchmarks_added_are_retained_based_on_percentage_allocation_in_descending_order_on_review_page_in_update_style_flow()
			throws Throwable {
		SRP.verifyCustomBenchmarksDisplayedInDescOrder();
	}

	@Then("^User should be able to see Custom Benchmarks added are retained based on percentage allocation in descending order on Benchmark page in Update Style Flow$")
	public void user_should_be_able_to_see_custom_benchmarks_added_are_retained_based_on_percentage_allocation_in_descending_order_on_benchmark_page_in_update_style_flow()
			throws Throwable {
		UEISD.verifyCustomBenchmarksDisplayedInDescOrder();
	}

	@Then("^User should be able to see Custom Benchmarks added are retained based on percentage allocation in descending order on View page in Update Style Flow$")
	public void user_should_be_able_to_see_custom_benchmarks_added_are_retained_based_on_percentage_allocation_in_descending_order_on_view_page_in_update_style_flow()
			throws Throwable {
		lp.verifyCustomBenchmarksDisplayedInDescOrder();
	}
	@And("^Notification Hub Process is started for update Style with (.+)$")
    public void notification_hub_process_is_started_for_update_style_with(String mandatorydetails) throws Throwable {
		String filename = mandatorydetails.split("_")[1];
		testmucNHLogFilePath = System.getProperty("user.dir") + "/temp/topic-NotiHub" + filename + ".log";
		System.out.println(testmucNHLogFilePath);
		FileManager.getFileManagerObj().deleteFile(testmucNHLogFilePath);
		String command = "";
		// String environment =
		// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.QA.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.UAT.OUT.WMAP.TOPIC";
		}
		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier = "ProductMaster";
		command = command + " | find /i \"" + identifier + "\" >>" + testmucNHLogFilePath;
		Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		// Thread.sleep(10000);
    }

    @And("^Data Hub Process is started for update Style with (.+)$")
    public void data_hub_process_is_started_for_update_style_with(String mandatorydetails) throws Throwable {
    	String filename = mandatorydetails.split("_")[1];
	    testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-DataHub" + filename + ".log";
		//String testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-testmucDataHub.log";
		FileManager.getFileManagerObj().deleteFile(testmucDHLogFilePath);
		String command = "";
		// String environment =
		// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment;
		if(environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.QA.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.UAT.OUT.WMAP.TOPIC";
		}
		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier = "Style";
		command = command + " | find /i \"" + identifier + "\" >>" + testmucDHLogFilePath;
		Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();
    }

    @And("^a notification is sent to Notification Hub after Update Style flow on UI$")
    public void a_notification_is_sent_to_notification_hub_after_update_style_flow_on_ui() throws Throwable {
    	Thread.sleep(10000);
	    styleId = UCP.getStyleId();
	    styleName = UCP.getStyleName();
		FileReader fr = new FileReader(testmucNHLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		String line;
		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;
		while((line = br.readLine()) != null) {
			if(line.contains(styleId)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucNHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Style Name: </b>" + styleName);
		Reporter.addStepLog("<b>Style Id: </b>" + styleId);
		if(line.contains(styleName)) {
			Reporter.addStepLog("<p style = 'color:green'>Style Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(styleName));
		}
		else if(line.contains(styleId)) {
			Reporter.addStepLog("<p style = 'color:green'>Style Id is Matched in Notification</p>");
			Assert.assertTrue(line.contains(styleId));
		}
		else {
			Assert.fail("No Response from Notification Hub");
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
    }

    @And("^a Payload is sent to Data Hub after Update Style flow on UI$")
    public void a_payload_is_sent_to_data_hub_after_update_style_flow_on_ui() throws Throwable {
    	Thread.sleep(10000);
		styleId = UCP.getStyleId();
		styleName = UCP.getStyleName();
		FileReader fr = new FileReader(testmucDHLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		String line;
		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;
		while((line = br.readLine()) != null) {
			if(line.contains(styleId)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
		Reporter.addStepLog("<b>Notification from DH: </b>" + line);
		Reporter.addStepLog("<b>Style Name: </b>" + styleName);
		Reporter.addStepLog("<b>Style Id: </b>" + styleId);
		if(line.contains(styleName)) {
			Reporter.addStepLog("<p style = 'color:green'>Style Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(styleName));
		}
		else if(line.contains(styleId)) {
			Reporter.addStepLog("<p style = 'color:green'>Style Id is Matched in Notification</p>");
			Assert.assertTrue(line.contains(styleId));
		}
		else {
			Assert.fail("No Payload is recieved from Data Hub");
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
    }

}
