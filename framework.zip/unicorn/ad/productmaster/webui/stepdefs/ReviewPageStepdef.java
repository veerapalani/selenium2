package qa.unicorn.ad.productmaster.webui.stepdefs;

import cucumber.api.java.en.Then;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.ReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.ReviewStrategyPage;
import qa.framework.utils.Action;

public class ReviewPageStepdef {
	PMPageGeneric createdoclink = new PMPageGeneric("AD_PM_CreateDocumentLinkPage");
	PMPageGeneric viewdoclink = new PMPageGeneric("AD_PM_ViewDocumentLinkPage");
	PMPageGeneric viewcomment = new PMPageGeneric("AD_PM_ViewCommentPage");
	PMPageGeneric createcomment = new PMPageGeneric("AD_PM_CreateCommentsPage");
	PMPageGeneric review = new PMPageGeneric("AD_PM_ReviewPage");
	PMPageGeneric confirmation = new PMPageGeneric("AD_PM_ConfirmationPage");
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ReviewPage"));;
	WebElement a1;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	ReviewStrategyPage reviewStrategyPage = new ReviewStrategyPage();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	int rowIndex,cellIndex;
	WebElement myElement;

	@Then("^User should be able to see the \"([^\"]*)\" on Review page$")
    public void user_should_be_able_to_see_the_something_on_review_page(String Key) throws Throwable {
    	review.verifyElement(Key);
    	Thread.sleep(2000);
    }
	@And("^User clicks on the \"([^\"]*)\" on Review Page$")
    public void user_clicks_on_the_something_on_review_page(String key) throws Throwable {
    	Thread.sleep(1000);
		review.clickOnLink(key);
    }
	 @And("^User clicks on the Submit Button on Review Page$")
	    public void user_clicks_on_the_submit_button_on_review_page() throws Throwable {
	        action.click(action.getElement("Submit Button"));
	    }
	@Then("^user should be able to see the following attributes on Review page$")
    public void user_should_be_able_to_see_the_following_attributes_on_review_page(List<String> attributes) throws Throwable {
		listOfElements = review.getElements("Attributes_ReviewPage");
	       for(int i=0;i<attributes.size();i++)
	    	   {
	    	   review.verifyTextInListOfElements(attributes.get(i), listOfElements);
	    	   Reporter.addStepLog("verified for "+attributes.get(i)+" attribute");
	    	   }
    }
	@Then("^the attributes on Review Page should contain one of the below following values$")
    public void the_attributes_on_review_page_should_contain_one_of_the_below_following_values(List<List<String>> attributeValuePair) throws Throwable {
		String myValue=null;
    	
    	for(int i=0;i<attributeValuePair.size();i++) {
    	String xpath="//label[contains(text(),'"+attributeValuePair.get(i).get(0)+"')]/ancestor::div/following-sibling::div";
    	myValue=review.findElementByDynamicXpath(xpath).getText();
    	Reporter.addStepLog("The value for "+attributeValuePair.get(i).get(0)+" is "+myValue);
    	String listOfValues[] = attributeValuePair.get(i).get(1).split(",");
    	for(int j=0;j<listOfValues.length;j++) {
    	if(myValue.equals(listOfValues[j]))
    		{Assert.assertTrue(true);
    		break;}
    	
    	else 
    		Assert.assertFalse(false);
    	
    	}
        }
    }

	@And("^user should be able to see the following attributes below \"([^\"]*)\" header on Review page$")
    public void user_should_be_able_to_see_the_following_attributes_below_something_header_on_review_page(String key,List<String> attributes) throws Throwable {
		listOfElements = review.getElements(key);
        for(int i=0;i<attributes.size();i++)
 	   {
        	review.verifyTextInListOfElements(attributes.get(i), listOfElements);
 	   }
        
    }
	@And("^The text written in \"([^\"]*)\" should match with the value of \"([^\"]*)\" attribute on Review page$")
    public void the_text_written_in_something_should_match_with_the_value_of_something_attribute_on_review_page(String actualkey, String expectedkey) throws Throwable {
		Assert.assertEquals(review.getText(actualkey), review.getText(expectedkey));
    }
	@Then("^the attributes on Review page should contain either true or false or blank value$")
    public void the_attributes_on_review_page_should_contain_either_true_or_false_or_blank_value(List<String> attributes) throws Throwable {
		String myValue=null;
    	for(int i=0;i<attributes.size();i++) {
    	String xpath="//div[@class='col-xs-6']/div/label";
    	//a1=review.findElementByDynamicXpath(xpath);
    	myValue=review.findElementByDynamicXpath(xpath).getText();
    	Reporter.addStepLog("The value for "+attributes.get(i)+" is "+myValue);
    	if(myValue.equals("true")||myValue.equals("false")||myValue.equals("")) {
    		Assert.assertTrue(true);
    		
    	}
    	else {
    		Assert.assertFalse(false);
    	}
        }
    }
	
	
	ReviewPage rp = new ReviewPage(); 
	@Then("^User is able to see (.+) Review Page$")
	    public void user_is_able_to_see_benchmark_review_page(String entity) throws Throwable {
	        assertTrue(rp.isUserOnReviewPage(entity));
	        Reporter.addScreenCapture();
	    }
	@Then("^User should be able to see the updates in the review page for following attributes$")
	public void user_should_be_able_to_see_the_updates_in_the_review_page_for_following_attributes(List<String> attribute) throws Throwable {
		sheet = exlObj.getSheet("Valid");
		
		for (int i=0;i<attribute.size();i++) {

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_Mandatory");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
		myElement = reviewStrategyPage.findElementByDynamicXpath("//label[text()='"+attribute.get(i)+"']/parent::div/following-sibling::div");
		Assert.assertTrue(myElement.getText().contains((String)exlObj.getCellData(sheet, rowIndex, cellIndex)));
		Reporter.addStepLog("verified the value for "+attribute.get(i));
	
				
		}
		Reporter.addScreenCapture();
   

}
	
}
