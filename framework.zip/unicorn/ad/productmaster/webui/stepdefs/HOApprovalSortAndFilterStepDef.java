package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.HOApprovalSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPSortAndFilterPage;

public class HOApprovalSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	PMPSortAndFilterPage pmpSortAndFilterPage = new PMPSortAndFilterPage("AD_PM_PMPSortAndFilterPage");
	HOApprovalSortAndFilterPage hoApprovalSortAndFilterPage = new HOApprovalSortAndFilterPage(
			"AD_PM_HOApprovalSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/PMPSortAndFilter.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	WebElement myElement;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_HOApprovalSortAndFilterPage"));

	@When("^user click on \"([^\"]*)\" tab on landing page for HO Approval$")
	public void user_click_on_something_tab_on_landing_page_for_ho_approval(String strArg1) throws Throwable {
		//hoApprovalSortAndFilterPage.verifyAndClickHOApprovalTab();
		landingPage.clickOnTab("HOApproval", "HO");
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design for HO Approval$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design_for_ho_approval(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.mouseHoverOnGridViewLabels(
					pmpSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			pmpSortAndFilterPage.verifyGridViewLabelsWithSortIcons(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for HO Approval$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_ho_approval(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for HO Approval$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_ho_approval(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			pmpSortAndFilterPage.mouseHoverOnGridViewLabels(
					pmpSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			pmpSortAndFilterPage.clickOnSortIcon(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for HO Approval$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_ho_approval() throws Throwable {
		String value = pmpSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = PMPSortAndFilterPage.ascSortValue;
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for HO Approval$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_ho_approval(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			pmpSortAndFilterPage.mouseHoverOnGridViewLabels(
					pmpSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			pmpSortAndFilterPage.clickOnSortIcon(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for HO Approval$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_ho_approval() throws Throwable {
		String value = pmpSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = PMPSortAndFilterPage.descSortValue;
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for HO Approval$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_ho_approval(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			pmpSortAndFilterPage.mouseHoverOnGridViewLabels(
					pmpSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]");
			pmpSortAndFilterPage.clickOnSortIcon(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for HO Approval$")
	public void user_should_able_to_sort_the_records_with_default_order_for_ho_approval() throws Throwable {
		String value = pmpSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = PMPSortAndFilterPage.defaultSortValue;
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to click on the filter icon for below column for HO Approval$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_ho_approval(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			hoApprovalSortAndFilterPage.clickOnFilterIconForGridView(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to validate the filter condition all options for HO Approval$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_ho_approval(List<String> entity)
			throws Throwable {
		pmpSortAndFilterPage.clickOnFilterCondition();
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage
					.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']");
			pmpSortAndFilterPage.verifyValueOfFilterCondition(pmpSortAndFilterPage.findElementByDynamicXpath(
					"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to see grid view data for HO Approval$")
	public void user_able_to_see_grid_view_data_for_ho_approval() throws Throwable {
		String gridCountBeforeCondition = hoApprovalSortAndFilterPage
				.verifyTheGridCountBeforeApplyFilterAndSortCondition();
		// String gridCountBeforeCondition =
		// HOApprovalSortAndFilterPage.gridCountAfterGlobalSearch;
		int beforeApplyCondition = Integer.parseInt(gridCountBeforeCondition);
		Reporter.addScreenCapture();
		if (beforeApplyCondition == 1)
			hoApprovalSortAndFilterPage.verifyTheNoResultsOnGridView();
	}

	@And("^User able to see tab count before any condition for HO Approval$")
	public void user_able_to_see_tab_count_before_any_condition_for_ho_approval() throws Throwable {
		String beforeApplyFilterValue = hoApprovalSortAndFilterPage
				.verifyTheHOApprovalGridCountAfterApplyFilterConditionOnTab();
		// String beforeApplyFilterValue =
		// HOApprovalSortAndFilterPage.tabCountAfterCondition;
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);
	}

	@And("^User able to select the (.+) from filter condition for HO Approval$")
	public void user_able_to_select_the_from_filter_condition_for_ho_approval(String filtercondition) throws Throwable {
		hoApprovalSortAndFilterPage.clickOnFilterCondition();
		hoApprovalSortAndFilterPage
				.clickOnFilterConditionForHOApprovalGridView(pmpSortAndFilterPage.findElementByDynamicXpath(
						"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for HO Approval$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_ho_approval(String filterconditionvalue)
			throws Throwable {
		hoApprovalSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button on HO Approval grid view$")
	public void user_able_to_click_on_the_apply_button_on_ho_approval_grid_view() throws Throwable {
		hoApprovalSortAndFilterPage.clickOnApplyFilterIconForHOApprovalGridView();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on HO Approval grid view$")
	public void user_should_able_to_verify_the_grid_count_on_ho_approval_grid_view() throws Throwable {
		//action.pause(5000);
		//System.out.println("In grid");
		String countTabAfterFilter = hoApprovalSortAndFilterPage
				.verifyTheHOApprovalGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// HOApprovalSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);
		//System.out.println(tabCountAfterFilterCondition);
		String presentGridData = hoApprovalSortAndFilterPage.verifyTheHOApprovalGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		 action.scrollToUp();
		 Reporter.addScreenCapture();
		//System.out.println("parseValueOfGridCountAfterFilterCondition-" + parseValueOfGridCountAfterFilterCondition);
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition / 10; i++) {
				action.waitForDomToComplete(WebDriverManager.getDriver());

				/*
				 * System.out.println(
				 * "//div[@class='ag-center-cols-container']/div[@role='row'][" +
				 * String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				 * hoApprovalSortAndFilterPage .waitForWebElement(
				 * "//div[@class='ag-center-cols-container']/div[@role='row'][" +
				 * String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				 */
				myElement = hoApprovalSortAndFilterPage
						.findElementByDynamicXpath("//div[@class='ag-center-cols-container']/div[@role='row']["
								+ String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				action.moveToElement(myElement);

				// action.scrollToElement(myElement);
				action.scrollToBottom();
				action.pause(2000);
				String presentGridAllData = hoApprovalSortAndFilterPage.verifyTheHOApprovalGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
				System.out.println("Inside grid parseValueOfGridCountAfterFilterCondition-"
						+ parseValueOfGridCountAfterFilterCondition);
				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			pmpSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The grid view and tab count mismatch");}
	}

	@And("^User should able to verify the Tab count on HO Approval grid view$")
	public void user_should_able_to_verify_the_tab_count_on_ho_approval_grid_view() throws Throwable {
		System.out.println("In tab");
		String countTabAfterFilter = hoApprovalSortAndFilterPage
				.verifyTheHOApprovalGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// HOApprovalSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);
		System.out.println("tab tabCountAfterFilterCondition-" + tabCountAfterFilterCondition);
		String presentGridData = hoApprovalSortAndFilterPage.verifyTheHOApprovalGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		System.out
				.println("tab parseValueOfGridCountAfterFilterCondition-" + parseValueOfGridCountAfterFilterCondition);
		// action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition / 10; i++) {
				action.waitForDomToComplete(WebDriverManager.getDriver());
				hoApprovalSortAndFilterPage
						.waitForWebElement("//div[@class='ag-center-cols-container']/div[@role='row']["
								+ String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				myElement = hoApprovalSortAndFilterPage
						.findElementByDynamicXpath("//div[@class='ag-center-cols-container']/div[@role='row']["
								+ String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				action.moveToElement(myElement);
				action.pause(2000);
				String presentGridAllData = hoApprovalSortAndFilterPage.verifyTheHOApprovalGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
				System.out.println("Inside tab parseValueOfGridCountAfterFilterCondition-"
						+ parseValueOfGridCountAfterFilterCondition);
				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			pmpSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Assert.assertEquals(tabCountAfterFilterCondition, parseValueOfGridCountAfterFilterCondition,
				"The tab count and grid view count mismatch");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Reset Button on HO Approval grid view$")
	public void user_able_to_click_on_the_reset_button_on_ho_approval_grid_view() throws Throwable {
		hoApprovalSortAndFilterPage.clickOnApplyFilterIconForHOApprovalGridViewForReset();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button on HO Approval grid view$")
	public void user_able_to_click_on_the_cancel_button_on_ho_approval_grid_view() throws Throwable {
		hoApprovalSortAndFilterPage.clickOnApplyFilterIconForHOApprovalGridViewForCancel();
		Reporter.addScreenCapture();
	}

}
