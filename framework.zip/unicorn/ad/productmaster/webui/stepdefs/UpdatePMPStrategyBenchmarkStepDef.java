package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.UpdatePMPStrategyBenchmarkPage;

public class UpdatePMPStrategyBenchmarkStepDef {

	UpdatePMPStrategyBenchmarkPage benchmarkPage = new UpdatePMPStrategyBenchmarkPage("AD_PM_UpdatePMPStrategyBenchmarkPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
	
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName;
	String label, attributeValue, uiValue,dbValue = null;
	
	public static int count;
	
	@Then("^Values for Attributes in Benchmark Page of Update PMP Strategy Flow should match the values for attributes stored in DB$")
    public void values_for_attributes_in_benchmark_page_of_update_pmp_strategy_flow_should_match_the_values_for_attributes_stored_in_db() {
		sheetName = "Conversion_Validation";
		   sheet = exlObj.getSheet(sheetName);
		   int rownum = 18;
		   count = 0;
		   label = (String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if((label == "") ||(label.contains("Proxy Manager")) )
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")) {
							rownum++;
			    			label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if((label == "") ||(label.contains("Proxy Manager")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromBenchmarkAndAssetClassificationPage(label);
						dbValue =(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							exlObj.setCellData(sheet, rownum, 5, attributeValue);
						}else {
							exlObj.setCellData(sheet, rownum, 5, attributeValue+"-UI Value is not same as Stored Value in DB");
							
							Reporter.addCompleteScreenCapture();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							count++;
							
						}
						
							rownum++;
							label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("Proxy Manager")))
								label = "isEmpty";
					
					}
			}
			
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addEntireScreenCaptured();
			Reporter.addStepLog("In Benchmark And Asset Classification Page Values Stored in DB are Populated in UI");
			exlObj.closeWorkBook();
    }

    private String getDataFromBenchmarkAndAssetClassificationPage(String data) {
		switch (data) {
		case "Primary Benchmark":
			
			uiValue = benchmarkPage.getPrimaryBenchmarkValue();

			break;

		default:
			break;
		}
		if((uiValue == null) || (uiValue.isEmpty()))
			uiValue = "isEmpty";
		
		return uiValue;
	}

    @And("^User is in Benchmark Page of Update PMP Strategy Flow$")
    public void user_is_in_benchmark_page_of_update_pmp_strategy_flow() {
        Assert.assertTrue(benchmarkPage.isUserOnBenchmarkPage());
    }
	
    @And("^User clicks on Next in Benchmark Page in Update PMP Strategy Flow$")
    public void user_clicks_on_next_in_benchmark_page_in_update_pmp_strategy_flow() {
        benchmarkPage.clickOnNext();
    }
}
