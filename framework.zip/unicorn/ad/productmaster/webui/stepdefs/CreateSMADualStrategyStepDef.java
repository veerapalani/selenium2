package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkReviewFlyoutPage;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyEnterStrategyDetailsPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMADualBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMADualCommentsPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMADualProxyPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMADualStrategyPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyReviewPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStrategyPage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;

public class CreateSMADualStrategyStepDef {
	WebElement myElement, myElement2;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateSMADualStrategyPage"));
	Alert alert;
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMADualStrategy.xlsx";
	String option, sheetName = "";
	int rowIndex, cellIndex;
	String xpath, myValue;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	Process p = null;
	String kafkaPath = "D://kafka_2.13-2.4.0//bin//windows";
	String testmucNHLogFilePath, testmucDHLogFilePath = "";
	String strategyCode, benchmarkType, benchmarkTypeCode = null;
	String strategyName = "";
	String userinfo = null;
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	CreateSMADualStrategyPage createsmadualstrategypageobj = new CreateSMADualStrategyPage(
			"AD_PM_CreateSMADualStrategyPage");
	CreateSMADualCommentsPage createsmadualstrategycommentspageobj = new CreateSMADualCommentsPage(
			"AD_PM_CreateSMADualCommentsPage");
	CreateStrategyPage createstrategypageobj = new CreateStrategyPage("AD_PM_CreateStrategyPage");
	CreateSMADualBenchmarkPage createsmadualstrategybecnhamrkpageobj = new CreateSMADualBenchmarkPage(
			"AD_PM_CreateSMADualBenchmarkpage");
	CreateSMADualProxyPage createsmadualstrategyproxypageobj = new CreateSMADualProxyPage(
			"AD_PM_CreateSMADualproxypage");
	CreateSMASingleAccessStrategyReviewPage reviewpage = new CreateSMASingleAccessStrategyReviewPage(
			"AD_PM_CreateSMASingleAccessStrategyReviewPage");
	CreateSMASingleAccessStrategyConfirmationPage con = new CreateSMASingleAccessStrategyConfirmationPage(
			"AD_PM_CreateSMASingleAccessStrategyConfirmationPage");
	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	CreatePMPStrategyEnterStrategyDetailsPage strategyDetailsPage = new CreatePMPStrategyEnterStrategyDetailsPage(
			"AD_PM_CreatePMPStrategyEnterStrategyDetailsPage");

	@And("^User clicks on Next Button on the Create SMA Dual Benchmark Page$")
	public void user_clicks_on_next_button_on_the_create_sma_dual_benchmark_page() throws Throwable {
		createsmadualstrategybecnhamrkpageobj.clickOnNextButtononBenchmarkPage();
		Thread.sleep(300);
	}

	@And("^User enters the details required on the Comments Page$")
	public void user_enters_the_details_required_on_the_comments_page() throws Throwable {
		createsmadualstrategycommentspageobj.selectCommentType();
		createsmadualstrategycommentspageobj.enterComment();
	}

	@And("^a Payload is sent to Data Hub after Creation of SMA Dual Strategy$")
	public void a_payload_is_sent_to_data_hub_after_creation_of_sma_dual_strategy() throws Throwable {
		Thread.sleep(10000);
		FileReader fr = new FileReader(testmucDHLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		String line;
		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;
		while ((line = br.readLine()) != null) {
			if (line.contains(strategyCode)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Strategy Name: </b>" + strategyName);
		Reporter.addStepLog("<b>Strategy Code: </b>" + strategyCode);
		if (line.contains(strategyName)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyName));
		}
		if (line.contains(strategyCode)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyCode));
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
	}

	@And("^a notification is sent to Notification Hub after Creation of SMA Dual Strategy$")
	public void a_notification_is_sent_to_notification_hub_after_creation_of_sma_dual_strategy() throws Throwable {
		Thread.sleep(10000);
		FileReader fr = new FileReader(testmucNHLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		String line;
		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;
		while ((line = br.readLine()) != null) {
			if (line.contains(strategyCode)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucNHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Strategy Name: </b>" + strategyName);
		Reporter.addStepLog("<b>Strategy Code: </b>" + strategyCode);
		if (line.contains(strategyName)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyName));
		}
		if (line.contains(strategyCode)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyCode));
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
	}

	@And("^User inputs all the (.+) for style based benchmark on the Benchmark and Asset Classification page of SMA Dual Strategy$")
	public void user_inputs_all_the_for_style_based_benchmark_on_the_benchmark_and_asset_classification_page_of_sma_dual_strategy(
			String valid_data) throws Throwable {
		if (valid_data.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("valid_data here : " + valid_data);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, valid_data);
		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 24);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 25);
		exlObj.closeWorkBook();
		createsmadualstrategybecnhamrkpageobj.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			createsmadualstrategybecnhamrkpageobj.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@Then("^User should be able to go to Create SMA Dual Strategy page$")
	public void user_should_be_able_to_go_to_create_sma_dual_strategy_page() throws Throwable {
		createsmadualstrategypageobj.smadualcreatepageURL();
	}

	@And("^User enters the mandatory details in Strategy Wizard for SMA Dual$")
	public void user_enters_the_mandatory_details_in_strategy_wizard_for_sma_dual_and_clicks_create_strategy_button()
			throws Throwable {
		Thread.sleep(2000);
		String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		Reporter.addStepLog("the window handle is" + winHandleBefore);
		createstrategypageobj.enterstrategynameinstrategywizard();
		createsmadualstrategypageobj.clickOnproginstrategywizard();
		// createstrategypageobj.selectsprogvalueinstrategywizard();
		Thread.sleep(1000);
		createstrategypageobj.clickOnstrategybutton();
		Thread.sleep(1000);
	}

	@When("^User enters (.+) in all the fields for SMA Dual$")
	public void user_enters_in_all_the_fields_for_sma_dual(String option) throws Throwable {
		if (option.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);
		String ManagerName = (String) exlObj.getCellData(sheet, rowIndex, 1);
		String StyleName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		String FOAGrpCode = (String) exlObj.getCellData(sheet, rowIndex, 3);
		String LargeTraderId = (String) exlObj.getCellData(sheet, rowIndex, 4);
		String ShortDuration = (String) exlObj.getCellData(sheet, rowIndex, 5);
		String ConcentratedStrategy = (String) exlObj.getCellData(sheet, rowIndex, 6);
		String MarginEligible = (String) exlObj.getCellData(sheet, rowIndex, 7);
		String OptionsEligible = (String) exlObj.getCellData(sheet, rowIndex, 8);
		String ColateralEligible = (String) exlObj.getCellData(sheet, rowIndex, 9);
		String SustainableInvesting = (String) exlObj.getCellData(sheet, rowIndex, 10);
		String MacEligibility = (String) exlObj.getCellData(sheet, rowIndex, 11);
		String ICEligibility = (String) exlObj.getCellData(sheet, rowIndex, 12);
		String ResearchRating = (String) exlObj.getCellData(sheet, rowIndex, 13);
		String MaxMACFee = (String) exlObj.getCellData(sheet, rowIndex, 14).toString();
		String RiskCategory = (String) exlObj.getCellData(sheet, rowIndex, 15);
		String Approvaldate = (String) exlObj.getCellData(sheet, rowIndex, 16).toString();
		String StrategyMin = (String) exlObj.getCellData(sheet, rowIndex, 17).toString();
		String FeeScheduleType = (String) exlObj.getCellData(sheet, rowIndex, 18);
		String SplInstructionschkbox = (String) exlObj.getCellData(sheet, rowIndex, 19);
		String SplInstructions = (String) exlObj.getCellData(sheet, rowIndex, 20);
		String HideStrategychkbox = (String) exlObj.getCellData(sheet, rowIndex, 21);
		String AARBaseTemplate = (String) exlObj.getCellData(sheet, rowIndex, 22);
		String CompUniverse = (String) exlObj.getCellData(sheet, rowIndex, 23);
		exlObj.closeWorkBook();
		if (ManagerName != "") {
			createsmadualstrategypageobj.selectManagername(ManagerName);
		}
		if (StyleName != "") {
			createsmadualstrategypageobj.selectStylename(StyleName);
		}
		if (FOAGrpCode != "") {
			createsmadualstrategypageobj.selectFOAGrpCode(FOAGrpCode);
		}
		if (LargeTraderId != "") {
			createsmadualstrategypageobj.enterLargeTraderId(LargeTraderId);
		}
		if (ShortDuration != "") {
			createsmadualstrategypageobj.selectShortDuration(ShortDuration);
		}
		if (ConcentratedStrategy != "") {
			createsmadualstrategypageobj.ConcentratedStrategy(ConcentratedStrategy);
		}
		if (MarginEligible != "") {
			createsmadualstrategypageobj.MarginEligible(MarginEligible);
		}
		if (OptionsEligible != "") {
			createsmadualstrategypageobj.OptionsEligible(OptionsEligible);
		}
		if (ColateralEligible != "") {
			createsmadualstrategypageobj.ColateralEligible(ColateralEligible);
		}
		if (SustainableInvesting != "") {
			createsmadualstrategypageobj.SustainableInvesting(SustainableInvesting);
		}
		if (MacEligibility != "") {
			createsmadualstrategypageobj.selectMACEligibility(MacEligibility);
		}
		if (ICEligibility != "") {
			createsmadualstrategypageobj.selectICEligibility(ICEligibility);
		}
		if (ResearchRating != "") {
			createsmadualstrategypageobj.selectResearchRating(ResearchRating);
		}
		if (MaxMACFee != "") {
			createsmadualstrategypageobj.enterMACFeeValue(MaxMACFee);
		}
		if (RiskCategory != "") {
			createsmadualstrategypageobj.selectRiskCategory(RiskCategory);
		}
		if (Approvaldate != "") {
			createsmadualstrategypageobj.selectApprovaldate(Approvaldate);
		}
		if (StrategyMin != "") {
			createsmadualstrategypageobj.enterStrategyMin(StrategyMin);
		}
		if (FeeScheduleType != "") {
			createsmadualstrategypageobj.selectFeeSchedule(FeeScheduleType);
		}
		/*
		 * if (SplInstructionschkbox != "") {
		 * createsmadualstrategypageobj.chkboxSplInstructions(SplInstructionschkbox); }
		 * if (SplInstructions != "") {
		 * createsmadualstrategypageobj.enterSplInstructions(SplInstructions); }
		 */
		if (HideStrategychkbox != "") {
			createsmadualstrategypageobj.chkboxHideStrategy(HideStrategychkbox);
		}
		if (AARBaseTemplate != "") {
			createsmadualstrategypageobj.selectAARBaseTemplate(AARBaseTemplate);
		}
		if (CompUniverse != "") {
			createsmadualstrategypageobj.selectCompUniverse(CompUniverse);
		}
		Reporter.addScreenCapture();
	}

	@And("^User clicks on Next Button on the Create SMA Dual Page$")
	public void user_clicks_on_next_button_on_the_create_sma_dual_page() throws Throwable {
		createsmadualstrategypageobj.clickOnNextButton();
		Thread.sleep(5000);
	}

	@And("^User clicks on PM Link on Create New SMADual Strategy Page$")
	public void user_clicks_on_pm_link_on_create_new_smadal_strategy_page() throws Throwable {
		myElement = action.fluentWaitWebElement("Product Master Link_SMADualpage");
		action.highligthElement(myElement);
		action.click(myElement);
		Reporter.addStepLog("clicked on Product Master Link");
	}

	@And("^User inputs all the (.+) for single custom based benchmark on the Benchmark and Asset Classification page of SMA Dual Strategy$")
	public void user_inputs_all_the_for_single_custom_based_benchmark_on_the_benchmark_and_asset_classification_page_of_sma_dual_strategy(
			String valid_data) throws Throwable {
		if (valid_data.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("valid_data here : " + valid_data);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, valid_data);
		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 24);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 25);
		exlObj.closeWorkBook();
		createsmadualstrategybecnhamrkpageobj.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			createsmadualstrategybecnhamrkpageobj.enterSingleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@And("^User inputs all the (.+) for mul custom based benchmark on the Benchmark and Asset Classification page of SMA Dual Strategy$")
	public void user_inputs_all_the_for_mul_custom_based_benchmark_on_the_benchmark_and_asset_classification_page_of_sma_dual_strategy(
			String valid_data) throws Throwable {
		if (valid_data.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		System.out.println("valid_data here : " + valid_data);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, valid_data);
		String sb_1 = (String) exlObj.getCellData(sheet, rowIndex, 24);
		String cb_2 = (String) exlObj.getCellData(sheet, rowIndex, 25);
		exlObj.closeWorkBook();
		createsmadualstrategybecnhamrkpageobj.enterSingleUnbundledAssetClassification();
		if (sb_1 != cb_2) {
			createsmadualstrategybecnhamrkpageobj.enterMultipleComparativeBenchmark(sb_1, cb_2);
		}
	}

	@Then("^User should be able to see the Timestamp on the Create New SMA Dual Strategy page$")
	public void user_should_be_able_to_see_the_timestamp_on_the_create_new_sma_dual_strategy_page() throws Throwable {
		WebElement myElement = action.getElement("SMADualPageTimestamp");
		action.highligthElement(myElement);
		Reporter.addStepLog("Able to see Timestamp");
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Enter Strategy Details Header on Create New SMADual Strategy page$")
	public void user_should_be_able_to_see_the_enter_strategy_details_header_on_create_new_smadual_strategy_page()
			throws Throwable {
		WebElement myElement = action.fluentWaitWebElement("Enter Strategy Details Header");
		action.highligthElement(myElement);
		myElement.isDisplayed();
		Reporter.addStepLog("Able to see Enter Strategy Details Header");
		Reporter.addScreenCapture();
	}

	@And("^User enters the details in Strategy Wizard for SMADual$")
	public void user_enters_the_details_in_strategy_wizard_for_smadual() throws Throwable {
		String winHandleBefore = WebDriverManager.getDriver().getWindowHandle();
		WebDriverManager.getDriver().switchTo().window(winHandleBefore);
		Reporter.addStepLog("the window handle is" + winHandleBefore);
		createstrategypageobj.enterstrategynameinstrategywizard();
	}

	@Then("^User should be able to see the SMA Dual Strategy Name Header on Create New Strategy page$")
	public void user_should_be_able_to_see_the_sma_dual_strategy_name_header_on_create_new_strategy_page()
			throws Throwable {
		action.fluentWaitWebElement("SMADualStrategy Name Header").isDisplayed();
		action.highligthElement(action.getElement("SMADualStrategy Name Header"));
	}

	@And("^The text written in Strategy Name Header should match with the value of Strategy Name Value attribute on Create New SMA Dual Strategy page$")
	public void the_text_written_in_strategy_name_header_should_match_with_the_value_of_strategy_name_value_attribute_on_create_new_sma_dual_strategy_page()
			throws Throwable {
		Assert.assertEquals(action.getElement("SMADualStrategy Name").getAttribute("value"),
				action.getElement("SMADualStrategy Name Header").getText());
		Reporter.addStepLog("validated that the strategy name header value matches with the strategy name");
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see the Product Master Link on Create New SMADual Strategy page$")
	public void user_should_be_able_to_see_the_product_master_link_on_create_new_smadual_strategy_page()
			throws Throwable {
		action.getElement("Product Master Link_SMADualpage").isDisplayed();
		action.highligthElement(action.getElement("Product Master Link_SMADualpage"));
		Reporter.addStepLog("Able to see Product Master Link");
		Reporter.addScreenCapture();
	}

	@And("^User enters the details on the Create SMA Dual Proxy Page$")
	public void user_enters_the_details_on_the_create_sma_dual_proxy_page() throws Throwable {
		createsmadualstrategyproxypageobj.enterManagerNameinProxyPage();
		createsmadualstrategyproxypageobj.enterAddressLine1inProxyPage();
		createsmadualstrategyproxypageobj.enterCityinProxyPage();
		createsmadualstrategyproxypageobj.selectState();
		createsmadualstrategyproxypageobj.enterZipCodeinProxyPage();
		createsmadualstrategyproxypageobj.Voluntaryreorgchkbox();
		createsmadualstrategyproxypageobj.Interimreorgchkbox();
	}

	@And("^User clicks on Next Button on the Create SMA Dual Proxy Page$")
	public void user_clicks_on_next_button_on_the_create_sma_dual_proxy_page() throws Throwable {
		createsmadualstrategyproxypageobj.clickOnNextButtonProxyPage();
	}

	@And("^User clicks on Next Button on the Create SMA Dual Documents Page$")
	public void user_clicks_on_next_button_on_the_create_sma_dual_documents_page() throws Throwable {
	}

	@And("^User clicks on Next Button on the Create SMA Dual Comments Page$")
	public void user_clicks_on_next_button_on_the_create_sma_dual_comments_page() throws Throwable {
	}

	@And("^User clicks on Next Button on the Create SMA Dual Review Page$")
	public void user_clicks_on_next_button_on_the_create_sma_dual_review_page() throws Throwable {
	}

	@Then("^User should be able to see the below fields on Create New Strategy Confirmation page$")
	public void user_should_be_able_to_see_the_below_fields_on_create_new_strategy_confirmation_page(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			con.verifyElementsonconfirmationpage(con.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should be able to see the FOA Code$")
	public void user_should_be_able_to_see_the_foa_code() throws Throwable {
		action.highligthElement(action.getElement("FOACode"));
		action.isDisplayed(action.getElement("FOACode"));
	}

	@And("^User clicks on Submit Button on Create New Strategy Review Page$")
	public void user_clicks_on_submit_button_on_create_new_strategy_review_page() throws Throwable {
		reviewpage.clickOnSubmitt();
	}

	@And("^the user amends the values to the dropdown for asset classification$")
	public void the_user_amends_the_values_to_the_dropdown_for_asset_classification(List<List<String>> attribute)
			throws Throwable {
		sheetName = "Valid";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_HappyFlow1");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(2000);
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@Then("^User should be able to view DVP/Key Trust template field on Benchmark and Asset Classification page while Creating SMA - Dual Strategy$")
	public void user_should_be_able_to_view_dvp_key_trust_template_field_on_benchmark_and_asset_classification_page_while_creating() {
		Assert.assertTrue(createsmadualstrategybecnhamrkpageobj.isDvpKeyTrustTemplateVisible());
	}

	@And("^User should be able to see Benchmark details Page in Create SMA Dual Flow$")
	public void user_should_be_able_to_see_benchmark_details_page_in_pmp_flow() {
		assertTrue(createsmadualstrategybecnhamrkpageobj.isUserOnBenchmarkPage());
	}

	@And("^User clicks on create SMA Dual Strategy with (.+) in Landing Page$")
	public void user_clicks_on_create_sma_dual_startegy_in_landing_page(String strategyName) {
		landingPage.clickOncreatenewdropdownicon();
		landingPage.clickOnstrategydropdownmenu();
		assertTrue(strategyDetailsPage.isUserOnCreateStrategyWizardPage());
		createsmadualstrategypageobj.clickOnSMADualRadioButton();
		createsmadualstrategypageobj.enterStrategyName(strategyName);
		createsmadualstrategypageobj.clickOnCreateButton();
	}

	@And("^User clicks on Previous button on Create SMA Dual Proxy page$")
	public void user_clicks_on_previous_button_on_create_sma_dual_proxy_page() {
		Assert.assertTrue(createsmadualstrategyproxypageobj.isUserOnProxyDetailsPage());
		createsmadualstrategyproxypageobj.clickonPreviousButton();
	}

	@And("^User inputs (.+) in Benchmark Page in Create SMA Dual Flow$")
	public void user_inputs_benchmark_details_page_in_create_sma_dual_flow(String valid_data) throws SQLException {
		if (valid_data.contains("Valid")) {
			sheetName = "Valid";
		}

		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, valid_data);

		String unbundledNodeId = (String) exlObj.getCellData(sheet, rowIndex, 27);
		String unbundledNodeIdPercentage = (String) exlObj.getCellData(sheet, rowIndex, 28);
		// exlObj.closeWorkBook();
		String benchmarkCategory = (String) exlObj.getCellData(sheet, rowIndex, 29);
		String benchmark = (String) exlObj.getCellData(sheet, rowIndex, 30).toString();
		String benchmarkPercentage = (String) exlObj.getCellData(sheet, rowIndex, 31).toString();
		String customBenchmarkReason = (String) exlObj.getCellData(sheet, rowIndex, 32);

		if (unbundledNodeId != "") {

			int i = 0;
			sheetName = "VariablePaths";
			sheet = exlObj.getSheet(sheetName);
			String locatorValueUnbundledNodeId = (String) exlObj.getCellData(sheet, 1, 1);
			String locatorValueUnbundledNodeIdHighlight = (String) exlObj.getCellData(sheet, 2, 1);
			String locatorValueUnbundledNodeIdPercentage = (String) exlObj.getCellData(sheet, 3, 1);

			if (unbundledNodeId.contains(",")) {

				String[] unBundle = unbundledNodeId.split(",");
				String[] percent = unbundledNodeIdPercentage.split(",");
				int size = unBundle.length;
				while (size > 0) {
					createsmadualstrategybecnhamrkpageobj.enterUnbundledNodeId(
							locatorValueUnbundledNodeId.replace("@data", i + "'"),
							locatorValueUnbundledNodeIdHighlight.replace("@data", i + "'"), unBundle[i]);
					createsmadualstrategybecnhamrkpageobj.enterUnbundledNodeIdPercentage(
							locatorValueUnbundledNodeIdPercentage.replace("@data", i + "'"), percent[i]);
					i++;
					size--;
					if (size > 0) {
						createsmadualstrategybecnhamrkpageobj.clickOnAddNewAssetClassification();
					}
				}
			} else {

				createsmadualstrategybecnhamrkpageobj.enterUnbundledNodeId(
						locatorValueUnbundledNodeId.replace("@data", i + "'"),
						locatorValueUnbundledNodeIdHighlight.replace("@data", i + "'"), unbundledNodeId);
				createsmadualstrategybecnhamrkpageobj.enterUnbundledNodeIdPercentage(
						locatorValueUnbundledNodeIdPercentage.replace("@data", i + "'"), unbundledNodeIdPercentage);
			}

		}

		if (benchmarkCategory != "") {

			switch (benchmarkCategory) {
			case "Custom":
				createsmadualstrategybecnhamrkpageobj.selectCustom();
				if (benchmark != "") {

					int i = 0;
					sheetName = "VariablePaths";
					sheet = exlObj.getSheet(sheetName);

					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, valid_data);
					String locatorValueCustomBenchmark = (String) exlObj.getCellData(sheet, 4, 1);
					String locatorValueCustomBenchmarkHighlight = (String) exlObj.getCellData(sheet, 5, 1);
					String locatorValueCustomBenchmarkPercentage = (String) exlObj.getCellData(sheet, 6, 1);

					if (benchmark.contains(",")) {
						String[] customBenchmark = benchmark.split(",");
						String[] customBenchmarkPercentage = benchmarkPercentage.split(",");
						int size = customBenchmark.length;

						while (size > 0) {
							createsmadualstrategybecnhamrkpageobj.enterCustomBenchmark(
									locatorValueCustomBenchmark.replace("@data", i + "'"),
									locatorValueCustomBenchmarkHighlight.replace("@data", i + "'"), customBenchmark[i],
									benchmarkCategory);
							createsmadualstrategybecnhamrkpageobj.enterCustomBenchmarkPercentage(
									locatorValueCustomBenchmarkPercentage.replace("@data", i + "'"),
									customBenchmarkPercentage[i], benchmarkCategory);
							i++;
							size--;
							if (size > 0) {
								createsmadualstrategybecnhamrkpageobj.addNewBenchmark();
							}
						}
					} else {

						createsmadualstrategybecnhamrkpageobj.enterCustomBenchmark(
								locatorValueCustomBenchmark.replace("@data", i + "'"),
								locatorValueCustomBenchmarkHighlight.replace("@data", i + "'"), benchmark,
								benchmarkCategory);
						createsmadualstrategybecnhamrkpageobj.enterCustomBenchmarkPercentage(
								locatorValueCustomBenchmarkPercentage.replace("@data", i + "'"), benchmarkPercentage,
								benchmarkCategory);

					}

				}

				if (customBenchmarkReason != "") {
					createsmadualstrategybecnhamrkpageobj.enterCustomBenchmarkReason(customBenchmarkReason);
				}
				break;

			case "Default":

				createsmadualstrategybecnhamrkpageobj.clickOnViewDetails();
				assertTrue(createsmadualstrategybecnhamrkpageobj.isDefaultValueAutopopulated(valid_data));
				createsmadualstrategybecnhamrkpageobj.clickOnCrossIcon();
				break;

			default:
				break;
			}

		}

	}

	@Then("^User should be able to see added Unbundled Node Ids from (.+) are sorted in descending order in Benchmark Page in Create SMA Dual Flow$")
	public void user_should_be_able_to_see_added_unbundled_node_ids_from_are_sorted_in_descending_order_in_benchmark_page_in_create_sma_sa_flow(
			String mandatorydetails) {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		String unBundledNodeID, unBundledNodeIDPercentage = "";

		String tName = Thread.currentThread().getName();
		synchronized (tName) {

			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			unBundledNodeID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 27);
			unBundledNodeIDPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 28);
		}

		HashMap<String, Float> unbundledNodeIdMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();

		if (unBundledNodeID.contains(",")) {
			String[] custom = unBundledNodeID.split(",");
			String[] customPercentage = unBundledNodeIDPercentage.split(",");
			int size = custom.length;

			for (int i = 0; i < size; i++) {
				unbundledNodeIdMap.put(custom[i], Float.parseFloat(customPercentage[i]));
			}

			sortedHashMap = sortUnbundledNodeIds(unbundledNodeIdMap);
		} else {
			sortedHashMap.put(unBundledNodeID, Float.parseFloat(unBundledNodeIDPercentage));
		}

		String unbundledNodeIdfromUI;
		Float unbundledNodeIdPercentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {

			unbundledNodeIdfromUI = createsmadualstrategybecnhamrkpageobj.getUnbundledithValuefromUI(j);
			unbundledNodeIdPercentagefromUI = createsmadualstrategybecnhamrkpageobj
					.getUnbundledPercentageithValuefromUI(j);

			Assert.assertTrue(unbundledNodeIdPercentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(unbundledNodeIdfromUI.equals(benchmarkKey));
			j++;

		}
	}

	private LinkedHashMap<String, Float> sortUnbundledNodeIds(HashMap<String, Float> unbundledNodeIdMap) {
		Set<Entry<String, Float>> customBenchmarkEntrySet = unbundledNodeIdMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		// sort based on benchmark names first to handle Equal Percentage scenario in
		// ascending order
		Collections.sort(entryList, (o1, o2) -> o1.getKey().substring(0, o1.getKey().length() - 5).trim()
				.compareTo(o2.getKey().substring(0, o2.getKey().length() - 5).trim()));

		// sort based on benchmark percentage in descending order
		Collections.sort(entryList, (o1, o2) -> {
			if (o1.getValue() > o2.getValue()) {
				return -1;
			} else if (o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		return sortedHashMap;
	}

	@And("^User should be able to see Review Page in Create SMA Dual Flow$")
	public void user_should_be_able_to_see_review_page_in_create_sma_sa_flow() {
		Assert.assertTrue(reviewpage.isUserOnReviewPage());
	}

	@Then("^User should be able to see added Unbundled Node Ids from (.+) are sorted in descending order in Review Page in Create SMA Dual Flow$")
	public void user_should_be_able_to_see_added_unbundled_node_ids_from_are_sorted_in_descending_order_in_review_page_in_create_sma_dual_flow(
			String mandatorydetails) {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		String unBundledNodeID, unBundledNodeIDPercentage = "";

		String tName = Thread.currentThread().getName();
		synchronized (tName) {

			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);

			unBundledNodeID = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 27);
			unBundledNodeIDPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 28);

		}

		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();

		if (unBundledNodeID.contains(",")) {
			String[] customBenchmark = unBundledNodeID.split(",");
			String[] customBenchmarkPercentage = unBundledNodeIDPercentage.split(",");
			int size = customBenchmark.length;

			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}

			sortedHashMap = sortUnbundledNodeIds(customBenchmarkMap);
		} else {
			sortedHashMap.put(unBundledNodeID, Float.parseFloat(unBundledNodeIDPercentage));
		}

		String unbundledNodeIdfromUI;
		Float unbundledNodeIdPercentagefromUI;
		int j = 1;
		reviewpage.moveToBenchmarkHeader();
		for (String benchmarkKey : sortedHashMap.keySet()) {

			unbundledNodeIdfromUI = reviewpage.getUnbundledithValuefromUI(j);
			unbundledNodeIdPercentagefromUI = reviewpage.getUnbundledPercentageithValuefromUI(j);
			Assert.assertTrue(unbundledNodeIdPercentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(unbundledNodeIdfromUI.equals(benchmarkKey.substring(0, benchmarkKey.length() - 5)));
			j++;

		}
	}

	@Then("^User should be able to see added benchmarks from (.+) are sorted in descending order in Benchmark Page in Create SMA Dual Flow$")
	public void user_should_be_able_to_see_added_benchmarks_from_are_sorted_in_descending_order_in_benchmark_page_in_create_sma_dual_flow(
			String mandatorydetails) {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		String benchmark, benchmarkPercentage = "";

		String tName = Thread.currentThread().getName();
		synchronized (tName) {

			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 30);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 31);
		}

		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();

		if (benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");
			int size = customBenchmark.length;

			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}

			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		} else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}

		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {

			benchmarkfromUI = createsmadualstrategybecnhamrkpageobj.getBenchmarkithValuefromUI(j);
			percentagefromUI = createsmadualstrategybecnhamrkpageobj.getPercentageithValuefromUI(j);

			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey));
			j++;

		}
	}

	private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
		Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		// sort based on benchmark names first to handle Equal Percentage scenario in
		// ascending order
		Collections.sort(entryList,
				(o1, o2) -> o1.getKey().split(" - ")[1].trim().compareTo(o2.getKey().split(" - ")[1].trim()));

		// sort based on benchmark percentage in descending order
		Collections.sort(entryList, (o1, o2) -> {
			if (o1.getValue() > o2.getValue()) {
				return -1;
			} else if (o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});

		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
		 * 
		 * @Override public int compare(Entry<String, Float> o1, Entry<String, Float>
		 * o2) { if(o1.getValue() > o2.getValue()) { return -1; }else if(o1.getValue() <
		 * o2.getValue()) { return 1; } return 0; } });
		 */

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		 * for (String countryKey : sortedHashMap.keySet()) {
		 * System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		 * 
		 * }
		 */

		return sortedHashMap;
	}

	@Then("^User should be able to see added benchmarks from (.+) are sorted in descending order in Review Page in Create SMA Dual Flow$")
	public void user_should_be_able_to_see_added_benchmarks_from_are_sorted_in_descending_order_in_review_page_in_create_sma_dual_flow(
			String mandatorydetails) {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}

		String benchmarkCategory, benchmark, benchmarkPercentage, customBenchmarkReason = "";
		String locatorValueCustomBenchmark, locatorValueCustomBenchmarkHighlight,
				locatorValueCustomBenchmarkPercentage = "";

		String tName = Thread.currentThread().getName();
		synchronized (tName) {

			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);

			benchmark = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 30);
			benchmarkPercentage = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 31);

		}

		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();

		if (benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");
			int size = customBenchmark.length;

			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}

			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		} else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}

		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		reviewpage.moveToBenchmarkHeader();
		for (String benchmarkKey : sortedHashMap.keySet()) {

			benchmarkfromUI = reviewpage.getBenchmarkithValuefromUI(j);
			percentagefromUI = reviewpage.getPercentageithValuefromUI(j);

			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey.split(" - ")[1].trim()));
			j++;

		}
	}

	@Then("^User should be in sma dual confirmation page and validate the custom benchmarktype from db$")
	public void user_should_be_in_sma_dual_confirmation_page_and_validate_the_custom_benchmarktype_from_db() throws Throwable {
		con.isStrategyCreatedSuccessfully();
		strategyCode = con.getStrategyCodeDual();
		//System.out.println(strategyCode);
		pmdb.DBConnectionStart();
		ResultSet result = DBManager.executeSelectQuery(
				"select selected_benchmark_type from Strategy where strategy_code='" + strategyCode + "'");
		while (result.next()) {
			benchmarkType = result.getString(1);
			//System.out.println(benchmarkType);
		}

		ResultSet result2 = DBManager.executeSelectQuery(
				"select list_id from list_values where list_type like '%BENCHMARK CATEGORY%' and list_code = 'C'");
		while (result2.next()) {
			benchmarkTypeCode = result2.getString(1);
			//System.out.println(benchmarkTypeCode);
		}
		Assert.assertTrue(benchmarkType.equals(benchmarkTypeCode));

	}
	
	@Then("^User should be in sma dual confirmation page and validate the style benchmarktype from db$")
	public void user_should_be_in_sma_dual_confirmation_page_and_validate_the_style_benchmarktype_from_db() throws Throwable {
		con.isStrategyCreatedSuccessfully();
		strategyCode = con.getStrategyCodeDual();
		//System.out.println(strategyCode);
		pmdb.DBConnectionStart();
		ResultSet result = DBManager.executeSelectQuery(
				"select selected_benchmark_type from Strategy where strategy_code='" + strategyCode + "'");
		while (result.next()) {
			benchmarkType = result.getString(1);
			//System.out.println(benchmarkType);
		}

		ResultSet result2 = DBManager.executeSelectQuery(
				"select list_id from list_values where list_type like '%BENCHMARK CATEGORY%' and list_code = 'D'");
		while (result2.next()) {
			benchmarkTypeCode = result2.getString(1);
			//System.out.println(benchmarkTypeCode);
		}
		Assert.assertTrue(benchmarkType.equals(benchmarkTypeCode));

	}
}
