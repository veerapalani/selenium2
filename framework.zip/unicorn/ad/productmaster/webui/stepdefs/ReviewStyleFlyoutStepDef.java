package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
public class ReviewStyleFlyoutStepDef {
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	List<String> listOfString = new ArrayList<String>();
	Action action;
	String value;
	Alert alert;
	Select dropdown;
	PMPageGeneric ReviewStyleFlyout = new PMPageGeneric("AD_PM_ReviewStyleFlyout");
	@Then("^User should be able to see the \"([^\"]*)\" on Review Style Flyout$")
    public void user_should_be_able_to_see_the_something_on_review_style_flyout(String key) throws Throwable {
        ReviewStyleFlyout.verifyElement(key);
        Reporter.addStepLog("verified that the "+key+" is present");
    }
	
	@And("^User clicks on \"([^\"]*)\" on Review Style Flyout$")
    public void user_clicks_on_something_on_review_style_flyout(String key) throws Throwable {
        ReviewStyleFlyout.clickOnLink(key);
        Reporter.addStepLog("clicked on "+key);
    }
	
	@Then("^User should be able to go to the Review Style Flyout$")
    public void user_should_be_able_to_go_to_the_review_style_flyout() throws Throwable {
        Assert.assertNotSame("Create new style", ReviewStyleFlyout.getElement("Header").getText());
        Reporter.addStepLog("User is reached to ReviewStyleFlyout");
        Reporter.addScreenCapture();
    }
	
	@Then("^User should be able to see \"([^\"]*)\" in the \"([^\"]*)\" on Review Style Flyout$")
    public void user_should_be_able_to_see_something_in_the_something_on_review_style_flyout(String hashMapKey, String key) throws Throwable {
        value = PMPageGeneric.UIPassedValues.get(hashMapKey);
        Assert.assertEquals(value, ReviewStyleFlyout.getText(key));
        Reporter.addStepLog("Verified that "+hashMapKey+" is present in "+key);
        Reporter.addScreenCapture();
    }
	
	@Then("^The value for the following attributes in Review Style Flyout should match what we have given earlier$")
    public void the_value_for_the_following_attributes_in_review_style_flyout_should_match_what_we_have_given_earlier(List<String> entity) throws Throwable {
        for (int i=0;i<entity.size();i++) {
        	myElement = ReviewStyleFlyout.findElementByDynamicXpath("//small[contains(text(),'"+entity.get(i)+"')]/parent::p/following-sibling::span");
        	ReviewStyleFlyout.verifyTextInElement(PMPageGeneric.UIPassedValues.get(entity.get(i)), myElement);
        	
        	Reporter.addStepLog("verified the value for "+entity.get(i));
        }
        Reporter.addScreenCapture();
    }
	
	
}
