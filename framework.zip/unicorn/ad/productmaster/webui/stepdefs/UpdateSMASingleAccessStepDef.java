package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.ibm.db2.jcc.a.a;
import com.ibm.db2.jcc.a.i;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.StrategyDetailPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFATeamUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategySMADualUIPage;
import org.openqa.selenium.support.ui.Select;
import qa.unicorn.ad.productmaster.webui.pages.CreateFATeamPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import java.util.HashMap;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import qa.framework.dbutils.DBManager;

public class UpdateSMASingleAccessStepDef {
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateSMASingleAccess.xlsx";
	CreateSMASingleAccessStrategyBenchmarkPage benchmarkPage = new CreateSMASingleAccessStrategyBenchmarkPage(
			"AD_PM_CreateSMASingleAccessStrategyBenchmarkPage");
	ProductMasterDBManager pmdb1 = new ProductMasterDBManager();
	String excelFilePath1 = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
	String sheetName = "";
	String myValue;
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	WebElement myElement;
	List<WebElement> myElements;

	int num;

	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);

	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateEntityPage"));
	LandingPage landingPage1 = new LandingPage("AD_PM_LandingPage");

	UpdateSMASingleAccessUIPage updateSMASinglePage = new UpdateSMASingleAccessUIPage();
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	ExcelUtils exlObj1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	UpdateStrategyPage up = new UpdateStrategyPage();
	SoftAssert sftAst = new SoftAssert();

	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	HashMap<String, Object> row = new HashMap<String, Object>();

	@And("^user gets a count of the existing strategies from the accordion by clicking at the SMA tab$")
	public void user_gets_a_count_of_the_existing_strategies_from_the_accordion_by_clicking_at_the_sma_tab()
			throws InterruptedException {
		landingPage1.smacount();

	}

	@When("^User search with the (.+) taken from (.+) in the Search TextBox on landing page while SMASingleAccess updation$")
	public void user_search_with_the_taken_from_in_the_search_textbox_on_landing_page_while_smasingleaccess_updation(
			String entity, String searchcode) throws Throwable {
		// action.waitForPageLoad();
		Thread.sleep(5000);
		sheetName = entity;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, searchcode);

		myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
		searchcode = myValue;
		System.out.println(myValue);

		Boolean compareBoolean = action.isPresent("js",
				"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");

		if (compareBoolean) {

			Thread.sleep(5000);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}

		Thread.sleep(5000);

		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		Thread.sleep(5000);
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;

		while (i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);
	}

	@Then("^User clicks on the first element of SMASingleAccess Searches on the suggestion box on landing page while SMASingleAccess updation$")
	public void user_clicks_on_the_first_element_of_smasingleaccess_searches_on_the_suggestion_box_on_landing_page_while_smasingleaccess_updation()
			throws Throwable {

		/*
		 * updateSMASinglePage.
		 * waitForWebElement("(//p[@class='body-3 text-tertiary'])[1]"); myElement =
		 * updateSMASinglePage.
		 * findElementByDynamicXpath("(//p[@class='body-3 text-tertiary'])[1]");
		 * action.scrollToElement(myElement); action.highligthElement(myElement);
		 * Thread.sleep(2000); myElement.click();
		 * Reporter.addStepLog("clicked on first suggestion ");
		 */

		myElements = updateSMASinglePage
				.findElementsByDynamicXpath("//label[contains(text(),'SMA Strategy')]//parent::div//div[2]");

		String status = "FAIL";

		for (WebElement E : myElements) {
			if (E.getText().toUpperCase().contains(myValue.toUpperCase())) {
				status = "PASS";
				// Thread.sleep(4000);
				action.scrollToElement(E);
				action.highligthElement(E);
				Thread.sleep(5000);
				E.click();
				Reporter.addStepLog("clicking on the matching suggestion");

				break;
			}

		}

		if (status.contentEquals("FAIL")) {
			myElement.sendKeys(Keys.ENTER);

			myElements = updateSMASinglePage
					.findElementsByDynamicXpath("//label[contains(text(),'SMA Strategy')]//parent::div//div[2]");

			for (WebElement E : myElements) {
				if (E.getText().toUpperCase().contains(myValue.toUpperCase())) {
					action.scrollToElement(E);
					action.highligthElement(E);
					Thread.sleep(5000);
					E.click();

					action.waitForPageLoad();

					Reporter.addStepLog("clicking on the matching suggestion");

					break;
				}

			}
		}

	}

	@Then("^User clicks on the CONTINUE EDITING Button on SMASingleAccess Details page$")
	public void user_clicks_on_the_continue_editing_button_on_smasingleaccess_details_page() throws Throwable {
		Thread.sleep(3000);
		myElement = updateSMASinglePage.findElementByDynamicXpath("//span[contains(text(),'CONTINUE EDITING')]");

		action.highligthElement(myElement);
		Thread.sleep(2000);

		myElement.click();
		Reporter.addStepLog("Clicked on Continue Editing Button");
		Thread.sleep(3000);
	}

	@And("^Edit all the below drop down fields with valid data for SMASingleAccess updation flow$")
	public void edit_all_the_below_drop_down_fields_with_valid_data_for_smasingleaccess_updation_flow(
			List<List<String>> attribute) throws Throwable {
		sheetName = "SMASingleAccess";
		sheet = exlObj.getSheet(sheetName);
		// Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			// Thread.sleep(2000);
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			// Thread.sleep(2000);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			// Thread.sleep(2000);
		}

	}

	@And("^Edit all the below input fields with valid data for SMASingleAccess updation flow$")
	public void edit_all_the_below_input_fields_with_valid_data_for_smasingleaccess_updation_flow(
			List<List<String>> attribute) throws Throwable {
		sheetName = "SMASingleAccess";
		sheet = exlObj.getSheet(sheetName);
		// Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			// System.out.println("xyz");
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			// action.clear(myElement);

			/*
			 * JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
			 * js.executeScript("arguments[0].value='';",myElement);
			 */
			up.sendKeysWithCheck(myElement, myValue);

			System.out.println(attribute.get(i).get(0) + " value " + myValue);
			// action.sendKeys(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			// Thread.sleep(2000);
		}
	}

	@And("^Edit all the below text fields with valid data for SMASingleAccess updation flow$")
	public void edit_all_the_below_text_fields_with_valid_data_for_smasingleaccess_updation_flow(
			List<List<String>> attribute) throws Throwable {
		sheetName = "SMASingleAccess";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-textarea[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('textarea')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			// Thread.sleep(2000);
		}
	}

	@Then("^User clicks the Next Button of SMASingleAccess updation flow$")
	public void user_clicks_the_next_button_of_smasingleaccess_updation_flow() throws Throwable {

		myElement = (WebElement) action
				.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Reporter.addStepLog("Clicked on Next button");
		Thread.sleep(8000);
	}

	@And("^User clicks upon the Unbundled Node dropdown$")
	public void user_clicks_upon_the_unbundled_node_dropdown() throws Throwable {

		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector(\"#ddlBenchmarkunBundledNode-0\").shadowRoot.querySelector(\"wf-input\")");
		action.click(myElement);
		Reporter.addStepLog("Clicked on Next button");
		Thread.sleep(2000);
	}

	@And("^further as after the concord fee check box the premium fee is also clicked upon$")
	public void further_as_after_the_concord_fee_check_box_the_premium_fee_is_also_clicked_upon() throws Throwable {

		up.clickonpremiumfeecheck();
	}

	@And("^chooses to select any other value from the list other than the one already selected$")
	public void chooses_to_select_any_other_value_from_the_list_other_than_the_one_already_selected(
			List<List<String>> attribute) throws Throwable {

		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"#ddlBenchmarkunBundledNode-0\").shadowRoot.querySelector(\"wf-input\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(2000);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"#ddlBenchmarkunBundledNode-0\").shadowRoot.querySelector(\"li[data-value='"
							+ myValue + "']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^user deletes the given Time Period  $")
	public void user_deletes_the_given_time_period() throws Throwable {
		Thread.sleep(2000);
		// up.deletetimeperiod();
	}

	@And("^user deletes the time period given for an existing benchmark$")
	public void user_deletes_the_time_period_given_for_an_existing_benchmark() throws Throwable {

		Thread.sleep(2000);
		// up.deletetimeperiod();

	}

	@And("^provides the required percentage value that equals hundred$")
	public void provides_the_required_percentage_value_that_equals_hundred(List<List<String>> attribute)
			throws Throwable {

		sheetName = "SMASingleAccess";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			System.out.println(attribute.get(i).get(0) + " value " + myValue);
			action.sendKeys(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^edits the benchmark page in the following manner$")
	public void edits_the_benchmark_page_in_the_following_manner() throws Throwable {
		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector(\"#ddlBenchmarkunBundledNode-0\").shadowRoot.querySelector(\"wf-tooltip > div > div > wf-dropdown > div > div.os-padding > div > div > ul > li:nth-child(3) > a\")]");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(5000);
		myElement.click();
		Reporter.addStepLog("clicked on first suggestion ");

	}

	@And("^user moves to the benchmark page to choose the benchmark from dropdown$")
	public void user_moves_to_the_benchmark_page_to_choose_the_benchmark_from_dropdown(List<List<String>> attribute)
			throws Throwable {
		sheetName = "SMASingleAccess";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for (int i = 0; i < attribute.size(); i++) {

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));

			System.out.println(attribute.get(i).get(0));
			myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(2000);
			myElement = (WebElement) action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

//			    @And("^user provides the \"([^\"]*)\" in the Unbundled node id$")
//			    public void user_provides_the_something_in_the_unbundled_node_id(String mandatorydetails) throws IOException {
//			    	if (mandatorydetails.contains("Test")) {
//						sheetName = "Test";
//					}
//
//					String environment = SSOLoginPage.UIEnvironment.toLowerCase();
//					if(environment.equalsIgnoreCase("dev")) {
//						mandatorydetails = mandatorydetails+"_dev";
//					}
//					if(environment.equalsIgnoreCase("qa")) {
//						mandatorydetails = mandatorydetails+"_qa";
//					}
//					if(environment.equalsIgnoreCase("uat")) {
//						mandatorydetails = mandatorydetails+"_uat";
//					}
//					sheet = exlObj.getSheet(sheetName);
//					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
//			        benchmarkPage.clickOnNext();
//			        
//			        assertTrue(benchmarkPage.isUserOnBenchmarkPage());
//			        Reporter.addStepLog("User after Clicking on Next is not moving to next page");
//			        
//			        String expError = (String) exlObj.getCellData(sheet, rowIndex, 81);
//			    	assertTrue(benchmarkPage.error(expError));
//			    	
//			    	Reporter.addEntireScreenCaptured();
//			    }
//	

	@And("^the user who has the \"([^\"]*)\" adds the details that matter in the benchmark page$")
	public void the_user_who_has_the_something_adds_the_details_that_matter_in_the_benchmark_page(
			String mandatorydetails) throws IOException {
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		// sheet = exlObj.getSheet(sheetName);

		// String environment =
		// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if (environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails + "_dev";
		}
		if (environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails + "_qa";
		}
		if (environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails + "_uat";
		}

		sheet = exlObj1.getSheet(sheetName);
		rowIndex = exlObj1.getRowIndexByCellValue(sheet, 0, mandatorydetails);

		String unbundledNodeId = (String) exlObj1.getCellData(sheet, rowIndex, 43);
		String unbundledNodeIdPercentage = (String) exlObj1.getCellData(sheet, rowIndex, 44).toString();
		exlObj.closeWorkBook();

		if (unbundledNodeId != "") {

			int i = 0;
			sheetName = "VariablePaths";
			sheet = exlObj.getSheet(sheetName);

			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
			String locatorValueUnbundledNodeId = (String) exlObj.getCellData(sheet, 7, 1);
			String locatorValueUnbundledNodeIdHighlight = (String) exlObj1.getCellData(sheet, 8, 1);
			String locatorValueUnbundledNodeIdPercentage = (String) exlObj1.getCellData(sheet, 9, 1);

			if (unbundledNodeId.contains(",")) {

				String[] unBundle = unbundledNodeId.split(",");
				String[] percent = unbundledNodeIdPercentage.split(",");
				int size = unBundle.length;

				while (size > 0) {
					benchmarkPage.enterUnbundledNodeId(locatorValueUnbundledNodeId.replace("@data", i + "'"),
							locatorValueUnbundledNodeIdHighlight.replace("@data", i + "'"), unBundle[i], i);
					benchmarkPage.enterUnbundledNodeIdPercentage(
							locatorValueUnbundledNodeIdPercentage.replace("@data", i + "'"), percent[i], i);
					i++;
					size--;
					if (size > 0) {
						benchmarkPage.addAssetClassification();
					}
				}
			} else {

				benchmarkPage.enterUnbundledNodeId(locatorValueUnbundledNodeId.replace("@data", i + "'"),
						locatorValueUnbundledNodeIdHighlight.replace("@data", i + "'"), unbundledNodeId, i);
				benchmarkPage.enterUnbundledNodeIdPercentage(
						locatorValueUnbundledNodeIdPercentage.replace("@data", i + "'"), unbundledNodeIdPercentage, i);
			}
		}
	}

	@And("^user clicks on the link to add a new time period$")
	public void user_clicks_on_the_link_to_add_a_new_time_period() throws Throwable {

		up.deletetimeperiod();
	}

	@And("^deletes the existing timeperiod$")
	public void deletes_the_existing_timeperiod() throws Throwable {

		up.deletetimeperiod();
	}

	@When("^User search with the Strategy code taken from DB in the Search TextBox on landing page for SMASingleAccess$")
	public void user_search_with_the_strategy_code_taken_from_db_in_the_search_textbox_on_landing_page_for_smasingleaccess() throws InterruptedException, SQLException {
		// action.waitForPageLoad();
		
		pmdb.DBConnectionStart();
		ResultSet result = DBManager.executeSelectQuery("select strategy_code from strategy where strategy_id in (select strategy_id from program_strategy where program_id in (select program_id from program where program_description='ACCESS')) limit 1");
		while(result.next())
		{
			myValue = result.getString(1);
			System.out.println(myValue);
		}

		Boolean compareBoolean = action.isPresent("js",
				"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");

		if (compareBoolean) {

			Thread.sleep(5000);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"button\")");
			myElement.click();
		}

		Thread.sleep(5000);

		myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		Thread.sleep(5000);
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;

		while (i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);
	}

}
