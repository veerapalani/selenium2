package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.HOApprovalSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.MutualFundsSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.RejectedStrategiesSortAndFilterPage;

public class RejectedStrategiesSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	PMPSortAndFilterPage pmpSortAndFilterPage = new PMPSortAndFilterPage("AD_PM_PMPSortAndFilterPage");
	HOApprovalSortAndFilterPage hoApprovalSortAndFilterPage = new HOApprovalSortAndFilterPage(
			"AD_PM_HOApprovalSortAndFilterPage");
	RejectedStrategiesSortAndFilterPage rejectedStrategiesSortAndFilterPage = new RejectedStrategiesSortAndFilterPage(
			"AD_PM_RejectedStrategiesSortAndFilterPage");
	MutualFundsSortAndFilterPage mutualFundsSortAndFilterPage2 = new MutualFundsSortAndFilterPage(
			"AD_PM_BenchmarkSortAndFilterPage");
	PMPageGeneric pmPageGeneric = new PMPageGeneric("AD_PM_MutualFundsSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/PMPSortAndFilter.xlsx";
	String excelFilePath2 = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String expError, countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	WebElement myElement;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_RejectedStrategiesSortAndFilterPage"));

	@When("^user click on \"([^\"]*)\" tab on landing page for Rejected Strategies$")
	public void user_click_on_something_tab_on_landing_page_for_rejected_strategies(String strArg1) throws Throwable {
		rejectedStrategiesSortAndFilterPage.verifyAndClickRejectedStrategiesTab();
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design for Rejected Strategies$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design_for_rejected_strategies(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			rejectedStrategiesSortAndFilterPage.mouseHoverOnGridViewLabels(rejectedStrategiesSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			rejectedStrategiesSortAndFilterPage.verifyGridViewLabelsWithSortIcons(rejectedStrategiesSortAndFilterPage
					.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for Rejected Strategies$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_rejected_strategies(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			rejectedStrategiesSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					rejectedStrategiesSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'"
							+ entity.get(i) + "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for Rejected Strategies$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_rejected_strategies(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			rejectedStrategiesSortAndFilterPage.mouseHoverOnGridViewLabels(rejectedStrategiesSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			rejectedStrategiesSortAndFilterPage.clickOnSortIcon(rejectedStrategiesSortAndFilterPage
					.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for Rejected Strategies$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_rejected_strategies() throws Throwable {
		String value = pmpSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = PMPSortAndFilterPage.ascSortValue;
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for Rejected Strategies$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_rejected_strategies(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			pmpSortAndFilterPage.mouseHoverOnGridViewLabels(
					pmpSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]");
			pmpSortAndFilterPage.clickOnSortIcon(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for Rejected Strategies$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_rejected_strategies() throws Throwable {
		String value = pmpSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = PMPSortAndFilterPage.descSortValue;
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for Rejected Strategies$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_rejected_strategies(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			pmpSortAndFilterPage.mouseHoverOnGridViewLabels(
					pmpSortAndFilterPage.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]");
			pmpSortAndFilterPage.clickOnSortIcon(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for Rejected Strategies$")
	public void user_should_able_to_sort_the_records_with_default_order_for_rejected_strategies() throws Throwable {
		String value = pmpSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = PMPSortAndFilterPage.defaultSortValue;
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to click on the filter icon for below column for Rejected Strategies$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_rejected_strategies(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			hoApprovalSortAndFilterPage.clickOnFilterIconForGridView(
					pmpSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to validate the filter condition all options for Rejected Strategies$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_rejected_strategies(
			List<String> entity) throws Throwable {
		pmpSortAndFilterPage.clickOnFilterCondition();
		for (int i = 0; i < entity.size(); i++) {
			pmpSortAndFilterPage
					.waitForWebElement("//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']");
			pmpSortAndFilterPage.verifyValueOfFilterCondition(pmpSortAndFilterPage.findElementByDynamicXpath(
					"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to see grid view data for Rejected Strategies$")
	public void user_able_to_see_grid_view_data_for_rejected_strategies() throws Throwable {
		String gridCountBeforeCondition = rejectedStrategiesSortAndFilterPage
				.verifyTheGridCountBeforeApplyFilterAndSortCondition();
		// String gridCountBeforeCondition =
		// RejectedStrategiesSortAndFilterPage.gridCountAfterGlobalSearch;
		int beforeApplyCondition = Integer.parseInt(gridCountBeforeCondition);
		if (beforeApplyCondition == 1)
			rejectedStrategiesSortAndFilterPage.verifyTheNoResultsOnGridView();
	}

	@And("^User able to see tab count before any condition for Rejected Strategies$")
	public void user_able_to_see_tab_count_before_any_condition_for_rejected_strategies() throws Throwable {
		String beforeApplyFilterValue = rejectedStrategiesSortAndFilterPage
				.verifyTheRejectedStrategiesGridCountAfterApplyFilterConditionOnTab();
		// String beforeApplyFilterValue =
		// RejectedStrategiesSortAndFilterPage.tabCountAfterCondition;
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);
	}

	@And("^User able to select the (.+) from filter condition for Rejected Strategies$")
	public void user_able_to_select_the_from_filter_condition_for_rejected_strategies(String filtercondition)
			throws Throwable {
		rejectedStrategiesSortAndFilterPage.clickOnFilterCondition();
		rejectedStrategiesSortAndFilterPage.clickOnFilterConditionForRejectedStrategiesGridView(
				rejectedStrategiesSortAndFilterPage.findElementByDynamicXpath(
						"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for Rejected Strategies$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_rejected_strategies(
			String filterconditionvalue) throws Throwable {
		rejectedStrategiesSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button on Rejected Strategies grid view$")
	public void user_able_to_click_on_the_apply_button_on_rejected_strategies_grid_view() throws Throwable {
		rejectedStrategiesSortAndFilterPage.clickOnApplyFilterIconForRejectedStrategiesGridView();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on Rejected Strategies grid view$")
	public void user_should_able_to_verify_the_grid_count_on_rejected_strategies_grid_view() throws Throwable {
		System.out.println("Inside grid");
		// action.pause(5000);
		String countTabAfterFilter = rejectedStrategiesSortAndFilterPage
				.verifyTheRejectedStrategiesGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// RejectedStrategiesSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);
		System.out.println("tab tabCountAfterFilterCondition-" + tabCountAfterFilterCondition);
		String presentGridData = rejectedStrategiesSortAndFilterPage.verifyTheRejectedStrategiesGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		System.out
				.println("tab parseValueOfGridCountAfterFilterCondition-" + parseValueOfGridCountAfterFilterCondition);
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition / 10; i++) {
				// action.waitForDomToComplete(WebDriverManager.getDriver());
				hoApprovalSortAndFilterPage
						.waitForWebElement("//div[@class='ag-center-cols-container']/div[@role='row']["
								+ String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				myElement = hoApprovalSortAndFilterPage
						.findElementByDynamicXpath("//div[@class='ag-center-cols-container']/div[@role='row']["
								+ String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				action.moveToElement(myElement);
				action.pause(2000);
				String presentGridAllData = rejectedStrategiesSortAndFilterPage
						.verifyTheRejectedStrategiesGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
				System.out.println("Inside grid parseValueOfGridCountAfterFilterCondition-"
						+ parseValueOfGridCountAfterFilterCondition);
				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			pmpSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The grid view and tab count mismatch");}
	}

	@And("^User should able to verify the Tab count on Rejected Strategies grid view$")
	public void user_should_able_to_verify_the_tab_count_on_rejected_strategies_grid_view() throws Throwable {
		String countTabAfterFilter = rejectedStrategiesSortAndFilterPage
				.verifyTheRejectedStrategiesGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter =
		// RejectedStrategiesSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = rejectedStrategiesSortAndFilterPage.verifyTheRejectedStrategiesGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= beforeApplyFiltertabCountValue; i++) {
				action.scrollToBottom();
				Action.pause(1000);
				String presentGridAllData = rejectedStrategiesSortAndFilterPage
						.verifyTheRejectedStrategiesGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			pmpSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Assert.assertEquals(tabCountAfterFilterCondition, parseValueOfGridCountAfterFilterCondition,
				"The tab count and grid view count mismatch");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Reset Button on Rejected Strategies grid view$")
	public void user_able_to_click_on_the_reset_button_on_rejected_strategies_grid_view() throws Throwable {
		rejectedStrategiesSortAndFilterPage.clickOnApplyFilterIconForRejectedStrategiesGridViewForReset();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button on Rejected Strategies grid view$")
	public void user_able_to_click_on_the_cancel_button_on_rejected_strategies_grid_view() throws Throwable {
		rejectedStrategiesSortAndFilterPage.clickOnApplyFilterIconForRejectedStrategiesGridViewForCancel();
		Reporter.addScreenCapture();
	}

	@Then("^user validates the Rejected Strategies Print functionality for (.+)$")
	public void user_validates_the_rejected_strategies_print_functionality_for(String entityName) throws Throwable {
		PMPageGeneric.setCellDataSync(excelFilePath2, entityName, 1, 0,
				mutualFundsSortAndFilterPage2.getTextforBenchmarkDescription());
		int i = 2;
		while (i <= 6) {
			PMPageGeneric.setCellDataSync(excelFilePath2, entityName, 1, i - 1,
					mutualFundsSortAndFilterPage2.getTextfromGridforRow(String.valueOf(i)));
			i++;
		}
		mutualFundsSortAndFilterPage2.clickOnBenchmarkPrint();
		pmPageGeneric.verifyPrintFunctionalityForFirstEntity(excelFilePath2, entityName);
	}

}
