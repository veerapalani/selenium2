package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkFlyoutPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkReviewFlyoutPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerReviewFlyoutPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateStylePage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.framework.utils.Action;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.it.Date;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;
import qa.framework.webui.browsers.WebDriverManager;
public class CreateManagerReviewFlyoutStepDef {
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	List<String> listOfString;
	String value;
	WebElement myElement;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action;
	Alert alert;

	CreateManagerReviewFlyoutPage createreviewfly = new CreateManagerReviewFlyoutPage(
			"AD_PM_CreateManagerReviewFlyoutPage");
	
	@Then("^user should be able to see the following attributes on Create Manager Flyout Review page$")
    public void user_should_be_able_to_see_the_following_attributes_on_create_manager_flyout_review_page(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			createreviewfly.verifyElementsinCreateManagerflyoutReviewPage(
					createreviewfly.findElementByDynamicXpath("//small"));
			Reporter.addStepLog("able to see " + entity.get(i) + " header");
		}
		Reporter.addScreenCapture();
    }
	
	@Then("^user should be able to see the Manager Name as header in Review page on manager flyout$")
    public void user_should_be_able_to_see_the_manager_name_as_header_in_review_page_on_manager_flyout() throws Throwable {
		Assert.assertEquals("Manager Name", createreviewfly.getText());
        
        Reporter.addScreenCapture();
    }
	@And("^User clicks on Edit Link on Manager Flyout Review Page$")
    public void user_clicks_on_edit_link_on_manager_flyout_review_page() throws Throwable {
		createreviewfly.clickOneditlinkinreviewmanagerflyout();
    }
	@And("^User clicks on Done Button on Create Manager Flyout Review page$")
    public void user_clicks_on_done_button_on_create_manager_flyout_review_page() throws Throwable {
		createreviewfly.clickOnnextbuttoninreviewmanagerflyout();
    }
}
