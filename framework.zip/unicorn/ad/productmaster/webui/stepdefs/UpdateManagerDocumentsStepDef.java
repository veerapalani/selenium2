package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateManagerDocumentsPage;

public class UpdateManagerDocumentsStepDef {
	
	UpdateManagerDocumentsPage documentsPage = new UpdateManagerDocumentsPage("AD_PM_UpdateManagerDocumentsPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateManager.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String label, attributeValue, uiValue,dbValue,flowPageDataValue = null;
	WebElement myElement,myElement2;
	String myValue;
	
	@Then("^User should be able to see Documents Page in Update Manager Flow$")
    public void user_should_be_able_to_see_documents_page_in_update_manager_flow() {
        Assert.assertTrue(documentsPage.isUserOnDocumentsPage());
    }
	
	@And("^User clicks on Add Another Document Link button in Add Contacts page in Update Manager Flow$")
    public void user_clicks_on_add_another_document_link_button_in_add_contacts_page_in_update_manager_flow() {
        documentsPage.clickOnAddAnotherDocument();
    }
	
	@And("^User inputs the values from (.+) in Documents page in Update Manager Flow$")
    public void user_inputs_the_values_from_in_documents_page_in_update_manager_flow(String mandatorydetails) throws IOException {
    	if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
    	
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();

		String tName = Thread.currentThread().getName();
		String documentType,documentLink,documentComment,deleteDocuments = "";
		
		documentLink = RandomStringUtils.randomAlphanumeric(10);
		synchronized (tName) {
			
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			deleteDocuments = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 25);
			documentType = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 26);
			//documentLink = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 27);
			PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 27, documentLink);
			documentComment = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 28);
			
		}
		
		int documentsCount = documentsPage.getcountofDocuments();
		
		if(Integer.parseInt(deleteDocuments) > documentsCount) {
			Reporter.addStepLog("Contact Count in UI is less than the count given in Excel -- Deleting all contacts");
			
			for (int i = 0; i < documentsCount; i++) {
				documentsPage.deleteDocument();
				
			}
			
		}else {
			for (int i = 0; i < Integer.parseInt(deleteDocuments); i++) {
				documentsPage.deleteDocument();
				
			}
		}
		
		if(documentType != "" && documentLink != "" && documentComment != "") {
			documentsPage.clickOnAddAnotherDocument();
			if(documentType.contains(",") && documentLink.contains(",") && documentComment.contains(",")) {
				String[] docType = documentType.split(",");
				String[] docLink = documentLink.split(",");
				String[] docComment = documentComment.split(",");
				
				int docTypeSize = docType.length;
				int docLinkSize = docLink.length;
				int docCommentSize = docComment.length;
				int size = Math.min(docCommentSize, docLinkSize);
				size = Math.min(size, docTypeSize);
				int i =0;
				
					while(size > 0) {
						documentsPage.selectDocumentType(docType[i]);
						documentsPage.enterDocumentLink(docLink[i]);
						documentsPage.enterDocumentComment(docComment[i]);
						documentsPage.clickOnAddDocumentLinkButton();
						size--;
						i++;
						if(size > 0) {
						documentsPage.clickOnAddAnotherDocument();
						}
					}
				
		        
			}
			else {
			
				documentsPage.selectDocumentType(documentType);
				documentsPage.enterDocumentLink(documentLink);
				documentsPage.enterDocumentComment(documentComment);
				documentsPage.clickOnAddDocumentLinkButton();
			}
			
		
		}
		
    }
	
	@And("^User clicks on Next in Documents page in Update Manager Flow$")
    public void user_clicks_on_next_in_documents_page_in_update_manager_flow() {
        documentsPage.clickOnNext();
    }
	
	@And("^Data prepopulated in Documents page should match with DB Data in Update Manager flow for (.+)$")
    public void data_prepopulated_in_documents_page_should_match_with_db_data_in_update_manager_flow_for(String mandatorydetails) {

		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 26;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int dbDataRowIndex = rowIndex+1;
		   
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromDocumentsPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equalsIgnoreCase(attributeValue)) {
							
							
							
						}else {
							
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			//Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In View Strategy Details Page Values Stored in DB are Populated in UI");
			
    
    }

	private String getDataFromDocumentsPage(String data) {
			
		Action.pause(2000);
			ArrayList<ArrayList<String>> documents = new ArrayList<ArrayList<String>>();
			ArrayList<String> tempData = new ArrayList<String>();
			String requiredDocumentValue = "";
	    	int docCount = documentsPage.getcountofDocuments();
	    	
	    	int j=0;
	    	for (int i = 0; i < docCount; i++) {
	    		
				documents.add(documentsPage.getithDocumentInfo(i));
				
			}
	    	
	    	
	    	switch (data) {
			case "Document Type":
				j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = documents.get(j).get(0);
					tempData.add(requiredDocumentValue);
					j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			case "Document Link":
				j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = documents.get(j).get(1);
					tempData.add(requiredDocumentValue);
					j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			case "Document Comment":
				j = 0;
		    	for (ArrayList<String> arrayList : documents) {
		    		requiredDocumentValue = documents.get(j).get(2);
					tempData.add(requiredDocumentValue);
					j++;
				}
		    	if(documents.size() > 1) {
					Collections.sort(tempData);
					requiredDocumentValue = "";
					for (String G : tempData) {
						requiredDocumentValue = requiredDocumentValue+G+",";
					}
					requiredDocumentValue = requiredDocumentValue.substring(0, requiredDocumentValue.length()-1);
				}
				tempData.clear();
				uiValue = requiredDocumentValue;
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
	    	
	    	documents.clear();
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
		
	}
	
	@And("^data from Documents page should be stored in Excel for (.+) in Update Manager Flow$")
    public void data_from_documents_page_should_be_stored_in_excel_for_in_update_manager_flow(String mandatorydetails) throws IOException {
		
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(documentsPage.areDocumentsAvailableinUI()) {
			
			
			   int columnIndex = 26;
			   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			   int flowPageDataRowIndex = rowIndex+3;
			   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			   
			   if(label == "")
					label = "isEmpty";
				while (label != "isEmpty") {
											
						if(label.contains("ignore") || label.contains("NIVDP")) {
							columnIndex++;
							
				    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
				    			
				    			if(label == "")
				    				label = "isEmpty";
						}else {
							
							attributeValue = getDataFromDocumentsPage(label);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex, attributeValue);
									//PMPageGeneric.getCellDataSync(excelFilePath, sheetName, dbDataRowIndex, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 3).toString();
							
							columnIndex++;
								
								label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
										//(String) exlObj.getCellData(sheet, rownum, 0).toString();
								
								if(label == "")
									label = "isEmpty";
						
						}
				}
			}
    }
	
	

    @And("^User clicks on Previous button in Documents Page in Update Manager Flow$")
    public void user_clicks_on_previous_button_in_documents_page_in_update_manager_flow() throws Throwable {
        documentsPage.clickOnPrevious();
    }
    
    @Then("^Data populated in Documents page should match with data before moving to another page in Update Manager Flow for (.+)$")
    public void data_populated_in_documents_page_should_match_with_data_before_moving_to_another_page_in_update_manager_flow_for(String mandatorydetails) {
    	mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
			
		   //sheet = exlObj.getSheet(sheetName);
		   //count = 0;
		   int columnIndex = 26;
		   rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		   int flowPageDataRowIndex = rowIndex+3;
		   
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
						columnIndex++;
						
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromDocumentsPage(label);
						flowPageDataValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, flowPageDataRowIndex, columnIndex);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(flowPageDataValue.equalsIgnoreCase(attributeValue)) {
							
							
							
						}else {
							
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							Assert.fail(label);
							
						}
						columnIndex++;
							
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, columnIndex);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
    }
    
    @Then("^user should be able to see the attribute values match with DB values in the following dropdown in Documents Page in Update Manager flow$")
    public void user_should_be_able_to_see_the_attribute_values_match_with_db_values_in_the_following_dropdown_in_documents_page_in_update_manager_flow(List<String> dropdownNames) throws SQLException {
    	documentsPage.clickOnAddAnotherDocument();
    	
		String replacedata = "";
		String failedDropdowns = "";
		pmdb.DBConnectionStart();
		
		for (int i = 0; i < dropdownNames.size(); i++) {
			
			switch (dropdownNames.get(i)) {
			case "Type":
				replacedata = "DOCUMENT";
				break;
			default:
				break;
			}
			sheetName = "Query";
			

	    	String SQLquery, labelname = null;
	    	String dbDataIterator = "testNull";
	    	List<String> dbData = new ArrayList<String>();
	    	ResultSet rs;
	    	
	    	ArrayList<String> tempData = new ArrayList<String>();
	    	ArrayList<String> uiTempData = new ArrayList<String>();
	    	
	    	dbDataIterator = "testnull";
			SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 1, 1);
			labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 1, 2);
			
    		SQLquery = SQLquery.replace("@data", "'"+replacedata+"'");
    		rs= DBManager.executeSelectQuery(SQLquery);
    		
   
    		while(rs.next()) {
    			
    				dbDataIterator = rs.getString(labelname);
    				if(rs.wasNull() || dbDataIterator.isEmpty()) {
	    					dbDataIterator = "isEmpty";
	    			}
    				
    				tempData.add(dbDataIterator);
    				
    		 }
    		//to handle Zero records from DB 
    		if(dbDataIterator.equalsIgnoreCase("testnull")) {
    			dbDataIterator = "isEmpty";
    			tempData.add(dbDataIterator);
    		}
    		//to handle multiple values for same column
    		if(tempData.size() > 1) {
    			Collections.sort(tempData);
    		}
    		
			uiTempData = documentsPage.getDropdownValuesDisplayedInUI(dropdownNames.get(i));
			
			if(uiTempData.size() != tempData.size()) {
				failedDropdowns = failedDropdowns+dropdownNames.get(i)+",";
			}else {
				if(uiTempData.equals(tempData))
					Reporter.addStepLog("For Dropdown Label "+dropdownNames.get(i)+" DB values match with UI values displayed");
				else {
					failedDropdowns = failedDropdowns+dropdownNames.get(i)+",";
				}
			}
			
			tempData.clear();
			uiTempData.clear();
		}
		
		if(failedDropdowns.length() > 0) {
			Assert.fail("For Labels "+failedDropdowns+" Dropdown values in UI do not match with DB");
		}
		
		pmdb.DBConnectionClose();
    }
    
    @And("^User clicks Back Link in Documents Page in Update Manager Flow$")
    public void user_clicks_back_link_in_documents_page_in_update_manager_flow() {
        documentsPage.clickOnBackLink();
    }
    
    @Then("^Document fields value should be blank in Documents page in Update Manager flow$")
    public void document_fields_value_should_be_blank_in_documents_page_in_update_manager_flow() {
        String type = documentsPage.getDocumentTypeValueinEditPage();
        String link = documentsPage.getDocumentLinkValueinEditPage();
        String comment = documentsPage.getDocumentCommentValueinEditPage();
        
        Assert.assertTrue(type.isEmpty());
        Assert.assertTrue(link.isEmpty());
        Assert.assertTrue(comment.isEmpty());
    }

    @And("^User inputs the test data into document fields in Documents page in Update Manager flow$")
    public void user_inputs_the_test_data_into_document_fields_in_documents_page_in_update_manager_flow() {
    	documentsPage.selectDocumentType("Series 7");
		documentsPage.enterDocumentLink("Test Link");
		documentsPage.enterDocumentComment("Test Comment");
		
		
		
    }

    @And("^User clicks on Reset button in Documents page in Update Manager flow$")
    public void user_clicks_on_reset_button_in_documents_page_in_update_manager_flow() {
        documentsPage.clickOnReset();
    }
    
    @Then("^User should be able to see (.+) displayed in UI for Update Manager flow$")
    public void user_should_be_able_to_see_displayed_in_ui_for_update_manager_flow(String errormessage) {
    	assertTrue(documentsPage.error(errormessage));
    }
    
    @And("^User clicks on Add Document Link button in Documents Page in Update Manager Flow$")
    public void user_clicks_on_add_document_link_button_in_documents_page_in_update_manager_flow() {
        documentsPage.clickOnAddDocumentLinkButton();
    }
    
    

}
