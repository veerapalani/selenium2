package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.ibm.db2.jcc.a.a;
import com.ibm.db2.jcc.a.i;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.StrategyDetailPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFATeamUIPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateFAViewPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategySMADualUIPage;
import org.openqa.selenium.support.ui.Select;
import qa.unicorn.ad.productmaster.webui.pages.CreateFATeamPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import java.util.HashMap;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import qa.framework.dbutils.DBManager;

public class UpdateFATeamStepDef {
	String pageURL = SSOLoginPage.URL + "#/faTeam/view/";
	String pageURL2 = SSOLoginPage.URL + "#/faTeam/edit/";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFATeam.xlsx";
	String sheetName = "";
	String myValue;
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	WebElement myElement;
	List<WebElement> myElements;
	int num;
	PMPageGeneric CreateStyleFlyout = new PMPageGeneric("AD_PM_CreateStyleFlyout");
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategySMADualUIPage"));
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	UpdateFATeamUIPage updateFATeamPage = new UpdateFATeamUIPage();
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	StrategyDetailPage strDtl = new StrategyDetailPage();
	SoftAssert sftAst = new SoftAssert();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	HashMap<String, Object> row = new HashMap<String, Object>();
	String faCode = null;
	String faTeamName = null;
	CreateFATeamPage createobj = new CreateFATeamPage("AD_PM_CreateEnterFAPage");
	UpdateFAViewPage updateFaPage = new UpdateFAViewPage("AD_PM_UpdateFAViewPage");
	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");

	@When("^User search with the \"([^\"]*)\" taken from \"([^\"]*)\" in the Search TextBox on landing page while FATeam updation$")
	public void user_search_with_the_something_taken_from_something_in_the_search_textbox_on_landing_page_while_fateam_updation(
			String strArg1, String strArg2) throws Throwable {
		sheetName = strArg2;
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, strArg1);
		myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"brml-search-input\")");
		myElement.click();
		action.sendkeysClipboard(myElement, myValue);
		Thread.sleep(2000);
		int i = 0;
		while(i < 5) {
			myElement.sendKeys(Keys.ENTER);
			i++;
		}
		Thread.sleep(2000);
	}

	@And("^User clicks on the first element of FATeam Searches on the suggestion box on landing page while FATeam updation$")
	public void user_clicks_on_the_first_element_of_fateam_searches_on_the_suggestion_box_on_landing_page_while_fateam_updation()
			throws Throwable {
		updateFATeamPage.waitForWebElement("(//p[@class='body-3 text-tertiary'])[1]");
		myElement = updateFATeamPage.findElementByDynamicXpath("(//p[@class='body-3 text-tertiary'])[1]");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("clicked on first suggestion ");
	}

	@Then("^User should be taken to FATeam Details page with the CONTINUE EDITING option should visible$")
	public void user_should_be_taken_to_fateam_details_page_with_the_continue_editing_option_should_visible()
			throws Throwable {
		action.waitForPageLoad();
		Thread.sleep(2000);
		sftAst.assertTrue(action.getCurrentURL().contains(pageURL), "We are in ViewFATeamUIPage");
		Reporter.addStepLog("We are in ViewFATeamUIPage");
		Reporter.addScreenCapture();
		//myElement = action.getElement("Continue_Button_on_View_Strategy_Details");
		myElement = updateFATeamPage.findElementByDynamicXpath("//brml-button[contains(text(),'CONTINUE EDITING')]");
		sftAst.assertTrue(myElement.isDisplayed(), "Continue Edit Button is displayed");
		Reporter.addStepLog("Continue Edit Button is displayed");
	}

	@And("^User clicks on the CONTINUE EDITING Button on FATeam Details page$")
	public void user_clicks_on_the_continue_editing_button_on_fateam_details_page() throws Throwable {
		myElement = updateFATeamPage.findElementByDynamicXpath("//brml-button[contains(text(),'CONTINUE EDITING')]");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("Clicked on Continue Editing Button");
		Thread.sleep(3000);
	}

	@Then("^User should be taken to Enter FA Team Details page of update flow$")
	public void user_should_be_taken_to_enter_fa_team_details_page_of_update_flow() throws Throwable {
		action.waitForPageLoad();
		sftAst.assertTrue(action.getCurrentURL().contains(pageURL2), "We are in Enter FATeam Details page");
		Reporter.addStepLog("We are in FATeam Details page");
		Reporter.addScreenCapture();
	}

	@And("^Edit all the below drop down fields with valid data for FA Team$")
	public void edit_all_the_below_drop_down_fields_with_valid_data_for_fa_team(List<List<String>> attribute)
			throws Throwable {
		/*
		 * myElement=(WebElement) action.
		 * executeJavaScript("return document.querySelector('brml-select[id=\"faDiscretionaryProgramName\"]').shadowRoot.querySelector('wf-dropdown')"
		 * ); action.scrollToElement(myElement); action.click(myElement);
		 * myElement=(WebElement) action.
		 * executeJavaScript("return document.querySelector('brml-select[id=\"faDiscretionaryProgramName\"]').shadowRoot.querySelector('wf-dropdown').querySelector('li[data-value=\"0\"]').querySelector('a')"
		 * ); action.scrollToElement(myElement);
		 * System.out.println(myElement.getText()); action.click(myElement);
		 * Thread.sleep(3000);
		 * 
		 * myElement=(WebElement) action.
		 * executeJavaScript("return document.querySelector('brml-select[id=\"faDiscretionaryProgramName\"]').shadowRoot.querySelector('wf-dropdown').querySelector('li')"
		 * );
		 * 
		 * Select sc = new Select(myElement); sc.getOptions();
		 */
		sheetName = "Valid";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\'brml-select[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Thread.sleep(2000);
			myElement = (WebElement)action
					.executeJavaScript("return document.querySelector(\'brml-select[id=\"" + attribute.get(i).get(1)
							+ "\"]').shadowRoot.querySelector(\"li[data-value=\'" + myValue + "\']\")");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			Reporter.addStepLog("Drop down value selected for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^Edit all the below input fields with valid data for FA Team$")
	public void edit_all_the_below_input_fields_with_valid_data_for_fa_team(List<List<String>> attribute)
			throws Throwable {
		sheetName = "Valid";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\'brml-input[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('input')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^Edit all the below text fields with valid data for FA Team$")
	public void edit_all_the_below_text_fields_with_valid_data_for_fa_team(List<List<String>> attribute)
			throws Throwable {
		sheetName = "Valid";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(2000);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
			System.out.println(attribute.get(i).get(0));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\'brml-textarea[id=\""
					+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('textarea')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.clear(myElement);
			action.sendkeysClipboard(myElement, myValue);
			Reporter.addStepLog(myValue + " sent for " + attribute.get(i).get(0));
			Thread.sleep(2000);
		}
	}

	@And("^User clicks the Next Button of FA Team$")
	public void user_clicks_the_next_button_of_fa_team() throws Throwable {
		myElement = (WebElement)action
				.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
		Reporter.addStepLog("Clicked on Next button");
		Thread.sleep(2000);
	}

	@And("^User should be able to see the below header on Update FATeam page$")
	public void user_should_be_able_to_see_the_below_header_on_update_fateam_page(String attribute) throws Throwable {
		myElement = updateFATeamPage.findElementByDynamicXpath("//h4[contains(text(),'" + attribute + "')]");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(2000);
		sftAst.assertTrue(myElement.isDisplayed(), attribute + " header is displayed");
		Reporter.addStepLog(attribute + " header is displayed");
	}

	@Then("^Check if all the edits made to the input and text feilds are reflected on Review page of FATeam$")
	public void check_if_all_the_edits_made_to_the_input_and_text_feilds_are_reflected_on_review_page_of_fateam(
			List<String> attribute) throws Throwable {
		sheetName = "Valid";
		sheet = exlObj.getSheet(sheetName);
		Thread.sleep(500);
		for(int i = 0; i < attribute.size(); i++) {
			rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
			cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
			myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
			myElement = updateFATeamPage.findElementByDynamicXpath("//div[contains(text(),'" + myValue + "')]");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			sftAst.assertTrue(myElement.isDisplayed(), " " + myValue + "is displayed");
			Reporter.addStepLog(myValue + " is displayed for " + attribute.get(i));
			Thread.sleep(500);
		}
	}

	@Then("^Check if all the edits made to the drop down feilds are reflected on Review page of FATeam$")
	public void check_if_all_the_edits_made_to_the_drop_down_feilds_are_reflected_on_review_page_of_fateam(
			List<List<String>> attribute) throws Throwable {
		Thread.sleep(500);
		Reporter.addScreenCapture();
		for(int i = 0; i < attribute.size(); i++) {
			myValue = attribute.get(i).get(1);
			myElement = updateFATeamPage.findElementByDynamicXpath("//div[contains(text(),'" + myValue + "')]");
			sftAst.assertTrue(myElement.isDisplayed(), " " + myValue + "is displayed");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			Reporter.addStepLog(myValue + " is displayed for " + attribute.get(i).get(0));
			Thread.sleep(500);
		}
	}

	@And("^User should be able to see the Confirmation Message on Confirmation page of FATeam$")
	public void user_should_be_able_to_see_the_confirmation_message_on_confirmation_page_of_fateam() throws Throwable {
		myElement = updateFATeamPage
				.findElementByDynamicXpath("//h4[contains(text(),'Your FA Team has been updated')]");
		sftAst.assertTrue(myElement.isDisplayed(), " Confirmation Message is displayed");
		Reporter.addStepLog(" Confirmation Message is displayed");
	}

	@And("^User clicks on the \"([^\"]*)\" button on the suggestion popup on landing page while FATeam updation$")
	public void user_clicks_on_the_something_button_on_the_suggestion_popup_on_landing_page_while_fateam_updation(
			String strArg1) throws Throwable {
		Thread.sleep(2000);
		updateFATeamPage.waitForWebElement("//h6[contains(text(),'Results')]");
		myElement = updateFATeamPage.findElementByDynamicXpath("//brml-button[@id='all-result-button']");
		myElement.click();
	}

	@Then("^User is able to see search results in \"([^\"]*)\" tab under FA accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_fa_accordion(String strArg1)
			throws Throwable {
		myElement = updateFATeamPage.findElementByDynamicXpath("//brml-tab-button[@tab=\"All\"]");
		Thread.sleep(2000);
		myElement = (WebElement)action.executeJavaScript(
				"return document.querySelector(\"brml-expansion-panel[panel-id='FINANCIALADVISORTEAM']\")");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(3000);
		String status = (String)action.executeJavaScript(
				"return document.querySelector(\"brml-expansion-panel[panel-id='FINANCIALADVISORTEAM']\").getAttribute(\"expanded\")");
		if(status.equalsIgnoreCase("true")) {
			myElement = (WebElement)action.executeJavaScript(
					"return document.querySelector(\"brml-expansion-panel[panel-id='FINANCIALADVISORTEAM']\")");
			myElement.click();
		}
		sheetName = "Strategy";
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "StrategyCode");
		myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		myElement = updateFATeamPage.findElementByDynamicXpath("//span[contains(text(),\'" + myValue + "\')]");
		sftAst.assertTrue(myElement.isDisplayed(), myValue + " is displayed in ALL tab");
		Reporter.addStepLog(myValue + " is displayed in ALL tab");
	}

	@And("^User clicks on FATeam tab on landing page$")
	public void user_clicks_on_fateam_tab_on_landing_page() throws Throwable {
		myElement = updateFATeamPage.findElementByDynamicXpath("//brml-tab-button[@tab=\"faTeam\"]");
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("FATeam tab is cicked");
	}

	@Then("^User is able to see FAs in FATeam tab$")
	public void user_is_able_to_see_fas_in_fateam_tab() throws Throwable {
		action.waitForPageLoad();
		sheetName = "Strategy";
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "StrategyCode");
		myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
		myElement = updateFATeamPage.findElementByDynamicXpath("//span[contains(text(),\'" + myValue + "\')]");
		sftAst.assertTrue(myElement.isDisplayed(), myValue + " is displayed in FATeam tab");
		Reporter.addStepLog(myValue + " is displayed in FATeam tab");
		Thread.sleep(2000);
	}

	@And("^User clicks on the ellipsis icon on FATeam tab$")
	public void user_clicks_on_the_ellipsis_icon_on_fateam_tab() throws Throwable {
		myElement = (WebElement)action.executeJavaScript(
				"return document.querySelector(\"brml-action-menu > brml-active-icon\").shadowRoot.querySelector(\"#Layer_1 > path:nth-child(4)\")");
		action.highligthElement(myElement);
		Thread.sleep(2000);
		myElement.click();
		Reporter.addStepLog("Clicked on ellipsis icon");
	}

	@Then("^User clicks on the ViewEdit Details link$")
	public void user_clicks_on_the_viewedit_details_link() throws Throwable {
		Thread.sleep(2000);
		myElement = (WebElement)action.executeJavaScript(
				"return document.querySelector(\"brml-action-menu\").shadowRoot.querySelector(\"span\")");
		action.highligthElement(myElement);
		Thread.sleep(1000);
		myElement.click();
		Reporter.addStepLog("Clicked on View/Edit Details link");
	}

	@And("^User able to get the all data from a Conversion Sql query from database$")
	public void user_able_to_get_the_all_data_from_conversion_sql_query_from_database() throws Throwable {
		//  throw new PendingException();
		System.out.println("my method start here");
		pmdb.DBConnectionStart();
		sheet = exlObj.getSheet("Sql");
		ResultSet rs;
		String SQLquery = (String)exlObj.getCellData(sheet, 0, 0);
		System.out.println("Sql Query--->" + SQLquery);
		rs = DBManager.executeSelectQuery(SQLquery);
		ResultSetMetaData md = rs.getMetaData();
		int columns = md.getColumnCount();
		System.out.println("Total col count----" + columns);
		while(rs.next()) {
			for(int i = 1; i <= columns; i++) {
				row.put(md.getColumnName(i), rs.getObject(i));
				if(md.getColumnName(i).trim().equalsIgnoreCase("fa_team_name")) {
					faTeamName = (String)rs.getObject(i);
					System.out.println("FA Code from DB " + faTeamName);
				}
			}
		}
		row.entrySet().stream().forEach(S -> System.out.println(S));
		exlObj.closeWorkBook();
		pmdb.DBConnectionClose();
	}

	@When("^User enter the FA team name in global search$")
	public void user_enter_the_FA_team_name_in_global_search() throws Throwable {
		Action.pause(1000);
		updateFATeamPage.searchFATeamName(faTeamName);
		;
	}

	@Then("^user is able to see search results for FA team in flyout$")
	public void user_is_able_to_see_search_results_for_fa_in_flyout() throws Throwable {
		System.out.println("Then user is able to see search results for FA team in flyout - ");
	}

	@When("^user click on \"([^\"]*)\" on landing page$")
	public void user_clicks_on_something_on_landing_page(String strArg1) throws Throwable {
		updateFATeamPage.clickOnSeeAllResults();
	}

	@Then("^user is able to navigate to view details page of FA team$")
	public void user_is_able_to_navigate_to_view_details_page_of_fa_team(List<String> entity) throws Throwable {
		System.out.println("method user_is_able_to_navigate_to_view_details_page_of_fa is working ");
		for(int i = 0; i < entity.size(); i++) {
			updateFATeamPage.verifyElementsOnViewFAage(
					updateFATeamPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^user is able to see below buttons on upper right side of screen$")
	public void user_is_able_to_see_below_button_on_upper_right_side_of_screen(List<String> entity) throws Throwable {
		for(int i = 0; i < entity.size(); i++) {
			updateFATeamPage.verifyContinueEditingAndCancelButtonsOnViewFAage(
					updateFATeamPage.findElementByDynamicXpath("//span[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@When("^user clicks on \"([^\"]*)\" icons on FATeam tab$")
	public void user_clicks_on_something_icon(String strArg1) throws Throwable {
		updateFATeamPage.clickOnContinueEditingLink();
	}

	@Then("^user is able to navigate to Edit details screen for FA team$")
	public void user_is_able_to_navigate_to_edit_details_screen_for_fa_team(List<String> entity) throws Throwable {
		for(int i = 0; i < entity.size(); i++) {
			updateFATeamPage.verifyEditFATeamPaage(
					updateFATeamPage.findElementByDynamicXpath("//*[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User clicks on Next Button on the Create FA Team Update Page$")
	public void user_clicks_on_next_button_on_the_create_fa_update_page() throws Throwable {
		createobj.clickOnNextButtonOnFATeamPage();
	}

	@And("^User Clicks on Next in Documents deatils FA Team Update$")
	public void user_clicks_on_next_in_documents_deatils_fa_update() throws Throwable {
		createobj.clickOnNextButtonOnFATeamPage();
	}

	@When("^User enter valid (.+) in global search box in FA Team$")
	public void user_enter_valid_in_global_search_box_in_fa_team(String mandatoryDetails) throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFATeam.xlsx";
		String sheetName = "";
		if(mandatoryDetails.contains("Valid")) {
			sheetName = "Valid";
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatoryDetails);
			faTeamName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
			System.out.println("fa team name: "+faTeamName);
		}
		if(faTeamName != "") {
			landingPage.enterSearchToken(faTeamName);
			landingPage.clickOnSearchIcon();
		}
	}

	@And("^User is able to see FATeams in FATeam tab$")
	public void user_is_able_to_see_faTeams_in_fa_tab() throws Throwable {
		updateFaPage.verifyFATeamTab();
	}
	
	@Then("^user clicks on FATeam tab on landing page$")
	public void user_clicks_on_FATeam_tab_on_landing_page() throws Throwable {
		updateFaPage.clickOnFATeamTab();
	}
	@And("^user is able to view the FA team name as shown in grid with (.+)$")
	public void user_is_able_to_view_the_FA_team_name_as_shown_in_grid(String manadatorydetails) throws Throwable {
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateFATeam.xlsx";
		String sheetName = "";
		if(manadatorydetails.contains("Valid")) {
			sheetName = "Valid";
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, manadatorydetails);
			faTeamName = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
		}
		System.out.println(updateFaPage.getFateamName());
		System.out.println(faTeamName);
		Assert.assertTrue(updateFaPage.getFateamName().equals(faTeamName));
	}
}
