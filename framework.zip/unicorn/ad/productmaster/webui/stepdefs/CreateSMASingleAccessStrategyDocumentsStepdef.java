package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.unicorn.ad.productmaster.webui.pages.CreateSMASingleAccessStrategyDocumentsPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreateSMASingleAccessStrategyDocumentsStepdef {

	CreateSMASingleAccessStrategyDocumentsPage documentsPage = new CreateSMASingleAccessStrategyDocumentsPage("AD_PM_CreateSMASingleAccessStrategyDocumentsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	
	@When("User Clicks on Next in Documents page")
	public void user_Clicks_on_Next_in_Documents_page() {
		documentsPage.clickOnNext();
	}
	@And("^User inputs (.+) in Documents Page$")
    public void user_inputs_in_documents_page(String mandatorydetails) throws IOException {
		
		documentsPage.isUserOnDocumentsPage();
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}

		
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			mandatorydetails = mandatorydetails+"_dev";
		}
		if(environment.equalsIgnoreCase("qa")) {
			mandatorydetails = mandatorydetails+"_qa";
		}
		if(environment.equalsIgnoreCase("uat")) {
			mandatorydetails = mandatorydetails+"_uat";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		
		String documentType = (String) exlObj.getCellData(sheet, rowIndex, 75);
		String documentLink = (String) exlObj.getCellData(sheet, rowIndex, 76);
		String documentComment = (String) exlObj.getCellData(sheet, rowIndex, 77);
		exlObj.closeWorkBook();
		
		
		
		if(documentType != "" && documentLink != "" && documentComment != "") {
			
			if(documentType.contains(",") && documentLink.contains(",") && documentComment.contains(",")) {
				String[] docType = documentType.split(",");
				String[] docLink = documentLink.split(",");
				String[] docComment = documentComment.split(",");
				
				int docTypeSize = docType.length;
				int docLinkSize = docLink.length;
				int docCommentSize = docComment.length;
				int size = Math.min(docCommentSize, docLinkSize);
				size = Math.min(size, docTypeSize);
				int i =0;
				
					while(size > 0) {
						
						documentsPage.selectDocumentType(docType[i]);
						documentsPage.enterDocumentLink(docLink[i]);
						documentsPage.enterDocumentComment(docComment[i]);
						documentsPage.clickOnAddDocumentLinkButton();
						size--;
						i++;
						if(size > 0) {
							documentsPage.isUserOnDocumentsPage();
							documentsPage.clickOnAddAnotherDocument();
						}
					}
				
		        
			}
			else {
			
				documentsPage.selectDocumentType(documentType);
				documentsPage.enterDocumentLink(documentLink);
				documentsPage.enterDocumentComment(documentComment);
				documentsPage.clickOnAddDocumentLinkButton();
			}
			
		
		}
		
    }
}
