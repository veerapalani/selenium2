package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import qa.framework.utils.Reporter;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class UIStrategyEntityStepDef {
	PMPageGeneric StrategyEntity=new PMPageGeneric("AD_PM_StrategyEntityPage");
	String activeLink = "Strategy";
	String pageURL = "http://10.49.116.4:8080/pmui/?#/strategy";	
	String expectedColorCode,xpath;
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	List<WebElement> listOfElements2 = new ArrayList<WebElement>();
	Action action =  new Action(SQLDriver.getEleObjData("AD_PM_StrategyEntityPage"));
    @Then("^Strategy Link should be active$")
    public void Strategy_link_should_be_something() throws Throwable {
        StrategyEntity.verifyAttribute("true", activeLink, "selected");
    }
    
    @Then("^\"([^\"]*)\" should be active on Strategy Entity page$")
    public void something_should_be_active_on_strategy_entity_page(String strArg1) throws Throwable {
        
    }
    
    @Then("^User should be able to see \"([^\"]*)\" in \"([^\"]*)\" on Strategy Entity page$")
    public void user_should_be_able_to_see_something_on_Strategy_Entity_page(String list1, String key) throws Throwable {
    	String[] listArray = list1.split(", ");
    	listOfElements =  StrategyEntity.getElements(key);
    	for(int i=0;i<listArray.length;i++) {
    		StrategyEntity.verifyTextInListOfElements(listArray[i], listOfElements);
    		Reporter.addStepLog(listArray[i]+" is displaying in " + key);
    	}
    }

    @And("^Order of the \"([^\"]*)\" should be \"([^\"]*)\" on Strategy Entity page$")
    public void order_of_the_something_should_be_something_on_Strategy_Entity_page(String key, String list1) throws Throwable {
    	String[] listArray = list1.split(", ");
     	listOfElements =  StrategyEntity.getElements(key);
     	for(int i=0;i<listArray.length;i++) {
     		Assert.assertEquals( listOfElements.get(i).getText(),listArray[i]);
     		Reporter.addStepLog(listOfElements.get(i).getText()+" is the "+i+" element in " + key);
     	}
    }

    @And("^All the \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Strategy Entity page$")
    public void all_the_something_should_be_displayed_in_something_color_on_Strategy_Entity_page(String key, String color) throws Throwable {
        listOfElements = StrategyEntity.getElements(key);
        expectedColorCode = Action.getTestData(color);
        for(int i=0;i<listOfElements.size();i++) {
        	StrategyEntity.verifyColor(listOfElements.get(i), expectedColorCode);
        }
        
        
    }
    @Then("^User should be able to see \"([^\"]*)\" in every row of \"([^\"]*)\" on Strategy Entity page$")
    public void user_should_be_able_to_see_something_in_every_row_of_something_on_Strategy_Entity(String insideElementKey, String key) throws Throwable {
        listOfElements = StrategyEntity.getElements(key);        
        for(int i=1;i<=Math.min(listOfElements.size(),10);i++) {
        	xpath="//tr[@class='divider divider-top divider-03 divider-color-03']["+i+"]//wf-icon[@name='ellipsis-v-solid']";
        	StrategyEntity.verifyElement(StrategyEntity.findElementByDynamicXpath(xpath));
        	Reporter.addStepLog("verified "+insideElementKey+ " for element no "+(i));
        	StrategyEntity.scrollByPixel(100);
        }
    }
    
    @Then("^User should be able to see the Following \"([^\"]*)\" while \"([^\\\"]*)\" on the Ellipse Icon in every row of \"([^\"]*)\" on Strategy Entity page$")
    public void user_should_be_able_to_see_the_following_something_while_hovering_on_the_something_in_every_row_of_something_on_strategy_entity_page(String options, String insideElementKey, String strArg2) throws Throwable {
    	Thread.sleep(3000);
    			StrategyEntity.hoverOnElement(StrategyEntity.getElementFromShadowRoot(insideElementKey));
    			Thread.sleep(1000);
    			StrategyEntity.verifyElement(options);
    			Reporter.addStepLog("verified "+options+ " for element");
    			StrategyEntity.scrollByPixel(100);  
//    	    	String threedotHovering = "return document.querySelector('body > wf-bridge > product-master > div > div > section > table > tbody > tr:nth-child(1) > td:nth-child(2) > button > wf-icon').shadowRoot.querySelector('div > svg')";
//    	    	   WebElement elethreedotHovering = (WebElement) action.executeJavaScript(threedotHovering);
//    	    			  Thread.sleep(1000);
//    	    			   Assert.assertTrue(elethreedotHovering.isDisplayed());
//    	    	   Actions actElement = new Actions(WebDriverManager.getDriver());
//    	    	    actElement.moveToElement(elethreedotHovering).build().perform();
//    	    	    StrategyEntity.verifyElement(options);
//    	    	    Reporter.addStepLog("verified "+options+ " for element");
//    	    	    Thread.sleep(1000);
    	}	
       
    

    @And("^the \"([^\"]*)\" should contain the following options on Strategy Entity page$")
    public void the_something_should_contain_on_Strategy_Entity_page( String key, List<String> options) throws Throwable {
        listOfElements = StrategyEntity.getElements(key);
        for (int i = 0; i < listOfElements.size(); i++) {
        	for (int j=0;j<options.size();j++)
			StrategyEntity.verifyInsideElement(listOfElements.get(i),options.get(j));
        	
		}
    }
    @Then("^User should be able to see the \"([^\"]*)\" header on Strategy Entity page$")
    public void user_should_be_able_to_see_the_something_header_on_strategy_entity_page(String key) throws Throwable {
        StrategyEntity.verifyHeader(key);
    }
    @Then("^User should be able to see the \"([^\"]*)\" at the \"([^\"]*)\" on Strategy Entity page$")
    public void user_should_be_able_to_see_the_something_at_the_something_on_Strategy_entity_page(String key, String shadowRootKey) throws Throwable {
    	StrategyEntity.verifyElement(StrategyEntity.fetchElementFromShadowRoot(key, shadowRootKey));
    }

    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Strategy Entity page$")
    public void something_should_be_displayed_in_something_color_on_Strategy_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	StrategyEntity.verifyColor(key,expectedColorCode);
    	
    }
    @And("^\"([^\"]*)\" should be displayed in \"([^\"]*)\" color inside Strategy Entity page$")
    public void something_should_be_displayed_in_something_color_inside_strategy_entity_page(String key, String color) throws Throwable {
    	String expectedColorCode = Action.getTestData(color);
    	StrategyEntity.verifyColor(StrategyEntity.getElementFromShadowRoot(key),expectedColorCode);
    }
    @And("^\"([^\"]*)\" should have \"([^\"]*)\" background color on Strategy Entity page$")
    public void something_should_have_something_background_color_on_Strategy_entity_page(String key, String backgroundColor) throws Throwable {
    	expectedColorCode = Action.getTestData(backgroundColor);
    	StrategyEntity.verifyBackgroundColor(key,expectedColorCode);
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" on Strategy Entity page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_on_Strategy_entity_page(String ghostText, String searchBox) throws Throwable {
    	StrategyEntity.verifyGhostText(ghostText, searchBox);
    }

    @And("^User should be able to see the \"([^\"]*)\" on Strategy Entity page$")
    public void user_should_be_able_to_see_the_something_on_Strategy_entity_page(String key) throws Throwable {
    	StrategyEntity.verifyElement(key);
    }

    @Then("^User should be able to see the \"([^\"]*)\" inside Strategy Entity page$")
    public void user_should_be_able_to_see_the_something_inside_strategy_entity_page(String key) throws Throwable {
        //for shadowroot only
    	StrategyEntity.verifyElementFromShadowRoot(key);
    }

    @And("^User should be able to see the \"([^\"]*)\" ghost text in \"([^\"]*)\" inside Strategy Entity page$")
    public void user_should_be_able_to_see_the_something_ghost_text_in_something_inside_strategy_entity_page(String ghostText, String searchBox) throws Throwable {
        // for shadowroot only
    	StrategyEntity.verifyGhostText(ghostText, StrategyEntity.getElementFromShadowRoot(searchBox));
    }

    @And("^That \"([^\"]*)\" should be displayed in \"([^\"]*)\" color on Strategy Entity page$")
    public void that_something_should_be_displayed_in_something_color_on_Strategy_entity_page(String key, String expectedColor) throws Throwable {
    	expectedColorCode = Action.getTestData(expectedColor);
    	StrategyEntity.verifyCurrentElementColor(expectedColorCode);
    }
    @And("^On clicking on \"([^\"]*)\" The \"([^\"]*)\" on the Strategy Entity page should contain all the following options$")
    public void on_clicking_on_something_the_something_on_the_strategy_entity_page_should_contain_all_the_following_options(String clickKey, String key,List<String> items) throws Throwable {
    	StrategyEntity.clickOnLink(clickKey);
        for(int i=0;i<items.size();i++) {
   		 Reporter.addStepLog("verifying for "+items.get(i));
   		 listOfElements = StrategyEntity.getElementsFromShadowRoot(key);
   		 Reporter.addStepLog(listOfElements.get(0).getText());
   	 StrategyEntity.verifyTextInListOfElements( items.get(i),listOfElements);  
        }
    }
    
    @And("^user hover over the \"([^\"]*)\" of first element of \"([^\"]*)\" on Strategy Entity page$")
    public void user_hover_over_the_something_of_first_element_of_something_on_strategy_entity_page(String insideElementKey, String parentElementKey) throws Throwable {
    	listOfElements = StrategyEntity.getElements(insideElementKey);
    			StrategyEntity.hoverOnElement(listOfElements.get(0));
    	Reporter.addStepLog(listOfElements.get(1).getText());
    			Reporter.addStepLog("hovering on "+insideElementKey);
    		
    }
    
    @And("^user hover over the \"([^\"]*)\" of valid element of \"([^\"]*)\" and click on \"([^\"]*)\" on Strategy Entity page$")
    public void user_hover_over_the_something_of_valid_element_of_something_and_click_on_something_on_strategy_entity_page(String insideElementKey, String parentElementKey, String clickOnElement) throws Throwable {
    	listOfElements = StrategyEntity.getElements(insideElementKey);
    	listOfElements2 = StrategyEntity.getElements(clickOnElement);
    	String programCode,styleCode,managerCode;
    	for(int i=1;i<=listOfElements.size();i++) {
    		xpath= "//tr[@class='divider divider-top divider-03 divider-color-03']["+i+"]/td";
    	 programCode=StrategyEntity.findElementByDynamicXpath(xpath+"[5]").getText();
    	 styleCode = StrategyEntity.findElementByDynamicXpath(xpath+"[6]").getText();
    	 managerCode = StrategyEntity.findElementByDynamicXpath(xpath+"[7]").getText();
    	 Reporter.addStepLog("programCode is "+programCode+" styleCode is "+styleCode+" managerCode is "+managerCode);
    		if((programCode.length()>0)&&(styleCode.length()>0)&&(managerCode.length()>0)) {
    			StrategyEntity.hoverOnElement(listOfElements.get(i-1));
    			Reporter.addStepLog("hovering on "+insideElementKey);
    			StrategyEntity.clickOnLink(listOfElements2.get(i-1));
    			Reporter.addStepLog("clicking on "+clickOnElement);
    			break;
    		}
    	}
    }
    
    @And("^user clicks the \"([^\"]*)\" on Strategy Entity page$")
    public void user_clicks_the_something_on_strategy_entity_page(String key) throws Throwable {
        StrategyEntity.clickOnLink(key);
    }
    @Then("^user should be able to go to Strategy Entity page$")
    public void user_should_be_able_to_go_to_strategy_entity_page() throws Throwable {
        Thread.sleep(2000);
    	StrategyEntity.verifyPageURL(pageURL);
    }
    
    
    @Then("^User should be able to see only \"([^\"]*)\" \"([^\"]*)\" on Strategy Entity Page$")
    public void user_should_be_able_to_see_only_something_something_on_program_entity_page(String numberOfItems, String key) throws Throwable {
        listOfElements = StrategyEntity.getElements(key);
        Assert.assertEquals( listOfElements.size(),Integer.parseInt(numberOfItems));
        Reporter.addStepLog("verified that "+numberOfItems+" "+key+" present");
    }
    @Then("^\"([^\"]*)\" should not be displayed in \"([^\"]*)\" on Strategy Entity Page$")
    public void something_should_not_be_displayed_in_something_on_program_entity_page(String item, String key) throws Throwable {
    	listOfElements = StrategyEntity.getElements(key);
    	StrategyEntity.verifyTextNotPresentInListOfElements(item, listOfElements);
        Reporter.addStepLog("verified that "+item+" is not present in "+key);
    }

}
