package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessStrategyProxyDetailsPage;

public class UpdateSMASingleAccessStrategyProxyDetailsStepDef {

	UpdateSMASingleAccessStrategyProxyDetailsPage proxyDetailsPage = new UpdateSMASingleAccessStrategyProxyDetailsPage("AD_PM_UpdateSMASingleAccessStrategyProxyDetailsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName;
	String label, attributeValue, uiValue, dbValue = null;
	
	public static int count;
	
	@And("^Stored Values in DB should be prepopulated in Proxy Details Page in Update SMA Single Access Flow$")
    public void stored_values_in_db_should_be_prepopulated_in_proxy_details_page_in_update_sma_single_access_flow() {
		sheetName = "Conversion_Validation";
		   sheet = exlObj.getSheet(sheetName);
		   count = 0;
		   int rownum = 19;
		   label = (String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if((label == "") ||(label.contains("Node ID")) )
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")) {
							rownum++;
			    			label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromProxyDetailsPage(label);
						dbValue =(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							exlObj.setCellData(sheet, rownum, 5, attributeValue);
						}else {
							exlObj.setCellData(sheet, rownum, 5, "UI Value is not same as Stored Value in DB");
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							count++;
							
						}
							rownum++;
							label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In Proxy Details Page Values Stored in DB are Populated in UI");
			exlObj.closeWorkBook();
    }
	private String getDataFromProxyDetailsPage(String data) {
		switch (data) {
						case "Proxy Manager":
							
							uiValue = proxyDetailsPage.getProxyManagerValue();
							
							break;
						case "Proxy Address1":
							
							uiValue = proxyDetailsPage.getProxyAddress1Value();
							
							break;
						case "Proxy Address2":
							
							uiValue = proxyDetailsPage.getProxyAddress2Value();
							
							break;
						case "Proxy Address3":
							
							uiValue = proxyDetailsPage.getProxyAddress3Value();
							
							break;
						case "Proxy Address4":
							
							uiValue = proxyDetailsPage.getProxyAddress4Value();
					
							break;
						case "Proxy City":
							
							uiValue = proxyDetailsPage.getProxyCityValue();
							
							break;
						case "Proxy State":
							
							uiValue = proxyDetailsPage.getProxyStateValue();
							
							break;
						case "Proxy Zipcode":
							
							uiValue = proxyDetailsPage.getProxyZipCodeValue();
							
							break;
						case "Voluntary Reorg Manager":
							
							uiValue = proxyDetailsPage.getVoluntaryReorgManagerValue();
							
							break;
						case "Voluntary Reorg Address1":
							
							uiValue = proxyDetailsPage.getVoluntaryReorgAddress1Value();
							
							break;
						case "Voluntary Reorg Address2":
							
							uiValue = proxyDetailsPage.getVoluntaryReorgAddress2Value();
							
							break;
						case "Voluntary Reorg Address3":
							
							uiValue = proxyDetailsPage.getVoluntaryReorgAddress3Value();
							
							break;
						case "Voluntary Reorg Address4":
							
							uiValue = proxyDetailsPage.getVoluntaryreorgAddress4Value();
					
							break;
						case "Voluntary Reorg City":
							
							uiValue = proxyDetailsPage.getVoluntaryReorgCityValue();
							
							break;
						case "Voluntary Reorg State":
							
							uiValue = proxyDetailsPage.getVoluntaryReorgStateValue();
							
							break;
						case "Voluntary Reorg Zipcode":
							
							uiValue = proxyDetailsPage.getVoluntaryReorgZipcodeValue();
							
							break;
						case "Interim Manager":
							
							uiValue = proxyDetailsPage.getInterimManagerValue();
							
							break;
						case "Interim Address1":
							
							uiValue = proxyDetailsPage.getInterimAddress1Value();
							
							break;
						case "Interim Address2":
							
							uiValue = proxyDetailsPage.getInterimAddress2Value();
							
							break;
						case "Interim Address3":
							
							uiValue = proxyDetailsPage.getInterimAddress3Value();
							
							break;
						case "Interim Address4":
							
							uiValue = proxyDetailsPage.getInterimAddress4Value();
					
							break;
						case "Interim City":
							
							uiValue = proxyDetailsPage.getInterimCityValue();
							
							break;
						case "Interim State":
							
							uiValue = proxyDetailsPage.getInterimStateValue();
							
							break;
						case "Interim Zipcode":
							
							uiValue = proxyDetailsPage.getInterimZipcodeValue();
							
							break;
						
					
					default:
						uiValue = "NotChanged";
						break;
					}
					if((uiValue == null) || (uiValue.isEmpty()))
						uiValue = "isEmpty";
		return uiValue;
	}
	
	@And("^User is in Proxy Details Page in Update SMA Single Access Flow$")
    public void user_is_in_proxy_details_page_in_update_sma_single_access_flow() {
        Assert.assertTrue(proxyDetailsPage.isUserOnProxyDetailsPage());
    }
	
	@And("^User clicks on Next in Proxy Details Page in Update SMA Single Access Flow$")
    public void user_clicks_on_next_in_proxy_details_page_in_update_sma_single_access_flow() {
        proxyDetailsPage.clickOnNext();
    }
}
