package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.ProgramSortAndFilterPage;

public class ProgramSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	ProgramSortAndFilterPage programSortAndFilterPage = new ProgramSortAndFilterPage("AD_PM_ProgramSortAndFilterPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/ProgramSortAndFilter.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ProgramSortAndFilterPage"));

	@When("^User enter valid (.+) in global search box for Program$")
	public void user_enter_valid_in_global_search_box_for_program(String mandatorydetails) throws Throwable {
		if (mandatorydetails.contains("Valid")) {
			sheetName = "Valid";
		}
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String ProgramSearchValue = (String) exlObj.getCellData(sheet, rowIndex, 1);

		exlObj.closeWorkBook();
		if (ProgramSearchValue != "") {
			programSortAndFilterPage.searchProgramValue(ProgramSearchValue);
		}
		Reporter.addScreenCapture();
	}

	@And("^user clicks on \"([^\"]*)\" on landing page for Program$")
	public void user_clicks_on_something_on_landing_page_for_program(String strArg1) throws Throwable {
		programSortAndFilterPage.clickOnSeeAllResultsForProgramLayout();
		Reporter.addScreenCapture();
	}

	@And("^user is able to see search results in \"([^\"]*)\" tab under Program accordion$")
	public void user_is_able_to_see_search_results_in_something_tab_under_program_accordion(String strArg1)
			throws Throwable {
		programSortAndFilterPage.verifyTheSearchedResultInAllTabForProgram();
		Reporter.addScreenCapture();

	}

	@And("^user click on \"([^\"]*)\" tab on landing page for Program$")
	public void user_click_on_something_tab_on_landing_page_for_program(String strArg1) throws Throwable {
		programSortAndFilterPage.verifyAndClickProgramTab();
		Reporter.addScreenCapture();
	}

	@And("^User able to see searched grid view data for Program grid view$")
	public void user_able_to_see_searched_grid_view_data_for_program_grid_view() throws Throwable {
		String gridCountBeforeCondition = programSortAndFilterPage
				.verifyTheGridCountBeforeApplyFilterAndSortCondition();
		// String gridCountBeforeCondition =
		// ProgramSortAndFilterPage.gridCountAfterGlobalSearch;
		int beforeApplyCondition = Integer.parseInt(gridCountBeforeCondition);
		if (beforeApplyCondition == 1)
			programSortAndFilterPage.verifyTheNoResultsOnGridView();
	}

	@Then("^User should be able to search records for Program View using the global search box on landing page$")
	public void user_should_be_able_to_search_records_for_program_view_using_the_global_search_box_on_landing_page()
			throws Throwable {
		programSortAndFilterPage.verifySearchedGridViewDisplay();
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design for Program$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design_for_program(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			programSortAndFilterPage.mouseHoverOnGridViewLabels(programSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			programSortAndFilterPage.verifyGridViewLabelsWithSortIcons(
					programSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}

	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for Program$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_program(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			programSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					programSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for Program$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_program(List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			programSortAndFilterPage.mouseHoverOnGridViewLabels(programSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			programSortAndFilterPage.clickOnSortIcon(
					programSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for Program$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_program() throws Throwable {
		String value = programSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		// String value = ProgramSortAndFilterPage.ascSortValue;
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for Program$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_program(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			programSortAndFilterPage.mouseHoverOnGridViewLabels(programSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			programSortAndFilterPage.clickOnSortIcon(
					programSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for Program$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_program() throws Throwable {
		String value = programSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		// String value = ProgramSortAndFilterPage.descSortValue;
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for Program$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_program(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			programSortAndFilterPage.mouseHoverOnGridViewLabels(programSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			programSortAndFilterPage.clickOnSortIcon(
					programSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for Program$")
	public void user_should_able_to_sort_the_records_with_default_order_for_program() throws Throwable {
		String value = programSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		// String value = ProgramSortAndFilterPage.defaultSortValue;
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to click on the filter icon for below column for Program$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_program(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			programSortAndFilterPage.clickOnFilterIconForGridView(
					programSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to validate the filter condition all options for Program$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_program(List<String> entity)
			throws Throwable {
		programSortAndFilterPage.clickOnFilterCondition();
		for (int i = 0; i < entity.size(); i++) {
			programSortAndFilterPage.verifyValueOfFilterCondition(programSortAndFilterPage.findElementByDynamicXpath(
					"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to see tab count as per searched keyword for before any condition for Program$")
	public void user_able_to_see_tab_count_as_per_searched_keyword_for_before_any_condition_for_program()
			throws Throwable {
		String beforeApplyFilterValue = programSortAndFilterPage
				.verifyTheProgramGridCountAfterApplyFilterConditionOnTab();
		// String beforeApplyFilterValue =
		// ProgramSortAndFilterPage.tabCountAfterCondition;
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);

	}

	@And("^User able to select the (.+) from filter condition for Program$")
	public void user_able_to_select_the_from_filter_condition_for_program(String filtercondition) throws Throwable {
		programSortAndFilterPage.clickOnFilterCondition();
		programSortAndFilterPage
				.clickOnFilterConditionForProgramGridView(programSortAndFilterPage.findElementByDynamicXpath(
						"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for Program$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_program(String filterconditionvalue)
			throws Throwable {
		programSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();

	}

	@And("^User able to click on the Apply Button on Program grid view$")
	public void user_able_to_click_on_the_apply_button_on_program_grid_view() throws Throwable {
		programSortAndFilterPage.clickOnApplyFilterIconForProgramGridView();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on Program grid view$")
	public void user_should_able_to_verify_the_grid_count_on_program_grid_view() throws Throwable {
		String countTabAfterFilter = programSortAndFilterPage.verifyTheProgramGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter = ProgramSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = programSortAndFilterPage.verifyTheProgramGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition/10; i++) {
				action.scrollToBottom();
				Action.pause(1000);
				String presentGridAllData = programSortAndFilterPage.verifyTheProgramGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			programSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The grid view and tab count mismatch");}
	}

	@And("^User should able to verify the Tab count on Program grid view$")
	public void user_should_able_to_verify_the_tab_count_on_program_grid_view() throws Throwable {
		String countTabAfterFilter = programSortAndFilterPage.verifyTheProgramGridCountAfterApplyFilterConditionOnTab();
		// String countTabAfterFilter = ProgramSortAndFilterPage.tabCountAfterCondition;
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = programSortAndFilterPage.verifyTheProgramGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= beforeApplyFiltertabCountValue; i++) {
				action.scrollToBottom();
				Action.pause(1000);
				String presentGridAllData = programSortAndFilterPage.verifyTheProgramGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			programSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The tab count and grid view mismatch");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Reset Button on Program grid view$")
	public void user_able_to_click_on_the_reset_button_on_program_grid_view() throws Throwable {
		programSortAndFilterPage.clickOnApplyFilterIconForProgramGridViewForReset();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button on Program grid view$")
	public void user_able_to_click_on_the_cancel_button_on_program_grid_view() throws Throwable {
		programSortAndFilterPage.clickOnApplyFilterIconForProgramGridViewForCancel();
		Reporter.addScreenCapture();
	}

}
