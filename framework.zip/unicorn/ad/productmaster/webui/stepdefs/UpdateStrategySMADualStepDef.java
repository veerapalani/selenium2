package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.Flags.Flag;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import com.codoid.products.fillo.Select;
import com.hp.lft.sdk.mobile.DropDown;
import com.ibm.db2.jcc.a.i;
import com.ibm.db2.jcc.am.s;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.StrategyDetailPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategySMADualUIPage;

public class UpdateStrategySMADualStepDef 
	{
		
		String pageURL = SSOLoginPage.URL + "#/smaDualMac/view/";
		String pageURL2 = SSOLoginPage.URL + "#/smaDualMac/edit/";
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategySMADual.xlsx";
		String sheetName = "";
		String inputSheetName = "InputSheet";
		String myValue,myValue1;
		XSSFSheet sheet,inputSheet;
		int rowIndex, cellIndex;
		WebElement myElement;
		List<WebElement> myElements;
		String proxyDetails[]= {"Proxy Address","Voluntary Reorg Address","Interim"};
		String scenario[]= {"0","2","4"};
		int num;
		List<List<String>> attributeLists = new ArrayList<List<String>>();
		List<String> dataList = new ArrayList<String>() ;
		//PMPageGeneric CreateStyleFlyout = new PMPageGeneric("AD_PM_CreateStyleFlyout");
		//	UpdateStrategyPage updateStrategyPage = new UpdateStrategyPage();
		//Action action1 = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategyUIPage"));
		
		Action action = new Action(SQLDriver.getEleObjData("AD_PM_UpdateStrategySMADualUIPage"));		

		UpdateStrategySMADualUIPage updateStrategyPage = new UpdateStrategySMADualUIPage();
		
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		
		StrategyDetailPage strDtl = new StrategyDetailPage();
		
		SoftAssert sftAst = new SoftAssert();
		
		HashMap<String, String> DropDownValues = new HashMap<String, String>();
		HashMap<String, String> InputValues = new HashMap<String, String>();
		HashMap<String, String> ProxyValues = new HashMap<String, String>();
		
		
		/*@When("^User search with the \"([^\"]*)\" in the Search TextBox on landing page$")
		public void user_search_with_the_something_in_the_search_textbox_on_landing_page(String strArg1) throws Throwable 
			{
			 sheetName = "Valid";
			 sheet = exlObj.getSheet(sheetName);

					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, strArg1);
					myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
					myElement = action.getElement("Search_TextBox");
					myElement.clear();
					
					action.sendkeysClipboard(myElement, myValue);
					myElement.sendKeys(Keys.ENTER);  
			}*/

		  @When("^User search with the \"([^\"]*)\" taken from \"([^\"]*)\" in the Search TextBox on landing page while StrategySMADual updation$")
		    public void user_search_with_the_something_taken_from_something_in_the_search_textbox_on_landing_page_while_strategysmadual_updation(String strArg1, String strArg2) throws Throwable
		    {
			  			sheetName = strArg2;
			  			sheet = exlObj.getSheet(sheetName);

						rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
						cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, strArg1);
						myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
						System.out.println(myValue);
						myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector(\"brml-search-input\").shadowRoot.querySelector(\"wf-action-icon\").shadowRoot.querySelector(\"svg\")");
						myElement.click();
						myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector(\"brml-search-input\")");
						myElement.click();
						
						action.sendkeysClipboard(myElement, myValue);
						
					    Thread.sleep(2000);
					        
							int i = 0;
							while(i < 5) 
							{
								myElement.sendKeys(Keys.ENTER);
								i++;
							}
					        	
					        Thread.sleep(2000);
		
		    }

    	@And("^User clicks on the first element of Strategy Searches on the suggestion box on landing page while StrategySMADual updation$")
    	public void user_clicks_on_the_first_element_of_strategy_searches_on_the_suggestion_box_on_landing_page_while_strategysmadual_updation() throws Throwable
		 	{
    			Thread.sleep(5000);
				//myElement = updateStrategyPage.findElementByDynamicXpath("(//p[@class='body-3 text-tertiary'])[1]");
    			
    			myElement = action.getElement("First_Suggestion");
			
    			myElement.click();
				Reporter.addStepLog("clicked on first suggestion ");
		    }
		 
		 @Then("^User should be taken to Strategy Details page with the CONTINUE EDITING option should visible$")
		    public void user_should_be_taken_to_strategy_details_page_with_the_continue_editing_option_should_visible() throws Throwable
		  {
			
				Thread.sleep(2000);
				action.waitForPageLoad();
				sftAst.assertTrue(action.getCurrentURL().contains(pageURL), "We are in UpdateStrategyUIPage"); 
				Reporter.addStepLog("We are in UpdateStrategyUIPage");
				Reporter.addScreenCapture();
				myElement = action.getElement("Continue_Button_on_View_Strategy_Details");
				sftAst.assertTrue(myElement.isDisplayed(), "Continue Edit Button is displayed");
				Reporter.addStepLog("Continue Edit Button is displayed");
	
		  }
		 
		 	@And("^User clicks on the CONTINUE EDITING Button$")
		    public void user_clicks_on_the_continue_editing_button() throws Throwable
		    {
				myElement = action.getElement("Continue_Button_on_View_Strategy_Details");
				myElement.click();
				Reporter.addStepLog("Clicked on Continue Editing Button");
				Thread.sleep(3000);
	
		    }
		
		   @Then("^User should be taken to Update Strategy page$")
		   public void user_should_be_taken_to_update_strategy_page() throws Throwable
		   { 
			   action.waitForPageLoad();
			   sftAst.assertTrue(action.getCurrentURL().contains(pageURL2), "We are in Enter Strategy Details page"); 
			   Reporter.addStepLog("We are in Enter Strategy Details page");
			   Reporter.addScreenCapture();
		   }
		   
		   
		   @And("^User should be able to see the Enter Strategy Details header on Update StrategySMADual page$")
		    public void user_should_be_able_to_see_the_enter_strategy_details_header_on_update_strategysmadual_page() throws Throwable 
		   {
			 	//myElement = updateStrategyPage.findElementByDynamicXpath("//h4[contains(text(),'Enter Strategy Details')]");
				myElement = action.getElement("Header_Enter_Strategy_Details");

			 	sftAst.assertTrue(myElement.isDisplayed(), "Enter Strategy Details header is displayed");
			 	Reporter.addStepLog("Enter Strategy Details header is displayed");
		   }
		       
		   @Then("^User update the following dopdown with Valid Data in the Update StrategySMADual page$")
		    public void user_update_the_following_dopdown_with_valid_data_in_the_update_strategysmadual_page(List<List<String>> attribute) throws Throwable 
		   {
			    sheetName = "Valid";
				sheet = exlObj.getSheet(sheetName);
				Thread.sleep(2000);
				for (int i = 0; i < attribute.size(); i++)
				{

					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					
					System.out.println(attribute.get(i).get(0));
					myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
					myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector(\'brml-select[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('wf-input')");
					action.scrollToElement(myElement);
					action.click(myElement);
					Thread.sleep(3000);
					//System.out.println(myValue+"ghjgjhjjj");
					myElement =(WebElement) updateStrategyPage.executeJavaScript("return document.querySelector(\'brml-select[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector(\"li[data-value=\'"+myValue+"\']\")");
					System.out.println(myElement.getText());
					action.click(myElement);
					Thread.sleep(3000);
				}
						
				
		   }
		   
		   @And("^User clicks the Next Button on Update StrategySMADuaL page$")
		    public void user_clicks_the_next_button_on_update_strategysmadual_page() throws Throwable
		   {
			   Thread.sleep(2000);
			   //myElement =(WebElement) action1.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
			   myElement = action.getElement("Next_Button");

			   action.scrollToElement(myElement);
			   action.click(myElement);
			   Reporter.addStepLog("Clicked on Next button");
			   Thread.sleep(3000);
			   action.waitForPageLoad();
		    }
		   
		   @Then("^User should be able to see the Benchmark and Asset Classification header on Update StrategySMADual page$")
		    public void user_should_be_able_to_see_the_benchmark_and_asset_classification_header_on_update_strategysmadual_page() throws Throwable
		    {
				//myElement = updateStrategyPage.findElementByDynamicXpath("//h4[contains(text(),'Benchmark and Asset Classification')]");
				myElement = action.getElement("Header_Benchmark_and_Asset_Classification");

				sftAst.assertTrue(myElement.isDisplayed(), " Benchmark and Asset Classification header is displayed");
				Reporter.addStepLog("Benchmark and Asset Classification header is displayed");
				
		    }
		   
		   @And("^User clicks the Next Button on Benchmark and Assest Classification page of StrategySMADual$")
		    public void user_clicks_the_next_button_on_benchmark_and_assest_classification_page_of_strategysmadual() throws Throwable
		    {
			   Thread.sleep(2000);
			   //myElement =(WebElement) action1.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
			   myElement = action.getElement("Next_Button");
			   action.scrollToElement(myElement);
			   action.click(myElement);
			   Reporter.addStepLog("Clicked on Next button");
			   Thread.sleep(3000);
		    }
		   
		   @Then("^User should be able to see the Proxy Details header on Update StrategySMADual page$")
		    public void user_should_be_able_to_see_the_proxy_details_header_on_update_strategysmadual_page() throws Throwable
		    {
				//myElement = updateStrategyPage.findElementByDynamicXpath("//h4[contains(text(),'Proxy Details')]");
				myElement = action.getElement("Header_Proxy_Details");

			   	sftAst.assertTrue(myElement.isDisplayed(), " Proxy Details header is displayed");
				Reporter.addStepLog("Proxy Details header is displayed");
		    }
		   
		   @And("^User update the following textfields with Valid Data in the Proxy Details page of Update StrategySMADual page$")
		    public void user_update_the_following_textfields_with_valid_data_in_the_proxy_details_page_of_update_strategysmadual_page(List<List<String>> attribute) throws Throwable 
		    {
			 
			   	sheetName = "Valid";
				sheet = exlObj.getSheet(sheetName);
				Thread.sleep(2000);
				for (int i = 0; i < attribute.size(); i++)
				{

					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");

					   action.scrollToElement(myElement);
					   action.clear(myElement);
					   Thread.sleep(5000);
					   action.sendkeysClipboard(myElement, myValue);
					   Thread.sleep(5000);
				}
		    }
		   
		   @And("^User clicks the Next Button on Proxy Details page of StrategySMADual$")
		    public void user_clicks_the_next_button_on_proxy_details_page_of_strategysmadual() throws Throwable
		    {
			   Thread.sleep(2000);
			  // myElement =(WebElement) action1.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
			   myElement = action.getElement("Next_Button");
			   action.scrollToElement(myElement);
			   action.click(myElement);
			   Reporter.addStepLog("Clicked on Next button");
			   Thread.sleep(3000);
		    }
		   
		   @Then("^User should be able to see the Enter Document Links header on Update StrategySMADual page$")
		    public void user_should_be_able_to_see_the_enter_document_links_header_on_update_strategysmadual_page() throws Throwable
		    {
			   	//myElement = updateStrategyPage.findElementByDynamicXpath("//h4[contains(text(),'Enter Document Links')]");
				myElement = action.getElement("Header_Enter_Document_Links");

			   	sftAst.assertTrue(myElement.isDisplayed(), " Enter Document Links header is displayed");
				Reporter.addStepLog(" Enter Document Links header is displayed");
		    }
		   
		   @And("^User clicks the Next Button on Enter Document Links page of StrategySMADual$")
		    public void user_clicks_the_next_button_on_enter_document_links_page_of_strategysmadual() throws Throwable
		    {
			   Thread.sleep(2000);
			   //myElement =(WebElement) action1.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
			   myElement = action.getElement("Next_Button");
			   action.scrollToElement(myElement);
			   action.click(myElement);
			   Reporter.addStepLog("Clicked on Next button");
			   Thread.sleep(3000);
		    }
		   
		   @Then("^User should be able to see the Add Comments header on Update StrategySMADual page$")
		    public void user_should_be_able_to_see_the_add_comments_header_on_update_strategysmadual_page() throws Throwable
		    {
			  // myElement = updateStrategyPage.findElementByDynamicXpath("//h4[contains(text(),'Add Comments')]");
				myElement = action.getElement("Header_Add_Comments");

				sftAst.assertTrue(myElement.isDisplayed(), " Add Comments header is displayed");
				Reporter.addStepLog(" Add Comments header is displayed");
		    }
		   
		   @And("^User clicks the Next Button on Add Comments page of StrategySMADual$")
		    public void user_clicks_the_next_button_on_add_comments_page_of_strategysmadual() throws Throwable
		    {
			   Thread.sleep(2000);
			   //myElement =(WebElement) action1.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
			   myElement = action.getElement("Next_Button");
			   action.scrollToElement(myElement);
			   action.click(myElement);
			   Reporter.addStepLog("Clicked on Next button");
			   Thread.sleep(3000); 
		    }
		   
		   @Then("^User should be able to see the Review header on Update StrategySMADual page$")
		    public void user_should_be_able_to_see_the_review_header_on_update_strategysmadual_page() throws Throwable 
		    {
			   	//myElement = updateStrategyPage.findElementByDynamicXpath("//h4[contains(text(),'Review')]");
				myElement = action.getElement("Header_Review");

			   	sftAst.assertTrue(myElement.isDisplayed(), " Review header is displayed");
				Reporter.addStepLog(" Review header is displayed");
		    }
		 
		   @And("^User clicks the Submit Button on Review page of StrategySMADual$")
		    public void user_clicks_the_submit_button_on_review_page_of_strategysmadual() throws Throwable
		    {
			   Thread.sleep(2000);
			   myElement =(WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-button[type=\"submit\"]')");
			   action.scrollToElement(myElement);
			   action.click(myElement);
			   Reporter.addStepLog("Clicked on Next button");
			   Thread.sleep(3000);
		    }
		   
		   @Then("^User should be able to see the Confirmation header on Update StrategySMADual page$")
		    public void user_should_be_able_to_see_the_confirmation_header_on_update_strategysmadual_page() throws Throwable
		    {
			  // myElement = updateStrategyPage.findElementByDynamicXpath("//h4[contains(text(),'Confirmation')]");
				myElement = action.getElement("Header_Confirmation");

			   	sftAst.assertTrue(myElement.isDisplayed(), " Confirmation header is displayed");
				Reporter.addStepLog(" Confirmation header is displayed");
		    }
		   
		   @And("^User should be able to see the Confirmation Message on Confirmation page of StrategySMADual$")
		    public void user_should_be_able_to_see_the_confirmation_message_on_confirmation_page_of_strategysmadual() throws Throwable
		    {
			   //	myElement = updateStrategyPage.findElementByDynamicXpath("//h4[contains(text(),'Your SMA Dual Updation Request Has Been Submitted')]");
				myElement = action.getElement("Confirmation_Message");

			   	sftAst.assertTrue(myElement.isDisplayed(), " Confirmation Message is displayed");
				Reporter.addStepLog(" Confirmation Message is displayed");
				
		    }
		   
		   
		   @Then("^Check if all the below drop down fields are editable$")
		    public void check_if_all_the_below_drop_down_fields_are_editable(List<List<String>> attribute) throws Throwable 
		    {
			   for (int i = 0; i < attribute.size(); i++)
				{
					myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-select[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('wf-input')");
					action.scrollToElement(myElement);
					if(myElement.isEnabled())
					{
						Reporter.addStepLog(attribute.get(i).get(0)+"is editable");
					}
					
				}
		    }
		   
		   
		   @And("^Check if all the below input fields are editable$")
		    public void check_if_all_the_below_input_fields_are_editable(List<List<String>> attribute) throws Throwable
		    {
			   for (int i = 0; i < attribute.size(); i++)
				{
					myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");
					action.scrollToElement(myElement);
					if(myElement.isEnabled())
					{
						Reporter.addStepLog(attribute.get(i).get(0)+"is editable");
					}
					
				}
		    }
		   
		   
		   @And("^Check if all the below check box fields are editable$")
		    public void check_if_all_the_below_check_box_fields_are_editable(List<List<String>> attribute) throws Throwable 
		    {
			   for (int i = 0; i < attribute.size(); i++)
				{
					myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-checkbox[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");
					action.scrollToElement(myElement);
					if(myElement.isEnabled())
					{
						Reporter.addStepLog(attribute.get(i).get(0)+"is editable");
					}
					
				}
		    }
		   
		   
		   @And("^Check if Date feild is editable$")
		    public void check_if_date_feild_is_editable() throws Throwable
		    {
				myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-calendar-picker[id=\"approvalDate\"]').shadowRoot.querySelector('wf-input')");
				action.scrollToElement(myElement);
				if(myElement.isEnabled())
				{
					Reporter.addStepLog("Calender is editable");
				}
				
		    }
		   
		   @And("^Check if all the below feilds are not editable$")
		    public void check_if_all_the_below_feilds_are_not_editable(List<List<String>> attribute) throws Throwable 
		    {
			   for (int i = 0; i < attribute.size(); i++)
				{
					myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");
					action.scrollToElement(myElement);
					if(!myElement.isEnabled())
					{
						Reporter.addStepLog(attribute.get(i).get(0)+"is not editable");
					}
					
				}
		    }
		   
		   @Then("^Edit all the below input fields with valid data$")
		    public void edit_all_the_below_input_fields_with_valid_data(List<List<String>> attribute) throws Throwable
		    {
			  	sheetName = "Valid";
				sheet = exlObj.getSheet(sheetName);
				Thread.sleep(2000);
				for (int i = 0; i < attribute.size(); i++)
				{

					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-input[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('input')");

					if(myElement.isEnabled())
					{
					   action.scrollToElement(myElement);
					   action.clear(myElement);
					   Thread.sleep(2000);
					   action.sendkeysClipboard(myElement, myValue);
					   InputValues.put(attribute.get(i).get(0),myValue);
					   Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));

					   Thread.sleep(2000);
					}
				}
		    }
		   
		   
		   @And("^Edit all the below drop down fields with valid data$")
		    public void edit_all_the_below_drop_down_fields_with_valid_data(List<List<String>> attribute) throws Throwable
		    {
			  	sheetName = "Valid";
					sheet = exlObj.getSheet(sheetName);
					Thread.sleep(2000);
					for (int i = 0; i < attribute.size(); i++)
					{

						myElement = (WebElement)updateStrategyPage.executeJavaScript("return document.querySelector('brml-select[id=\""
								+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector('wf-input')");
						if(myElement.isEnabled())
						{
						action.scrollToElement(myElement);
						action.click(myElement);
						Thread.sleep(2000);
						rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
						cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
						myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
//						myElement = (WebElement)updateStrategyPage.executeJavaScript("return document.querySelector('brml-select[id=\""
//								+ attribute.get(i).get(1) + "\"]').shadowRoot.querySelector(\"li[data-value='" + myValue + "']\")");
						
						myElements = updateStrategyPage.getDynamicElementsFromShadowRoot("return document.querySelector('brml-select[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelectorAll('li')");
						
						for(WebElement E : myElements) 
						{
							if(E.getText().equalsIgnoreCase(myValue))
							{
								myElement = E;
								break;
							}
						}
						
						System.out.println(myElement.getText());
						
						//updateStrategyPage.writeIntoExcel(attribute.get(i).get(0), myElement.getText());
						
						DropDownValues.put(attribute.get(i).get(0),myElement.getText());
						
						action.scrollToElement(myElement);
						Reporter.addStepLog("Drop down for"+ attribute.get(i).get(0)+"selected");

						action.click(myElement);
						Thread.sleep(2000);
						
						}
						  
					}
		    }
		   
		   
		   @Then("^Check if all the edits made to the input and text feilds on Proxy Details page are reflected on Review page$")
		    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_on_proxy_details_page_are_reflected_on_review_page() throws Throwable
		    {
			   sheetName = "Proxy_Deatils";
				sheet = exlObj.getSheet(sheetName);
				Thread.sleep(2000);
			
					for (Map.Entry<String, String> data : ProxyValues.entrySet())
					{
						myValue = data.getValue();
						myElement = updateStrategyPage.findElementByDynamicXpath("//td[contains(text(),'"+myValue+"')]");
						sftAst.assertTrue(myElement.isDisplayed(), " "+myValue+"is displayed");
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						Reporter.addStepLog(myValue + " is displayed for " + data.getKey());
						Thread.sleep(500);
					}
		/*			for (int i = 0; i < attribute.size(); i++)
					{

						myElements = updateStrategyPage.findElementsByDynamicXpath("//th[contains(text(),'"+attribute.get(i)+"')]");
						
					for (int j = 0; j < myElements.size(); j++)
					{
						
							rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, proxyDetails[j]);
							num = Integer.parseInt(scenario[j]);
							cellIndex = exlObj.getCellIndexByCellValue(sheet, num, attribute.get(i));
							myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
							System.out.println(myValue);
							
							myElement = updateStrategyPage.findElementByDynamicXpath("//td[contains(text(),'"+myValue+"')]");

							action.scrollToElement(myElement);
							action.highligthElement(myElement);
							sftAst.assertTrue(myElement.isDisplayed(), " "+myValue+"is displayed");
							Reporter.addStepLog(myValue + " is displayed for " + attribute.get(i));

							Thread.sleep(500);
						
					}

				}*/
		    }
		   
		   @Then("^User Edits all the below input fields of Proxy Details with valid data$")
		    public void user_edits_all_the_below_input_fields_of_proxy_details_with_valid_data(List<List<String>> attribute) throws Throwable
		    {
			   sheetName = "Proxy_Deatils";
				sheet = exlObj.getSheet(sheetName);
				Thread.sleep(2000);
				for (int i = 0; i < attribute.size(); i++)
				{

					myElements = updateStrategyPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll('brml-input[id=\""
							+ attribute.get(i).get(1) + "\"]')");
					
					for (int j = 0; j < myElements.size(); j++)
					{
							myElement = (WebElement)updateStrategyPage.executeJavaScript("return document.querySelectorAll('brml-input[id=\""
									+ attribute.get(i).get(1) + "\"]')["+j+"].shadowRoot.querySelector(\"input\")");
							
							if(myElement.isEnabled())
							{
								action.scrollToElement(myElement);
								action.highligthElement(myElement);
		
								rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, proxyDetails[j]);
								num = Integer.parseInt(scenario[j]);
								cellIndex = exlObj.getCellIndexByCellValue(sheet, num, attribute.get(i).get(0));
								myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
								System.out.println(myValue);
								action.scrollToElement(myElement);
								action.clear(myElement);
								Thread.sleep(2000);
								action.sendkeysClipboard(myElement, myValue);
								
								String abcString = attribute.get(i).get(0)+j;
								System.out.println(abcString);
								ProxyValues.put(attribute.get(i).get(0)+j,myValue);
								
								Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0)+j);
	
								Thread.sleep(2000);
							}
						
					}

				}
				
		    }
		   
		   
		   @Then("^Edit all the below text fields with valid data$")
		    public void edit_all_the_below_text_fields_with_valid_data(List<List<String>> attribute) throws Throwable
		    {
			   sheetName = "Valid";
				sheet = exlObj.getSheet(sheetName);
				Thread.sleep(2000);
				for (int i = 0; i < attribute.size(); i++)
				{

					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get(0));
					myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					myElement = (WebElement) updateStrategyPage.executeJavaScript("return document.querySelector('brml-textarea[id=\""+attribute.get(i).get(1)+"\"]').shadowRoot.querySelector('textarea')");

					   action.scrollToElement(myElement);
					   action.clear(myElement);
					   Thread.sleep(2000);
					   action.sendkeysClipboard(myElement, myValue);
					   InputValues.put(attribute.get(i).get(0),myValue);
					   Reporter.addStepLog("send keys " + myValue + " for " + attribute.get(i).get(0));

					   Thread.sleep(2000);
				}
		    }
		   
		   @Then("^Check if all the edits made to the drop down feilds are reflected on Review page$")
		    public void check_if_all_the_edits_made_to_the_drop_down_feilds_are_reflected_on_review_page() throws Throwable
		    {
				Thread.sleep(500);
				Reporter.addScreenCapture();
				for (Map.Entry<String, String> data : DropDownValues.entrySet())
				{
					myValue = data.getValue();
					myElements = updateStrategyPage.findElementsByDynamicXpath("//*[contains(text(),'"+myValue+"')]");
					for(WebElement E : myElements)
					{
						sftAst.assertTrue(E.isDisplayed(), " "+myValue+"is displayed");
						action.scrollToElement(E);
						action.highligthElement(E);
						Reporter.addStepLog(myValue + " is displayed for " + data.getKey());
						Thread.sleep(500);
					}
				}

		    }
		   
		   @Then("^Check if all the edits made to the input and text feilds are reflected on Review page$")
		    public void check_if_all_the_edits_made_to_the_input_and_text_feilds_are_reflected_on_review_page() throws Throwable
		    {
			   sheetName = "Valid";
				sheet = exlObj.getSheet(sheetName);
				Thread.sleep(500);
				
				for (Map.Entry<String, String> data : InputValues.entrySet())
				{
					if(data.getKey().equalsIgnoreCase("Document Link"))
					{
						
					}
					else
					{
						myValue = data.getValue();
						System.out.println(data.getKey()+" "+data.getKey());
						myElements = updateStrategyPage.findElementsByDynamicXpath("//*[contains(text(),'"+myValue+"')]");
						for(WebElement E : myElements)
						{
							sftAst.assertTrue(E.isDisplayed(), " "+myValue+"is displayed");
							action.scrollToElement(E);
							action.highligthElement(E);
							Reporter.addStepLog(myValue + " is displayed for " + data.getKey());
							Thread.sleep(500);
						}
					}
				}
			/*	for (int i = 0; i < attribute.size(); i++)
				{

					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
					myValue = (String) exlObj.getCellData(sheet, rowIndex, cellIndex);
					
					myElement = updateStrategyPage.findElementByDynamicXpath("//div[contains(text(),'"+myValue+"')]");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);
					sftAst.assertTrue(myElement.isDisplayed(), " "+myValue+"is displayed");
					Reporter.addStepLog(myValue + " is displayed for " + attribute.get(i));

					Thread.sleep(500);

				}*/
				
		    }

		   
		   @Then("^User clicks on the suggestion which matches with his search token$")
		    public void user_clicks_on_the_suggestion_which_matches_with_his_search_token() throws Throwable
		    {
			 
				sheetName = "Strategy";
				sheet = exlObj.getSheet(sheetName);
				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
				cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, "Entity Type");
				myValue1 = (String)exlObj.getCellData(sheet, rowIndex, cellIndex);
				Thread.sleep(5000);
				updateStrategyPage.waitForWebElement("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
				myElements = updateStrategyPage.findElementsByDynamicXpath("//label[contains(text(),'" + myValue1 + "')]//parent::div//div[2]");
				
				for(int j = 0; j < myElements.size(); j++) 
				{
					
					if(myElements.get(j).getText().toUpperCase().contains(myValue.toUpperCase())) 
					{
						action.scrollToElement(myElements.get(j));
						action.highligthElement(myElements.get(j));
						Thread.sleep(2000);
						myElements.get(j).click();
						
						Reporter.addStepLog("clicking on the matching suggestion");
						
						break;
					}
					
				}
				
		    }
		 
		   @And("^User clicks on SMA tab on landing page$")
		    public void user_clicks_on_sma_tab_on_landing_page() throws Throwable
		    {
				myElement = updateStrategyPage.findElementByDynamicXpath("//brml-tab-button[@tab=\"SMAStrategy\"]");

				myElement.click();
				Reporter.addStepLog("SMA tab is cicked");
				action.waitForPageLoad();
				Thread.sleep(5000);

//				myElement = updateStrategyPage
//						.findElementByDynamicXpath("(//span[contains(text(),'UBS AM')]//parent::div//brml-action-menu)[3]");
//		    	myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"brml-action-menu\").shadowRoot.querySelector(\"span\")");
//		    	myElement.click();
//				Thread.sleep(5000);
		    }
		   
		   @And("^User clicks on the \"([^\"]*)\" button on the suggestion popup on landing page while StrategySMADual updation$")
		    public void user_clicks_on_the_something_button_on_the_suggestion_popup_on_landing_page_while_strategysmadual_updation(String strArg1) throws Throwable
		    {
			   Thread.sleep(2000);
				updateStrategyPage.waitForWebElement("//h6[contains(text(),'Results')]");
		    	myElement = updateStrategyPage.findElementByDynamicXpath("//brml-button[@id='all-result-button']");
		    	myElement.click();
				Reporter.addStepLog("clicking on the SEE ALL RESULTS button");

		    }
		   
		   @Then("^User should go to viewedit details of the Strategy Code \"([^\"]*)\"$")
		    public void user_should_go_to_viewedit_details_of_the_strategy_code_something(String strArg1) throws Throwable 
		    {
			   scroll_to_bottom();
			   
			   myElements = updateStrategyPage.getDynamicElementsFromShadowRoot("return document.querySelectorAll(\"div[col-id='strategyCode']\")");  
			   for (int i = 1; i < myElements.size(); i++)
			   {
				   System.out.println(myElements.get(i).getText());
					if(myElements.get(i).getText().toUpperCase().contains(strArg1.toUpperCase())) 
					{
					   	myElement = (WebElement)updateStrategyPage.executeJavaScript("return document.querySelectorAll(\"div[col-id='strategyCode']\")["+i+"]");
					   	myElement.click();
					   	myElement = (WebElement)updateStrategyPage.executeJavaScript("return document.querySelectorAll(\"div[col-id='strategyCode']\")["+i+"].parentElement.querySelector(\"brml-action-menu\")");
						action.scrollToElement(myElement);
						action.highligthElement(myElement);
						Thread.sleep(5000);
						myElement.click();
						Reporter.addStepLog("clicking on ellipsis icon");
					   
						myElement = (WebElement)updateStrategyPage.executeJavaScript("return document.querySelectorAll(\"div[col-id='strategyCode']\")["+i+"].parentElement.querySelector(\"brml-action-menu\").shadowRoot.querySelector(\"button > span\")");
						action.highligthElement(myElement);
						Thread.sleep(2000);
						myElement.click();
						
						Reporter.addStepLog("clicking on the View/Edit option");
						
						Thread.sleep(5000);
						break;
					}
			   }
			  
		    }
		   
		   @Then("^Scroll to bottom$")
		    public void scroll_to_bottom() throws Throwable
		    {	
			   try
			   {
				   Object lastHeight = (Object)action.executeJavaScript("return document.body.scrollHeight");
				   while(true)
				   {
					   Action.scrollToBottom();
					   Thread.sleep(5000);
					   
					   Object newHeight = (Object)action.executeJavaScript("return document.body.scrollHeight");
					   System.out.println("second scroll");
					   if(newHeight.equals(lastHeight))
					   {
						   break;
					   }
					   
					   lastHeight = newHeight;
				   }

			   }
			   
			   catch (Exception e) 
			   {
				   e.printStackTrace();
			   }
		    }
	
		   
		   @Then("^Edit the below fields of Benchmark Page$")
		    public void edit_the_below_fields_of_benchmark_page(List<Map<String,String>> attribute) throws Throwable
		    {
					myElement = (WebElement)updateStrategyPage.executeJavaScript(
							"return document.querySelector(\"#benchmarl_1\").shadowRoot.querySelectorAll(\"input[name='benchmarl_1']\" && \"input[type='radio']\")[1].parentElement.querySelector('button')");
					action.scrollToElement(myElement);
					
					if(!myElement.isSelected())
					{
						myElement.click();
						updateStrategyPage.deleteAllBins();
					}
					else 
					{
						updateStrategyPage.deleteAllBins();
					}
					
					sheetName = "Valid";
					sheet = exlObj.getSheet(sheetName);
					rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data");
					
					cellIndex = exlObj.getCellIndexByCellValue(sheet, 0,"Custom BM Reason");
					myValue = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
					
					myElement = (WebElement)updateStrategyPage.executeJavaScript("return document.querySelector('brml-textarea[id=\"txtCustomReasonSet1\"]').shadowRoot.querySelector('textarea')");
					action.scrollToElement(myElement);
					action.highligthElement(myElement);	
					action.sendkeysClipboard(myElement, myValue);
					
					for(int i = 0; i < attribute.size(); i++)
					{
						cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get("Dropdown Name"));
						String dropdownValues = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
						cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i).get("Dropdown Percentage"));
						String dropdownPercentages = (String)exlObj.getCellData(sheet, rowIndex, cellIndex).toString();
						
						if(dropdownValues.contains(",")) 
						{
							String[] ddValue = dropdownValues.split(",");
							String[] ddpercent = dropdownPercentages.split(",");
							
							if(ddValue.length != ddpercent.length) 
							{
								Assert.fail("The number of benchmarks & percentages don't match");
							}
							
							int size = ddValue.length;
							int j = 0;
							int sum = 0;
							
							
							while(size > 0 && size <= 10) 
							{
								String id = attribute.get(i).get("Percentage ID") + j;
								myValue = ddpercent[j];
								sum = sum + Integer.parseInt(myValue);
								
								if(sum != 100 && size == 1) 
								{
									myValue = "100";
								}
								
								updateStrategyPage.enterPercentage(id, myValue);
								Reporter.addStepLog(
										"send keys " + myValue + " for " + attribute.get(i).get("Dropdown Percentage"));
								
								myValue = ddValue[j];
								id = attribute.get(i).get("Dropdown ID") + j;
								updateStrategyPage.selectBMDropdown(id, myValue);
								Reporter.addStepLog("Drop down for" + attribute.get(i).get("Dropdown Name") + "selected");
								
								j++;
								size--;
								
								if(sum >= 100 && size !=0)
								{
									break;
								}
								
								if(size > 0 && size != 0)
								{
									if(attribute.get(i).get("Dropdown Name").contentEquals("UnBundled Node ID BM"))
									{
										updateStrategyPage.clickOnNewAsset();
									}
									else if(attribute.get(i).get("Dropdown Name").contentEquals("Custom Benchmark BM")) 
									{
										updateStrategyPage.clickOnNewBenchmark();
									}
								}
							}
						}
								else 
								{
									String id = attribute.get(i).get("Percentage ID") + 0;
									updateStrategyPage.enterPercentage(id, "100");
									
									myValue = dropdownValues;
									id = attribute.get(i).get("Dropdown ID") + 0;
									updateStrategyPage.selectBMDropdown(id, myValue);
								}
							}
						}
	
		   @Then("^User fills all the details of Documents Page$")
		    public void user_fills_all_the_details_of_documents_page() throws Throwable
		    {
			   dataList.clear();
			   attributeLists.clear();
			   
			   myElement = updateStrategyPage.findElementByDynamicXpath("//*[contains(text(),'DOCUMENT LINK')]");
			   if(myElement.isEnabled())
			   {
				   myElement.click();
			   }
			   
			   dataList.add(0,"Type1");
			   dataList.add(1,"documentType");
			   attributeLists.add(0,dataList);
			   edit_all_the_below_drop_down_fields_with_valid_data(attributeLists);
			   
			   dataList.set(0,"Document Link");
			   dataList.set(1,"documentLink");
			   attributeLists.set(0,dataList);
			   edit_all_the_below_input_fields_with_valid_data(attributeLists);
			   
			   dataList.set(0,"Comment1");
			   dataList.set(1,"documentDescription");
			   attributeLists.set(0,dataList);
			   edit_all_the_below_text_fields_with_valid_data(attributeLists);
			   
			   myElement = updateStrategyPage.findElementByDynamicXpath("//wf-button[contains(text(),'DOCUMENT LINK')]");
			   myElement.click();
			   Thread.sleep(2000);
		    }
		   
		   @Then("^User fills all the details of Comments Page$")
		    public void user_fills_all_the_details_of_comments_page() throws Throwable
		    {
			   dataList.clear();
			   attributeLists.clear();
			   
			   myElement = updateStrategyPage.findElementByDynamicXpath("//*[contains(text(),'COMMENT')]");
			   if(myElement.isEnabled())
			   {
				   myElement.click();
			   }
			   
			   dataList.add(0,"Type2");
			   dataList.add(1,"commentType");
			   attributeLists.add(0,dataList);
			   edit_all_the_below_drop_down_fields_with_valid_data(attributeLists);
			   
			   dataList.set(0,"Comment2");
			   dataList.set(1,"comments");
			   attributeLists.set(0,dataList);
			   edit_all_the_below_text_fields_with_valid_data(attributeLists);
			   
			   myElement = updateStrategyPage.findElementByDynamicXpath("//wf-button[contains(text(),'COMMENT')]");
			   myElement.click();
			   Thread.sleep(2000);
		    }
	}