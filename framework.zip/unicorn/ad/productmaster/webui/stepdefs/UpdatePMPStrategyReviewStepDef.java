package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;

import cucumber.api.java.en.And;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.UpdatePMPStrategyReviewPage;

public class UpdatePMPStrategyReviewStepDef {

	UpdatePMPStrategyReviewPage reviewPage = new UpdatePMPStrategyReviewPage("AD_PM_UpdatePMPStrategyReviewPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
	
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName;
	String label, attributeValue, uiValue,dbValue = null;
	
	public static int count;
	
	@And("^User is in Review Page in Update PMP Strategy Flow$")
    public void user_is_in_review_page_in_update_pmp_strategy_flow() {
        Assert.assertTrue(reviewPage.isUserOnReviewPage());
    }

	@And("^Stored Values in DB should be prepopulated in Review Page in Update PMP Strategy Flow$")
    public void stored_values_in_db_should_be_prepopulated_in_review_page_in_update_pmp_strategy_flow() {
    	sheetName = "Conversion_Validation";
		   sheet = exlObj.getSheet(sheetName);
		   count = 0;
		   int rownum = 1;
		   label = (String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")  || (label.contains("NIESDP"))) {
							rownum++;
			    			label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromReviewPage(label);
						dbValue =(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							exlObj.setCellData(sheet, rownum, 6, attributeValue);
						}else {
							exlObj.setCellData(sheet, rownum, 6, attributeValue+" -UI Value is not same as Stored Value in DB");
							
							Reporter.addCompleteScreenCapture();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							count++;
							
						}
							rownum++;
							label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
			if(UpdatePMPStratgeyViewStepDef.count+UpdatePMPStrategyEnterStrategyDetailsStepDef.count+UpdatePMPStrategyBenchmarkStepDef.count+count > 0) {
				if(UpdatePMPStratgeyViewStepDef.count>0) {
					Reporter.addStepLog("In View Page Values Stored in DB differ from Values Populated in UI");
				}
				if(UpdatePMPStrategyEnterStrategyDetailsStepDef.count>0) {
					Reporter.addStepLog("In Enter Startegy Details Page Values Stored in DB differ from Values Populated in UI");
				}
				if(UpdatePMPStrategyBenchmarkStepDef.count>0) {
					Reporter.addStepLog("In Benchmark Page Values Stored in DB differ from Values Populated in UI");
				}
				if(count>0) {
					Reporter.addStepLog("In Review & Attestation Page Values Stored in DB differ from Values Populated in UI");
				}
				
				Assert.fail("Prepopulated Values are not same as values stored in DB");
			}
			Reporter.addEntireScreenCaptured();
			//Reporter.addStepLog("In Review & Attestation Page Values Stored in DB are Populated in UI");
			exlObj.closeWorkBook();
    }

	private String getDataFromReviewPage(String data) {
			switch (data) {
			case "Risk Category":
				
				uiValue = reviewPage.getRiskCategoryValue();
				
				break;
			case "PIV Style":
				
				uiValue = reviewPage.getPIVStyleValue();
				
				break;
			case "Geographic Indicator":
				
				uiValue = reviewPage.getGeographicIndicatorValue();
				
				break;
			case "Strategy Name":
				
				uiValue = reviewPage.getStrategyNameValue();
				
				break;
			case "Strategy Code":
				
				uiValue = reviewPage.getStrategyCodeValue();
				
				break;
			case "Balanced Allocation":
				
				uiValue = reviewPage.getBalancedAllocationValue();
				
				break;
			case "Concentrated Strategy Indicator_radiobutton":
				
				uiValue = reviewPage.getConcentratedStrategyIndicatorValue();
				
				break;
			case "Structured Products Strategy_radiobutton":
				
				uiValue = reviewPage.getStructuredProductsStrategyValue();
				
				break;
			case "Margins":
				
				uiValue = reviewPage.getMarginsValue();
				
				break;
			case "Status":
				
				uiValue = reviewPage.getStrategyStatusValue();
				
				break;
			case "Concord Eligible(NEW)":
				
				//uiValue = reviewPage.getConcordEligibleValue();
				
				break;
			case "Options Approval Level Code":
				
				//uiValue = reviewPage.getOptionalApprovalLevelCodeValues();
				
				break;
			case "Hedge Core Indicator_radiobutton":
				
				uiValue = reviewPage.getHedgeCoreIndicatorValue();
				
				break;
			case "Style Pairing Code":
				
				uiValue = reviewPage.getStylePairingCodeValue();
				
				break;
			case "Risk Tolerance":
				
				//uiValue = reviewPage.getRiskToleranceValue();
				
				break;
			case "Portfolio Strategy Group Code":
				
				//uiValue = reviewPage.getPortfolioStrategyGroupCodeValue();
				
				break;
			case "Investment Style":
				
				uiValue = reviewPage.getInvestmentStyleValue();
				
				break;
			case "Primary Benchmark":
				
				uiValue = reviewPage.getPrimaryBenchmarkValue();
				
				break;
			default:
				
				uiValue = "NotChanged";
				
				break;
		}
			if(uiValue.equals("—"))
				uiValue = "isEmpty";
	
		return uiValue;
	}
}
