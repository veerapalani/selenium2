package qa.unicorn.ad.productmaster.webui.stepdefs;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.CreateFAActualDocLinkPage;

public class CreateFADocLinkStepDef {
	WebElement myElement, myElement2;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_CreateFADocLinkPage"));
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateFA.xlsx";
	String option, sheetName = "";
	int rowIndex;
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	CreateFAActualDocLinkPage documentsactualPage = new CreateFAActualDocLinkPage("AD_PM_CreateFAActualDocLinkPage");

	@And("^User enters the details required on the Documents Page$")
	public void user_enters_the_details_required_on_the_documents_page() throws Throwable {
		documentsactualPage.selectDocumentType();
		documentsactualPage.enterDocumentLink();
		documentsactualPage.enterDocumentComment();
		documentsactualPage.clickOnAddDocumentLinkButton();
		Reporter.addScreenCapture();
	}

	@And("^User enters the details required on the Create FA Documents Page$")
	public void user_enters_the_details_required_on_the_create_fa_documents_page() throws Throwable {
		documentsactualPage.clickOnAddAnotherDocumentLinkButton();
		documentsactualPage.selectDocumentType();
		documentsactualPage.enterDocumentLink();
		documentsactualPage.enterDocumentComment();
		documentsactualPage.clickOnAddDocumentLinkButton();
		Reporter.addScreenCapture();
	}

	@And("^User Clicks on the Next button in Documents page$")
	public void user_clicks_on_the_next_button_in_documents_page() throws Throwable {
		documentsactualPage.clickOnNextButton();
		Reporter.addScreenCapture();
	}

	@And("^User should be able to see document is added and click on delete button$")
	public void user_should_be_able_to_see_document_is_added_and_click_on_delete_link() throws Throwable {
		Assert.assertTrue(documentsactualPage.getDocumentLinktext().contains("GOOGLE"),
				"Same document is present in documents page");
		documentsactualPage.clickOnDeleteButton();
		Reporter.addScreenCapture();
	}

	@Then("^User should be able to see that document is removed$")
	public void user_should_be_able_to_see_that_document_is_removed() throws Throwable {
		Assert.assertFalse(documentsactualPage.isDocumentPresent());
	}

	@And("^User deletes the documents if present in page$")
	public void user_deletd_the_documents_if_present_in_page() throws Throwable {
		documentsactualPage.deleteDocumentsIfPresent();
	}

	@And("^User enters the details required on the Documents Page and delete documents if present$")
	public void user_enters_the_details_required_on_the_documents_page_and_delete_documents_if_present()
			throws Throwable {
		Reporter.addScreenCapture();
		documentsactualPage.deleteDocumentsIfPresent();
		documentsactualPage.selectDocumentType();
		documentsactualPage.enterDocumentLink();
		documentsactualPage.enterDocumentComment();
		documentsactualPage.clickOnAddDocumentLinkButton();
		Reporter.addScreenCapture();
	}

	@And("^User clicks on previous button in Documents page in Create FA$")
	public void user_clicks_on_previous_button_in_documents_page_in_create_fa() throws Throwable {
		documentsactualPage.clickonpreviousbuttonindocumentlinkspage();
		Reporter.addScreenCapture();
	}

	@And("^User verifies the details in Documents page in create FA$")
	public void user_verifies_the_details_in_documents_page_in_create_fa() throws Throwable {
		documentsactualPage.validateDocLinksFields();
	}

}
