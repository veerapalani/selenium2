package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.DraftSortAndFilterPage;
import qa.unicorn.ad.productmaster.webui.pages.LandingPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;

public class DraftSortAndFilterStepDef {

	LandingPage landingPage = new LandingPage("AD_PM_LandingPage");
	DraftSortAndFilterPage draftSortAndFilterPage = new DraftSortAndFilterPage("AD_PM_DraftSortAndFilterPage");
	String mandatorydetails, sheetName = "";
	int rowIndex;
	XSSFSheet sheet;
	String expError, countTabValue, beforeCountTabValue;
	int beforeApplyFiltertabCountValue, parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition;
	WebElement myElement, myElement2;
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_DraftSortAndFilterPage"));

	@When("^user click on \"([^\"]*)\" tab on landing page for Draft View$")
	public void user_click_on_something_tab_on_landing_page_for_draft_view(String strArg1) throws Throwable {
		draftSortAndFilterPage.verifyAndClickDraftTab();
	}

	@Then("^User should be able to see Sort Icon with below coloum as per frontify design for Draft View$")
	public void user_should_be_able_to_see_sort_icon_with_below_coloum_as_per_frontify_design_for_draft_view(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			draftSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			draftSortAndFilterPage.mouseHoverOnGridViewLabels(draftSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			draftSortAndFilterPage.verifyGridViewLabelsWithSortIcons(
					draftSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for Draft View$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_draft_view(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			draftSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			draftSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					draftSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User able to click on the Sort icon for below Column for of Draft grid view$")
	public void user_able_to_click_on_the_sort_icon_for_below_column_for_of_draft_grid_view(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			draftSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			draftSortAndFilterPage.mouseHoverOnGridViewLabels(draftSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			draftSortAndFilterPage.clickOnSortIcon(
					draftSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Asc order for of Draft grid view$")
	public void user_should_able_to_sort_the_records_with_asc_order_for_of_draft_grid_view() throws Throwable {
		draftSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		String value = draftSortAndFilterPage.verifyTheSortCoumnPropertyTypeASC();
		Assert.assertTrue(value.contains("asc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Asc Sort icon for below Column for Draft grid view$")
	public void user_able_to_click_on_the_asc_sort_icon_for_below_column_for_draft_grid_view(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			draftSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			draftSortAndFilterPage.mouseHoverOnGridViewLabels(draftSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			draftSortAndFilterPage.clickOnSortIcon(
					draftSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortAsc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Desc order for Draft grid view$")
	public void user_should_able_to_sort_the_records_with_desc_order_for_draft_grid_view() throws Throwable {
		draftSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		String value = draftSortAndFilterPage.verifyTheSortCoumnPropertyTypeDESC();
		Assert.assertTrue(value.contains("desc"), "The sorted value not matching");
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Desc Sort icon for below Column for Draft grid view$")
	public void user_able_to_click_on_the_desc_sort_icon_for_below_column_for_draft_grid_view(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			draftSortAndFilterPage.waitForWebElement("//span[contains(text(),'" + entity.get(i) + "')]");
			draftSortAndFilterPage.mouseHoverOnGridViewLabels(draftSortAndFilterPage
					.findElementByDynamicXpath("//span[contains(text(),'" + entity.get(i) + "')]"));
			Reporter.addScreenCapture();

			draftSortAndFilterPage.clickOnSortIcon(
					draftSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//following::span[@ref='eSortDesc']/brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to sort the records with Default order for Draft grid view$")
	public void user_should_able_to_sort_the_records_with_default_order_for_draft_grid_view() throws Throwable {
		draftSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		String value = draftSortAndFilterPage.verifyTheSortCoumnPropertyTypeDefault();
		Assert.assertTrue(value.contains("none"), "The sorted value not matching");
	}

	@And("^User able to click on the filter icon for below column for Draft grid view$")
	public void user_able_to_click_on_the_filter_icon_for_below_column_for_draft_grid_view(List<String> entity)
			throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			draftSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			draftSortAndFilterPage.clickOnFilterIconForGridView(
					draftSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User should able to validate the filter condition all options for Draft grid view$")
	public void user_should_able_to_validate_the_filter_condition_all_options_for_draft_grid_view(List<String> entity)
			throws Throwable {
		draftSortAndFilterPage.clickOnFilterCondition();
		for (int i = 0; i < entity.size(); i++) {
			draftSortAndFilterPage.verifyValueOfFilterCondition(draftSortAndFilterPage.findElementByDynamicXpath(
					"//div[@class='options-list-wrapper']//ul//li[text()='" + entity.get(i) + "']"));
			Reporter.addScreenCapture();
		}
	}

	@Then("^User should be able to see Filters Icon with below coloum as per frontify design for Draft grid view$")
	public void user_should_be_able_to_see_filters_icon_with_below_coloum_as_per_frontify_design_for_draft_grid_view(
			List<String> entity) throws Throwable {
		for (int i = 0; i < entity.size(); i++) {
			draftSortAndFilterPage.waitForWebElement("(//span[contains(text(),'" + entity.get(i)
					+ "')]//parent::div//parent::div//brml-action-icon)[1]");
			draftSortAndFilterPage.verifyGridViewLabelsWithFilterIcons(
					draftSortAndFilterPage.findElementByDynamicXpath("(//span[contains(text(),'" + entity.get(i)
							+ "')]//parent::div//parent::div//brml-action-icon)[1]"));
			Reporter.addScreenCapture();
		}
	}

	@And("^User able to see tab count before any condition for Draft grid view$")
	public void user_able_to_see_tab_count_before_any_condition_for_draft_grid_view() throws Throwable {
		draftSortAndFilterPage.verifyTheDraftGridCountAfterApplyFilterConditionOnTab();
		String beforeApplyFilterValue = draftSortAndFilterPage.verifyTheDraftGridCountAfterApplyFilterConditionOnTab();
		beforeCountTabValue = beforeApplyFilterValue.substring(beforeApplyFilterValue.indexOf("(") + 1,
				beforeApplyFilterValue.length() - 1);
		beforeApplyFiltertabCountValue = Integer.parseInt(beforeCountTabValue);
	}

	@And("^User able to select the (.+) from filter condition for Draft grid view$")
	public void user_able_to_select_the_from_filter_condition_for_draft_grid_view(String filtercondition)
			throws Throwable {
		draftSortAndFilterPage.clickOnFilterCondition();
		draftSortAndFilterPage.clickOnFilterConditionForDraftGridView(draftSortAndFilterPage.findElementByDynamicXpath(
				"//div[@class='options-list-wrapper']//ul//li[text()='" + filtercondition + "']"));
		Reporter.addScreenCapture();
	}

	@And("^User able to enter the filter condition (.+) in input field for Draft grid view$")
	public void user_able_to_enter_the_filter_condition_in_input_field_for_draft_grid_view(String filterconditionvalue)
			throws Throwable {
		draftSortAndFilterPage.enterFilterValue(filterconditionvalue);
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Apply Button on Draft grid view$")
	public void user_able_to_click_on_the_apply_button_on_draft_grid_view() throws Throwable {
		draftSortAndFilterPage.clickOnApplyFilterIconForDraftGridView();
		Reporter.addScreenCapture();
	}

	@And("^User should able to verify the grid count on Draft grid view$")
	public void user_should_able_to_verify_the_grid_count_on_draft_grid_view() throws Throwable {
		// draftSortAndFilterPage.verifyTheDraftGridCountAfterApplyFilterConditionOnTab();
		String countTabAfterFilter = draftSortAndFilterPage.verifyTheDraftGridCountAfterApplyFilterConditionOnTab();
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);
		System.out.println("tabCountAfterFilterCondition" + tabCountAfterFilterCondition);
		String presentGridData = draftSortAndFilterPage.verifyTheDraftGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		System.out.println("parseValueOfGridCountAfterFilterCondition" + parseValueOfGridCountAfterFilterCondition);
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10)
			for (int i = 0; i <= tabCountAfterFilterCondition / 10; i++) {
				// action.scrollToBottom();
				action.waitForDomToComplete(WebDriverManager.getDriver());
				draftSortAndFilterPage.waitForWebElement(
						"(//brml-active-icon)[" + String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				/*
				 * myElement = draftSortAndFilterPage.findElementByDynamicXpath(
				 * "(//brml-active-icon)[" +
				 * String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				 */
				// action.moveToElement(myElement);
				action.scrollToBottom();
				action.pause(2000);
				String presentGridAllData = draftSortAndFilterPage.verifyTheDraftGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			draftSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		if (parseValueOfGridCountAfterFilterCondition != 0) {
			Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
					"The grid view and tab count mismatch");
		}
	}

	@And("^User should able to verify the Tab count on Draft grid view$")
	public void user_should_able_to_verify_the_tab_count_on_draft_grid_view() throws Throwable {
		draftSortAndFilterPage.verifyTheDraftGridCountAfterApplyFilterConditionOnTab();
		String countTabAfterFilter = draftSortAndFilterPage.verifyTheDraftGridCountAfterApplyFilterConditionOnTab();
		countTabValue = countTabAfterFilter.substring(countTabAfterFilter.indexOf("(") + 1,
				countTabAfterFilter.length() - 1);
		tabCountAfterFilterCondition = Integer.parseInt(countTabValue);

		String presentGridData = draftSortAndFilterPage.verifyTheDraftGridCountAfterScroll();
		parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridData);
		parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;
		action.scrollToUp();
		if (parseValueOfGridCountAfterFilterCondition >= 10) {
			for (int i = 0; i <= tabCountAfterFilterCondition / 10; i++) {
				// action.scrollToBottom();
				action.waitForDomToComplete(WebDriverManager.getDriver());
				draftSortAndFilterPage.waitForWebElement(
						"(//brml-active-icon)[" + String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				myElement = draftSortAndFilterPage.findElementByDynamicXpath(
						"(//brml-active-icon)[" + String.valueOf(parseValueOfGridCountAfterFilterCondition) + "]");
				action.moveToElement(myElement);
				action.pause(2000);
				String presentGridAllData = draftSortAndFilterPage.verifyTheDraftGridCountAfterScroll();
				parseValueOfGridCountAfterFilterCondition = Integer.parseInt(presentGridAllData);
				parseValueOfGridCountAfterFilterCondition = parseValueOfGridCountAfterFilterCondition - 1;

				if (parseValueOfGridCountAfterFilterCondition == tabCountAfterFilterCondition)
					break;
			}
		}
		if (parseValueOfGridCountAfterFilterCondition == 0) {
			draftSortAndFilterPage.verifyTheNoResultsOnGridView();
		}
		Reporter.addStepLog("Grid count after filter condition is:" + parseValueOfGridCountAfterFilterCondition);
		Reporter.addStepLog("tab count after filter condition is:" + tabCountAfterFilterCondition);
		Reporter.addScreenCapture();
		Assert.assertEquals(parseValueOfGridCountAfterFilterCondition, tabCountAfterFilterCondition,
				"The tab count and Grid view count mismatch");
	}

	@And("^User able to click on the Reset Button on Draft grid view$")
	public void user_able_to_click_on_the_reset_button_on_draft_grid_view() throws Throwable {
		draftSortAndFilterPage.clickOnApplyFilterIconForDraftGridViewForReset();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Cancel Button on Draft grid view$")
	public void user_able_to_click_on_the_cancel_button_on_draft_grid_view() throws Throwable {
		draftSortAndFilterPage.clickOnApplyFilterIconForDraftGridViewForCancel();
		Reporter.addScreenCapture();
	}

	@And("^User able to click on the Next arrow button for tab scroll on landing page$")
	public void user_able_to_click_on_the_next_arrow_button_for_tab_scroll_on_landing_page() throws Throwable {
		if (draftSortAndFilterPage.verifyNextArrowIsDisplay())
			draftSortAndFilterPage.clickOnNextArrowTab();
	}

	@And("^User able to select the (.+) from filter date condition for Draft grid view$")
	public void user_able_to_select_the_from_filter_date_condition_for_draft_grid_view(String filtercondition)
			throws Throwable {
		action.fluentWaitWebElement("DatePicker");
		action.pause(4000);

		if (Integer.valueOf(filtercondition) == 6) {
			// action.pause(2000);
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-range.date-picker-wrapper > div > div > div.pmu-days >div:nth-child(5)')");
			action.scrollToElement(myElement);
			action.highligthElement(myElement);
			action.click(myElement);
			action.pause(1000);
			myElement2 = (WebElement) action.executeJavaScript(
					"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-range.date-picker-wrapper > div > div > div.pmu-days >div:nth-child(25)')");
			action.scrollToElement(myElement2);
			action.highligthElement(myElement2);
			action.click(myElement2);
		} else {
			myElement = (WebElement) action.executeJavaScript(
					"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > ul > div.os-padding > div > div > li:nth-child("
							+ Integer.valueOf(filtercondition) + ") > span')");
			action.highligthElement(myElement);
			action.click(myElement);
		}
	}

	@And("^User able to click on Date the Apply Button on Draft grid view$")
	public void user_able_to_click_on_date_the_apply_button_on_draft_grid_view() throws Throwable {
		action.pause(2000);
		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(3)')");
		PMPageGeneric.waitForElementToBeVisible(myElement, 20);
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@And("^User able to click on Date the Reset Button on Draft grid view$")
	public void user_able_to_click_on_date_the_reset_button_on_draft_grid_view() throws Throwable {
		action.pause(2000);
		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(1)')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}

	@And("^User able to click on Date the Cancel Button on Draft grid view$")
	public void user_able_to_click_on_date_the_cancel_button_on_draft_grid_view() throws Throwable {
		action.pause(2000);
		myElement = (WebElement) action.executeJavaScript(
				"return document.querySelector('#filterCalendar').shadowRoot.querySelector('div > div > div > div > div.date-picker-footer > wf-button:nth-child(2)')");
		action.scrollToElement(myElement);
		action.highligthElement(myElement);
		action.click(myElement);
	}
}
