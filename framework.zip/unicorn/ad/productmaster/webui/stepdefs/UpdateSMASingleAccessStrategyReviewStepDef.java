package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessStrategyReviewPage;

public class UpdateSMASingleAccessStrategyReviewStepDef {
	
	UpdateSMASingleAccessStrategyReviewPage reviewPage = new UpdateSMASingleAccessStrategyReviewPage("AD_PM_UpdateSMASingleAccessStrategyReviewPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName;
	String label, attributeValue, uiValue,dbValue = null;
	
	public static int count;
	public static int defaultbenchmarkcount;
	
	@And("^User is in Review Page in Update SMA Single Access Flow$")
    public void user_is_in_review_page_in_update_sma_single_access_flow() {
		 assertTrue(reviewPage.isUserOnReviewPage());
    }

    @And("^Stored Values in DB should be prepopulated in Review Page in Update SMA Single Access Flow$")
    public void stored_values_in_db_should_be_prepopulated_in_review_page_in_update_sma_single_access_flow() {
    	sheetName = "Conversion_Validation";
 	   sheet = exlObj.getSheet(sheetName);
 	   count = 0;
 	   int rownum = 1;
 	   label = (String) exlObj.getCellData(sheet, rownum, 0);
 	   
 	   if(label == "")
 			label = "isEmpty";
 		while (label != "isEmpty") {
 												
 				if(label.contains("ignore") || label.contains("NIVDP")) {
 						rownum++;
 		    			label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
 		    			
 		    			if(label == "")
 		    				label = "isEmpty";
 				}else {
 					
 					attributeValue = getDataFromreviewPage(label);
 					dbValue =(String) exlObj.getCellData(sheet, rownum, 3).toString();
 					if(dbValue.equals(attributeValue)) {
 						exlObj.setCellData(sheet, rownum, 6, attributeValue);
 					}else {
 						exlObj.setCellData(sheet, rownum, 6, attributeValue+" -UI Value is not same as Stored Value in DB");
 						
 						Reporter.addEntireScreenCaptured();
 						Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
 						count++;
 						
 					}
 						rownum++;
 						label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
 						
 						if(label == "")
 							label = "isEmpty";
 				
 				}
 		}
 		if(UpdateSMASingleAccesstrategyViewDetailsStepDef.count+UpdateSMASingleAccessStrategyEnterStrategyDetailsStepDef.count+UpdateSMASingleAccessStrategyBenchmarkStepDef.count+UpdateSMASingleAccessStrategyProxyDetailsStepDef.count+count > 0) {
 			if(UpdateSMASingleAccesstrategyViewDetailsStepDef.count > 0) {
 				Reporter.addStepLog("In View Page Values Stored in DB are Populated in UI");
 			}
 			if(UpdateSMASingleAccessStrategyEnterStrategyDetailsStepDef.count > 0) {
 				Reporter.addStepLog("In Enter Strategy Details Page Values Stored in DB are Populated in UI");
 			}
 			if(UpdateSMASingleAccessStrategyBenchmarkStepDef.count > 0) {
 				Reporter.addStepLog("In Benchmark Page Values Stored in DB are Populated in UI");
 			}
 			if(UpdateSMASingleAccessStrategyProxyDetailsStepDef.count > 0) {
 				Reporter.addStepLog("In Proxy Details Page Values Stored in DB are Populated in UI");
 			}
 			if(count > 0) {
 				Reporter.addStepLog("In View Page Values Stored in DB are Populated in UI");
 			}
 			Assert.fail("Prepopulated Values are not same as values stored in DB");
 		}
 		Reporter.addCompleteScreenCapture();
 		//Reporter.addStepLog("In Review Page Values Stored in DB are Populated in UI");
 		exlObj.closeWorkBook();
    }

	private String getDataFromreviewPage(String data) {
			switch (data) {
			case "Risk Category":
				
				uiValue = reviewPage.getRiskCategoryValue();
				
				break;
			case "Strategy Name":
				
				uiValue = reviewPage.getStrategyNameValue();
				
				break;
			case "Strategy Code":
				
				uiValue = reviewPage.getStrategyCodeValue();
				
				break;
			case "Research Rating":
				
				uiValue = reviewPage.getResearchRatingValue();
				
				break;
			case "Strategy Minimum":
				
				uiValue = reviewPage.getStrategyMinimumValue();
				
				break;
			case "Exception Minimum":
				
				uiValue = reviewPage.getExceptionMinimumValue();
				
				break;
			case "Withdrawal/Rebalance Minimum":
				
				uiValue = reviewPage.getWithdrawalRebalanceMinimumValue();
				
				break;
			case "Status":
				
				uiValue = reviewPage.getStrategyStatus();
				
				break;
			case "Premium Fee Eligible":
				
				uiValue = reviewPage.getPremiumEligibleValue();
				
				break;
			case "Concord Fee Eligible":
				
				uiValue = reviewPage.getConcordFeeEligibleValue();
				
				break;
			case "Node ID - Bundled":
				
				uiValue = reviewPage.getBundledNodeIDValue();
				
				break;
			case "Assets":
				
				uiValue = reviewPage.getUnbundledNodeIDValues();
				
				break;
			case "Inception Date_ignore":
				
				uiValue = reviewPage.getInceptionDateIgnore();
				
				break;
			case "Premium Fee Eligible2":
				
				uiValue = reviewPage.getPremiumEligibleValue();
				
				break;
			case "Start Date_ignore":
				
				uiValue = reviewPage.getStartDateIgnoreValue();
				
				break;
			case "IS Manager Profile Available":
				
				uiValue = reviewPage.getIsManagerProfileValue();
				
				break;
			case "Deleted":
				
				uiValue = reviewPage.getDeletedValue();
				
				break;
			case "Alternatives Strategy Code_ignore":
				
				uiValue = reviewPage.getAlternativesStrategyCodeValue();
				
				break;
			case "Proxy Manager":
				
				uiValue = reviewPage.getProxyManagerValue();
				
				break;
			case "Proxy Address1":
				
				uiValue = reviewPage.getProxyAddress1Value();
				
				break;
			case "Proxy Address2":
				
				uiValue = reviewPage.getProxyAddress2Value();
				
				break;
			case "Proxy Address3":
				
				uiValue = reviewPage.getProxyAddress3Value();
				
				break;
			case "Proxy Address4":
				
				uiValue = reviewPage.getProxyAddress4Value();
	
				break;
			case "Proxy City":
				
				uiValue = reviewPage.getProxyCityValue();
				
				break;
			case "Proxy State":
				
				uiValue = reviewPage.getProxyStateValue();
				
				break;
			case "Proxy Zipcode":
				
				uiValue = reviewPage.getProxyZipCodeValue();
				
				break;
			case "Voluntary Reorg Manager":
				
				uiValue = reviewPage.getVoluntaryReorgManagerValue();
				
				break;
			case "Voluntary Reorg Address1":
				
				uiValue = reviewPage.getVoluntaryReorgAddress1Value();
				
				break;
			case "Voluntary Reorg Address2":
				
				uiValue = reviewPage.getVoluntaryReorgAddress2Value();
				
				break;
			case "Voluntary Reorg Address3":
				
				uiValue = reviewPage.getVoluntaryReorgAddress3Value();
				
				break;
			case "Voluntary Reorg Address4":
				
				uiValue = reviewPage.getVoluntaryreorgAddress4Value();
	
				break;
			case "Voluntary Reorg City":
				
				uiValue = reviewPage.getVoluntaryReorgCityValue();
				
				break;
			case "Voluntary Reorg State":
				
				uiValue = reviewPage.getVoluntaryReorgStateValue();
				
				break;
			case "Voluntary Reorg Zipcode":
				
				uiValue = reviewPage.getVoluntaryReorgZipcodeValue();
				
				break;
			case "Interim Manager":
				
				uiValue = reviewPage.getInterimManagerValue();
				
				break;
			case "Interim Address1":
				
				uiValue = reviewPage.getInterimAddress1Value();
				
				break;
			case "Interim Address2":
				
				uiValue = reviewPage.getInterimAddress2Value();
				
				break;
			case "Interim Address3":
				
				uiValue = reviewPage.getInterimAddress3Value();
				
				break;
			case "Interim Address4":
				
				uiValue = reviewPage.getInterimAddress4Value();
	
				break;
			case "Interim City":
				
				uiValue = reviewPage.getInterimCityValue();
				
				break;
			case "Interim State":
				
				uiValue = reviewPage.getInterimStateValue();
				
				break;
			case "Interim Zipcode":
				
				uiValue = reviewPage.getInterimZipcodeValue();
				
				break;
			
	
		default:
			uiValue = "NotChanged";
			break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
	return uiValue;
	}
	
	@Then("^User should be able to see Benchmark value matching as per value in DB in Update SMA Access Review Page with (.+)$")
    public void user_should_be_able_to_see_benchmark_value_matching_as_per_value_in_db_in_update_sma_access_review_page_with(String mandatorydetails) throws SQLException {
		String primaryBenchmarkValue = reviewPage.getPrimaryBenchmarkValue();
		//System.out.println("CreateSMASingleAccessStrategyReviewStepdef::"+primaryBenchmarkValue);
		String defaultBenchmarkName ="";
		defaultbenchmarkcount = 0;
		if(primaryBenchmarkValue.contains(",")) {
			Reporter.addStepLog("In SMA Single Access - Default Benchmark cannot have two Benchmarks associated");
			defaultbenchmarkcount++;
		}
		else {
			String[] data = primaryBenchmarkValue.split("-#-");
			defaultBenchmarkName = data[2];
		}
		
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreateSMASingleAccess.xlsx";
		String sheetName = "";
		int rowIndex;
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet;
		//get DB Query
		sheetName = "Query";
		sheet = exlObj.getSheet(sheetName);
		String SQLquery = (String) exlObj.getCellData(sheet, 1, 1);
		String labelname = (String) exlObj.getCellData(sheet, 1, 2);
		
		
		if (mandatorydetails.contains("Test")) {
			sheetName = "Test";
			mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		}
		
		//get investment style name
		sheet = exlObj.getSheet(sheetName);
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, mandatorydetails);
		String investmentStyleName = (String) exlObj.getCellData(sheet, rowIndex, 2);
		
		pmdb.DBConnectionStart();
		SQLquery = SQLquery.replace("@data", "'"+investmentStyleName+"'");
		ResultSet rs;
		rs= DBManager.executeSelectQuery(SQLquery);
		String dbDataIterator = null;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			
		 }
		pmdb.DBConnectionClose();
		exlObj.closeWorkBook();
		
		//comparing only Benchmark Name as Percentage will be 100 for default
		if(dbDataIterator.equals(defaultBenchmarkName)) {
			Reporter.addStepLog("Default Benchmark Name Value displayed in Review Page matches with Value in DB");
		}
		else {
			defaultbenchmarkcount++;
			Reporter.addStepLog("Default Benchmark Name Value displayed in Review Page does not match with Value in DB");
		}
    }
	
	@And("^check if Default value is not same as Value in DB$")
    public void check_if_default_value_is_not_same_as_value_in_db() {
		System.out.println("-------------------");
		System.out.println(CreateSMASingleAccessStrategyBenchmarkStepdef.defaultbenchmarkcount);
		System.out.println(CreateSMASingleAccessStrategyReviewStepdef.defaultbenchmarkcount);
		System.out.println(UpdateSMASingleAccesstrategyViewDetailsStepDef.defaultbenchmarkcount);
		System.out.println(UpdateSMASingleAccessStrategyBenchmarkStepDef.defaultbenchmarkcount);
		System.out.println(UpdateSMASingleAccessStrategyReviewStepDef.defaultbenchmarkcount);
		
		
		
		if(CreateSMASingleAccessStrategyBenchmarkStepdef.defaultbenchmarkcount + CreateSMASingleAccessStrategyReviewStepdef.defaultbenchmarkcount + UpdateSMASingleAccesstrategyViewDetailsStepDef.defaultbenchmarkcount + UpdateSMASingleAccessStrategyBenchmarkStepDef.defaultbenchmarkcount + UpdateSMASingleAccessStrategyReviewStepDef.defaultbenchmarkcount > 0) {
        	Assert.fail("Default value not populated in one of the pages");
        }
    }
}
