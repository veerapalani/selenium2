package qa.unicorn.ad.productmaster.webui.stepdefs;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.DocumentLinkPage;
import qa.unicorn.ad.productmaster.webui.pages.GlobalSearchPage;
import qa.unicorn.ad.productmaster.webui.pages.LoginPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.framework.utils.Action;

public class CreateDocumentLinkStepDef 
{

	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ViewDocumentLinkPage"));
	DocumentLinkPage documentLink = new DocumentLinkPage();
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
//	String pageURL=property.getProperty("url_PM")+"#/documentLink";
//	String pageURL2 = property.getProperty("url_PM")+"#/documentLink";
	List<WebElement> listOfElements = new ArrayList<WebElement>();
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	String sheetName = "";
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	int rowIndex,cellIndex;
	WebElement myElement,myElement2;
	String myValue;
	
	 @And("^User should be able to go to Document Link page$")
	    public void user_should_be_able_to_go_to_document_link_page() throws Throwable {
	        Assert.assertTrue(action.getCurrentURL().toLowerCase().contains("documentlink"));
	        Reporter.addStepLog("We are in the document link page");
	        Reporter.addScreenCapture();
	    }
	 
	 @Then("^User should be able to see the Time Stamp on the Document Link page$")
	    public void user_should_be_able_to_see_the_time_stamp_on_the_document_link_page() throws Throwable {
	        action.getElement("Time Stamp").isDisplayed();
	        Reporter.addStepLog("Able to see Time Stamp");
	        Reporter.addScreenCapture();
	    }
	 
	 @Then("^User should be able to see the Enter Document Links Header on Document Link page$")
	    public void user_should_be_able_to_see_the_enter_document_links_header_on_document_link_page() throws Throwable {
		 action.getElement("Enter Document Links Header").isDisplayed();
	        Reporter.addStepLog("Able to see Enter Document Links Header");
	        Reporter.addScreenCapture();
	    }
	 
	 @Then("^User should be able to see the Strategy|Name of the program selected on the Document Link page$")
	    public void user_should_be_able_to_see_the_strategyname_of_the_program_selected_on_the_document_link_page() throws Throwable {
		 action.getElement("Strategy|Program Name").isDisplayed();
	        Reporter.addStepLog("Able to see Strategy|Program Name");
	        Reporter.addScreenCapture();
	    }
	

	    @Then("^User should be able to see the Add Another Document Link on the View Document Link page$")
	    public void user_should_be_able_to_see_the_add_another_document_link_on_the_view_document_link_page() throws Throwable {
	        Assert.assertTrue(action.getElement("Add Another Document").isDisplayed());
	        Reporter.addStepLog("Able to see Add Another Document Link");
	        Reporter.addScreenCapture();
	    }
	
	@And("^User clicks on Previous Button on Document Link Page$")
    public void user_clicks_on_previous_button_on_manager_document_link_page() throws Throwable {
        action.click(action.getElement("Previous Button"));
        Reporter.addStepLog("clicked on Previous Button");
    }
	
	
	@And("^User enters all the manadtory attributes in the Document Link Page$")
    public void user_enters_all_the_manadtory_attributes_in_the_document_link_page() throws Throwable {
		String elementValue="doc code for creating new Strategy";
		String elementKey="return document.querySelector('wf-input').shadowRoot.querySelector('wf-tooltip div div input')";
		action.sendkeysClipboard((WebElement) action
				.executeJavaScript(elementKey),elementValue+Calendar.getInstance().getTimeInMillis());
		 Reporter.addScreenCapture();
    }
	
	
    @Then("^user should be able to see the following attributes on Doc Link page$")
    public void user_should_be_able_to_see_the_following_attributes_on_doc_link_page(List<String> attributes) throws Throwable {
    	listOfElements = action.getElements("Attributes_Doc Link");
        for(int i=0;i<attributes.size();i++)
     	   {
        	documentLink.verifyTextInListOfElements(attributes.get(i), listOfElements);
     	   Reporter.addStepLog("verified for "+attributes.get(i)+" attribute");
     	   }
    }
    @Then("^User should be navigated to Add Document Link Page$")
    public void user_should_be_navigated_to_add_document_link_page() throws Throwable {
        String actualurl=action.getCurrentURL();
        String Expectedurl=SSOLoginPage.URL+"#/documentLink";
        Assert.assertEquals(actualurl,Expectedurl);
        Reporter.addScreenCapture();
    }
   
    @And("^User clicks on the Next Button on View Doc Link Page$")
    public void user_clicks_on_the_next_button_on_view_doc_link_page() throws Throwable {
        action.click(action.getElement("Next Button"));
        Reporter.addStepLog("clicked on Next Button in document link page");
    }
    
    @And("^User clicks on Add Another Document Link Button on View Document Link Page$")
    public void user_clicks_on_add_document_link_button_on_view_document_link_page() throws Throwable {
    	myElement = (WebElement)action.getElementByJavascript("Add Another Document Link");
    	if(myElement!=null) {
    	action.click(myElement);
        Reporter.addStepLog("clicking on Add Another Document Link Button");
    	}
    }
    
    @And("^User enters the valid values in all the fields of document link$")
    public void user_enters_the_valid_values_in_all_the_fields_of_document_link(List<String> attribute) throws Throwable {
    	sheet = exlObj.getSheet("Valid");
    	for (int i=0;i<attribute.size();i++) {
		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, "Valid_Data_Mandatory");
		cellIndex = exlObj.getCellIndexByCellValue(sheet, 0, attribute.get(i));
		if(attribute.get(i).equalsIgnoreCase("Document Type")) {
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"wf-select[label='Type']\").shadowRoot.querySelector('button')");
			action.scrollToElement(myElement);
			action.click(myElement);
			myElement2 = (WebElement)action.executeJavaScript("return document.querySelector(\"wf-select[label='Type']\").shadowRoot.querySelector(\"li[data-value='\\\""+(String) exlObj.getCellData(sheet, rowIndex, cellIndex)+"\\\"']\")");
			action.click(myElement2);	
		}
		else if(attribute.get(i).equalsIgnoreCase("Comment")) {
			myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"[label='"+attribute.get(i)+"']\").shadowRoot.querySelector('textarea')");
			action.sendkeysClipboard(myElement,(String) exlObj.getCellData(sheet, rowIndex, cellIndex)+Calendar.getInstance().getTimeInMillis());
		}
		else {
		myElement = (WebElement)action.executeJavaScript("return document.querySelector(\"[label='"+attribute.get(i)+"']\").shadowRoot.querySelector('input')");
		
		action.sendkeysClipboard(myElement,(String) exlObj.getCellData(sheet, rowIndex, cellIndex)+Calendar.getInstance().getTimeInMillis()); 
		}
    }
    
  }

    @Then("^User clicks on Add Document Link$")
    public void user_clicks_on_add_document_link() throws Throwable {
    	action.click(action.getElement("Add Document Link"));
        Reporter.addStepLog("clicking on Add Document Link");
    }
    
    @Then("^user should be able to see the following values in the following dropdown in Document Link page$")
    public void user_should_be_able_to_see_the_following_values_in_the_following_dropdown_in_document_link_page(List<List<String>> attributeValuePair) throws Throwable {
    	for (int i = 0; i < attributeValuePair.size(); i++) {
			listOfElements = documentLink.findElementsByDynamicXpath(
					"//wf-select[@label='" + attributeValuePair.get(i).get(0) + "']/wf-select-option");
			String[] options = attributeValuePair.get(i).get(1).split(",");
			for (int j = 0; j < options.length; j++) {
				Assert.assertEquals(listOfElements.get(j).getAttribute("name"), options[j]);
				Reporter.addStepLog(
						"verified that " + options[j] + " is present in " + attributeValuePair.get(i).get(0));
			}
		}   
    }
    
    @Then("^User should not be able to see any error message while updating the following attributes with following values in Document Link page$")
    public void user_should_not_be_able_to_see_any_error_message_while_updating_the_following_attributes_with_following_values_in_document_link_page(List<List<String>> attributeValuePair) throws Throwable {
    	Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Invalid_Special_Character_Message");
			Assert.assertFalse(action.getPageSource().contains(message));
			Reporter.addStepLog("verified that there is no error message for " + attributeValuePair.get(i).get(0));
		}
    }
    
    @Then("^User should be able to see the Invalid Special Character Message while updating with the following values in following attributes in Document Link page$")
    public void user_should_be_able_to_see_the_invalid_special_character_message_while_updating_with_the_following_values_in_following_attributes_in_document_link_page(List<List<String>> attributeValuePair) throws Throwable {
    	Thread.sleep(2000);
		for (int i = 0; i < attributeValuePair.size(); i++) {
			myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"wf-input[label='"
					+ attributeValuePair.get(i).get(0) + "']\").shadowRoot.querySelector('input')");
			action.clear(myElement);
			action.sendkeysClipboard(myElement, attributeValuePair.get(i).get(1));
			myElement.sendKeys(Keys.ENTER);
			String message = Action.getTestData("Invalid_Special_Character_Message");
			Assert.assertFalse(action.getPageSource().contains(message));
			Reporter.addStepLog("verified that there is no error message for " + attributeValuePair.get(i).get(0));
		}
    }
    
    @Then("^User should be able to see the Add Document Link in Document Link page$")
    public void user_should_be_able_to_see_the_add_document_link_in_document_link_page() throws Throwable {
        Assert.assertTrue(action.getElement("Add Document Link Header").isDisplayed());
        Reporter.addStepLog("verified that Add Document Link header is present");
        Reporter.addScreenCapture();
    }
    
    @Then("^Following attributes should be resetted to default values after clicking on reset button in Document Link page$")
    public void following_attributes_should_be_resetted_to_default_values_after_clicking_on_reset_button_in_document_link_page(List<String> attribute) throws Throwable {
    	for(int i=0;i<attribute.size();i++) {
			 myElement =  documentLink.findElementByDynamicXpath("//*[@label='"+attribute.get(i)+"']");
			 myValue = myElement.getAttribute("value");
			 if(attribute.get(i).equals("Comment"))
				 {myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
							+ attribute.get(i) + "']\").shadowRoot.querySelector('textarea')");}
			 else
			 { myElement2 = (WebElement) action.executeJavaScript("return document.querySelector(\"[label='"
						 + attribute.get(i) + "']\").shadowRoot.querySelector('input')");}
			 action.sendkeysClipboard(myElement2, documentLink.getCurrentTimeStamp());
			 Reporter.addStepLog("sent random keys to "+attribute.get(i));
			 action.click(action.getElement("Reset Button"));
			 Reporter.addStepLog("clicking on reset button");
			 Thread.sleep(2000);
			 myElement =  documentLink.findElementByDynamicXpath("//*[@label='"+attribute.get(i)+"']");
			 Assert.assertEquals(myElement.getAttribute("value"), myValue);
			 Reporter.addStepLog("validated that the value for "+attribute.get(i)+" is getting resetted");
			 
		 }
		 Reporter.addStepLog("validated the functionality of reset button");
    }
    
    @Then("^The following attributes on Document Link page should be marked as mandatory$")
    public void the_following_attributes_on_document_link_page_should_be_marked_as_mandatory(List<String> items) throws Throwable {
    	for (int i = 0; i < items.size(); i++) {
			myElement = documentLink.findElementByDynamicXpath("//*[@label='" + items.get(i) + "']");
			Assert.assertEquals(action.getAttribute(myElement, "required"), "true");
			Reporter.addStepLog("validated that " + items.get(i) + " is mandatory");
		}
		Reporter.addScreenCapture();
    }
    
 
    @And("^User clicks on Back Link on Document Link Page$")
    public void user_clicks_on_back_link_on_document_link_page() throws Throwable {
        action.click(action.getElement("Back Link"));
        Reporter.addStepLog("clicked on Back Link");
    }
}
