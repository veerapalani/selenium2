package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.fail;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;
import qa.unicorn.ad.productmaster.webui.pages.UpdateSMASingleAccessStrategyEnterStrategyDetailsPage;

public class UpdateSMASingleAccessStrategyEnterStrategyDetailsStepDef {

	
	UpdateSMASingleAccessStrategyEnterStrategyDetailsPage strategyDetailsPage = new UpdateSMASingleAccessStrategyEnterStrategyDetailsPage("AD_PM_UpdateSMASingleAccessStrategyEnterStrategyDetailsPage");
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdateStrategy2418.xlsx";
	
	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;
	String sheetName;
	String label, attributeValue, uiValue,dbValue = null;
	
	public static int count;
	
	@And("^User is in Enter Strategy Details Page of Update SMA Single Access flow$")
    public void user_is_in_enter_strategy_details_page_of_update_sma_single_access_flow() {
        Assert.assertTrue(strategyDetailsPage.isUserOnEnterStrategyDetailspage());
    }
	
	@Then("^Stored Values in DB should be prepopulated in Enter Strategy Details Page in Update SMA Single Access Flow$")
    public void stored_values_in_db_should_be_prepopulated_in_enter_strategy_details_page_in_update_sma_single_access_flow() {
		sheetName = "Conversion_Validation";
		   sheet = exlObj.getSheet(sheetName);
		   int rownum = 1;
		   count = 0;
		   label = (String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if((label == "") ||(label.contains("Node ID")) )
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore")) {
							rownum++;
			    			label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if((label == "") ||(label.contains("Node ID")))
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromEnterStrategyDetailsPage(label);
						dbValue =(String) exlObj.getCellData(sheet, rownum, 3).toString();
						if(dbValue.equals(attributeValue)) {
							exlObj.setCellData(sheet, rownum, 5, attributeValue);
						}else {
							exlObj.setCellData(sheet, rownum, 5, attributeValue+"-UI Value is not same as Stored Value in DB");
							
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							count++;
							
						}
						
							rownum++;
							label = (String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if((label == "") ||(label.contains("Node ID")))
								label = "isEmpty";
					
					}
			}
			
//			if(count > 0) {
//				Assert.fail("Prepopulated Values are not same as values stored in DB");
//			}
			Reporter.addCompleteScreenCapture();
			//Reporter.addStepLog("In Enter Strategy Details Page Values Stored in DB are Populated in UI");
			exlObj.closeWorkBook();
    }

	private String getDataFromEnterStrategyDetailsPage(String data) {
		switch (data) {
		case "Risk Category":
			
			uiValue = strategyDetailsPage.getRiskCategoryValue();
			
			break;
		case "Strategy Name":
			
			uiValue = strategyDetailsPage.getStrategyNameValue();
			
			break;
		case "Strategy Code":
			
			uiValue = strategyDetailsPage.getStrategyCodeValue();
			
			break;
		case "Research Rating":
			
			uiValue = strategyDetailsPage.getResearchRatingValue();
			
			break;
		case "Strategy Minimum":
			
			uiValue = strategyDetailsPage.getStrategyMinimumValue();
			
			break;
		case "Exception Minimum":
			
			uiValue = strategyDetailsPage.getExceptionMinimumValue();
			
			break;
		case "Withdrawal/Rebalance Minimum":
			
			uiValue = strategyDetailsPage.getWithdrawalRebalanceMinimumValue();
			
			break;
		case "Status":
			
			uiValue = strategyDetailsPage.getStrategyStatus();
			
			break;
		case "Premium Fee Eligible":
			
			uiValue = strategyDetailsPage.getPremiumEligibleValue();
			
			break;
		case "Concord Fee Eligible":
			
			uiValue = strategyDetailsPage.getConcordFeeEligibleValue();
			
			break;
		case "IS Manager Profile Available":
			
			uiValue = strategyDetailsPage.getIsManagerProfileValue();
			
			break;
		case "Deleted":
			
			uiValue = strategyDetailsPage.getDeletedValue();
			
			break;
		default:
				uiValue = "NotChanged";
				break;
			}
		if((uiValue == null) || (uiValue.isEmpty()))
			uiValue = "isEmpty";
	
	return uiValue;
	}
	
	@And("^User clicks on Next in Enter Strategy Details page in Update SMA Single Acces Flow$")
    public void user_clicks_on_next_in_enter_strategy_details_page_in_update_sma_single_acces_flow() {
        strategyDetailsPage.clickOnNext();
    }
}
