package qa.unicorn.ad.productmaster.webui.stepdefs;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.HOApprovalViewPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.ad.productmaster.webui.pages.UpdateStrategyPage;

public class HOApprovalViewStepDef {
	
	WebDriverWait wait = new WebDriverWait(WebDriverManager.getDriver(), 20);
	String expectedColorCode;
	String xpath, myValue;
	Select dropdown;
	Boolean myFlag;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	String pageURL = SSOLoginPage.URL + "#/smaAccess/view/2053002";
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_HOApprovalPage"));
	HOApprovalViewPage reviewPage = new HOApprovalViewPage("AD_PM_HOApprovalViewPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/PendingHOApproval.xlsx";
	String sheetName = "";
	XSSFSheet sheet;
	int rowIndex, cellIndex;
	String label, attributeValue, uiValue,dbValue = null;
	
	WebElement myElement, myElement1, myElement2;
	List<WebElement> listOfElements, listOfElements2 = new ArrayList<WebElement>();

	
    @When("^user clicks on the HO Approval tab directly through the accordion$")
    public void user_clicks_on_the_ho_approval_tab_directly_through_the_accordion() throws Throwable {
    	myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"#wftabs > brml-tab-button:nth-child(12)\")");
    	action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(5000);
		myElement.click();
		Reporter.addStepLog("clicked on first suggestion ");

    }
  /*  @Then("^the list of strategies must appear $")
    public void the_list_of_strategies_must_appear() throws Throwable {
    	myElement = (WebElement) action.executeJavaScript("return document.querySelector(\"#ag-grid-wrapper > div > div > div.ag-root-wrapper-body.ag-layout-auto-height.ag-focus-managed > div.ag-root.ag-unselectable.ag-layout-auto-height > div.ag-body-viewport.ag-layout-auto-height.ag-row-no-animation > div.ag-center-cols-clipper > div > div > div.ag-row.ag-row-even.ag-row-level-0.ag-row-position-absolute.ag-row-first.ag-row-focus.ag-row-hover > div.ag-cell.ag-cell-not-inline-editing.ag-cell-auto-height.ag-cell-value.ag-cell-focus.ag-column-hover");
    	action.scrollToElement(myElement);
		action.highligthElement(myElement);
		Thread.sleep(5000);
		myElement.click();
		Reporter.addStepLog("clicked on first suggestion ");
    	//document.querySelector("#ag-grid-wrapper > div > div > div.ag-root-wrapper-body.ag-layout-auto-height.ag-focus-managed > div.ag-root.ag-unselectable.ag-layout-auto-height > div.ag-body-viewport.ag-layout-auto-height.ag-row-no-animation > div.ag-center-cols-clipper > div > div > div.ag-row.ag-row-even.ag-row-level-0.ag-row-position-absolute.ag-row-first.ag-row-focus.ag-row-hover > div.ag-cell.ag-cell-not-inline-editing.ag-cell-auto-height.ag-cell-value.ag-cell-focus.ag-column-hover")
    }
    
    }*/
    @Then("^user should be able to see that the Label \"([^\"]*)\" is changed to \"([^\"]*)\" on HO Approval View page$")
    public void user_should_be_able_to_see_that_the_label_something_is_changed_to_something_on_ho_approval_view_page(String strArg1, String strArg2) throws Throwable {
    	reviewPage.CheckingPMPTitle();
    }
    
	@Then("^Values for Attributes in View Page of HOApproval flow should match the values for attributes stored in DB$")
    public void values_for_attributes_in_view_page_of_hoapproval_flow_should_match_the_values_for_attributes_stored_in_db() throws IOException {
		sheetName = "Conversion_Validation";
		   //sheet = exlObj.getSheet(sheetName);
		   int count = 0;
		   int rownum = 1;
		   label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
				   //(String) exlObj.getCellData(sheet, rownum, 0);
		   
		   if(label == "")
				label = "isEmpty";
			while (label != "isEmpty") {
													
					if(label.contains("ignore") || label.contains("NIVDP")) {
							rownum++;
			    			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
			    					//(String) exlObj.getCellData(sheet, rownum, 0).toString();
			    			
			    			if(label == "")
			    				label = "isEmpty";
					}else {
						
						attributeValue = getDataFromReviewPage(label);
						dbValue = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 3);
								//(String) exlObj.getCellData(sheet, rownum, 3).toString();
						
						if(dbValue.equals(attributeValue)) {
							//exlObj.setCellData(sheet, rownum, 4, attributeValue);
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 4, attributeValue);
						}else {
							//exlObj.setCellData(sheet, rownum, 4, attributeValue+" -UI Value is not same as Stored Value in DB");
							PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rownum, 4, attributeValue+" -UI Value is not same as Stored Value in DB");
							Reporter.addEntireScreenCaptured();
							Reporter.addStepLog("For Attribute - "+label+" UI Value Prepopulated is not same as Stored Value in DB");
							count++;
							
						}
							rownum++;
							label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rownum, 0);
									//(String) exlObj.getCellData(sheet, rownum, 0).toString();
							
							if(label == "")
								label = "isEmpty";
					
					}
			}
			if(count > 0) {
				Assert.fail("Prepopulated Values are not same as values stored in DB");
			}
			Reporter.addCompleteScreenCapture();
			Reporter.addStepLog("In Review Page Values Stored in DB are Populated in UI");
			//exlObj.closeWorkBook();
    }

    private String getDataFromReviewPage(String data) {
	    	switch (data) {
				case "Risk Category":
					
					uiValue = reviewPage.getRiskCategoryValue();
					
					break;
				case "PIV Style":
					
					uiValue = reviewPage.getPIVStyleValue();
					
					break;
				case "Geographic Indicator":
					
					uiValue = reviewPage.getGeographicIndicatorValue();
					
					break;
				case "Strategy Name":
					
					uiValue = reviewPage.getStrategyNameValue();
					
					break;
				case "Strategy Code":
					
					uiValue = reviewPage.getStrategyCodeValue();
					
					break;
				case "Balanced Allocation":
					
					uiValue = reviewPage.getBalancedAllocationValue();
					
					break;
				case "Concentrated Strategy Indicator_radiobutton":
					
					uiValue = reviewPage.getConcentratedStrategyIndicatorValue();
					
					break;
				case "Structured Products Strategy_radiobutton":
					
					uiValue = reviewPage.getStructuredProductsStrategyValue();
					
					break;
				case "Margins":
					
					uiValue = reviewPage.getMarginEligibleValue();
					
					break;
				case "Status":
					
					uiValue = reviewPage.getStrategyStatusValue();
					
					break;
				case "Concord Eligible(NEW)":
					
					//uiValue = reviewPage.getConcordEligibleValue();
					
					break;
				case "Options Approval Level Code":
					
					//uiValue = reviewPage.getOptionalApprovalLevelCodeValues();
					
					break;
				case "Hedge Core Indicator_radiobutton":
					
					uiValue = reviewPage.getHedgeCoreIndicatorValue();
					
					break;
				case "Style Pairing Code":
					
					uiValue = reviewPage.getStylePairingCodeValue();
					
					break;
				case "Risk Tolerance":
					
					//uiValue = reviewPage.getRiskToleranceValue();
					
					break;
				case "Portfolio Strategy Group Code":
					
					//uiValue = reviewPage.getPortfolioStrategyGroupCodeValue();
					
					break;
				case "Investment Style":
					
					uiValue = reviewPage.getInvestmentStyleValue();
					
					break;
				case "Primary Benchmark":
					
					uiValue = reviewPage.getPrimaryBenchmarkValue();
					
					break;
				default:
					
					uiValue = "NotChanged";
					
					break;
		}
		if(uiValue.equals("—"))
			uiValue = "isEmpty";
	
		return uiValue;
	}

	@And("^User is in View Strategy Page in HOApproval flow$")
    public void user_is_in_view_strategy_page_in_hoapproval_flow() {
        Assert.assertTrue(reviewPage.isUserOnReviewPHOAStrategyPage());
        
    }
	
	@Then("^User should be able to see benchmarks are sorted in descending order in Review Page in HO Approval Flow for (.+)$")
    public void user_should_be_able_to_see_benchmarks_are_sorted_in_descending_order_in_review_page_in_ho_approval_flow_for(String mandatorydetails) throws SQLException, IOException {
		
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
		
		//To get the PHOA Strategy - Strategy Code
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		String strategyCode = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, 1);
		
		//get Benchmark details From DB
    	String benchmark,benchmarkPercentage = "";
		String benchmarkCategory = reviewPage.getBenchmarkCategoryValue();
		
    	sheetName = "Query";
    		
    		String SQLQuery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 4, 1);
    		String label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 4, 2);
			benchmark = getBenchmarkDataFromDB(strategyCode, SQLQuery, label, benchmarkCategory);
			
			SQLQuery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 5, 1);
    		label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 5, 2);
			benchmarkPercentage = getBenchmarkDataFromDB(strategyCode, SQLQuery, label, benchmarkCategory);
			
		
		
		HashMap<String, Float> customBenchmarkMap = new HashMap<String, Float>();
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		
		if(benchmark.contains(",")) {
			String[] customBenchmark = benchmark.split(",");
			String[] customBenchmarkPercentage = benchmarkPercentage.split(",");		
			int size = customBenchmark.length;
			
			for (int i = 0; i < size; i++) {
				customBenchmarkMap.put(customBenchmark[i], Float.parseFloat(customBenchmarkPercentage[i]));
			}
			
			sortedHashMap = sortCustomBenchmarks(customBenchmarkMap);
		}else {
			sortedHashMap.put(benchmark, Float.parseFloat(benchmarkPercentage));
		}
		
		String benchmarkfromUI;
		Float percentagefromUI;
		int j = 0;
		for (String benchmarkKey : sortedHashMap.keySet()) {
			
			benchmarkfromUI = reviewPage.getBenchmarkithValuefromUI(j);
			percentagefromUI = reviewPage.getPercentageithValuefromUI(j);
			
			Assert.assertTrue(percentagefromUI.equals(sortedHashMap.get(benchmarkKey)));
			Assert.assertTrue(benchmarkfromUI.equals(benchmarkKey));
			j++;
			
		}
    }
	
	private String getBenchmarkDataFromDB(String strategyCode, String SQLquery, String labelname, String benchmarkCategory) throws SQLException, IOException {
    	pmdb.DBConnectionStart();

    	String category = benchmarkCategory;
    	String dbDataIterator = "testNull";
    	ResultSet rs;
    	
    	int cellnum = 1;
    	
    	ArrayList<String> tempData = new ArrayList<String>();
    	
				dbDataIterator = "testnull";
				SQLquery = SQLquery.replace("@data", "'"+strategyCode+"'");
				rs= DBManager.executeSelectQuery(SQLquery);
				
		
				while(rs.next()) {
					
						dbDataIterator = rs.getString(labelname);
						if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    					dbDataIterator = "isEmpty";
		    			}
						
						tempData.add(dbDataIterator);
						
				 }
				//to handle Zero records from DB 
				if(dbDataIterator.equalsIgnoreCase("testnull")) {
					dbDataIterator = "isEmpty";
				}
				
				//to handle multiple values for same column
				if(tempData.size() > 1) {
					dbDataIterator = "";
					for (String G : tempData) {
							dbDataIterator = dbDataIterator+G+",";
					}
					dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
						if(category.equalsIgnoreCase("default")) {
							dbDataIterator = dbDataIterator.split(",")[0];
						}
					
				}
				tempData.clear();
	
		
		pmdb.DBConnectionClose();
		
		return dbDataIterator;
		
	}
	private LinkedHashMap<String, Float> sortCustomBenchmarks(HashMap<String, Float> customBenchmarkMap) {
		Set<Entry<String, Float>> customBenchmarkEntrySet = customBenchmarkMap.entrySet();
		List<Entry<String, Float>> entryList = new ArrayList<Entry<String, Float>>(customBenchmarkEntrySet);

		//sort based on benchmark names first to handle Equal Percentage scenario
		Collections.sort(entryList, (o1, o2) -> o1.getKey().trim().compareTo(o2.getKey().trim()));
		
		//sort based on benchmark percentage
		Collections.sort(entryList, (o1, o2) -> {
			if(o1.getValue() > o2.getValue()) {
				return -1;
			}else if(o1.getValue() < o2.getValue()) {
				return 1;
			}
			return 0;
		});
		
		/*
		 * Collections.sort(entryList, new Comparator<Entry<String, Float>>() {
			@Override
			public int compare(Entry<String, Float> o1, Entry<String, Float> o2) {
				if(o1.getValue() > o2.getValue()) {
					return -1;
				}else if(o1.getValue() < o2.getValue()) {
					return 1;
				}
				return 0;
			}
		});*/

		// Using LinkedHashMap to keep entries in sorted order
		LinkedHashMap<String, Float> sortedHashMap = new LinkedHashMap<String, Float>();
		for (Entry<String, Float> entry : entryList) {
			sortedHashMap.put(entry.getKey(), entry.getValue());
		}

		/*
		  for (String countryKey : sortedHashMap.keySet()) {
		  System.out.println(countryKey + " -> " + sortedHashMap.get(countryKey));
		  
		  }*/
		 
		return sortedHashMap;
	}
	
	@Then("^Number Of Active Strategies field value displayed for \"([^\"]*)\" in UI should be same as the value for active strategies in DB for (.+)$")
    public void number_of_active_strategies_field_value_displayed_for_something_in_ui_should_be_same_as_the_value_for_active_strategies_in_db_for(String faSelection, String mandatorydetails) throws Throwable {
        
		sheetName = "Query";
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		mandatorydetails = mandatorydetails+"_"+environment;
		//sheet = exlObj.getSheet(sheetName);
		String SQLQuery,labelname = "";
		switch (faSelection) {
		case "FA":
			SQLQuery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 7, 1);
						//(String) exlObj.getCellData(sheet, 7, 1);
			labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 7, 2);
						//(String) exlObj.getCellData(sheet, 7, 2);
			break;
		case "FA Team":
			SQLQuery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 6, 1);
						//(String) exlObj.getCellData(sheet, 6, 1);
			labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 6, 2);
						//(String) exlObj.getCellData(sheet, 6, 2);
			break;
		default:
			SQLQuery = "";
			break;
		}
		
		Assert.assertTrue(Integer.parseInt(reviewPage.getCommonAttributeValue("Number of Active Strategies")) == (getDBValueOfCountOfStrategieslinkedToFATeam(SQLQuery, labelname)));
		
    }
	private int getDBValueOfCountOfStrategieslinkedToFATeam(String SQLquery, String labelname) throws SQLException {

		String faSelectionValue = reviewPage.getCommonAttributeValue("FA/FA Team");
    	pmdb.DBConnectionStart();
    	String dbDataIterator = "testNull";
    	ResultSet rs;
    	
    	ArrayList<String> tempData = new ArrayList<String>();
    	
				dbDataIterator = "testnull";
				SQLquery = SQLquery.replace("@data", "'"+faSelectionValue+"'");
				rs= DBManager.executeSelectQuery(SQLquery);
				
		
				while(rs.next()) {
					
						dbDataIterator = rs.getString(labelname);
						if(rs.wasNull() || dbDataIterator.isEmpty()) {
		    					dbDataIterator = "isEmpty";
		    			}
						
						tempData.add(dbDataIterator);
						
				 }
				//to handle Zero records from DB 
				if(dbDataIterator.equalsIgnoreCase("testnull")) {
					dbDataIterator = "isEmpty";
				}
				
				//to handle multiple values for same column
				if(tempData.size() > 1) {
					dbDataIterator = "";
					for (String G : tempData) {
							dbDataIterator = dbDataIterator+G+",";
					}
					dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length()-1);
					
				}
				tempData.clear();
	
		
		pmdb.DBConnectionClose();
		
		return Integer.parseInt(dbDataIterator);
		
	
	}


}

