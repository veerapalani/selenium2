package qa.unicorn.ad.productmaster.webui.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.ibm.db2.jcc.am.ac;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.api.stepdefs.ProductMasterDBManager;
import qa.unicorn.ad.productmaster.webui.pages.CreatePMPStrategyConfirmationPage;
import qa.unicorn.ad.productmaster.webui.pages.PMPageGeneric;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

public class CreatePMPStrategyConfirmationStepDef {
	CreatePMPStrategyConfirmationPage confirmationPage = new CreatePMPStrategyConfirmationPage(
			"AD_PM_CreatePMPStrategyConfirmationPage");
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	Action action;
	Process p = null;
	String kafkaPath = "C://PM_SANITYTEST//kafka_2.13-3.2.1//bin//windows";
	String testmucNHLogFilePath, testmucDHLogFilePath = "";
	String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/CreatePMPStrategy.xlsx";
	String mandatorydetails, sheetName = "";
	int rowIndex;
	String strategyCode = null;
	String strategyName, category = "";
	String userinfo = null;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	
	@Then("^User should be able to see Confirmation Page$")
	public void user_should_be_able_to_see_confirmation_page() {
		action.pause(2000);
		Assert.assertTrue(confirmationPage.isConfirmationHeaderDisplayed());
		assertTrue(confirmationPage.isUserOnConfirmatioPage());
		action.pause(2000);
		strategyCode = confirmationPage.getStrategyCode();
		userinfo = "HO_Edit";
	}

	@Then("^Branch User should be able to see (.+) in Confirmation Page$")
	public void branch_user_should_be_able_to_see_in_confirmation_page(String confirmationmessage) {
		assertTrue(confirmationPage.isBranchUserOnConfirmationPage(confirmationmessage));
		strategyName = confirmationPage.getStrategyName();
		userinfo = "Branch User";
	}

	@And("^PMP Strategy should be successfully Created$")
	public void pmp_strategy_should_be_successfully_created() {
		assertTrue(confirmationPage.isStrategyCreatedSuccessfully());
	}

	@And("^(.+) provided during create PMP Strategy should be stored in Data base$")
	public void provided_during_create_pmp_strategy_should_be_stored_in_data_base(String mandatorydetails)
			throws Throwable {
		if(mandatorydetails.contains("Test")) {
			sheetName = "Test";
		}
		String[] temp = null;
		String tName = Thread.currentThread().getName();
		synchronized(tName) {
			mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.toLowerCase();
//			String environment = SSOLoginPage.UIEnvironment.toLowerCase();
//			if(environment.equalsIgnoreCase("dev")) {
//				mandatorydetails = mandatorydetails + "_dev";
//			}
//			if(environment.equalsIgnoreCase("qa")) {
//				mandatorydetails = mandatorydetails + "_qa";
//			}
//			if(environment.equalsIgnoreCase("uat")) {
//				mandatorydetails = mandatorydetails + "_uat";
//			}
			rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
			String excelData;
			List<String> excelDataGiven = new ArrayList<String>();
			int cellnum = 1;
			int i = 1;
			String label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
			if(label == "")
				label = "isEmpty";
			while(label != "isEmpty") {
				excelData = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, rowIndex, i);
				if(excelData == "") {
					excelData = "isEmpty";
					if(label.contains("noemptyvalue"))
						excelData = "Not Defined";
				}
				else if(excelData.equalsIgnoreCase("yes")) {
					excelData = "t";
				}
				else if(excelData.equalsIgnoreCase("no")) {
					excelData = "f";
				}
				else if(excelData.equals("PMP Default")) {
					excelData = "Default";
				}
				else if(label.contains("onlysort")) {
					if(excelData.contains(",")) {
						String[] percentages = excelData.split(",");
						ArrayList<String> percent = new ArrayList<String>();
						for(String E: percentages) {
							temp = E.split("-");
							percent.add(temp[0]);
						}
						Collections.sort(percent);
						excelData = "";
						for(String F: percent) {
							excelData = excelData + F + ":";
						}
					}
				}
				else if(label.contains("Benchmark Name")) {
					if(excelData.contains(",")) {
						String[] benchmarkNames = excelData.split(",");
						// String[] temp = null;
						ArrayList<String> benchmark = new ArrayList<String>();
						for(String G: benchmarkNames) {
							temp = G.split(" - ");
							benchmark.add(temp[1]);
						}
						Collections.sort(benchmark);
						excelData = "";
						for(String H: benchmark) {
							excelData = excelData + H + ":";
						}
					}
					else {
						String[] split2 = excelData.split(" - ");
						excelData = split2[1];
					}
				}
				if(label.contains("ignore")) {
					cellnum++;
					i++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
					if(label == "")
						label = "isEmpty";
				}
				else {
					// Handling Checkboxes
					if(label.contains("specialdata")) {
						if(excelData.contains("f") || excelData.contains("isEmpty")) {
							excelData = "specialfalse";
						}
					}
					excelDataGiven.add(excelData);
					// System.out.println(excelData+"--"+label+ " -Data from Excel");
					cellnum++;
					i++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, 0, cellnum);
					if(label == "")
						label = "isEmpty";
				}
			}
			cellnum = 1;
			pmdb.DBConnectionStart();
			List<String> dbData = new ArrayList<String>();
			String dbDataIterator;
			String replaceData = null;
			// Selecting the Sheet based on User
			switch(userinfo) {
				case "HO_Edit":
					sheetName = "SQLquerywithCode";
					replaceData = strategyCode;
					break;
				case "Branch User":
					sheetName = "SQLquerywithName";
					replaceData = strategyName;
					break;
				default:
					sheetName = "SQLquerywithCode";
					replaceData = strategyCode;
					break;
			}
			ResultSet rs;
			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
			if(label == "")
				label = "isEmpty";
			System.out.println("Testing");
			while(label != "isEmpty") {
				if(label.contains("ignore")) {
					cellnum++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if(label == "")
						label = "isEmpty";
				}
				else {
					dbDataIterator = "testnull";
					ArrayList<String> tempData = new ArrayList<String>();
					String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
					String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
					SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
					System.out.println("For Label -- "+label+" : SQL Query -- "+SQLquery);
					
					rs = DBManager.executeSelectQuery(SQLquery);
					while(rs.next()) {
						dbDataIterator = rs.getString(labelname);
							
							if(rs.wasNull() || dbDataIterator.isEmpty()) {
								System.out.println("Inside null VaLue");
								dbDataIterator = "isEmpty";
								if(label.contains("noemptyvalue"))
									dbDataIterator = "Not Defined";
							}
							
							if(dbDataIterator.isEmpty()) {
								System.out.println("Inside Empty String ");
								dbDataIterator = "isEmpty";
								if(label.contains("noemptyvalue"))
									dbDataIterator = "Not Defined";
							}
							tempData.add(dbDataIterator);
						
							if(label.contains("BenchmarkCategory")) {
							category = dbDataIterator;
							}
					}
					// to handle Zero records from DB
					if(dbDataIterator.equalsIgnoreCase("testnull")) {
						System.out.println("Inside Zero Records");
						dbDataIterator = "isEmpty";
					}
					if(tempData.size() > 1) {
						Collections.sort(tempData);
						dbDataIterator = "";
						for(String G: tempData) {
							dbDataIterator = dbDataIterator + G + ":";
						}
						if(label.contains("Benchmark Name") || label.contains("Percentage_onlysort")) {
							if(category.equalsIgnoreCase("default")) {
								dbDataIterator = dbDataIterator.substring(0, dbDataIterator.length() - 1);
								dbDataIterator = dbDataIterator.split(":")[0];
							}
						}
						tempData.clear();
					}
					if(label.contains("_specialdata")) {
						if(dbDataIterator.equals("f")) {
							dbDataIterator = "specialfalse";
						}
					}
					if(label.equals("BenchmarkCategory")) {
						if(dbDataIterator.contains(":Custom")) {
							dbDataIterator = "Custom";
						}
					}
					dbData.add(dbDataIterator);
					System.out.println("For Label -- "+label+" : DB Data -- "+dbDataIterator);
					cellnum++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if(label == "")
						label = "isEmpty";
				}
			}
			cellnum = 1;
			int listno = 1;
			label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
			if(label == "")
				label = "isEmpty";
			while(label != "isEmpty") {
				if(label.contains("ignore")) {
					cellnum++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if(label == "")
						label = "isEmpty";
				}
				else {
					try {
						//System.out.println(label +" :DB -- "+ dbData.get(listno - 1));
						//System.out.println(label +" :Excel -- "+ excelDataGiven.get(listno - 1));
						String message = label + " :DB -- " + dbData.get(listno - 1) + "::::" + label + " :Excel -- "
								+ excelDataGiven.get(listno - 1) + " -- for Strategy Code -- " + strategyCode;
						assertTrue(dbData.get(listno - 1).equals(excelDataGiven.get(listno - 1)), message);
					}
					catch(Exception e) {
						// Data Base value is not same as value provided
						Reporter.addStepLog("Data Base value is not same as value provided");
					}
					cellnum++;
					listno++;
					label = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 0);
					if(label == "")
						label = "isEmpty";
				}
			}
		}
	}

	@And("^Notification Hub Process is started for create PMP with (.+)$")
	public void notification_hub_process_is_started_for_create_pmp_with(String mandatorydetails) throws IOException {
		String filename = mandatorydetails.split("_")[1];
		testmucNHLogFilePath = System.getProperty("user.dir") + "/temp/topic-NotiHub" + filename + ".log";
		System.out.println(testmucNHLogFilePath);
		FileManager.getFileManagerObj().deleteFile(testmucNHLogFilePath);
		String command = "";
		// String environment =
		// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment.toLowerCase();
		if(environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.QA.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.UAT.OUT.WMAP.TOPIC";
		}
		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier = "ProductMaster";
		command = command + " | find /i \"" + identifier + "\" >>" + testmucNHLogFilePath;
		Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		// Thread.sleep(10000);
	}

	@And("^Data Hub Process is started for create PMP with (.+)$")
	public void data_hub_process_is_started_for_create_pmp_with(String mandatorydetails) throws IOException {
		String filename = mandatorydetails.split("_")[1];
		testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-DataHub" + filename + ".log";
		//String testmucDHLogFilePath = System.getProperty("user.dir") + "/temp/topic-testmucDataHub.log";
		FileManager.getFileManagerObj().deleteFile(testmucDHLogFilePath);
		String command = "";
		// String environment =
		// property.getProperty("ProductMaster_UI_Environment").toLowerCase();
		String environment = SSOLoginPage.UIEnvironment;
		if(environment.equalsIgnoreCase("dev")) {
			command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_dev.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("qa")) {
			command = "kafka-console-consumer --bootstrap-server qa-bk1.kafka.wmap.broadridge.com:19092 --consumer.config \"nh_qa.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.QA.OUT.WMAP.TOPIC";
		}
		if(environment.equalsIgnoreCase("uat")) {
			command = "kafka-console-consumer --bootstrap-server \"uat-bk1.kafka.wmap.broadridge.com:19092,uat-bk2.kafka.wmap.broadridge.com:19092,uat-bk3.kafka.wmap.broadridge.com:19092,uat-bk4.kafka.wmap.broadridge.com:19092,uat-bk5.kafka.wmap.broadridge.com:19092,uat-bk6.kafka.wmap.broadridge.com:19092\" --consumer.config \"nh_uat.properties\" --topic BR.INVESTMENTMANAGEMENT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.UAT.OUT.WMAP.TOPIC";
		}
		// Redirecting to a pipe and applying a filter with identifier as filter value
		String identifier = "Portfolio Management Program";
		command = command + " | find /i \"" + identifier + "\" >>" + testmucDHLogFilePath;
		Reporter.addStepLog("<b>Kafka Command: </b>" + command);
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();
	}

	@And("^a notification is sent to Notification Hub after Create PMP$")
	public void a_notification_is_sent_to_notification_hub_after_create_pmp() throws IOException, InterruptedException {
		Thread.sleep(10000);
		strategyCode = confirmationPage.getStrategyCode();
		strategyName = confirmationPage.getStrategyName();
		FileReader fr = new FileReader(testmucNHLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		String line;
		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;
		while((line = br.readLine()) != null) {
			if(line.contains(strategyCode)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucNHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Strategy Name: </b>" + strategyName);
		Reporter.addStepLog("<b>Strategy Code: </b>" + strategyCode);
		if(line.contains(strategyName)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyName));
		}
		else if(line.contains(strategyCode)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyCode));
		}
		else {
			Assert.fail("No Response from Notification Hub");
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
	}

	@And("^a Payload is sent to Data Hub after Create PMP$")
	public void a_payload_is_sent_to_data_hub_after_create_pmp() throws InterruptedException, IOException {
		Thread.sleep(10000);
		strategyCode = confirmationPage.getStrategyCode();
		strategyName = confirmationPage.getStrategyName();
		FileReader fr = new FileReader(testmucDHLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		String line;
		// String strategyName = CreateStrategyStepDef.strategyName;
		// String message = "\"Operation\":\"CREATE\"";
		// String strategyCode = strategyCode;
		while((line = br.readLine()) != null) {
			if(line.contains(strategyCode)) {
				Action.pause(1000);
				p.destroy();
				// System.out.println("Successful!!!!!!!");
				break;
			}
		}
		Reporter.addStepLog("<b>Notification Stored in: </b>" + testmucDHLogFilePath);
		Reporter.addStepLog("<b>Notification from NH: </b>" + line);
		Reporter.addStepLog("<b>Strategy Name: </b>" + strategyName);
		Reporter.addStepLog("<b>Strategy Code: </b>" + strategyCode);
		if(line.contains(strategyName)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyName));
		}
		else if(line.contains(strategyCode)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyCode));
		}
		else {
			Assert.fail("No Payload is recieved from Data Hub");
		}
		/*
		 * if(line.contains(message)) { Reporter.
		 * addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message
		 * +"</b>"); Assert.assertTrue(line.contains(message)); }
		 */
		p.destroyForcibly();
		br.close();
		fr.close();
	}

	@And("^selected_benchmark_type value should be \"([^\"]*)\" in DB$")
	public void selectedbenchmarktype_value_should_be_something_in_db(String benchmarkType)
			throws SQLException, IOException {
		pmdb.DBConnectionStart();
		String dbDataIterator = "testnull";
		String replaceData = null;
		// Selecting the Sheet based on User
		sheetName = "Query";
		replaceData = strategyCode;
		int cellnum = 2;
		ResultSet rs;
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		rs = DBManager.executeSelectQuery(SQLquery);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
		int count = 1;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			if(rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
		}
		// to handle Zero records from DB
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		assertTrue(dbDataIterator.equalsIgnoreCase(benchmarkType));
		Reporter.addStepLog("Selected Benchmark Type is stored as " + benchmarkType + " in DB");
	}

	@And("^attestation Date value should be autopopulated in DB$")
	public void attestation_date_value_should_be_autopopulated_in_db() throws SQLException, IOException {
		pmdb.DBConnectionStart();
		String dbDataIterator = "testnull";
		String replaceData = null;
		// Selecting the Sheet based on User
		sheetName = "Query";
		replaceData = strategyCode;
		int cellnum = 3;
		ResultSet rs;
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		rs = DBManager.executeSelectQuery(SQLquery);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
		int count = 1;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			if(rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
		}
		// to handle Zero records from DB
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		String date = new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
		assertTrue(date.equals(dbDataIterator));
	}

	@And("^User clicks on Product Master Link in Confirmation Page in PMP Flow$")
	public void user_clicks_on_product_master_link_in_confirmation_page_in_pmp_flow() {
		confirmationPage.clickOnProductMasterLink();
	}

	@And("^FOA Code generated should be unique in DB after PMP Flow$")
	public void foa_code_generated_should_be_unique_in_db_after_pmp_flow() throws SQLException {
		pmdb.DBConnectionStart();
		String dbDataIterator = "testnull";
		String replaceData = null;
		// Selecting the Sheet based on User
		sheetName = "Query";
		replaceData = strategyCode;
		int cellnum = 5;
		ResultSet rs;
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		rs = DBManager.executeSelectQuery(SQLquery);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
		int count = 1;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			if(rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
		}
		// to handle Zero records from DB
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		if(count != Integer.parseInt(dbDataIterator))
			Assert.fail();
	}

	@And("^Created PMP Strategy Status should be \"([^\"]*)\" in Data base$")
	public void created_pmp_strategy_status_should_be_something_in_data_base(String status) throws SQLException {
		pmdb.DBConnectionStart();
		String dbDataIterator = "testnull";
		String replaceData = null;
		// Selecting the Sheet based on User
		sheetName = "Query";
		replaceData = confirmationPage.getStrategyName();
		int cellnum = 6;
		ResultSet rs;
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		rs = DBManager.executeSelectQuery(SQLquery);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
		int count = 1;
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			if(rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
		}
		// to handle Zero records from DB
		if(dbDataIterator.equalsIgnoreCase(status)) {
			Reporter.addStepLog("Status of Startegy in DB is " + status);
		}
		else
			Assert.fail("Status of Startegy is not " + status);
	}

	@Then("^User should be able to see Confirmation Page for (.+)$")
	public void user_should_be_able_to_see_confirmation_page_for(String mandatorydetails) throws IOException {
		Assert.assertTrue(confirmationPage.isConfirmationHeaderDisplayed());
		assertTrue(confirmationPage.isUserOnConfirmatioPage());
		strategyCode = confirmationPage.getStrategyCode();
		if(mandatorydetails.contains("Test"))
			sheetName = "Test";
		mandatorydetails = mandatorydetails + "_" + SSOLoginPage.UIEnvironment.trim().toLowerCase();
		rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, mandatorydetails);
		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 29, strategyCode);
		userinfo = "HO_Edit";
		confirmationPage.clickOnProductMasterLink();
	}
	
	@Then("^a new Browser is initialised after closing and releasig the previous user$")
    public void a_new_browser_is_initialised_after_closing_and_releasig_the_previous_user() {
		
		//WebDriverManager.getDriver().manage().deleteAllCookies();
		/* Product Master - Release User */
		SSOLoginPage.ReleaseUser();
		WebDriverManager.getDriver().close();
		/* config web driver */
        WebDriverManager.configureDriver();
        WebDriverManager.startDriver();
		WebDriverManager.getDriver().get(property.getProperty("url_PM_"+SSOLoginPage.UIEnvironment.toUpperCase().trim()));
        Reporter.addCompleteScreenCapture();
    }
	
	@And("^created Strategy Code is stored in \"([^\"]*)\" file under (.+) for complete PMP Flow$")
    public void created_strategy_code_is_stored_in_something_file_under_for_complete_pmp_flow(String fileName, String mandatorydetails) throws SQLException, IOException {
		
		strategyName = confirmationPage.getStrategyName();
		
		//Below code is to find Strategy code from DB
		pmdb.DBConnectionStart();
		String dbDataIterator = "testnull";
		String replaceData = strategyName;
		sheetName = "Query";
		int cellnum = 12;
		ResultSet rs;
		
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		
		rs = DBManager.executeSelectQuery(SQLquery);
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			if(rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
		}
		// to handle Zero records from DB
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		strategyCode = dbDataIterator;
		
		//Below code is to store the Strategy Code in HOApproval Excel File
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/"+fileName+".xlsx";
    	String sheetName = "Test";
    	this.mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, this.mandatorydetails);
    	
    	if(fileName.equalsIgnoreCase("RejectedStrategy"))
    		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 2, strategyCode);
    	else
    		PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 1, strategyCode);
        
    }
	
	@And("^created Strategy Code is stored in all Excel files under (.+) for complete PMP Flow$")
    public void created_strategy_code_is_stored_in_all_excel_files_under_for_complete_pmp_flow(String mandatorydetails) throws IOException, SQLException {
        
		strategyName = confirmationPage.getStrategyName();
		
		//Below code is to find Strategy code from DB
		pmdb.DBConnectionStart();
		String dbDataIterator = "testnull";
		String replaceData = strategyName;
		sheetName = "Query";
		int cellnum = 12;
		ResultSet rs;
		
		String SQLquery = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 1);
		String labelname = PMPageGeneric.getCellDataSync(excelFilePath, sheetName, cellnum, 2);
		SQLquery = SQLquery.replace("@data", "'" + replaceData + "'");
		
		rs = DBManager.executeSelectQuery(SQLquery);
		while(rs.next()) {
			dbDataIterator = rs.getString(labelname);
			if(rs.wasNull() || dbDataIterator.isEmpty()) {
				dbDataIterator = "isEmpty";
			}
		}
		// to handle Zero records from DB
		if(dbDataIterator.equalsIgnoreCase("testnull")) {
			dbDataIterator = "isEmpty";
		}
		strategyCode = dbDataIterator;
		
		//Below code is to store the Strategy Code in HOApproval Excel File
		String excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/PendingHOApproval.xlsx";
    	String sheetName = "Test";
    	this.mandatorydetails = mandatorydetails+"_"+SSOLoginPage.UIEnvironment.trim().toLowerCase();
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, this.mandatorydetails);
        PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 1, strategyCode);
        
        //Below code is to store the Strategy Code in Rejected Strategy Excel File
        excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/RejectedStrategy.xlsx";
    	sheetName = "Test";
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, this.mandatorydetails);
    	PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 2, strategyCode);
    	
    	//Below code is to store the Strategy Code in Update PMP Strategy Excel File
        excelFilePath = "./src/test/resources/ad/productmaster/webui/excel/UpdatePMPStrategy.xlsx";
    	sheetName = "Test";
    	rowIndex = PMPageGeneric.getRowIndexbySyncCellValue(excelFilePath, sheetName, this.mandatorydetails);
    	PMPageGeneric.setCellDataSync(excelFilePath, sheetName, rowIndex, 1, strategyCode);
		
    }
	
	@Then("^(.+) should be able to see the (.+) in the Confirmation Page in PMP Flow$")
    public void should_be_able_to_see_the_in_the_confirmation_page_in_pmp_flow(String typeofuser, String confirmationmessage) {
		if(typeofuser.contains("HO")) {
			Assert.assertTrue(confirmationPage.isConfirmationHeaderDisplayed());
			assertTrue(confirmationPage.isUserOnConfirmatioPage());
			strategyCode = confirmationPage.getStrategyCode();
			userinfo = "HO_Edit";
		}else
		{
			assertTrue(confirmationPage.isBranchUserOnConfirmationPage(confirmationmessage));
			strategyName = confirmationPage.getStrategyName();
			userinfo = "Branch User";
		}
    }
}
