package qa.unicorn.ad.productmaster.api.stepdefs;

import java.io.BufferedReader;  
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import org.json.JSONException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.logging.LogEntries;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.CreateBenchmarkPage;
import qa.unicorn.ad.productmaster.webui.pages.CreateManagerPage;
import qa.unicorn.ad.productmaster.webui.stepdefs.CreateManagerStepDef;
import qa.unicorn.ad.productmaster.webui.stepdefs.CreateStrategyStepDef;
import qa.unicorn.ad.productmaster.webui.stepdefs.CreateStyleStepDef;

@SuppressWarnings("deprecation")
public class PM_EISL_Integration{
	Process p=null;
	String kafkaPath ="D://kafka_2.13-2.4.0//bin//windows";
	
	@SuppressWarnings({ "resource" })
	@Given("Validate data on DATA HUB")
	public void data_hub_is_running() throws InterruptedException, JSONException {
	   
		
		String dataHubLogFilePath=System.getProperty("user.dir")+"/temp/topic-DataHub.log";
		FileManager.getFileManagerObj().deleteFile(dataHubLogFilePath);
		
		
		String command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config "+kafkaPath+"/nh.properties --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC --from-beginning >>"+dataHubLogFilePath;
				
		try
		{
			//System.setProperty("user.dir", );
			//Runtime.getRuntime().exec(new String[] {"cmd", "C:\\Users\\patelnim\\kafka_2.13-2.4.0\\bin\\windows", command2});
			Reporter.addStepLog("<b>Kafka Command: </b>"+command);
			
			ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
			pb.directory(new File(kafkaPath));
			p = pb.start();
			
			Thread.sleep(10000);
			
			FileReader fr = new FileReader(dataHubLogFilePath);
			BufferedReader br = new BufferedReader(fr);
			
			String line;
			String resProgramId = ProductMasterGeneric.response.body().jsonPath().get("programId")+"";
			
			while((line=br.readLine())!=null ) {
				
				if(line.contains(resProgramId)) {
					p.destroy();
					break;
				}
				
			}
			Reporter.addStepLog("<b>Data from Data Hub: </b>"+line);
			Reporter.addStepLog("<b>Response JSON: </b>"+ProductMasterGeneric.response.asString());
			
			line=line.replace("\\", "");
			int lastIndOfEvent = line.lastIndexOf("\"event\"");
			
			line =line.substring(lastIndOfEvent).replace("\"event\":\"", "");
			
			JSONAssert.assertEquals(ProductMasterGeneric.requestJson, line, JSONCompareMode.LENIENT);
			Reporter.addStepLog("<p style = 'color:green'>Payload verification successful!</p>");
		       
			
		} catch (IOException e)
		{
		    e.printStackTrace();
		}
	}
	
	@SuppressWarnings({ "resource" })
	@And("^Validate notification on NOTIFICATION HUB$")
    public void validate_notification_on_notification_hub() throws IOException, InterruptedException {
		String notHubLogFilePath=System.getProperty("user.dir")+"/temp/topic-NotHub.log";
		FileManager.getFileManagerObj().deleteFile(notHubLogFilePath);
		
		
		String command2 = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config "+kafkaPath+"/nh.properties --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC --from-beginning >>"+notHubLogFilePath;
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command2);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command2);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		
		Thread.sleep(10000);
		
		FileReader fr = new FileReader(notHubLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		
		while((line=br.readLine())!=null ) {
			String progName = ProductMasterGeneric.response.body().jsonPath().get("programName");
			String message = "Program Created!";
			String progCode = ProductMasterGeneric.response.body().jsonPath().get("programCode");
			
			if(line.contains(progCode)) {
				p.destroy();
				
				line = line.replace(progCode, "<b>"+progCode+"</b>");
				line = line.replace(progName, "<b>"+progName+"</b>");
				
				String response = ProductMasterGeneric.response.asString();
				response = response.replace(progCode, "<b>"+progCode+"</b>");
				response = response.replace(progName, "<b>"+progName+"</b>");
				
				Reporter.addStepLog("<b>Notification from NH: </b>"+line);
				Reporter.addStepLog("<b>API Response: </b>"+response);
				
				if(line.contains(progCode)) {
					Reporter.addStepLog("<p style = 'color:green'>Program Code in Response is Matched with Program Code in Notification</p>");
					Assert.assertTrue(line.contains(progCode));
				
				}
				if(line.contains(progName)) {
					Reporter.addStepLog("<p style = 'color:green'>Program Name in Response is Matched with Program Name in Notification</p>");
					Assert.assertTrue(line.contains(progName));
				}
				if(line.contains(message)) {
					Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message+"</b>");
					Assert.assertTrue(line.contains(message));
				}
				break;
			}
		}
		
	}
	@And("^Validate the notification on NOTIFICATION HUB for Manager created through UI$")
    public void validate_the_notification_on_notification_hub_for_manager_created_through_ui() throws Throwable {
		String notHubLogFilePath=System.getProperty("user.dir")+"/temp/topic-NotHub.log";
		FileManager.getFileManagerObj().deleteFile(notHubLogFilePath);
		
		
		String command2 = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config "+kafkaPath+"/nh.properties --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC --from-beginning >>"+notHubLogFilePath;
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command2);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command2);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		
		Thread.sleep(10000);
		
		FileReader fr = new FileReader(notHubLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		
		String ManagerName = CreateManagerPage.managerFirmName;
		String message = "Manager Created!";
		String managerCode = CreateManagerPage.managerCode;
		
		while((line=br.readLine())!=null ) {
			
			System.out.println(managerCode+ManagerName);
			if(line.contains(managerCode)) {
				p.destroy();
				//System.out.println("Successful!!!!!!!");
				break;
			}
		}
		
		
		Reporter.addStepLog("<b>Notification from NH: </b>"+line);
		Reporter.addStepLog("<b>manager Name: </b>"+ManagerName);
		Reporter.addStepLog("<b>manager Code: </b>"+managerCode);
		
		
		if(line.contains(ManagerName)) {
			Reporter.addStepLog("<p style = 'color:green'>manager Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(ManagerName));
		
		}
		if(line.contains(managerCode)) {
			Reporter.addStepLog("<p style = 'color:green'>manager Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(managerCode));
		}
		if(line.contains(message)) {
			Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message+"</b>");
			Assert.assertTrue(line.contains(message));
		}
		
    }
	@And("^Validate the notification on NOTIFICATION HUB for Benchmark created through benchmark link$")
    public void validate_the_notification_on_notification_hub_for_benchmark_created_through_benchmark_link() throws Throwable {
		String notHubLogFilePath=System.getProperty("user.dir")+"/temp/topic-NotHub.log";
		FileManager.getFileManagerObj().deleteFile(notHubLogFilePath);
		
		
		String command2 = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config "+kafkaPath+"/nh.properties --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC --from-beginning >>"+notHubLogFilePath;
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command2);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command2);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		
		Thread.sleep(10000);
		
		FileReader fr = new FileReader(notHubLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		
		String benchmarkName = CreateBenchmarkPage.benchmarkName1;
		String message = "Benchmark Created!";
		String benchmarkCode = CreateBenchmarkPage.benchmarkCode1;
		
		while((line=br.readLine())!=null ) {
			
			System.out.println(benchmarkCode+benchmarkName);
			if(line.contains(benchmarkCode)) {
				p.destroy();
				//System.out.println("Successful!!!!!!!");
				break;
			}
		}
		
		
		Reporter.addStepLog("<b>Notification from NH: </b>"+line);
		Reporter.addStepLog("<b>benchmark Name: </b>"+benchmarkName);
		Reporter.addStepLog("<b>benchmark Code: </b>"+benchmarkCode);
		
		
		if(line.contains(benchmarkName)) {
			Reporter.addStepLog("<p style = 'color:green'>benchmark Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(benchmarkName));
		
		}
		if(line.contains(benchmarkCode)) {
			Reporter.addStepLog("<p style = 'color:green'>benchmark Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(benchmarkCode));
		}
		if(line.contains(message)) {
			Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message+"</b>");
			Assert.assertTrue(line.contains(message));
		}
		
    }
	
	@And("^Validate the notification on Data HUB for Benchmark$")
    public void validate_the_notification_on_data_hub_for_benchmark() throws Throwable {
		
		
		String dataHubLogFilePath=System.getProperty("user.dir")+"/temp/topic-DataHub.log";
		FileManager.getFileManagerObj().deleteFile(dataHubLogFilePath);
		
		
		String command = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config "+kafkaPath+"/nh.properties --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.DATA.DEV.OUT.WMAP.TOPIC --from-beginning >>"+dataHubLogFilePath;
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		
		Thread.sleep(10000);
		
		FileReader fr = new FileReader(dataHubLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		
		String benchmarkName = CreateBenchmarkPage.benchmarkName1;
		String message = "Benchmark Created!";
		String benchmarkCode = CreateBenchmarkPage.benchmarkCode1;
		
		while((line=br.readLine())!=null ) {
			
			System.out.println(benchmarkCode+benchmarkName);
			if(line.contains(benchmarkCode)) {
				p.destroy();
				//System.out.println("Successful!!!!!!!");
				break;
			}
		}
		
		
		Reporter.addStepLog("<b>Notification from DH: </b>"+line);
		Reporter.addStepLog("<b>benchmark Name: </b>"+benchmarkName);
		Reporter.addStepLog("<b>benchmark Code: </b>"+benchmarkCode);
		
		
		if(line.contains(benchmarkName)) {
			Reporter.addStepLog("<p style = 'color:green'>benchmark Code is Matched in Data</p>");
			Assert.assertTrue(line.contains(benchmarkName));
		
		}
		if(line.contains(benchmarkCode)) {
			Reporter.addStepLog("<p style = 'color:green'>benchmark Name is Matched in data</p>");
			Assert.assertTrue(line.contains(benchmarkCode));
		}
		if(line.contains(message)) {
			Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message+"</b>");
			Assert.assertTrue(line.contains(message));
		}
		
    }

	@And("^Validate the notification on NOTIFICATION HUB for Benchmark$")
    public void validate_the_notification_on_notification_hub_for_benchmark() throws Throwable {
		String notHubLogFilePath=System.getProperty("user.dir")+"/temp/topic-NotHub.log";
		FileManager.getFileManagerObj().deleteFile(notHubLogFilePath);
		
		
		String command2 = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config "+kafkaPath+"/nh.properties --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC --from-beginning >>"+notHubLogFilePath;
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command2);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command2);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		
		Thread.sleep(10000);
		
		FileReader fr = new FileReader(notHubLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		
		String benchmarkName = CreateBenchmarkPage.benchmarkName1;
		String message = "Benchmark Created!";
		String benchmarkCode = CreateBenchmarkPage.benchmarkCode1;
		
		while((line=br.readLine())!=null ) {
			
			System.out.println(benchmarkCode+benchmarkName);
			if(line.contains(benchmarkCode)) {
				p.destroy();
				//System.out.println("Successful!!!!!!!");
				break;
			}
		}
		
		
		Reporter.addStepLog("<b>Notification from NH: </b>"+line);
		Reporter.addStepLog("<b>benchmark Name: </b>"+benchmarkName);
		Reporter.addStepLog("<b>benchmark Code: </b>"+benchmarkCode);
		
		
		if(line.contains(benchmarkName)) {
			Reporter.addStepLog("<p style = 'color:green'>benchmark Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(benchmarkName));
		
		}
		if(line.contains(benchmarkCode)) {
			Reporter.addStepLog("<p style = 'color:green'>benchmark Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(benchmarkCode));
		}
		if(line.contains(message)) {
			Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message+"</b>");
			Assert.assertTrue(line.contains(message));
		}
		
	}
	
	@And("^Validate the notification on NOTIFICATION HUB for Style$")
    public void validate_the_notification_on_notification_hub_for_style() throws Throwable {
		String notHubLogFilePath=System.getProperty("user.dir")+"/temp/topic-NotHub.log";
		FileManager.getFileManagerObj().deleteFile(notHubLogFilePath);
		
		
		String command2 = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config "+kafkaPath+"/nh.properties --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC --from-beginning >>"+notHubLogFilePath;
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command2);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command2);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		
		Thread.sleep(10000);
		
		FileReader fr = new FileReader(notHubLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		
		String styleName = CreateStyleStepDef.styleName1;
		String message = "Style Created!";
		String styleCode = CreateStyleStepDef.styleCode1;
		
		while((line=br.readLine())!=null ) {
			
			System.out.println("Hellooooo"+styleCode+styleName);
			if(line.contains(styleCode)) {
				p.destroy();
				//System.out.println("Successful!!!!!!!");
				break;
			}
		}
		
		
		Reporter.addStepLog("<b>Notification from NH: </b>"+line);
		Reporter.addStepLog("<b>Style Name: </b>"+styleName);
		Reporter.addStepLog("<b>Style Code: </b>"+styleCode);
		
		
		if(line.contains(styleName)) {
			Reporter.addStepLog("<p style = 'color:green'>style Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(styleName));
		
		}
		if(line.contains(styleCode)) {
			Reporter.addStepLog("<p style = 'color:green'>style Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(styleCode));
		}
		if(line.contains(message)) {
			Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message+"</b>");
			Assert.assertTrue(line.contains(message));
		}
	
    }
    
	@SuppressWarnings({ "resource" })
	@And("^Validate notification on NOTIFICATION HUB for Strategy$")
    public void validate_notification_on_notification_hub_for_Strategy() throws IOException, InterruptedException {
		String notHubLogFilePath=System.getProperty("user.dir")+"/temp/topic-NotHub.log";
		FileManager.getFileManagerObj().deleteFile(notHubLogFilePath);
		
		
		String command2 = "kafka-console-consumer --bootstrap-server dev-bk1.kafka.wmap.broadridge.com:19092 --consumer.config "+kafkaPath+"/nh.properties --topic BR.INVESTMENTMANAGEMENTPRODUCT.MANAGEDACCOUNT.PRODUCTMASTER.EVENTS.DEV.OUT.WMAP.TOPIC --from-beginning >>"+notHubLogFilePath;
		
		Reporter.addStepLog("<b>Kafka Command: </b>"+command2);
		
		ProcessBuilder pb = new ProcessBuilder("cmd", "/K", command2);
		pb.directory(new File(kafkaPath));
		p = pb.start();
		
		Thread.sleep(10000);
		
		FileReader fr = new FileReader(notHubLogFilePath);
		BufferedReader br = new BufferedReader(fr);
		
		String line;
		
		String strategyName = CreateStrategyStepDef.strategyName;
		String message = "Strategy Created!";
		String strategyCode = CreateStrategyStepDef.StrategyCode;
		
		while((line=br.readLine())!=null ) {
			
			System.out.println(strategyCode+strategyName);
			if(line.contains(strategyCode)) {
				p.destroy();
				//System.out.println("Successful!!!!!!!");
				break;
			}
		}
		
		
		Reporter.addStepLog("<b>Notification from NH: </b>"+line);
		Reporter.addStepLog("<b>Strategy Name: </b>"+strategyName);
		Reporter.addStepLog("<b>Strategy Code: </b>"+strategyCode);
		
		
		if(line.contains(strategyName)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Code is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyName));
		
		}
		if(line.contains(strategyCode)) {
			Reporter.addStepLog("<p style = 'color:green'>Strategy Name is Matched in Notification</p>");
			Assert.assertTrue(line.contains(strategyCode));
		}
		if(line.contains(message)) {
			Reporter.addStepLog("Message from Notification Hub: <b style = 'color:green'>"+message+"</b>");
			Assert.assertTrue(line.contains(message));
		}
		
	}
	
	
}