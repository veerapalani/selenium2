package qa.unicorn.ad.productmaster.api.stepdefs;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;

import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

public class BaseAPIGetFundStyles   {
	EISLBaseAPIGeneric ebg = new EISLBaseAPIGeneric();
			
	String requestStr = ebg.requestJson;
	JSONObject requestJson = null;
	JSONParser parser = new JSONParser();
	Response response = ebg.response;
	SoftAssert sa = new SoftAssert();
	
	
	

	
	
	@And("verify the data received from server with Product Master DB for getFundStyles")
	public void verify_the_data_received_from_server_with_Product_Master_DB_for_getFundStyles() throws ParseException, SQLException {
		String programCodeReq="",statusReq="";
		JSONObject request = (JSONObject) parser.parse(requestStr);
		if (!request.isEmpty()) {
			 if (request.containsKey("programCode")) {
		 programCodeReq = request.get("programCode").toString();}
		 if (request.containsKey("status")) {
			 statusReq = request.get("status").toString();
			 statusReq=statusReq.replace("[", "");
			 statusReq=statusReq.replace("]", "");
			 statusReq=statusReq.replace("\"", "'");
			if (programCodeReq=="") {
			 programCodeReq="15";
			 statusReq="'Source DAAD','Rejected','Pending HO Approval','Pending','Draft','Reassigned','Eligible','Ineligible','Grandfathered','Hold','Terminated'";
				}
			 }else {
				
					 statusReq="'Source DAAD','Rejected','Pending HO Approval','Pending','Draft','Reassigned','Eligible','Ineligible','Grandfathered','Hold','Terminated'";
				
			 }
		 }else if (request.isEmpty() || (!request.containsKey("programCode"))) {
			 programCodeReq="15";
			 if (request.containsKey("status")) {
				 statusReq = request.get("status").toString();
				 statusReq=statusReq.replace("[", "");
				 statusReq=statusReq.replace("]", "");
				 statusReq=statusReq.replace("\"", "'");
				
				 }else {
					
						 statusReq="'Source DAAD','Rejected','Pending HO Approval','Pending','Draft','Reassigned','Eligible','Ineligible','Grandfathered','Hold','Terminated'";
					
				 }
			 }
	
		ProductMasterDBManager pmdb = new ProductMasterDBManager();
		ResultSet rs = null;
		pmdb.DBConnectionStart(); 
		ArrayList<String> DBNodeId = new ArrayList<String>();	
		ArrayList<String> DBStyleName = new ArrayList<String>();
		
		
		//-------query-----------//
		String	sqlQuery = "select  distinct nir.style_node_id,st.style_name from node_id_rollup nir\r\n" + 
				"inner join mutual_funds mf on mf.style_id = nir.reference_id and nir.reference_type = 'STYLE'\r\n" + 
				"inner join style st on st.style_id= mf.style_id\r\n" + 
				"inner join program_eligibility pe on pe.reference_id = mf.mf_id and pe.reference_type = 'MF'\r\n" + 
				"inner join program p on pe.program_id = p.program_id\r\n" + 
				"where  p.program_code in ('"+programCodeReq+"') and nir.rollup_type_flag = 'F' and nir.effective_to_date IS NULL"
				+ " and pe.status in (select list_id from list_values where list_type='PROGRAM STATUS' and list_value in ("+statusReq+"))"
				+ " union\r\n" + 
				"select distinct nir.style_node_id ,st.style_name from node_id_rollup nir\r\n" + 
				"inner join etf e on e.style_id = nir.reference_id and nir.reference_type = 'STYLE'\r\n" + 
				"inner join style st on st.style_id=e.style_id\r\n" + 
				"inner join program_eligibility pe on pe.reference_id = e.etf_id and pe.reference_type = 'ETF'\r\n" + 
				"inner join program p on pe.program_id = p.program_id\r\n" + 
				"where p.program_code in ('"+programCodeReq+"') and nir.rollup_type_flag = 'F' and nir.effective_to_date IS NULL "
				+ " and pe.status in (select list_id from list_values where list_type='PROGRAM STATUS' and list_value in ("+statusReq+"))"
				+ " union\r\n" + 
				"select distinct nir.style_node_id, st.style_name from program_strategy ps, strategy s,program p,style st,node_id_rollup nir\r\n" + 
				"where p.program_code in ('"+programCodeReq+"') and p.program_id=ps.program_id\r\n" + 
				"and s.strategy_id=ps.strategy_id and s.style_id=st.style_id\r\n" + 
				"and s.style_id=nir.reference_id and nir.reference_type='STYLE'\r\n" + 
				"and nir.rollup_type_flag = 'F' and nir.effective_to_date IS NULL\r\n" 
				+ " and s.status in (select list_id from list_values where list_type='STRATEGY STATUS' and list_value in ("+statusReq+"))";
		
		
		 
			System.out.println(sqlQuery);
			rs = DBManager.executeSelectQuery(sqlQuery);
		
				
			while (rs.next()) {
				String dbNodeId =rs.getString("style_node_id");
				DBNodeId.add(dbNodeId);
				String dbStyleName =rs.getString("style_name");	
			    DBStyleName.add(dbStyleName);	
			}
			pmdb.DBConnectionClose();
			int countDB=DBNodeId.size();
			String actualNodeId = response.jsonPath().getString("styleNodeId");
			String[] actualNodeIdarr = actualNodeId.split(",");
			int countAPI=actualNodeIdarr.length;
			Assert.assertEquals(countDB, countAPI);
		String result="";
			Reporter.addStepLog("<b>No. of NodeIds in API = </b>" + countAPI + "<b>| No. of NodeIds for in DB = </b>" + countDB);
			//Collections.sort(DBNodeId);
			for (int count=0;count<countAPI;count++ ) {
				String actualNodeId1 = response.jsonPath().getString("styleNodeId[" + count + "]");
				String actualStyleName = response.jsonPath().getString("styleName[" + count + "]");
				sa.assertTrue(DBNodeId.contains(actualNodeId1),"StyleNodeId "+actualNodeId1 +"  matching in API and DB");
				sa.assertTrue(DBStyleName.contains(actualStyleName),"StyleName "+actualStyleName +"  matching in API and DB");
				 result = result +"<b>StyleNodeId :</b>"+actualNodeId1 +" <b>| styleName :</b>"+ actualStyleName +" <b>is matching in API and DB</b><br>";
				
				//Reporter.addStepLog("<b>StyleNodeId :</b>"+actualNodeId1 +" <b>| styleName :</b>"+ actualStyleName +" <b>is present in API and DB for programCode 15</b>");
				
			
			}
			sa.assertAll();
			setCollapsibleHtml("Click here to see result",result );
		
		
	}
	
	public void setCollapsibleHtml(String header, String body) {
		Reporter.addStepLog("<div class=\"card-body\"> <div class=\"card-header\" role=\"tab\"> "
				+ "<h5 class=\"card-title outline-child-child\"> <div class=\"node\">" + header + "</div> </h5> "
				+ "</div> <div class=\"card-body collapse mt-3\">" + body + "</div> </div>");
	}
}
		
	
	



