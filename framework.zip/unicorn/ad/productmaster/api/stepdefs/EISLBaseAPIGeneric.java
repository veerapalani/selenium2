package qa.unicorn.ad.productmaster.api.stepdefs;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.path.json.config.JsonPathConfig;
import io.restassured.response.Response;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.utils.RestApiUtils;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

@SuppressWarnings("deprecation")
public class EISLBaseAPIGeneric {

	PropertyFileUtils property = new PropertyFileUtils("./config.properties");
	static String serviceName = "";
	String toCheckInApi = "";
	static String jwtToken = null;
	static String requestJson;
	static Response response;
	static int numberOfParentObject = 0;
	String countinDB = null;
	SoftAssert sa = new SoftAssert();
	String finalReport, reportName = "";
	List<String> strategyCodes = new ArrayList<String>();

	ProductMasterGeneric pm = new ProductMasterGeneric();
	DataConversions dc = new DataConversions();
	String environment = SSOLoginPage.UIEnvironment.toLowerCase();

	@Given("user generates jwt token to connect to EISL(.*)")
	public void user_generates_jwt_token_to_connect_to_EISL(String userId) {

		/*
		 * Getting values from framework DB according to "environment" mentioned in
		 * "config.properties" file
		 */
		String keyOrPfxPath = "./src/test/resources/ad/productmaster/api/DataLoadFiles/"
				+ Action.getTestData("certName");
		String URI = Action.getTestData("tokenURI");
		String subjectValue = Action.getTestData("subjectValue");
		String certPass = Action.getTestData("certPass");

		/*
		 * If user id is mentioned in FF, we need to use that
		 */

		if (userId.length() > 0) {
			String[] subjectValueArr = userId.split("-");
			/*
			 * using second value to fetch user ID " - V005QPM1" -> " V005QPM1" ->
			 * "V005QPM1"
			 */
			subjectValue = subjectValueArr[1].trim();
		}

		HttpClientUtils.baseUri = URI;
		HttpClientUtils.basePath = "/token";

		RetriveResponse response = HttpClientUtils.given().setHeader("Subject", subjectValue)
				.setProxy("10.98.21.24", 8080).setCetificate(keyOrPfxPath, certPass).buildUri()
				.executeRequest(MethodType.POST);

		int status = response.getStatusCode();

		if (status != 200) {
			Assert.assertTrue("Not able to generate JWT Token, Please Check!", false);
		}

		jwtToken = (String) response.getBody().jsonPath("token");

		Reporter.addStepLog("JWT Token generated successfully for userID - <b>" + subjectValue + "</b>!!");
		setCollapsibleHtml("click here to view generate token", jwtToken);

	}

	@Given("^User uses \"([^\"]*)\" JWT token$")
	public void user_user_expired_jwt_token(String type) throws Throwable {

		/* Getting Expired JWT Token */
		if (environment.equals("dev") || environment.equals("int")) {
			jwtToken = getExpiredDevToken();

		} else
			jwtToken = getExpiredQAToken();

		/* if type = NO means NO JWT token required */
		if (type.equalsIgnoreCase("no")) {
			jwtToken = "";
		}

		setCollapsibleHtml("click to view JWT Token", jwtToken);
	}

	@Given("user is connected to Base API - {string}")
	public void user_is_connected_to_Base_API(String serviceName) {
		this.serviceName = serviceName;

		String serviceURI = Action.getTestData("baseURI") + serviceName;

		RestApiUtils.requestSpecification = null;
		RestAssured.baseURI = null;
		RestAssured.basePath = "";
		String headerName = "Authorization", headerValue = "Bearer " + jwtToken;

		RestApiUtils.setBaseURI(serviceURI);

		RestApiUtils.requestSpecification = RestAssured.given();

		/* Setting Headers */
		RestApiUtils.requestSpecification.header(headerName, headerValue);

		/* Logging in report */
		Reporter.addStepLog("Working on <b style=\"color:green\">" + serviceName + "</b> "
				+ "| Environment: <b style=\"color:green\">" + environment + "</b>");
		Reporter.addStepLog("<b>Base URI:</b>" + serviceURI);

	}

	@And("^user creates a request JSON file with search keys - (.+) and values - (.+)$")
	public void user_creates_a_request_json_file_with_search_keys_and_values(String keys, String values)
			throws Throwable {

		String jsonString = "{@}";
		reportName = keys.replaceAll(",", "_");

		/*
		 * Adding unique string so that we have new reports for each scenario with same
		 * attributes and diff values Example: |codes|["value1"]| |codes|["value2"]|
		 * 
		 * Report name will be: 1. codes_AN76 | 2. codes_7H6G
		 */

		reportName = reportName.replaceAll(" ", "").concat("_" + pm.randomStringAlphaNumeric(4).toUpperCase());

		String[] keysArr = keys.split(",");

		/* converting complete string of values into individual value in an array */
		// String[] valuesArr = values.split(",");
		String[] valuesArr = getRequestValuesInArray(values);
		keys = values = "";

		/* number of keys should always equals to number of values */
		if (keysArr.length != valuesArr.length) {
			String message = "You have missed something. Please check keys and values pair in Feature File. "
					+ "\n If you want to pass multiple values for an attribute or if we have comma in attribute's value"
					+ "use semicolon at the end of test data. "
					+ "\n Example: | codes | [\"ABCD\", \"EFGH\", \"IJKL\"]; |"
					+ "\n Example: | name | John, Maxwell; |";

			Reporter.addStepLog("<abc style=\"color:red\">" + message.replaceAll("\n", "</br>") + "</abc>");
			Assert.assertTrue(message, false);
		}

		/* Forming JSON */
		for (int n = 0; n < keysArr.length; n++) {
			keys = keys.concat("\"" + keysArr[n].trim() + "\" : " + "\"" + valuesArr[n].trim() + "\"");
			if (n != keysArr.length - 1) {
				keys = keys.concat(",");
			}
		}

		/* Final JSON */
		jsonString = jsonString.replace("@", keys);

		// converting "123" -> 123 [String to Number]
		requestJson = pm.ConvertStringInJsonToNumeric(jsonString);

		/*
		 * Making [NULL] -> null [BLANK] -> "" [SPACE] -> " " [MAXCHARS] -> actual
		 * string of length 256 [MINCHARS] -> actual string of length 2 "["NIM"]" ->
		 * ["NIM"] ---- Removing double quotes before and after bracket
		 */
		requestJson = requestJson.replace("\"[", "[");
		requestJson = requestJson.replace("]\"", "]");
		requestJson = requestJson.replace("[BLANK]", "");
		requestJson = requestJson.replace("[NULL]", "null");
		requestJson = requestJson.replace("[SPACE]", " ");
		requestJson = requestJson.replace("\"true\"", "true");
		requestJson = requestJson.replace("\"false\"", "false");
		requestJson = requestJson.replace("[MAXCHARS]", pm.randomStringAlphaNumeric(256));
		requestJson = requestJson.replace("[MINCHARS]", pm.randomStringAlphaNumeric(2));
		if ((requestJson).equals("{ : }")) {
			requestJson = requestJson.replace(":", "");
		}

		/* Logging in Reports */
		Reporter.addStepLog("<b>Request Json:</b></br> " + requestJson);

		/* Writes the content to the file ---- Removing code to write JSON in file */
		// String filePath =
		// "./src/test/resources/ad/productmaster/api/requestjson/EISLSearch.json";
		// WriteToFile(filePath, requestJson);
	}

	@And("^user sends POST request$")
	public void sent_POST_request() {

		// POST request
		RestApiUtils.requestSpecification.body(requestJson);
		RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Content-Type", "application/json");
		try {
			response = RestApiUtils.postRequest(RestApiUtils.requestSpecification, RestAssured.baseURI);
		} catch (Exception e) {
			Reporter.addStepLog("<b style=\"color:red\">TIME OUT ERROR - Could not get any response from API.</b>");
			Assert.assertTrue("Connection Error", false);
		}
	}

	@Then("^response code for the service API is \"([^\"]*)\"$")
	public void response_code_for_the_service_api_is_something(String expResponseCode) throws Throwable {

		/* If status code is not as expected, printing the error/response in Reports */
		if (response.getStatusCode() != Integer.parseInt(expResponseCode)) {

			Reporter.addStepLog("<b style=\"color:red\">NOT AS EXPECTED | Response from API is : Response Code - "
					+ response.getStatusCode() + "</b>");

			setCollapsibleHtml("Click here to see response",
					"<p style=\"color:red\">" + response.getBody().asString() + "</p>");

//			Reporter.addStepLog(
//					"<p style=\"color:red\"> <b>Response Body -</b> " + response.getBody().asString() + "</p>");

		} else {
			setCollapsibleHtml("Click here to see response", response.getBody().asString());
			// Reporter.addStepLog("<b>Response Body:</b> " +
			// response.getBody().asString());
		}

		/* Verifying response code */
		RestApiHelperMethods.verfiyStatusCode(response, Integer.parseInt(expResponseCode));

	}

	@And("^verify the data received from server with Product Master DB$")
	public void verify_the_data_received_from_server_with_product_master_db() throws Throwable {

		/* Setting path for Mapping file */
		String excelFilePath = "./src/test/resources/ad/productmaster/api/excel/EISL_BaseAPIMapping.xlsx",
				sheetName = "MASTER-SHEET", uniqueIdentifierAPI = "", uniqueIdentifierDB = "", sqlQuery = "";

		List<String> expValueList = new ArrayList<String>();
		List<String> actValueList = new ArrayList<String>();

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);

		ProductMasterDBManager pmdb = new ProductMasterDBManager();

		// Getting actual sheet name
		int rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, serviceName);
		sheetName = (String) exlObj.getCellData(sheet, rowIndex, 1);

		/* using new sheet(actual) */
		sheet = exlObj.getSheet(sheetName);

		uniqueIdentifierAPI = exlObj.getStringCellData(sheet, 1, 3);
		uniqueIdentifierDB = exlObj.getStringCellData(sheet, 1, 2);

		String uniqueIdentifierValueFromRes = response.jsonPath().getString(uniqueIdentifierAPI);
		String[] uniqueIdentifierFromResArr = uniqueIdentifierValueFromRes.split(",");

		numberOfParentObject = uniqueIdentifierValueFromRes.split(",").length; // getting total objects from
																				// response
		/* getting total number of rows (which denotes total number of attributes) */
		int totalRows = exlObj.getRowCount(sheet);

		int j = 2; // starting from 2nd index as 0 is header and 1 is unique Identifier

		pmdb.DBConnectionStart(); // connecting to PM DB

		/* Header for Report. Columns: Attribute|DB Value|API Value|Result */
		finalReport = "\"Attribute\",\"DB Value\",\"API Value\",\"Result\" \n";

		for (int i = 0; i < numberOfParentObject; i++) {
			String dbIdentifierValue = uniqueIdentifierFromResArr[i].trim();
			dbIdentifierValue = pm.RemoveSquareBrackets(dbIdentifierValue);

			while (j != totalRows) {

				String isAPIRequest = exlObj.getStringCellData(sheet, j, 8);
				// String api = exlObj.getStringCellData(sheet, j, 3);
				toCheckInApi = exlObj.getStringCellData(sheet, j, 3);
				toCheckInApi = toCheckInApi + "[" + i + "]";
				String actValue = GetActualValueFromAPI(toCheckInApi);
				String apiValue = null;

				// sysout.println("!!!!!!!!!!!!!!! Actual Value: "+actValue);
				/* Storing actual values in a list */
				if (actValue != null && actValue.length() > 1) {

					String[] actValueArr = actValue.split(",");
					for (String n : actValueArr) {
						actValueList.add(nullToStringNull(pm.RemoveSquareBrackets(n.trim())));
					}
				} else {

					actValueList.add(nullToStringNull(actValue));
				}

				if (!isAPIRequest.isEmpty()) {
					JSONObject request = null;

					JSONParser parser = new JSONParser();
					request = (JSONObject) parser.parse(requestJson);
					Boolean apiValueCheck = requestJson.contains(isAPIRequest);
					if (apiValueCheck) {

						apiValue = request.get(isAPIRequest).toString();
					}

				}

				// Reporter.addStepLog(toCheckInApi + ":
				// "+response.jsonPath().getString(toCheckInApi));
				String dbTableName = exlObj.getStringCellData(sheet, j, 1);
				String dbColumnName = exlObj.getStringCellData(sheet, j, 2);
				String sqlFromExl = exlObj.getStringCellData(sheet, j, 4);
				String isListValue = exlObj.getStringCellData(sheet, j, 5);
				String isNumeric = exlObj.getStringCellData(sheet, j, 6);
				String isDateOrFormat = exlObj.getStringCellData(sheet, j, 7);

				// countinDB = exlObj.getStringCellData(sheet, j, 8);

				if (sqlFromExl.length() > 0) {
					sqlQuery = exlObj.getStringCellData(sheet, j, 4);
					sqlQuery = sqlQuery.replace("@id", "'" + dbIdentifierValue + "'");
					sqlQuery = sqlQuery.replace("@columnName", dbColumnName);
					sqlQuery = sqlQuery.replace("@tableName", dbTableName);
				} else {
					sqlQuery = "SELECT " + dbColumnName + " FROM " + dbTableName + " WHERE " + uniqueIdentifierDB
							+ " = '" + dbIdentifierValue + "';";
				}

				//System.out.println(sqlQuery);

				ResultSet rs;

				rs = DBManager.executeSelectQuery(sqlQuery);

				/* Fetching value from DB and storing it in a list of expected values */
				while (rs.next()) {

					if (isListValue.length() > 0) {
						expValueList.add(nullToStringNull(getValueFromListId(rs.getString(dbColumnName), isListValue)));
					}

					/* Checking for date attribute */
					else if (isDateOrFormat.length() > 0) {
						String date = convertDateToExpectedFormat(rs.getTimestamp(dbColumnName) + "", isDateOrFormat);

						expValueList.add(nullToStringNull(date));
					} else
						expValueList.add(nullToStringNull(rs.getString(dbColumnName)));
				}

				/* Comparing the values and storing it in a variable: */
				finalReport = finalReport + Comparision(actValueList, expValueList, actValue, isNumeric, apiValue);

				/* Clearing the list - Ready for new iteration */
				expValueList.clear();
				actValueList.clear();

				/* Next Row */
				j++;
			}

			/* Next Parent Object */
			j = 2;
		}

		/* Writing in report file */
		String reportAddress = "./target/cucumber-reports/Spark/" + reportName + ".txt";

		WriteToFile(reportAddress, finalReport);

		Reporter.addStepLog("<b>Report: </b><a href = \"" + reportName
				+ ".txt\" target=\"_blank\" > Click Here to View Detailed Report</a>");
		finalReport = "";

		pmdb.DBConnectionClose(); // closing PMDB connection
		sa.assertAll();
	}

	@And("^verify for (.+), error details should be (.+)$")
	public void verify_for_error_details_should_be(String scenario, String expDetails) throws Throwable {
		String actDetails = null;

		/* Storing details from response */
		try {
			actDetails = response.jsonPath().getString("errors[0].details");
		}
		/* for invalid characters scenario, getting error message at diff path */
		catch (Exception e) {
			actDetails = response.jsonPath().getString("details[0]");

		}

		/*
		 * Validating details from response with expected details and logging in reports
		 */
		Reporter.addStepLog("<b>Scenario: </b><i>" + scenario + "</i>");
		Reporter.addStepLog(
				"<b>Expected:</b> " + expDetails.replaceAll("\"", "") + " | <b>Actual Details: </b>" + actDetails);
		Assert.assertTrue("Actual doesn't contains expected message.",
				actDetails.contains(expDetails.replaceAll("\"", "")));
	}

	@And("^verify for response (.+)$")
	public void verify_for_response(String statusMessage) throws Throwable {

		if (statusMessage.contains("entitled")) {
			verify_for_error_details_should_be("Unauthorized", statusMessage);
		} else {

			Assert.assertNotNull("Response body is null, please check response.", response.body().asString());
			Reporter.addStepLog("Response body is not empty, refer response in above step");
		}

	}

	@And("^user is able to see error for \"([^\"]*)\" JWT token$")
	public void user_is_able_to_see_error_for_jwt_token(String type) throws Throwable {
		/* Storing details from response */
		String actError = response.jsonPath().getString("errors[0].message");
		String expError = "";

		if (type.equalsIgnoreCase("no")) {
			expError = "JWT Token does not begin with Bearer String!";
		} else if (type.equalsIgnoreCase("expired")) {
			expError = "JWT Token has expired!";
		} else
			Assert.assertFalse("Invalid JWT Token Type, Accepted Type = No or Expired", true);

		/*
		 * Validating details from response with expected details and logging in reports
		 */
		Reporter.addStepLog("<b>Actual: </b><i>" + actError + "</i>");
		Reporter.addStepLog("<b>Expected:</b>" + expError);
		Assert.assertTrue("Result Mismatch.", actError.contains(expError));
	}

	/*****************
	 * FUNCTIONS
	 * 
	 * @throws SQLException
	 *************************/
	public String getValueFromListId(String element, String value) throws IOException, SQLException {

		String expValue = "", sQuery = "", dbColumnName = "";
		ResultSet rss;

		if (value.equalsIgnoreCase("V")) {
			dbColumnName = "list_value";
		} else if (value.equalsIgnoreCase("C")) {
			dbColumnName = "list_code";
		} else {
			Assert.assertTrue(
					"\"" + element + "\" is not a list value pair or there is something worng in code mapping", false);
		}
		if (element != null && !element.equalsIgnoreCase("")) {
			sQuery = "SELECT " + dbColumnName + " from list_values where list_id=" + element;
			//System.out.println(sQuery);

			rss = DBManager.executeSelectQuery(sQuery);
			while (rss.next()) {
				expValue = rss.getString(dbColumnName);

			}
			return expValue;
		} else
			return null;
	}

	@SuppressWarnings("unused")
	public String Comparision(List<String> actValueList, List<String> expValueList, String actValue, String isNumeric,
			String apiValue) throws IOException {
		String report = "", expValue = "";
		boolean flag = false;

		if (actValueList.size() > 0 && expValueList.size() > 0 && actValue != null) {
			int a = 0;
			Double expNum, actNum;

			while (a < actValueList.size()) {
				if (apiValue != null && apiValue.length() > 0) {
					if (apiValue.contains(actValue)) {
						flag = true;
					} else {
						flag = false;

					}
					sa.assertTrue(flag, "API request Value is not matching with api Response: " + actValue);
				}

				if (isNumeric != null && !isNumeric.equalsIgnoreCase("") && isNumeric.equalsIgnoreCase("y")) {
					Collections.sort(expValueList);
					Collections.sort(actValueList);
					try {
						expNum = Double.parseDouble(expValueList.get(a));
						actNum = Double.parseDouble(actValueList.get(a));
						if (expNum == null && actNum == 0) {
							flag = true;
						} else if (Double.compare(expNum, actNum) == 0) {
							flag = true;
						}
//						Reporter.addStepLog(
//								toCheckInApi + " - " + a + " | DB: " + expNum + " | API: " + actNum + "| " + flag);
						report = report + "\"" + toCheckInApi + "\"," + expNum + "," + actNum + ",\"" + flag + "\" \n";
					} catch (Exception e) {
//						Reporter.addStepLog(toCheckInApi + " : either API value \"" + actValueList.get(a)
//								+ "\" or DB value \"" + expValueList.get(a) + "\" is not a number.");
						report = report + "\"" + toCheckInApi + "\"," + expValueList.get(a) + "," + actValueList.get(a)
								+ ",\"One of the value is not a number or error in mapping\" \n";
					}
					sa.assertTrue(flag, "API Value is not matching with DB for " + toCheckInApi);

				} else {
					try {
						Collections.sort(expValueList);
						if (!expValueList.get(a).trim().contains(",")) {
							Collections.sort(actValueList);
						}

						expValue = expValueList.get(a).trim();
						actValue = actValueList.get(a).trim();
						if (expValue.contains(",") && actValueList.size() > 1) {
							actValue = actValueList.get(a) + "," + actValueList.get(a + 1);
							actValue = actValue.toString().trim().replaceAll("\\s", "");
							expValue = expValue.toString().trim().replaceAll("\\s", "");
							a = a + 1;
						} else if (expValue.contains(",") && actValueList.size() == 1) {
							actValue = actValueList.get(a) + ",";
							actValue = actValue.toString().trim().replaceAll("\\s", "");
							expValue = expValue.toString().trim().replaceAll("\\s", "");
						}

					} catch (Exception e) {
						//Nothing to do
					}
					
					if ((actValue.equalsIgnoreCase("") || actValue.equalsIgnoreCase("0")) && expValue == "null") {
						flag = true;
					}
					if (expValue.equalsIgnoreCase("t")) {
						expValue = "true";
					}
					if (expValue.equals("f")) {
						expValue = "false";
					}

					if (actValue.equals(expValue)) {
						flag = true;
					}

//					Reporter.addStepLog(
//							toCheckInApi + " - " + a + " | DB: " + expValue + " | API: " + actValue + "| " + flag);
					report = report + "\"" + toCheckInApi + "\"," + expValue + "," + actValue + ",\"" + flag + "\" \n";
				}
				a++;

				sa.assertTrue(flag, "API Value is not matching with DB for " + toCheckInApi);
			}
		} else {

			flag = actValueList.containsAll(expValueList);

//			Reporter.addStepLog("************ " + toCheckInApi + " | DB: " + expValueList + " | API: " + actValueList
//					+ "| " + actValueList.containsAll(expValueList));
			report = report + "\"" + toCheckInApi + "\"," + expValueList + "," + actValueList + ",\""
					+ actValueList.containsAll(expValueList) + "\" \n";

			sa.assertTrue(flag, "API Value is not matching with DB for " + toCheckInApi);

		}
		return report;

	}

	public void WriteToFile(String filePath, String data) throws IOException {
		// Creates file if not exist, If exist - works on that file
		File file = new File(filePath);

		// creates the file
		file.createNewFile();

		// creates a FileWriter Object
		FileWriter writer = new FileWriter(file);

		// Writes the content to the file
		writer.write(data);
		writer.flush();
		writer.close();

	}

	public String nullToStringNull(String strNull) {
		if (strNull == null) {
			strNull = "null";
		} else if (strNull.length() <= 0) {
			strNull = "";
		}
		return strNull;
	}

	public void setCollapsibleHtml(String header, String body) {
		Reporter.addStepLog("<div class=\"card-body\"> <div class=\"card-header\" role=\"tab\"> "
				+ "<h5 class=\"card-title outline-child-child\"> <div class=\"node\">" + header + "</div> </h5> "
				+ "</div> <div class=\"card-body collapse mt-3\">" + body + "</div> </div>");
	}

	public String getExpiredQAToken() {
		return "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjVGQ0FHUmxGM0dfWVA1cVhycmtWY1dYZFJZTSJ9.ew0KCSJpc3MiOiAiaHR0cHM6Ly93d3cuYnJvYWRyaWR"
				+ "nZS5jb20vZ2F0ZXdheS9qd3QvdWF0X2V4dHJhbmV0IiwNCgkic3ViIjogIlYwMDVRSE8xIiwNCgkiYXVkIjogIkVJU0wiLA0KCSJleHAiOiAxNjY4NzAxNjQwLA0K"
				+ "CSJpYXQiOiAxNjY4Njk4MDQwLA0KCSJuYmYiOiAxNjY4Njk4MDM1LA0KCSJhenAiOiAiVjAwNVFITzEiLA0KCSJqdGkiOiAiMDAwMDAxODQ2Yzk2NjlhMi0xMDlmOG"
				+ "YiLA0KCSJhdXRoeiI6IHsNCgkJImNsaWVudG51bWJlciI6ICIwMDUiLA0KCQkidXNlcmlkIjogIlYwMDVRSE8xIiwNCgkJImZlZGVyYXRlZGNsaWVudGlkIjogIiIs"
				+ "DQoJCSJ1c2VyVHlwZSI6ICJFWFRFUk5BTFVTRVIiLAkJDQoJCSJlaXNsY29udHJhY3RpZCIgOiAiZTcwNDc0ZjFmMDQ5NGY3NDlkMTFkOTI3YTZmODkzOTQiLAkJDQ"
				+ "oJCSJ1YnNPdXRib3VuZEFwaUtleSIgOiAiIiwJCQ0KCQkiZmlyc3RuYW1lIjogIk5pbWl0IiwNCgkJImxhc3RuYW1lIjogIlBhdGVsIiwNCgkJImVtYWlsIjogIm5p"
				+ "bWl0LnBhdGVsQGJyb2FkcmlkZ2UuY29tIiwNCgkJInJvbGVzIjogW10sDQoJCSJlbnRpdGxlbWVudHMiOiBbIlBST0RNX1VQREFURUVURiwgUFJPRE1fVUksIFBST0"
				+ "RNX05PTlBNUFNUUkFURUdJRVNfU0VSVklDRSwgUFJPRE1fU0VBUkNITVVUVUFMRlVORCwgUFJPRE1fU0VBUkNITUFOQUdFUiwgUFJPRE1fVVBEQVRFTUFOQUdFUiwg"
				+ "UFJPRE1fU0VBUkNIRVRGLCBQUk9ETV9DUkVBVEVNQU5BR0VSLCBQUk9ETV9VUERBVEVGQSwgUFJPRE1fTk9OUE1QU1RSQVRFR0lFUywgUFJPRE1fQ1JFQVRFRkFURUF"
				+ "NLCBQUk9ETV9TRUFSQ0hTVFJBVEVHWSwgUFJPRE1fQ1JFQVRFUFJPR1JBTSwgUFJPRE1fVVBEQVRFTVVUVUFMRlVORCwgUFJPRE1fVVBEQVRFRkFURUFNLCBQUk9ETV"
				+ "9TRUFSQ0hCRU5DSE1BUkssIFBST0RNX1VQREFURVNUUkFURUdZLCBQUk9ETV9QTVBTVFJBVEVHSUVTLCBQUk9ETV9DUkVBVEVTVFJBVEVHWSwgUFJPRE1fVVBEQVRFU"
				+ "FJPR1JBTSwgUFJPRE1fQ1JFQVRFTVVUVUFMRlVORCwgUFJPRE1fU0VBUkNIRkFURUFNLCBQUk9ETV9TRUFSQ0hGQSwgUFJPRE1fU0VBUkNIUFJPR1JBTSwgV09SS19M"
				+ "T0dJTiwgUFJPRE1fUE1QU1RSQVRFR0lFU19TRVJWSUNFLCBQUk9ETV9TRUFSQ0hTVFlMRSwgUFJPRE1fVVBEQVRFU1RZTEUsIFBST0RNX1NFUlZJQ0UsIFBST0RNX0N"
				+ "SRUFURVNUWUxFLCBQUk9ETV9DUkVBVEVGQSwgUFJPRE1fUE1QQVBQUk9WQUwsIFBST0RNX0NSRUFURUVURiJdLA0KCQkicmVwY29kZXMiOiBbIkFBQSw5OTkiXSwNCg"
				+ "kJImJyYW5jaCI6IFsiQUFBLDk5OSJdLA0KCQkidXNhaWQiOiAiIiwNCgkJImVuY3B3ZCI6ICIvdEltQnBPbk9MVUhQREkzSTBVNUp3PT0iLA0KCQkiZ3BuIjogIiIsD"
				+ "QoJCSJmaXJtY29kZSI6ICIiLA0KCQkid2lyZWNvZGUiOiAiIiwNCgkJInNwbGl0cyI6IFtdDQoJfQ0KfQ.a0hwVHcmR8kjsFCcj2txqIFv2TGfG8BaspPirSR_ijmz3"
				+ "elxaeAtPyTHy5TVwoo7IyPf2ZVEHyoK767KEiHfib1XY5f9HUqJR9jEtYdoK8-aAPYK6pkRa2q1iI57kUOEQsEC6fMZtB4QDwhz1SBIGsGSMwDeFNYkoeJM7w0PK9F9"
				+ "ed4_TTmgkFgXWdJ6ilwaraFya_hcRT69qm0aKAPTojnzLt1A9u8piqURBwD-z2Cd3O59akGGu-VC22qSlYKR3ZgNRlW5y44W8zR4ux_-JrBFfI_c9zB7u70xDd6Hel8i"
				+ "IgUcIBonQgWFtxOufHOOtppuUZxbUs3lJpRTtHApUR_VNpPkIFS8L_iHJvv_l-wFOD87jOPHPIv4wuGyI21n81iiH24bw2cruyK4J2iD9eUK0QC6k4kQGy3Sg2nYI2IH"
				+ "2r3YHYvu1blp0Ht3l-4yz6sOA73Pp0feBoR32U5Tf0qNGn_shTJbxrdeMT0gPj-zR0_N78ms8ocePvp9YnoLbJC9AnZvWKT8pCNXew6GC_bIxnNWZozftCNF1odOogT_"
				+ "eF6SDTRCN22gyq_joAb_vKfyR22x-_oQ3XZpIEWyQLpp8xCxrjGtUsqTlxizcEyceuE9bOwE2VBigzjmK6nXR640Jp7FtYe_MjHr077JlwrqOlGjs_jTMtbTCawSSFM";
	}

	public String getExpiredDevToken() {
		return "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Inc4Wk9rV3VrWkpyalplWm5wek5jNk0yNGJXUSJ9.ew0KCSJpc3MiOiAiaHR0cHM6Ly93d3cuYnJvYWRyaWRnZS5jb20vZ2F0ZXdheS9qd3Qvc2FuZGJveCIsDQoJInN1YiI6ICJWMDA1UVNITyIsDQoJImF1ZCI6ICJFSVNMIiwNCgkiZXhwIjogMTY2ODY3NTEwNCwNCgkiaWF0IjogMTY2ODY3MTUwNCwNCgkibmJmIjogMTY2ODY3MTQ5OSwNCgkiYXpwIjogIlYwMDVRU0hPIiwNCgkianRpIjogIjAwMDAwMTg0Njk0ZjkzMmQtMThkMDU0IiwNCgkiYXV0aHoiOiB7DQoJCSJjbGllbnRudW1iZXIiOiAiMDA1IiwNCgkJInVzZXJpZCI6ICJWMDA1UVNITyIsDQoJCSJmZWRlcmF0ZWRjbGllbnRpZCI6ICIiLA0KCQkidXNlclR5cGUiOiAiRVhURVJOQUxVU0VSIiwJCQ0KCQkiZWlzbGNvbnRyYWN0aWQiIDogImU3MDQ3NGYxZjA0OTRmNzQ5ZDExZDkyN2E2Zjg5Mzk0IiwJCQ0KCQkidWJzT3V0Ym91bmRBcGlLZXkiIDogIiIsCQkNCgkJImZpcnN0bmFtZSI6ICJOaW1pdCIsDQoJCSJsYXN0bmFtZSI6ICJQYXRlbCIsDQoJCSJlbWFpbCI6ICJuaW1pdC5wYXRlbEBicm9hZHJpZGdlLmNvbSIsDQoJCSJyb2xlcyI6IFtdLA0KCQkiZW50aXRsZW1lbnRzIjogWyJQUk9ETV9OT05QTVBTVFJBVEVHSUVTX1NFUlZJQ0UsIFBST0RNX1NFUlZJQ0UsIFBST0RNX1BNUFNUUkFURUdJRVNfU0VSVklDRSJdLA0KCQkicmVwY29kZXMiOiBbIkFBQSw5OTkiXSwNCgkJImJyYW5jaCI6IFsiQUFBLDk5OSJdLA0KCQkidXNhaWQiOiAiIiwNCgkJImVuY3B3ZCI6ICIiLA0KCQkiZ3BuIjogIiIsDQoJCSJmaXJtY29kZSI6ICIiLA0KCQkid2lyZWNvZGUiOiAiIiwNCgkJInNwbGl0cyI6IFtdDQoJfQ0KfQ.UfvpTQql26DQLQ_3zdG-XNF3ePoY3jYAQ__EoqRXek690hbeQrxFmFoqYI6h7qJtU00nuDw9khPbu80nPghPFsPbMPB5nrJmUcFMx8uV2_nBlTq1KXLOu63ZasbYqgRMUOzHMlVYQupAtzLFfvPqrSwHJUq0oumb62pzxLFuCjWL3EuOXqCKr6oPRa43fEYjYTuf0uP2K0CuGq9dADvLpBMqTeo9REwyn1IDDrpnduh24kXaulEMXfc0rhssxE_va9jX-rf4jJIP5LaCvaywtjH-reKg9d8lyLNAsndcXGVzVE7FjTH_QSZ5qXf3d5XIbH0nq3x0eUrIeMID0zlErefhP46bnqFgRH_62tVXG95SXZRjW7sRhIoqf__-1u2BPjt0C14Fg4LjJ5XeTO87NIVlzh4J7xEin9Nu0vamoWm80jdWgeXpEx3INbnruiaREugFirxkQ4TeG7avvwT-j6TYc2MED0l7KUZpZA73p9PRzrip79CQ5WIlJNCMSwkf1L3CVMR5U6lhLn_aNllk26HDnQBfmvYXr5Gj7PprCTRW1OofCClI9Y2CNI63LA3dSbGZ2bQjB3rPWRv8_BxXdvqb0tLWTFSvlORzcC1wTewDh8MajIPipEeM2uQBJtIIJ3aEAIEdyLcjv4E9cDANbkptrw21cGX236jluNCUhrE";
	}

	/*
	 * if we want to pass multiple values for one attribute(like codes), then we're
	 * using ";" in FF example: |codes, programCodes, styleId |
	 * ["COD1","COD2"];"12"; 123 |
	 */
	String[] getRequestValuesInArray(String strToConvert) {
		String[] valuesArr = null;

		if (strToConvert.contains(";")) {
			valuesArr = strToConvert.split(";");
		} else
			valuesArr = strToConvert.split(",");

		return valuesArr;
	}

	public String convertDateToExpectedFormat(String dateFromDB, String isDateOrFormat) {

		String convertedDate = "";
		/*
		 * Getting 2022-03-08 07:05:51.653151 | Expected 03/08/2022 07:05:51:653 if date
		 * from DB = 2022-03-08 07:05:51.6 | Adding # -> 2022-03-08 07:05:51.6### (to
		 * avoid null in milliseconds) and then replacing # to match API value ->
		 * 2022-03-08 07:05:51.600
		 */

		if (dateFromDB != null && dateFromDB.length() > 4) {

			String year = null;
			String month = null;
			String day = null;
			int hours = 0;
			String strHours = null, minutes = null, seconds = null, milliseconds = null;

			try {
				dateFromDB = dateFromDB + "###";

				year = dateFromDB.substring(0, 4);
				month = dateFromDB.substring(5, 7);
				day = dateFromDB.substring(8, 10);
				hours = Integer.parseInt(dateFromDB.substring(11, 13));
				minutes = dateFromDB.substring(14, 16);
				seconds = dateFromDB.substring(17, 19);
				milliseconds = dateFromDB.substring(20, 23);

				milliseconds = milliseconds.replaceAll("#", "0");

			} catch (Exception n) {
			}

			/* in DB we have 24hours format but in API it's 12hours format */
			if (hours > 12) {
				hours = hours - 12;
			}
			if (hours == 0) {
				hours = 12;
			}

			/* formatting hours 7 -> 07; 3 -> 03 */
			strHours = (hours < 10 ? "0" : "") + hours;

			switch (isDateOrFormat) {
			case "MM/DD/YYYY": {
				convertedDate = month + "/" + day + "/" + year;
				break;
			}
			default: {
				convertedDate = month + "/" + day + "/" + year + " " + strHours + ":" + minutes + ":" + seconds + ":"
						+ milliseconds;
				break;
			}
			}

			return convertedDate;

		} else
			return null;
	}

	int compareCounts(String sql, String apiAttribute) throws SQLException {
		ProductMasterDBManager pmdb = new ProductMasterDBManager();
		int expectedCount = 0;
		ResultSet rs = null;
		// String actualTemplateFlag = response.jsonPath().getString(apiAttribute);
		pmdb.DBConnectionStart(); // connecting to PM DB
		//System.out.println(sql);
		rs = DBManager.executeSelectQuery(sql);
		while (rs.next()) {
			if (rs.getObject(1) != null) {
				expectedCount = rs.getInt("count");
			}
		}
		pmdb.DBConnectionClose();
		return expectedCount;
	}

	/**
	 *
	 * @param strategyCode
	 * @param ProgramCode
	 * @return reportingName
	 * @throws SQLException
	 */
	String GenerateReportingStratageyName(String strategyCode, String programCode)
			throws SQLException, NullPointerException {
		String expReportingName = "";

		String fa_team_name = "", fa_name = "", style_name = "", strategy_name = "", manager_name = "";

		String sqlQuery = "select fa.fa_name, fat.fa_team_name, m.manager_name, st.style_name, s.strategy_name, s.strategy_code from strategy s \r\n"
				+ "left join fa_team fat on s.fa_team_id = fat.fa_team_id\r\n"
				+ "left join strategy_financial_advisor sfa on s.strategy_id = sfa.strategy_id\r\n"
				+ "left join financial_advisor fa on fa.fa_id = sfa.fa_id \r\n"
				+ "left join manager m on s.manager_id = m.manager_id \r\n"
				+ "left join style st on st.style_id = s.style_id\r\n" + "where s.strategy_code = '" + strategyCode
				+ "' ORDER BY fa.fa_id desc";

		ResultSet resultset = DBManager.executeSelectQuery(sqlQuery);

		while (resultset.next()) {
			fa_team_name = resultset.getString("fa_team_name");
			fa_name = resultset.getString("fa_name");
			style_name = resultset.getString("style_name");
			strategy_name = resultset.getString("strategy_name");
			manager_name = resultset.getString("manager_name");
		}

		switch (programCode) {
		case "12": {
			if (fa_team_name != null) {
				expReportingName = fa_team_name + " - " + style_name;
			} else if (fa_name != null) {
				expReportingName = fa_name + " - " + style_name;
			} else {
				expReportingName = strategy_name;
			}
			break;
		}

		case "13":
		case "39": {
			expReportingName = manager_name + " - " + strategy_name;
			break;
		}

		default: {
			expReportingName = strategy_name;
			break;
		}
		}
		return expReportingName;
	}

	/* Set and Print Table in HTML Reports */

	/**
	 * This should be before any loop, headers will be separated by | [pipe]
	 * 
	 * @param headers
	 */
	public void SetAndPrintTableHeaders(String headers) {

		headers = "<th>" + headers.replace("|", "</th><th>") + "</th>";

		Reporter.addStepLog("<table style=\"overflow-x:auto;\" border=1px solid><tr>\r\n" + headers + "  </tr>");
	}

	/**
	 * This should be in any loop, row Values will be separated by | [pipe]
	 * 
	 * @param rowValue
	 */
	public void SetAndPrintTableRows(String rowValue) {
		rowValue = "<td>" + rowValue.replace("|", "</td><td>") + "</td>";

		Reporter.addStepLog("<tr>" + rowValue + "</tr>");
	}

	/**
	 * This should be after any loop
	 * 
	 */
	public void SetAndPrintTableFooter() {
		Reporter.addStepLog("</table>");
	}

	/* This will fetch data from API according to the json path provided. */
	public String GetActualValueFromAPI(String apiPath) {

		String value = response.jsonPath().getString(apiPath);

		/* to get values for Big Decimal from API. */
		if ((apiPath.contains("strategyMinimumAmount") || apiPath.contains("withdrawalMinimumAmount")
				|| apiPath.contains("exceptionMinimumAmount") || apiPath.contains("rebalanceMinimumAmount")
				|| apiPath.contains("assets")) || apiPath.contains("investmentVehicleAum")
				|| apiPath.contains("grossExpenseRatio") || apiPath.contains("netExpenseRatio") && value != null) {

			JsonPath jsonPathEvaluator = response.jsonPath()
					.using(new JsonPathConfig(JsonPathConfig.NumberReturnType.BIG_DECIMAL));
			value = jsonPathEvaluator.getString(apiPath);
		}

		return value;
	}

}
