package qa.unicorn.ad.productmaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;

public class CSVtoExcelConverter {
	List<String[]> fileData = new ArrayList<String[]>();

	public void convertCSVtoExcel(String csvFilePath, String exlFilePath, String sheetName) throws IOException {

		/* Setting up CSV file instance */
		fileData = CSVFileUtils.getInstance().readAll(csvFilePath, ",");

		BufferedReader bufferedReader = new BufferedReader(new FileReader(csvFilePath));

		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, exlFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);

		String input = null;
		int rowIndex = 0;
		int lastColumn = 0;

		while ((input = bufferedReader.readLine()) != null) {
			// input = input.replaceAll(",\"\"$", ",\"1\"");
			String[] numberOfCoulmns = input.split(",");
			lastColumn = numberOfCoulmns.length;
			if (lastColumn > 0) {
				for (int i = 0; i < lastColumn; i++) {
					System.out.println(i);
					// String data = CSVFileUtils.getInstance().
					String data = CSVFileUtils.getInstance().getValue(fileData, rowIndex, i);
					exlObj.setCellData(sheet, rowIndex, i, data.replaceAll("\"", ""));

				}
				rowIndex++;
			}
		}
	}
}
