package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;

public class BaseAPIgetAllFirms {

	ProductMasterDBManager pmdb = new ProductMasterDBManager();

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD,
			"./src/test/resources/ad/productmaster/api/excel/EISL_BaseAPIMapping.xlsx");
	XSSFSheet sheet = exlObj.getSheet("GET-ALL-FA-STRAT");

	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();

	List<String> fa_code = new ArrayList<String>();
	List<String> strategy_code = new ArrayList<String>();
	List<String> strategy_name = new ArrayList<String>();
	List<String> strategy_status = new ArrayList<String>();
	List<String> style_name = new ArrayList<String>();
	SoftAssert sa = new SoftAssert();
	EISLBaseAPIGeneric ebg = new EISLBaseAPIGeneric();
	int responseCode = 0;
	String investmentType, status, programCode = null;
	JSONParser parser = new JSONParser();
	String requestStr = ebg.requestJson;
	JSONObject requestJson = null;
	Response response = ebg.response;
	String sqlSMACount = null;
	String sqlMFCount = null;
	String sqlETFCount = null;
	int countStrategyInResponse = 0;
	int countStrategyInDB = 0;
	int countMFInResponse = 0;
	int countMFInDB = 0;
	int countETFInResponse = 0;
	int countETFInDB = 0;
	String fundCat = "";
	String additionalQuery = "";

	@And("^Verify investmentType should be null in response if it is not requested$")
	public void Verify_if_investmentType_should_be_null_in_response_if_not_requested() throws Throwable {
		responseCode = EISLBaseAPIGeneric.response.getStatusCode();
		if (responseCode != 200) {
			Reporter.addStepLog("Nothing to validate as response code is not 200.");
		} else {
			requestJson = (JSONObject) parser.parse(requestStr);
			investmentType = requestJson.get("investmentType").toString();
			programCode = requestJson.get("programCode").toString();

			if (requestJson.containsKey("status")) {
				status = requestJson.get("status").toString();
				status = status.replace("[", "");
				status = status.replace("]", "");
				status = status.replace("\"", "'");

			} else {
				status = "'Eligible','Ineligible','Grandfathered','Hold','Terminated','Reassigned'";
			}

			if (requestJson.containsKey("fundCat")) {
				fundCat = requestJson.get("fundCat").toString();
				fundCat = fundCat.replace("[", "");
				fundCat = fundCat.replace("]", "");
				fundCat = fundCat.replace("\"", "'");
			}

			sqlSMACount = "select count(*) from (select distinct (mgr.firm_id),mgr.firm_name \r\n"
					+ "from program pm join program_strategy ps on (pm.program_id = ps.program_id)\r\n"
					+ "join strategy stg on (ps.strategy_id = stg.strategy_id)\r\n"
					+ "join manager mgr on (stg.manager_id = mgr.manager_id)\r\n" + "where pm.program_code = '"
					+ programCode + "' and stg.status not in \r\n"
					+ "(select list_id from list_values where list_value in \r\n"
					+ " ('Rejected','Draft','Pending','Source DAAD','Pending HO Approval') and list_type='STRATEGY STATUS')"
					+ " and stg.status in (select list_id from list_values where list_value in (" + status
					+ ") and list_type='STRATEGY STATUS') and stg.client_id = 1) as count1;";

			sqlETFCount = "select count(*) from (select distinct etf.fund_family_id ,\r\n"
					+ "       etf.fund_family_name\r\n" + "from program pm\r\n"
					+ "join program_eligibility pe on (pm.program_id = pe.program_id)\r\n"
					+ "join etf etf on (pe.reference_id = etf.etf_id) and (pe.reference_type = 'ETF')\r\n"
					+ "where pm.program_code = '" + programCode + "' \r\n"
					+ "and (etf.fund_family_id is not null and  etf.fund_family_name is not null) and pe.status in"
					+ "(select list_id from list_values where list_value in (" + status
					+ ") and list_type='PROGRAM STATUS')" + additionalQuery + " and etf.client_id = 1)as count1;";

			if (investmentType.equalsIgnoreCase("SMA") || investmentType.equalsIgnoreCase("ALL")) {
				String firmId = response.jsonPath().getString("strategy.firmId");
				if (firmId != null) {
					String[] firmIdArr = firmId.split(",");
					countStrategyInResponse = firmIdArr.length;
				}
				System.out.println(sqlSMACount);
				countStrategyInDB = ebag.compareCounts(sqlSMACount, "");
			}
			if (investmentType.equalsIgnoreCase("MF") || investmentType.equalsIgnoreCase("ALL")) {
				String firmId = response.jsonPath().getString("mf.familyId");
				if (firmId != null) {
					String[] firmIdArr = firmId.split(",");
					countMFInResponse = firmIdArr.length;
				}
				if (requestJson.containsKey("fundCat")) {
					additionalQuery = " and mf.fund_category in (" + fundCat + ")";
				}
				sqlMFCount = "select count(*) from (select distinct mf.fund_family_id,\r\n"
						+ "       mf.fund_family_name  from program pm\r\n"
						+ "join program_eligibility pe on (pm.program_id = pe.program_id)\r\n"
						+ "join mutual_funds mf on (pe.reference_id = mf.mf_id) and (pe.reference_type = 'MF')\r\n"
						+ "where pm.program_code = '" + programCode + "'\r\n"
						+ "and (mf.fund_family_id is not null and  mf.fund_family_name is not null) and pe.status in "
						+ "(select list_id from list_values where list_value in (" + status
						+ ") and list_type='PROGRAM STATUS')" + additionalQuery + " and mf.client_id = 1)as count1;";

				System.out.println(sqlMFCount);
				countMFInDB = ebag.compareCounts(sqlMFCount, "");
			}
			if (investmentType.equalsIgnoreCase("ETF") || investmentType.equalsIgnoreCase("ALL")) {
				String firmId = response.jsonPath().getString("etf.familyId");
				if (firmId != null) {
					String[] firmIdArr = firmId.split(",");
					countETFInResponse = firmIdArr.length;
				}
				if (requestJson.containsKey("fundCat")) {
					additionalQuery = " and etf.fund_category in (" + fundCat + ")";
				}
				System.out.println(sqlETFCount);
				sqlETFCount = "select count(*) from (select distinct etf.fund_family_id ,\r\n"
						+ "       etf.fund_family_name\r\n" + "from program pm\r\n"
						+ "join program_eligibility pe on (pm.program_id = pe.program_id)\r\n"
						+ "join etf etf on (pe.reference_id = etf.etf_id) and (pe.reference_type = 'ETF')\r\n"
						+ "where pm.program_code = '" + programCode + "' \r\n"
						+ "and (etf.fund_family_id is not null and  etf.fund_family_name is not null) and pe.status in"
						+ "(select list_id from list_values where list_value in (" + status
						+ ") and list_type='PROGRAM STATUS')" + additionalQuery + " and etf.client_id = 1)as count1;";

				countETFInDB = ebag.compareCounts(sqlETFCount, "");
			}
			if (!investmentType.equalsIgnoreCase("SMA") && !investmentType.equalsIgnoreCase("ALL")) {

				String investmentRes = response.jsonPath().getString("strategy");
				Assert.assertEquals(null, investmentRes);
				Reporter.addStepLog("Response for Strategy is :" + investmentRes);
			}
			if (!investmentType.equalsIgnoreCase("ETF") && !investmentType.equalsIgnoreCase("ALL")) {

				String investmentRes = response.jsonPath().getString("etf");
				Assert.assertEquals(null, investmentRes);
				Reporter.addStepLog("Response for ETF is :" + investmentRes);
			}
			if (!investmentType.equalsIgnoreCase("MF") && !investmentType.equalsIgnoreCase("ALL")) {

				String investmentRes = response.jsonPath().getString("mf");
				Assert.assertEquals(null, investmentRes);
				Reporter.addStepLog("Response for MF is :" + investmentRes);
			}
			if (investmentType.equalsIgnoreCase("ALL")) {
				String investmentRes = response.jsonPath().getString("mf");
				if (countMFInDB == 0) {
					Assert.assertNull("InvestmentType is ALL,MF is null in response as no data present in DB",
							investmentRes);
					Reporter.addStepLog("<b>InvestmentType is ALL,MF is null in response as no data present in DB</b>");
				} else {
					Assert.assertNotNull("InvestmentType is ALL,MF is not null in response", investmentRes);
					Reporter.addStepLog("<b>InvestmentType is ALL,MF is not null in response</b>");
				}
				investmentRes = response.jsonPath().getString("etf");
				if (countETFInDB == 0) {
					Assert.assertNull("InvestmentType is ALL,ETF is null in response as no data present in DB",
							investmentRes);
					Reporter.addStepLog(
							"<b>InvestmentType is ALL,ETF is null in response as no data present in DB</b>");
				} else {
					Assert.assertNotNull("InvestmentType is ALL,etf is not null in response", investmentRes);
					Reporter.addStepLog("<b>InvestmentType is ALL,ETF is not null in response</b>");
				}
				investmentRes = response.jsonPath().getString("strategy");
				if (countStrategyInDB == 0) {
					Assert.assertNull("InvestmentType is ALL,strategy is null in response as no data present in DB",
							investmentRes);
					Reporter.addStepLog(
							"<b>InvestmentType is ALL,Strategy is null in response as no data present in DB</b>");
				} else {
					Assert.assertNotNull("InvestmentType is ALL,strategy is not null in response", investmentRes);
					Reporter.addStepLog("<b>InvestmentType is ALL,strategy is not null in response</b>");
				}
				Reporter.addStepLog("Refer above response");
			}

		}
	}

	@Then("^compare count of firms from service and product master DB$")
	public void compare_count_of_firms_from_service_and_product_master_DB() throws Throwable {
		if (investmentType.equalsIgnoreCase("SMA") || investmentType.equalsIgnoreCase("ALL")) {
			sa.assertEquals(countStrategyInDB, countStrategyInResponse);
			Reporter.addStepLog("No. of firmIds for Strategy with  programCode= " + programCode + " |DB: "
					+ countStrategyInDB + " |API : " + countStrategyInResponse);
		}
		if (investmentType.equalsIgnoreCase("MF") || investmentType.equalsIgnoreCase("ALL")) {
			sa.assertEquals(countMFInDB, countMFInResponse);
			Reporter.addStepLog("No. of familyIds for MF with programCode= " + programCode + " |DB: " + countMFInDB
					+ " |API : " + countMFInResponse);
		}
		if (investmentType.equalsIgnoreCase("ETF") || investmentType.equalsIgnoreCase("ALL")) {
			sa.assertEquals(countETFInDB, countETFInResponse);
			Reporter.addStepLog("No. of familyIds for ETF with programCode= " + programCode + " |DB: " + countETFInDB
					+ " |API : " + countETFInResponse);
		}
	}

	@And("^verify data received from server with Product Master DB for getallfirmsapi$")
	public void verify_data_received_from_server_with_Product_Master_DB_for_getallfirmsapi() throws Throwable {
		if (investmentType.equalsIgnoreCase("SMA") || investmentType.equalsIgnoreCase("ALL")) {
			if (countStrategyInResponse != 0) {
				List<String> firmIdDB = new ArrayList<String>();
				List<String> FirmNameDB = new ArrayList<String>();
				List<String> firmIdAPI = new ArrayList<String>();
				List<String> FirmNameAPI = new ArrayList<String>();

				String sqlSMACountData = "select distinct (mgr.firm_id),mgr.firm_name from program pm join program_strategy ps on (pm.program_id = ps.program_id) "
						+ "join strategy stg on (ps.strategy_id = stg.strategy_id) join manager mgr on (stg.manager_id = mgr.manager_id) where pm.program_code = '"
						+ programCode + "'"
						+ " and stg.status not in (select list_id from list_values where list_value in ('Rejected','Draft','Pending','Source DAAD','Pending HO Approval') and list_type='STRATEGY STATUS')"
						+ " and stg.status in (select list_id from list_values where list_value in (" + status
						+ ") and list_type='STRATEGY STATUS') and stg.client_id = 1";

				pmdb.DBConnectionStart();

				System.out.println(sqlSMACountData);
				ebg.setCollapsibleHtml("Click here to see DB Query",
						"<p style=\"color:red\">" + sqlSMACountData + "</p>");
				
				ResultSet rs;

				rs = DBManager.executeSelectQuery(sqlSMACountData);
				while (rs.next()) {
					firmIdDB.add(rs.getString(1));
					FirmNameDB.add(rs.getString(2));
				}
				pmdb.DBConnectionClose();
				String flag = "false";
				Reporter.addStepLog("<b>Comparing API values with DB values for Strategy </b>");
				for (int i = 0; i < countStrategyInResponse; i++) {

					String firmId1 = response.jsonPath().getString("strategy.firmId[" + (i) + "]");
					String firmname = response.jsonPath().getString("strategy.firmName[" + (i) + "]");
					firmIdAPI.add(firmId1);
					FirmNameAPI.add(firmname);
				}
//			Collections.sort(firmIdDB);
//			Collections.sort(FirmNameDB);
//			Collections.sort(firmIdAPI);
//			Collections.sort(FirmNameAPI);
//			int j=0;
//			while (j<countStrategyInResponse) {
//				Assert.assertEquals(firmIdDB.get(j), firmIdAPI.get(j));
//				Assert.assertEquals(FirmNameDB.get(j), FirmNameAPI.get(j));
//				
//		
//			
//				if (FirmNameDB.get(j).equalsIgnoreCase(FirmNameAPI.get(j))) {
//					flag = "true";
//				
//				}
//			
//				
//				Reporter.addStepLog("Firm ID" + " - " + firmIdDB.get(j) + " | Firm Name in DB: " + FirmNameDB.get(j) + " | Family Name in API: "
//						+ FirmNameAPI.get(j) + "| " + flag);
//j++;
//}
				int j = 0;
				while (j < countStrategyInResponse) {
					if (firmIdDB.contains(firmIdAPI.get(j)) && FirmNameDB.contains(FirmNameAPI.get(j))) {
						flag = "true";
					}
					Reporter.addStepLog("Firm ID" + " - " + firmIdDB.get(j) + " | Firm Name in DB: " + FirmNameDB.get(j)
							+ " | Family Name in API: " + FirmNameAPI.get(j) + "| " + flag);
					j++;
				}
			} else if (countStrategyInResponse == 0) {
				Reporter.addStepLog("No Data present for strategy in DB for progrmaCode:" + programCode);
			}

			sa.assertAll();
		}
		if (investmentType.equalsIgnoreCase("MF") || investmentType.equalsIgnoreCase("ALL")) {
			if (countMFInResponse != 0) {
				List<String> firmIdDB = new ArrayList<String>();
				List<String> FirmNameDB = new ArrayList<String>();
				List<String> firmIdAPI = new ArrayList<String>();
				List<String> FirmNameAPI = new ArrayList<String>();
				if (requestJson.containsKey("fundCat")) {
					additionalQuery = " and mf.fund_category in (" + fundCat + ")";
				}
				String sqlMFCountData = "select distinct mf.fund_family_id, mf.fund_family_name from program pm "
						+ "join program_eligibility pe on (pm.program_id = pe.program_id) "
						+ "join mutual_funds mf on (pe.reference_id = mf.mf_id) and (pe.reference_type = 'MF') "
						+ "where mf.client_id = 1 and pm.program_code = '" + programCode
						+ "' and (mf.fund_family_id is not null and  mf.fund_family_name is not null) "
						+ "and pe.status in (select list_id from list_values where list_value in (" + status
						+ ") and list_type='PROGRAM STATUS')" + additionalQuery;

				pmdb.DBConnectionStart();

				System.out.println(sqlMFCountData);
				ebg.setCollapsibleHtml("Click here to see DB Query",
						"<p style=\"color:red\">" + sqlMFCountData + "</p>");
				ResultSet rs;

				rs = DBManager.executeSelectQuery(sqlMFCountData);
				while (rs.next()) {
					firmIdDB.add(rs.getString(1));
					FirmNameDB.add(rs.getString(2));
				}
				pmdb.DBConnectionClose();
				String flag = "false";
				Reporter.addStepLog("<b>Comparing API values with DB values for MF </b>");
				for (int i = 0; i < countMFInResponse; i++) {

					String firmId1 = response.jsonPath().getString("mf.familyId[" + (i) + "]");
					String firmname = response.jsonPath().getString("mf.familyName[" + (i) + "]");
					firmIdAPI.add(firmId1);
					FirmNameAPI.add(firmname);

				}
				Collections.sort(firmIdDB);
				Collections.sort(FirmNameDB);
				Collections.sort(firmIdAPI);
				Collections.sort(FirmNameAPI);
				int j = 0;
				while (j < countMFInResponse) {
					Assert.assertEquals(firmIdDB.get(j), firmIdAPI.get(j));
					Assert.assertEquals(FirmNameDB.get(j), FirmNameAPI.get(j));

					if (FirmNameDB.get(j).equalsIgnoreCase(FirmNameAPI.get(j))) {
						flag = "true";

					}

					Reporter.addStepLog("Family ID" + " - " + firmIdDB.get(j) + " | Family Name in DB: "
							+ FirmNameDB.get(j) + " | Family Name in API: " + FirmNameAPI.get(j) + "| " + flag);
					j++;
				}
			} else if (countMFInResponse == 0) {
				Reporter.addStepLog("No Data present for MF in DB for progrmaCode:" + programCode);
			}
			sa.assertAll();
		}
		if (investmentType.equalsIgnoreCase("ETF") || investmentType.equalsIgnoreCase("ALL")) {
			if (countETFInResponse != 0) {
				List<String> firmIdDB = new ArrayList<String>();
				List<String> FirmNameDB = new ArrayList<String>();
				List<String> firmIdAPI = new ArrayList<String>();
				List<String> FirmNameAPI = new ArrayList<String>();
				if (requestJson.containsKey("fundCat")) {
					additionalQuery = " and etf.fund_category in (" + fundCat + ")";
				}
				String sqlETFCountData = "select distinct etf.fund_family_id, etf.fund_family_name from "
						+ "program pm join program_eligibility pe on (pm.program_id = pe.program_id) join etf etf on "
						+ "(pe.reference_id = etf.etf_id) and (pe.reference_type = 'ETF') where etf.client_id = 1 and pm.program_code = '"
						+ programCode + "'"
						+ "and (etf.fund_family_id is not null and  etf.fund_family_name is not null)"
						+ "and pe.status in (select list_id from list_values where list_value in (" + status
						+ ") and list_type='PROGRAM STATUS')" + additionalQuery;

				pmdb.DBConnectionStart();

				System.out.println(sqlETFCountData);
				ebg.setCollapsibleHtml("Click here to see DB Query",
						"<p style=\"color:red\">" + sqlETFCountData + "</p>");
				
				ResultSet rs;

				rs = DBManager.executeSelectQuery(sqlETFCountData);
				while (rs.next()) {
					firmIdDB.add(rs.getString(1));
					FirmNameDB.add(rs.getString(2));
				}
				pmdb.DBConnectionClose();
				String flag = "false";
				Reporter.addStepLog("<b>Comparing API values with DB values for ETF </b>");
				for (int i = 0; i < countETFInResponse; i++) {

					String firmId1 = response.jsonPath().getString("etf.familyId[" + (i) + "]");
					String firmname = response.jsonPath().getString("etf.familyName[" + (i) + "]");
					firmIdAPI.add(firmId1);
					FirmNameAPI.add(firmname);
				}
				Collections.sort(firmIdDB);
				Collections.sort(FirmNameDB);
				Collections.sort(firmIdAPI);
				Collections.sort(FirmNameAPI);
				int j = 0;
				while (j < countETFInResponse) {
					Assert.assertEquals(firmIdDB.get(j), firmIdAPI.get(j));
					Assert.assertEquals(FirmNameDB.get(j), FirmNameAPI.get(j));

					if (FirmNameDB.get(j).equalsIgnoreCase(FirmNameAPI.get(j))) {
						flag = "true";

					}

					Reporter.addStepLog("Family ID" + " - " + firmIdDB.get(j) + " | Family Name in DB: "
							+ FirmNameDB.get(j) + " | Family Name in API: " + FirmNameAPI.get(j) + "| " + flag);
					j++;
				}
			} else if (countETFInResponse == 0) {
				Reporter.addStepLog("No Data present for ETF in DB for progrmaCode:" + programCode);
			}
			sa.assertAll();
		}
	}
}