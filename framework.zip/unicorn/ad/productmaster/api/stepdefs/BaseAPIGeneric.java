package qa.unicorn.ad.productmaster.api.stepdefs;



import java.util.List;
import java.util.Map;

import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class BaseAPIGeneric {
	
	
	 private static String token;
	 private static Response response;
	 private static String jsonString;
	 private static String USERNAME="V003PMB7";
	 String BASE_URL="https://sandbox02-apigateway.broadridge.com/unicorn/v2/token";

	
	
	@Given("^The Base URL is connected to the service$")
	 public void listOfBooksAreAvailable() {
	 RestAssured.baseURI = BASE_URL;
	 RequestSpecification request = RestAssured.given();
	 response = request.post("https://ws.dev.bpsuspm.prd.bfsaws.net/productmaster/v1/searchstyleclassificationapi");
	 
	 jsonString = response.asString();
	 List<Map<String, String>> books = JsonPath.from(jsonString).get("listCode");
	 Assert.assertTrue(books.size() > 0);
	 
	String Id = books.get(0).get("E1"); 
	System.out.println("ID is:"+Id);
	 }
	/* @Given("^I am an authorized user$")
	 public void iAmAnAuthorizedUser() {
	 
	 RestAssured.baseURI = BASE_URL;
	 RequestSpecification request = RestAssured.given();
	 
	 request.header("Content-Type", "application/json");
	 request.header("Subject", USERNAME);
	 response = request.body("{}").post(BASE_URL);
	 
	 String jsonString = response.asString();
	 token = JsonPath.from(jsonString).get("token");
	
	 System.out.println("token generated is :"+token);
	 }*/
}