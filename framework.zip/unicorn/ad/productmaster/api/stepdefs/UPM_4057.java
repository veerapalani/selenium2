package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;

public class UPM_4057 {
	
	String filePath = "./src/test/resources/ad/productmaster/api/excel/";
	ExcelUtils exlObj; // = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;// = exlObj.getSheet(sheetName);
	String jobType, clientNum, processStatus, foaCode, managerName, address1, address2, address3 = null;
	String city, state, zipCode, highRange = null;
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	
	@Given("^User has the (.*)$")
	public void user_has_excelFile(String fileName) {
	 filePath = filePath + fileName;   
	}

	@When("^User reads file$")
	public void user_reads_file() {
		exlObj = new ExcelUtils(ExcelOperation.LOAD, filePath);
		sheet = exlObj.getSheet("Sheet1");
		
		for(int i=1; i<3; i++){
			jobType = (String) exlObj.getCellData(sheet, i, 0).toString().trim();
			clientNum = (String) exlObj.getCellData(sheet, i, 1).toString().trim();
			processStatus = (String) exlObj.getCellData(sheet, i, 2).toString().trim();
			foaCode = (String) exlObj.getCellData(sheet, i, 3).toString().trim();
			highRange = (String) exlObj.getCellData(sheet, i, 6).toString().trim();
			managerName = (String) exlObj.getCellData(sheet, i, 7).toString().trim();
			address1 = (String) exlObj.getCellData(sheet, i, 8).toString().trim();
			address2 = (String) exlObj.getCellData(sheet, i, 9).toString().trim();
			address3 = (String) exlObj.getCellData(sheet, i, 10).toString().trim();
			city = (String) exlObj.getCellData(sheet, i, 11).toString().trim();
			state = (String) exlObj.getCellData(sheet, i, 12).toString().trim();
			zipCode = (String) exlObj.getCellData(sheet, i, 13).toString().trim();
			
			if(jobType.equals("+")) {
				jobType = "29";
			}else if (jobType.equals("-")) {
				jobType = "784";
			} else {
				jobType = "783";
			}
		}
		
		
	    
	}

	@Then("^User is able to validate data from file in PM DB$")
	public void user_is_able_to_validate_data_from_file_in_PM_DB() {
		pmdb.DBConnectionStart();
		
		String query = "select c.type as job_type, s.strategy_code as cons_key,c.contact_first_name as managername,c.contact_address as NAMEADDR, c.contact_addres_2 as NAMEADDR," + 
				"c.contact_addres_3 as NAMEADDR, c.contact_city as NAMEADDR, c.contact_state as NAMEADDR, c.contact_postal_code as ZIPCODE" + 
				"from contact c, strategy s, contact_assoc ca where c.contact_id = ca.contact_id and c.type = " +jobType+ 
				"and ca.reference_id = s.strategy_id and s.strategy_code = '"+foaCode+"'";
		
		ResultSet rs = DBManager.executeSelectQuery(query);
		
		pmdb.DBConnectionClose();
	   
	}

}
