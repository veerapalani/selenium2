package qa.unicorn.ad.productmaster.api.stepdefs;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;

import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

public class BaseAPIGenerateFamCode   {
	EISLBaseAPIGeneric ebg = new EISLBaseAPIGeneric();
	Response response = ebg.response;
//	String statusId = response.jsonPath().getString("templateId");
	SoftAssert sa = new SoftAssert();
	String requestStr = ebg.requestJson;
//	JSONObject requestJson = null;
//	JSONParser parser = new JSONParser();
//	

	

 
	
	@And("verify famCode in API and PMDB")
	public void verify_famCode_in_API_and_PMDB() throws SQLException {

			ProductMasterDBManager pmdb = new ProductMasterDBManager();
			
			String actualFamCode = response.jsonPath().getString("foaFamCode");
			
			ResultSet rs=null;String sqlQuery="";
			String expectedFamCode=null;
			 
			String fam1=null;
			
			      pmdb.DBConnectionStart(); // connecting to PM DB
			      sqlQuery ="select foa_fam_code from strategy_code_universe where is_advisory='false' \r\n" + 
			      		"order by created_on desc limit 1";
			      	System.out.println(sqlQuery);
				
			     	rs = DBManager.executeSelectQuery(sqlQuery);
			     	while (rs.next()) {
				if(rs.getObject(1) !=null)
				{    expectedFamCode=rs.getString(1);
			
				
					}}
					
			    		
			    	Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>FamCode from API</th>\r\n"
							 + "    <th>FamCode from DB</th>\r\n" + "    </tr>");
			    	Reporter.addStepLog("<td>" + actualFamCode.substring(1) + "</td>\r\n"
							+ "    <td>" + expectedFamCode + "	   </td>\r\n");
			    	Reporter.addStepLog("</table></br>");
				    
         		    	sa.assertEquals(actualFamCode.substring(1), expectedFamCode);
         		    	System.out.println("test11"+actualFamCode.substring(1));
         		    	System.out.println(expectedFamCode);
         		    	
      				    pmdb.DBConnectionClose(); // closing PMDB connection
				        sa.assertAll();	
			        }
	

}
		
	
	



