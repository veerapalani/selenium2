package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;

public class BaseAPIAllFAStrategies {

	ProductMasterDBManager pmdb = new ProductMasterDBManager();

	ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD,
			"./src/test/resources/ad/productmaster/api/excel/EISL_BaseAPIMapping.xlsx");
	XSSFSheet sheet = exlObj.getSheet("GET-ALL-FA-STRAT");

	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();

	List<String> fa_code = new ArrayList<String>();
	List<String> strategy_code = new ArrayList<String>();
	List<String> strategy_name = new ArrayList<String>();
	List<String> strategy_status = new ArrayList<String>();
	List<String> style_name = new ArrayList<String>();
	SoftAssert sa = new SoftAssert();
	
	int responseCode = 0;


	
	@SuppressWarnings("deprecation")
	@When("^user creates request json with status as \"([^\"]*)\" and relevant strategies codes$")
    public void user_creates_request_json_with_status_as_something_and_relevant_strategies_codes(String status) throws Throwable {
        String sql = "SELECT strategy_code, random() FROM strategy WHERE status IN"
        		+ "(SELECT list_id FROM list_values WHERE LOWER(list_value) IN('"+status.toLowerCase()+"')) ORDER BY random() LIMIT 2";
        
        System.out.println("SQL: "+sql);
        pmdb.DBConnectionStart();
        
		ResultSet rs = DBManager.executeSelectQuery(sql);
	
            
        String strategyCodes = "";
		
        while(rs.next()) {
			strategyCodes = strategyCodes.concat("\""+rs.getString("strategy_code")+"\"");
		}
        
        /* formatting codes "ABCD""EFGH" -> "ABCD","EFGH" */
        strategyCodes = strategyCodes.replace("\"\"", "\",\"");
  
        pmdb.DBConnectionClose();
        
        /* creating JSON request with status and codes */
        ebag.user_creates_a_request_json_file_with_search_keys_and_values("codes, status", "["+strategyCodes+"];[\""+status+"\"]");
    }
	
	

	@And("^verify the data received from server with Product Master DB for getallfastrategies$")
	public void verify_the_data_received_from_server_with_product_master_db_for_getallfastrategies() throws Throwable {

		responseCode = EISLBaseAPIGeneric.response.getStatusCode();
		
		/* Need to proceed only if status code is 200 */
		if(responseCode!=200) {
			Reporter.addStepLog("Nothing to validate as response code is not 200.");
		} else {
		EISLBaseAPIGeneric ebg = new EISLBaseAPIGeneric();

		String uniqueIdentifierAPI = exlObj.getStringCellData(sheet, 1, 3);

		JSONParser parser = new JSONParser();
		String requestStr = ebg.requestJson;

		JSONObject requestJson = null;
		Response response = ebg.response;

		String uniqueIdentifierValueFromRes = response.jsonPath().getString(uniqueIdentifierAPI);
		String[] uniqueIdentifierFromResArr = uniqueIdentifierValueFromRes.split(",");

		String strategyCodes = null, status = "";

		requestJson = (JSONObject) parser.parse(requestStr);

		try {
			strategyCodes = removeBracketsAndInvertedCommas(requestJson.get("codes").toString());
			status = removeBracketsAndInvertedCommas(requestJson.get("status").toString());
		} catch (Exception e) {

		}
		
		/* if multiple codes in response */
		if(strategyCodes.contains(",")) {
			String [] temp = strategyCodes.split(",");
			strategyCodes = "";
			
			for(String code:temp) {
				strategyCodes = strategyCodes.concat("\""+removeBracketsAndInvertedCommas(code)+"\"");
			}
			
			 /* formatting codes "ABCD""EFGH" -> "ABCD","EFGH" */
	        strategyCodes = strategyCodes.replace("\"\"", "\",\"");
	        strategyCodes = strategyCodes.replace("\"", "'");
		} else 
			strategyCodes = "'" + strategyCodes + "'";

		String sql = "select fa.fa_code, strategy_code, strategy_name, style_name, \r\n"
				+ "(select list_value from list_values where list_id = s.status) as status\r\n"
				+ "from strategy s, style st, financial_advisor fa, strategy_financial_advisor sfa where\r\n"
				+ "sfa.strategy_id = s.strategy_id and sfa.fa_id = fa.fa_id and s.style_id = st.style_id ";

		if (strategyCodes.length() > 0) {
			sql = sql + "and strategy_code IN (" + strategyCodes + ")";
		}

		if (status.length() > 0) {
			
			pmdb.DBConnectionStart();
			
			String sql1 = "select list_id from list_values where "
					+ "list_type = 'STRATEGY STATUS' and list_value = '"+status+"'";
			System.out.println(sql1);
			
			ResultSet rs = DBManager.executeSelectQuery(sql1);
			while(rs.next()) {
				status = rs.getString("list_id");
			}
			
			pmdb.DBConnectionClose();
			
			
			sql = sql + "and s.status='" + status + "' ";
		}

		pmdb.DBConnectionStart();

		System.out.println(sql);

		/* Getting all values from DB and storing in a list */
		ResultSet rs = DBManager.executeSelectQuery(sql);
		int count = 0;
		while (rs.next()) {
			fa_code.add(count, rs.getString("fa_code").trim());
			strategy_code.add(count, rs.getString("strategy_code").trim());
			strategy_name.add(count, rs.getString("strategy_name").trim());
			strategy_status.add(count, rs.getString("status").trim());
			style_name.add(count, rs.getString("style_name").trim());

			count++;
		}

		Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>Attribute from API </th>\r\n"
				+ "    <th>Value</th>\r\n" + "    <th>Available in expected list</th>\r\n" + "    </tr>");

		count = 0;
		for (String n : uniqueIdentifierFromResArr) {
			String faIdApi = removeBracketsAndInvertedCommas(response.jsonPath()
					.getString(exlObj.getStringCellData(sheet, 1, 3).concat("[" + count + "]")));
			String foaCodeApi = removeBracketsAndInvertedCommas(response.jsonPath()
					.getString(exlObj.getStringCellData(sheet, 2, 3).concat("[" + count + "]")));
			String strategyNameApi = removeBracketsAndInvertedCommas(response.jsonPath()
					.getString(exlObj.getStringCellData(sheet, 3, 3).concat("[" + count + "]")));
			String styleNameApi = removeBracketsAndInvertedCommas(response.jsonPath()
					.getString(exlObj.getStringCellData(sheet, 4, 3).concat("[" + count + "]")));
			String statusApi = removeBracketsAndInvertedCommas(response.jsonPath()
					.getString(exlObj.getStringCellData(sheet, 5, 3).concat("[" + count + "]")));

			count++;

			/* logging into report(faId) */
			sa.assertTrue(fa_code.contains(removeBracketsAndInvertedCommas(faIdApi.trim())));
			Reporter.addStepLog("<td>" + exlObj.getStringCellData(sheet, 1, 3).concat("[" + count + "]") + "</td>\r\n"
					+ "    <td>" + faIdApi + "	   </td>\r\n");

			if (fa_code.contains(removeBracketsAndInvertedCommas(faIdApi.trim()))) {
				Reporter.addStepLog("<td style = 'color:green'>true</td>\r\n" + "  </tr>");
			} else {
				Reporter.addStepLog("<td style = 'color:red'>false</td>\r\n" + "  </tr>");
			}

			/* logging into report(foaCode) */
			sa.assertTrue(strategy_code.contains(removeBracketsAndInvertedCommas(foaCodeApi.trim())));
			Reporter.addStepLog("<td>" + exlObj.getStringCellData(sheet, 2, 3).concat("[" + count + "]") + "</td>\r\n"
					+ "    <td>" + foaCodeApi + "	   </td>\r\n");

			if (strategy_code.contains(removeBracketsAndInvertedCommas(foaCodeApi.trim()))) {
				Reporter.addStepLog("<td style = 'color:green'>true</td>\r\n" + "  </tr>");
			} else {
				Reporter.addStepLog("<td style = 'color:red'>false</td>\r\n" + "  </tr>");
			}

			/* logging into report(strategyName) */
			sa.assertTrue(strategy_name.contains(removeBracketsAndInvertedCommas(strategyNameApi.trim())));
			Reporter.addStepLog("<td>" + exlObj.getStringCellData(sheet, 3, 3).concat("[" + count + "]") + "</td>\r\n"
					+ "    <td>" + strategyNameApi + "	   </td>\r\n");

			if (strategy_name.contains(removeBracketsAndInvertedCommas(strategyNameApi.trim()))) {
				Reporter.addStepLog("<td style = 'color:green'>true</td>\r\n" + "  </tr>");
			} else {
				Reporter.addStepLog("<td style = 'color:red'>false</td>\r\n" + "  </tr>");
			}

			/* logging into report(styleName) */
			sa.assertTrue(style_name.contains(removeBracketsAndInvertedCommas(styleNameApi.trim())));
			Reporter.addStepLog("<td>" + exlObj.getStringCellData(sheet, 4, 3).concat("[" + count + "]") + "</td>\r\n"
					+ "    <td>" + styleNameApi + "	   </td>\r\n");

			if (style_name.contains(removeBracketsAndInvertedCommas(styleNameApi.trim()))) {
				Reporter.addStepLog("<td style = 'color:green'>true</td>\r\n" + "  </tr>");
			} else {
				Reporter.addStepLog("<td style = 'color:red'>false</td>\r\n" + "  </tr>");
			}

			/* logging into report(status) */
			sa.assertTrue(strategy_status.contains(removeBracketsAndInvertedCommas(statusApi.trim())));
			Reporter.addStepLog("<td>" + exlObj.getStringCellData(sheet, 5, 3).concat("[" + count + "]") + "</td>\r\n"
					+ "    <td>" + statusApi + "	   </td>\r\n");

			if (strategy_status.contains(removeBracketsAndInvertedCommas(statusApi.trim()))) {
				Reporter.addStepLog("<td style = 'color:green'>true</td>\r\n" + "  </tr>");
			} else {
				Reporter.addStepLog("<td style = 'color:red'>false</td>\r\n" + "  </tr>");
			}

		}
		Reporter.addStepLog("</table></br>");
		ebg.setCollapsibleHtml("Expected List for faIds", fa_code.toString());
		ebg.setCollapsibleHtml("Expected List for foaCode", strategy_code.toString());
		ebg.setCollapsibleHtml("Expected List for strategyName", strategy_name.toString());
		ebg.setCollapsibleHtml("Expected List for styleName", style_name.toString());
		ebg.setCollapsibleHtml("Expected List for status", strategy_status.toString());

		pmdb.DBConnectionClose();
		
		
		/* END of else */
		}

	}

	@And("^verify the \"([^\"]*)\" name for given strategy for getallfastrategies$")
	public void verify_the_something_name_for_given_strategy(String strArg1) throws Throwable {
		
		responseCode = EISLBaseAPIGeneric.response.getStatusCode();
		
		/* Need to proceed only if status code is 200 */
		if(responseCode!=200) {
			Reporter.addStepLog("Nothing to validate as response code is not 200.");
		} else {

		String strategyCodeAPI = EISLBaseAPIGeneric.response.jsonPath().getString("foaCodes.foaCode");

		String reportingNameAct = "", programCodesAct = "";
		String reportingNameExp = "";

		String[] strategyCodeAPIArr = strategyCodeAPI.split(",");
		String[] programCodesAPIArr = null;

		pmdb.DBConnectionStart();

		/* Checking number of total strategies in response */
		for (int countParent = 0; countParent < strategyCodeAPIArr.length; countParent++) {
			strategyCodeAPI = EISLBaseAPIGeneric.response.jsonPath()
					.getString("foaCodes[" + countParent + "].foaCode[0]");
			programCodesAct = EISLBaseAPIGeneric.response.jsonPath()
					.getString("foaCodes[" + countParent + "].reportingStrategyNames.programCode[0]");
			programCodesAPIArr = programCodesAct.split(",");

			/*
			 * Checking number of total programs/reporting name with a strategy one strategy
			 * can have multiple names (eg: linked with 36 and 46 program)
			 */
			for (int countChild = 0; countChild < programCodesAPIArr.length; countChild++) {
				reportingNameAct = EISLBaseAPIGeneric.response.jsonPath().getString("foaCodes.reportingStrategyNames["
						+ countParent + "]" + ".reportingStrategyName[" + countChild + "]");

				programCodesAct = EISLBaseAPIGeneric.response.jsonPath().getString(
						"foaCodes.reportingStrategyNames[" + countParent + "]" + ".programCode[" + countChild + "]");

				reportingNameExp = ebag.GenerateReportingStratageyName(strategyCodeAPI,
						removeBracketsAndInvertedCommas(programCodesAct));

				Reporter.addStepLog("------------------------- " + strategyCodeAPI + " | " + programCodesAct
						+ " -----------------------------");
				Reporter.addStepLog("<b>Expected (Database): </b>" + reportingNameExp);
				Reporter.addStepLog("<b>Actual (API): </b>" + removeBracketsAndInvertedCommas(reportingNameAct));
				Reporter.addStepLog("-------------------------------------------------------------------------");

				sa.assertEquals(removeBracketsAndInvertedCommas(reportingNameAct),
						removeBracketsAndInvertedCommas(reportingNameExp),
						"Values not matched for strategy code: " + strategyCodeAPI);

				System.out.println("Checked for strategy code: " + strategyCodeAPI);

			}

		}

		pmdb.DBConnectionClose();
		sa.assertAll();
		
		/*END of else*/
		}
	}
	
	
	
	

	public String removeBracketsAndInvertedCommas(String s) {
		try {
		s = s.replace("\"", "");
		s = s.replace("[", "");
		s = s.replace("]", "");
		} catch(Exception e) {
			System.out.println("Inside catch - removeBracketsAndInvertedCommas");
		}
		return s;
	}
}
