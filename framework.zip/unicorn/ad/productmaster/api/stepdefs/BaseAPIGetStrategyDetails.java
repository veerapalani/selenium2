package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet; 
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

@SuppressWarnings("deprecation")
public class BaseAPIGetStrategyDetails {

	String requestJsonStr = EISLBaseAPIGeneric.requestJson;
	ProductMasterGeneric pmg = new ProductMasterGeneric();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	String jwtToken = EISLBaseAPIGeneric.jwtToken;
	static JSONArray repCodes = null, branch = null, entitlements = null;
	List<String> strategyCodes = new ArrayList<String>();
	List<String> allStrategyCodes = new ArrayList<String>();

	JSONObject requestJson = null;
	JSONParser parser = new JSONParser();

	String srvcName = null;
	String user = null;

	SoftAssert sa = new SoftAssert();
	int count = 0;

	@And("^verify the \"([^\"]*)\" name for given strategy$")
	public void verify_the_something_name_for_given_strategy(String strArg1) throws Throwable {

		String strategyCodeAPI = EISLBaseAPIGeneric.response.jsonPath().getString("strategyCode");

		String reportingNameAct = "", programCodesAct = "";
		String reportingNameExp = "";

		String[] strategyCodeAPIArr = strategyCodeAPI.split(",");
		String[] programCodesAPIArr = null;

		pmdb.DBConnectionStart();

		/* Checking number of total strategies in response */
		for (int countParent = 0; countParent < strategyCodeAPIArr.length; countParent++) {
			strategyCodeAPI = EISLBaseAPIGeneric.response.jsonPath().getString("strategyCode[" + countParent + "]");
			programCodesAct = EISLBaseAPIGeneric.response.jsonPath()
					.getString("reportingStrategyNames[" + countParent + "].programCode");
			programCodesAPIArr = programCodesAct.split(",");

			/*
			 * Checking number of total programs/reporting name with a strategy one strategy
			 * can have multiple names (eg: linked with 36 and 46 program)
			 */
			for (int countChild = 0; countChild < programCodesAPIArr.length; countChild++) {
				reportingNameAct = EISLBaseAPIGeneric.response.jsonPath().getString(
						"reportingStrategyNames[" + countParent + "]" + ".reportingStrategyName[" + countChild + "]");

				programCodesAct = EISLBaseAPIGeneric.response.jsonPath()
						.getString("reportingStrategyNames[" + countParent + "]" + ".programCode[" + countChild + "]");

				reportingNameExp = ebag.GenerateReportingStratageyName(strategyCodeAPI, programCodesAct);

				Reporter.addStepLog("------------------------- " + strategyCodeAPI + " | " + programCodesAct
						+ " -----------------------------");
				Reporter.addStepLog("<b>Expected (Database): </b>" + reportingNameExp);
				Reporter.addStepLog("<b>Actual (API): </b>" + reportingNameAct);
				Reporter.addStepLog("-------------------------------------------------------------------------");

				sa.assertEquals(reportingNameAct, reportingNameExp,
						"Values not matched for strategy code: " + strategyCodeAPI);

			}

		}

		pmdb.DBConnectionClose();
		sa.assertAll();
	}

	@And("^system is checking eligible repcodes and branch numbers for given user (.+)$")
	public void system_is_checking_eligible_repcodes_and_branch_numbers_for_given_user(String userid) throws Throwable {
		user = userid;

		String[] chunks = jwtToken.split("\\.");

		Base64.Decoder decoder = Base64.getUrlDecoder();

		// String header = new String(decoder.decode(chunks[0])); --not required
		String payload = new String(decoder.decode(chunks[1]));

		/* converting string to JSON Object */
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(payload);

		JSONObject authz = (JSONObject) json.get("authz");

		repCodes = (JSONArray) authz.get("repcodes");
		entitlements = (JSONArray) authz.get("entitlements");
		branch = (JSONArray) authz.get("branch");

		Reporter.addStepLog("<b>RepCodes: </b>" + repCodes.toString().replaceAll("\",\"", "\" , \""));
		Reporter.addStepLog("<b>Branch: </b>" + branch.toString().replaceAll("\",\"", "\" , \""));
		Reporter.addStepLog("<b>Entitlements: </b>" + entitlements.toString().replaceAll("\",\"", "\" , \""));

	}

	@When("^user selects \"([^\"]*)\" number of \"([^\"]*)\" strategies from PM DB(.*)$")
	public void user_selects_something_number_of_strategies_from_pm_db_according_to_repcodes_and_branch(int count,
			String type, String serviceName) throws Throwable {

		this.count = count;
		srvcName = serviceName;
		// sysout(GenerateSQLWithBranchAndRepCodes(repCodes, branch, count,
		// type));

		/*
		 * Nullifying so that list will be ready for new set of codes for next
		 * scenarios.
		 */
		strategyCodes.clear();

		pmdb.DBConnectionStart();

		/*
		 * Getting final SQL according to the repcodes, branch number and counts for PMP
		 * strategies. Only if entitlements contains "PRODM_PMPSTRATEGIES_SERVICE"
		 */
		if (entitlements.toString().contains("PRODM_PMPSTRATEGIES_SERVICE")) {
			String sqlQueryPMP = GetSQLWithBranchAndRepCodesForPMP(repCodes, branch, count, type);

			ebag.setCollapsibleHtml("SQL Query used for PMP - click here to view", sqlQueryPMP);

			ResultSet rs_pmp = DBManager.executeSelectQuery(sqlQueryPMP);

			while (rs_pmp.next()) {
				strategyCodes.add(rs_pmp.getString("strategy_code"));
				allStrategyCodes.add(rs_pmp.getString("strategy_code"));
			}
		}

		/* not required for getallfastrategies */
		if (!serviceName.contains("getallfastrategies")) {

			/*
			 * if user has "PRODM_NONPMPSTRATEGIES_SERVICE" entitlement, then we're fetching
			 * NON PMP strategies also & only for entitled scenario
			 */
			if (type.equalsIgnoreCase("Entitled")) {
				if (entitlements.toString().contains("PRODM_NONPMPSTRATEGIES_SERVICE")) {
					String sqlQuery = GetSQLForSMAStrategies(count);

					ebag.setCollapsibleHtml("SQL Query used for SMA - click here to view", sqlQuery);

					ResultSet rs_sma = DBManager.executeSelectQuery(sqlQuery);

					while (rs_sma.next()) {
						strategyCodes.add(rs_sma.getString("strategy_code"));
					}
				}
			}
		} /* IF ENDS here for getallfastrategies */

		/*
		 * Special case, when user has NON PMP and PRODM_SERVICE access, scenarios is to
		 * check not eligible strategies to search. From above code, if strategyCodes
		 * will not have any value we're adding a value. This case is for USER ID:
		 * V005QS01
		 */
		if (strategyCodes.size() <= 0) {
			strategyCodes.add("AE0H");
		}

		pmdb.DBConnectionClose();

		/* Printing in reports */
		Reporter.addStepLog("</br><b>" + type + " strategy codes are:</b>");

		for (String code : strategyCodes) {
			Reporter.addStepLog(code);
		}

	}

	@And("^user creates a request JSON file with \"([^\"]*)\" strategy codes$")
	public void user_creates_a_request_json_file_with_something_strategy_codes(String type) throws Throwable {
		String value = "";

		/* For either Entitled or not entitled */
		if (!type.equalsIgnoreCase("entitled & not entitled")) {

			for (String code : strategyCodes) {

				value = value + "\"" + code + "\"";
			}
		}

		/* For mixed codes i.e. Entitled and Not Entitled. */
		else {
			for (String code : allStrategyCodes) {

				value = value + "\"" + code + "\"";
			}

		}

		/* formatting "S051""AD0L""IA41" -> ["S051","AD0L","IA41"]; */
		value = value.replace("\"\"", "\",\"");
		value = "[" + value + "];";

		ebag.user_creates_a_request_json_file_with_search_keys_and_values("codes", value);

	}

	@And("^user is able to see only entitled codes in response$")
	public void user_is_able_to_see_only_entitled_codes_in_response() {
		int totalSize = allStrategyCodes.size();

		List<String> expectedCodes = new ArrayList<String>();

		/*
		 * First half will be entitled and second half will be not entitled, need to
		 * maintain this in FF | When user selects "3" number of "Entitled" strategies
		 * from PM DB | When user selects "3" number of "Not Entitled" strategies from PM
		 * DB
		 * 
		 */

		for (int n = 0; n < totalSize / 2; n++) {
			expectedCodes.add(allStrategyCodes.get(n));
		}

		String actCodes = "";
		String serviceName = EISLBaseAPIGeneric.serviceName;
		if (serviceName.equalsIgnoreCase("getstrategydetails")) {
			actCodes = EISLBaseAPIGeneric.response.body().jsonPath().getString("strategyCode");
		} else if (serviceName.equalsIgnoreCase("searchstrategyapi")) {
			actCodes = EISLBaseAPIGeneric.response.body().jsonPath().getString("code");
		} else {
			Assert.assertTrue("Something went wrong..!! Please check service name.", false);
		}

		String[] actCodesArr = actCodes.split(",");

		for (int i = 0; i < actCodesArr.length; i++) {
			boolean flag = expectedCodes.contains(pmg.RemoveSquareBrackets(actCodesArr[i].trim()));
			sa.assertTrue(flag, "code: [" + pmg.RemoveSquareBrackets(actCodesArr[i].trim()) + "] NOT FOUND..!!");
		}
		
		Reporter.addStepLog("<b>Expected Codes: </b>" + expectedCodes.toString().replace("[", "").replace("]", ""));
		Reporter.addStepLog("<b>Actual Codes: </b>" + Arrays.toString(actCodesArr).replace("[", "").replace("]", ""));
		
		sa.assertEquals(actCodesArr.length, expectedCodes.size()," Expected and Actual Size differs.");
		
		sa.assertAll();

	}

	/* For searchstrategyapi */
	@And("^counts of strategy in response is equal to counts from DB$")
	public void counts_of_strategy_in_response_is_equals_to_counts_from_DB() throws ParseException, SQLException {

		requestJson = (JSONObject) parser.parse(EISLBaseAPIGeneric.requestJson);
		String sqlQuery = GetSqlQueryToFetchCounts(requestJson);

		int expCount = ebag.compareCounts(sqlQuery, "");
		String[] arr = EISLBaseAPIGeneric.response.body().jsonPath().getString("identifier").split(", ");
		int actCount = arr.length;

		Reporter.addStepLog("<b>Expected number of strategies:</b> " + expCount);
		Reporter.addStepLog("<b>Actual number of strategies: </b>" + actCount);

		if (expCount != actCount) {
			pmdb.DBConnectionStart();
			ResultSet rs = DBManager
					.executeSelectQuery(sqlQuery.replace("count(distinct s.strategy_id)", "distinct s.strategy_id"));
			List<String> strategyIdsFromAPI = new ArrayList<String>();
			List<String> strategyIdsFromDB = new ArrayList<String>();
			List<String> mismachedStrategyIds = new ArrayList<String>();
			while (rs.next()) {
				strategyIdsFromDB.add(rs.getString("strategy_id"));
			}

			for (String id : arr) {
				strategyIdsFromAPI.add(pmg.RemoveSquareBrackets(id.trim()));
				if (!strategyIdsFromDB.contains(pmg.RemoveSquareBrackets(id.trim()))) {
					mismachedStrategyIds.add(pmg.RemoveSquareBrackets(id.trim()));
				}
			}

			for (String id : strategyIdsFromDB) {
				if (!strategyIdsFromAPI.contains(pmg.RemoveSquareBrackets(id.trim()))) {
					mismachedStrategyIds.add(pmg.RemoveSquareBrackets(id.trim()));
				}
			}
			ebag.setCollapsibleHtml("Mismatched IDs", mismachedStrategyIds.toString());
			pmdb.DBConnectionClose();

		}

		Assert.assertEquals("count mismatched.", expCount, actCount);
	}

	@And("^number of strategies in response is equal to number of codes passed in request$")
	public void number_of_strategies_in_response_is_equal_to_number_of_codes_passed_in_request() throws Throwable {

		String strategyCodesFromAPI = EISLBaseAPIGeneric.response.jsonPath().getString("strategyId");
		int countFromResponse = strategyCodesFromAPI.split(",").length;
		int countFromRequest = strategyCodes.size();

		Reporter.addStepLog("<b>Number of codes in request: </b>" + countFromRequest);
		Reporter.addStepLog("<b>Number of codes in response: </b>" + countFromResponse);

		/*
		 * Special Case for User V005QSMB and not for getallfastrategies We have to
		 * check if we're getting both PMP and SMA, from FF we will pass a number and in
		 * request we should have same number of PMP and SMA i.e. count will be double
		 * FF: 3, in request & response = (3 PMP + 3 SMA) = 6.
		 */
		if (!srvcName.contains("getallfastrategies") && user.contains("V005QSMB")) {
			if (countFromRequest != (2 * count) || countFromResponse != (2 * count)) {
				Reporter.addStepLog(
						"<b> Expected number of codes are not present in Request/Response, Please check..! </b>");
				Reporter.addStepLog("Special Case for User V005QSMB and not for getallfastrategies We have to\r\n"
						+ "		 * check if we're getting both PMP and SMA, from FF we will pass a number and in\r\n"
						+ "		 * request we should have same number of PMP and SMA i.e. count will be double\r\n"
						+ "		 * FF: 3, in request & response = (3 PMP + 3 SMA) = 6");
				Assert.assertTrue("Either PMP or SMA codes are missing..", false);
			}
		}
		Assert.assertEquals("Mismatched..!! Check codes in response and request.", countFromRequest, countFromResponse);

		/*
		 * Nullifying so that list will be ready for new set of codes for next
		 * scenarios.
		 */
		strategyCodes.clear();
	}
	
	@And("^firmName in response should start with name from request i.e. \"([^\"]*)\"$")
	public void fundFamilyName_In_response_should_contains_name_from_request(String firmNameReq) {
		String[] firmNameRes = EISLBaseAPIGeneric.response.jsonPath().getString("firmName").split(",");
		String[] strategyCodesRes = EISLBaseAPIGeneric.response.jsonPath().getString("code").split(",");

		/* Setting table headers */
		ebag.SetAndPrintTableHeaders(
				"strategyCode|firmName (from response) | firmName (from req) | Result");

		for (int i = 0; i < firmNameRes.length; i++) {

			String firmNameStr = pmg.RemoveSquareBrackets(firmNameRes[i]).trim();
			String strategyCodesStr = pmg.RemoveSquareBrackets(strategyCodesRes[i]).trim();
			Boolean flag = true;
			if (!firmNameStr.toLowerCase().contains(firmNameReq.toLowerCase())) {
				sa.assertEquals(true, false,
						"firm name mismatched for strategyCode: " + strategyCodesStr);
				flag = false;
			}
			ebag.SetAndPrintTableRows(
					strategyCodesStr + "|" + firmNameStr + "|" + firmNameReq + "|" + flag);
		}
		ebag.SetAndPrintTableFooter();
		sa.assertAll();

	}

	/**
	 * Function to return SQL according to provided RepCodes and Branch Numbers
	 * ORDER BY RANDOM() -> this will give different rows every time
	 */

	String GetSQLWithBranchAndRepCodesForPMP(JSONArray rr_code, JSONArray branch_number, int count, String type) {

		String sql = "SELECT distinct strategy_code, RANDOM() FROM strategy s, financial_advisor fa, \r\n"
				+ "strategy_financial_advisor sfa, rr_mapping rm WHERE\r\n"
				+ "s.strategy_id = sfa.strategy_id AND sfa.fa_id = fa.fa_id AND \r\n"
				+ "s.status IN (SELECT list_id FROM list_values WHERE list_type = 'STRATEGY STATUS' AND list_value NOT IN ('Source DAAD','Rejected','Pending HO Approval','Draft','Pending'))\r\n"
				+ "AND fa.fa_code = rm.fa_code AND ";

		String additionalQuery = "";

		if (rr_code.size() > 0) {
			additionalQuery = "rm.rr_code $type (" + pmg.RemoveSquareBrackets(rr_code.toString().replace("\"", "'"))
					+ ")";

		}

		if (branch_number.size() > 0) {
			if (additionalQuery.length() > 0) {

				/* Removing 5 from branch, in JWT = '5AB', in DB = 'AB' */
				additionalQuery = additionalQuery + " OR rm.branch_number $type ("
						+ pmg.RemoveSquareBrackets(branch_number.toString().replace("\"", "'").replace("'5", "'"))
						+ ")";
			} else {
				additionalQuery = "rm.branch_number $type ("
						+ pmg.RemoveSquareBrackets(branch_number.toString().replace("\"", "'").replace("'5", "'"))
						+ ")";
			}
		}

		/*
		 * hard-coded, when user is having all 3 entitlements but no repcodes and branch
		 * numbers
		 */
		if (rr_code.size() == 0 && branch_number.size() == 0) {
			additionalQuery = "rm.rr_code $type ('') OR rm.branch_number $type ('')";
		}

		/* Changing condition according to requirements */
		if (type.equalsIgnoreCase("entitled")) {
			additionalQuery = additionalQuery.replace("$type", "IN");
		} else
			additionalQuery = additionalQuery.replace("$type", "NOT IN");

		/* formatting additional query in a bracket if we have additional query */
		if (additionalQuery.length() > 0) {
			additionalQuery = "(" + additionalQuery + ")";
		}

		/* final sql query */
		sql = sql + additionalQuery;

		/* RANDOM() and Length */
		sql = sql.concat(" ORDER BY RANDOM() LIMIT " + count);

		return sql;
	}

	/**
	 * This will return SMA(Non PMP) strategy codes.
	 * 
	 * @param count
	 * @return sql with limit
	 */

	String GetSQLForSMAStrategies(int count) {

		return "SELECT distinct strategy_code, RANDOM() FROM strategy s, program_strategy ps, program p\r\n"
				+ "WHERE ps.strategy_id = s.strategy_id AND ps.program_id = p.program_id AND \r\n"
				+ "s.status IN (SELECT list_id FROM list_values WHERE list_type = 'STRATEGY STATUS' "
				+ "AND list_value NOT IN ('Source DAAD','Rejected','Pending HO Approval','Draft','Pending'))\r\n"
				+ "AND p.program_code IN ('13','15','16','36','39','46') ORDER BY RANDOM() LIMIT " + count;
	}

	/**
	 * Function to get SQL query for counts
	 * 
	 * @return SQL
	 *
	 */

	String GetSqlQueryToFetchCounts(JSONObject request) {
		String sql = "select count(distinct s.strategy_id) from strategy s \r\n"
				+ "join program_strategy ps on s.strategy_id = ps.strategy_id\r\n"
				+ "join program p on p.program_id = ps.program_id\r\n" + "join style st on st.style_id = s.style_id\r\n"
				+ "left join manager m on m.manager_id = s.manager_id\r\n"
				+ "left join strategy_financial_advisor sfa on sfa.strategy_id = s.strategy_id\r\n"
				+ "left join financial_advisor fa on fa.fa_id = sfa.fa_id\r\n"
				+ "left join fa_team fat on fat.fa_team_id = s.fa_team_id\r\n"
				+ "left join node_id_rollup nir on nir.reference_id = s.style_id and nir.reference_type = 'STYLE' and nir.rollup_type_flag = 'F' and nir.effective_to_date is null\r\n"
				+ "where s.status not in (select list_id from list_values where lower(list_value) in ('pending','draft','rejected','source daad','pending ho approval')) \r\n";

		String additionalQuery = "";

		if (requestJson.containsKey("codes")) {
			String codes = getMultipleValues(requestJson.get("codes").toString());
			additionalQuery = additionalQuery + " and s.strategy_codes in (" + codes + ")";
		}

		if (requestJson.containsKey("faCodes")) {
			String faCodes = getMultipleValues(requestJson.get("faCodes").toString());
			additionalQuery = additionalQuery + " and fa.fa_code in (" + faCodes + ")";
		}

		if (requestJson.containsKey("faId")) {
			additionalQuery = additionalQuery + " and fa.fa_id = '" + requestJson.get("faId") + "'";
		}

		if (requestJson.containsKey("styleClassificationId")) {
			additionalQuery = additionalQuery + " and nir.style_node_id = '" + requestJson.get("styleClassificationId")
					+ "'";
		}

		if (requestJson.containsKey("programId")) {
			additionalQuery = additionalQuery + " and p.program_id = '" + requestJson.get("programId") + "'";
		}

		if (requestJson.containsKey("programName")) {
			additionalQuery = additionalQuery + " and p.program_name = '" + requestJson.get("programName") + "'";
		}

		if (requestJson.containsKey("programCode")) {
			additionalQuery = additionalQuery + " and p.program_code = '" + requestJson.get("programCode") + "'";
		}
		if (requestJson.containsKey("minimumInvestmentAmount")) {
			additionalQuery = additionalQuery + " and s.strategy_minimum <="
					+ requestJson.get("minimumInvestmentAmount");
		}

		if (requestJson.containsKey("riskCategory")) {
			int riskCategory = Integer.parseInt(requestJson.get("riskCategory") + "");

			if (riskCategory != 0) {
				additionalQuery = additionalQuery + " and s.risk_category in\r\n"
						+ "(select list_id from list_values where list_type = 'RISK' and "
						+ "CAST(list_code AS int) != 0 and CAST(list_code AS int) <=" + riskCategory + ")";
			}
			// if zero, we need to send everything
		}

		if (requestJson.containsKey("firmId")) {
			additionalQuery = additionalQuery + " and m.firm_id = '" + requestJson.get("firmId") + "'";
		}

		if (requestJson.containsKey("firmName")) {
			additionalQuery = additionalQuery + " and m.firm_name ilike '" + requestJson.get("firmName") + "%'";
		}

		if (requestJson.containsKey("managerCode")) {
			additionalQuery = additionalQuery + " and m.manager_code = '" + requestJson.get("managerCode") + "'";
		}

		if (requestJson.containsKey("rating")) {

		}

		if (requestJson.containsKey("strategyId")) {
			additionalQuery = additionalQuery + " and s.strategy_id = '" + requestJson.get("strategyId") + "'";
		}
		if (requestJson.containsKey("strategyName")) {
			additionalQuery = additionalQuery + " and s.strategy_name = '" + requestJson.get("strategyName") + "'";
		}

		if (requestJson.containsKey("status")) {
			String statusVal = getMultipleValues(requestJson.get("status").toString());
			additionalQuery = additionalQuery
					+ " and s.status in (select list_id from list_values where list_value in (" + statusVal + "))";
		}

		sql = sql + additionalQuery;
		ebag.setCollapsibleHtml("SQL Query Used", sql);

		return sql;
	}

	String getMultipleValues(String s) {
		try {
			s = s.replace("\"", "");
			s = s.replace("[", "");
			s = s.replace("]", "");
		} catch (Exception e) {
			
		}

		/* if multiple values in request */
		if (s.contains(",")) {
			String[] temp = s.split(",");
			s = "";

			for (String code : temp) {
				s = s.concat("'" + code + "'");
			}

			/* formatting codes 'ABCD''EFGH' -> 'ABCD','EFGH' */
			s = s.replace("''", "','");
		} else
			s = "'" + s + "'";

		return s;
	}
}
