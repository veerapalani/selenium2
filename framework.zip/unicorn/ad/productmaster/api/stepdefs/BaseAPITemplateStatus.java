package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;

import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;
import java.sql.ResultSet;

import org.owasp.html.examples.EbayPolicyExample;
import org.testng.Assert;

import cucumber.api.java.en.And;
import io.restassured.response.Response;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;
import qa.framework.utils.StringUtility;

public class BaseAPITemplateStatus   {
	
	
	
	
	String statusId =null;
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	ProductMasterGeneric pmg = new ProductMasterGeneric();
	
	
	SoftAssert sa = new SoftAssert();
	
	//String requestStr = ebg.requestJson;
	JSONObject requestJson1 = null;
	JSONParser parser = new JSONParser();
	
	 @And("user fetches template testdata from DB (.+) and create JSON file for (.+)")
		//@And("^User fetches template testdata from DB (.+) and creates JSON file for (.+)$")
		public void user_fetches_template_testdata_from_DB(String DBAttribute,String Attribute) throws Throwable {
		 String Values1="";
			String[] DBAttribute1 = null;
			//String additionalQuery1 = "";
			
			if (DBAttribute != null) {
				ProductMasterDBManager pmdb = new ProductMasterDBManager();
				//String additionalQuery = null;
				pmdb.DBConnectionStart();
				String sql = "select " + DBAttribute + " from  strategy where " + DBAttribute + " is not null and "
						+ "status in (select list_id from list_values where list_type='STRATEGY STATUS' and list_value='Eligible')"
						+ " order by RANDOM() limit 1";
				System.out.println(sql);
				ResultSet rs;
				
				rs = DBManager.executeSelectQuery(sql);
				while (rs.next()) {
					Values1 = rs.getString(DBAttribute);
					Reporter.addStepLog("Test data from db for " + DBAttribute + " is :" + Values1);
					System.out.println(Values1);
					pmdb.DBConnectionClose();
				}
		}	
			ebag.user_creates_a_request_json_file_with_search_keys_and_values(Attribute, Values1);
		}
		  

   @And("templateId in response should be same as templateId requested")
	public void templateId_in_response_should_be_same_as_templateId_requested() throws SQLException {
		
		try {
			Response response = EISLBaseAPIGeneric.response;
			 statusId = response.jsonPath().getString("templateId");
			 String requestJson = EISLBaseAPIGeneric.requestJson;
			requestJson1 = (JSONObject) parser.parse(requestJson);
			String reqTemplateId = requestJson1.get("templateId").toString();
			sa.assertEquals(reqTemplateId, statusId);
			Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>TemplateId from request</th>\r\n"
					 + "    <th>TemplateId from response</th>\r\n" + "    </tr>");
	    	Reporter.addStepLog("<td>" + reqTemplateId + "</td>\r\n"
					+ "    <td>" + statusId + "	   </td>\r\n");
	    	Reporter.addStepLog("</table></br>");
		} catch (ParseException e1) {
			
			e1.printStackTrace();
		}
				
	}

  
	
	@Then("verify the template flag in response")
	public void verify_the_template_flag_in_response() throws SQLException {

		
			ProductMasterDBManager pmdb = new ProductMasterDBManager();
			Response response = EISLBaseAPIGeneric.response;
			String actualTemplateFlag = response.jsonPath().getString("templateFlag");
			
			ResultSet rs=null;String sqlQuery="";
			String expectedTemplateFlag=null;
			 
			 expectedTemplateFlag="false";
			if (statusId!=null)
				{
			      pmdb.DBConnectionStart(); // connecting to PM DB
			      sqlQuery ="select 1 where exists(select 1 from strategy where aar_base_template_id='"+statusId+"' or dvp_key_trust_template_id='"
			       +statusId+"');";
			      	System.out.println(sqlQuery);
				
			     	rs = DBManager.executeSelectQuery(sqlQuery);
			     	while (rs.next()) {
				if(rs.getObject(1) !=null) {   
				      expectedTemplateFlag="true";}}
					
			    		
			    	Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>TemplateFlag from API</th>\r\n"
							 + "    <th>TemplateFlag from DB</th>\r\n" + "    </tr>");
			    	Reporter.addStepLog("<td>" + actualTemplateFlag + "</td>\r\n"
							+ "    <td>" + expectedTemplateFlag + "	   </td>\r\n");
			    	Reporter.addStepLog("</table></br>");
				    
         		    	sa.assertEquals(actualTemplateFlag, expectedTemplateFlag);
         		    	System.out.println(actualTemplateFlag);
         		    	System.out.println(expectedTemplateFlag);
      				    pmdb.DBConnectionClose(); // closing PMDB connection
				        sa.assertAll();	
			        }
			
				
			
				
		
			
	}

}
		
	
	



