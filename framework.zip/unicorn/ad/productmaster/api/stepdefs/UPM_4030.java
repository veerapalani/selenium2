package qa.unicorn.ad.productmaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.Reporter;

public class UPM_4030 {
	String filePath = "./src/test/resources/ad/productmaster/api/DataLoadFiles/";
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	Boolean flag = false;
	int notMatched = 0;

	String fStyleNodeId;

	@Given("^File (.+) is available for testing$")
	public void file_name_is_available(String fileName) {
		filePath = filePath + fileName;
		Reporter.addStepLog("<b>FILE Location: </b>" + filePath);

	}

	@Then("^Validating the data from input file for (.+) level attributes$")
	public void validating_the_data_from_input_file_for_something(String entity, List<String> attributes)
			throws IOException {
		File file = new File(filePath);
		BufferedReader br = new BufferedReader(new FileReader(file));

		int rowIndex = 0;

		String line;
		int count = 0;

		if (entity.equalsIgnoreCase("style")) {
			pmdb.DBConnectionStart();
			String sqlQuery = "SELECT * FROM asset_classification WHERE style_node_id = ";
			ResultSet rs;

			/*
			 * For reporting purpose - Table for data validation b/w Data in file and
			 * Database
			 */
			
			Reporter.addStepLog("<table style=\"overflow-x:auto;\" border=1px solid><tr>\r\n" + "    <th>Style Node Id</th>\r\n"
					+ "    <th>Style Name Id</th>\r\n" + "    <th>Style Name</th>\r\n"
					+ "    <th>Style Tire Numeric Code</th>\r\n" + "    <th>Status</th>\r\n" + "    </tr>");

			String fStyleNameId = "", fStyleName = "", fStyleTierNumCode = "", dbStyleNodeId = "", dbStyleNameId = "",
					dbStyleName = "", dbStyleTierNumCode = "";

			while ((line = br.readLine()) != null) {

				fStyleNodeId = line.substring(0, 4).trim();
				fStyleNameId = line.substring(4, 13).trim();
				fStyleName = line.substring(13, 63).trim();
				fStyleTierNumCode = line.substring(63, 69).trim();

				count++;
				try {
					int styleNodeId = Integer.parseInt(fStyleNodeId);

					rs = DBManager.executeSelectQuery(
							"SELECT * FROM asset_classification WHERE style_node_id = '" + fStyleNodeId + "'");

					
						while (rs.next()) {
							dbStyleNodeId = rs.getString("style_node_id").trim();
							dbStyleNameId = rs.getString("style_name_id").trim();
							dbStyleName = rs.getString("style_name").trim();
							dbStyleTierNumCode = rs.getString("style_tier_numeric_code").trim();
						}
					
					/* logging into report(data table) */
					WriteAllAttributesInHTMLTable(fStyleNodeId, fStyleNameId, fStyleName, fStyleTierNumCode, "na");

					if (fStyleNodeId.equals(dbStyleNodeId) && fStyleNameId.equals(dbStyleNameId)
							&& fStyleName.equals(dbStyleName) && fStyleTierNumCode.equals(dbStyleTierNumCode)) {
						WriteStatusInHTMLTable(true);
					} else {
						CheckInExceptionFile(fStyleNodeId);

					}
				} catch (Exception e) {
					WriteAllAttributesInHTMLTable(fStyleNodeId, fStyleNameId, fStyleName, fStyleTierNumCode, "na");
					CheckInExceptionFile(fStyleNodeId);
				}
			}

			pmdb.DBConnectionClose();

		} else if (entity.equalsIgnoreCase("broad asset class")) {
			pmdb.DBConnectionStart();
			ResultSet rs;

			/*
			 * For reporting purpose - Table for data validation b/w Data in file and
			 * Database
			 */
			Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>Style Node Id</th>\r\n"
					+ "    <th>Broad Asset Class Node Id</th>\r\n" + "    <th>Broad Asset Class Name Id</th>\r\n"
					+ "    <th>Broad Asset Class Name</th>\r\n" + "    <th>Broad Asset Class Tire Numeric Code</th>\r\n"
					+ "    <th>Status</th>\r\n" + "    </tr>");

			String fBRCNodeId = "", fBRCNameId = "", fBRCName = "", fBRCTierNumCode = "", dbBRCNodeId = "",
					dbBRCNameId = "", dbBRCName = "", dbBRCTierNumCode = "";
			

			while ((line = br.readLine()) != null) {

				fStyleNodeId = line.substring(0, 4).trim();
				fBRCNodeId = line.substring(69, 73).trim();
				fBRCNameId = line.substring(73, 82).trim();
				fBRCName = line.substring(82, 132).trim();
				fBRCTierNumCode = line.substring(132, 138).trim();

				count++;
				try {
					int styleNodeId = Integer.parseInt(fStyleNodeId);

				rs = DBManager.executeSelectQuery(
						"SELECT * FROM asset_classification WHERE style_node_id = '" + fStyleNodeId + "'");

				try {
					while (rs.next()) {
						dbBRCNodeId = rs.getString("broad_asset_class_node_id").trim();
						dbBRCNameId = rs.getString("broad_asset_class_name_id").trim();
						dbBRCName = rs.getString("broad_asset_class_name").trim();
						dbBRCTierNumCode = rs.getString("broad_asset_class_tier_numeric_code").trim();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				/* logging into report(data table) */
				WriteAllAttributesInHTMLTable(fStyleNodeId,fBRCNodeId,fBRCNameId,fBRCName,fBRCTierNumCode);
				

				if (fBRCNodeId.equals(dbBRCNodeId) && fBRCNameId.equals(dbBRCNameId) && fBRCName.equals(dbBRCName)
						&& fBRCTierNumCode.equals(dbBRCTierNumCode)) {
					WriteStatusInHTMLTable(true);
				} else {
					CheckInExceptionFile(fStyleNodeId);
				} 
			}catch (Exception e) {
				WriteAllAttributesInHTMLTable(fStyleNodeId,fBRCNodeId,fBRCNameId,fBRCName,fBRCTierNumCode);
				CheckInExceptionFile(fStyleNodeId);
			}
			}

			pmdb.DBConnectionClose();

		} else if (entity.equals("asset class")) {
			pmdb.DBConnectionStart();
			ResultSet rs;

			/*
			 * For reporting purpose - Table for data validation b/w Data in file and
			 * Database
			 */
			Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>Style Node Id</th>\r\n"
					+ "    <th>Asset Class Node Id</th>\r\n" + "    <th>Asset Class Name Id</th>\r\n"
					+ "    <th>Asset Class Name</th>\r\n" + "    <th>Asset Class Tire Numeric Code</th>\r\n"
					+ "    <th>Status</th>\r\n" + "    </tr>");

			String fACNodeId = "", fACNameId = "", fACName = "", fACTierNumCode = "", dbACNodeId = "", dbACNameId = "",
					dbACName = "", dbACTierNumCode = "";

			while ((line = br.readLine()) != null) {

				fStyleNodeId = line.substring(0, 4).trim();
				fACNodeId = line.substring(138, 142).trim();
				fACNameId = line.substring(142, 151).trim();
				fACName = line.substring(151, 201).trim();
				fACTierNumCode = line.substring(201, 207).trim();

				count++;
				try {
					int styleNodeId = Integer.parseInt(fStyleNodeId);

				rs = DBManager.executeSelectQuery(
						"SELECT * FROM asset_classification WHERE style_node_id = '" + fStyleNodeId + "'");

				try {
					while (rs.next()) {
						dbACNodeId = rs.getString("asset_class_node_id").trim();
						dbACNameId = rs.getString("asset_class_name_id").trim();
						dbACName = rs.getString("asset_class_name").trim();
						dbACTierNumCode = rs.getString("asset_class_tier_numeric_code").trim();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				/* logging into report(data table) */
				WriteAllAttributesInHTMLTable(fStyleNodeId,fACNodeId,fACNameId,fACName,fACTierNumCode);
				

				if (fACNodeId.equals(dbACNodeId) && fACNameId.equals(dbACNameId) && fACName.equals(dbACName)
						&& fACTierNumCode.equals(dbACTierNumCode)) {
					WriteStatusInHTMLTable(true);
				} else {
					CheckInExceptionFile(fStyleNodeId);
				}
			}catch (Exception e) {
				WriteAllAttributesInHTMLTable(fStyleNodeId,fACNodeId,fACNameId,fACName,fACTierNumCode);
				CheckInExceptionFile(fStyleNodeId);
			}
			}

			pmdb.DBConnectionClose();
		} else if (entity.equals("sub class")) {
			pmdb.DBConnectionStart();
			ResultSet rs;

			/*
			 * For reporting purpose - Table for data validation b/w Data in file and
			 * Database
			 */
			Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>Style Node Id</th>\r\n"
					+ "    <th>Sub Class Node Id</th>\r\n" + "    <th>Sub Class Name Id</th>\r\n"
					+ "    <th>Sub Class Name</th>\r\n" + "    <th>Sub Class Tire Numeric Code</th>\r\n"
					+ "    <th>Status</th>\r\n" + "    </tr>");

			String fSCNodeId = "", fSCNameId = "", fSCName = "", fSCTierNumCode = "", dbSCNodeId = "", dbSCNameId = "",
					dbSCName = "", dbSCTierNumCode = "";

			while ((line = br.readLine()) != null) {

				fStyleNodeId = line.substring(0, 4).trim();
				fSCNodeId = line.substring(207, 211).trim();
				fSCNameId = line.substring(211, 220).trim();
				fSCName = line.substring(220, 270).trim();
				fSCTierNumCode = line.substring(270, 276).trim();

				count++;
				try {
					int styleNodeId = Integer.parseInt(fStyleNodeId);

				rs = DBManager.executeSelectQuery(
						"SELECT * FROM asset_classification WHERE style_node_id = '" + fStyleNodeId + "'");

				try {
					while (rs.next()) {
						dbSCNodeId = rs.getString("sub_class_node_id").trim();
						dbSCNameId = rs.getString("sub_class_name_id").trim();
						dbSCName = rs.getString("sub_class_name").trim();
						dbSCTierNumCode = rs.getString("sub_class_tier_numeric_code").trim();
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				/* logging into report(data table) */
				WriteAllAttributesInHTMLTable(fStyleNodeId, fSCNodeId, fSCNameId, fSCName, fSCTierNumCode);
			

				if (fSCNodeId.equals(dbSCNodeId) && fSCNameId.equals(dbSCNameId) && fSCName.equals(dbSCName)
						&& fSCTierNumCode.equals(dbSCTierNumCode)) {
					WriteStatusInHTMLTable(true);
				} else {
					CheckInExceptionFile(fStyleNodeId);
				}
			}catch (Exception e) {
				WriteAllAttributesInHTMLTable(fStyleNodeId, fSCNodeId, fSCNameId, fSCName, fSCTierNumCode);
				CheckInExceptionFile(fStyleNodeId);
			}
			}

			pmdb.DBConnectionClose();
		}

		Reporter.addStepLog("</table></br>");
		Reporter.addStepLog("<b>Total Count:</b> " + count);
		Reporter.addStepLog("<b>Not Matched:</b> " + notMatched);
	}

	public void CheckInExceptionFile(String expStyleNodeId) throws IOException {
		filePath = "./src/test/resources/ad/productmaster/api/DataLoadFiles/asset_classification_exception";

		// CSVFileUtils exlObj;
		List<String[]> fileData = new ArrayList<String[]>();

		fileData = CSVFileUtils.getInstance().readAllCommaSeparatedValues(filePath);

		String input = "", actStyleNodeId = "", exceptionDetails = "";

		BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));

		/* Reading header outside loop, as it is not required while fetching data */
		input = bufferedReader.readLine();

		int count = 1;
		while ((input = bufferedReader.readLine()) != null) {
			/* Getting code and name (line by line) */
			actStyleNodeId = CSVFileUtils.getInstance().getValue(fileData, count, 0);
			exceptionDetails = CSVFileUtils.getInstance().getValue(fileData, count, 16);
			if (expStyleNodeId.equals(actStyleNodeId)) {
				flag = true;
				System.out.println("FOUND IN EXCEPTION FILE!!");
				Reporter.addStepLog("<td style = 'color:green'>F.I.E. - " + exceptionDetails + " </td>\r\n </tr>");
				break;
			}

			count++;
		}
		if (!expStyleNodeId.equals(actStyleNodeId)) {
			WriteStatusInHTMLTable(flag);
		}

	}

	public void WriteStatusInHTMLTable(Boolean flag) {
		if (flag == true) {
			Reporter.addStepLog("<td style = 'color:green'>MATCHED</td>\r\n" + "  </tr>");
		} else {
			Reporter.addStepLog("<td style = 'color:red'>NOT MATCHED</td>\r\n" + "  </tr>");
			notMatched++;
		}
	}

	public void WriteAllAttributesInHTMLTable(String s1, String s2, String s3, String s4, String s5) {
		if (s5.equals("na")) {
			Reporter.addStepLog("<td>" + s1 + "</td>\r\n" + "    <td>" + s2 + "	   </td>\r\n" + "    <td>" + s3
					+ "    </td>\r\n" + "    <td>" + s4 + "	   </td>\r\n");
		} else {
			Reporter.addStepLog("<td>" + s1 + "</td>\r\n" + "    <td>" + s2 + "	   </td>\r\n" + "    <td>" + s3
					+ "    </td>\r\n" + "    <td>" + s4 + "	   </td>\r\n" + "    <td>" + s5 + "	   </td>\r\n");
		}

	}

}
