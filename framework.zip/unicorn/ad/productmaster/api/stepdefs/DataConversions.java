package qa.unicorn.ad.productmaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.testng.Assert;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;

@SuppressWarnings("deprecation")
public class DataConversions {

	String filePath = "./src/test/resources/ad/productmaster/api/excel/";
	String createdTimeStamp, sheetName = null;
	CSVFileUtils exlObj;
	List<String[]> fileData = new ArrayList<String[]>();
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	int count=0;
	
	ProductMasterDBManager pmdb = new ProductMasterDBManager();

	@Given("File (.+) is present & created on (.+)")
	public void file_PM_STRATEGY_is_present_created_on(String fileName, String timeStamp) {

		filePath = filePath + fileName;
		createdTimeStamp = timeStamp;

	}

	@When("User opens the file")
	public void user_opens_the_file() {

		/* Setting up CSV file instance */
		fileData = CSVFileUtils.getInstance().readAllCommaSeparatedValues(filePath);
	}

	@SuppressWarnings({ "resource", "unused" })
	@Then("Validate attributes in PM DB")
	public void Validate_the_MF_attributes_in_PM_DB() throws IOException, SQLException {

		/* Starting DB connection */
		
		//String completeSqlQuery=null;

		/* Setting up SQL Query */
		//String sqlQuery = "SELECT * FROM STRATEGY WHERE client_id = 1 AND created_on < '"
		//		+ createdTimeStamp + "'";

		//String sqlQuery = "SELECT * FROM Mutual_funds ";
		
		/* For getting number of lines in CSV File */
		BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
		String input;
		count = 1;
		int size = 0;

		/* Reading header outside loop, as it is not required while fetching data */
		input = bufferedReader.readLine();

		/* For reporting purpose - Table about status and client id information */
		/*Reporter.addStepLog("<table border=1px solid>\r\n" 
				+ "  <tr>\r\n"
				+ "  <td><b>Status</b></td>\r\n" 
				+ "  <td>446</td><td>Active</td>\r\n"
				+ "  </tr>\r\n" 
			//	+ "  <tr>\r\n<td>2</td><td>Pending</td>\r\n" + "  </tr>\r\n"
			//	+ "  <tr>\r\n" 
				+ "  <td><b>Client</b></td>\r\n" 
				+ "  <td>1</td><td>UBS</td>\r\n"
				+ "  </tr>\r\n" 
				+ "	 </table></br>");*/

	Reporter.addStepLog("<b>Taking particular cusip from actual file for validation</b>");
		
		
		
int count1=0;
		/* Validating data line by line */
		while ((input = bufferedReader.readLine()) != null) {
			/* Getting code and name (line by line) */
			String client,cusip, ProductName,BroadridgeADPNumber,shareClass,newInvestorIndicator,daysSettlementCycle,reinvestDividend;
			String TradingEligibilityFlag ;
			String share_class;

				client =input.substring(0,4).trim();
				cusip =input.substring(4,13).trim();
				ProductName=input.substring(13,16).trim();
				BroadridgeADPNumber=input.substring(16,23).trim();
				TradingEligibilityFlag =input.substring(23,24).trim();
				newInvestorIndicator =input.substring(24,25).trim();
				daysSettlementCycle =input.substring(25,26).trim();
				shareClass =input.substring(26,46).trim();
				reinvestDividend =input.substring(46,47).trim();
				
				if (reinvestDividend.equals("N")) {
					reinvestDividend="f";
				}else {
					reinvestDividend="t";
				}
				if (TradingEligibilityFlag.equals("0")) {TradingEligibilityFlag="423";}
				else if (TradingEligibilityFlag.equals("1")) {TradingEligibilityFlag="424";}
				else if (TradingEligibilityFlag.equals("2")) {TradingEligibilityFlag="425";}
				else if (TradingEligibilityFlag.equals("3")) {TradingEligibilityFlag="426";}
				else if (TradingEligibilityFlag.equals("4")) {TradingEligibilityFlag="427";}
				else if (TradingEligibilityFlag.equals("5")) {TradingEligibilityFlag="428";}
				else if (TradingEligibilityFlag.equals("6")) {TradingEligibilityFlag="429";}
				else if (TradingEligibilityFlag.equals("7")) {TradingEligibilityFlag="430";}
				else if (TradingEligibilityFlag.equals("8")) {TradingEligibilityFlag="431";}
				else if (TradingEligibilityFlag.equals("9")) {TradingEligibilityFlag="432";}
				
				count1++;
				pmdb.DBConnectionStart();
			/* adding strategy_code in search query */
		String	 completeSqlQuery = "select mf.mf_id,mf.client_id,mf.cusip,p.program_name,mf.broadridge_adp_id,pe.trading_flag_indicator,\r\n" + 
					"pe.new_invest_indicator,mf.days_in_settlement_cycle ,mf.share_class_description,mf.dividend_reinvest_cash,\r\n" + 
					"mf.created_on,mf.last_update_on,mf.created_by,mf.last_update_by\r\n" + 
					"from mutual_funds mf, program p, program_eligibility pe\r\n" + 
					"where mf.cusip='"+cusip+ "'and p.program_name='"+ProductName+ "'and p.program_id=pe.program_id\r\n" + 
					"and mf.mf_id=pe.reference_id\r\n" + 
					"and pe.reference_type='MF'";

			/* Result set for search query with code */
			ResultSet allResult = DBManager.executeSelectQuery(completeSqlQuery);
			while (allResult.next()) {
			String cusipDB	=allResult.getString("cusip");
			String	program_nameDB=allResult.getString("program_name");
			String	broadridge_adp_idDB=allResult.getString("broadridge_adp_id");
			String	trading_flag_indicatorDB=allResult.getString("trading_flag_indicator");
			String	new_invest_indicatorDB=allResult.getString("new_invest_indicator");
			String	days_in_settlement_cycleDB=allResult.getString("days_in_settlement_cycle");
			String share_class_descriptionDB=allResult.getString("share_class_description");
			String	dividend_reinvest_cashDB=allResult.getString("dividend_reinvest_cash");
			
			if (new_invest_indicatorDB==null)new_invest_indicatorDB="";
			if (share_class_descriptionDB==null)share_class_descriptionDB="";
			Reporter.addStepLog("Record from File : "+client+"|"+cusip+"|"+ProductName+"|"+BroadridgeADPNumber+"|"+
			TradingEligibilityFlag+"|"+newInvestorIndicator+"|"+daysSettlementCycle+"|"+shareClass+"|"+reinvestDividend )	;
			Reporter.addStepLog("Record from DB : "+client+"|"+cusipDB+"|"+program_nameDB+"|"+broadridge_adp_idDB+"|"+
					trading_flag_indicatorDB+"|"+new_invest_indicatorDB+"|"+days_in_settlement_cycleDB+"|"+share_class_descriptionDB+"|"+dividend_reinvest_cashDB )	;
						
	    	
			
			if ((client.equals("0003")) && (cusip.equals(cusipDB)) &&
						(ProductName.equals(program_nameDB))
						&& (BroadridgeADPNumber.equals(broadridge_adp_idDB))
						&& (TradingEligibilityFlag.equals(trading_flag_indicatorDB))
						&& (newInvestorIndicator.equals(new_invest_indicatorDB))
						&& (daysSettlementCycle.equals(days_in_settlement_cycleDB))
						&& (shareClass.equals(share_class_descriptionDB))
						&& (reinvestDividend.equals(dividend_reinvest_cashDB))) {
				
					
					Reporter.addStepLog("Record "+count1+" from file with cusip: "+cusip+" is matching with DB attributes");
				} else {
					Reporter.addStepLog("Record "+count1+" from file with cusip: "+cusip+" is not matching with DB attributes");
				}
			Reporter.addStepLog("----------------------------------------------");
			Assert.assertEquals(TradingEligibilityFlag, trading_flag_indicatorDB);
			Assert.assertEquals(newInvestorIndicator, new_invest_indicatorDB);
			Assert.assertEquals(daysSettlementCycle, days_in_settlement_cycleDB);
			Assert.assertEquals(shareClass, share_class_descriptionDB);
			Assert.assertEquals(reinvestDividend, dividend_reinvest_cashDB);
			}
			
			

			/* NEXT LINE - for CSV file */
			count++;
		}
	

		/*
		 * ResultSet for count in DataBase, size->number of data fetched from data base
		 */
		

		/*
		 * logging in report and validating number of strategies in file with database
		 */
		Reporter.addStepLog("<b>Number of rows in txt for Validation: </b>" + (count - 1));
		//Reporter.addStepLog("<b>Number of rows in DataBase: </b>" + size);
		//Assert.assertEquals(size, (count - 1));

		/* Closing DB connection */
		pmdb.DBConnectionClose();
	}
	
	/********************************************************
	 * 						Data Load
	 ********************************************************/
	
	@Given("File (.+) is available and created on (.+)")
	public void file_is_available(String fileName, String createdOn) {
	    filePath = filePath + fileName;
	    createdTimeStamp = createdOn;
	}

	@SuppressWarnings("resource")
	@Then("Validating the data from input file with database for (.+) entity")
	public void validating_the_data_in_file_with_database(String entity) throws IOException, SQLException {
		
		  File file = new File(filePath);
		  BufferedReader br = new BufferedReader(new FileReader(file)); 
		  
			
		  int rowIndex = 0;
//				  exlObj.getRowIndexByCellValue(sheet, 0, option);
		  
		  String line; 
		  count =0;
		  int notMatched=0;
		  
		  pmdb.DBConnectionStart();
		  
		  /*
			 * For reporting purpose - Table for data validation b/w Data in file and
			 * Database
			 */
		  if(entity.equalsIgnoreCase("PROGRAM")) {
			Reporter.addStepLog("<table border=1px solid><tr>\r\n" 
					+ "    <th>CODE</th>\r\n" 
					+ "    <th>NAME</th>\r\n"
					+ "    <th>Description</th>\r\n"  
					+ "    <th>MATCHED</th>\r\n"
					+ "    </tr>");
		  } else if(entity.equalsIgnoreCase("STYLE")) {
			  Reporter.addStepLog("<table border=1px solid><tr>\r\n" 
					  	+ "    <th>Market Cap</th>\r\n" 
						+ "    <th>PIV Style</th>\r\n"
						+ "    <th>Geo Ind</th>\r\n"  
						+ "    <th>Style Code</th>\r\n"
						+ "    <th>Style Name</th>\r\n"
						+ "    <th>Style Cat.</th>\r\n"
						+ "    <th>Risk Cat</th>\r\n"
						+ "    <th>Comp. Uni.</th>\r\n"
						+ "    <th>Found in (table name)</th>\r\n"
						+ "    <th>Exception Message</th>\r\n"
						+ "    <th>STATUS</th>\r\n"
						+ "    </tr>");
		  }
		  
		  while ((line = br.readLine()) != null) {
			  /*
			   * For program entity (According to the mapping rules)
			   * */
			 // System.out.println("Line: "+line);
			  if(entity.equalsIgnoreCase("PROGRAM")) {
				  String programCode = line.substring(0, 11).trim();
				  String programName = line.substring(11, 14).trim();
				  String programDescription = line.substring(14, 256).trim();
				  
				  String sqlQuery = "SELECT * FROM program WHERE created_by = 'GLUE_BATCH' AND program_code "
				  		+ "= '"+programCode+"'";
				  
				  ResultSet rs = DBManager.executeSelectQuery(sqlQuery);
				  
				  while(rs.next()) {
				  String codeDB = rs.getString("program_code"); 
				  String nameDB = rs.getString("program_name"); 
				  String descriptionDB = rs.getString("program_description"); 
				  
				  /* logging into report(data table) */
					Reporter.addStepLog("<td>" + programCode + "</td>\r\n" 
					+ "    <td>" + programName 
					+ "	   </td>\r\n" 
					+ "    <td>" + programDescription 
					+ "    </td>\r\n");
					
					/* If name, code and description is matched with DB, then marking it as "MATCHED" */
					if (programCode.equals(codeDB) && programName.equals(nameDB) && programDescription.equals(descriptionDB)) {
						Reporter.addStepLog("<td style = 'color:green'>MATCHED</td>\r\n" + "  </tr>");
					} else {
						Reporter.addStepLog("<td style = 'color:red'>NOT MATCHED</td>\r\n" + "  </tr>");
						notMatched++;
					}
				  }
			  } else if(entity.equalsIgnoreCase("STYLE")) {
				  String styleCodeDB = "",styleNameDB="",mktCapDB="",pivDB="",geoIndDB="",styleCatDB="",riskCatDB ="", compUniDB ="";
				  Boolean flag = false;
				  String excpMessageDB="";
				  String unknown = ConvertSpaceOrNullToString(line.substring(0,11).trim());
				  String mktCap = ConvertSpaceOrNullToString(line.substring(11,19).trim());
				  String pivStyle = ConvertSpaceOrNullToString(line.substring(19,20).trim());
				  String geoInd = ConvertSpaceOrNullToString(line.substring(20,21).trim());
				  String styleCode = ConvertSpaceOrNullToString(line.substring(21,32).trim());
				  String styleName = ConvertSpaceOrNullToString(line.substring(32,132).trim());
				  String styleCat = ConvertSpaceOrNullToString(line.substring(132,137).trim());
				  String riskCat = ConvertSpaceOrNullToString(line.substring(137,143).trim());
				  String compUni = ConvertSpaceOrNullToString(line.substring(143,152).trim());
				  
				  String expMktCap = ConvertSpaceOrNullToString(ExpectedValue(mktCap));
				  String expPivStyle = ConvertSpaceOrNullToString(ExpectedValue(pivStyle));
				  String expGeoInd = ConvertSpaceOrNullToString(ExpectedValue(geoInd));
				  String expStyleCat = ConvertSpaceOrNullToString(ExpectedValue(styleCat));
				  String expRiskCat = ConvertSpaceOrNullToString(ExpectedValue(riskCat+" - risk"));
				  String expCompUni = ConvertSpaceOrNullToString(ExpectedValue(compUni));
				 
				  
				  String sqlQuery = "SELECT * FROM style WHERE created_by = 'GLUE_BATCH' AND style_code "
					  		+ "= '"+styleCode+"' AND created_on > '" + createdTimeStamp + "'";
				  ResultSet rs = DBManager.executeSelectQuery(sqlQuery);
				  
				  //if found in style table
				  while(rs.next()) {
					  styleCodeDB = ConvertSpaceOrNullToString(rs.getString("style_code"));
					  styleNameDB = ConvertSpaceOrNullToString(rs.getString("style_name"));
					  mktCapDB = ConvertSpaceOrNullToString(rs.getString("market_cap"));
					  pivDB = ConvertSpaceOrNullToString(rs.getString("piv_style"));
					  geoIndDB = ConvertSpaceOrNullToString(rs.getString("geographic_indicator"));
					  styleCatDB = ConvertSpaceOrNullToString(rs.getString("style_category"));
					  riskCatDB = ConvertSpaceOrNullToString(rs.getString("risk_category"));
					  compUniDB =ConvertSpaceOrNullToString(rs.getString("comparative_universe"));

					  // flag = true;
				  }
				  
//				  while(line!=null) {
					 
					  Reporter.addStepLog("<tr><td>" + mktCap + "</td>\r\n" 
								+ "<td>" + pivStyle + "</td>\r\n" 
								+ "<td>" + geoInd + "</td>\r\n"
					  			+ "<td>" + styleCode + "</td>\r\n"
					  			+ "<td>" + styleName + "</td>\r\n"
					  			+ "<td>" + styleCat + "</td>\r\n"
					  			+ "<td>" + riskCat + "</td>\r\n"
					  			+ "<td>" + compUni + "</td>\r\n");

					  if(styleCodeDB.equals(styleCode))  {
			  			System.out.println("Code File: "+styleCode+" | Name File: "+styleName);
			  			System.out.println("Code DB: "+styleCodeDB+" | Name DB: "+styleNameDB);
			  			if(styleName.equals(styleNameDB) && expPivStyle.equals(pivDB) && expGeoInd.equals(geoIndDB) &&
				  				expCompUni.equals(compUniDB) && expStyleCat.equals(styleCatDB) && expRiskCat.equals(riskCatDB) && expMktCap.equals(mktCapDB)) {
			  				flag = true;
				  			Reporter.addStepLog("<td>Style Table</td>");
				  			Reporter.addStepLog("<td>-</td>");
				  			Reporter.addStepLog("<td style = 'color:green'>MATCHED</td></tr>");
			  				
			  			}else {
			  				flag = true;
			  				notMatched++;
			  				Reporter.addStepLog("<td style = 'color:red'>Style Table</td>");
				  			Reporter.addStepLog("<td style = 'color:red'>MISMATCHED</td>");
				  			Reporter.addStepLog("<td style = 'color:red'>MISMATCHED</td></tr>");
			  			}
			  			
			  			
			  		}else {
			  			String sqlQuery2 = "SELECT * FROM style_excp WHERE created_by = 'GLUE_BATCH' AND style_code "
						  		+ "= '"+styleCode+"' AND created_on > '" + createdTimeStamp + "'";
						  //Reporter.addStepLog(sqlQuery);
			  			ResultSet rs2 = DBManager.executeSelectQuery(sqlQuery2);
					  
					  //if not found in style table
			  			while(rs2.next()) {
						  styleCodeDB = ConvertSpaceOrNullToString(rs2.getString("style_code"));
						  styleNameDB = ConvertSpaceOrNullToString(rs2.getString("style_name"));
						  mktCapDB = ConvertSpaceOrNullToString(rs2.getString("market_cap"));
						  pivDB = ConvertSpaceOrNullToString(rs2.getString("piv_style"));
						  geoIndDB = ConvertSpaceOrNullToString(rs2.getString("geographic_indicator"));
						  styleCatDB = ConvertSpaceOrNullToString(rs2.getString("style_category"));
						  riskCatDB = ConvertSpaceOrNullToString(rs2.getString("risk_category"));
						  compUniDB = ConvertSpaceOrNullToString(rs2.getString("comparative_universe"));
						  excpMessageDB = ConvertSpaceOrNullToString(rs2.getString("exception_desc"));
						  
					  }
			  			if(styleCodeDB.equals(styleCode)) {
			  				if(styleName.equals(styleNameDB) && expPivStyle.equals(pivDB) && expGeoInd.equals(geoIndDB) &&
				  				expCompUni.equals(compUniDB) && expStyleCat.equals(styleCatDB) && expRiskCat.equals(riskCatDB) && expMktCap.equals(mktCapDB)) {
				  				flag = true;
					  			Reporter.addStepLog("<td>Style Exception Table</td>");
					  			Reporter.addStepLog("<td>"+excpMessageDB+"</td>");
					  			Reporter.addStepLog("<td style = 'color:green'>MATCHED</td></tr>");
				  				
				  			}else {
				  				flag = true;
				  				notMatched++;
				  				Reporter.addStepLog("<td style = 'color:red'>Style Exception Table</td>");
					  			Reporter.addStepLog("<td style = 'color:red'>MISMATCHED</td>");
					  			Reporter.addStepLog("<td style = 'color:red'>MISMATCHED</td></tr>");
				  			}
			  				
			  			}
			  		}
			  		if(flag.equals(false)) {
			  			notMatched++;
			  			Reporter.addStepLog("<td><b style = 'color:red'>NOT FOUND</b></td>");
			  			Reporter.addStepLog("<td style = 'color:red'>MISMATCHED</td>");
			  			Reporter.addStepLog("<td style = 'color:red'>MISMATCHED</td></tr>");

			  			flag = true;
			  		}
			  }
			  /* Counting from file */
			  count++;
			}
		  Reporter.addStepLog("</table></br>");
		  Reporter.addStepLog("Total Number of data(in File): <b>"+count+"</b>");
		  Reporter.addStepLog("Number of data matched: <b style = 'color:green'>"+(count-notMatched)+"</b>");
		  Reporter.addStepLog("Number of data mismatched/Not Found: <b style = 'color:red'>"+notMatched+"</b>");
		  
		  /* Closing DB connection */
		  pmdb.DBConnectionClose();
		}
	
	/********************************************************
	 * 						UPM - 2938
	 ********************************************************/
	ResultSet rs = null;
	
	@Given("User is connected to Product Master Database$")
	public void user_is_connected_to_Product_Master_Database() {
	    pmdb.DBConnectionStart();
	    Reporter.addStepLog("<b>Connection Established!!</b>");
	}

	@When("User runs select query to fetch codes for (.+)$")
	public void user_runs_select_query_to_fetch_codes_for_STYLE(String entity) {
		String sqlQuery = "select * from list_values where list_type = '"+entity+"'";
		rs = DBManager.executeSelectQuery(sqlQuery);
		
		Reporter.addStepLog("<b>SQL Query:</b> "+sqlQuery);
	}

	@Then("User should be able to fetch code '(.+)' for (.+)$")
	public void user_should_be_able_to_fetch_E_for_Equity(String expCode, String expListValue) throws SQLException {
		Boolean flag = false;
		while(rs.next()) {
			
			String actCode = rs.getString("list_code");
			String actListValue = rs.getString("list_value");
			System.out.println(actCode +" 0000000 "+actListValue);
			if(actCode.equalsIgnoreCase(expCode) && actListValue.equalsIgnoreCase(expListValue)) {
				flag = true;
				Reporter.addStepLog("_________________________________________________________________");
				Reporter.addStepLog("<b>List Value: </b>"+expListValue);
				Reporter.addStepLog("<b>Actual Code: </b>"+actCode + "<b> | Expected Code:</b> "+expCode);
				Reporter.addStepLog("_________________________________________________________________");
			}
		}
		System.out.println("FLAG: "+flag);
		Assert.assertTrue(flag, "Code '"+expCode+"' Not found in DB");
		
	    pmdb.DBConnectionClose();
	}
	
	@Given("^pipe deliminated file, checking pmp or not$")
	public void checking_pmp_non_pmp() throws IOException, SQLException {
		String filePath = "D:\\Users\\PatelNim\\Documents\\strategynmgr";
		
		 File file = new File(filePath);
		  BufferedReader br = new BufferedReader(new FileReader(file)); 
		  
			
		  int rowIndex = 0;
		  
		  String line; 
		 int  pmp =0;
		  int nonPMP=0;
		  
		  pmdb.DBConnectionStart();
		  
		
		  
		  while ((line = br.readLine()) != null) {
			  //String [] codeArr = line.split("|");
			  String foaCode = line.substring(0, 4);
			  
			  String query = "select program_name from program where\r\n" + 
				  		"program_id = (select program_id from program_strategy where\r\n" + 
				  		"  strategy_id = (select strategy_id from strategy\r\n" + 
				  		"where strategy_code = '"+foaCode+"'))";
			  ResultSet rs = DBManager.executeSelectQuery(query);
			  
			 // System.out.println(query);
			  while(rs.next()) {
			  String expFlag = rs.getString("program_name");
			  if(expFlag.equalsIgnoreCase("ma2")) {
				 // System.out.println("PMP Strategy");
				  pmp++;
			  }
			  else {
				  System.out.println("NON PMP");
				  Reporter.addStepLog(foaCode+" - is NON PMP");
				  nonPMP++;
			  }
			 
			  }
	}
		  Reporter.addStepLog("<b>PMP Strategies: "+pmp);
		  Reporter.addStepLog("<b>NON PMP Strategies: "+nonPMP);
		  pmdb.DBConnectionClose();}
	
		 

	
	
	
	
	/********************************************************
	 * 						FUNCTIONS
	 ********************************************************/

	
	public String ExpectedValue(String element) throws IOException {
		String excelFilePath = "./src/test/resources/ad/productmaster/api/excel/ListValuePair.xlsx";
		String expValue;
		  ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD,excelFilePath);
		  XSSFSheet sheet = exlObj.getSheet("listvalue");
		  int rowIndex = exlObj.getRowIndexByCellValue(sheet, 1, element);
		  if(rowIndex>=0) {
			  expValue = exlObj.getCellData(sheet, rowIndex, 2)+"";
		  }
		  else {
			  expValue = element;
		  }
		  
		  exlObj.closeWorkBook();
		  
		  return expValue;
	}
	
	@SuppressWarnings("unused")
	public String ConvertSpaceOrNullToString(String string) {
		if(string!=null) {
			if(string.length()>=2) {
				if(string.contains("  ")) {
					string = "";
				}
			}else if(string.length()==1){
				if(string.equals(" ")) {
					string = "";
				}
			} else if(string.length()==0) {
				string = "";
			} 
		} else {
			string ="";
		}
		return string;
	}
}