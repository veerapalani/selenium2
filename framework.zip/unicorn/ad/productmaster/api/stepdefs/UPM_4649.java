package qa.unicorn.ad.productmaster.api.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.hp.lft.sdk.internal.common.MessageFieldNames.Report;
import com.mysql.cj.jdbc.result.ResultSetFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import fj.data.Iteratee.Input;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.ExcelFilloUtils;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.Reporter;

public class UPM_4649 {
	File file;
	String filePath = "./src/test/resources/ad/productmaster/api/DataLoadFiles/";
	List<String[]> fileData = new ArrayList<String[]>();
	Map<String, String> scrData = new HashMap<String, String>();
	Map<String, List<String>> targetData = new HashMap<String, List<String>>();
	int countInDB = 0;
	int countInFile = 0;

	@Given("^User has file (.+)$")
	public void user_has_file(String filename) throws Throwable {
		filePath = filePath + filename;

		file = new File(filePath);

		if (!file.exists()) {
			Reporter.addStepLog("FILE NOT FOUND at: " + filePath);
			assertTrue(false, "FILE NOT FOUND!!");
		} else
			Reporter.addStepLog("<b>File found at </b>" + filePath);

	}

	@And("^output file is in csv format$")
	public void output_file_is_in_csv_format() throws Throwable {
		BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
		String input = null;
		while ((input = bufferedReader.readLine()) != null) {
			String[] checkingCSV = input.split(",");
			assertTrue((checkingCSV.length > 1), "Invalid CSV FILE");
		}

	}

	@When("^User opens the output file$")
	public void user_opens_the_file() throws Throwable {
		fileData = CSVFileUtils.getInstance().readAllCommaSeparatedValues(filePath);

		if (fileData.isEmpty()) {
			assertTrue(false, "No Data found in file");
		} else
			Reporter.addStepLog("<b>Data found in file.</b>");
	}

	@Then("^Validate the set of comp uni description and code$")
	public void file_contains_all_the_comperative_universe_code_which_are_present_in_product_masters_database()
			throws Throwable {
		/* For getting number of lines in CSV File */
		BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
		String input;
		// int count = 1;
		int size = 0;

		/* Reading header outside loop, as it is not required while fetching data */
		input = bufferedReader.readLine();
		String sqlQuery = "select list_id as id, list_code as code, list_value as description from list_values where list_type = 'COMP UNIVERSE'";

		ProductMasterDBManager pmdb = new ProductMasterDBManager();

		pmdb.DBConnectionStart();

		ResultSet rs = DBManager.executeSelectQuery(sqlQuery);

		while (rs.next()) {
			countInDB++;
		}

		Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>CODE in DB</th>\r\n"
				+ "    <th>Description in DB</th>\r\n" + "    <th>CODE in file</th>\r\n"
				+ "    <th>Description in file</th>\r\n" + "    <th>MATCHED</th>\r\n" + "    </tr>");

		while ((input = bufferedReader.readLine()) != null) {
			String actCode = CSVFileUtils.getInstance().getValue(fileData, (countInFile + 1), 0);
			String actDescription = CSVFileUtils.getInstance().getValue(fileData, (countInFile + 1), 1);
			String sqlQuery2 = "select list_id as id, list_code as code, list_value as description "
					+ "from list_values where list_type = 'COMP UNIVERSE' and list_code = '" + actCode + "'";

			rs = DBManager.executeSelectQuery(sqlQuery2);

			while (rs.next()) {
				String expCode = rs.getString(2);
				String expDescription = rs.getString(3);

				/* logging into report(data table) */
				Reporter.addStepLog("<td>" + expCode + "</td>\r\n" + "    <td>" + expDescription + "	   </td>\r\n"
						+ "    <td>" + actCode + "    </td>\r\n" + "    <td>" + actDescription + "	   </td>\r\n");

				/* If name, status and client is as expected then marking it as "MATCHED" */
				if (actCode.equals(expCode) && actDescription.equals(expDescription)) {
					Reporter.addStepLog("<td style = 'color:green'>MATCHED</td>\r\n" + "  </tr>");
				} else {
					Reporter.addStepLog("<td style = 'color:red'>NOT MATCHED</td>\r\n" + "  </tr>");
				}
			}
			countInFile++;
		}

		Reporter.addStepLog("</table></br>");
		pmdb.DBConnectionClose();

	}

	@Then("^number of records in Product Master DB is equal to number of records in output file$")
	public void count_of_comparative_universe_code_in_file_is_same_sa_count_of_comparative_universe_code_in_db()
			throws Throwable {
		Reporter.addStepLog("<b>Number of data in DB:</b> " + countInDB);
		Reporter.addStepLog("<b>Number of data in File:</b> " + countInFile);
		Assert.assertEquals(countInDB, countInFile);
	}

	@Then("^user is able to see below attribites as headers$")
	public void user_is_able_to_see_below_attribites_as_headers(List<String> expColumn) throws Throwable {
		for (int i = 0; i < expColumn.size(); i++) {
			String actColumn1 = CSVFileUtils.getInstance().getValue(fileData, 0, i);

			Reporter.addStepLog("<b>Actual Column: </b>" + actColumn1);
			Reporter.addStepLog("<b>Expected Column: </b>" + expColumn.get(i));
			Reporter.addStepLog("____________________________________________");
			Assert.assertEquals(expColumn.get(i), actColumn1);
		}
	}

	/*
	 * UPM-18496 : Added by Nimit on 12/08/2021
	 * 
	 */
	@Then("^Validate the set of foa group code and foa code from file with DB schema \"([^\"]*)\"$")
	public void validate_the_set_of_foa_group_code_and_foa_code(String schema) throws SQLException {
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, filePath);
		XSSFSheet sheet = exlObj.getSheet("APL FIle Details_Original");

		List<Object> foaGroupCodeExl = new ArrayList<Object>();
		List<Object> foaCodeExl = new ArrayList<Object>();

		foaGroupCodeExl = exlObj.getColumnData(sheet, 0, "Group Codes");
		foaCodeExl = exlObj.getColumnData(sheet, 0, "FOA Codes");

		ProductMasterDBManager pmdb = new ProductMasterDBManager();
		pmdb.DBConnectionStart();
		ResultSet rs;

		Reporter.addStepLog("<table border=1px solid><tr>\r\n" + "    <th>FOA Group CODE in DB</th>\r\n"
				+ "    <th>FOA CODE in DB</th>\r\n" + "    <th>FOA Group CODE in File</th>\r\n"
				+ "    <th>FOA CODE in DB</th>\r\n" + "    <th>Status</th>\r\n" + "    </tr>");
		for (int i = 0; i < foaGroupCodeExl.size(); i++) {

			String foaCodeExlString = foaCodeExl.get(i).toString().trim();
			String foaGroupCodeExlString = foaGroupCodeExl.get(i).toString().trim();
			
			String sqlQuery = "select * from " + schema + ".stg_foa_group_codes where foa_group_code = '"
					+ foaGroupCodeExlString + "'  and foa_code = '" + foaCodeExlString + "'";
			rs = DBManager.executeSelectQuery(sqlQuery);

			if (rs.next() == false) {
				System.out.println("ResultSet is empty.");

				/* logging into report(data table) */
				Reporter.addStepLog("<td>" + "N/A" + "</td>\r\n" + "    <td>" + "N/A" + "	   </td>\r\n" + "    <td>"
						+ foaGroupCodeExlString + "    </td>\r\n" + "    <td>" + foaCodeExlString + "	   </td>\r\n");

				Reporter.addStepLog("<td style = 'color:red'>NOT MATCHED</td>\r\n" + "  </tr>");
				System.out.println(sqlQuery);

			} else {

				do {
					String foaGroupCodeDB = rs.getString("foa_group_code");
					String foaCodeDB = rs.getString("foa_code");

					/* logging into report(data table) */
					Reporter.addStepLog("<td>" + foaGroupCodeDB + "</td>\r\n" + "    <td>" + foaCodeDB
							+ "	   </td>\r\n" + "    <td>" + foaGroupCodeExlString + "    </td>\r\n" + "    <td>"
							+ foaCodeExlString + "	   </td>\r\n");

					/* If name, status and client is as expected then marking it as "MATCHED" */
					if (foaGroupCodeExlString.equals(foaGroupCodeDB) && foaCodeExlString.equals(foaCodeDB)) {
						Reporter.addStepLog("<td style = 'color:green'>MATCHED</td>\r\n" + "  </tr>");
					} else {
						Reporter.addStepLog("<td style = 'color:red'>NOT MATCHED</td>\r\n" + "  </tr>");
					}

				} while (rs.next());
			}

		}
		Reporter.addStepLog("</table></br>");
	}

}
