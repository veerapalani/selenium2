package qa.unicorn.ad.productmaster.api.stepdefs;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;

import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

public class BaseAPIStyleClassification   {
	EISLBaseAPIGeneric ebg = new EISLBaseAPIGeneric();
			
	String requestStr = ebg.requestJson;
	JSONObject requestJson = null;
	JSONParser parser = new JSONParser();
	
	@And("^validate count of api resonse and db row should match$")
	public void validate_count_of_api_resonse_and_db_row_should_match() throws SQLException {

	String	sqlQuery ="select count(*) from list_values where list_type='COMP UNIVERSE';";
		int expectedCount=ebg.compareCounts(sqlQuery, "");	
		int actualApiCount =ebg.numberOfParentObject;

		Reporter.addStepLog("Count of API responses :"+actualApiCount);
		Reporter.addStepLog("Count of DB rows :"+expectedCount);
        Assert.assertEquals("Count is Matching in API and DB",expectedCount, actualApiCount);
	}
 
	
	
}
		
	
	



