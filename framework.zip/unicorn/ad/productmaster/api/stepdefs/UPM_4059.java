package qa.unicorn.ad.productmaster.api.stepdefs;

import static org.junit.Assert.assertArrayEquals;
import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.ResultSet;

import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.codoid.products.fillo.Recordset;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.ExcelFilloUtils;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;

public class UPM_4059 {
	File file;
	String filePath = "./src/test/resources/ad/productmaster/api/DataLoadFiles/";
	String exlFIlePath = "c:/automation/Reports.xlsx";
	ExcelUtils exlObj; // = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
	XSSFSheet sheet;// = exlObj.getSheet(sheetName);

	@Given("^file (.+) is available$")
    public void file_is_available(String filename) throws Throwable {
		filePath = filePath+filename;
		
		file = new File(filePath);

		if (file.exists() == true) {
			Reporter.addStepLog("<b>FILE found at location -</b> " + filePath);
		} else {
			Reporter.addStepLog("FILE not found");
			assertTrue(false,"File not Found!");
		}
    }

    @When("^User convert it in excel file$")
    public void user_opens_the_file() throws Throwable {
    	 BufferedReader br = new BufferedReader(new FileReader(file));
    	 String line=null;
    	 
    	 String jobType, clientNum, processStatus, foaCode, spaces, foaCode2, staticString, managerName, address1, address2, address3 = null;
    		String address4, cityState, zipCode, spaces2 = null;
    	 int rowIndex = 1;
    	 while((line = br.readLine()) != null) {
    		jobType = line.substring(0, 1).trim();
    		clientNum = line.substring(1, 4).trim();
    		processStatus = line.substring(4, 5).trim();
    		foaCode = line.substring(5, 9).trim();
    		spaces = line.substring(9, 24);
    		foaCode2 = line.substring(24, 28).trim();
    		staticString = line.substring(28, 43).trim();
    		managerName = line.substring(43, 63).trim();
    		address1 = line.substring(63, 93).trim();
    		address2 = line.substring(93, 123).trim();
    		address3 = line.substring(123, 153).trim();
    		address4 = line.substring(153, 183).trim();
    		cityState = line.substring(183, 213).trim();
    		zipCode = line.substring(213, 218).trim();
    		spaces2 = line.substring(218, 250);
    		
    		exlObj  = new ExcelUtils(ExcelOperation.LOAD, exlFIlePath);
    		sheet = exlObj.getSheet("UPM_4059"); 
    		
    		exlObj.setCellData(sheet, rowIndex, 0, jobType);
    		exlObj.setCellData(sheet, rowIndex, 1, clientNum);
    		exlObj.setCellData(sheet, rowIndex, 2, processStatus);
    		exlObj.setCellData(sheet, rowIndex, 3, foaCode);
    		exlObj.setCellData(sheet, rowIndex, 4, spaces);
    		exlObj.setCellData(sheet, rowIndex, 5, foaCode2);
    		exlObj.setCellData(sheet, rowIndex, 6, staticString);
    		exlObj.setCellData(sheet, rowIndex, 7, managerName);
    		exlObj.setCellData(sheet, rowIndex, 8, address1);
    		exlObj.setCellData(sheet, rowIndex, 9, address2);
    		exlObj.setCellData(sheet, rowIndex, 10, address3);
    		exlObj.setCellData(sheet, rowIndex, 11, address4);
    		exlObj.setCellData(sheet, rowIndex, 12, cityState);
    		exlObj.setCellData(sheet, rowIndex, 13, zipCode);
    		exlObj.setCellData(sheet, rowIndex, 14, spaces2);
   
    		rowIndex++;
    	 }
    	 exlObj.closeWorkBook();
    }

    @Then("^User is able to see expected data from PMDB in file$")
    public void user_is_able_to_see_expected_data_from_pmdb_in_file() throws Throwable {
       ProductMasterDBManager pmdb = new ProductMasterDBManager();
       DataConversions dc = new DataConversions(); 
       pmdb.DBConnectionStart();
       ExcelFilloUtils exlFillo = new ExcelFilloUtils(exlFIlePath);
       int rowIndex =1, notMatched = 0;
       
       String sql = "select * " + 
       		"from contact c " + 
       		"join " + 
       		"( " + 
       		"select * " + 
       		"from contact_assoc ca " + 
       		"join " + 
       		"( " + 
       		"select s.strategy_id, s.strategy_code " + 
       		"from strategy s " + 
       		"join program_strategy ps " + 
       		"on s.strategy_id = ps.strategy_id " + 
       		"join program p " + 
       		"on ps.program_id = p.program_id " + 
       		"and p.program_description in ('ACCESS', 'Strategic Wealth Portfolio', 'UBS Advisor Allocation Program', 'MACWrap', 'UBS-IC ALL-INCLUSIVE FEE') " + 
       		") a " + 
       		"on ca.reference_id = a.strategy_id " + 
       		"and ca.reference_type = 'STRATEGY' " + 
       		") a " + 
       		"on c.contact_id = a.contact_id ";
       Reporter.addStepLog(sql);
      ResultSet rs = DBManager.executeSelectQuery(sql);
      
      while(rs.next()) {
    	  System.out.println("working on "+rowIndex);
    	  String expJobType = dc.ExpectedValue(rs.getString("type"));
  		String expClientNum = "221";
  		String expProcessStatus = "2";
  		String expFoaCode1 = rs.getString("strategy_code");
  		String expFoaCode2 = rs.getString("strategy_code");
  		String expStaticString = "999999999999999";
  		String expManagerName = rs.getString("contact_first_name");
  		String expAddress1 = rs.getString("contact_address");
  		String expAddress2 = rs.getString("contact_address_2");
  		String expAddress3 = rs.getString("contact_address_3");
  		String expAddress4 = rs.getString("contact_address_4");
  		String expCity = rs.getString("contact_city");
  		String expState = dc.ExpectedValue(rs.getString("contact_state"));
  		String expCityState = expCity+","+expState;
  		String expZipCode = rs.getString("contact_postal_code");
  		 
  		System.out.println(expFoaCode1);
  		Recordset rSet = exlFillo.executeQuery("select * from UPM_4059 where foaCode = '"+expFoaCode1+"'");
  		while(rSet.next()) {
  			if(expCityState.equals("null,null")) {expCityState="";}
  			
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expJobType), rSet.getField("jobType"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expClientNum), rSet.getField("clientNum"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expProcessStatus), rSet.getField("processStatus"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expFoaCode1), rSet.getField("foaCode"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expFoaCode2), rSet.getField("foaCode2"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expStaticString), rSet.getField("staticString"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expManagerName), rSet.getField("managerName"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expAddress1), rSet.getField("address1"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expAddress2), rSet.getField("address2"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expAddress3), rSet.getField("address3"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expAddress4), rSet.getField("address4"));
//  			
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expCityState), rSet.getField("cityState"));
//  			Assert.assertEquals(dc.ConvertSpaceOrNullToString(expZipCode), rSet.getField("zipCode"));
  			
  			
  			if(((dc.ConvertSpaceOrNullToString(expJobType)).equals(rSet.getField("jobType"))) &&
  			((dc.ConvertSpaceOrNullToString(expClientNum)).equals(rSet.getField("clientNum"))) &&
  			((dc.ConvertSpaceOrNullToString(expProcessStatus)).equals(rSet.getField("processStatus"))) &&
  			((dc.ConvertSpaceOrNullToString(expFoaCode1)).equals(rSet.getField("foaCode"))) &&
  			((dc.ConvertSpaceOrNullToString(expFoaCode2)).equals(rSet.getField("foaCode2"))) &&
  			((dc.ConvertSpaceOrNullToString(expStaticString)).equals(rSet.getField("staticString"))) &&
  			((dc.ConvertSpaceOrNullToString(expManagerName)).equals(rSet.getField("managerName"))) &&
  			((dc.ConvertSpaceOrNullToString(expAddress1)).equals(rSet.getField("address1"))) &&
  			((dc.ConvertSpaceOrNullToString(expAddress2)).equals(rSet.getField("address2"))) &&
  			((dc.ConvertSpaceOrNullToString(expAddress3)).equals(rSet.getField("address3"))) &&
  			((dc.ConvertSpaceOrNullToString(expAddress4)).equals(rSet.getField("address4"))) &&
  			((dc.ConvertSpaceOrNullToString(expCityState)).equals(rSet.getField("cityState"))) &&
  			((dc.ConvertSpaceOrNullToString(expZipCode)).equals(rSet.getField("zipCode")))) {
  				exlFillo.executeUpdate("Update UPM_4059 Set `MATCHED?`='MATCHED' where foaCode='"+expFoaCode1+"'");
  			} 
  			
  			else {
  				notMatched++; 
  				exlFillo.executeUpdate("Update UPM_4059 Set `MATCHED?`='NOT MATCHED' where foaCode='"+expFoaCode1+"'");
  			}
  		
  		}
  		
  		rowIndex++;
      }
      Recordset r2 = exlFillo.executeQuery("select * from UPM_4059");
      
      Reporter.addStepLog("<b>Total Records in DB: </b>"+(rowIndex-1));
      Reporter.addStepLog("<b>Total Records in Extract File:</b> "+r2.getCount());
      Reporter.addStepLog("<b>Number of data matched: <b style = 'color:green'>"+((rowIndex-1)-notMatched)+"</b></b>");
	  Reporter.addStepLog("<b>Number of data mismatched/Not Found: <b style = 'color:red'>"+notMatched+"</b></b>");
	  Reporter.addStepLog("<a href=\"Reports.xlsx\"> "
				+ "Click Here to see detailed excel report</a> Sheet: UPM_4059");
      
       pmdb.DBConnectionClose();
    }
    
}
