package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.simple.JSONArray;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

public class BaseAPIGetFA {

	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	List<String> faCodes = new ArrayList<String>();
	List<String> allFaCodes = new ArrayList<String>();
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	ProductMasterGeneric pmg = new ProductMasterGeneric();
	SoftAssert sa = new SoftAssert();
	
	@When("^user selects \"([^\"]*)\" number of \"([^\"]*)\" FAs from PM DB(.*)$")
	public void user_selects_something_number_of_strategies_from_pm_db_according_to_repcodes_and_branch(int count,
			String type, String serviceName) throws Throwable {
		
		/*
		 * Nullifying so that list will be ready for new set of codes for next
		 * scenarios.
		 */
		faCodes.clear();
		
		pmdb.DBConnectionStart();
		
		/*
		 * Getting final SQL according to the repcodes, branch number and counts for PMP
		 * strategies. Only if entitlements contains "PRODM_PMPSTRATEGIES_SERVICE"
		 */
		if (BaseAPIGetStrategyDetails.entitlements.toString().contains("PRODM_PMPSTRATEGIES_SERVICE")) {
			String sqlQueryPMP = GetSQLWithBranchAndRepCodes(BaseAPIGetStrategyDetails.repCodes, BaseAPIGetStrategyDetails.branch, count, type);

			ebag.setCollapsibleHtml("SQL Query used for PMP - click here to view", sqlQueryPMP);

			ResultSet rs_pmp = DBManager.executeSelectQuery(sqlQueryPMP);

			while (rs_pmp.next()) {
				faCodes.add(rs_pmp.getString("fa_code"));
				allFaCodes.add(rs_pmp.getString("fa_code"));
			}
		}
		
		pmdb.DBConnectionClose();
		
		/* Printing in reports */
		Reporter.addStepLog("</br><b>" + type + " strategy codes are:</b>");

		for (String code : faCodes) {
			Reporter.addStepLog(code);
		}
	}
	
	
	@And("^user creates a request JSON file with \"([^\"]*)\" FA codes$")
	public void user_creates_a_request_json_file_with_something_strategy_codes(String type) throws Throwable {
		String value = "";

		/* For either Entitled or not entitled */
		if (!type.equalsIgnoreCase("entitled & not entitled")) {

			for (String code : faCodes) {

				value = value + "\"" + code + "\"";
			}
		}

		/* For mixed codes i.e. Entitled and Not Entitled. */
		else {
			for (String code : allFaCodes) {

				value = value + "\"" + code + "\"";
			}

		}

		/* formatting "S051""AD0L""IA41" -> ["S051","AD0L","IA41"]; */
		value = value.replace("\"\"", "\",\"");
		value = "[" + value + "];";

		ebag.user_creates_a_request_json_file_with_search_keys_and_values("code", value);

	}
	
	@And("^number of FAs in response is equal to number of codes passed in request$")
	public void number_of_strategies_in_response_is_equal_to_number_of_codes_passed_in_request() throws Throwable {

		String faCodesFromAPI = EISLBaseAPIGeneric.response.jsonPath().getString("code2");
		int countFromResponse = faCodesFromAPI.split(",").length;
		int countFromRequest = faCodes.size();

		Reporter.addStepLog("<b>Number of codes in request: </b>" + countFromRequest);
		Reporter.addStepLog("<b>Number of codes in response: </b>" + countFromResponse);
		
		Assert.assertEquals("Mismatched..!! Check codes in response and request.", countFromRequest, countFromResponse);

		/*
		 * Nullifying so that list will be ready for new set of codes for next
		 * scenarios.
		 */
		faCodes.clear();
		
	}
	
	@And("^user is able to see only entitled FAs in response$")
	public void user_is_able_to_see_only_entitled_codes_in_response() {
		int totalSize = allFaCodes.size();

		List<String> expectedCodes = new ArrayList<String>();

		/*
		 * First half will be entitled and second half will be not entitled, need to
		 * maintain this in FF | When user selects "3" number of "Entitled" strategies
		 * from PM DB | When user selects "3" number of "Not Entitled" strategies from PM
		 * DB
		 * 
		 */

		for (int n = 0; n < totalSize / 2; n++) {
			expectedCodes.add(allFaCodes.get(n));
		}

		String actCodes = EISLBaseAPIGeneric.response.body().jsonPath().getString("code");

		String[] actCodesArr = actCodes.split(",");

		for (int i = 0; i < actCodesArr.length; i++) {
			boolean flag = expectedCodes.contains(pmg.RemoveSquareBrackets(actCodesArr[i].trim()));
			sa.assertTrue(flag, "code: [" + pmg.RemoveSquareBrackets(actCodesArr[i].trim()) + "] NOT FOUND..!!");
		}
		
		Reporter.addStepLog("<b>Expected Codes: </b>" + expectedCodes.toString().replace("[", "").replace("]", ""));
		Reporter.addStepLog("<b>Actual Codes: </b>" + Arrays.toString(actCodesArr).replace("[", "").replace("]", ""));
		
		sa.assertEquals(actCodesArr.length, expectedCodes.size()," Expected and Actual Size differs.");
		
		sa.assertAll();

	}
	
	
	/**
	 * Function to return SQL according to provided RepCodes and Branch Numbers
	 * ORDER BY RANDOM() -> this will give different rows every time
	 */

	String GetSQLWithBranchAndRepCodes(JSONArray rr_code, JSONArray branch_number, int count, String type) {

		String sql = "SELECT distinct fa.fa_code, RANDOM() FROM financial_advisor fa, \r\n"
				+ "rr_mapping rm WHERE\r\n"
				+ " fa.fa_code = rm.fa_code AND ";

		String additionalQuery = "";

		if (rr_code.size() > 0) {
			additionalQuery = "rm.rr_code $type (" + pmg.RemoveSquareBrackets(rr_code.toString().replace("\"", "'"))
					+ ")";
		}

		if (branch_number.size() > 0) {
			if (additionalQuery.length() > 0) {

				/* Removing 5 from branch, in JWT = '5AB', in DB = 'AB' */
				additionalQuery = additionalQuery + " OR rm.branch_number $type ("
						+ pmg.RemoveSquareBrackets(branch_number.toString().replace("\"", "'").replace("'5", "'"))
						+ ")";
			} else {
				additionalQuery = "rm.branch_number $type ("
						+ pmg.RemoveSquareBrackets(branch_number.toString().replace("\"", "'").replace("'5", "'"))
						+ ")";
			}
		}

		/*
		 * hard-coded, when user is having all 3 entitlements but no repcodes and branch
		 * numbers
		 */
		if (rr_code.size() == 0 && branch_number.size() == 0) {
			additionalQuery = "rm.rr_code $type ('') OR rm.branch_number $type ('')";
		}

		/* Changing condition according to requirements */
		if (type.equalsIgnoreCase("entitled")) {
			additionalQuery = additionalQuery.replace("$type", "IN");
		} else
			additionalQuery = additionalQuery.replace("$type", "NOT IN");

		/* formatting additional query in a bracket if we have additional query */
		if (additionalQuery.length() > 0) {
			additionalQuery = "(" + additionalQuery + ")";
		}

		/* final sql query */
		sql = sql + additionalQuery;

		/* RANDOM() and Length */
		sql = sql.concat(" ORDER BY RANDOM() LIMIT " + count);

		return sql;
	}
	
	
}
