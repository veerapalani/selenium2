package qa.unicorn.ad.productmaster.api.stepdefs;

import java.io.IOException; 
import java.util.Iterator;
import java.util.Set;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import cucumber.api.java.en.And;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;

@SuppressWarnings("deprecation")
public class CreateReferenceId {
	
	String  excelFilePath, sheetName ="";
	
	@And("^store reference details in \"([^\"]*)\"$")
	public void store_reference_details_in_variablse(String excelFileName) throws Exception {
		
		/* Setting up the excel file path and sheet to store reference details */
		System.out.println("FILE NAME: "+excelFileName);
		excelFilePath = "./src/test/resources/ad/productmaster/api/excel/"+excelFileName;
		String referenceId = null;
		String toCheck= null;
		
		if(ProductMasterGeneric.refParameter.contains("Program")) {
			toCheck = "programId"; 
			sheetName = "PROGRAM";
		}
		else if(ProductMasterGeneric.refParameter.contains("Style")) {
			toCheck = "styleId";
			sheetName = "STYLE";
		}
		else if(ProductMasterGeneric.refParameter.contains("Strategy")) {
			toCheck = "strategyId";
			sheetName = "STRATEGY";
		}
		else if(ProductMasterGeneric.refParameter.contains("Manager")) {
			toCheck = "managerId";
			sheetName = "MANAGER";
		}
		else if(ProductMasterGeneric.refParameter.contains("Benchmark")) {
			toCheck = "benchmarkId";
			sheetName = "BENCHMARK";
		}
		else if(ProductMasterGeneric.refParameter.contains("FinancialAdvisor")) {
			toCheck = "faId";
			sheetName = "FINANCIAL ADVISOR";
		}
		System.out.println("============ resonse"+ProductMasterGeneric.response.body().asString());

		//Getting referenceId for response of POST request
		System.out.println("TO Check: "+toCheck);
		referenceId = ProductMasterGeneric.response.body().jsonPath().getString(toCheck);
		
		//Writing Reference Id and type in excel file (excelFilePath, sheetName, id, type)
		WriteToExcel(excelFilePath, sheetName, referenceId, sheetName);
		
		
		/* ________________________Writing data to excel file (ReferenceDetails.xlsx)__________________________ */ 
		
		
		/* converting string to JSON Object */
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(ProductMasterGeneric.response.getBody().asString());

		Set<?> set = (Set<?>) json.keySet();

		Iterator<?> i = set.iterator();
		int columnNumber = 2;
		do {
			String keyName = i.next().toString();
			String value = ProductMasterGeneric.response.jsonPath().getString(keyName);
			System.out.println(keyName + " : " + value);

			/* Creating object of Excel */
			ExcelUtils exl1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
			
			/* Getting sheet */
			XSSFSheet sheet = exl1.getSheet(sheetName);
			
			/* Operations */
			exl1.setCellData(sheet, 0, columnNumber, keyName);
			exl1.setCellData(sheet, 1, columnNumber, value);
							
			/* Closing excel file */
			exl1.closeWorkBook();

			columnNumber += 1;

		} while (i.hasNext());
	}

	//Function to write details in JSON
	public void WriteToExcel(String excelFilePath, String sheetName, String referenceId, String referenceType) throws Exception {
		
		/* Creating object of Excel */
		ExcelUtils exl1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		
		/* Getting sheet */
		XSSFSheet sheet = exl1.getSheet(sheetName);
		
		/* Operations */
		exl1.setCellData(sheet, 1, 0, referenceId);
		exl1.setCellData(sheet, 1, 1, referenceType);
		
		/* Closing excel file */
		exl1.closeWorkBook();
	
	}
}
