package qa.unicorn.ad.productmaster.api.stepdefs;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;

import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

public class BaseAPIMFInvestmentObjective   {
	EISLBaseAPIGeneric ebg = new EISLBaseAPIGeneric();
			
	String requestStr = ebg.requestJson;
	JSONObject requestJson = null;
	JSONParser parser = new JSONParser();
	Response response = ebg.response;
	SoftAssert sa = new SoftAssert();

	
	
	@And("verify the data received from server with Product Master DB for searchmfinvestmentobjectiveapi")
	public void verify_the_data_received_from_server_with_Product_Master_DB_for_getFundStyles() throws ParseException, SQLException {
		String programCodeReq="",statusReq="";
		JSONObject request = (JSONObject) parser.parse(requestStr);
		if (!request.isEmpty()) {
		 programCodeReq = request.get("programCode").toString();
		 if (request.containsKey("status")) {
			 statusReq = request.get("status").toString();
			 statusReq=statusReq.replace("[", "");
			 statusReq=statusReq.replace("]", "");
			 statusReq=statusReq.replace("\"", "'");
			
			 }else {
				
					 statusReq="'Eligible','Ineligible','Grandfathered','Hold'";
				
			 }
		 }
		ProductMasterDBManager pmdb = new ProductMasterDBManager();
		ResultSet rs = null;
		pmdb.DBConnectionStart(); 
		ArrayList<String> DBId = new ArrayList<String>();	
		ArrayList<String> DBName = new ArrayList<String>();
		
		
		//-------query-----------//
		String	sqlQuery = "select distinct lv.list_code as objectiveId, lv.list_value as objectiveName \r\n" + 
				"from list_values lv join mutual_funds mf on (lv.list_id = mf.investment_objective) \r\n" + 
				"join program_eligibility pe on (pe.reference_id = mf.mf_id) and (pe.reference_type = 'MF') \r\n" + 
				"join program pm on (pe.program_id = pm.program_id) where lv.list_type = 'INVESTMENT OBJECTIVE'\r\n" + 
				"and pe.effective_to_date is null and pm.program_code ='"+programCodeReq+"' and pe.status in (select list_id from list_values where list_value in ("+statusReq+"))";
					
	
			System.out.println(sqlQuery);
			rs = DBManager.executeSelectQuery(sqlQuery);
		
				
			while (rs.next()) {
				String dbobjectiveId =rs.getString("objectiveId");
				DBId.add(dbobjectiveId);
				String dbobjectiveName =rs.getString("objectiveName");	
			    DBName.add(dbobjectiveName);	
			}
			pmdb.DBConnectionClose();
			int countDB=DBId.size();
			String actualId = response.jsonPath().getString("objectiveName");
			String[] actualIdarr = actualId.split(",");
			int countAPI=actualIdarr.length;
			Assert.assertEquals(countDB, countAPI);
		String result="";
			Reporter.addStepLog("<b>No. of NodeIds in API = </b>" + countAPI + "<b>| No. of NodeIds for in DB = </b>" + countDB);
			//Collections.sort(DBNodeId);
			for (int count=0;count<countAPI;count++ ) {
				String actualId1 = response.jsonPath().getString("objectiveId[" + count + "]");
				String actualName = response.jsonPath().getString("objectiveName[" + count + "]");
				sa.assertTrue(DBId.contains(actualId1),"StyleNodeId "+actualId1 +"  matching in API and DB");
				sa.assertTrue(DBName.contains(actualName),"StyleName "+actualName +"  matching in API and DB");
				 result = result +"<b>objectiveId :</b>"+actualId1 +" <b>| objectiveName :</b>"+ actualName +" <b>is matching in API and DB</b><br>";
				
				//Reporter.addStepLog("<b>StyleNodeId :</b>"+actualNodeId1 +" <b>| styleName :</b>"+ actualStyleName +" <b>is present in API and DB for programCode 15</b>");
				
			
			}
			sa.assertAll();
			setCollapsibleHtml("Click here to see result",result );
		
		
	}
	
	public void setCollapsibleHtml(String header, String body) {
		Reporter.addStepLog("<div class=\"card-body\"> <div class=\"card-header\" role=\"tab\"> "
				+ "<h5 class=\"card-title outline-child-child\"> <div class=\"node\">" + header + "</div> </h5> "
				+ "</div> <div class=\"card-body collapse mt-3\">" + body + "</div> </div>");
	}
}
		
	
	



