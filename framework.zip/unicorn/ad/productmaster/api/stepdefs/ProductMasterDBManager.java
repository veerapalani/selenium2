package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;

import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.RelationalDBType;
import qa.framework.utils.PropertyFileUtils;

public class ProductMasterDBManager {

	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	
	String configPropertyFilePath = "./config.properties";
	PropertyFileUtils configProperty = new PropertyFileUtils(configPropertyFilePath);

	String environment = System.getProperty("environment", configProperty.getProperty("environment")).trim();
	DBManager dbm = new DBManager();
	/**
	 * Connecting to DB (Product Master DB)
	 * 
	 * @author PatelNim
	 */
	@SuppressWarnings("deprecation")
	
	public void fwDBConnect(){
		String host =  configProperty.getProperty("db_url");
		String dbName = configProperty.getProperty("db_name");
		String userName = configProperty.getProperty("db_username");
		String pwd = configProperty.getProperty("db_password");
		int port = Integer.parseInt(configProperty.getProperty("db_port"));
		
		
		dbm.connected(RelationalDBType.MYSQL, host, port, dbName, userName, pwd);
		//System.out.println("FW DB connected..!!");
		
	}
	
	public ResultSet fwSelect(String sqlQuery) {
		ResultSet rs = dbm.selectQuery(sqlQuery);
		
		return rs;
	}
	
	public void fwExecuteQuery(String sqlQuery) {
		dbm.executeQuery(sqlQuery);
	}
	
	public void fwDBDisconnect() {
		dbm.disconnect();
		//System.out.println("FW DB disconnected..!!");
	}
	
	public void DBConnectionStart() {

		String db_url = null;
		String db_port = null;
		String db_dbname = null;
		String db_username = null;
		String db_password = null;

		if (environment.equalsIgnoreCase("dev")) {
			db_url = property.getProperty("db_PM_dev_url");
			db_port = property.getProperty("db_PM_dev_port");
			db_dbname = property.getProperty("db_PM_dev_dbname");
			db_username = property.getProperty("db_PM_dev_username");
			db_password = property.getProperty("db_PM_dev_password");
			
		} else if (environment.equalsIgnoreCase("qa")) {
			db_url = property.getProperty("db_PM_qa_url");
			db_port = property.getProperty("db_PM_qa_port");
			db_dbname = property.getProperty("db_PM_qa_dbname");
			db_username = property.getProperty("db_PM_qa_username");
			db_password = property.getProperty("db_PM_qa_password");
			
		} else if (environment.equalsIgnoreCase("int")) {
			db_url = property.getProperty("db_PM_int_url");
			db_port = property.getProperty("db_PM_int_port");
			db_dbname = property.getProperty("db_PM_int_dbname");
			db_username = property.getProperty("db_PM_int_username");
			db_password = property.getProperty("db_PM_int_password");
			
		} else if (environment.equalsIgnoreCase("uat")) {
			db_url = property.getProperty("db_PM_uat_url");
			db_port = property.getProperty("db_PM_uat_port");
			db_dbname = property.getProperty("db_PM_uat_dbname");
			db_username = property.getProperty("db_PM_uat_username");
			db_password = property.getProperty("db_PM_uat_password");
			
		} 
		else if (environment.equalsIgnoreCase("demo")) {
			db_url = property.getProperty("db_PMDemo_demo_url");
			db_port = property.getProperty("db_PM_demo_port");
			db_dbname = property.getProperty("db_PM_demo_dbname");
			db_username = property.getProperty("db_PM_demo_username");
			db_password = property.getProperty("db_PM_demo_password");
			
		} 
		
		else {
			
			/** Not Required, scripts will fails in HOOKS itself. **/
		//	Assert.assertTrue(false, "Undefined Product Master Database Environment, Please check in config.properties file. \n"
			//		+ "Acceptable Values(not case sensitive): environment = dev/qa/uat");
		}
		
		System.out.println("Connecting to " + environment.toUpperCase() + " DB..!!");
		DBManager.openPostgreDBConnection(db_url, db_port, db_dbname, db_username, db_password);
		System.out.println("Connected successfully with user [" + db_username + "]..!!");
	}

	/**
	 * Closing DB Connection (Product Master DB)
	 *
	 */
	@SuppressWarnings({ "deprecation" })
	public void DBConnectionClose() {
		DBManager.closeConnection();
		System.out.println("DB connection closed successfully.");

	}
}
