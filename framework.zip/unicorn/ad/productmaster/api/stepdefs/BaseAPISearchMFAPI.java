package qa.unicorn.ad.productmaster.api.stepdefs;

import org.junit.Assert;

import cucumber.api.java.en.And;
import io.restassured.response.Response;
import qa.framework.utils.Reporter;

public class BaseAPISearchMFAPI {

	Response response = null;
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();

	@And("^response code for searchmfapi service API is 200 or 404$")
	public void validate_the_counts_in_response_with_DB_for() {
		response = EISLBaseAPIGeneric.response;
		int statusCode = response.getStatusCode();

		if (statusCode == 200 || statusCode == 404) {
			Reporter.addStepLog("<b>Expected Response Code: </b>200 or 404");
			Reporter.addStepLog("<b>Actual Response Code: </b>" + statusCode);
		} else {
			Reporter.addStepLog("Status code is not as expected, expected 200/404 but received " + statusCode);
			Reporter.addStepLog(
					"<b style=\"color:red\">NOT AS EXPECTED | Response code from API is: " + statusCode + "</b>");

			ebag.setCollapsibleHtml("Click here to see response",
					"<p style=\"color:red\">" + response.getBody().asString() + "</p>");
			Assert.assertTrue("Status code is not as expected, expected 200/404 but received " + statusCode, false);
		}
	}
}
