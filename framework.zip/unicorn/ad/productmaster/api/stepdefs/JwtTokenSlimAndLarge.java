package qa.unicorn.ad.productmaster.api.stepdefs;

import org.junit.Assert;

import cucumber.api.java.en.Given;
import io.restassured.response.Response;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RetriveResponse;
import qa.framework.utils.Action;
import qa.framework.utils.Reporter;

public class JwtTokenSlimAndLarge {

	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();

	/*
	 * Getting values from framework DB according to "environment" mentioned in
	 * "config.properties" file
	 */
	String keyOrPfxPath = "./src/test/resources/ad/productmaster/api/DataLoadFiles/" + Action.getTestData("certName");
	String URI = Action.getTestData("v3tokenURI");
	String subjectValue = Action.getTestData("subjectValue");
	String certPass = Action.getTestData("certPass");

	@Given("^user generates jwt \"([^\"]*)\" token to connect to EISL(.*)$")
	public void user_generates_jwt_something_token_to_connect_to_eisl(String version,String userID) throws Throwable {
		switch (version) {
		case "large - v2": {

			/* No coding required, referring to EISLBaseAPI token */
			ebag.user_generates_jwt_token_to_connect_to_EISL(userID);
			ebag.setCollapsibleHtml("Click here to see v2 token", EISLBaseAPIGeneric.jwtToken);

			break;
		}
		
		case "slim - v3": {

			HttpClientUtils.baseUri = URI;
			HttpClientUtils.basePath = "/token";
			
			if(userID.length()>0) {
				String [] subjectValueArr = userID.split("-"); 
				/* using second value to fetch user ID " - V005QPM1" -> " V005QPM1" -> "V005QPM1" */
				subjectValue = subjectValueArr[1].trim(); 
			}

			RetriveResponse response = HttpClientUtils.given().setHeader("Subject", subjectValue)
					.setProxy("10.98.21.24", 8080).setCetificate(keyOrPfxPath, certPass).buildUri()
					.executeRequest(MethodType.POST);

			int status = response.getStatusCode();

			if (status != 200) {
				Assert.assertTrue("Not able to generate JWT Token, Please Check!", false);
			}

			EISLBaseAPIGeneric.jwtToken = (String) response.getBody().jsonPath("token");

			Reporter.addStepLog("<b>URI:</b> " + URI);

			Reporter.addStepLog("JWT Token generated successfully for userID - <b>" + subjectValue + "</b>!!");
			ebag.setCollapsibleHtml("Click here to see v3 token", EISLBaseAPIGeneric.jwtToken);

			break;
		}
		}

	}

}
