package qa.unicorn.ad.productmaster.api.stepdefs;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.Cookie;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.Assert;
import qa.framework.utils.Reporter;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Action;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.RestApiHelperMethods;
import qa.framework.utils.RestApiUtils;
import qa.framework.utils.WaitManager;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;

@SuppressWarnings("deprecation")
public class ProductMasterGeneric {
	String excelFilePath, sheetName, requestJsonFilePath = "";
	int rowIndex;
	public static String requestJson;
	public static Response response;
	String jsonString;
	String option;
	String entityId;
	public static String refParameter;
	String referenceId;
	public static String postBaseURI;
	String referenceType;
	String username = "";
	String password = "";
	String WebUiUrl = "";

	public static String duplicateCode, tokenValue;
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);

	ProductMasterDBManager pmdb = new ProductMasterDBManager();

	List<String> partSearchString = new ArrayList<String>();
	List<String> identifiers = new ArrayList<String>();

	String partOrExact = "exact";

	/**
	 * @author PatelNim
	 *
	 */

	@Given("^base \"([^\"]*)\" post uri is available$")
	public void base_post_uri_is_available(String baseUrlKey) throws Throwable {

		RestApiUtils.requestSpecification = null;
		RestAssured.baseURI = null;
		RestAssured.basePath = "";
		String headerName = "", headerValue = "";
		/*
		 * Setting up connection with Base URI Use "BaseURI_PM_" in DBKey and adding
		 * headers according to Environment-
		 */
		postBaseURI = Action.getTestData("BaseURI_PM_" + baseUrlKey);

		RestApiUtils.setBaseURI(postBaseURI);

		RestApiUtils.requestSpecification = RestAssured.given();

		/* For Dev, UAT and QA Environment */
		if (postBaseURI.contains(".dev.") || postBaseURI.contains(".qa.") || postBaseURI.contains(".uat.")) {
			headerName = "PMAPITEST";
			headerValue = "Test";
		}

		/* Setting Headers */
		RestApiUtils.requestSpecification.header(headerName, headerValue);

		/*
		 * If API is SSO Integrated, fetching cookies from WebUI and setting in Rest
		 * call
		 */
		if (postBaseURI.contains("pm.qa.")||postBaseURI.contains("pm.uat.")) {
			username = property.getProperty("pm_qa_username");
			password = property.getProperty("pm_qa_password");
			WebUiUrl = property.getProperty("url_PM_QA");

			/*
			 * SSOAuthentication(String webUIUrl, String baseUri, String username, String
			 * password)
			 */
			Reporter.addStepLog("Getting Cookies from Web browser and setting in Rest call.");
			SSOAuthentication(postBaseURI, username, password);

		} else if (postBaseURI.contains("pm.dev.")) {
			username = property.getProperty("pm_dev_username");
			password = property.getProperty("pm_dev_password");
			WebUiUrl = SSOLoginPage.URL;

			/*
			 * SSOAuthentication(String webUIUrl, String baseUri, String username, String
			 * password)
			 */
			Reporter.addStepLog("Getting Cookies from Web browser and setting in Rest call.");
			SSOAuthentication(postBaseURI, username, password);
		}

		/* Logging in report */
		Reporter.addStepLog("Working on <b style=\"color:green\">" + baseUrlKey + "</b>");
		Reporter.addStepLog("Base URI:" + postBaseURI);
		Reporter.addStepLog("<strong>Header Name: </strong>" + headerName);
		Reporter.addStepLog("<strong>Header Value: </strong>" + headerValue);
	}

	@And("^jira scenario Id is (.+)$")
	public void jira_scenario_id_is(String jiraid) throws Throwable {
		Reporter.addStepLog("<b>JIRA Test Case ID: </b>" + jiraid);

	}

	@When("^the \"([^\"]*)\" request json is created from \"([^\"]*)\" with (.+) data from \"([^\"]*)\"$")
	public void the_create_request_is_sent_with_and_unique_name_with_data_from(String notToUse, String jsonFileName,
			String optionFromFF, String excelFileName) throws Exception {

		/*
		 * setting json path and excel path and options through which test data will
		 * mapped to JSON
		 */
		requestJsonFilePath = "./src/test/resources/ad/productmaster/api/requestjson/" + jsonFileName;
		excelFilePath = "./src/test/resources/ad/productmaster/api/excel/" + excelFileName;
		option = optionFromFF;

		/* Selecting sheet */
		if (option.contains("Invalid")) {
			sheetName = "Invalid";
		} else if (option.contains("Valid")) {
			sheetName = "Valid";
		} else if (option.contains("Duplicate")) {
			sheetName = "Duplicate";
		}

		else {
			Assert.fail();
		}

		/*
		 * getting the row index from the excel sheet using which request json will be
		 * formed
		 */
		ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = exlObj.getSheet(sheetName);

		rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);

		exlObj.closeWorkBook();

		if (rowIndex > 0) {
			requestJson = RestApiHelperMethods.putExcelRowDataToJSONReturnsString(requestJsonFilePath, excelFilePath,
					sheetName, rowIndex);
		} else {
			Assert.fail();
		}
	}

	@And("^replace \"([^\"]*)\" with unique code$")
	public void replace_parameters(String parameter) throws Exception {

		/* forming json from excel data */
		if (rowIndex > 0) {
			if (parameter.equalsIgnoreCase("nothing")) {
				Reporter.addStepLog("Nothing to change to unique");
			}

			else {
				String[] indvParameter = parameter.split(", ");
				String oldParameter;

				/*
				 * getting the row index from the excel sheet using which request json will be
				 * formed
				 */
				ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
				XSSFSheet sheet = exlObj.getSheet(sheetName);

				rowIndex = exlObj.getRowIndexByCellValue(sheet, 0, option);

				HashMap<String, Object> map = new HashMap<String, Object>();
				map = RestApiHelperMethods.creatMapFromExcelHeaders(excelFilePath, sheetName, rowIndex);

				exlObj.closeWorkBook();

				/*
				 * Creating unique code and replacing it in JSON
				 */
				for (int i = 0; i < indvParameter.length; i++) {

					Long time = Calendar.getInstance().getTimeInMillis();

					oldParameter = (String) map.get("$" + indvParameter[i]);
					System.out.println("Replacing " + indvParameter[i]);

					/*
					 * SPECIAL CASE If entity needs to be unique but user have to treat it with
					 * special case like More than maximum, less than minimum, null , blank etc
					 */
					Reporter.addStepLog("OLD JSON: " + requestJson);
					if (oldParameter.equalsIgnoreCase("MAX")) {
						requestJson = requestJson.replace(oldParameter, randomStringAlphaNumeric(256));
					} else if (oldParameter.equalsIgnoreCase("MIN")) {
						requestJson = requestJson.replace(oldParameter, randomStringAlphaNumeric(2));
					} else if (oldParameter.equalsIgnoreCase("null")) {
						requestJson = requestJson.replace("\"" + oldParameter + "\"", "null");
					} else if (oldParameter.equalsIgnoreCase("blank")) {
						requestJson = requestJson.replace(oldParameter, "");
					} else if (oldParameter.equalsIgnoreCase("RAND4")) {
						requestJson = requestJson.replace(oldParameter, randomStringAlphaNumeric(4));
					} else {
						requestJson = requestJson.replace("\"" + oldParameter + "\"",
								"\"" + oldParameter + "-QA-Automation-PM-" + time + "\"");
					}
				}
			}
		} else {
			Assert.fail();
		}

	}

	@And("^send POST request$")
	public void sent_POST_request() {

		// POST request
		RestApiUtils.requestSpecification.body(requestJson);
		RestApiUtils.setRequestHeader(RestApiUtils.requestSpecification, "Content-Type", "application/json");

		response = RestApiUtils.postRequest(RestApiUtils.requestSpecification, RestAssured.baseURI);
		Reporter.addStepLog("<b>JSON:-</b> " + requestJson.toString());
		// Reporter.addScenarioLog("Response: "+response.asString());
	}

	@And("^the response code should be \"([^\"]*)\"$")
	public void the_response_status_code_should_be_matching_with(String statusCode) throws Throwable {

		/* If status code is not as expected, printing the error/response in Reports */
		if (response.getStatusCode() != Integer.parseInt(statusCode)) {

			Reporter.addStepLog("<b style=\"color:red\">NOT AS EXPECTED | Response from API is : Response Code - "
					+ response.getStatusCode() + "</b>");
			Reporter.addStepLog(
					"<p style=\"color:red\"> <b>Response Body -</b> " + response.getBody().asString() + "</p>");

		} else {
			Reporter.addStepLog("<b>Response Body:</b> " + response.getBody().asString());
		}

		/* Verifying response/status code */
		RestApiHelperMethods.verfiyStatusCode(response, Integer.parseInt(statusCode));

	}

	@And("^the response body should contain valid information send in post request$")
	public void json_comparision() throws JSONException, IOException {

		Reporter.addStepLog(
				"<b>RequestJson:</b> " + requestJson.toString() + "<br> <b>Response Json: </b>" + response.asString());

		/* Verifying request JSON with response JSON */
		JSONAssert.assertEquals(requestJson.toString(), response.asString(), JSONCompareMode.LENIENT);

		/* printing response in report */
		Reporter.addStepLog("<b>Response is</b> " + response.body().asString());

	}

	@And("^verify the details are not null for the parameters given below for \"([^\"]*)\" uri:$")
	public void validateStatusAndOtherThings(String notToUse, List<String> parameters) {

		for (int n = 0; n < parameters.size(); n++) {

			if (parameters.get(n).toString().equalsIgnoreCase("Status_should_be_either_Active_or_Pending")) {

				/* Getting status from response */
				String status = response.jsonPath().getString("status");

				/* Validating status is ACTIVE or PENDING */
				if (status.equalsIgnoreCase("active") || status.equalsIgnoreCase("pending")) {
					Reporter.addStepLog("<p style=\"color:green\">Status is - <b>" + status + "</b></p>");
					Assert.assertTrue(true);

				} else {
					Reporter.addStepLog("<p style=\"color:red\">Status is - <b>" + status + "</b></p>");
					Assert.assertTrue(false);
				}
			}

			else {
				Reporter.addStepLog("Verifying for <b>" + parameters.get(n) + " </b> - "
						+ (String) response.jsonPath().getString(parameters.get(n)));
				RestApiHelperMethods.verifyNotNull(response.jsonPath().getString(parameters.get(n)));
			}
		}
	}

	@And("^the response body should contain invalid information send in the post request$")
	public void the_response_body_should_contain_invalid_information_send_in_the_post_request() throws Throwable {

		// Getting actual values
		String aMessage = response.body().jsonPath().getString("message").toString();
		String aException = response.body().jsonPath().getString("exception").toString();
		String aDetails = response.body().jsonPath().getString("details");
		String testDetails = null;

		/* Getting Expected values */
		try {

			/* Creating object of Excel */
			ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);

			/* Getting sheet */
			XSSFSheet sheet = exlObj.getSheet(sheetName);

			/* Operations: getting expected message, expected exception and test details */
			String xMessage = exlObj.getStringCellData(sheet, rowIndex, 3);
			String xException = exlObj.getStringCellData(sheet, rowIndex, 2);
			testDetails = exlObj.getStringCellData(sheet, rowIndex, 1);

			/* Closing excel file */
			exlObj.closeWorkBook();

			Reporter.addStepLog("<b>Verifying for " + testDetails + "</b>");

			/* Verifying exception and details and logging in Reports. */
			Reporter.addStepLog("\n <b>Expected Message:</b> " + xMessage + " <b>| Actual Message:</b> " + aMessage);
			Reporter.addStepLog(
					"\n <b>Expected Exception:</b> " + xException + " <b>| Actual Exception:</b> " + aException);
			Reporter.addStepLog("<b>Actual Details: </b>" + aDetails);
			RestApiHelperMethods.verifyTrue(aMessage.contains(xMessage));
			RestApiHelperMethods.verifyTrue(aException.contains(xException));
			Reporter.addStepLog("<b>Successful for " + testDetails + "</b>");

		} catch (Exception e) {
			Reporter.addStepLog("<b>FAILED FOR " + testDetails + " </b>");
			ExceptionHandler.handleException(e);

		}

	}

	/* Use this only for "HappyFlow" */
	@When("^create json file for (.+)$")
	public void create_json_file_for(String parameter) throws Exception {
		refParameter = parameter;
		requestJsonFilePath = refParameter + ".json";
		excelFilePath = refParameter + ".xlsx";

		the_create_request_is_sent_with_and_unique_name_with_data_from("", requestJsonFilePath, "Valid_HappyFlow",
				excelFilePath);
	}

	/* Replacing reference Parameters */
	@And("^read (.+) from \"([^\"]*)\" and replace in \"([^\"]*)\"$")
	public void replace_from_and_put_in(String reference, String excelFileName, String notToUse) throws Exception {

		if (reference.equalsIgnoreCase("nothing")) {
			/* Nothing to do */
		}

		else {
			String[] indvReference = reference.split(", ");
			String xlSheet = null, entityId = null;
			String xlFilePath = "./src/test/resources/ad/productmaster/api/excel/" + excelFileName;
			/* using reference as sheet name here */

			for (int i = 0; i < indvReference.length; i++) {

				if (indvReference[i].equals("PROGRAM")) {
					xlSheet = indvReference[i];
					entityId = "\"$programId\"";
				} else if (indvReference[i].equals("MANAGER")) {
					xlSheet = indvReference[i];
					entityId = "\"$managerId\"";

				} else if (indvReference[i].equals("BENCHMARK")) {
					xlSheet = indvReference[i];
					entityId = "\"$benchmarkId\"";
				} else if (indvReference[i].equals("STRATEGY")) {
					xlSheet = indvReference[i];
					entityId = "\"$strategyId\"";
				} else if (indvReference[i].equals("STYLE")) {
					xlSheet = indvReference[i];
					entityId = "\"$styleId\"";
				} else if (indvReference[i].equals("FINANCIAL ADVISOR")) {
					xlSheet = indvReference[i];
					entityId = "\"$faId\"";
				}

				ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, xlFilePath);
				XSSFSheet sheet = exlObj.getSheet(xlSheet);

				String referenceId = exlObj.getStringCellData(sheet, 1, 0);
				String referenceType = exlObj.getStringCellData(sheet, 1, 1);

				exlObj.closeWorkBook();

				/* Replacing reference id and reference type (if present in requestJson) */
				requestJson = requestJson.replace("\"$referenceId\"", referenceId);
				requestJson = requestJson.replace("$referenceType", referenceType);

				/* Replacing ManagerId, programId, styleId */
				requestJson = requestJson.replace(entityId, referenceId);

			}
		}
	}

	/* Checking duplication is not allowed */
	@And("^replace \"([^\"]*)\" with old value$")
	public void replace_with_old_value(String parameterToChange) {
		String[] indvParameterToChange = parameterToChange.split(", ");

		for (int i = 0; i < indvParameterToChange.length; i++) {

			/* getting old value from response */
			String oldParameter = response.body().jsonPath().getString(indvParameterToChange[i]).toString();

			/* changing value in array according to test data [needs to be change later] */
			if (indvParameterToChange[i].equalsIgnoreCase("managerCode2")) {
				indvParameterToChange[i] = "manager-Code2";

			}

			/* Replacing "$valueName" with old value */
			requestJson = requestJson.replace("parameterToChange", oldParameter);
		}
	}

	@And("^check status of \"([^\"]*)\" should be \"([^\"]*)\"$")
	public void check_status_of_should_be(String toCheck, String expectedStatus) {

		/* If nothing, do nothing */
		if (toCheck.equalsIgnoreCase("nothing")) {

		}

		/* else check expected status with actual */
		else {

			/* Getting actual status */
			String actualStatus = response.jsonPath().getString("status");

			/* Validating and logging in Reports */
			Reporter.addStepLog(
					"<b>Expected Status: </b>" + expectedStatus + " <b>| Actual Status: </b>" + actualStatus);
			Assert.assertEquals(actualStatus, expectedStatus);
		}

	}

	@And("^read parameters given below from response and replace in \"([^\"]*)\"$")
	public void read_parameters_given_below_from_response_and_replace_in_something(String jsonPath,
			List<String> parameters) {
		for (int i = 0; i < parameters.size(); i++) {

			String[] indvParameters = parameters.get(i).split(", ");

			/*
			 * if more than one parameter is there in pipeline example: |entity1, entity2|
			 */
			for (int n = 0; n < indvParameters.length; n++) {

				String parameter = response.jsonPath().getString(indvParameters[n]);
				String str[] = indvParameters[n].split("\\.");
				String replace = str[str.length - 1];
				Reporter.addStepLog("replacing " + "$" + replace + " with " + ":" + parameter);
				requestJson = requestJson.replace("$" + replace + "", parameter);

				/* converting numeric value into numeric */
				requestJson = ConvertStringInJsonToNumeric(requestJson);
			}
		}

	}

	/* ------------------ FOR UPDATE ------------------------ */

	@And("^store the \"([^\"]*)\" from response$")
	public void store_the_something_from_response(String code) {
		duplicateCode = response.jsonPath().getString(code);
		Reporter.addStepLog(duplicateCode);
	}

	@And("^replace \"([^\"]*)\" with duplicate code$")
	public void replace_something_with_duplicate_code(String code) throws Exception {
		Reporter.addStepLog("replacing " + "\"$" + code + "\"" + " with " + ":" + duplicateCode);
		requestJson = requestJson.replace("parameterToChange", duplicateCode);
	}

	/* *********************** SEARCH ********************************** */

	@When("^search via \"([^\"]*)\" in API$")
	public void search_via_in_API(String searchToken) throws Throwable {

		if (searchToken.contains("int_")) {
			tokenValue = IntegrationGeneric.UIPassedValues.get(searchToken.substring(4));
		} else if (!searchToken.contains("str_")) {
			tokenValue = response.jsonPath().getString(searchToken);

			/* Making string of length 20, because more than 20 chars are not allowed */
			if (tokenValue.length() > 20) {
				tokenValue = tokenValue.substring(tokenValue.length() - 20, tokenValue.length());
			}
		}

		/* Removing "str_" from search token */
		else {
			tokenValue = searchToken.substring(4);
			searchToken = "String";
		}

		/* Replacing search token in request JSON */
		requestJson = requestJson.replace("$searchToken", tokenValue);

		/* Logging in reports */
		Reporter.addStepLog("Searching via " + searchToken + " : " + tokenValue);

	}

	@And("^something here$")
	public void something_here() throws Throwable {
	}

	@Then("^verify \"([^\"]*)\" contains \"([^\"]*)\" \"([^\"]*)\" or not$")
	public void verify_should_contains(String parameters, String notToUse, String searchToken) throws Throwable {

		/* Comma Seperator */
		String[] indvParameter = parameters.split(", ");

		List<String> searchResults = new ArrayList<String>();

		/* Storing results of all entities one by one */
		for (int i = 0; i < indvParameter.length; i++) {
			searchResults.add(response.jsonPath().getString(indvParameter[i]));
		}

		/* checking if search result contains token or not */
		if (searchResults.toString().contains(tokenValue)) {
			RestApiHelperMethods.verifyTrue(searchResults.toString().contains(tokenValue));
			Reporter.addStepLog("Verified Successfully");
		} else {
			RestApiHelperMethods.verifyTrue(response.body().asString().contains("details"));
			Reporter.addStepLog("<b style=\"color:red\">" + response.jsonPath().getString("details") + "</b>");
		}

		/* Clearing list */
		searchResults.clear();

	}

	@And("^verify for (.+), details should be (.+)$")
	public void verify_for_details_should_be(String notToUse, String eDetails) {

		/* Storing details from response */
		String aDetails = response.jsonPath().getString("details");

		/*
		 * Validating details from response with expected details and logging in reports
		 */
		Reporter.addStepLog("<b>Expected:</b> " + eDetails + "<b>Actual Details: </b>" + aDetails);
		RestApiHelperMethods.verifyTrue(aDetails.contains(eDetails));

	}

	/**
	 * Validating case sensitivity
	 * 
	 * @author GuptaRa
	 * @param searchtoken
	 * @param Case
	 */
	@And("^search via changing the \"([^\"]*)\" to \"([^\"]*)\" case$")
	public void search_via_changing_the_something_to_something_case(String searchtoken, String Case) {

		String myValue = null;

		if (Case.equalsIgnoreCase("upper")) {
			Reporter.addStepLog("changing into " + Case + " case");
			myValue = tokenValue.toUpperCase();
		} else if (Case.equalsIgnoreCase("lower")) {
			Reporter.addStepLog("changing into " + Case + " case");
			myValue = tokenValue.toLowerCase();
		}
		/* Replacing search token in request JSON */
		requestJson = requestJson.replace("$searchToken", myValue);

		/* Logging in reports */
		Reporter.addStepLog("Searching via " + searchtoken + " : " + myValue);

	}

	@And("^store the value of \"([^\"]*)\" for tokenValue$")
	public void store_the_value_of_something_for_tokenvalue(String searchtoken) {
		tokenValue = response.jsonPath().getString(searchtoken);
	}

	/* ***************************** ESIL SEARCH ***************************** */

	@When("^create JSON file with (.+) and name as (.+)$")
	public void create_JSON_with_something(String keys, String fileName) throws IOException, ParseException {

		String jsonString = "{@}";

		/* Creates file if not exist, If exist - works on that file */
		File file = new File("./src/test/resources/ad/productmaster/api/requestjson/" + fileName);

		/* creates the file */
		file.createNewFile();

		/* creates a FileWriter Object */
		FileWriter writer = new FileWriter(file);

		keys = RemoveEntityNameFromString(keys); // program.identifier -> identifier

		if (keys.contains(".")) {
			keys = keys.substring(keys.indexOf(".") + 1);
		}

		/* Storing in array */
		String[] keysArr = keys.split(", ");
		keys = "";

		/* Forming JSON */
		for (int n = 0; n < keysArr.length; n++) {
			keys = keys.concat("\"" + keysArr[n] + "\" : " + "\"$" + keysArr[n] + "\"");
			if (n != keysArr.length - 1) {
				keys = keys.concat(",");
			}
		}

		/* Final JSON */
		jsonString = jsonString.replace("@", keys);

		requestJson = jsonString;

		/* Logging in Reports */
		Reporter.addStepLog("<b>Json:</b></br> " + jsonString.replace(",", ",</br>"));

		/* Writes the content to the file */
		writer.write(jsonString);
		writer.flush();
		writer.close();
	}

	@Then("^write (.+)'s response attributes in excel$")
	public void store_program_attributes_in_excel(String entity) throws ParseException {

		/* converting string to JSON Object */
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(response.getBody().asString());

		Set<?> set = (Set<?>) json.keySet();

		Iterator<?> i = set.iterator();
		int columnNumber = 0;
		do {
			String keyName = i.next().toString();
			String value = response.jsonPath().getString(keyName);
			System.out.println(keyName + " : " + value);

			// Writing values in Excel File
			try {
				/*
				 * Changing each value to string "entity" is acting as sheet name. It should
				 * always in CAPS like PROGRAM MANAGER STYLE etc..
				 */

				WriteKeyValueInExcel(entity, columnNumber, keyName, "'" + value);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // sheetName, columnNumber, keyName, value

			columnNumber += 1;

		} while (i.hasNext());
	}

	@Then("^replace search parameters with (.+)'s value in JSON file$")
	public void replace_search_parameters_with_keys_s_value_in_JSON_file(String key) {

		// requestJsonFilePath =
		// "./src/test/resources/ad/productmaster/api/requestjson/ESILSearch.json";
		excelFilePath = null;

		String exlSheetName = null;

		String[] keyArr = null;

		// if(key.contains(", ")) {
		keyArr = key.split(", ");

		for (int n = 0; n < keyArr.length; n++) {

			/*
			 * Assigning sheet name according to key name Example: if keyArr[n]="fa.code",
			 * it will return "FINANCIAL ADVISOR" if keyArr[n]="program.code", it will
			 * return "PROGRAM"
			 * 
			 * Special case for investmentStyleStatus, investmentStyleName, managerCode1 and
			 * programName = it will return
			 */
			exlSheetName = ReturnSheetName(keyArr[n]);

			/* Special case for strategy */
			if (keyArr[n].toLowerCase().contains("investmentstyle") || keyArr[n].toLowerCase().contains("managercode1")
					|| keyArr[n].toLowerCase().contains("programname")) {
				excelFilePath = "./src/test/resources/ad/productmaster/api/excel/ReferenceDetails.xlsx";
			} else {
				excelFilePath = "./src/test/resources/ad/productmaster/api/excel/ESILSearch.xlsx";
			}

			Reporter.addStepLog("EXL FILE: " + excelFilePath + " | Sheet: " + exlSheetName);
			/*
			 * getting the row index from the excel sheet using which request json will be
			 * formed
			 */

			/* Setting Excel file and sheet */
			ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
			XSSFSheet sheet = exlObj.getSheet(exlSheetName);

			// ExcelUtil.setExcelFile(excelFilePath, exlSheetName);
			rowIndex = 1;

			/* checking whether to perform partial search or exact search */
			if (keyArr[n].contains("part.")) {
				partOrExact = "partial";
				keyArr[n] = keyArr[n].replace("part.", "");
			}

			/*
			 * Removing "entityName." from key (removes if present)
			 * 
			 * Example: program.identifier ----> identifier
			 * 
			 */
			keyArr[n] = RemoveEntityNameFromString(keyArr[n].toString());

			String fromReplaceAttribute = keyArr[n];

			Reporter.addStepLog("fromReplace" + fromReplaceAttribute);

			/* hard coded for EISL Search strategy */
			if (keyArr[n].equalsIgnoreCase("investmentStyleName")) {
				keyArr[n] = "styleName";
			} else if (keyArr[n].equalsIgnoreCase("investmentStyleStatus")) {
				keyArr[n] = "status";
			} else if (keyArr[n].equalsIgnoreCase("managerCode1")) {
				keyArr[n] = "managerCode";
			} else if (keyArr[n].equalsIgnoreCase("programName")) {
				keyArr[n] = "programName";
			}

			/* Getting value for particular key from excel */
			// List<String> toReplace = ExcelUtil.getCellData(keyArr[n]);
			List<Object> toReplace = exlObj.getColumnData(sheet, 0, keyArr[n]);

			/* Closing excel file as it is no longer in use below */
			exlObj.closeWorkBook();

			// Fetching Exact value from excel file
			String toReplaceString = (String) toReplace.get(0);

			/* making sub string of random number (Partial Search) */
			if (partOrExact.equalsIgnoreCase("partial")) {
				Random rand = new Random();
				int lastIndex = rand.nextInt(toReplaceString.length());
				// int lastIndex = 2;

				if (lastIndex < 3) {
					lastIndex = 3; // because minimum characters allowed is 3
				}
				toReplaceString = toReplaceString.substring(0, lastIndex + 1);

				/*
				 * Adding partial search value to a list so that we can use this later in
				 * validate_the_values_of_<keys>_in_response)
				 */
				partSearchString.add(toReplaceString);
				partOrExact = "exact";
			}

			requestJson = requestJson.replace("\"$" + fromReplaceAttribute + "\"", "\"" + toReplaceString + "\"");

			/* converting string null into null null in json string */
			requestJson = requestJson.replace("\"null\"", "null");

			/* converting string true into boolean true in json string */
			requestJson = requestJson.replace("\"true\"", "true");

			/* converting string false into boolean false json string */
			requestJson = requestJson.replace("\"false\"", "false");

			/* removing ' [inverted comma] */
			requestJson = requestJson.replace("\"'", "\"");

			/* converting numeric value into numeric */
			requestJson = ConvertStringInJsonToNumeric(requestJson);
		}
		Reporter.addStepLog("JSON Created </br>:" + requestJson);
	}

	@SuppressWarnings("unused")
	@Then("^validate the values of (.+) in response$")
	public void validate_the_values_of_in_response(String keys) {

		excelFilePath = null;
		String exlSheetName = null;
		Boolean flagForStrategy = false;
		String[] keysArr = keys.split(", ");
		String checkInResponse = null;
		String ignore = "no";
		int n = 0;

		List<Object> values = new ArrayList<Object>();

		/* Selecting one entity from LIST */
		for (int i = 0; i < keysArr.length; i++) {

			/* Assigning value of entity as SHEET NAME */
			exlSheetName = ReturnSheetName(keysArr[i]);

			/* Selecting Excel file with particular sheet */
			/* Special case for strategy */
			if (keysArr[i].toLowerCase().contains("investmentstyle")
					|| keysArr[i].toLowerCase().contains("managercode1")
					|| keysArr[i].toLowerCase().contains("programname")) {
				excelFilePath = "./src/test/resources/ad/productmaster/api/excel/ReferenceDetails.xlsx";
			} else {
				excelFilePath = "./src/test/resources/ad/productmaster/api/excel/ESILSearch.xlsx";
			}

			/* Connecting to EXCEL FILE */
			ExcelUtils exlObj = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
			XSSFSheet sheet = exlObj.getSheet(exlSheetName);

			/* hard coded for EISL Search strategy */
			if (keysArr[i].equalsIgnoreCase("investmentStyleName")) {
				keysArr[i] = "styleName";
				checkInResponse = "styles.name";
				ignore = "yes";
			} else if (keysArr[i].equalsIgnoreCase("investmentStyleStatus")) {
				keysArr[i] = "status";
				checkInResponse = "styles.status";
				ignore = "yes";
			} else if (keysArr[i].equalsIgnoreCase("managerCode1")) {
				keysArr[i] = "managerCode";
				checkInResponse = "managers.code";
				ignore = "yes";
			} else if (keysArr[i].toLowerCase().contains("programname")) {
				if (keysArr[i].contains("part.")) {
					keysArr[i] = "part.programName";
					checkInResponse = "programs.name";
				} else {
					keysArr[i] = "programName";
					checkInResponse = "programs.name";
				}

				ignore = "yes";
			}

			/* contains .part or not */
			if (keysArr[i].contains("part.") || keysArr[i].contains(".part")) {
				partOrExact = "partial";
			} else {
				partOrExact = "exact";
			}

			/* For further use for STRATEGY */
			if (postBaseURI.contains("ESILSearchStrategy")) {
				flagForStrategy = true;
			}

			/* Removing "entityName." from key (removes if present) */
			keysArr[i] = RemoveEntityNameFromString(keysArr[i].toString());

			/* Storing value of key in variable so that we can use it later */
			if (ignore != "yes") {
				checkInResponse = keysArr[i].toString();
				Reporter.addStepLog("<b>CHECK IN RESPONSE</b>: " + checkInResponse);
			}

			/* getting value for particular key from excel. */
			values = exlObj.getColumnData(sheet, 0, keysArr[i]);

			/* used "0" as values is been stored in 0th index of list. */
			String expectedResult = (String) values.get(0);

			/* changing value of expected result if it is partial search */

			if (partOrExact.equals("partial")) {
				expectedResult = partSearchString.get(n);
				Reporter.addStepLog("EXPECTEDRESULTS: " + expectedResult);
				n++;

			}

			/*
			 * Removing ' from string as we are getting ' by default from excel sheet
			 * Example: 'something -> something
			 */
			expectedResult = expectedResult.replace("'", "");

			/*
			 * SPECIAL CASE FOR STRATEGY- |in request | in response |
			 * |investmentStrategyName | name | |investmentStrategyStatus | status |
			 */
			if (flagForStrategy = true) {
				if (checkInResponse.equalsIgnoreCase("investmentStrategyName")) {
					checkInResponse = "name";
				} else if (checkInResponse.equalsIgnoreCase("investmentStrategyStatus")) {
					checkInResponse = "status";
				}
			}

			/* Fetching records from response body */
			String allResponse = response.jsonPath().getString(checkInResponse).toString();
			allResponse = allResponse.substring(1, allResponse.length() - 1);
			String[] actualResult = allResponse.split(", ");

			Reporter.addStepLog("<b>No. of Actual Result for " + keysArr[i] + "</b>: " + actualResult.length);

			for (int j = 0; j < actualResult.length; j++) {
				/*
				 * Special Case for strategy Minimum Amount where strategyMinimumAmount in
				 * responseshould be equal to or less than strategyMinimumAmount from request
				 */
				if (keysArr[i].equalsIgnoreCase("strategyminimumamount")) {

					/* converting expected and actual to double */
					double dblExpResult = Double.parseDouble(expectedResult);
					double dblActResult = Double.parseDouble(actualResult[j]);
					boolean result = false;
					if (dblActResult <= dblExpResult) {
						result = true;
					}

					Reporter.addStepLog("<b>Entity: </b>" + keysArr[i]);
					Reporter.addStepLog("<b>Expected: </b>Strategy Minimum Amount should be " + "less than or equal to "
							+ dblExpResult);
					Reporter.addStepLog("<b>Actual: </b>" + dblActResult);

					Assert.assertTrue(result);

				} else {

					Reporter.addStepLog("<b>Entity: </b>" + keysArr[i]);
					Reporter.addStepLog("<b>Expected: </b>" + expectedResult);
					Reporter.addStepLog("<b>Actual: </b>" + actualResult[j]);

					Assert.assertTrue(actualResult[j].contains(expectedResult));
				}
			}
			/* D-initializing */
			ignore = "no";
			exlObj.closeWorkBook();
		}
		values.clear();

	}

	@Then("^validate all the other linked attributes for (.+)$")
	public void validate_all_the_other_linked_attributes_for(String searchEntity) throws SQLException {

		/* entity = Child name and entityId = Child Id and referenceId = Parent Id */

		/*
		 * FOR PROGRAM, STYLE and MANAGER ENTITY Change for other entities, for PROGRAM,
		 * STYLE and MANAGER we are getting below entities in response
		 */
		if (searchEntity.equalsIgnoreCase("program") || searchEntity.equalsIgnoreCase("style")
				|| searchEntity.equalsIgnoreCase("manager")) {
			String[] id = response.jsonPath().getString("identifier").split(", ");

			for (int i = 0; i < id.length; i++) {

				String identifier = response.jsonPath().getString("identifier[" + i + "]");
				String[] commentId = response.jsonPath().getString("comments[" + i + "].identifier").split(", ");
				String[] documentId = response.jsonPath().getString("documents[" + i + "].identifier").split(", ");
//				String[] feeStructureId = response.jsonPath().getString("feeStructures[" + i + "].identifier")
//						.split(", ");

				/* Special Case for PROGRAM & MANAGER */
				if (searchEntity.equalsIgnoreCase("program") || searchEntity.equalsIgnoreCase("manager")) {
					String[] contactId = response.jsonPath().getString("contacts[" + i + "].identifier").split(", ");
					for (String n : contactId) {
						RestApiHelperMethods
								.verifyTrue(ValidateLinkedEntities("contact", RemoveSquareBrackets(n), identifier));
					}
				}

				/* Special Case for MANAGER */
				if (searchEntity.equalsIgnoreCase("manager")) {
					String[] registrationId = response.jsonPath().getString("registrations[" + i + "].identifier")
							.split(", ");
					for (String n : registrationId) {
						System.out.println("Registration Id: " + n);
						RestApiHelperMethods.verifyTrue(
								ValidateLinkedEntities("registration", RemoveSquareBrackets(n), identifier));
					}
				}

				/* Special Case for Style */
				if (searchEntity.equalsIgnoreCase("style")) {
					String[] benchmarkId = response.jsonPath().getString("benchmarks[" + i + "].identifier")
							.split(", ");
					for (String n : benchmarkId) {
						RestApiHelperMethods
								.verifyTrue(ValidateLinkedEntities("benchmark", RemoveSquareBrackets(n), identifier));
					}
				}

				for (String n : commentId) {
					RestApiHelperMethods
							.verifyTrue(ValidateLinkedEntities("comment", RemoveSquareBrackets(n), identifier));
				}

				for (String n : documentId) {
					RestApiHelperMethods
							.verifyTrue(ValidateLinkedEntities("document", RemoveSquareBrackets(n), identifier));
				}

//				for (String n : feeStructureId) {
//					RestApiHelperMethods.verifyTrue(ValidateLinkedEntities("fee", RemoveSquareBrackets(n), identifier));
//				}
			}
		}

		/* FOR FINANCIAL ADVISOR */
		else if (searchEntity.equalsIgnoreCase("financial advisor")) {
			Reporter.addStepLog("RESPONSE: " + response.asString());
			String[] id = response.jsonPath().getString("identifier").split(", ");

			for (int i = 0; i < id.length; i++) {

				String identifier = response.jsonPath().getString("identifier[" + i + "]");
				String[] commentId = response.jsonPath().getString("comments[" + i + "].identifier").split(", ");
				String[] contactId = response.jsonPath().getString("contacts[" + i + "].identifier").split(", ");
				Reporter.addStepLog("identifier: " + identifier + "</br> comment: " + commentId[i]);
				for (String n : contactId) {
					RestApiHelperMethods
							.verifyTrue(ValidateLinkedEntities("contact", RemoveSquareBrackets(n), identifier));
				}

				for (String n : commentId) {
					RestApiHelperMethods
							.verifyTrue(ValidateLinkedEntities("comment", RemoveSquareBrackets(n), identifier));
				}

//				for (String n : feeStructureId) {
//				RestApiHelperMethods.verifyTrue(ValidateLinkedEntities("fee", RemoveSquareBrackets(n), identifier));
//				}

			}
		}

		/* FOR STRATEGY */
		else if (searchEntity.equalsIgnoreCase("strategy")) {
			Reporter.addStepLog("<b>VALIDATING FOR STRATEGY</b>");

			String[] code = response.jsonPath().getString("code").split(", ");

			for (int i = 0; i < code.length; i++) {
				String sqlQ1 = "SELECT * FROM STRATEGY WHERE strategy_code='" + RemoveSquareBrackets(code[i]) + "';";
				String identifier = null;

				pmdb.DBConnectionStart();

				System.out.println("SQL Query: " + sqlQ1);
				ResultSet rs1 = DBManager.executeSelectQuery(sqlQ1);

				while (rs1.next()) {
					identifier = rs1.getString("strategy_id");
				}
				String[] commentId = null;
				String[] contactId = null;
				String[] benchmarkId = null;
				String[] documentId = null;

				pmdb.DBConnectionClose();

				try {
					commentId = response.jsonPath().getString("comments[" + i + "].identifier").split(", ");
					// Needs to be change, for now we are not getting identifier under contact-
					contactId = response.jsonPath().getString("contacts[" + i + "].contactReferenceList[0].contactId")
							.split(", ");
					benchmarkId = response.jsonPath().getString("benchmarks[" + i + "].identifier").split(", ");
					documentId = response.jsonPath().getString("documents[" + i + "].identifier").split(", ");

					for (String n : contactId) {
						System.out.println("i =" + i);
						RestApiHelperMethods
								.verifyTrue(ValidateLinkedEntities("contact", RemoveSquareBrackets(n), identifier));
					}

					for (String n : commentId) {
						RestApiHelperMethods
								.verifyTrue(ValidateLinkedEntities("comment", RemoveSquareBrackets(n), identifier));
					}

					for (String n : benchmarkId) {
						RestApiHelperMethods
								.verifyTrue(ValidateLinkedEntities("benchmark", RemoveSquareBrackets(n), identifier));
					}

					for (String n : documentId) {
						RestApiHelperMethods
								.verifyTrue(ValidateLinkedEntities("document", RemoveSquareBrackets(n), identifier));
					}
				} catch (Exception e) {
					Reporter.addStepLog("No Linked Entity Found in DB for strategy id " + identifier);
				}

			}

		}
	}

	@When("^create JSON file with (.+) and (.+) name as ESILSearch.json$")
	public void create_JSON_file_with_and_name_as_ESILSearch_json(String keys, String values) {
		String[] keysArr = keys.split(", ");
		String[] valuesArr = values.split(", ");
		String finalJsonString = "{ @ }";
		String iniJsonString = "";

		for (int n = 0; n < keysArr.length; n++) {

			// creating JSON
			iniJsonString = iniJsonString.concat("\"" + keysArr[n] + "\" : \"" + valuesArr[n] + "\"");
			if (n != keysArr.length - 1) {
				iniJsonString = iniJsonString.concat(",");
			}
		}

		/*
		 * Making [NULL] -> null [BLANK] -> "" [SPACE] -> " "
		 */
		iniJsonString = iniJsonString.replace("[BLANK]", "");
		iniJsonString = iniJsonString.replace("\"[NULL]\"", "null");
		iniJsonString = iniJsonString.replace("[SPACE]", " ");

		/* Maximum and Minimum */
		if (iniJsonString.contains("[MAXCHARS]")) {
			iniJsonString = iniJsonString.replace("[MAXCHARS]", randomStringAlphaNumeric(256));

		} else if (iniJsonString.contains("[MINCHARS]")) {
			iniJsonString = iniJsonString.replace("[MINCHARS]", randomStringAlphaNumeric(2));
		}

		/* final request JSON {String} */
		finalJsonString = finalJsonString.replace("@", iniJsonString);
		requestJson = finalJsonString;

	}

	@When("^replace reference type as (.+) and reference Id from (.+)$")
	public void replace_reference_type_as_and_reference_Id_from(String sheetName, String xlFileName) {

		xlFileName = "./src/test/resources/ad/productmaster/api/excel/" + xlFileName;

		ExcelUtil.setExcelFile(xlFileName, sheetName);

		List<String> identifier = ExcelUtil.getCellData("identifier");

		// removing extra ' [inverted comma] {0th element -> 1st row in excel}
		requestJson = requestJson.replace("$referenceId", identifier.get(0).replace("'", ""));
		requestJson = requestJson.replace("$referenceType", sheetName);

	}

	@When("^(.+) numbers of (.+) is created with unique \"([^\"]*)\" with response code \"([^\"]*)\"$")
	public void number_number_of_PROGRAM_is_created_with_unique(String count, String entityName, String toBeUnique,
			String responseCode) throws Throwable {

		int countInt = Integer.parseInt(count);
		String xlFileName = "Create" + entityName + ".xlsx";
		String requestJsonFileName = "Create" + entityName + ".json";

		for (int i = 0; i < countInt; i++) {
			/* Creating JSON */
			the_create_request_is_sent_with_and_unique_name_with_data_from("", requestJsonFileName, "Valid_HappyFlow",
					xlFileName);

			/* Making required attribute unique */
			replace_parameters(toBeUnique);

			// Replacing required attribute's values where it is required.
			if (entityName.toLowerCase().contains("benchmark") || entityName.toLowerCase().contains("style")) {
				replace_from_and_put_in("PROGRAM", "ReferenceDetails.xlsx", requestJsonFileName);
			} else if (entityName.toLowerCase().contains("strategy")) {
				replace_from_and_put_in("PROGRAM, STYLE, MANAGER", "ReferenceDetails.xlsx", requestJsonFileName);
			}

			/* sending request POST */
			sent_POST_request();

			/* status code validating */
			the_response_status_code_should_be_matching_with(responseCode);

			/* adding latest id's in list */
			if (entityName.toLowerCase().contains("benchmark")) {
				identifiers.add(response.jsonPath().getString("benchmarkId"));
			} else if (entityName.toLowerCase().contains("program")) {
				identifiers.add(response.jsonPath().getString("programId"));
			} else if (entityName.toLowerCase().contains("manager")) {
				identifiers.add(response.jsonPath().getString("managerId"));
			} else if (entityName.toLowerCase().contains("style")) {
				identifiers.add(response.jsonPath().getString("styleId"));
			}

		}
	}

	@Then("number of entities found should not be greater than {string}")
	public void number_of_entities_found_should_not_be_greater_than(String count) {

		/* changing string to integer */
		int maxCount = Integer.parseInt(count);
		int noOfElementsFound = 0;

		/* Fetching all the identifier's value. example: programId -> identifier */
		String numberOfIdentifiers = response.jsonPath().getString("identifier");
		String[] numberOfIdentifiersArr = numberOfIdentifiers.substring(1, numberOfIdentifiers.length() - 1)
				.split(", ");

		Reporter.addStepLog("<b>Number of response found: </b>" + numberOfIdentifiersArr.length);
		Reporter.addStepLog("<b>Max Records should be </b>" + maxCount);

		for (int i = 0; i < identifiers.size(); i++) {
			if (Arrays.asList(numberOfIdentifiersArr).contains(identifiers.get(i)) == true) {
				// Reporter.addStepLog(i+". FOUND ");
				noOfElementsFound++;
			} else {
				Reporter.addStepLog("<b style=\"color:red\">identifier - " + identifiers.get(i)
						+ " is not present in response.</b>");
			}

		}

		/* Report */
		Reporter.addStepLog("Total Number of entities created: " + identifiers.size());
		Reporter.addStepLog("Number of elements matched (w.r.t. no. of entities created): " + noOfElementsFound);
		Reporter.addStepLog("Number of elements not found (w.r.t. no. of entities created): "
				+ (identifiers.size() - noOfElementsFound));

		/* Validating max count should be 200 */
		Assert.assertEquals(numberOfIdentifiersArr.length, maxCount);

	}

	/* ************************* AUDIT ****************************** */

	@And("^read (.+) from response and store in variable$")
	public void read_entity_id_from_response_and_store_in_variable(String attribute) {
		String[] indvAttribute = attribute.split(", ");

		/*
		 * Need only one attribute here Example: contactId, contactDetails.detailId
		 */
		entityId = response.jsonPath().getString(indvAttribute[0]);
	}

	@And("^Validate the following attributes from API in Database for (.+) - (.+)$")
	public void validate_the_following_attributes_from_API_in_Database(String action, String entityName,
			List<String> toValidate) throws SQLException {

		String sqlQuery = "";

		if (action.equalsIgnoreCase("create")) {
			action = "CREATED";
		} else {
			action = "UPDATED";
		}

		for (String n : toValidate) {
			String createdBy = response.jsonPath().getString("createdBy");
			String createdOn = response.jsonPath().getString("createdOn");
			Long createdOnLong = Long.parseLong(createdOn);
			System.out.println("Sabse Upar: " + createdOnLong);

			/* Connecting to DB */
			pmdb.DBConnectionStart();

			/* SQL Query */
			sqlQuery = "SELECT * FROM application_audit WHERE entity_id = '" + entityId + "' and audit_type = '"
					+ action + "' and entity_name = '" + entityName + "'";
			System.out.println("SQL: " + sqlQuery);
			
			/* Result Set */
			ResultSet rs = DBManager.executeSelectQuery(sqlQuery);

			/* Validating Data */
			if (n.equalsIgnoreCase("Created By")) {

				while (rs.next()) {
					System.out.println("INSIDE WHILE: " + rs.toString());
					/* Fetching data from DB (Actual Value) */
					String createdByDB = rs.getString("created_by");

					/* Logging in report */
					Reporter.addStepLog("<b>(Expected) Created By in Response: </b>" + createdBy);
					Reporter.addStepLog("<b>(Actual) Entity ID in DB: </b>" + createdByDB);
					Reporter.addStepLog("_______________________________________________________________");

					/* Assertion */
					Assert.assertEquals(createdByDB, createdBy);
				}
			}

			else if (n.equalsIgnoreCase("Created On")) {
				Boolean dayLightSaving = true;
				while (rs.next()) {

					/* Uncomment(GST PART) if GST time is requited. and comment EST Part */

					Date dbCreatedOn = null;
//					String expGMT ="";
					String expEST = "";

					/*
					 * Date Format yyyy-MM-dd HH:mm (Needs to be changes according to requirement)
					 */
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");

					/*
					 * Fetching data from DB (Actual Value) and converting it to particular format
					 * here we are validating date upto seconds and not mili seconds. yyyy-MM-dd
					 * HH:mm (Needs to be changes according to requirement)
					 */
					dbCreatedOn = rs.getTimestamp("created_on");
					String strActDBCreatedON = df.format(dbCreatedOn);

					dayLightSaving = TimeZone.getTimeZone("EST").observesDaylightTime();

					/* Making changes according to day light saving */
					if (dayLightSaving.equals(false)) {
						System.out.println("INSIDE IF COND");
						createdOnLong = createdOnLong + 3600000;
						System.out.println("IF: " + createdOnLong);

					}

					/* Converting to Date */
					Date result = new Date(createdOnLong);

					/* Converting date to GMT and EST format */
//					TimeZone gmtTime = TimeZone.getTimeZone("GMT");
					TimeZone estTime = TimeZone.getTimeZone("EST");

//					df.setTimeZone(gmtTime);
//					expGMT = df.format(result).toString();

					df.setTimeZone(estTime);
					expEST = df.format(result).toString();

					/* Logging into Report */
//					Reporter.addStepLog("<b>Created On value in Response:</b> "+createdOnLong);
//					Reporter.addStepLog("<b>(Expected) Created On Value (Converted to GMT):</b> "+expGMT);
//					Reporter.addStepLog("<b>(Actual) Created On value in DB:</b> "+strActDBCreatedON);
//					Reporter.addStepLog("_______________________________________________________________");

					Reporter.addStepLog("<b>Created On value in Response:</b> " + createdOnLong);
					Reporter.addStepLog("<b>(Expected) Created On Value from API:</b> " + expEST);
					Reporter.addStepLog("<b>(Actual) Created On value in DB:</b> " + strActDBCreatedON);
					Reporter.addStepLog("_______________________________________________________________");

					/* Assertion */
//					Assert.assertEquals(strActDBCreatedON, expGMT);
					Assert.assertEquals(strActDBCreatedON, expEST);
				}
			}

			else if (n.contains("Reference (Entity Name)")) {
				while (rs.next()) {
					/* Fetching data from DB (Actual Value) */
					String entityNameDB = rs.getString("entity_name");

					/* Logging in report */
					Reporter.addStepLog("<b>(Expected) Entity Name in Response: </b>" + entityName);
					Reporter.addStepLog("<b>(Actual) Entity Name in DB: </b>" + entityNameDB);
					Reporter.addStepLog("_______________________________________________________________");

					/* Assertion */
					Assert.assertEquals(entityNameDB, entityName);
				}
			}

			else if (n.contains("Reference Id (Entity Id)")) {
				while (rs.next()) {
					/* Fetching data from DB (Actual Value) */
					String entityIdDB = rs.getString("entity_id");

					/* Logging in report */
					Reporter.addStepLog("<b>(Expected) Entity ID in Response:</b> " + entityId);
					Reporter.addStepLog("<b>(Actual) Entity ID in DB:</b> " + entityIdDB);
					Reporter.addStepLog("_______________________________________________________________");

					/* Assertion */
					Assert.assertEquals(entityIdDB, entityId);
				}
			}

			else if (n.contains("Audit Type - ")) {
				String[] expAuditType = n.split(" - ");

				while (rs.next()) {

					/* Fetching data from DB (Actual Value) */
					String auditTypeDB = rs.getString("audit_type");

					/* Logging in report */
					Reporter.addStepLog("<b>(Expected) Audit Type: </b>" + expAuditType[1]);
					Reporter.addStepLog("<b>(Actual) Audit Type for DB: </b>" + auditTypeDB);
					Reporter.addStepLog("_______________________________________________________________");

					/* Assertion */
					Assert.assertEquals(auditTypeDB, expAuditType[1]);
				}
			}
			/* Closing DB Connection */
			pmdb.DBConnectionClose();
		}
	}

	/* *********************** FUNCTIONS ********************************** */

	/**
	 * AlphaNumeric string of specific length generator
	 * 
	 * @author PatelNim
	 * @return random alpha-numeric string of length n
	 *
	 */
	public String randomStringAlphaNumeric(int n) {
		String randomString = RandomStringUtils.randomAlphanumeric(n);
		return randomString;
	}

	/**
	 * Function to write key and values received from response in Excel File.
	 * 
	 * @author PatelNim
	 */
	public void WriteKeyValueInExcel(String sheetName, int columnNumber, String keyName, String value)
			throws IOException {

		excelFilePath = "./src/test/resources/ad/productmaster/api/excel/ESILSearch.xlsx";

		/* Changing name of attributes according to the entity */

		/* FOR STYLE */
		if (sheetName.equalsIgnoreCase("style")) {
			if (keyName.equalsIgnoreCase("styleId")) {
				keyName = "identifier";
			} else if (keyName.equalsIgnoreCase("styleCode")) {
				keyName = "code";
			} else if (keyName.equalsIgnoreCase("styleName")) {
				keyName = "name";
			} else if (keyName.equalsIgnoreCase("styleCategory")) {
				keyName = "category";
			} else if (keyName.equalsIgnoreCase("marketCap")) {
				keyName = "marketCapitalization";
			} else if (keyName.equalsIgnoreCase("minimumAmount")) {
				keyName = "minimumInvestmentAmount";
			}
		}

		/* FOR PROGRAM */
		else if (sheetName.equalsIgnoreCase("program")) {
			if (keyName.equalsIgnoreCase("programId")) {
				keyName = "identifier";
			} else if (keyName.equalsIgnoreCase("programCode")) {
				keyName = "code";
			} else if (keyName.equalsIgnoreCase("programName")) {
				keyName = "name";
			}
		}

		/* FOR BENCHMARK */
		else if (sheetName.equalsIgnoreCase("benchmark")) {
			if (keyName.equalsIgnoreCase("benchmarkId")) {
				keyName = "identifier";
			} else if (keyName.equalsIgnoreCase("benchmarkCode")) {
				keyName = "code";
			} else if (keyName.equalsIgnoreCase("benchmarkName")) {
				keyName = "name";
			} else if (keyName.toLowerCase().equalsIgnoreCase("benchmarkType")) {
				keyName = "type";
			} else if (keyName.toLowerCase().equalsIgnoreCase("benchmarkdescription")) {
				keyName = "description";
			}
		}

		/* FOR MANAGER */
		else if (sheetName.equalsIgnoreCase("manager")) {
			if (keyName.equalsIgnoreCase("managerId")) {
				keyName = "identifier";
			} else if (keyName.equalsIgnoreCase("managerCode")) {
				keyName = "code";
			}
		}

		/* FOR FINANCIAL ADVISOR */
		else if (sheetName.equalsIgnoreCase("financial advisor")) {
			if (keyName.equalsIgnoreCase("faCode")) {
				keyName = "code";
			} else if (keyName.equalsIgnoreCase("faCode2")) {
				keyName = "code2";
			} else if (keyName.equalsIgnoreCase("branchCode")) {
				keyName = "branchNumber";
			} else if (keyName.equalsIgnoreCase("faid")) {
				keyName = "identifier";
			}
		}

		/* FOR STRATEGY */
		else if (sheetName.equalsIgnoreCase("strategy")) {
			if (keyName.equalsIgnoreCase("strategyCode")) {
				keyName = "code";
			} else if (keyName.equalsIgnoreCase("marketCap")) {
				keyName = "marketCapitalization";
			} else if (keyName.equalsIgnoreCase("strategyName")) {
				keyName = "investmentStrategyName";
			} else if (keyName.equalsIgnoreCase("status")) {
				keyName = "investmentStrategyStatus";
			} else if (keyName.equalsIgnoreCase("strategyId")) {
				keyName = "identifier";
			} else if (keyName.equalsIgnoreCase("strategyminimum")) {
				keyName = "strategyMinimumAmount";
			}
		}

		/* Creating object of Excel */
		ExcelUtils exl1 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);

		/* Getting sheet */
		XSSFSheet sheet = exl1.getSheet(sheetName);

		/* Operations */
		exl1.setCellData(sheet, 0, columnNumber, keyName);
		exl1.setCellData(sheet, 1, columnNumber, value);

		/* Closing excel file */
		exl1.closeWorkBook();
	}

	/**
	 * @author PatelNim Function to return sheet name according to entity. suppose,
	 *         entity is "program", it will return "PROGRAM"
	 * @return sheet name according to entity name
	 */
	public String ReturnSheetName(String entity) {

		String exlSheetName = null;

		/*
		 * Special case for programname, managercode1, investmentstyle (FOR EISL
		 * STRATEGY SEARCH)
		 */
		if (entity.toLowerCase().contains("program") || entity.toLowerCase().contains("programname")) {
			exlSheetName = "PROGRAM";
		} else if (entity.toLowerCase().contains("manager") || entity.toLowerCase().contains("managercode1")) {
			exlSheetName = "MANAGER";
		} else if (entity.toLowerCase().contains("benchmark")) {
			exlSheetName = "BENCHMARK";
		} else if (entity.toLowerCase().contains("feestructure")) {
			exlSheetName = "FEESTRUCTURE";
		} else if (entity.toLowerCase().contains("style") || entity.toLowerCase().contains("investmentstyle")) {
			exlSheetName = "STYLE";
		} else if (entity.toLowerCase().contains("comment")) {
			exlSheetName = "COMMENT";
		} else if (entity.toLowerCase().contains("document")) {
			exlSheetName = "DOCUMENT";
		} else if (entity.toLowerCase().contains("strategy")) {
			exlSheetName = "STRATEGY";
		} else if (entity.toLowerCase().contains("contact")) {
			exlSheetName = "CONTACT";
		} else if (entity.toLowerCase().contains("registration")) {
			exlSheetName = "REGISTRATION";
		} else if (entity.toLowerCase().contains("fa")) {
			exlSheetName = "FINANCIAL ADVISOR";
		}

		System.out.println("SHEET NAME: " + exlSheetName);

		return exlSheetName;
	}

	/**
	 * @author PatelNim Removing entity name
	 * @return string without entity name
	 */
	public String RemoveEntityNameFromString(String key) {
		if (key.contains("program.")) {
			key = key.replace("program.", "");
		} else if (key.contains("benchmark.")) {
			key = key.replace("benchmark.", "");
		} else if (key.contains("manager.")) {
			key = key.replace("manager.", "");
		} else if (key.contains("style.")) {
			key = key.replace("style.", "");
		} else if (key.contains("strategy.")) {
			key = key.replace("strategy.", "");
		} else if (key.contains("fa.")) {
			key = key.replace("fa.", "");
		} else {

		}

		/* Removing "part.", if present */
		if (key.contains("part.")) {
			key = key.replace("part.", "");
		}
		return key;
	}

	/**
	 * Function to validate linked entities in DataBase
	 * 
	 * @author PatelNim
	 * @param entity
	 * @param entityId
	 * @param referenceId
	 * @return flag
	 * @throws SQLException
	 */
	public Boolean ValidateLinkedEntities(String entity, String entityId, String referenceId) throws SQLException {

		String dbTable = null;
		String dbEntityName = null;
		Boolean flag = false;

		if (entityId.length() > 0) {

			/* Establishing connection to DataBase */
			pmdb.DBConnectionStart();

			if (entity.toLowerCase().contains("comment")) {
				dbTable = "comment";
				dbEntityName = "comment_id";
			} else if (entity.toLowerCase().contains("document")) {
				dbTable = "document_link_assoc";
				dbEntityName = "document_id";
			} else if (entity.toLowerCase().contains("contact")) {
				dbTable = "contact_assoc";
				dbEntityName = "contact_id";
			} else if (entity.toLowerCase().contains("fee")) {
				dbTable = "fee_structure_assoc";
				dbEntityName = "fee_structure_id";
			} else if (entity.toLowerCase().contains("benchmark")) {
				dbTable = "benchmark_assoc";
				dbEntityName = "benchmark_id";
			} else if (entity.toLowerCase().contains("registration")) {
				dbTable = "registration";
				dbEntityName = "registration_id";
			}

			/* referenceId = Parent Id and entityId = Child Id */
			String sqlQuery = "SELECT * FROM " + dbTable + " WHERE reference_id = '" + referenceId + "' AND "
					+ dbEntityName + " = '" + entityId + "';";

			System.out.println("QUERY: " + sqlQuery);

			/* returns true if data is found, else false */
			flag = DBManager.executeSelectQuery(sqlQuery).next();

			/* logging into reports */
			Reporter.addStepLog(dbEntityName + " - " + entityId + " is linked with entity Id- " + referenceId);

			/* closing connection */
			pmdb.DBConnectionClose();

		}
		/* if nothing to check, Assertion should be true. */
		else {
			flag = true;
		}
		return flag;
	}

	/**
	 * Function to remove square brackets
	 * 
	 * @author PatelNim
	 * @param str
	 * @return String without brackets[]
	 */
	public String RemoveSquareBrackets(String str) {

		str = str.replace("[", "");
		str = str.replace("]", "");

		return str;

	}

	/**
	 * Converting Numeric string to numeric value in request JSON Example: "12345"
	 * -> 12345
	 * 
	 * @author PatelNim
	 * @param requestJson
	 */
	public String ConvertStringInJsonToNumeric(String requestJson) {
		List<String> allMatches = new ArrayList<String>();
		Matcher numericValue = Pattern.compile("\"[0-9]+(\\.\\d+)?\"").matcher(requestJson);
		while (numericValue.find()) {
			allMatches.add(numericValue.group());
		}
int allMatchesInt = allMatches.size();
		for (int count = 0; count < allMatchesInt ; count++) {
			//Reporter.addStepLog("Removing from: " + allMatches.get(count).toString());
			requestJson = requestJson.replace(allMatches.get(count),
					allMatches.get(count).substring(1, allMatches.get(count).toString().length() - 1));
		}
		allMatches.clear();
		return requestJson;
	}

	/*
	 * SSO Login For APIs and setting cookies in Rest Call.
	 */
	public void SSOAuthentication(String webUIUrl, String username, String password) {
		
		SSOLoginPage loginPage = new SSOLoginPage();

		Set<Cookie> cookieSet = loginPage.loginForAPI(webUIUrl, username, password);

		/* Setting cookies in Rest Call */
		RestApiUtils.setCookies(cookieSet);

	}

}