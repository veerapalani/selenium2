package qa.unicorn.ad.productmaster.api.stepdefs;

import static org.testng.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hp.lft.sdk.internal.common.MessageFieldNames.Report;
import com.mysql.cj.jdbc.result.ResultSetFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import fj.data.Iteratee.Input;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.Reporter;

public class UPM_11018 {
	File file;
	String filePath = "./src/test/resources/ad/productmaster/api/DataLoadFiles/";
	List<String[]> fileData = new ArrayList<String[]>();
	int countInFile = 0;
	int notMatched = 0;
	List<String> notMatchedCodesAct = new ArrayList<String>();
	List<String> notMatchedCodesExp = new ArrayList<String>();

	@Given("^user has file with foa code and alternative code - (.+)$")
	public void user_has_file_with_foa_code_and_alternative_code_(String filename) throws Throwable {
		
		filePath = filePath + filename;
		System.out.println(filePath);
		file = new File(filePath);

		if (!file.exists()) {
			Reporter.addStepLog("FILE NOT FOUND at: " + filePath);
			assertTrue(false, "FILE NOT FOUND!!");
		} else
			Reporter.addStepLog("<b>File found at </b>" + filePath);
	}

	@When("^user opens the file and read the data$")
	public void user_opens_the_file_and_read_the_data() throws Throwable {
		fileData = CSVFileUtils.getInstance().readAllCommaSeparatedValues(filePath);

		if (fileData.isEmpty()) {
			assertTrue(false, "No Data found in file");
		} else
			Reporter.addStepLog("<b>Data found in file.</b>");
	}

	@Then("^user is able to match codes from file with DB$")
	public void user_is_able_to_match_codes_from_file_with_db() throws Throwable {
		BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
		String input;
		// int count = 1;
		int size = 0;

		/* Reading header outside loop, as it is not required while fetching data */
		input = bufferedReader.readLine();
		

		ProductMasterDBManager pmdb = new ProductMasterDBManager();

		pmdb.DBConnectionStart();
		
		

		Reporter.addStepLog("<table border=1px solid><tr>\r\n" 
				+ "    <th>strategy_code in DB</th>\r\n"
				+ "    <th>alternative_strategy_code in DB</th>\r\n" 
				+ "    <th>strategy_code in file</th>\r\n"
				+ "    <th>alternative_strategy_code in file</th>\r\n" 
				+ "    <th>Matched?</th>\r\n" + "    </tr>");

		while ((input = bufferedReader.readLine()) != null) {
			String expCode1 = CSVFileUtils.getInstance().getValue(fileData, (countInFile + 1), 4);
			String expCode2 = CSVFileUtils.getInstance().getValue(fileData, (countInFile + 1), 5);
			String sqlQuery = "select strategy_code, alternative_strategy_code from tdr7.strategy where strategy_code = '"+expCode1+"'";
			

			ResultSet rs = DBManager.executeSelectQuery(sqlQuery);

			while (rs.next()) {
				String actCode1 = rs.getString("strategy_code");
				String actCode2 = rs.getString("alternative_strategy_code");

				/* logging into report(data table) */
				Reporter.addStepLog("<td>" + actCode1 + "</td>\r\n" + "    <td>" + actCode2 + "	   </td>\r\n"
						+ "    <td>" + expCode1 + "    </td>\r\n" + "    <td>" + expCode2 + "	   </td>\r\n");

				/* If name, status and client is as expected then marking it as "MATCHED" */
				if (expCode1.equals(actCode1) && expCode2.equals(actCode2)) {
					Reporter.addStepLog("<td style = 'color:green'>MATCHED</td>\r\n" + "  </tr>");
				} else {
					Reporter.addStepLog("<td style = 'color:red'>NOT MATCHED</td>\r\n" + "  </tr>");
					notMatched++;
					actCode1=actCode1+"";
					actCode2=actCode2+"";
					notMatchedCodesAct.add(actCode1+","+actCode2);
					notMatchedCodesExp.add(expCode1+","+expCode2);
				}
			}
			countInFile++;
			if(countInFile%100 == 0) {
				System.out.println("Working on line - "+countInFile);
			}
		}

		Reporter.addStepLog("</table></br>");
		pmdb.DBConnectionClose();
	}
	
	@And("^user is able to see final report$")
    public void user_is_able_to_see_final_report() throws Throwable {
        Reporter.addStepLog("<b>Total Records in File: </b>"+countInFile);
        Reporter.addStepLog("<b>No. of records matched: </b><nim style = 'color:green'>"+(countInFile-notMatched)+"</nim>");
        Reporter.addStepLog("<b>No. of Records mismatched: </b><nim style = 'color:red'>"+notMatched+"</nim>");
        Reporter.addStepLog("");
        Reporter.addStepLog("<b>Below strategy codes mismatched:</b>");
        Reporter.addStepLog("format of expected and actual - \"(strategy_code, altervative_strategy_code)\"");
        Reporter.addStepLog("");
        Reporter.addStepLog("<table border=1px solid><tr>\r\n" 
				+ "    <th>Expected (from File)</th>\r\n"
				+ "    <th>Actual (from DB)</th></tr>" 
				);
        for(int i = 0; i<notMatchedCodesAct.size();i++) {
        	
        	Reporter.addStepLog("<tr><td>" + notMatchedCodesExp.get(i).toString() + "</td>\r\n" + "    <td>" + notMatchedCodesAct.get(i).toString() + "	   </td></tr>");
        	
        }
        Reporter.addStepLog("</table></br>");
    }
}
