package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;
import org.junit.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

public class IntegrationGeneric {
public static String dateInString;
public static Date dateInDatabase,dateInUI;
public static LinkedHashMap<String, String>  UIPassedValues = new LinkedHashMap<String, String> ();
Object APIValue,UIValue;

@Given("^the database is connected$")
public void the_database_is_connected() throws Throwable {
	DBManager.openPostgreDBConnection("prodmaster.cwhuea5dgpmk.us-east-1.rds.amazonaws.com", "5432", "maindb", "pmread", "pmread");
}

@When("^the \"([^\"]*)\" of the \"([^\"]*)\" with the same \"([^\"]*)\" is retrieved$")
public void the_something_of_the_something_with_the_same_something_is_retrieved(String attributeName, String tableName, String attributeForUniqueness) throws Throwable {
    dateInString = getAttributeValueFromDB(attributeName, tableName, attributeForUniqueness);
    dateInString = dateInString.substring(0,dateInString.length()-4);
}

@And("^convert from \"([^\"]*)\" format to date from \"([^\"]*)\" and store it$")
public void convert_from_something_format_to_date_from_something_and_store_it(String format, String storingVariable) throws ParseException  {
    switch (storingVariable) {
	case "Database":
		dateInDatabase = convertStringToDate(dateInString, format);
		break;
	case "UI":
		dateInUI = convertStringToDate(dateInString, format);
		break;
	default:
		break;
	}
}

@And("^compare the dates from UI and Database$")
public void compare_the_dates_from_ui_and_database() {
	//converting est to gmt
    dateInUI = DateUtils.addHours(dateInUI, 4);
    Assert.assertTrue(dateInDatabase.compareTo(dateInUI) == 0);
}
public Date convertStringToDate(String dateInString,String format) throws ParseException {
	 Date date=new SimpleDateFormat(format).parse(dateInString);  
	 return date;
	 
}
public String getAttributeValueFromDB(String attributeName, String tableName,String attributeForUniqueness) throws SQLException {
		
		
		String query = "Select "+attributeName+" from "+tableName+"where "+attributeForUniqueness+"='"+ProductMasterGeneric.duplicateCode+"'";
		ResultSet resultSet = DBManager.executeSelectQuery(query);
		ResultSetMetaData metaData = resultSet.getMetaData();
//		int colCount1 = metaData.getColumnCount();
		String value = resultSet.getString(1);
		
		DBManager.closeConnection();
		return value;
		
	}
@And("^compare the following \"([^\"]*)\" attribute's values in API with the values in UI$")
public void compare_the_following_something_attributes_values_in_ui_with_the_values_in_api(String attributeType,List<List<String>> APIUIAttributePair) throws Throwable {
	
		
		 if(attributeType.equalsIgnoreCase("String"))
		 {for(int i=0;i<APIUIAttributePair.size();i++) {
			 APIValue = ProductMasterGeneric.response.jsonPath().getList(APIUIAttributePair.get(i).get(0)).get(0);
			 UIValue=UIPassedValues.get(APIUIAttributePair.get(i).get(1));
			 Assert.assertEquals( APIValue,UIValue);
			 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+UIValue);
			 
		 }
		 }
		 else if(attributeType.equalsIgnoreCase("Numeric")) {
			 for(int i=0;i<APIUIAttributePair.size();i++) {
			 APIValue = (ProductMasterGeneric.response.jsonPath().getList(APIUIAttributePair.get(i).get(0)).get(0));
			 UIValue=Float.parseFloat(UIPassedValues.get(APIUIAttributePair.get(i).get(1))); 
			 Assert.assertEquals( APIValue,UIValue);
			 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+UIValue);
			 }
		 }
		 else if(attributeType.equalsIgnoreCase("Boolean")) {
			 for(int i=0;i<APIUIAttributePair.size();i++) {
			 APIValue = ProductMasterGeneric.response.jsonPath().getList(APIUIAttributePair.get(i).get(0)).get(0);
			 UIValue=Boolean.parseBoolean(UIPassedValues.get(APIUIAttributePair.get(i).get(1))); 
			 Assert.assertEquals( APIValue,UIValue);
			 Reporter.addStepLog("verified that the value of "+APIUIAttributePair.get(i).get(1)+" is "+UIValue); 
			 }
		 }
		 else
		 {
			 Reporter.addStepLog("Wrong attributeType");
			 Assert.assertTrue(false);
		 }
	 
}

}
