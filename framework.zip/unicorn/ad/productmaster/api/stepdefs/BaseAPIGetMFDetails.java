package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.asserts.SoftAssert;

import com.google.common.util.concurrent.Service;
import com.ibm.db2.cmx.runtime.internal.repository.util.ExpandableIntArray;
import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;

import cucumber.api.java.en.And;
import io.restassured.response.Response;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.RelationalDBType;
import qa.framework.utils.Reporter;

@SuppressWarnings("deprecation")
public class BaseAPIGetMFDetails {

	// Response response = null;
	JSONObject requestJson = null;
	JSONParser parser = new JSONParser();
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	ProductMasterGeneric pmg = new ProductMasterGeneric();
	SoftAssert sa = new SoftAssert();

	Map<String, String> BenchmarkAttributesAndDBColumns = new HashMap<String, String>();

	@And("^validate the counts in response with DB for \"([^\"]*)\"$")
	public void validate_the_counts_in_response_with_DB_for(String attribute) throws ParseException, SQLException {

		int countFromDB = 0, countFromAPI = 0;

		/* will check counts only if response code = 200 */
		if (EISLBaseAPIGeneric.response.getStatusCode() == 200) {
			/* getting request JSON from generic class */
			requestJson = (JSONObject) parser.parse(EISLBaseAPIGeneric.requestJson);

			/* getting counts from API response */
			String[] cusipsFromAPI = EISLBaseAPIGeneric.response.body().jsonPath().getString("cusip").split(",");
			countFromAPI = cusipsFromAPI.length;

			String sqlQuery = GetSQL(requestJson);

			/* searchmfapi is returning result also for MFs not linked with program */
			if (EISLBaseAPIGeneric.serviceName.equalsIgnoreCase("searchmfapi")) {
				sqlQuery = sqlQuery.replace("join program", "left join program");
			}

			pmdb.DBConnectionStart();

			ResultSet rs = DBManager.executeSelectQuery(sqlQuery);

			while (rs.next()) {
				countFromDB = rs.getInt("count");
			}

			Reporter.addStepLog("<b>Counts from DB: </b>" + countFromDB);
			Reporter.addStepLog("<b>Counts from API: </b>" + countFromAPI);

			ArrayList<String> cusipFromDB = new ArrayList<String>();
			ArrayList<String> cusipAPI = new ArrayList<String>();

			/* if counts are not equal, identifying mismatched Broadridge ADP Ids */
			// if (countFromAPI != countFromDB) {

			// List<String> cusipFromAPI = new ArrayList<String>();

			List<String> misMatchedCusips = new ArrayList<String>();

			sqlQuery = GetSQL(requestJson).replace("count(distinct(mf.mf_id))", "distinct(mf.cusip)");
			System.out.println(sqlQuery);
			ResultSet cusip = DBManager.executeSelectQuery(sqlQuery);

			/* getting IDs from DB (Expected) */
			while (cusip.next()) {
				cusipFromDB.add(cusip.getString("cusip"));
			}

			/* checking if cusip from API is available in expected list(from DB) */

			/* available in API not in DB */
			for (String cusip_one : cusipsFromAPI) {
				cusipAPI.add(removeBracketsAndInvertedCommas(cusip_one + "").trim());
				if (!cusipFromDB.contains(removeBracketsAndInvertedCommas(cusip_one + "").trim())) {
					misMatchedCusips.add(removeBracketsAndInvertedCommas(cusip_one + "").trim());
				}
			}

			/* available in DB not in API */
			for (String cusip_one : cusipFromDB) {
				if (!cusipAPI.contains(removeBracketsAndInvertedCommas(cusip_one + "").trim())) {
					misMatchedCusips.add(removeBracketsAndInvertedCommas(cusip_one + "").trim());
				}
			}

			ebag.setCollapsibleHtml("Expected Cusips", cusipFromDB.toString());
			ebag.setCollapsibleHtml("Actual Cusips", cusipAPI.toString());
			ebag.setCollapsibleHtml("Mismatched Cusips:", misMatchedCusips.toString());
			// Reporter.addStepLog("Number of mismatched: "+misMatchedCusips.size());

			/* clearing list for next iteration */
			cusipFromDB.clear();
			cusipAPI.clear();
			pmdb.DBConnectionClose();
			misMatchedCusips.clear();
		}

		Assert.assertEquals("Count Mismatched", countFromDB, countFromAPI);

	}

	@And("^fundFamilyName in response should start with name from request i.e. \"([^\"]*)\"$")
	public void fundFamilyName_In_response_should_contains_name_from_request(String fundFamilyNameReq) {
		String[] fundFamilyNamesRes = EISLBaseAPIGeneric.response.jsonPath().getString("fundFamilyName").split(",");
		String[] broadridgeAdpIdsRes = EISLBaseAPIGeneric.response.jsonPath().getString("adpSecurityNumber").split(",");

		/* Setting table headers */
		ebag.SetAndPrintTableHeaders(
				"adpSecurityNo|fundFamilyName (from response) | fundFamilyName (from req) | Result");

		for (int i = 0; i < fundFamilyNamesRes.length; i++) {

			String fundFamilyNameRes = pmg.RemoveSquareBrackets(fundFamilyNamesRes[i]).trim();
			String broadridgeAdpIdRes = pmg.RemoveSquareBrackets(broadridgeAdpIdsRes[i]).trim();
			Boolean flag = true;
			if (!fundFamilyNameRes.toLowerCase().contains(fundFamilyNameReq.toLowerCase())) {
				sa.assertEquals(true, false,
						"fund family name mismatched for adpSecurityNumber: " + broadridgeAdpIdRes);
				flag = false;
			}
			ebag.SetAndPrintTableRows(
					broadridgeAdpIdRes + "|" + fundFamilyNameRes + "|" + fundFamilyNameReq + "|" + flag);
		}
		ebag.SetAndPrintTableFooter();
		sa.assertAll();

	}

	String benchmarkType = null, adpSecurityNumber = null;

	@And("^user creates request JSON for MF linked with \"([^\"]*)\"$")
	public void user_creates_request_JSON_for_MF_linked_with(String benchmarkType) throws Throwable {
		this.benchmarkType = benchmarkType;

		String sql = "select broadridge_adp_id, random() from mutual_funds mf, benchmark_assoc ba where mf.selected_benchmark_type = \r\n"
				+ "(select list_id from list_values where list_type = 'BENCHMARK CATEGORY' and list_value = '"
				+ benchmarkType + "') "
				+ " and ba.benchmark_category in (select list_id from list_values where list_type = 'BENCHMARK CATEGORY' and list_value = '" + benchmarkType + "') "
				+ " and ((mf.mf_id = ba.reference_id and ba.reference_type = 'MF' ) or (mf.style_id = ba.reference_id and ba.reference_type = 'STYLE')) "
				+ "and ba.effective_to_date is null and mf.advisory_status in (select list_id from list_values where list_value = 'Active')  and mf.client_id = 1 order by random() limit 1";
		System.out.println("$$$$$ " + sql);
		pmdb.DBConnectionStart();
		ResultSet rs = DBManager.executeSelectQuery(sql);

		while (rs.next()) {
			adpSecurityNumber = rs.getString("broadridge_adp_id");
		}

		pmdb.DBConnectionClose();

		try {
			ebag.user_creates_a_request_json_file_with_search_keys_and_values("adpSecurityNumber", adpSecurityNumber);
		} catch (Exception e) {
			// when we don't have any benchmark available in DB.
			ebag.user_creates_a_request_json_file_with_search_keys_and_values("adpSecurityNumber",
					"NO_BENCHMARK_PRESENT");
		}
	}

	@And("^benchmark data in response should match with data present in DB$")
	public void benchmark_data_in_response_should_match_with_data_present_in_DB() throws SQLException {

		if (EISLBaseAPIGeneric.response.getStatusCode() == 200) {

			/* getting total number of parent objects (number of MFs in response) */
			String[] adpIds = EISLBaseAPIGeneric.response.jsonPath().getString("adpSecurityNumber").split(",");

			String apiAttribute = null;

			if (benchmarkType.equals("Default")) {
				apiAttribute = "defaultBenchmarkInfo";
			} else if (benchmarkType.equals("Custom")) {
				apiAttribute = "customBenchmarkInfo";
			} else if (benchmarkType.equals("Primary Prospectus")) {
				apiAttribute = "primaryProspectusBenchmark";
			} else if (benchmarkType.equals("Secondary Prospectus")) {
				apiAttribute = "secondaryProspectusBenchmark";
			} else {
				Assert.assertTrue("Invalid benchmark type in request.", false);
			}

			/* mutual funds */
			for (int i = 0; i < adpIds.length; i++) {

				/* getting number of benchmarks for a particular MF */
				String[] benchmarkIds = EISLBaseAPIGeneric.response.jsonPath()
						.getString(apiAttribute + "[" + i + "].identifier").split(",");
				String receivedBenchmark = EISLBaseAPIGeneric.response.jsonPath()
						.getString(apiAttribute + "[" + i + "]");

				System.out.println("*** " + receivedBenchmark);

				String sqlCount = "select count(ba.benchmark_id) from benchmark_assoc ba, mutual_funds mf where"
						+ " and mf.client_id = 1 and ba.reference_id = mf.$refId and ba.reference_type = '$refType' and ba.effective_to_date is null and"
						+ " mf.broadridge_adp_id = '" + pmg.RemoveSquareBrackets(adpIds[i]).trim()
						+ "' and ba.benchmark_category in "
						+ "(select list_id from list_values where list_type = 'BENCHMARK CATEGORY' and list_value = '"
						+ benchmarkType + "') ";

				if (!benchmarkType.equals("Default")) {
					sqlCount = sqlCount.replace("$refId", "mf_id").replace("$refType", "MF");
				} else
					sqlCount = sqlCount.replace("$refId", "style_id").replace("$refType", "STYLE");

				System.out.println("COUNTSSSSSS: " + sqlCount);
				int expCount = ebag.compareCounts(sqlCount, "");

				Reporter.addStepLog("<b>Expected Number of linked benchmarks:</b> " + expCount);
				Reporter.addStepLog("<b>Actual Number of linked benchmarks:</b> " + benchmarkIds.length);

				sa.assertEquals(benchmarkIds.length, expCount, "Benchmark Counts mismatched, refer reports.");

				/* benchmarks */
				if (receivedBenchmark.length() > 10) {
					for (int j = 0; j < benchmarkIds.length; j++) {
						String benchmarkId = pmg.RemoveSquareBrackets(benchmarkIds[j]);

						String sqlQuery = "select distinct b.created_on, b.last_update_on, ba.effective_from_date, b.created_by, b.last_update_by, ba.benchmark_id, c.client_name, c.client_code,\r\n"
								+ "b.client_id, b.benchmark_code,\r\n"
								+ " (select list_value from list_values where list_id = b.benchmark_classification) as benchmark_classification, \r\n"
								+ " (select list_value from list_values where list_id = b.benchmark_type) as benchmark_type, b.benchmark_name, b.benchmark_description, ba.percentage, \r\n"
								+ " (select list_value from list_values where list_id = b.status) as status, \r\n"
								+ " (select list_value from list_values where list_id = ba.benchmark_category) as benchmark_category, b.data_source from benchmark b\r\n"
								+ " inner join benchmark_assoc ba on ba.benchmark_id = b.benchmark_id\r\n"
								+ " inner join mutual_funds mf on $id = ba.reference_id and ba.reference_type = '$ref'\r\n"
								+ " inner join client c on c.client_id = b.client_id\r\n" + "where ba.benchmark_id ="
								+ benchmarkId + " and mf.broadridge_adp_id = '" + pmg.RemoveSquareBrackets(adpIds[i])
								+ "' \r\n"
								+ " and ba.benchmark_category = (select list_id from list_values where list_value = '"
								+ benchmarkType + "') and b.client_id = 1 and mf.client_id = 1 ";

						if (!benchmarkType.equals("Default")) {
							sqlQuery = sqlQuery.replace("$id", "mf.mf_id");
							sqlQuery = sqlQuery.replace("$ref", "MF");

						} else {

							sqlQuery = sqlQuery.replace("$id", "mf.style_id");
							sqlQuery = sqlQuery.replace("$ref", "STYLE");
						}

						ebag.setCollapsibleHtml("SQL Query", sqlQuery);

						/* Setting up mapping */
						SetBenchmarkMapping(apiAttribute);
						ebag.SetAndPrintTableHeaders("Attribute|Expected|Actual|Result");
						pmdb.DBConnectionStart();

						ResultSet rs = null;
						System.out.println(sqlQuery);

						for (Map.Entry<String, String> set : BenchmarkAttributesAndDBColumns.entrySet()) {
							String apiAttributeName = set.getKey();

							/* replacing parent and child count */
							apiAttributeName = apiAttributeName.replace("[i]", "[" + i + "]").replace("[j]",
									"[" + j + "]");

							String columnName = set.getValue();

							/* fetching from API */
							String apiValue = EISLBaseAPIGeneric.response.body().jsonPath().getString(apiAttributeName)
									+ "";
							String dbValue = null;

							rs = DBManager.executeSelectQuery(sqlQuery);
							while (rs.next()) {
								/* fetching from DB */
								dbValue = rs.getString(columnName) + "";

								if ((columnName.contains("created_on") || columnName.contains("last_update_on"))
										&& !dbValue.equalsIgnoreCase("null")) {
									dbValue = ebag.convertDateToExpectedFormat(dbValue, "");
								}

								if ((columnName.contains("effective_from_date") && !dbValue.equalsIgnoreCase("null"))) {
									dbValue = ebag.convertDateToExpectedFormat(dbValue, "").substring(0, 10);
								}

								if ((columnName.contains("percentage") && !dbValue.equalsIgnoreCase("null"))) {
									int index = dbValue.indexOf('.');
									if (index >= 0) {
										dbValue = dbValue.substring(0, index + 2);
									}
								}

								Boolean flag = true;

								if (!nullAndBlank(apiValue).equals(nullAndBlank(dbValue))) {
									flag = false;
								}

								ebag.SetAndPrintTableRows(
										apiAttributeName + "|" + dbValue + "|" + apiValue + "|" + flag);
								sa.assertEquals(nullAndBlank(apiValue), nullAndBlank(dbValue), "Value Mismatch for " + apiAttributeName + ".");
							}
						}
						ebag.SetAndPrintTableFooter();
						pmdb.DBConnectionClose();
						BenchmarkAttributesAndDBColumns.clear();

					}
				} else {
					Reporter.addStepLog("Expected " + benchmarkType + " but found null.");
					sa.assertTrue(false, "Expected " + benchmarkType + " but found null.");
				}
			}

			sa.assertAll();
		} else {
			// If no benchmark present i.e. status code is 404
			Reporter.addStepLog("<b>No " + benchmarkType + " is available in DB.</b>");
		}

	}

	/**
	 * Function to return SQL for counts for getmfdetails API according to request
	 * parameters
	 * 
	 * @type JSONObject
	 * @return sql
	 */
	public String GetSQL(JSONObject requestJson) {
		String sql = "select count(distinct(mf.mf_id)) from mutual_funds mf\r\n"
				+ "join program_eligibility pe on pe.reference_type = 'MF' and pe.reference_id = mf.mf_id \r\n"
				+ "join program p on p.program_id = pe.program_id \r\n"
				+ "left join node_id_rollup nir on nir.reference_id = mf.mf_id and nir.reference_type = 'MF' \r\n"
				+ "where  mf.mf_id = mf.mf_id and mf.client_id = 1 and p.client_id = 1 ";

		String additionalQuery = "";

		if (requestJson.containsKey("fundCat")) {
			additionalQuery = additionalQuery + " and mf.fund_category = '"
					+ requestJson.get("fundCat").toString().replace("[\"", "").replace("\"]", "") + "'";
		}

		if (requestJson.containsKey("minimumYield")) {
			additionalQuery = additionalQuery + " and mf.yield >= " + requestJson.get("minimumYield");
		}

		if (requestJson.containsKey("netExpenseRatio")) {
			additionalQuery = additionalQuery + " and mf.net_expense_ratio <= " + requestJson.get("netExpenseRatio");
		}

		if (requestJson.containsKey("minimumAsset")) {
			additionalQuery = additionalQuery + " and mf.minimum_asset <= " + requestJson.get("minimumAsset");
		}

		if (requestJson.containsKey("fundMinimumQP")) {
			additionalQuery = additionalQuery + " and mf.minimum_qp_investment_amount <= "
					+ requestJson.get("fundMinimumQP");
		}

		if (requestJson.containsKey("fundMinimumNonQP")) {
			additionalQuery = additionalQuery + " and mf.minimum_non_qp_investment_amount <= "
					+ requestJson.get("fundMinimumNonQP");
		}

		if (requestJson.containsKey("fundFamilyId")) {
			additionalQuery = additionalQuery + " and mf.fund_family_id = '" + requestJson.get("fundFamilyId") + "'";
		}

		if (requestJson.containsKey("programCode")) {
			additionalQuery = additionalQuery + " and p.program_code = '" + requestJson.get("programCode") + "'";
		}

		if (requestJson.containsKey("investmentObjective")) {
			additionalQuery = additionalQuery
					+ " and mf.investment_objective in (select list_id from list_values where list_type = 'INVESTMENT OBJECTIVE' and list_value = '"
					+ requestJson.get("investmentObjective") + "')";
		}

		if (requestJson.containsKey("styleClassificationId")) {
			additionalQuery = additionalQuery
					+ " and nir.rollup_type_flag = 'F' and nir.effective_to_date is null and nir.style_node_id = '"
					+ requestJson.get("styleClassificationId") + "'";
		}

		if (requestJson.containsKey("cusip")) {
			additionalQuery = additionalQuery + " and mf.cusip = '" + requestJson.get("cusip") + "'";
		}

		if (requestJson.containsKey("ticker")) {
			additionalQuery = additionalQuery + " and mf.ticker = '" + requestJson.get("ticker") + "'";
		}

		if (requestJson.containsKey("status")) {
			String statusVal = removeBracketsAndInvertedCommas(requestJson.get("status").toString());

			/* if multiple statu in request */
			if (statusVal.contains(",")) {
				String[] temp = statusVal.split(",");
				statusVal = "";

				for (String code : temp) {
					statusVal = statusVal.concat("'" + removeBracketsAndInvertedCommas(code) + "'");
				}

				/* formatting codes 'ABCD''EFGH' -> 'ABCD','EFGH' */
				statusVal = statusVal.replace("''", "','");
			} else
				statusVal = "'" + statusVal + "'";

			additionalQuery = additionalQuery
					+ " and pe.status in (select list_id from list_values where list_value in (" + statusVal + "))";
		}

		/* FOR searchmfapi */
		if (requestJson.containsKey("billingSymbol")) {
			additionalQuery = additionalQuery + " and mf.billing_symbol = '" + requestJson.get("billingSymbol") + "'";
		}

		if (requestJson.containsKey("pwSecurityID")) {
			additionalQuery = additionalQuery + " and mf.pw_sec_no = '" + requestJson.get("pwSecurityID") + "'";
		}

		if (requestJson.containsKey("minimumQpInvestmentAmount")) {
			additionalQuery = additionalQuery + " and mf.minimum_qp_investment_amount <= '"
					+ requestJson.get("minimumQpInvestmentAmount") + "'";
		}

		if (requestJson.containsKey("minimumNonQpInvestmentAmount")) {
			additionalQuery = additionalQuery + " and mf.minimum_non_qp_investment_amount <= '"
					+ requestJson.get("minimumNonQpInvestmentAmount") + "'";
		}

		if (requestJson.containsKey("adpSecurityNumber")) {
			additionalQuery = additionalQuery + " and mf.broadridge_adp_id = '" + requestJson.get("adpSecurityNumber")
					+ "'";
		}

		if (requestJson.containsKey("mfName")) {
			additionalQuery = additionalQuery + " and mf.fund_name = '" + requestJson.get("mfName") + "'";
		}

		if (requestJson.containsKey("isin")) {
			additionalQuery = additionalQuery + " and mf.isin = '" + requestJson.get("isin") + "'";
		}

		if (requestJson.containsKey("fundFamilyName")) {
			additionalQuery = additionalQuery + " and mf.fund_family_name ilike '" + requestJson.get("fundFamilyName")
					+ "%'";
		}

		sql = sql + additionalQuery;
		ebag.setCollapsibleHtml("SQL Query Used", sql);
//		Reporter.addStepLog(
//				"<b>Note: for this user story, done a temporary fix on counts - count(distinct((mf.cusip, pe.created_on)))  </b>"
//						+ "</br> sent mail to dev team to look for duplicates entries.");
//		Reporter.addStepLog("</br>");
		return sql;
	}

	public String removeBracketsAndInvertedCommas(String s) {
		try {
			s = s.replace("\"", "");
			s = s.replace("[", "");
			s = s.replace("]", "");
		} catch (Exception e) {
			System.out.println("Inside catch - removeBracketsAndInvertedCommas");
		}
		return s;
	}

	void SetBenchmarkMapping(String apiAttribute) {
		apiAttribute = apiAttribute + "[i].";

		BenchmarkAttributesAndDBColumns.put(apiAttribute + "identifier[j]", "benchmark_id");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "code[j]", "benchmark_code");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "name[j]", "benchmark_name");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "description[j]", "benchmark_description");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "percentage[j]", "percentage");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "benchmarkSourceType[j]", "data_source");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "benchmarkCategory[j]", "benchmark_category");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "createdBy[j]", "created_by");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "lastUpdateBy[j]", "last_update_by");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "clientReference[j]", "client_name");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "clientReferenceType[j]", "client_code");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "clientReferenceID[j]", "client_id");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "classificationCode[j]", "benchmark_classification");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "type[j]", "benchmark_type");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "status[j]", "status");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "lastUpdateOnString[j]", "last_update_on");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "createdOnString[j]", "created_on");
		BenchmarkAttributesAndDBColumns.put(apiAttribute + "effectiveDateString[j]", "effective_from_date");
	}
	
	String nullAndBlank(String str) {
		if(str==null || str == "" || str.length() < 1 || str.contains("null")) {
		str = "NODATA";
		}
		return str;
	}
}
