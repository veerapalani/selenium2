package qa.unicorn.ad.productmaster.api.stepdefs;

import java.awt.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Connection.Request;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;

public class BaseAPISearchStyleAPI {
	Response response = EISLBaseAPIGeneric.response;
	String request = EISLBaseAPIGeneric.requestJson;
	JSONObject requestJson = null;
	JSONParser parser = new JSONParser();
	SoftAssert sa = new SoftAssert();
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	ProductMasterGeneric pm = new ProductMasterGeneric();
	JSONArray entitlements = BaseAPIGetStrategyDetails.entitlements;
	JSONArray repCodes = BaseAPIGetStrategyDetails.repCodes;
	JSONArray branch = BaseAPIGetStrategyDetails.branch;
	Object keyVal = null;
	int noOfStylesinResponse = 0;
	String finalReport = "";
	int totalnodeIdInResponse = 0;
	Map<String, String> BundledNodeIdAttributes = new HashMap<String, String>();
	Map<String, String> AssetClassificationAttributes = new HashMap<String, String>();
	Map<String, String> BenchmarkAttributesAndDBColumns = new HashMap<String, String>();
	String pmpStrategyCode = null;
	String pmpStyleId = null;
	String smaStrategyCode = null;
	String smaStyleId = null;

	ProductMasterGeneric pmg = new ProductMasterGeneric();

	String columnName = "";
	String apiAttributeName = "";

	@Then("response code for style service API is {string} or {string}")
	public void response_code_for_the_service_API_is_or(String str200, String str404) {
		if (noOfStylesinResponse != 0) {
			/* If status code is not as expected, printing the error/response in Reports */
			if (response.getStatusCode() != Integer.parseInt(str200)) {

				Reporter.addStepLog("<b style=\"color:red\">NOT AS EXPECTED | Response from API is : Response Code - "
						+ response.getStatusCode() + "</b>");

				setCollapsibleHtml("Click here to see response",
						"<p style=\"color:red\">" + response.getBody().asString() + "</p>");

			} else if (response.getStatusCode() == Integer.parseInt(str200)) {
				Reporter.addStepLog("<b style=\"color:green\"> AS EXPECTED | Response from API is : Response Code - "
						+ response.getStatusCode() + "</b>");

				setCollapsibleHtml("Click here to see response",
						"<p style=\"color:black\">" + response.getBody().asString() + "</p>");

			}

		} else if (noOfStylesinResponse == 0) {
			if (response.getStatusCode() != Integer.parseInt(str404)) {

				Reporter.addStepLog("<b style=\"color:red\">NOT AS EXPECTED | Response from API is : Response Code - "
						+ response.getStatusCode() + "</b>");

				setCollapsibleHtml("Click here to see response",
						"<p style=\"color:red\">" + response.getBody().asString() + "</p>");

			} else if (response.getStatusCode() == Integer.parseInt(str404)) {
				Reporter.addStepLog(
						"<b style=\"color:green\"> AS EXPECTED ,NO DATA PRESENT IN DB | Response from API is : Response Code - "
								+ response.getStatusCode() + "</b>");

			}

		} else {
			setCollapsibleHtml("Click here to see response", response.getBody().asString());
			RestApiHelperMethods.verfiyStatusCode(response, Integer.parseInt(str200));
		}

	}

	@And("^Compare number of styles linked with requested (.+) in API and DB$")
	public void compare_number_of_managers_linked_with_requested_in_API_and_DB(String keys)
			throws ParseException, SQLException {
		int keyCountInDB = 0;
		String sql = null;
		requestJson = (JSONObject) parser.parse(request);
		if (requestJson.containsKey(keys))
			keyVal = requestJson.get(keys);
		if (response.getStatusCode() == 200) {
			String styleId = "null";
			styleId = response.jsonPath().getString("identifier");
			if (!styleId.equalsIgnoreCase("null")) {
				String[] styleIdArr = styleId.split(",");
				noOfStylesinResponse = styleIdArr.length;
				if (keys.equals("riskCategory")) {
					if (!keyVal.toString().equals("0")) {
						sql = "select count(*) from style where risk_category in  "
								+ " (select list_id from list_values where list_type='RISK' and list_code <='" + keyVal
								+ "' and list_code!='0')"
								+ " and style_id in (select style_id from strategy)  and program_id in (select program_id from program)";
					} else if (keyVal.toString().equals("0")) {
						sql = "select count(*) from style where risk_category in  "
								+ " (select list_id from list_values where list_type='RISK' and list_code in ('0','1','2','3','4','5')) "
								+ " and style_id in (select style_id from strategy)  and program_id in (select program_id from program)";

					}
				} else if (keys.equals("category")) {
					sql = "select count(*) from style where style_category in \r\n"
							+ "(select list_id from list_values where list_type='STYLE' and list_value='" + keyVal
							+ "')\r\n"
							+ "and style_id in (select style_id from strategy )  and program_id in (select program_id from program)";

				} else if (keys.equals("geographicIndicator")) {
					sql = "select count(*) from style where geographic_Indicator in \r\n"
							+ "(select list_id from list_values where list_type='GEO IND' and list_value='" + keyVal
							+ "')\r\n"
							+ "and style_id in (select style_id from strategy )  and program_id in (select program_id from program)";
				} else if (keys.equals("marketCapitalization")) {
					sql = "select count(*) from style where market_Cap in \r\n"
							+ "(select list_id from list_values where list_type='MKT CAP' and list_value='" + keyVal
							+ "')\r\n"
							+ "and style_id in (select style_id from strategy )  and program_id in (select program_id from program)";
				} else if (keys.equals("comparativeUniverse")) {
					sql = "select count(*) from style where comparative_universe in \r\n"
							+ "(select list_id from list_values where list_type='COMP UNIVERSE' and list_code='"
							+ keyVal + "')\r\n"
							+ "and style_id in (select style_id from strategy ) and program_id in (select program_id from program)";
				} else if (keys.equals("status")) {
					sql = "select count(*) from style where status in \r\n"
							+ "(select list_id from list_values where list_type='STATUS' and list_value='" + keyVal
							+ "')\r\n"
							+ "and style_id in (select style_id from strategy ) and program_id in (select program_id from program)";
				}

				System.out.println(sql);
				keyCountInDB = ebag.compareCounts(sql, "");
			}
			// Assert.assertEquals(keyCountInDB, noOfStylesinResponse);
			sa.assertEquals(keyCountInDB, noOfStylesinResponse);
			Reporter.addStepLog("No. of styles linked with " + keys + " = " + keyVal + " |DB: " + keyCountInDB
					+ " |API : " + noOfStylesinResponse);

		} else if (response.getStatusCode() == 404) {
			Assert.assertEquals(0, noOfStylesinResponse);
			Reporter.addStepLog("Status Code is 404 as No. of style linked with " + keys + " = " + keyVal + " |DB: "
					+ keyCountInDB + "|API : " + noOfStylesinResponse);

		}
	}

	@And("^verify the data received from server for (.+) with Product Master DB for Style$")
	public void verify_the_data_received_from_server_for_riskCategory_with_Product_Master_DB(String keys)
			throws SQLException {
		String sql = null;
		if (keys.equals("riskCategory")) {
			if (!keyVal.toString().equals("0")) {
				sql = "select style_id from style where risk_category in  "
						+ " (select list_id from list_values where list_type='RISK' and list_code <='" + keyVal
						+ "' and list_code!='0')"
						+ " and style_id in (select style_id from strategy) and program_id in (select program_id from program)";
			} else if (keyVal.toString().equals("0")) {
				sql = "select style_id from style where risk_category in  "
						+ " (select list_id from list_values where list_type='RISK' and list_code in ('0','1','2','3','4','5'))"
						+ " and style_id in (select style_id from strategy) and program_id in (select program_id from program)";

			}
		} else if (keys.equals("category")) {
			sql = "select style_id from style where style_category in \r\n"
					+ "(select list_id from list_values where list_type='STYLE' and list_value='" + keyVal + "')\r\n"
					+ "and style_id in (select style_id from strategy ) and program_id in (select program_id from program)";

		} else if (keys.equals("geographicIndicator")) {
			sql = "select style_id from style where geographic_Indicator in \r\n"
					+ "(select list_id from list_values where list_type='GEO IND' and list_value='" + keyVal + "')\r\n"
					+ "and style_id in (select style_id from strategy) and program_id in (select program_id from program)";
		} else if (keys.equals("marketCapitalization")) {
			sql = "select style_id from style where market_Cap in \r\n"
					+ "(select list_id from list_values where list_type='MKT CAP' and list_value='" + keyVal + "')\r\n"
					+ "and style_id in (select style_id from strategy) and program_id in (select program_id from program)";
		} else if (keys.equals("comparativeUniverse")) {
			sql = "select style_id from style where comparative_universe in \r\n"
					+ "(select list_id from list_values where list_type='COMP UNIVERSE' and list_code='" + keyVal
					+ "')\r\n"
					+ "and style_id in (select style_id from strategy ) and program_id in (select program_id from program)";
		} else if (keys.equals("status")) {
			sql = "select style_id from style where status in \r\n"
					+ "(select list_id from list_values where list_type='STATUS' and list_value='" + keyVal + "')\r\n"
					+ "and style_id in (select style_id from strategy ) and program_id in (select program_id from program)";
		}
		System.out.println(sql);
		pmdb.DBConnectionStart();
		int dbstyleId;
		Integer styleId = null;
		ResultSet rs = DBManager.executeSelectQuery(sql);

		ArrayList<Integer> DBVal = new ArrayList<Integer>();
		ArrayList<Integer> APIVal = new ArrayList<Integer>();
		int j = 0;
		while (rs.next()) {
			dbstyleId = rs.getInt("style_id");
			DBVal.add(j, dbstyleId);
			j++;
		}
		for (int n = 0; n < noOfStylesinResponse; n++) {
			styleId = response.jsonPath().getInt("identifier[" + n + "]");
			APIVal.add(n, styleId);
			Collections.sort(APIVal);
		}

		Collections.sort(DBVal);

		for (int i = 0; i < DBVal.size(); i++) {
			sa.assertEquals(DBVal.get(i), APIVal.get(i), " styleID:" + styleId);

			if (!DBVal.get(i).equals(APIVal.get(i))) {
				Reporter.addStepLog("Not matched for style ID = " + APIVal.get(i) + "|DB: " + (DBVal.get(i))
						+ " |API : " + APIVal.get(i));
			} else if (DBVal.get(i).equals(APIVal.get(i))) {
				finalReport = finalReport + "StyleIds : | DB:" + (DBVal.get(i)) + " = API :" + APIVal.get(i)
						+ " </br> ";
			}

		}

		ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);
		pmdb.DBConnectionClose();
		sa.assertAll();
	}

	@And("^Compare number of nodeId linked from API and DB$")
	public void Compare_number_of_assetClassification_linked_from_API_and_DB() throws ParseException, SQLException {
		Object assetClass = "null";
		Object bundled = "null";
		Object unBundled = "null";

		requestJson = (JSONObject) parser.parse(request);
		if ((requestJson.containsKey("includeBundledNodeID"))) {
			bundled = requestJson.get("includeBundledNodeID");
			String styleId = response.jsonPath().getString("identifier");
			if (bundled.toString().equals("true")) {
				String nodeId = response.jsonPath().getString("bundledNodeIDs.nodeID");
				// nodeId = pm.RemoveSquareBrackets(nodeId);
				String[] styleIdArr = styleId.split(",");
				if (!nodeId.equalsIgnoreCase("")) {
					String[] nodeIdArr = nodeId.split(",");
					totalnodeIdInResponse = nodeIdArr.length;
				}
				for (int i = 0; i < styleIdArr.length; i++) {
					styleId = response.jsonPath().getString("identifier[" + i + "]");

					String sql = "select count(style_node_id) from node_id_rollup where reference_type='STYLE' and reference_id='"
							+ styleId + "'" + " and rollup_type_flag='F'";

					System.out.println(sql);
					int nodeIdCountInDB = ebag.compareCounts(sql, "");
					sa.assertEquals(nodeIdCountInDB, totalnodeIdInResponse);
					Reporter.addStepLog("No. of bundledNodeId for styleId = " + styleId + " |DB: " + nodeIdCountInDB
							+ " |API : " + totalnodeIdInResponse);
				}

			} else {

				// Assert.assertEquals(0, totalnodeIdInResponse);
				sa.assertEquals(0, totalnodeIdInResponse);
				if (bundled.toString().equalsIgnoreCase("null")) {
					Reporter.addStepLog("No. of BundledNodeID forstyleId = " + styleId
							+ " |Flag for BundledNodeID in request is not present | BundledNodeID in API : "
							+ totalnodeIdInResponse);

				} else {
					Reporter.addStepLog("No. of BundledNodeID for manager ID = " + styleId
							+ " |Flag for BundledNodeID in request is: " + bundled + " | BundledNodeID in API : "
							+ totalnodeIdInResponse);
				}
			}
		}
		if ((requestJson.containsKey("includeUnbundledNodeID"))) {
			unBundled = requestJson.get("includeUnbundledNodeID");
			String styleId = response.jsonPath().getString("identifier");

			if (unBundled.toString().equals("true")) {
				String nodeId = response.jsonPath().getString("unbundledNodeIDs.nodeID");
				// nodeId = pm.RemoveSquareBrackets(nodeId);
				String[] styleIdArr = styleId.split(",");
				if (!nodeId.equalsIgnoreCase("")) {
					String[] nodeIdArr = nodeId.split(",");
					totalnodeIdInResponse = nodeIdArr.length;
				}
				for (int i = 0; i < styleIdArr.length; i++) {
					styleId = response.jsonPath().getString("identifier[" + i + "]");

					String sql = "select count(style_node_id) from node_id_rollup where reference_type='STYLE' and reference_id='"
							+ styleId + "'" + " and rollup_type_flag='P'";

					System.out.println(sql);
					int nodeIdCountInDB = ebag.compareCounts(sql, "");
					sa.assertEquals(nodeIdCountInDB, totalnodeIdInResponse);
					Reporter.addStepLog("No. of unbundledNodeId for styleId = " + styleId + " |DB: " + nodeIdCountInDB
							+ " |API : " + totalnodeIdInResponse);
				}

			} else {

				Assert.assertEquals(0, totalnodeIdInResponse);
				if (bundled.toString().equalsIgnoreCase("null")) {
					Reporter.addStepLog("No. of unBundledNodeID forstyleId = " + styleId
							+ " |Flag for unBundledNodeID in request is not present | unBundledNodeID in API : "
							+ totalnodeIdInResponse);

				} else {
					Reporter.addStepLog("No. of unBundledNodeID for manager ID = " + styleId
							+ " |Flag unfor BundledNodeID in request is: " + bundled + " | unBundledNodeID in API : "
							+ totalnodeIdInResponse);
				}
			}
		}

		if ((requestJson.containsKey("includeAssetClassification"))) {
			assetClass = requestJson.get("includeAssetClassification");
			String styleId = response.jsonPath().getString("identifier");
			if (assetClass.toString().equals("true")) {
				String nodeId = response.jsonPath().getString("assetClassification.styleNodeId");
				// nodeId = pm.RemoveSquareBrackets(nodeId);
				String[] styleIdArr = styleId.split(",");
				if (!nodeId.equalsIgnoreCase("")) {
					String[] nodeIdArr = nodeId.split(",");
					totalnodeIdInResponse = nodeIdArr.length;
				}
				for (int i = 0; i < styleIdArr.length; i++) {
					styleId = response.jsonPath().getString("identifier[" + i + "]");

					String sql = "select count(style_node_id) from node_id_rollup where reference_type='STYLE' and reference_id='"
							+ styleId + "'"
							+ " and rollup_type_flag='F' and style_node_id in (select style_node_id from asset_classification)";

					System.out.println(sql);
					int nodeIdCountInDB = ebag.compareCounts(sql, "");

					Assert.assertEquals(nodeIdCountInDB, totalnodeIdInResponse);
					Reporter.addStepLog("No. of assetClassification for styleId = " + styleId + " |DB: "
							+ nodeIdCountInDB + " |API : " + totalnodeIdInResponse);
				}

			} else {

				Assert.assertEquals(0, totalnodeIdInResponse);
				if (bundled.toString().equalsIgnoreCase("null")) {
					Reporter.addStepLog("No. of unBundledNodeID forstyleId = " + styleId
							+ " |Flag for unBundledNodeID in request is not present | unBundledNodeID in API : "
							+ totalnodeIdInResponse);

				} else {
					Reporter.addStepLog("No. of unBundledNodeID for manager ID = " + styleId
							+ " |Flag unfor BundledNodeID in request is: " + assetClass + " | unBundledNodeID in API : "
							+ totalnodeIdInResponse);
				}
			}
		}

	}

	@And("^verify the data received from server for Bundled with Product Master DB$")
	public void verify_the_data_received_from_server_for_Documents_with_Product_Master_DB() throws Throwable {

		if (totalnodeIdInResponse != 0) {

			String styleId = response.jsonPath().getString("identifier");
			String[] styleIdArr = styleId.split(",");

			SetBundledNodeIdMapping();

			pmdb.DBConnectionStart();
			if ((requestJson.containsKey("includeBundledNodeID"))) {
				for (int i = 0; i < styleIdArr.length; i++) {
					styleId = response.jsonPath().getString("identifier[" + i + "]");

					String BundledNodeID = response.jsonPath().getString("bundledNodeIDs.nodeID");
					String[] BundledNodeIDArr = BundledNodeID.split(",");

					for (int j = 0; j < BundledNodeIDArr.length; j++) {

						BundledNodeID = response.jsonPath().getString("bundledNodeIDs[" + i + "].nodeID[" + j + "]");
						String sql = "select percentage,effective_from_date from node_id_rollup where reference_type='STYLE' and reference_id='"
								+ styleId + "'" + " and rollup_type_flag='F' and style_node_id = '" + BundledNodeID
								+ "'";

						System.out.println(sql);

						for (Map.Entry<String, String> set : BundledNodeIdAttributes.entrySet()) {

							columnName = set.getKey();
							apiAttributeName = set.getValue();

							String Path = "bundledNodeIDs[" + i + "]." + apiAttributeName + "[" + j + "]";

							String apiValue = response.jsonPath().getString(Path) + "";
							String dbValue = null;
							String dbValue11 = null;

							ResultSet rs = DBManager.executeSelectQuery(sql);

							while (rs.next()) {
								dbValue = rs.getString(set.getKey()) + "";
								if ((set.getKey().contains("Date") && !dbValue.equalsIgnoreCase("null"))) {

									dbValue11 = ebag.convertDateToExpectedFormat(dbValue, "");
									dbValue11 = dbValue11.substring(0, 10);

								}
								if ((set.getKey().contains("percentage") && !dbValue.equalsIgnoreCase("null"))) {
									int index = dbValue.indexOf('.');
									if (index >= 0) {
										dbValue11 = dbValue.substring(0, index + 2);
									} else {
										dbValue11 = dbValue;
									}

								}
								System.out.println(Path + " | " + dbValue11 + " = " + apiValue);

								if (!dbValue11.equalsIgnoreCase("null") && (!apiValue.equalsIgnoreCase("")
										|| !apiValue.isEmpty() || !apiValue.equalsIgnoreCase("null"))) {
									sa.assertEquals(apiValue, dbValue11,
											"mismatched for " + Path + " | styleId:" + styleId);

									if (!apiValue.equals(dbValue11)) {
										Reporter.addStepLog("Not matched for BundledNodeID = " + BundledNodeID
												+ " | path = " + Path + "|DB: " + dbValue11 + " |API : " + apiValue);
									} else {
										finalReport = finalReport + Path + " | " + BundledNodeID + " | " + dbValue11
												+ " = " + apiValue + " </br> ";
									}
								} else {
									finalReport = finalReport + Path + " | " + dbValue11 + " = " + apiValue + " </br> ";
								}
							}
						}
					}

				}

			}
			if ((requestJson.containsKey("includeUnbundledNodeID"))) {
				for (int i = 0; i < styleIdArr.length; i++) {
					styleId = response.jsonPath().getString("identifier[" + i + "]");

					String unbundledNodeIDs = response.jsonPath().getString("unbundledNodeIDs.nodeID");
					String[] unbundledNodeIDsArr = unbundledNodeIDs.split(",");

					for (int j = 0; j < unbundledNodeIDsArr.length; j++) {

						unbundledNodeIDs = response.jsonPath()
								.getString("unbundledNodeIDs[" + i + "].nodeID[" + j + "]");
						String sql = "select percentage,effective_from_date from node_id_rollup where reference_type='STYLE' and reference_id='"
								+ styleId + "'" + " and rollup_type_flag='P' and style_node_id = '" + unbundledNodeIDs
								+ "'";

						System.out.println(sql);

						for (Map.Entry<String, String> set : BundledNodeIdAttributes.entrySet()) {

							columnName = set.getKey();
							apiAttributeName = set.getValue();

							String Path = "unbundledNodeIDs[" + i + "]." + apiAttributeName + "[" + j + "]";

							String apiValue = response.jsonPath().getString(Path) + "";
							String dbValue = null;
							String dbValue11 = null;

							ResultSet rs = DBManager.executeSelectQuery(sql);

							while (rs.next()) {
								dbValue = rs.getString(set.getKey()) + "";
								if ((set.getKey().contains("Date") && !dbValue.equalsIgnoreCase("null"))) {

									dbValue11 = ebag.convertDateToExpectedFormat(dbValue, "");
									dbValue11 = dbValue11.substring(0, 10);

								}
								if ((set.getKey().contains("percentage") && !dbValue.equalsIgnoreCase("null"))) {
									int index = dbValue.indexOf('.');
									if (index >= 0) {
										dbValue11 = dbValue.substring(0, index + 2);
									} else {
										dbValue11 = dbValue;
									}

								}
								System.out.println(Path + " | " + dbValue11 + " = " + apiValue);

								if (!dbValue11.equalsIgnoreCase("null") && (!apiValue.equalsIgnoreCase("")
										|| !apiValue.isEmpty() || !apiValue.equalsIgnoreCase("null"))) {
									sa.assertEquals(apiValue, dbValue11,
											"mismatched for " + Path + " | styleId:" + styleId);

									if (!apiValue.equals(dbValue11)) {
										Reporter.addStepLog("Not matched for unbundledNodeIDs = " + unbundledNodeIDs
												+ " | path = " + Path + "|DB: " + dbValue11 + " |API : " + apiValue);
									} else {
										finalReport = finalReport + Path + " | " + unbundledNodeIDs + " | " + dbValue11
												+ " = " + apiValue + " </br> ";
									}
								} else {
									finalReport = finalReport + Path + " | " + dbValue11 + " = " + apiValue + " </br> ";
								}
							}
						}
					}

				}
			}

			if ((requestJson.containsKey("includeAssetClassification"))) {
				AssetClassificationAttributesMapping();
				for (int i = 0; i < styleIdArr.length; i++) {
					styleId = response.jsonPath().getString("identifier[" + i + "]");

					String assetNodeId = response.jsonPath().getString("assetClassification.styleNodeId");
					String[] assetNodeIdArr = assetNodeId.split(",");

					for (int j = 0; j < assetNodeIdArr.length; j++) {

						assetNodeId = response.jsonPath()
								.getString("assetClassification[" + i + "].styleNodeId[" + j + "]");
						String sql = "select broad_asset_class_node_id,broad_asset_class_name,asset_class_node_id,asset_class_name ,\r\n"
								+ "						sub_class_node_id,sub_class_name,style_name\r\n"
								+ "						from asset_classification where style_node_id in (select style_node_id from node_id_rollup \r\n"
								+ "						where reference_type='STYLE' and reference_id='" + styleId
								+ "' and rollup_type_flag='F' and style_node_id = '" + assetNodeId + "')";

						System.out.println(sql);

						for (Map.Entry<String, String> set : AssetClassificationAttributes.entrySet()) {

							columnName = set.getKey();
							apiAttributeName = set.getValue();

							String Path = "assetClassification[" + i + "]." + apiAttributeName + "[" + j + "]";

							String apiValue = response.jsonPath().getString(Path) + "";
							String dbValue11 = null;

							ResultSet rs = DBManager.executeSelectQuery(sql);

							while (rs.next()) {
								dbValue11 = rs.getString(set.getKey()) + "";
								System.out.println(Path + " | " + dbValue11 + " = " + apiValue);

								if (!dbValue11.equalsIgnoreCase("null") && (!apiValue.equalsIgnoreCase("")
										|| !apiValue.isEmpty() || !apiValue.equalsIgnoreCase("null"))) {
									sa.assertEquals(apiValue, dbValue11,
											"mismatched for " + Path + " | styleId:" + styleId);

									if (!apiValue.equals(dbValue11)) {
										Reporter.addStepLog("Not matched for assetClassification = " + assetNodeId
												+ " | path = " + Path + "|DB: " + dbValue11 + " |API : " + apiValue);
									} else {
										finalReport = finalReport + Path + " | " + assetNodeId + " | " + dbValue11
												+ " = " + apiValue + " </br> ";
									}
								} else {
									finalReport = finalReport + Path + " | " + dbValue11 + " = " + apiValue + " </br> ";
								}
							}
						}
					}

				}
			}

			pmdb.DBConnectionClose();
			ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);
		}

		sa.assertAll();
	}

	@SuppressWarnings("deprecation")
	@And("^Validate the benchmark data in response for searchstyleapi$")
	public void checkstyleids() throws ParseException, SQLException {

		String selectedBenchmarkDB = null;
		SoftAssert sa = new SoftAssert();

		/* getting all styleIds from response */
		String styleIdAPIAll = EISLBaseAPIGeneric.response.body().jsonPath().getString("identifier");
		String[] styleIdAPIArr = styleIdAPIAll.split(",");

		/* iterating each object */
		for (int i = 0; i < styleIdAPIArr.length; i++) {

			/* fetching defaultBenchmark OR customBenchmark from API response */
			String defaultBenchmarkAPI = EISLBaseAPIGeneric.response.body().jsonPath()
					.getString("defaultBenchmarks[" + i + "]");
			String customBenchmarkAPI = EISLBaseAPIGeneric.response.body().jsonPath()
					.getString("customBenchmarks[" + i + "]");
			String benchmarkIdsAPI = null;
			boolean includeBenchmarkValue = false;

			requestJson = (JSONObject) parser.parse(EISLBaseAPIGeneric.requestJson);

			/* getting value of includeBenchmark if present */
			if (requestJson.containsKey("includeBenchmark")) {
				includeBenchmarkValue = (Boolean) requestJson.get("includeBenchmark");
			}

			/*
			 * if includeBenchmark = false OR includeBenchmark not present in request, we
			 * should have null for both benchmarks.
			 */
			if (includeBenchmarkValue == false) {

				sa.assertEquals(null, customBenchmarkAPI,
						"Expected null for customBenchmark but found " + customBenchmarkAPI);
				sa.assertEquals(null, defaultBenchmarkAPI,
						"Expected null for defaultBenchmark but found " + defaultBenchmarkAPI);

				sa.assertAll();

				Reporter.addStepLog("<b>Expected customBenchmark: </b>null");
				Reporter.addStepLog("<b>Actual customBenchmark: </b>" + customBenchmarkAPI);
				Reporter.addStepLog("<b>Expected defaultBenchmark: </b>null");
				Reporter.addStepLog("<b>Actual defaultBenchmark: </b>" + customBenchmarkAPI);

			} else { // Else checking benchmark DATA and counts.

				String styleIdAPI = pmg.RemoveSquareBrackets(styleIdAPIArr[i]);

				String sqlQuery = "select (select list_value from list_values where list_id = s.selected_benchmark_type) as ben_type from style s where s.style_id = "
						+ " " + styleIdAPI;

				pmdb.DBConnectionStart();

				ResultSet rs = DBManager.executeSelectQuery(sqlQuery);

				/* getting selected_benchmark_type from DB */
				while (rs.next()) {
					selectedBenchmarkDB = rs.getString("ben_type");
				}

				/* expected list of benchmarkIds */
				ArrayList<String> benchmarkIdsDB = new ArrayList<String>();

				/* Validating if correct benchmark is coming or not */
				if (selectedBenchmarkDB.equals("Default")) {
					Assert.assertTrue("Expected Default benchmark but found null.", defaultBenchmarkAPI.length() > 4);
					benchmarkIdsAPI = EISLBaseAPIGeneric.response.body().jsonPath()
							.getString("defaultBenchmarks[" + i + "].identifier");

				} else {
					Assert.assertTrue("Expected Custom benchmark but found null.", customBenchmarkAPI.length() > 4);
					benchmarkIdsAPI = EISLBaseAPIGeneric.response.body().jsonPath()
							.getString("customBenchmarks[" + i + "].identifier");
				}

				String[] benchmarkIdsAPIArr = benchmarkIdsAPI.split(",");

				/* Getting benchmarkIds from DB to validate */
				if (selectedBenchmarkDB.equals("Custom")) {
					sqlQuery = "select benchmark_id from benchmark_assoc where reference_id = " + styleIdAPI
							+ " and reference_type = 'STYLE' and benchmark_category in"
							+ " (select list_id from list_values where list_value = '" + selectedBenchmarkDB + "')";
				} else {
					sqlQuery = "select nib.benchmark_id from node_id_rollup nir, node_id_benchmark nib, style s where\r\n"
							+ "s.style_id = nir.reference_id and nir.reference_type = 'STYLE' and nir.style_node_id = nib.style_node_id\r\n"
							+ "and nir.effective_to_date is null and nib.effective_to_date is null and nir.rollup_type_flag = 'F' and s.style_id = '"
							+ styleIdAPI + "'";
				}
				rs = DBManager.executeSelectQuery(sqlQuery);
				System.out.println(sqlQuery);

				while (rs.next()) {
					benchmarkIdsDB.add(rs.getString("benchmark_id"));
				}

				/* Checking counts expected(from DB) and actual(from API) */

				Reporter.addStepLog("<b>Expected Counts(from DB): </b>" + benchmarkIdsDB.size());
				Reporter.addStepLog("<b>Actual Counts(from API): </b>" + benchmarkIdsAPIArr.length);

				/* Hard Assert - Fails, if count mismatch */
				if (benchmarkIdsAPIArr.length != benchmarkIdsDB.size()) {
					Assert.assertTrue("Count Mismatched.", false);
				}

				/* if counts are equal, checking benchmark ID and data */
				for (int j = 0; j < benchmarkIdsAPIArr.length; j++) {

					/* if id mismatch, no need to match benchmark data */
					if (!benchmarkIdsDB.contains(pmg.RemoveSquareBrackets(benchmarkIdsAPIArr[i]))) {
						sa.assertTrue(false, pmg.RemoveSquareBrackets(benchmarkIdsAPIArr[i])
								+ " benchmarkId is not in expected list.");
						Reporter.addStepLog((benchmarkIdsAPIArr[i]) + " benchmarkId is not in expected list.");

						sa.assertAll();
						/* if everything is alright, checking benchmark data */
					} else {
						if (selectedBenchmarkDB.equals("Custom")) {
							sqlQuery = "select distinct b.created_on, b.last_update_on, ba.effective_from_date, b.created_by, b.last_update_by, ba.benchmark_id, c.client_name, c.client_code,\r\n"
									+ "b.client_id, b.benchmark_code,\r\n"
									+ "(select list_value from list_values where list_id = b.benchmark_classification) as benchmark_classification, \r\n"
									+ "(select list_value from list_values where list_id = b.benchmark_type) as benchmark_type, b.benchmark_name, b.benchmark_description, ba.percentage, \r\n"
									+ "(select list_value from list_values where list_id = b.status) as status, \r\n"
									+ "(select list_value from list_values where list_id = ba.benchmark_category) as benchmark_category, b.data_source from benchmark b\r\n"
									+ "inner join benchmark_assoc ba on ba.benchmark_id = b.benchmark_id\r\n"
									+ "inner join style s on s.style_id = ba.reference_id and ba.reference_type = 'STYLE'\r\n"
									+ "inner join client c on c.client_id = b.client_id\r\n" + "where ba.benchmark_id ="
									+ pmg.RemoveSquareBrackets(benchmarkIdsAPIArr[i]) + " and s.style_id = "
									+ styleIdAPI + " \r\n"
									+ "and ba.benchmark_category = (select list_id from list_values where list_value = '"
									+ selectedBenchmarkDB + "')";
						} else {
							sqlQuery = "select distinct b.created_on, b.last_update_on, nib.effective_from_date, b.created_by, b.last_update_by, b.benchmark_id,\r\n"
									+ "						c.client_name, c.client_code,b.client_id, b.benchmark_code,\r\n"
									+ "						(select list_value from list_values where list_id = b.benchmark_classification) as benchmark_classification,\r\n"
									+ "						(select list_value from list_values where list_id = b.benchmark_type) as benchmark_type, b.benchmark_name, b.benchmark_description,\r\n"
									+ "						b.percentage, (select list_value from list_values where list_id = b.status) as status,\r\n"
									+ "						(select list_value from list_values where list_id = s.selected_benchmark_type) as benchmark_category, b.data_source\r\n"
									+ "						from benchmark b\r\n"
									+ "						inner join node_id_benchmark nib on nib.benchmark_id = b.benchmark_id and nib.effective_to_date is null\r\n"
									+ "						inner join node_id_rollup nir on nir.style_node_id = nib.style_node_id and nir.effective_to_date is null and nir.rollup_type_flag = 'F'\r\n"
									+ "						inner join style s on s.style_id = nir.reference_id and nir.reference_type = 'STYLE'\r\n"
									+ "						inner join client c on c.client_id = b.client_id where nib.benchmark_id = "
									+ pmg.RemoveSquareBrackets(benchmarkIdsAPIArr[i]) + " and s.style_id = "
									+ styleIdAPI;
						}

						ebag.setCollapsibleHtml("SQL Query", sqlQuery);

						/* Setting up mapping */
						SetBenchmarkMapping(selectedBenchmarkDB);

						for (Map.Entry<String, String> set : BenchmarkAttributesAndDBColumns.entrySet()) {
							String apiAttributeName = set.getKey();

							/* replacing parent and child count */
							apiAttributeName = apiAttributeName.replace("[i]", "[" + i + "]").replace("[j]",
									"[" + j + "]");

							String columnName = set.getValue();

							/* fetching from API */
							String apiValue = EISLBaseAPIGeneric.response.body().jsonPath().getString(apiAttributeName)
									+ "";
							String dbValue = null;

							rs = DBManager.executeSelectQuery(sqlQuery);

							while (rs.next()) {
								/* fetching from DB */
								dbValue = rs.getString(columnName) + "";

								if ((columnName.contains("created_on") || columnName.contains("last_update_on"))
										&& !dbValue.equalsIgnoreCase("null")) {
									dbValue = ebag.convertDateToExpectedFormat(dbValue, "");
								}

								if ((columnName.contains("effective_from_date") && !dbValue.equalsIgnoreCase("null"))) {
									dbValue = ebag.convertDateToExpectedFormat(dbValue, "").substring(0, 10);
								}

								if ((columnName.contains("percentage") && !dbValue.equalsIgnoreCase("null"))) {
									int index = dbValue.indexOf('.');
									if (index >= 0) {
										dbValue = dbValue.substring(0, index + 2);
									}
								}

								Reporter.addStepLog(apiAttributeName + ": <b>Actual -</b> " + apiValue
										+ " | <b>Expected -</b> " + dbValue);
								sa.assertEquals(apiValue, dbValue, "Value Mismatch for " + apiAttributeName + ".");
							}
						}
					}
				}

				pmdb.DBConnectionClose();

				sa.assertAll();
			}
		}

	}

	@And("^user creates a request JSON file with \"([^\"]*)\" strategy codes and styleId for PMP$")
	public void user_creates_a_request_json_file_with_something_strategy_codes(String type) throws Throwable {

		System.out.println("Request pmpStrategyCode: " + pmpStrategyCode + " styleId :" + pmpStyleId);
		ebag.user_creates_a_request_json_file_with_search_keys_and_values("foaCode,identifier",
				pmpStrategyCode + "," + pmpStyleId);
	}

	@And("^user creates a request JSON file with \"([^\"]*)\" strategy codes and styleId for SMA$")
	public void user_creates_a_request_json_file_with_something_strategy_codesSMA(String type) throws Throwable {

		System.out.println("Request smaStrategyCode: " + smaStrategyCode + " styleId :" + smaStyleId);
		ebag.user_creates_a_request_json_file_with_search_keys_and_values("foaCode,identifier",
				smaStrategyCode + "," + smaStyleId);
	}

	@When("^user selects \"([^\"]*)\" number of \"([^\"]*)\" PMP styles from PM DB$")
	public void user_selects_something_number_of_strategies_from_pm_db_according_to_repcodes_and_branch(int count,
			String type) throws Throwable {
		pmdb.DBConnectionStart();

		if (entitlements.toString().contains("PRODM_PMPSTRATEGIES_SERVICE")) {
			String sqlQueryPMP = GetSQLWithBranchAndRepCodesForPMP(repCodes, branch, count, type);

			ebag.setCollapsibleHtml("SQL Query used for PMP - click here to view", sqlQueryPMP);

			ResultSet rs_pmp = DBManager.executeSelectQuery(sqlQueryPMP);

			while (rs_pmp.next()) {
				pmpStrategyCode = rs_pmp.getString("strategy_code");
				pmpStyleId = rs_pmp.getString("style_id");
			}

			pmdb.DBConnectionClose();

			/* Printing in reports */
			Reporter.addStepLog("</br><b>" + type + " PMP strategy codes is:</b>");
			Reporter.addStepLog(pmpStrategyCode);
		}
	}

	@When("^user selects \"([^\"]*)\" number of \"([^\"]*)\" SMA styles from PM DB(.*)$")
	public void user_selects_something_number_of_SMAstrategies_from_pm_db_according_to_repcodes_and_branch(int count,
			String type, String serviceName) throws Throwable {

		pmdb.DBConnectionStart();
		if (type.equalsIgnoreCase("Entitled")) {
			if (entitlements.toString().contains("PRODM_NONPMPSTRATEGIES_SERVICE")) {
				String sqlQuery = GetSQLForSMAStrategies(count);

				ebag.setCollapsibleHtml("SQL Query used for SMA - click here to view", sqlQuery);
				ResultSet rs_sma = DBManager.executeSelectQuery(sqlQuery);
				while (rs_sma.next()) {
					smaStrategyCode = rs_sma.getString("strategy_code");
					smaStyleId = rs_sma.getString("style_id");
				}
				pmdb.DBConnectionClose();

				/* Printing in reports */
				Reporter.addStepLog("</br><b>" + type + " SMA strategy codes is:</b>");
				Reporter.addStepLog(smaStrategyCode);

			}
		}
	}

	void SetBenchmarkMapping(String benchmarkType) {
		if (benchmarkType.equals("Default")) {
			benchmarkType = "defaultBenchmarks[i].";
		} else
			benchmarkType = "customBenchmarks[i].";

		BenchmarkAttributesAndDBColumns.put(benchmarkType + "identifier[j]", "benchmark_id");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "code[j]", "benchmark_code");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "name[j]", "benchmark_name");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "description[j]", "benchmark_description");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "percentage[j]", "percentage");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "benchmarkSourceType[j]", "data_source");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "benchmarkCategory[j]", "benchmark_category");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "createdBy[j]", "created_by");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "lastUpdateBy[j]", "last_update_by");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "clientReference[j]", "client_name");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "clientReferenceType[j]", "client_code");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "clientReferenceID[j]", "client_id");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "classificationCode[j]", "benchmark_classification");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "type[j]", "benchmark_type");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "status[j]", "status");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "lastUpdateOnString[j]", "last_update_on");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "createdOnString[j]", "created_on");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "effectiveDateString[j]", "effective_from_date");
	}

	void SetBundledNodeIdMapping() {
		// BundledNodeIdAttributes.put("style_node_id", "nodeID");
		BundledNodeIdAttributes.put("percentage", "rollupPercentage");
		BundledNodeIdAttributes.put("effective_From_Date", "effectiveFromString");
	}

	void AssetClassificationAttributesMapping() {
		AssetClassificationAttributes.put("broad_asset_class_node_id", "broadAssetClassNodeId");
		AssetClassificationAttributes.put("broad_asset_class_name", "broadAssetClassName");
		AssetClassificationAttributes.put("asset_class_node_id", "assetClassNodeId");
		AssetClassificationAttributes.put("asset_class_name", "assetClassName");
		AssetClassificationAttributes.put("sub_class_node_id", "subClassNodeId");
		AssetClassificationAttributes.put("sub_class_name", "subClassName");
		AssetClassificationAttributes.put("style_name", "styleName");
	}

	String GetSQLForSMAStrategies(int count) {

		return "SELECT distinct strategy_code,style_id, RANDOM() FROM strategy s, program_strategy ps, program p\r\n"
				+ "WHERE ps.strategy_id = s.strategy_id AND ps.program_id = p.program_id AND \r\n"
				+ "s.status IN (SELECT list_id FROM list_values WHERE list_type = 'STRATEGY STATUS' "
				+ "AND list_value NOT IN ('Source DAAD','Rejected','Pending HO Approval','Draft','Pending'))\r\n"
				+ "AND s.style_id is not null AND s.strategy_code is not null "
				+ "AND p.program_code IN ('13','15','16','36','39','46') ORDER BY RANDOM() LIMIT " + count;
	}

	String GetSQLWithBranchAndRepCodesForPMP(JSONArray rr_code, JSONArray branch_number, int count, String type) {

		String sql = "SELECT distinct strategy_code,style_id, RANDOM() FROM strategy s, financial_advisor fa, \r\n"
				+ "strategy_financial_advisor sfa, rr_mapping rm WHERE\r\n"
				+ "s.strategy_id = sfa.strategy_id AND sfa.fa_id = fa.fa_id AND \r\n"
				+ " s.style_id is not null AND s.strategy_code is not null and "
				+ "s.status IN (SELECT list_id FROM list_values WHERE list_type = 'STRATEGY STATUS' AND list_value NOT IN ('Source DAAD','Rejected','Pending HO Approval','Draft','Pending'))\r\n"
				+ "AND fa.fa_code = rm.fa_code AND ";

		String additionalQuery = "";

		if (rr_code.size() > 0) {
			additionalQuery = "rm.rr_code $type (" + pmg.RemoveSquareBrackets(rr_code.toString().replace("\"", "'"))
					+ ")";

		}

		if (branch_number.size() > 0) {
			if (additionalQuery.length() > 0) {

				/* Removing 5 from branch, in JWT = '5AB', in DB = 'AB' */
				additionalQuery = additionalQuery + " OR rm.branch_number $type ("
						+ pmg.RemoveSquareBrackets(branch_number.toString().replace("\"", "'").replace("'5", "'"))
						+ ")";
			} else {
				additionalQuery = "rm.branch_number $type ("
						+ pmg.RemoveSquareBrackets(branch_number.toString().replace("\"", "'").replace("'5", "'"))
						+ ")";
			}
		}

		/* Changing condition according to requirements */
		if (type.equalsIgnoreCase("entitled")) {
			additionalQuery = additionalQuery.replace("$type", "IN");
		} else
			additionalQuery = additionalQuery.replace("$type", "NOT IN");

		/* formatting additional query in a bracket if we have additional query */
		if (additionalQuery.length() > 0) {
			additionalQuery = "(" + additionalQuery + ")";
		}

		/* final sql query */
		sql = sql + additionalQuery;

		/* RANDOM() and Length */
		sql = sql.concat(" ORDER BY RANDOM() LIMIT " + count);

		return sql;
	}

	public void setCollapsibleHtml(String header, String body) {
		Reporter.addStepLog("<div class=\"card-body\"> <div class=\"card-header\" role=\"tab\"> "
				+ "<h5 class=\"card-title outline-child-child\"> <div class=\"node\">" + header + "</div> </h5> "
				+ "</div> <div class=\"card-body collapse mt-3\">" + body + "</div> </div>");
	}

}
