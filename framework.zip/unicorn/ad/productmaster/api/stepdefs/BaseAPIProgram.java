package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;

import org.owasp.html.examples.EbayPolicyExample;
import org.testng.Assert;

import cucumber.api.java.en.And;
import io.restassured.response.Response;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;
import qa.framework.utils.StringUtility;

public class BaseAPIProgram {

	Response response = EISLBaseAPIGeneric.response;
	String requestJson = EISLBaseAPIGeneric.requestJson;
	String Values = null;
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	ProductMasterGeneric pmg = new ProductMasterGeneric();
	static String Values1 = "";
	String code, name, status, identifier;

	@And("^verify the counts of program w\\.r\\.t\\. request body$")
	public void verify_the_counts_of_program_wrt_request_body() throws Throwable {
		
		String programIds = response.jsonPath().getString("identifier");
		String[] programIdsArr = programIds.split(",");

		 int numberOfProgram = programIdsArr.length; // getting total objects from

		 
		code = StringUtility.getRequestJsonValue(requestJson, "code");
		name = StringUtility.getRequestJsonValue(requestJson, "name");
		status = StringUtility.getRequestJsonValue(requestJson, "status");
		identifier = StringUtility.getRequestJsonValue(requestJson, "identifier");
		String sql = "SELECT count(distinct program_id) FROM program where ";
		String additionalSql = "";

		if (code != null) {

			additionalSql = formSQL(additionalSql, "program_code", code);
			CompareValuesOfRequestinResponse("code",code);

		}
		if (name != null) {
			additionalSql = formSQL(additionalSql, "program_name", name);
			CompareValuesOfRequestinResponse("name",name);
		}

		if (status != null) {

			//additionalSql = formSQL(additionalSql, "status", status);
			CompareValuesOfRequestinResponse("status",status);

		}
		if (identifier != null) {
			additionalSql = formSQL(additionalSql, "program_id", identifier);
			CompareValuesOfRequestinResponse("identifier",identifier);
		}

		sql = sql + additionalSql;
		
		int countFromDB  = ebag.compareCounts(sql, "");
		int countFromAPI = numberOfProgram;
		
		Reporter.addStepLog("Counts from DB: "+countFromDB + " | Counts from API: "+ countFromAPI);
		Assert.assertEquals(countFromDB, countFromAPI,"Count Mismatch..!!");
		
		System.out.println(sql);
	}

	@And("^User fetches Program testdata from DB (.+) and creates JSON file for (.+)$")
	public void User_fetches_testdata_from_DB_for_ETF(String DBAttribute,String Attribute) throws Throwable {
		String[] DBAttribute1 = null;
		String additionalQuery1 = "";
		
		if (DBAttribute != null) {
			ProductMasterDBManager pmdb = new ProductMasterDBManager();
			String additionalQuery = null;
			pmdb.DBConnectionStart();
			String sql = "select " + DBAttribute + " from  Program where " + DBAttribute + " is not null and status=80 order by RANDOM() limit 1";
			if (DBAttribute.contains(",")) {
				DBAttribute1 = DBAttribute.split(",", 0);
				for (String a : DBAttribute1) {
					System.out.println(a);
					additionalQuery = a + " is not null";
					additionalQuery1 = additionalQuery1 + " and ".concat(additionalQuery);
					System.out.println(additionalQuery1);
				}

				additionalQuery1 = additionalQuery1.substring(4);

				sql = "select " + DBAttribute + " from  Program where " + additionalQuery1 + " and status=80 order by RANDOM() limit 1";
				System.out.println(sql);
				ResultSet rs;
				Values1="";
				rs = DBManager.executeSelectQuery(sql);
				while (rs.next()) {
					for (String a : DBAttribute1) {
						System.out.println(a);
						Values = rs.getString(a);
						Reporter.addStepLog("Test data from db for " + DBAttribute + " is :" + Values);
						System.out.println(Values);
					//	Values1 = rs.getString(DBAttribute);
						if (Values.equalsIgnoreCase("82")) {
							Values="INACTIVE";
						}if (Values.equalsIgnoreCase("80")) {
							Values="ACTIVE";
						}
						Values1 = Values1 + ",".concat(Values);
						System.out.println(Values1);
					}
				}

				Values1 = Values1.substring(1);
				System.out.println(Values1);
			} else {
				System.out.println(sql);
				ResultSet rs;
				Values1="";
				rs = DBManager.executeSelectQuery(sql);
				while (rs.next()) {
					Values1 = rs.getString(DBAttribute);
					if (Values1.equalsIgnoreCase("82")) {
						Values1="INACTIVE";
					}if (Values1.equalsIgnoreCase("80")) {
						Values1="ACTIVE";
					}
					Reporter.addStepLog("Test data from db for " + DBAttribute + " is :" + Values1);
					System.out.println(Values1);
					pmdb.DBConnectionClose();
				}
				
			}

		}

	//	return Values1;
		
		ebag.user_creates_a_request_json_file_with_search_keys_and_values(Attribute, Values1);
	}

	
	
	
	
	
	
	String formSQL(String sql, String column, String value) {

		if (sql.length() > 0) {
			sql = sql + " and " + column + " = '" + value + "'";
		} else {
			sql = column + " = '" + value + "'";
		}

		return sql;

	}
	
	void CompareValuesOfRequestinResponse(String jsonPath, String value) {
		String valueFromResponse = response.jsonPath().getString(jsonPath);
		String [] valueFromResponseArr = valueFromResponse.split(",");
		
		for(String n: valueFromResponseArr) {
			Reporter.addStepLog(value + " = " + pmg.RemoveSquareBrackets(n).trim());
			Assert.assertEquals(value, pmg.RemoveSquareBrackets(n).trim());
		}
		
	}

}
