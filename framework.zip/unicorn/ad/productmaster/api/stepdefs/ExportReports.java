package qa.unicorn.ad.productmaster.api.stepdefs;

import java.io.BufferedReader;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.io.FileReader;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.CSVFileUtils;
import qa.framework.utils.ExcelOperation;
import qa.framework.utils.ExcelUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;

public class ExportReports {
	String fileDownloadPath = FileManager.getFileManagerObj().downloadFolderFilePath();
	String exlPath = FileManager.getFileManagerObj().downloadFolderFilePath();
	File tempFile;
	List<String[]> fileData = new ArrayList<String[]>();
	int count = 0;
	List<WebElement> elementsInGrid;
	ExcelUtils exlObj;
	XSSFSheet sheet;
		
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_ManagerEntityPage,AD_PM_StyleEntityPage"));

	public void DeletePreviousFile(String entityName) throws InterruptedException {
		
		fileDownloadPath = fileDownloadPath + "\\" + entityName + ".csv";

		tempFile = new File(fileDownloadPath);

		if (tempFile.exists() == true) {
			Reporter.addStepLog("FILE found at download location - " + fileDownloadPath);
			FileManager.getFileManagerObj().deleteFile(fileDownloadPath);
			Reporter.addStepLog("<b>File Deleted!!!</b>");
		} else {
			Reporter.addStepLog("Download location - " + fileDownloadPath);
			Reporter.addStepLog("FILE not found");
		}
	}
	
	public Boolean VerifyFileDownloaded() throws InterruptedException {
		Boolean flag = false;
		Thread.sleep(1000);

		tempFile = new File(fileDownloadPath);

		if (tempFile.exists() == true) {
			flag = true;
			Reporter.addStepLog("<b>FILE found at download location -</b> " + fileDownloadPath);
		} else {
			Reporter.addStepLog("Download location - " + fileDownloadPath);
			Reporter.addStepLog("FILE not found");
		}

		return flag;
	}
	
	public Boolean verifyDataPresent(String dbKey) throws IOException {
		Boolean flag = false;
		elementsInGrid = action.getElements(dbKey);
		
		/* Setting up CSV file instance */
		fileData = CSVFileUtils.getInstance().readAllCommaSeparatedValues(fileDownloadPath);
		
		BufferedReader bufferedReader = new BufferedReader(new FileReader(fileDownloadPath));

		/* Reading header outside loop, as it is not required while fetching data */
		String input = bufferedReader.readLine();
		
		/* 1. Table Start*/
		Reporter.addStepLog("<table border=1px solid><tr>\r\n" 
				+ "    <th>Name In UI</th>\r\n" 
				+ "    <th>Name In File</th>\r\n"
				+"    </tr>");
		while ((input = bufferedReader.readLine()) != null) {
			/* Getting code and name (line by line) */
			String nameFromFile = CSVFileUtils.getInstance().getValue(fileData, (count+1), 0);
			String nameFromUI = elementsInGrid.get(count).getText();
			
			/* 2. Table Data*/
			Reporter.addStepLog("<tr><td>" + nameFromUI + "</td>\r\n" 
					+ "    <td>" + nameFromFile 
					+ "	   </td></tr>\r\n");
			
			if(nameFromFile.equalsIgnoreCase(nameFromUI)) {
				flag = true;
			} if(flag==false) {
				break;
			}
			count++;
		}
		
		/* 3. Table Close*/
		Reporter.addStepLog("</table></br>");
		return flag;
	}
	
	public Boolean verifyCountInFileAndOnUI() {
		Boolean flag = false;
		Reporter.addStepLog("<b>Number of records in file: </b>"+count);
		Reporter.addStepLog("<b>Number of records on UI: </b>"+elementsInGrid.size());
		if(count==elementsInGrid.size()) {
			flag = true;
		} return flag;
	}
	
	public void CSVtoExcel(String entityName) throws IOException {
		CSVtoExcelConverter conv = new CSVtoExcelConverter();
		exlPath = exlPath + "/Reports.xlsx";
		
    	conv.convertCSVtoExcel(fileDownloadPath, exlPath, entityName);
		
	}
	
	public void verifyAttributes(List<String> expAttributes, String entityName) throws IOException {
		Boolean flag = false;
		System.out.println("path"+exlPath);
		exlObj = new ExcelUtils(ExcelOperation.LOAD, exlPath);
		sheet = exlObj.getSheet(entityName);
		
		for(int n=0;n<expAttributes.size();n++) {
			String actAttribute = exlObj.getStringCellData(sheet, 0, n);
			Reporter.addStepLog("__________________________________________");
			Reporter.addStepLog("<b>Expected: </b>"+expAttributes.get(n));
			Reporter.addStepLog("<b>Actual: </b>"+actAttribute);
			Reporter.addStepLog("__________________________________________");
			//Assert.assertEquals(expAttributes.get(n),actAttribute);
			Assert.assertTrue(actAttribute.contains(expAttributes.get(n)));
		} 
		
		exlObj.closeWorkBook();
	}
	
	public void verifyAttributesData() throws SQLException, IOException {
		exlObj = new ExcelUtils(ExcelOperation.LOAD, "c:/automation/Reports.xlsx");
		sheet = exlObj.getSheet("Manager");
		int matched=0,notMatched = 0;
		
		int lastColumnIndex = exlObj.getRow(sheet, 0).getLastCellNum();
		
			
		DataConversions dc = new DataConversions();
		
		
		System.out.println("lastColumn: "+lastColumnIndex);
		System.out.println("EXL Obj"+exlObj);
		System.out.println("Sheet: "+sheet);
		//exlObj.setCellData(sheet, 0, lastColumnIndex-1, "STATUS");
		
		
		
		ProductMasterDBManager pmdb = new ProductMasterDBManager();
		pmdb.DBConnectionStart();
		
		String sql = "select m.manager_code, m.manager_name, m.firm_name, m.firm_website, m.vestmark_name, m.taxpayer_identification_no," + 
				"				m.large_trader_id, m.dtcc_id, m.status, m.eye_check_override, m.ubs_subsidiary," + 
				"				fs.fee_structure_code, fs.fee_structure_type , fs.fee_structure_name, fs.fee_structure_description," + 
				"				fs.fee_structure_frequency, fs.fee_structure_amount" + 
				"				from manager m " + 
				"				INNER JOIN fee_structure_assoc fsa ON m.manager_id = fsa.reference_id" + 
				"				INNER JOIN fee_structure fs ON fsa.fee_structure_id = fs.fee_structure_id" + 
				"				where lower(m.manager_name) LIKE'%manager20%' or LOWER(m.manager_code) like '%manager20%' and fsa.reference_type = 'MANAGER'";
		
		List<String> expColumn = new ArrayList<String>();
		List<Object> actColumn = new ArrayList<Object>(); 
		
		System.out.println("sql: "+sql);
		
		//System.out.println("RS: "+resultSet);
		
		System.out.println("_____________________________");
		System.out.println("EXL Obj"+exlObj);
		System.out.println("Sheet: "+sheet);
		
		for(int i =0;i<(lastColumnIndex);i++) {
			ResultSet resultSet = DBManager.executeSelectQuery(sql);
			//expColumn=null;
			String columnName = (String) exlObj.getCellData(sheet, 0, i);
			System.out.println(columnName);
			if(!(columnName.equals("STATUS") || columnName.equals("Mismatched for"))) { 
			actColumn =exlObj.getColumnData(sheet, 0, columnName);
			
			if(columnName.equals("feeStructureAmount")) {
				for(int n=0;n<actColumn.size();n++) {
					float f = Float.parseFloat(actColumn.get(n).toString());
					actColumn.clear();
					actColumn.add(f);
					
				}
			}
						
			System.out.println("row in db: "+resultSet.getRow());
			while(resultSet.next()) {
				
				expColumn.add(dc.ExpectedValue(resultSet.getString(i+1)));
				
			} 
			System.out.println("DB: "+ expColumn);
			System.out.println("Excel: "+actColumn);
			
			for(int j=0;j<actColumn.size();j++) {
				String expData = expColumn.get(j);
				if(expData==null) {expData = "null"; }
				
				String actData = actColumn.get(j).toString();
				if(actData.equals(expData)) {
					exlObj.setCellData(sheet, j+1, 17, "MATCHED");
					matched++;
				}else {
					exlObj.setCellData(sheet, j+1, 17, "Not Matched");
					
					String notMatchedFor = (String) exlObj.getCellData(sheet, j+1, 18);
					notMatchedFor = notMatchedFor + "|" +columnName;
					exlObj.setCellData(sheet, j+1, 18, notMatchedFor);
					notMatched++;
					//Assert.assertFalse("Value is not matched at row: "+(j+1)+" and column: "+(i+1),true);
				}
			}
			
			expColumn.clear();
		}
		}
		Reporter.addStepLog("<b>Total Records: </b>"+(matched+notMatched));
		Reporter.addStepLog("<b>Matched: </b>"+matched);
		Reporter.addStepLog("<b>Not Matched: </b>"+notMatched);
		Reporter.addStepLog("<a href=\""+FileManager.getFileManagerObj().downloadFolderFilePath()+"/Reports.xlsx\"> "
				+ "Click Here to see detailed excel report</a>");
		//Adding last column as "Status" and "Mismatched Foe" fields
				exlObj.setCellData(sheet, 0, 17, "STATUS");
				exlObj.setCellData(sheet, 0, 18, "Mismatched for");
		
		exlObj.closeWorkBook();
		pmdb.DBConnectionClose();
		}
}
