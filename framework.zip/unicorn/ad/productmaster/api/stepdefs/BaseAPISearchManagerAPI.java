package qa.unicorn.ad.productmaster.api.stepdefs;

import java.awt.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Connection.Request;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiHelperMethods;

public class BaseAPISearchManagerAPI {
	Response response = EISLBaseAPIGeneric.response;
	String request = EISLBaseAPIGeneric.requestJson;
	JSONObject requestJson = null;
	JSONParser parser = new JSONParser();
	SoftAssert sa = new SoftAssert();
	String columnName = "";
	String apiAttributeName = "";
	int totaldocInResponse = 0;
	int totalContactInResponse = 0;
	Object rRating = "null";
	Object rnodeId = "null";
	int noOfManagersinResponse = 0;
	Object minimumInvestmentAmount=null;
	Object riskCategory=null;
	

	Map<String, String> contactAttributes = new HashMap<String, String>();
	Map<String, String> DocumentAttributes = new HashMap<String, String>();
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	String finalReport = "";
	ProductMasterGeneric pm = new ProductMasterGeneric();
	
	
	
	

	

	@And("^Compare number of contacts linked with manager from API and DB$")
	public void compare_number_of_contacts_linked_with_manager_from_API_and_DB() throws ParseException, SQLException {
		Object contact = "null";
		requestJson = (JSONObject) parser.parse(request);
		if (requestJson.containsKey("includeContact"))
			contact = requestJson.get("includeContact");

		String managerId = response.jsonPath().getString("identifier");
		if (contact.equals("true")) {
			String contactId = response.jsonPath().getString("contacts.contactId");
			String[] managerIdArr = managerId.split(",");
			String[] contactIdArr = contactId.split(",");

			totalContactInResponse = contactIdArr.length;
			for (int i = 0; i < managerIdArr.length; i++) {
				managerId = response.jsonPath().getString("identifier[" + i + "]");

				String sql = "select count (c.contact_id ) from manager m "
						+ "left join contact_assoc ca on reference_id = manager_id  and reference_type = 'MANAGER' "
						+ "left join contact_details cd on cd.contact_id = ca.contact_id "
						+ "left join contact c on c.contact_id = ca.contact_id where m.manager_id = '" + managerId
						+ "'";
				System.out.println(sql);
				int ContactCountInDB = ebag.compareCounts(sql, "");
				Assert.assertEquals(ContactCountInDB, totalContactInResponse);
				Reporter.addStepLog("No. of Contacts for manager ID = " + managerId + " |DB: " + ContactCountInDB
						+ " |API : " + totalContactInResponse);
			}
		} else {

			Assert.assertEquals(0, totalContactInResponse);
			if (contact.toString().equalsIgnoreCase("null")) {
				Reporter.addStepLog("No. of Contacts for manager ID = " + managerId
						+ " |Flag for Contacts in request is not present | Contacts in API : "
						+ totalContactInResponse);

			} else {
				Reporter.addStepLog(
						"No. of Contacts for manager ID = " + managerId + " |Flag for document in request is: "
								+ contact + " | Conatcats in API : " + totalContactInResponse);
			}

		}
	}

	@And("^verify the data received from server for Contacts with Product Master DB$")
	public void verify_the_data_received_from_server_for_something_with_product_master_db() throws Throwable {

		if (totalContactInResponse != 0) {
			/* Getting total number of managers in response */
			String managerId = response.jsonPath().getString("identifier");
			String[] managerIdArr = managerId.split(",");

			/* Setting Mapping */
			SetManagerContactMapping();

			pmdb.DBConnectionStart();

			for (int i = 0; i < managerIdArr.length; i++) {
				managerId = response.jsonPath().getString("identifier[" + i + "]");

				/* Getting total number of contact linked with a manager */
				String contactId = response.jsonPath().getString("contacts.contactId");
				String[] contactIdArr = contactId.split(",");

				for (int j = 0; j < contactIdArr.length; j++) {

					contactId = response.jsonPath().getString("contacts[" + i + "].contactId[" + j + "]");

					String sql = "select c.contact_id, contact_code,contact_code_seq, area,(select list_value from list_values where list_id = type) as type, description, contact_company_name,contact_first_name,contact_last_name, contact_middle_name, contact_nickname, contact_address, contact_city, (select list_value from list_values where list_id = contact_state) as contact_state, (select list_value from list_values where list_id = contact_country) as contact_country, contact_postal_code, (select list_value from list_values where list_id = c.status) as status,contact_title, c.created_on as created_on, c.last_update_on as last_update_on, c.created_by as created_by, c.last_update_by as last_update_by, cd.detail_id, cd.created_by as cd_created_by, cd.last_update_by as cd_last_update_by, (select list_value from list_values where list_id = cd.status) as cd_status, cd.last_update_on as cd_last_update_on, cd.created_on as cd_created_on, cd.phone_number, (select list_value from list_values where list_id = cd.phone_number_type) as phone_number_type, cd.email_address, (select list_value from list_values where list_id = cd.email_address_type) as email_address_type, website_address, (select list_value from list_values where list_id = cd.website_type) as website_type   \r\n"
							+ "from manager m\r\n"
							+ "left join contact_assoc ca on reference_id = manager_id  and reference_type = 'MANAGER'\r\n"
							+ "left join contact_details cd on cd.contact_id = ca.contact_id\r\n"
							+ "left join contact c on c.contact_id = ca.contact_id" + " where m.manager_id = '"
							+ managerId + "' AND c.contact_id = '" + contactId + "'";
					System.out.println(sql);

					for (Map.Entry<String, String> set : contactAttributes.entrySet()) {

						columnName = set.getKey();
						apiAttributeName = set.getValue();

						// if it's directly under contacts
						String completePath = "contacts[" + i + "]." + apiAttributeName + "[" + j + "]";

						// if it's under contacts > contactDetails > attribute
						if (apiAttributeName.contains("contactDetails")) {
							completePath = "contacts[" + i + "]." + apiAttributeName;
							completePath = completePath.replace("contactDetails", "contactDetails[" + j + "]");
						}

						/* fetching from API */
						String apiValue = response.jsonPath().getString(completePath) + "";
						String dbValue = null;

						ResultSet rs = DBManager.executeSelectQuery(sql);

						while (rs.next()) {
							/* fetching from DB */
							dbValue = rs.getString(set.getKey()) + "";

							if ((set.getKey().contains("created_on") || set.getKey().contains("last_update_on"))
									&& !dbValue.equalsIgnoreCase("null")) {
								dbValue = ebag.convertDateToExpectedFormat(dbValue, "");

							}
							System.out.println(completePath + " | " + dbValue + " = " + apiValue);

							if (!dbValue.equalsIgnoreCase("null") && (!apiValue.equalsIgnoreCase("")
									|| !apiValue.isEmpty() || !apiValue.equalsIgnoreCase("null"))) {
								sa.assertEquals(apiValue, dbValue,
										"mismatched for " + completePath + " | managerID:" + managerId);

								if (!apiValue.equals(dbValue)) {
									Reporter.addStepLog("Not matched for manager ID = " + managerId + " | path = "
											+ completePath + "|DB: " + dbValue + " |API : " + apiValue);
								} else {
									finalReport = finalReport + completePath + " | " + dbValue + " = " + apiValue
											+ " </br> ";
								}
							} else {
								finalReport = finalReport + completePath + " | " + dbValue + " = " + apiValue
										+ " </br> ";
							}
						}
					}
				}

			}
			pmdb.DBConnectionClose();
			ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);
			sa.assertAll();
		}
	}

	@And("^Compare number of document linked from API and DB$")
	public void Compare_number_of_document_linked_from_API_and_DB() throws ParseException, SQLException {
		Object doc = "null";
		requestJson = (JSONObject) parser.parse(request);
		/* Getting total number of managers in response */

		if (requestJson.containsKey("includeDocumentEntity"))
			doc = requestJson.get("includeDocumentEntity");
		String managerId = response.jsonPath().getString("identifier");
//		if ( doc.toString().equalsIgnoreCase("null")) { 	
//			Reporter.addStepLog(
//				"No. of documents for manager ID = " + managerId + " |Flag for document in request is not present | document in API : " + totaldocInResponse  );
//		}
		if (doc.equals("true")) {

			String docId = response.jsonPath().getString("documents.identifier");
			docId = pm.RemoveSquareBrackets(docId);
			String[] managerIdArr = managerId.split(",");
			if (!docId.equalsIgnoreCase("")) {
				String[] docIdArr = docId.split(",");
				totaldocInResponse = docIdArr.length;
			}
			for (int i = 0; i < managerIdArr.length; i++) {
				managerId = response.jsonPath().getString("identifier[" + i + "]");

				String sql = "select count (dla.document_id) from manager m "
						+ "left join document_link_assoc dla on reference_id = m.manager_id  and reference_type = 'MANAGER' "
						+ "left join document_link dl on dl.document_id = dla.document_id where m.manager_id = '"
						+ managerId + "'";
				System.out.println(sql);
				int docCountInDB = ebag.compareCounts(sql, "");
				Assert.assertEquals(docCountInDB, totaldocInResponse);
				Reporter.addStepLog("No. of documents for manager ID = " + managerId + " |DB: " + docCountInDB
						+ " |API : " + totaldocInResponse);
			}

		} else {

			Assert.assertEquals(0, totaldocInResponse);
			if (doc.toString().equalsIgnoreCase("null")) {
				Reporter.addStepLog("No. of documents for manager ID = " + managerId
						+ " |Flag for document in request is not present | document in API : " + totaldocInResponse);

			} else {
				Reporter.addStepLog("No. of documents for manager ID = " + managerId
						+ " |Flag for document in request is: " + doc + " | document in API : " + totaldocInResponse);
			}
		}
	}

	@And("^verify the data received from server for Documents with Product Master DB$")
	public void verify_the_data_received_from_server_for_Documents_with_Product_Master_DB() throws Throwable {

		if (totaldocInResponse != 0) {

			String managerId = response.jsonPath().getString("identifier");
			String[] managerIdArr = managerId.split(",");

			SetManagerDocumentMapping();

			pmdb.DBConnectionStart();

			for (int i = 0; i < managerIdArr.length; i++) {
				managerId = response.jsonPath().getString("identifier[" + i + "]");

				/* Getting total number of contact linked with a manager */
				String docId = response.jsonPath().getString("documents.identifier");
				String[] docIdArr = docId.split(",");

				for (int j = 0; j < docIdArr.length; j++) {

					docId = response.jsonPath().getString("documents[" + i + "].identifier[" + j + "]");

					String sql = "select dl.*,(select list_value from list_values where list_id = document_type) as type,\r\n"
							+ "(select list_value from list_values where list_id = dl.status) as lstatus from manager m left join document_link_assoc dla on reference_id = m.manager_id "
							+ "and reference_type = 'MANAGER' left join document_link dl on dl.document_id = dla.document_id"
							+ " where m.manager_id = '" + managerId + "' AND dl.document_id = '" + docId + "'";
					System.out.println(sql);

					for (Map.Entry<String, String> set : DocumentAttributes.entrySet()) {

						columnName = set.getKey();
						apiAttributeName = set.getValue();

						String Path = "documents[" + i + "]." + apiAttributeName + "[" + j + "]";

						String apiValue = response.jsonPath().getString(Path) + "";
						String dbValue = null;

						ResultSet rs = DBManager.executeSelectQuery(sql);

						while (rs.next()) {
							dbValue = rs.getString(set.getKey()) + "";
							if ((set.getKey().contains("created_on") || set.getKey().contains("last_update_on"))
									&& !dbValue.equalsIgnoreCase("null")) {
								dbValue = ebag.convertDateToExpectedFormat(dbValue, "");

							}
							System.out.println(Path + " | " + dbValue + " = " + apiValue);

							if (!dbValue.equalsIgnoreCase("null") && (!apiValue.equalsIgnoreCase("")
									|| !apiValue.isEmpty() || !apiValue.equalsIgnoreCase("null"))) {
								sa.assertEquals(apiValue, dbValue,
										"mismatched for " + Path + " | managerID:" + managerId);

								if (!apiValue.equals(dbValue)) {
									Reporter.addStepLog("Not matched for manager ID = " + managerId + " | path = "
											+ Path + "|DB: " + dbValue + " |API : " + apiValue);
								} else {
									finalReport = finalReport + Path + " | " + dbValue + " = " + apiValue + " </br> ";
								}
							} else {
								finalReport = finalReport + Path + " | " + dbValue + " = " + apiValue + " </br> ";
							}
						}
					}
				}

			}
			pmdb.DBConnectionClose();
			ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);

		}

		sa.assertAll();
	}

	@And("Compare number of managers linked with requested researchRating in API and DB")
	public void compare_number_of_managers_linked_with_requested_researchRating_in_API_and_DB()
			throws ParseException, SQLException {
		int docCountInDB = 0;

		if (response.getStatusCode() == 200) {
			String managerId = "null";
			requestJson = (JSONObject) parser.parse(request);
			if (requestJson.containsKey("researchRating"))
				rRating = requestJson.get("researchRating");
			managerId = response.jsonPath().getString("identifier");
			if (!managerId.equalsIgnoreCase("null")) {
				String[] managerIdArr = managerId.split(",");
				noOfManagersinResponse = managerIdArr.length;

				String sql = "select count(*) from manager where manager_id in (\r\n"
						+ "select manager_id from strategy where research_rating='" + rRating + "')";
				System.out.println(sql);
				docCountInDB = ebag.compareCounts(sql, "");
			}
			Assert.assertEquals(docCountInDB, noOfManagersinResponse);
			Reporter.addStepLog("No. of managers linked with researchRating = " + rRating + " |DB: " + docCountInDB
					+ " |API : " + noOfManagersinResponse);

		} else if (response.getStatusCode() == 404) {
			Assert.assertEquals(0, docCountInDB);
			Reporter.addStepLog("Status Code is 404 as No. of managers linked with researchRating = " + rRating
					+ " |in DB is : " + docCountInDB);

		}
	}
	
	@And("Compare number of managers linked with requested nodeId in API and DB")
	public void compare_number_of_managers_linked_with_requested_nodeId_in_API_and_DB()
			throws ParseException, SQLException {
		int nodeIdInDB = 0;

		if (response.getStatusCode() == 200) {
			String managerId = "null";
			requestJson = (JSONObject) parser.parse(request);
			if (requestJson.containsKey("nodeId"))
				rnodeId = requestJson.get("nodeId");
			managerId = response.jsonPath().getString("identifier");
			if (!managerId.equalsIgnoreCase("null")) {
				String[] managerIdArr = managerId.split(",");
				noOfManagersinResponse = managerIdArr.length;

			
				String sql =	"select count (distinct m.manager_id) from node_id_rollup nir,strategy st,manager m\r\n" + 
						"						where nir.rollup_type_flag = 'F'\r\n" + 
						"						and nir.reference_type='STRATEGY' and nir.reference_id =st.strategy_id \r\n" + 
						"						and st.manager_id=m.manager_id\r\n" + 
						"						and nir.style_node_id='"+rnodeId+"'";
				System.out.println(sql);
				nodeIdInDB = ebag.compareCounts(sql, "");
			}
			Assert.assertEquals(nodeIdInDB, noOfManagersinResponse);
			Reporter.addStepLog("No. of managers linked with nodeId = " + rnodeId + " |DB: " + nodeIdInDB
					+ " |API : " + noOfManagersinResponse);

		} else if (response.getStatusCode() == 404) {
			Assert.assertEquals(0, nodeIdInDB);
			Reporter.addStepLog("Status Code is 404 as No. of managers linked with researchRating = " + rnodeId
					+ " |in DB is : " + nodeIdInDB);

		}
	}

	

	
	@Then("response code for the service API is {string} or {string}")
	public void response_code_for_the_service_API_is_or(String str200, String str404) {
		if (noOfManagersinResponse != 0) {
			/* If status code is not as expected, printing the error/response in Reports */
			if (response.getStatusCode() != Integer.parseInt(str200)) {

				Reporter.addStepLog("<b style=\"color:red\">NOT AS EXPECTED | Response from API is : Response Code - "
						+ response.getStatusCode() + "</b>");

				setCollapsibleHtml("Click here to see response",
						"<p style=\"color:red\">" + response.getBody().asString() + "</p>");

			}else if (response.getStatusCode() == Integer.parseInt(str200)) {
				Reporter.addStepLog("<b style=\"color:green\"> AS EXPECTED | Response from API is : Response Code - "
						+ response.getStatusCode() + "</b>");

				setCollapsibleHtml("Click here to see response",
						"<p style=\"color:black\">" + response.getBody().asString() + "</p>");

				
			}
			
		} else if (noOfManagersinResponse == 0) {
			if (response.getStatusCode() != Integer.parseInt(str404)) {

				Reporter.addStepLog("<b style=\"color:red\">NOT AS EXPECTED | Response from API is : Response Code - "
						+ response.getStatusCode() + "</b>");

				setCollapsibleHtml("Click here to see response",
						"<p style=\"color:red\">" + response.getBody().asString() + "</p>");

			} else if (response.getStatusCode() == Integer.parseInt(str404)) {
				Reporter.addStepLog(
						"<b style=\"color:green\"> AS EXPECTED ,NO DATA PRESENT IN DB | Response from API is : Response Code - "
								+ response.getStatusCode() + "</b>");

			}

		} else {
			setCollapsibleHtml("Click here to see response", response.getBody().asString());
			// Reporter.addStepLog("<b>Response Body:</b> " +
			// response.getBody().asString());
			/* Verifying response code */
			RestApiHelperMethods.verfiyStatusCode(response, Integer.parseInt(str200));
		}

	

	}

	
	@And("Compare number of managers linked with requested minimumInvestmentAmount in API and DB")
	public void compare_number_of_managers_linked_with_requested_minimumInvestmentAmount_in_API_and_DB()
			throws ParseException, SQLException {
		int amountCountInDB = 0;
		
		if (response.getStatusCode() == 200) {
			String managerId = "null";
			requestJson = (JSONObject) parser.parse(request);
			
			if (requestJson.containsKey("minimumInvestmentAmount"))
				minimumInvestmentAmount  = requestJson.get("minimumInvestmentAmount");
			managerId = response.jsonPath().getString("identifier");
			if (!managerId.equalsIgnoreCase("null")) {
				String[] managerIdArr = managerId.split(",");
				noOfManagersinResponse = managerIdArr.length;

				String sql = "select count(*) from manager where manager_id in (\r\n"
						+ "select manager_id from strategy where strategy_minimum<='" + minimumInvestmentAmount + "')";
				System.out.println(sql);
				amountCountInDB = ebag.compareCounts(sql, "");
			}
			Assert.assertEquals(amountCountInDB, noOfManagersinResponse);
			Reporter.addStepLog("No. of managers linked with minimumInvestmentAmount = " + minimumInvestmentAmount + " |DB: " + amountCountInDB
					+ " |API : " + noOfManagersinResponse);

		} else if (response.getStatusCode() == 404) {
			Assert.assertEquals(0, noOfManagersinResponse);
			Reporter.addStepLog("Status Code is 404 as No. of managers linked with minimumInvestmentAmount = " + minimumInvestmentAmount
					+ " |in DB is : " + noOfManagersinResponse);

		}
	}
	
	
	@And("verify the data received from server for minimumInvestmentAmount with Product Master DB")
	public void verify_the_data_received_from_server_for_minimumInvestmentAmount_with_Product_Master_DB() throws SQLException {

		String sql = "select manager_id from manager where manager_id in (\r\n"
				+ "select manager_id from strategy where strategy_minimum<='" + minimumInvestmentAmount + "')";
		System.out.println(sql);
		pmdb.DBConnectionStart();
		String dbmanagerID = null;
		String managerId = null;
		ResultSet rs = DBManager.executeSelectQuery(sql);

		ArrayList<String> DBVal = new ArrayList<String>();
		ArrayList<String> APIVal = new ArrayList<String>();
		int j = 0;
		while (rs.next()) {
			dbmanagerID = rs.getString("manager_Id");
			managerId = response.jsonPath().getString("identifier[" + j + "]");
			System.out.println("ManagerIds : | DB:" + dbmanagerID + " = API: " + managerId);

			DBVal.add(j, dbmanagerID);
			
			APIVal.add(j, managerId);
			
			j++;
		}
		Collections.sort(DBVal);
		Collections.sort(APIVal);
		for (int i = 0; i < DBVal.size(); i++) {
			sa.assertEquals(DBVal.get(i), APIVal.get(i), " managerID:" + managerId);

			if (!DBVal.get(i).equals(APIVal.get(i))) {
				Reporter.addStepLog("Not matched for manager ID = " + APIVal.get(i) + "|DB: " + (DBVal.get(i))
						+ " |API : " + APIVal.get(i));
			} else {
				finalReport = finalReport + "ManagerIds : | DB:" + (DBVal.get(i)) + " = API :" + APIVal.get(i)
						+ " </br> ";
			}

		}

		ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);
		pmdb.DBConnectionClose();
		sa.assertAll();
	}
	
	
	@And("verify the data received from server for Research Rating with Product Master DB")
	public void verify_the_data_received_from_server_for_Research_Rating_with_Product_Master_DB() throws SQLException {

		String sql = "select manager_id from manager where manager_id in (\r\n"
				+ "select manager_id from strategy where research_rating='" + rRating + "')";
		System.out.println(sql);
		pmdb.DBConnectionStart();
		String dbmanagerID = null;
		String managerId = null;
		ResultSet rs = DBManager.executeSelectQuery(sql);

		ArrayList<String> DBVal = new ArrayList<String>();
		ArrayList<String> APIVal = new ArrayList<String>();
		int j = 0;
		while (rs.next()) {
			dbmanagerID = rs.getString("manager_Id");
			managerId = response.jsonPath().getString("identifier[" + j + "]");
			System.out.println("ManagerIds : | DB:" + dbmanagerID + " = API: " + managerId);

			DBVal.add(j, dbmanagerID);
			
			APIVal.add(j, managerId);
			
			j++;
		}
		Collections.sort(DBVal);
		Collections.sort(APIVal);
		for (int i = 0; i < DBVal.size(); i++) {
			sa.assertEquals(DBVal.get(i), APIVal.get(i), " managerID:" + managerId);

			if (!DBVal.get(i).equals(APIVal.get(i))) {
				Reporter.addStepLog("Not matched for manager ID = " + APIVal.get(i) + "|DB: " + (DBVal.get(i))
						+ " |API : " + APIVal.get(i));
			} else {
				finalReport = finalReport + "ManagerIds : | DB:" + (DBVal.get(i)) + " = API :" + APIVal.get(i)
						+ " </br> ";
			}

		}

		ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);
		pmdb.DBConnectionClose();
		sa.assertAll();
	}

	 
	@And("Compare number of managers linked with requested riskCategory in API and DB")
	public void compare_number_of_managers_linked_with_requested_riskCategory_in_API_and_DB()
			throws ParseException, SQLException {
		int riskCountInDB = 0;
		
		if (response.getStatusCode() == 200) {
			String managerId = "null";
			requestJson = (JSONObject) parser.parse(request);
			
			if (requestJson.containsKey("riskCategory"))
				riskCategory  = requestJson.get("riskCategory");
			managerId = response.jsonPath().getString("identifier");
			if (!managerId.equalsIgnoreCase("null")) {
				String[] managerIdArr = managerId.split(",");
				noOfManagersinResponse = managerIdArr.length;

String sql = "select count(*) from manager where manager_id in (select manager_id from strategy where risk_category in "
		+ " (select list_id from list_values where list_type='RISK' and list_code <='"+riskCategory+"' and list_code!='0'))";
				System.out.println(sql);
				riskCountInDB = ebag.compareCounts(sql, "");
			}
			Assert.assertEquals(riskCountInDB, noOfManagersinResponse);
			Reporter.addStepLog("No. of managers linked with RiskCategory = " + riskCategory + " |DB: " + riskCountInDB
					+ " |API : " + noOfManagersinResponse);

		} else if (response.getStatusCode() == 404) {
			Assert.assertEquals(0, noOfManagersinResponse);
			Reporter.addStepLog("Status Code is 404 as No. of managers linked with RiskCategory = " + riskCategory
					+ " |in DB is : " + noOfManagersinResponse);

		}
	}
	
	@And("verify the data received from server for riskCategory with Product Master DB")
	public void verify_the_data_received_from_server_for_riskCategory_with_Product_Master_DB() throws SQLException {

		String sql = "select manager_id from manager where manager_id in (select manager_id from strategy where risk_category in "
				+ " (select list_id from list_values where list_type='RISK' and list_code <='"+riskCategory+"' and list_code!='0'))";
						System.out.println(sql);
		pmdb.DBConnectionStart();
		String dbmanagerID = null;
		String managerId = null;
		ResultSet rs = DBManager.executeSelectQuery(sql);

		ArrayList<String> DBVal = new ArrayList<String>();
		ArrayList<String> APIVal = new ArrayList<String>();
		int j = 0;
		while (rs.next()) {
			dbmanagerID = rs.getString("manager_Id");
			managerId = response.jsonPath().getString("identifier[" + j + "]");
			System.out.println("ManagerIds : | DB:" + dbmanagerID + " = API: " + managerId);

			DBVal.add(j, dbmanagerID);
			
			APIVal.add(j, managerId);
			
			j++;
		}
		Collections.sort(DBVal);
		Collections.sort(APIVal);
		for (int i = 0; i < DBVal.size(); i++) {
			sa.assertEquals(DBVal.get(i), APIVal.get(i), " managerID:" + managerId);

			if (!DBVal.get(i).equals(APIVal.get(i))) {
				Reporter.addStepLog("Not matched for manager ID = " + APIVal.get(i) + "|DB: " + (DBVal.get(i))
						+ " |API : " + APIVal.get(i));
			} else {
				finalReport = finalReport + "ManagerIds : | DB:" + (DBVal.get(i)) + " = API :" + APIVal.get(i)
						+ " </br> ";
			}

		}

		ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);
		pmdb.DBConnectionClose();
		sa.assertAll();
	}
	
	
	@And("verify FoaCodes for given Manager")
	public void verify_FoaCodes_for_given_Manager() throws ParseException, SQLException {
		Object FoaCodes=null;
		String FoaCodesRes=null;
		requestJson = (JSONObject) parser.parse(request);
		if (requestJson.containsKey("foaCodes"))
			FoaCodes = requestJson.get("foaCodes");
		String managerId = response.jsonPath().getString("identifier");
		String[] managerIdArr = managerId.split(",");
		String[] FoaCodeArr = null;
		ArrayList<String> DBVal = new ArrayList<String>();

		pmdb.DBConnectionStart();

		/* Checking number of total strategies in response */
		for (int countParent = 0; countParent < managerIdArr.length; countParent++) {
		
			managerId = response.jsonPath().getString("identifier[" + countParent + "]");
			FoaCodesRes = response.jsonPath().getString("foaCodes[" + countParent + "]");
			//FoaCodeArr = FoaCodesRes.split(",");
			
			if (FoaCodes !=null) {
				FoaCodes=FoaCodes.toString().replace("[", "");
				FoaCodes=FoaCodes.toString().replace("]", "");
				FoaCodes=FoaCodes.toString().replace("\"", "'");
		String	sql= "SELECT strategy_code FROM strategy WHERE manager_id = '"+managerId+"' and strategy_code in ("+FoaCodes+")";
		System.out.println(sql);
		ResultSet rs = DBManager.executeSelectQuery(sql);
		while (rs.next()) {
			
			String dbValue = rs.getString("strategy_code");
			DBVal.add(dbValue);
		}
			

		sa.assertTrue(FoaCodesRes.contains(DBVal.toString()),"FoaCodes are matching in API and DB:"+DBVal);
		
		Reporter.addStepLog("Matched for manager ID = " + managerId + "|DB: " + DBVal
				+ " |API : " +FoaCodesRes);
			
			
		DBVal.clear();
	
			}else {
				String	sql= "SELECT strategy_code FROM strategy WHERE manager_id = '"+managerId+"'";
				System.out.println(sql);
				ResultSet rs = DBManager.executeSelectQuery(sql);
				while (rs.next()) {
					
					String dbValue = rs.getString("strategy_code");
					DBVal.add(dbValue);}
				sa.assertTrue(FoaCodesRes.contains(DBVal.toString()),"FoaCodes are matching in API and DB:"+DBVal);
				
				Reporter.addStepLog("Matched for manager ID = " + managerId + "|DB: " + DBVal
						+ " |API : " +FoaCodesRes);
				
					
				DBVal.clear();
			}

		}

		pmdb.DBConnectionClose();
		sa.assertAll();
		
	}


	
	void SetManagerContactMapping() {

		/* db column name, api attribute name */
		contactAttributes.put("contact_id", "contactId");
		contactAttributes.put("contact_code", "code");
		contactAttributes.put("contact_code_seq", "sequenceNumber");
		contactAttributes.put("area", "area");
		contactAttributes.put("type", "type");
		contactAttributes.put("description", "description");
		contactAttributes.put("contact_company_name", "companyName");
		contactAttributes.put("contact_first_name", "firstName");
		contactAttributes.put("contact_last_name", "lastName");
		contactAttributes.put("contact_middle_name", "middleName");
		contactAttributes.put("contact_nickname", "nickName");
		contactAttributes.put("contact_address", "address");
		contactAttributes.put("contact_city", "city");
		contactAttributes.put("contact_state", "state");
		contactAttributes.put("contact_postal_code", "postalCode");
		contactAttributes.put("contact_country", "countryCode");
		contactAttributes.put("status", "status");
		contactAttributes.put("created_by", "createdBy");
		contactAttributes.put("last_update_by", "lastUpdateBy");
		contactAttributes.put("created_on", "createdOnString");
		contactAttributes.put("last_update_on", "lastUpdateOnString");
		contactAttributes.put("contact_title", "title");

		/* contact details */
		contactAttributes.put("detail_id", "contactDetails.detailID[0]");
		contactAttributes.put("cd_status", "contactDetails.status[0]");
		contactAttributes.put("cd_created_by", "contactDetails.createdBy[0]");
		contactAttributes.put("cd_last_update_by", "contactDetails.lastUpdateBy[0]");
		contactAttributes.put("phone_number_type", "contactDetails.phoneNumberType[0]");
		contactAttributes.put("phone_number", "contactDetails.phoneNumber[0]");
		contactAttributes.put("email_address_type", "contactDetails.emailAddressType[0]");
		contactAttributes.put("email_address", "contactDetails.emailAddress[0]");
		contactAttributes.put("website_type", "contactDetails.websiteType[0]");
		contactAttributes.put("website_address", "contactDetails.websiteAddress[0]");
		contactAttributes.put("cd_created_on", "contactDetails.createdOnString[0]");
		contactAttributes.put("cd_last_update_on", "contactDetails.lastUpdateOnString[0]");

	}

	void SetManagerDocumentMapping() {

		DocumentAttributes.put("document_id", "identifier");
		DocumentAttributes.put("document_code", "code");
		DocumentAttributes.put("document_description", "description");
		DocumentAttributes.put("document_link", "link");
		DocumentAttributes.put("lstatus", "status");
		DocumentAttributes.put("type", "type");
		DocumentAttributes.put("created_by", "createdBy");
		DocumentAttributes.put("last_update_by", "lastUpdateBy");
		DocumentAttributes.put("created_on", "createdOnString");
		DocumentAttributes.put("last_update_on", "lastUpdateOnString");

	}

	public void setCollapsibleHtml(String header, String body) {
		Reporter.addStepLog("<div class=\"card-body\"> <div class=\"card-header\" role=\"tab\"> "
				+ "<h5 class=\"card-title outline-child-child\"> <div class=\"node\">" + header + "</div> </h5> "
				+ "</div> <div class=\"card-body collapse mt-3\">" + body + "</div> </div>");
	}
}
