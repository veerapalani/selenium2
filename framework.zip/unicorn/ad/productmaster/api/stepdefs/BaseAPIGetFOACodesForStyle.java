package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

@SuppressWarnings("deprecation")
public class BaseAPIGetFOACodesForStyle {

	String styleIdReqVal = null, foaCodesReqVal = null, faIdsReqVal = null, statusReqVal = null;
	JSONObject requestJson = null;
	JSONParser parser = new JSONParser();
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	SoftAssert sa = new SoftAssert();
	ProductMasterGeneric pmg = new ProductMasterGeneric();

	@And("^verify the \"([^\"]*)\" name for given strategy in response for getfoacodesforstyle$")
	public void verify_the_something_name_for_given_strategy_in_response_for_getfoacodesforstyle(String notInUse)
			throws Throwable {

		String strategyCodeAPI = EISLBaseAPIGeneric.response.jsonPath().getString("code");

		String reportingNameAct = "", programCodesAct = "";
		String reportingNameExp = "";

		String[] strategyCodeAPIArr = strategyCodeAPI.split(",");
		String[] programCodesAPIArr = null;

		pmdb.DBConnectionStart();

		/* Checking number of total strategies in response */
		for (int countParent = 0; countParent < strategyCodeAPIArr.length; countParent++) {
			strategyCodeAPI = EISLBaseAPIGeneric.response.jsonPath().getString("code[" + countParent + "]");
			programCodesAct = EISLBaseAPIGeneric.response.jsonPath()
					.getString("reportingStrategyNames[" + countParent + "].programCode");
			programCodesAPIArr = programCodesAct.split(",");
			
			/*
			 * Checking number of total programs/reporting name with a strategy one strategy
			 * can have multiple names (eg: linked with 36 and 46 program)
			 */
			for (int countChild = 0; countChild < programCodesAPIArr.length; countChild++) {
				reportingNameAct = EISLBaseAPIGeneric.response.jsonPath().getString(
						"reportingStrategyNames[" + countParent + "]" + ".reportingStrategyName[" + countChild + "]");

				programCodesAct = EISLBaseAPIGeneric.response.jsonPath()
						.getString("reportingStrategyNames[" + countParent + "]" + ".programCode[" + countChild + "]");

				reportingNameExp = ebag.GenerateReportingStratageyName(strategyCodeAPI, programCodesAct);

				Reporter.addStepLog("------------------------- " + strategyCodeAPI + " | " + programCodesAct
						+ " -----------------------------");
				Reporter.addStepLog("<b>Expected (Database): </b>" + reportingNameExp);
				Reporter.addStepLog("<b>Actual (API): </b>" + reportingNameAct);
				Reporter.addStepLog("-------------------------------------------------------------------------");

				sa.assertEquals(reportingNameAct, reportingNameExp,
						"Values not matched for strategy code: " + strategyCodeAPI);

				System.out.println("Checked for strategy code: " + strategyCodeAPI);

			}

		}

		pmdb.DBConnectionClose();
		sa.assertAll();
	}

	@When("^user fetches and create request JSON with styleId, foaCodes and status as \"([^\"]*)\"$")
	public void user_fetches_and_create_request_json_with_styleid_foacodes_and_status_as_something(String statusVal)
			throws Throwable {

		/*
		 * if passing only single status -> Eligible multiple status will be like ->
		 * 'Eligible', 'Ineligible','Rejected'
		 */

		if (!statusVal.contains("'")) {
			statusVal = "'" + statusVal + "'";
		}

		/* fetching foaCodes and styleIds related to status passed in FF */
		String sql = "SELECT s.style_id, strategy_code, random() FROM strategy s, style st, program_strategy ps, program p\r\n"
				+ "WHERE st.style_id = s.style_id AND ps.program_id = p.program_id AND s.strategy_id = ps.strategy_id AND \r\n"
				+ "p.program_code = '12' AND  s.strategy_id in (select strategy_id from strategy_financial_advisor)"
				+ " s.status IN (SELECT list_id FROM list_values WHERE lower(list_value) IN ("
				+ statusVal.toLowerCase() 
				+ ")) AND st.client_id = 1 and s.client_id = 1 and p.client_id = 1 ORDER BY random() LIMIT 1";
		String styleId = null;
		String foaCode = null;

		pmdb.DBConnectionStart();

		ResultSet rs = DBManager.executeSelectQuery(sql);

		while (rs.next()) {
			styleId = (rs.getString("style_id"));
			foaCode = (rs.getString("strategy_code"));
		}

		System.out.println("StyleId: " + styleId + " | FoaCode: " + foaCode);

		if (styleId == null && foaCode == null) {

			/*
			 * if data for that particular status is not available in DB, passing random
			 * styleId and foaCodes
			 */
			Reporter.addStepLog("<b>Data not available for status '" + statusVal + "'.</b>");
			ebag.user_creates_a_request_json_file_with_search_keys_and_values("styleIds,foaCodes,status",
					"[1];[\"XYZZ\"];[" + statusVal.replace("'", "\"") + "]");

		} else {
			ebag.user_creates_a_request_json_file_with_search_keys_and_values("styleIds,foaCodes,status",
					"[\"" + styleId + "\"];[\"" + foaCode + "\"];[" + statusVal.replace("'", "\"") + "]");
		}

		pmdb.DBConnectionClose();
		ebag.setCollapsibleHtml("click here to see SQL Query", sql);

	}

	/* to store entitled and not entitled styleIds and foaCodes */
	List<String> styleIds = new ArrayList<String>();
	List<String> foaCodes = new ArrayList<String>();

	@When("^user selects \"([^\"]*)\" number of \"([^\"]*)\" foaCodes and styleId from PM DB$")
	public void user_selects_something_number_of_something_foacodes_and_styleid_from_pm_db(int count, String type)
			throws Throwable {

		JSONArray repCodes = BaseAPIGetStrategyDetails.repCodes, branch = BaseAPIGetStrategyDetails.branch;

		/*
		 * Nullifying so that list will be ready for new set of codes for next
		 * scenarios.
		 */
		foaCodes.clear();
		styleIds.clear();

		pmdb.DBConnectionStart();

		String sqlQuery = GetSQLwithBrnanchAndRepCodes(repCodes, branch, count, type);

		ResultSet rs_pmp = DBManager.executeSelectQuery(sqlQuery);

		while (rs_pmp.next()) {
			foaCodes.add(rs_pmp.getString("strategy_code"));
			styleIds.add(rs_pmp.getString("style_id"));
		}

		pmdb.DBConnectionClose();

		/* Printing in reports */
		Reporter.addStepLog("</br><b>" + type + " foaCodes are:</b>");

		for (String code : foaCodes) {
			Reporter.addStepLog(code);
		}

		/* Printing in reports */
		Reporter.addStepLog("</br><b>" + type + " styleIds are:</b>");

		for (String id : styleIds) {
			Reporter.addStepLog(id);
		}

	}

	@And("^user creates a request JSON file with \"([^\"]*)\" foaCodes and styleIds$")
	public void user_creates_a_request_json_file_with_something_foacodes_and_styleids(String strArg1) throws Throwable {
		String foaCode = "", styleId = "";

		for (String code : foaCodes) {

			foaCode = foaCode + "\"" + code + "\"";
		}

		for (String id : styleIds) {
			styleId = styleId + "\"" + id + "\"";
		}

		/* formatting "S051""AD0L""IA41" -> ["S051","AD0L","IA41"]; */
		foaCode = foaCode.replace("\"\"", "\",\"");
		styleId = styleId.replace("\"\"", "\",\"");

		foaCode = "[" + foaCode + "];";
		styleId = "[" + styleId + "];";

		System.out.println("FOA Codes: " + foaCode);
		System.out.println("Style IDs: " + styleId);

		ebag.user_creates_a_request_json_file_with_search_keys_and_values("styleIds, foaCodes", styleId + foaCode);
	}

	@When("^user creates a request JSON with \"([^\"]*)\" number of \"([^\"]*)\" styles$")
	public void user_creates_a_request_json_with_something_number_of_something_styles(int count, String type)
			throws Throwable {
		String styleId = "";

		String sql = "SELECT distinct s.style_id, random() FROM strategy s, style st, program_strategy ps, "
				+ "program p WHERE p.program_id = ps.program_id AND ps.strategy_id = s.strategy_id AND s.style_id = st.style_id "
				+ "AND st.program_id = p.program_id AND p.program_code ### ('12') AND st.client_id = 1 and s.client_id = 1 and p.client_id = 1 ORDER BY random() LIMIT " + count;

		if (type.equalsIgnoreCase("SMA")) {

			sql = sql.replace("###", "not in");

		} else if (type.equalsIgnoreCase("PMP")) {
			sql = sql.replace("###", "in");
		} else {
			sql = "( " + sql.replace("###", "in")
					+ ") UNION ( SELECT distinct s.style_id, random() from strategy s, style st, program_strategy ps, "
					+ "program p WHERE p.program_id = ps.program_id AND ps.strategy_id = s.strategy_id AND s.style_id = st.style_id "
					+ "AND st.program_id = p.program_id AND p.program_code IN ('15') AND st.client_id = 1 and s.client_id = 1 and p.client_id = 1 ORDER BY random() LIMIT " + count
					+ " ) ";
		}

		pmdb.DBConnectionStart();
		System.out.println("SQL: " + sql);
		ResultSet rs = DBManager.executeSelectQuery(sql);

		while (rs.next()) {
			if (styleId.length() > 0) {
				styleId = styleId + "\",\"" + rs.getString("style_id");
			} else
				styleId = rs.getString("style_id");
		}

		pmdb.DBConnectionClose();

		/* formatting styleId to be used as request parameter */
		styleId = "[\"" + styleId + "\"]";

		System.out.println(count + " STYLE ID: " + styleId);
		ebag.setCollapsibleHtml("click here to see SQL Query", sql);

		ebag.user_creates_a_request_json_file_with_search_keys_and_values("styleIds", styleId + ";");
	}

	@And("^the counts of foa codes and codes linked with given style in response is same as in DB$")
	public void the_counts_of_foa_codes_linked_with_given_style_in_response_is_same_as_in_db() throws Throwable {

		List<String> foaCodeFromDB = new ArrayList<String>();
		List<String> foaCodesFromAPIButNotInDB = new ArrayList<String>();

		/* getting request JSON from generic class */
		requestJson = (JSONObject) parser.parse(EISLBaseAPIGeneric.requestJson);

		int dbCount = 0, apiCount = 0;

		/*
		 * fetching request attribute's values so that we can pass it in SQL query and
		 * get the counts and codes from DB
		 */
		if (requestJson.containsKey("styleIds")) {
			styleIdReqVal = requestJson.get("styleIds").toString().replace("[", "").replace("]", "").replace("\"", "'");
		}

		String sql = "SELECT distinct strategy_code FROM strategy s\r\n"
				+ "LEFT JOIN style st ON s.style_id = st.style_id\r\n"
				+ "LEFT JOIN strategy_financial_advisor sfa ON sfa.strategy_id = s.strategy_id\r\n"
				+ "LEFT JOIN financial_advisor fa ON fa.fa_id = sfa.fa_id\r\n"
				+ "LEFT JOIN program_strategy ps ON ps.strategy_id = s.strategy_id\r\n"
				+ "LEFT JOIN program p ON p.program_id = ps.program_id " + "WHERE s.status NOT IN \r\n"
				+ "(SELECT list_id FROM list_values WHERE lower(list_value) IN ('rejected','pending ho approval','draft','pending','source daad'))"
				+ " AND st.style_id IN (" + styleIdReqVal + ") AND p.program_code = '12' "
						+ " and st.client_id = 1 and s.client_id = 1 and p.client_id = 1 and fa.client_id = 1";

		/*
		 * fetching request attribute's values so that we can pass it in SQL query and
		 * get the counts and codes from DB
		 */
		if (requestJson.containsKey("status")) {
			statusReqVal = requestJson.get("status").toString().replace("[", "").replace("]", "").replace("\"", "'");
			sql = sql + " AND (s.status IN (SELECT list_id FROM list_values WHERE list_value IN (" + statusReqVal
					+ ")))";
		}

		if (requestJson.containsKey("foaCodes")) {
			foaCodesReqVal = requestJson.get("foaCodes").toString().replace("[", "").replace("]", "").replace("\"",
					"'");
			sql = sql + " AND (s.strategy_code IN (" + foaCodesReqVal + "))";
		}

		if (requestJson.containsKey("faIds")) {
			faIdsReqVal = requestJson.get("faIds").toString().replace("[", "").replace("]", "").replace("\"", "'");
			sql = sql + " AND (fa.fa_id IN (" + faIdsReqVal + "))";
		}

		pmdb.DBConnectionStart();

		System.out.println("SQL: " + sql);
		ebag.setCollapsibleHtml("SQL Used: ", sql);

		ResultSet rs = DBManager.executeSelectQuery(sql);

		while (rs.next()) {
			dbCount++;
			foaCodeFromDB.add(rs.getString("strategy_code"));
		}

		pmdb.DBConnectionClose();

		/* fetching number of objects from response, "code" is unique identifier. */
		String strategyCode = EISLBaseAPIGeneric.response.jsonPath().getString("code");
		String[] foaCodeFromAPI = strategyCode.split(",");

		apiCount = foaCodeFromAPI.length;

		for (String code : foaCodeFromDB) {
			if (!foaCodeFromDB.contains(code)) {
				sa.assertTrue(false, code + " not found in expected List.");
				foaCodesFromAPIButNotInDB.add(code);
			}
		}

		/* Printing in Reports */
		Reporter.addStepLog("<b>Counts from DB:</b> " + dbCount);
		Reporter.addStepLog("<b>Counts from API:</b> " + apiCount);

		/* printing only if list is not null */
		if (foaCodesFromAPIButNotInDB.size() > 0) {
			ebag.setCollapsibleHtml("Click here to see FOA Codes from DB", foaCodeFromDB.toString());
			ebag.setCollapsibleHtml("Click here to see Mismatched FOA Codes", foaCodesFromAPIButNotInDB.toString());
		} else
			Reporter.addStepLog("------------------------------------------------------------------------------ "
					+ "</br><b>All FOA Codes from API is matched with expected FOA Codes from DB</b>");

		ebag.setCollapsibleHtml("click here to see SQL Query", sql);

		/* nullifying lists */
		foaCodeFromDB.clear();
		foaCodesFromAPIButNotInDB.clear();

		sa.assertEquals(dbCount, apiCount, "Count Mismatched..!!");
		sa.assertAll();

	}

	/**
	 * FUNCTION GetSQLwithBrnanchAndRepCodes
	 * 
	 * @param rr_code
	 * @param branch_number
	 * @param count
	 * @param type
	 * @return String sql
	 */

	String GetSQLwithBrnanchAndRepCodes(JSONArray rr_code, JSONArray branch_number, int count, String type) {

		String sql = "SELECT distinct st.style_id, strategy_code, random() FROM strategy s, style st, financial_advisor fa, program p, program_strategy ps, strategy_financial_advisor sfa, rr_mapping rm\r\n"
				+ "WHERE s.style_id = st.style_id AND s.strategy_id = ps.strategy_id AND p.program_id = ps.program_id AND sfa.strategy_id = s.strategy_id\r\n"
				+ " AND sfa.fa_id = fa.fa_id AND fa.fa_code = rm.fa_code AND st.client_id = 1 and s.client_id = 1 AND p.client_id = 1 and fa.client_id = 1 and  p.program_code = '12' AND ";

		String additionalQuery = "";

		if (rr_code.size() > 0) {
			additionalQuery = "rm.rr_code $type (" + pmg.RemoveSquareBrackets(rr_code.toString().replace("\"", "'"))
					+ ")";

		}

		if (branch_number.size() > 0) {
			if (additionalQuery.length() > 0) {

				/* Removing 5 from branch, in JWT = '5AB', in DB = 'AB' */
				additionalQuery = additionalQuery + " AND rm.branch_number $type ("
						+ pmg.RemoveSquareBrackets(branch_number.toString().replace("\"", "'").replace("'5", "'"))
						+ ")";
			} else {
				additionalQuery = "rm.branch_number $type ("
						+ pmg.RemoveSquareBrackets(branch_number.toString().replace("\"", "'").replace("'5", "'"))
						+ ")";
			}
		}

		/* Changing condition according to requirements */
		if (type.equalsIgnoreCase("entitled")) {
			additionalQuery = additionalQuery.replace("$type", "IN");
		} else
			additionalQuery = additionalQuery.replace("$type", "NOT IN");

		/* formatting additional query in a bracket if we have additional query */
		if (additionalQuery.length() > 0) {
			additionalQuery = "(" + additionalQuery + ")";
		}

		/* final sql query */
		sql = sql + additionalQuery;

		/* RANDOM() and Length */
		sql = sql.concat(" ORDER BY RANDOM() LIMIT " + count);

		return sql;

	}

}
