package qa.unicorn.ad.productmaster.api.stepdefs;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;
import io.restassured.response.Response;
import junit.framework.Assert;
import qa.framework.dbutils.DBManager;
import qa.framework.utils.Reporter;

@SuppressWarnings("deprecation")
public class BaseAPISearchStrategyAPI {
	JSONParser parser = new JSONParser();
	JSONObject requestJson = null;
	Response response = EISLBaseAPIGeneric.response;
	String requestJsonStr = EISLBaseAPIGeneric.requestJson;
	ProductMasterGeneric pmg = new ProductMasterGeneric();
	ProductMasterDBManager pmdb = new ProductMasterDBManager();
	EISLBaseAPIGeneric ebag = new EISLBaseAPIGeneric();
	String jwtToken = EISLBaseAPIGeneric.jwtToken;
	static JSONArray repCodes = null, branch = null, entitlements = null;
	List<String> strategyCodes = new ArrayList<String>();
	Map<String, String> BenchmarkAttributesAndDBColumns = new HashMap<String, String>();
	Map<String, String> contactAttributes = new HashMap<String, String>();
	Map<String, String> CommentAttributes = new HashMap<String, String>();
	int totalCommentInResponse=0;
	int totalContactInResponse=0;
	String columnName = "";
	String apiAttributeName = "";
	String finalReport = "";
	String finalReport1 = "";
	int totalnodeIdInResponseUn=0;
	int totalnodeIdInResponseBundled=0;
	Map<String, String> BundledNodeIdAttributes = new HashMap<String, String>();

	String srvcName = null;
	String user = null;

	SoftAssert sa = new SoftAssert();
	int count = 0;

	@And("^verify the reportingStrategyName name for given strategy$")
	public void verify_the_something_name_for_given_strategy() throws Throwable {

		
		String strategyCodeAPI = EISLBaseAPIGeneric.response.jsonPath().getString("code");
		String reportingNameAct = "", programCodesAct = "";
		String reportingNameExp = "";

		String[] strategyCodeAPIArr = strategyCodeAPI.split(",");
		String[] programCodesAPIArr = null;

		pmdb.DBConnectionStart();

		/* Checking number of total strategies in response */
		for (int countParent = 0; countParent < strategyCodeAPIArr.length; countParent++) {
			strategyCodeAPI = EISLBaseAPIGeneric.response.jsonPath().getString("code[" + countParent + "]");
			programCodesAct = EISLBaseAPIGeneric.response.jsonPath()
					.getString("reportingStrategyNames[" + countParent + "].programCode");
			programCodesAPIArr = programCodesAct.split(",");

			/*
			 * Checking number of total programs/reporting name with a strategy one strategy
			 * can have multiple names (eg: linked with 36 and 46 program)
			 */
			for (int countChild = 0; countChild < programCodesAPIArr.length; countChild++) {
				reportingNameAct = EISLBaseAPIGeneric.response.jsonPath().getString(
						"reportingStrategyNames[" + countParent + "]" + ".reportingStrategyName[" + countChild + "]");

				programCodesAct = EISLBaseAPIGeneric.response.jsonPath()
						.getString("reportingStrategyNames[" + countParent + "]" + ".programCode[" + countChild + "]");

				reportingNameExp = ebag.GenerateReportingStratageyName(strategyCodeAPI, programCodesAct);

				Reporter.addStepLog("------------------------- " + strategyCodeAPI + " | " + programCodesAct
						+ " -----------------------------");
				Reporter.addStepLog("<b>Expected (Database): </b>" + reportingNameExp);
				Reporter.addStepLog("<b>Actual (API): </b>" + reportingNameAct);
				Reporter.addStepLog("-------------------------------------------------------------------------");

				sa.assertEquals(reportingNameAct, reportingNameExp,
						"Values not matched for strategy code: " + strategyCodeAPI);

				System.out.println("Checked for strategy code: " + strategyCodeAPI);

			}

		}

		pmdb.DBConnectionClose();
		sa.assertAll();
	}
	
	
	@And("^Validate the benchmark data in response for searchstrategyapi$")
	public void checkstyleids() throws ParseException, SQLException {

		String selectedBenchmarkDB = null;
		SoftAssert sa = new SoftAssert();

		/* getting all styleIds from response */
		String styleIdAPIAll = EISLBaseAPIGeneric.response.body().jsonPath().getString("identifier");
		String[] styleIdAPIArr = styleIdAPIAll.split(",");

		/* iterating each object */
		for (int i = 0; i < styleIdAPIArr.length; i++) {

			/* fetching defaultBenchmark OR customBenchmark from API response */
			String defaultBenchmarkAPI = EISLBaseAPIGeneric.response.body().jsonPath()
					.getString("benchmarks[" + i + "]");
			
			String benchmarkIdsAPI = null;
			

			requestJson = (JSONObject) parser.parse(EISLBaseAPIGeneric.requestJson);

				String styleIdAPI = pmg.RemoveSquareBrackets(styleIdAPIArr[i]);

				String sqlQuery = "select (select list_value from list_values where list_id = s.selected_benchmark_type) as ben_type from strategy s where s.strategy_id = "
						+ " " + styleIdAPI;

				pmdb.DBConnectionStart();

				ResultSet rs = DBManager.executeSelectQuery(sqlQuery);

				/* getting selected_benchmark_type from DB */
				while (rs.next()) {
					selectedBenchmarkDB = rs.getString("ben_type");
				}

				/* expected list of benchmarkIds */
				ArrayList<String> benchmarkIdsDB = new ArrayList<String>();

				
					
					benchmarkIdsAPI = EISLBaseAPIGeneric.response.body().jsonPath()
							.getString("benchmarks[" + i + "].identifier");

				

				String[] benchmarkIdsAPIArr = benchmarkIdsAPI.split(",");

				/* Getting benchmarkIds from DB to validate */
				if (selectedBenchmarkDB.equals("Custom")) {
					sqlQuery = "select benchmark_id from benchmark_assoc where reference_id = " + styleIdAPI
							+ " and reference_type = 'STRATEGY' and benchmark_category in"
							+ " (select list_id from list_values where list_value = '" + selectedBenchmarkDB + "')";
				} else {
					sqlQuery = "select nib.benchmark_id from node_id_rollup nir, node_id_benchmark nib, style s where\r\n"
							+ "s.style_id = nir.reference_id and nir.reference_type = 'STRATEGY' and nir.style_node_id = nib.style_node_id\r\n"
							+ "and nir.effective_to_date is null and nib.effective_to_date is null and nir.rollup_type_flag = 'F' and s.style_id = '"
							+ styleIdAPI + "'";
				}
				rs = DBManager.executeSelectQuery(sqlQuery);
				System.out.println(sqlQuery);

				while (rs.next()) {
					benchmarkIdsDB.add(rs.getString("benchmark_id"));
				}

				/* Checking counts expected(from DB) and actual(from API) */

				Reporter.addStepLog("<b>Expected Counts(from DB): </b>" + benchmarkIdsDB.size());
				Reporter.addStepLog("<b>Actual Counts(from API): </b>" + benchmarkIdsAPIArr.length);

				/* Hard Assert - Fails, if count mismatch */
				if (benchmarkIdsAPIArr.length != benchmarkIdsDB.size()) {
					Assert.assertTrue("Count Mismatched.", false);
				}

				/* if counts are equal, checking benchmark ID and data */
				for (int j = 0; j < benchmarkIdsAPIArr.length; j++) {

					/* if id mismatch, no need to match benchmark data */
					if (!benchmarkIdsDB.contains(pmg.RemoveSquareBrackets(benchmarkIdsAPIArr[i]))) {
						sa.assertTrue(false, pmg.RemoveSquareBrackets(benchmarkIdsAPIArr[i])
								+ " benchmarkId is not in expected list.");
						Reporter.addStepLog((benchmarkIdsAPIArr[i]) + " benchmarkId is not in expected list.");

						sa.assertAll();
						/* if everything is alright, checking benchmark data */
					} else {
						if (selectedBenchmarkDB.equals("Custom")) {
							sqlQuery = "select distinct b.created_on, b.last_update_on, ba.effective_from_date, b.created_by, b.last_update_by, ba.benchmark_id, c.client_name, c.client_code,\r\n"
									+ "b.client_id, b.benchmark_code,\r\n"
									+ "(select list_value from list_values where list_id = b.benchmark_classification) as benchmark_classification, \r\n"
									+ "(select list_value from list_values where list_id = b.benchmark_type) as benchmark_type, b.benchmark_name, b.benchmark_description, ba.percentage, \r\n"
									+ "(select list_value from list_values where list_id = b.status) as status, \r\n"
									+ "(select list_value from list_values where list_id = ba.benchmark_category) as benchmark_category, b.data_source from benchmark b\r\n"
									+ "inner join benchmark_assoc ba on ba.benchmark_id = b.benchmark_id\r\n"
									+ "inner join strategy s on s.strategy_id = ba.reference_id and ba.reference_type = 'STRATEGY'\r\n"
									+ "inner join client c on c.client_id = b.client_id\r\n" + "where ba.benchmark_id ="
									+ pmg.RemoveSquareBrackets(benchmarkIdsAPIArr[i]) + " and s.strategy_id = "
									+ styleIdAPI + " \r\n"
									+ "and ba.benchmark_category = (select list_id from list_values where list_value = '"
									+ selectedBenchmarkDB + "')";
						} else {
							sqlQuery = "select distinct b.created_on, b.last_update_on, nib.effective_from_date, b.created_by, b.last_update_by, b.benchmark_id,\r\n"
									+ "						c.client_name, c.client_code,b.client_id, b.benchmark_code,\r\n"
									+ "						(select list_value from list_values where list_id = b.benchmark_classification) as benchmark_classification,\r\n"
									+ "						(select list_value from list_values where list_id = b.benchmark_type) as benchmark_type, b.benchmark_name, b.benchmark_description,\r\n"
									+ "						b.percentage, (select list_value from list_values where list_id = b.status) as status,\r\n"
									+ "						(select list_value from list_values where list_id = s.selected_benchmark_type) as benchmark_category, b.data_source\r\n"
									+ "						from benchmark b\r\n"
									+ "						inner join node_id_benchmark nib on nib.benchmark_id = b.benchmark_id and nib.effective_to_date is null\r\n"
									+ "						inner join node_id_rollup nir on nir.style_node_id = nib.style_node_id and nir.effective_to_date is null and nir.rollup_type_flag = 'F'\r\n"
									+ "						inner join strategy s on s.strategy_id = nir.reference_id and nir.reference_type = 'STRATEGY'\r\n"
									+ "						inner join client c on c.client_id = b.client_id where nib.benchmark_id = "
									+ pmg.RemoveSquareBrackets(benchmarkIdsAPIArr[i]) + " and s.strategy_id = "
									+ styleIdAPI;
						}

						ebag.setCollapsibleHtml("SQL Query", sqlQuery);

						/* Setting up mapping */
						SetBenchmarkMapping(selectedBenchmarkDB);

						for (Map.Entry<String, String> set : BenchmarkAttributesAndDBColumns.entrySet()) {
							String apiAttributeName = set.getKey();

							/* replacing parent and child count */
							apiAttributeName = apiAttributeName.replace("[i]", "[" + i + "]").replace("[j]",
									"[" + j + "]");

							String columnName = set.getValue();

							/* fetching from API */
							String apiValue = EISLBaseAPIGeneric.response.body().jsonPath().getString(apiAttributeName)
									+ "";
							String dbValue = null;

							rs = DBManager.executeSelectQuery(sqlQuery);

							while (rs.next()) {
								/* fetching from DB */
								dbValue = rs.getString(columnName) + "";

								if ((columnName.contains("created_on") || columnName.contains("last_update_on"))
										&& !dbValue.equalsIgnoreCase("null")) {
									dbValue = ebag.convertDateToExpectedFormat(dbValue, "");
								}

								if ((columnName.contains("effective_from_date") && !dbValue.equalsIgnoreCase("null"))) {
									dbValue = ebag.convertDateToExpectedFormat(dbValue, "").substring(0, 10);
								}

								if ((columnName.contains("percentage") && !dbValue.equalsIgnoreCase("null"))) {
									int index = dbValue.indexOf('.');
									if (index >= 0) {
										dbValue = dbValue.substring(0, index + 2);
									}
								}

								Reporter.addStepLog(apiAttributeName + ": <b>Actual -</b> " + apiValue
										+ " | <b>Expected -</b> " + dbValue);
								sa.assertEquals(apiValue, dbValue, "Value Mismatch for " + apiAttributeName + ".");
							}
						}
					}
				}

				pmdb.DBConnectionClose();

				sa.assertAll();
			
		}

	}	

	
	void SetBenchmarkMapping(String benchmarkType) {
		
			benchmarkType = "benchmarks[i].";

		BenchmarkAttributesAndDBColumns.put(benchmarkType + "identifier[j]", "benchmark_id");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "code[j]", "benchmark_code");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "name[j]", "benchmark_name");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "description[j]", "benchmark_description");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "percentage[j]", "percentage");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "benchmarkSourceType[j]", "data_source");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "benchmarkCategory[j]", "benchmark_category");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "createdBy[j]", "created_by");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "lastUpdateBy[j]", "last_update_by");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "clientReference[j]", "client_name");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "clientReferenceType[j]", "client_code");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "clientReferenceID[j]", "client_id");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "classificationCode[j]", "benchmark_classification");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "type[j]", "benchmark_type");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "status[j]", "status");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "lastUpdateOnString[j]", "last_update_on");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "createdOnString[j]", "created_on");
		BenchmarkAttributesAndDBColumns.put(benchmarkType + "effectiveDateString[j]", "effective_from_date");
	}

	
	@And("^Compare number of comment linked from API and DB$")
	public void Compare_number_of_document_linked_from_API_and_DB() throws ParseException, SQLException {
		Object comment = "null";
		requestJson = (JSONObject) parser.parse(requestJsonStr);
		/* Getting total number of managers in response */
		ProductMasterGeneric pm = new ProductMasterGeneric();
		if (requestJson.containsKey("includeComments"))
			comment = requestJson.get("includeComments");
		String strategyId = response.jsonPath().getString("identifier");

		if (comment.toString().equalsIgnoreCase("true")) {

			String commentId = response.jsonPath().getString("comments.identifier");
			commentId = pm.RemoveSquareBrackets(commentId);
			String[] strategyIdArr = strategyId.split(",");
			if (!commentId.equalsIgnoreCase("")) {
				String[] commentIdArr = commentId.split(",");
				totalCommentInResponse = commentIdArr.length;
			}
			for (int i = 0; i < strategyIdArr.length; i++) {
				strategyId = response.jsonPath().getString("identifier[" + i + "]");

				String sql = "select count (comment_id) from comment where reference_type='STRATEGY' and reference_id ='"+strategyId+"'";
				System.out.println(sql);
				int commentCountInDB = ebag.compareCounts(sql, "");
				Assert.assertEquals(commentCountInDB, totalCommentInResponse);
				Reporter.addStepLog("No. of comments for strategy ID = " + strategyId + " |DB: " + commentCountInDB
						+ " |API : " + totalCommentInResponse);
			}

		} else {

			Assert.assertEquals(0, totalCommentInResponse);
			if (comment.toString().equalsIgnoreCase("null")) {
				Reporter.addStepLog("No. of comments for straegy ID = " + strategyId
						+ " |Flag for comment in request is not present | document in API : " + totalCommentInResponse);

			} else {
				Reporter.addStepLog("No. of comment for strategy ID = " + strategyId
						+ " |Flag for comment in request is: " + comment + " | comment in API : " + totalCommentInResponse);
			}
		}
	}

	@And("^verify the data received from server for comments with Product Master DB$")
	public void verify_the_data_received_from_server_for_comments_with_Product_Master_DB() throws Throwable {

		if (totalCommentInResponse != 0) {

			String strategyId = response.jsonPath().getString("identifier");
			String[] strategyIdArr = strategyId.split(",");

			SetCommentMapping();

			pmdb.DBConnectionStart();

			for (int i = 0; i < strategyIdArr.length; i++) {
				strategyId = response.jsonPath().getString("identifier[" + i + "]");
				String commentId = response.jsonPath().getString("comments.identifier");
				String[] commentIdArr = commentId.split(",");

				for (int j = 0; j < commentIdArr.length; j++) {

					commentId = response.jsonPath().getString("comments[" + i + "].identifier[" + j + "]");

					String sql = "select *,(select list_value from list_values where list_id = status) as lstatus, "
							+ "(select list_value from list_values where list_id = comment_type) as type "
							+ " from comment where reference_type='STRATEGY' and reference_id ='"+strategyId+"'"
							+ " and comment_id='"+commentId+"'";
					System.out.println(sql);

					for (Map.Entry<String, String> set : CommentAttributes.entrySet()) {

						columnName = set.getKey();
						apiAttributeName = set.getValue();

						String Path = "comments[" + i + "]." + apiAttributeName + "[" + j + "]";

						String apiValue = response.jsonPath().getString(Path) + "";
						String dbValue = null;

						ResultSet rs = DBManager.executeSelectQuery(sql);

						while (rs.next()) {
							dbValue = rs.getString(set.getKey()) + "";
							if ((set.getKey().contains("created_on") || set.getKey().contains("last_update_on"))
									&& !dbValue.equalsIgnoreCase("null")) {
								dbValue = ebag.convertDateToExpectedFormat(dbValue, "");

							}
							System.out.println(Path + " | " + dbValue + " = " + apiValue);

							if (!dbValue.equalsIgnoreCase("null") && (!apiValue.equalsIgnoreCase("")
									|| !apiValue.isEmpty() || !apiValue.equalsIgnoreCase("null"))) {
								sa.assertEquals(apiValue, dbValue,
										"mismatched for " + Path + " |strategy ID:" + strategyId);

								if (!apiValue.equals(dbValue)) {
									Reporter.addStepLog("Not matched for strategy ID = " + strategyId + " | path = "
											+ Path + "|DB: " + dbValue + " |API : " + apiValue);
								} else {
									finalReport = finalReport + Path + " | " + dbValue + " = " + apiValue + " </br> ";
								}
							} else {
								finalReport = finalReport + Path + " | " + dbValue + " = " + apiValue + " </br> ";
							}
						}
					}
				}

			}
			pmdb.DBConnectionClose();
			ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);

		}
		
		
		

		sa.assertAll();
	}
	
	
	
	void SetCommentMapping() {

		CommentAttributes.put("comment_id", "identifier");
		CommentAttributes.put("comment", "comments");
		CommentAttributes.put("reference_type", "referenceType");
		CommentAttributes.put("lstatus", "status");
		CommentAttributes.put("type", "type");
		CommentAttributes.put("created_by", "createdBy");
		CommentAttributes.put("last_update_by", "lastUpdateBy");
		CommentAttributes.put("created_on", "createdOnString");
		CommentAttributes.put("last_update_on", "lastUpdateOnString");

	}
	
	
	@And("^Compare number of contact linked from API and DB$")
	public void Compare_number_of_contact_linked_from_API_and_DB() throws ParseException, SQLException {
		Object contact = "null";
		requestJson = (JSONObject) parser.parse(requestJsonStr);
		/* Getting total number of managers in response */
		ProductMasterGeneric pm = new ProductMasterGeneric();
		if (requestJson.containsKey("includeContacts"))
			contact = requestJson.get("includeContacts");
		String strategyId = response.jsonPath().getString("identifier");

		if (contact.toString().equalsIgnoreCase("true")) {

			String contactId = response.jsonPath().getString("contactIds");
			//Object contactId1=response.jsonPath().getString("contactIds");
			contactId = pm.RemoveSquareBrackets(contactId);
			String[] strategyIdArr = strategyId.split(",");
			String[] contactIdArr = null;
			if (!contactId.equalsIgnoreCase("")) {
				 contactIdArr = contactId.split(",");
				totalContactInResponse = contactIdArr.length;
			
			}
			ArrayList<String> apiValue=new ArrayList<>();
			ArrayList<String> dbValue=new ArrayList<>();
			for (int i = 0; i < strategyIdArr.length; i++) {
				strategyId = response.jsonPath().getString("identifier[" + i + "]");
				   
				 
				String sql = "select count(contact_id) from contact_assoc where reference_id='"+strategyId+"'";
				System.out.println(sql);
				int contactCountInDB = ebag.compareCounts(sql, "");
				Assert.assertEquals(contactCountInDB, totalContactInResponse);
				Reporter.addStepLog("No. of contact for strategy ID = " + strategyId + " |DB: " + contactCountInDB
						+ " |API : " + totalContactInResponse);
				}
			
			if (totalContactInResponse != 0) {

				//SetCommentMapping();
				pmdb.DBConnectionStart();

				for (int i = 0; i < strategyIdArr.length; i++) {
					strategyId = response.jsonPath().getString("identifier[" + i + "]");
				
					
						String sql = "select (contact_id) from contact_assoc where reference_id='"+strategyId+"' order by contact_id ASC";
						System.out.println(sql);
							ResultSet rs = DBManager.executeSelectQuery(sql);
                            int k=0;
                        
                            String dbValue1 =null;
     						while (rs.next()) {
								 dbValue1 = rs.getString("contact_id") + "";
								  apiValue.add(contactIdArr[k]);
								  dbValue.add(dbValue1);
								  
								  k++;
							}
     						Collections.sort(apiValue);
     						Collections.sort(dbValue);
									if (apiValue.toString().contains(dbValue.toString())) {
										Reporter.addStepLog("Not matched for strategy ID = " + strategyId  + "|DB: " + dbValue + " |API : " + apiValue);
									} else {
										finalReport = finalReport  +" | " + dbValue + " = " + apiValue + " </br> ";
									}
							
				}
				pmdb.DBConnectionClose();
				ebag.setCollapsibleHtml("click here to see MATCHED Attributes", finalReport);

			}
			
		}else {

			Assert.assertEquals(0, totalContactInResponse);
			if (contact.toString().equalsIgnoreCase("null")) {
				Reporter.addStepLog("No. of contact for straegy ID = " + strategyId
						+ " |Flag for contact in request is not present | contact in API : " + totalContactInResponse);

			} else {
				Reporter.addStepLog("No. of contact for strategy ID = " + strategyId
						+ " |Flag for contact in request is: " + contact + " | contact in API : " + totalContactInResponse);
			}
		}
		sa.assertAll();
	}	
	
	
	
	@And("^Compare number of nodeIds for strategy linked from API and DB$")
	public void Compare_number_of_linked_from_API_and_DB() throws ParseException, SQLException {
		
		
			String strategyId = response.jsonPath().getString("identifier");
				String nodeId = response.jsonPath().getString("unbundledNodeIds.nodeID");
				String bundlednodeId = response.jsonPath().getString("bundledNodeIds.nodeID");
				// nodeId = pm.RemoveSquareBrackets(nodeId);
				String[] strategyIdArr = strategyId.split(",");
				if (!nodeId.equalsIgnoreCase("") && !nodeId.equalsIgnoreCase("[[]]")) {
					String[] nodeIdArr = nodeId.split(",");
					totalnodeIdInResponseUn = nodeIdArr.length;
				}
				if (!bundlednodeId.equalsIgnoreCase("") && !bundlednodeId.equalsIgnoreCase("[[]]")) {
					String[] nodeIdArr1 = bundlednodeId.split(",");
					totalnodeIdInResponseBundled = nodeIdArr1.length;
				}
				String sql=null;String sqlBundled=null;String sqlBundled1=null;
				
				for (int i = 0; i < strategyIdArr.length; i++) {
					strategyId = response.jsonPath().getString("identifier[" + i + "]");
					
String investmentType= response.jsonPath().getString("investmentType");
if (investmentType.equalsIgnoreCase("[SMA]")) {
					 sql = "select count(style_node_id) from node_id_rollup where reference_type='STRATEGY' and reference_id='"
							+ strategyId + "'" + " and rollup_type_flag='P'";
					
					 sqlBundled = "select count(style_node_id) from node_id_rollup where reference_type='STRATEGY' and reference_id='"
							+ strategyId + "'" + " and rollup_type_flag='F'";
					
					 sqlBundled1 = "select count(style_node_id) from node_id_rollup where reference_type='STYLE' and reference_id in "
							+ "(select style_id from strategy where strategy_id='" + strategyId + "'" + " and rollup_type_flag='F')";
}else {
	 sql = "select count(style_node_id) from node_id_rollup where reference_type='STYLE' and reference_id "
	 		+ " in (select style_id from strategy where strategy_id='"+strategyId+"') and rollup_type_flag='P'";
	 
	 sqlBundled = "select count(style_node_id) from node_id_rollup where reference_type='STYLE' and reference_id "
			 + " in (select style_id from strategy where strategy_id='"+strategyId+"')and rollup_type_flag='F'";
	 
	 sqlBundled1="select count(style_node_id) from node_id_rollup where reference_type='XYZ'";
}
					System.out.println(sql);
					int nodeIdCountInDB = ebag.compareCounts(sql, "");
					sa.assertEquals(nodeIdCountInDB, totalnodeIdInResponseUn);
					Reporter.addStepLog("No. of unbundledNodeId for strategyId = " + strategyId + " |DB: " + nodeIdCountInDB
							+ " |API : " + totalnodeIdInResponseUn);
					
					System.out.println(sqlBundled);
					int nodeIdCountInDBBundled = ebag.compareCounts(sqlBundled, "");
					int nodeIdCountInDBBundled1 = ebag.compareCounts(sqlBundled1, "");
					int total=nodeIdCountInDBBundled+nodeIdCountInDBBundled1;
					sa.assertEquals(total, totalnodeIdInResponseBundled);
					Reporter.addStepLog("No. of bundledNodeId for strategyId = " + strategyId + " |DB: " + total
							+ " |API : " + totalnodeIdInResponseBundled);
					
				}
	
sa.assertAll();
	}
	
	@And("^verify the data received from server for Bundled with Product Master DB for Strategy$")
	public void verify_the_data_received_from_server_for_Documents_with_Product_Master_DB_for_strategy() throws Throwable {
		String investmentType= response.jsonPath().getString("investmentType");
		
		if (totalnodeIdInResponseBundled != 0) {

			String strategyId = response.jsonPath().getString("identifier");
			String[] styleIdArr = strategyId.split(",");
			
			SetBundledNodeIdMapping();
			String sql =null;
			pmdb.DBConnectionStart();
				for (int i = 0; i < styleIdArr.length; i++) {
					strategyId = response.jsonPath().getString("identifier[" + i + "]");

					String BundledNodeID = response.jsonPath().getString("bundledNodeIds.nodeID");
					String[] BundledNodeIDArr = BundledNodeID.split(",");

					for (int j = 0; j < BundledNodeIDArr.length; j++) {

						BundledNodeID = response.jsonPath().getString("bundledNodeIds[" + i + "].nodeID[" + j + "]");
					if (investmentType.equalsIgnoreCase("SMA")) {
						 sql = "select case  when effective_to_date is not null " + 
								"then effective_from_date else (select max(effective_to_date) from node_id_rollup where reference_type='STRATEGY' "
								+ "and reference_id='"+strategyId+"' and rollup_type_flag='F' " + 
								" ) End As effective_to_date1, style_node_id,percentage,rollup_type_flag from node_id_rollup where reference_type='STYLE' and reference_id in (select style_id from strategy where strategy_id='"+strategyId+"') and style_node_id='"+BundledNodeID+"'" + 
								"Union \r\n" + 
								"select effective_from_date as effective_to_date1,style_node_id,percentage,rollup_type_flag from node_id_rollup where reference_type='STRATEGY' and reference_id='"+strategyId+"' and rollup_type_flag='F' and style_node_id='"+BundledNodeID+"'" + 
								"";
					}else {
						 sql = "select effective_from_date as effective_to_date1,style_node_id,percentage,rollup_type_flag  from node_id_rollup where reference_type='STYLE' "
								+ "and reference_id in (select style_id from strategy where strategy_id='"+strategyId+"') and rollup_type_flag='F' and style_node_id='"+BundledNodeID+"'";
						
					}
						System.out.println(sql);

						for (Map.Entry<String, String> set : BundledNodeIdAttributes.entrySet()) {

							columnName = set.getKey();
							apiAttributeName = set.getValue();

							String Path = "bundledNodeIds[" + i + "]." + apiAttributeName + "[" + j + "]";
							
							String apiValue = EISLBaseAPIGeneric.response.jsonPath().getString(Path) + "";
							String dbValue = null;
							String dbValue11 = null;

							ResultSet rs = DBManager.executeSelectQuery(sql);

							while (rs.next()) {
								dbValue = rs.getString(set.getKey()) + "";
								if ((set.getKey().contains("effective") && !dbValue.equalsIgnoreCase("null"))) {

									dbValue11 = ebag.convertDateToExpectedFormat(dbValue, "");
									dbValue11 = dbValue11.substring(0, 10);

								}
								if ((set.getKey().contains("percentage") && !dbValue.equalsIgnoreCase("null"))) {
									int index = dbValue.indexOf('.');
									if (index >= 0) {
										dbValue11 = dbValue.substring(0, index + 2);
									} else {
										dbValue11 = dbValue;
									}

								}
								
								if ((set.getKey().contains("style_node_id")  && !dbValue.equalsIgnoreCase("null"))) {
									dbValue11 = dbValue;
								}
								System.out.println(Path + " | " + dbValue11 + " = " + apiValue);

								if (!dbValue11.equalsIgnoreCase("null") && (!apiValue.equalsIgnoreCase("")
										|| !apiValue.isEmpty() || !apiValue.equalsIgnoreCase("null"))) {
									sa.assertEquals(apiValue, dbValue11,
											"mismatched for " + Path + " | strategyId:" + strategyId);

									if (!apiValue.equals(dbValue11)) {
										Reporter.addStepLog("Not matched for BundledNodeID = " + BundledNodeID
												+ " | path = " + Path + "|DB: " + dbValue11 + " |API : " + apiValue);
									} else {
										finalReport = finalReport + Path + " | " + BundledNodeID + " | " + dbValue11
												+ " = " + apiValue + " </br> ";
									}
								} else {
									finalReport = finalReport + Path + " | " + dbValue11 + " = " + apiValue + " </br> ";
								}
							}
						}
					}

				}

			
			pmdb.DBConnectionClose();
			ebag.setCollapsibleHtml("click here to see MATCHED Attributes for BundledNodeId", finalReport);
		}
		
		if (totalnodeIdInResponseUn != 0) {
		
			String strategyId = response.jsonPath().getString("identifier");
			String[] styleIdArr = strategyId.split(",");

			SetBundledNodeIdMapping();

			pmdb.DBConnectionStart();
				for (int i = 0; i < styleIdArr.length; i++) {
					strategyId = response.jsonPath().getString("identifier[" + i + "]");

					String unbundledNodeIds = response.jsonPath().getString("unbundledNodeIds.nodeID");
					String[] unBundledNodeIDArr = unbundledNodeIds.split(",");

					for (int j = 0; j < unBundledNodeIDArr.length; j++) {
						String sql = null;
						unbundledNodeIds = response.jsonPath().getString("unbundledNodeIds[" + i + "].nodeID[" + j + "]");
						if (investmentType.equalsIgnoreCase("SMA")) {
						 sql = "select effective_from_date as effective_to_date1,style_node_id,percentage,rollup_type_flag  from node_id_rollup where reference_type='STRATEGY' "
								+ "and reference_id='"+strategyId+"' and rollup_type_flag='P' and style_node_id='"+unbundledNodeIds+"'";
						}else {
							sql = "select effective_from_date as effective_to_date1,style_node_id,percentage,rollup_type_flag  from node_id_rollup where reference_type='STYLE' "
									+ "and reference_id in (select style_id from strategy where strategy_id='"+strategyId+"') and rollup_type_flag='P' and style_node_id='"+unbundledNodeIds+"'";
						
						}
						System.out.println(sql);

						for (Map.Entry<String, String> set : BundledNodeIdAttributes.entrySet()) {

							columnName = set.getKey();
							apiAttributeName = set.getValue();

							String Path = "unbundledNodeIds[" + i + "]." + apiAttributeName + "[" + j + "]";
							
							String apiValue = EISLBaseAPIGeneric.response.jsonPath().getString(Path) + "";
							String dbValue = null;
							String dbValue11 = null;

							ResultSet rs = DBManager.executeSelectQuery(sql);

							while (rs.next()) {
								dbValue = rs.getString(set.getKey()) + "";
								if ((set.getKey().contains("effective") && !dbValue.equalsIgnoreCase("null"))) {

									dbValue11 = ebag.convertDateToExpectedFormat(dbValue, "");
									dbValue11 = dbValue11.substring(0, 10);

								}
								if ((set.getKey().contains("percentage") && !dbValue.equalsIgnoreCase("null"))) {
									int index = dbValue.indexOf('.');
									if (index >= 0) {
										dbValue11 = dbValue.substring(0, index + 2);
									} else {
										dbValue11 = dbValue;
									}

								}
								
								if ((set.getKey().contains("style_node_id")  && !dbValue.equalsIgnoreCase("null"))) {
									dbValue11 = dbValue;
								}
								System.out.println(Path + " | " + dbValue11 + " = " + apiValue);

								if (!dbValue11.equalsIgnoreCase("null") && (!apiValue.equalsIgnoreCase("")
										|| !apiValue.isEmpty() || !apiValue.equalsIgnoreCase("null"))) {
									sa.assertEquals(apiValue, dbValue11,
											"mismatched for " + Path + " | strategyId:" + strategyId);

									if (!apiValue.equals(dbValue11)) {
										Reporter.addStepLog("Not matched for UnBundledNodeID = " + unbundledNodeIds
												+ " | path = " + Path + "|DB: " + dbValue11 + " |API : " + apiValue);
									} else {
										finalReport1 = finalReport1 + Path + " | " + unbundledNodeIds + " | " + dbValue11
												+ " = " + apiValue + " </br> ";
									}
								} else {
									finalReport1 = finalReport1 + Path + " | " + dbValue11 + " = " + apiValue + " </br> ";
								}
							}
						}
					}

				}

			
			pmdb.DBConnectionClose();
			ebag.setCollapsibleHtml("click here to see MATCHED Attributes for UnbundledId", finalReport1);
		}
		
		
		
		
		

		sa.assertAll();
	}
	void SetBundledNodeIdMapping() {
		BundledNodeIdAttributes.put("style_node_id", "nodeID");
		BundledNodeIdAttributes.put("percentage", "rollupPercentage");
		BundledNodeIdAttributes.put("effective_to_date1", "effectiveFromString");
	}
	
}


