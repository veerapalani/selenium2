package qa.unicorn.ad.productmaster.api.stepdefs;

import org.testng.Assert;  

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import io.restassured.response.Response;
import qa.framework.utils.CommonAPISteps;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;

/**
 * 
 * @author PatelNim
 *
 */
public class EISLJwtAndCorrelationId {

	PropertyFileUtils property = new PropertyFileUtils("./application.properties");
	CommonAPISteps common = new CommonAPISteps();
	String expCorrelationId="";
	String baseURI = ProductMasterGeneric.postBaseURI;

	@And("^user set (.+) jwt token in headers$")
	public void user_set_jwt_token_in_headers(String flag) throws Throwable {

		/* if not blank, then add Authorization token in headers */ 
		if (!flag.equalsIgnoreCase("blank")) {
			String token = property.getProperty("jwtToken");

			/* Setting Authorization in headers for current end points */
			common.user_set_header_something_as_something_for_current_endpoint("Authorization", token);
		}
		
		/* Setting EISL in headers for current end points */
		common.user_set_header_something_as_something_for_current_endpoint("EISL", "true");
	}

	@And("^user is able to see error as \"(.+)\" in response$")
	public void user_is_able_to_see_error_inresponse(String expErrorMessage) {
		Response response = ProductMasterGeneric.response;

		String actErrorMessage = response.jsonPath().getString("message");
		Reporter.addStepLog("<b>Error Message Received:</b> " + actErrorMessage);
		Reporter.addStepLog("<b>Expected Error Message::</b> " + expErrorMessage);

		if (!actErrorMessage.equalsIgnoreCase(expErrorMessage)) {
			Reporter.addStepLog("<p style=\"color:red\"><b>Response: </b>" + response.asString() + "</p>");
		}

		Assert.assertEquals(actErrorMessage, expErrorMessage);
	}
	
	@And("^user set correlationId as \"([^\"]*)\"$")
	public void user_set_correlation_id_as(String correlationId) {
		expCorrelationId = correlationId;
		
		common.user_set_header_something_as_something_for_current_endpoint("correlationId", expCorrelationId);
	}
	
	@Then("^user is able to see (.+) correlation id in response headers$")
	public void user_is_able_to_see_jwt_token_in_response(String newOrOld) {
		Response response = ProductMasterGeneric.response;
		
		String actCorrelationId = response.getHeader("correlationId");
		
		if(newOrOld.equalsIgnoreCase("old")) {
			Reporter.addStepLog("<b>Actual Value: </b>"+ actCorrelationId);
			Reporter.addStepLog("<b>Expected Value: </b>"+ expCorrelationId);
			
			Assert.assertEquals(actCorrelationId, expCorrelationId);
		} else {
			Reporter.addStepLog("<b>Correlation Id: </b>"+actCorrelationId);
			Assert.assertNotNull(actCorrelationId);
		}
	}
	
	/*--------------------------------------------- For EISL Version validation ---------------------------------------------*/
	@And("^base URI contains version as \"([^\"]*)\"$")
	public void base_uri_contains_version_as(String version) {
		Reporter.addStepLog("<b>Version: </b>"+version);
		Reporter.addStepLog("<b>URI: </b>"+baseURI);
		
		if(version.equalsIgnoreCase("invalid")) {
			Reporter.addStepLog("<b><i>Checking with invalid version</i></b>");
		} else {
			Assert.assertTrue(baseURI.contains("/"+version+"/"));
		}
	}
	
	@And("^error in resonse is \"([^\"]*)\"$") 
	public void error_in_response_is_this(String expError) {
		String actError = ProductMasterGeneric.response.jsonPath().getString("error");
		
		Reporter.addStepLog("<b>Actual Error: </b>"+actError);
		
		Assert.assertEquals(actError, expError);
		
	}
	
	@And("^base URI format is like \"([^\"]*)\"$")
	public void base_uri_format_is_like_this(String format) {
		String [] baseURIArr = baseURI.split("/");
		String [] formatArr = format.split("/");
		int i = 0;
		for (String str : baseURIArr) {
			if(str.length()>0) {
				Reporter.addStepLog("<b>"+formatArr[i]+ " -</b> <i>"+str+"</i>");
				Assert.assertNotNull(str, formatArr[i]+" is not as expected in Base URI.");
			}
			i++;
		}
	}

}
