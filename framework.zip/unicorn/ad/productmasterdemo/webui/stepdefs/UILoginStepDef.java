package qa.unicorn.ad.productmasterdemo.webui.stepdefs;

import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.PropertyFileUtils;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UILoginStepDef {
	Action action = new Action(SQLDriver.getEleObjData("AD_PM_SSOLoginPage"));
	SSOLoginPage slp = new SSOLoginPage();
	String applicationPropertyFilePath = "./application.properties";
	PropertyFileUtils property = new PropertyFileUtils(applicationPropertyFilePath);
	
	
	@Given("^(.+) has logged into the Product Master Demo application$")
    public void has_logged_into_the_product_master_demo_application(String typeofuser) throws Throwable {
       
    }
}
