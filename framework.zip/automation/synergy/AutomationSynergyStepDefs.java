package qa.automation.synergy;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.json.JSONObject;

import com.jayway.jsonpath.JsonPath;

import org.json.JSONArray;

import io.cucumber.java.en.Given;
import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.FileManager;

public class AutomationSynergyStepDefs {

	@Given("^user convert db data into json when key \"([^\"]*)\" is provided$")
	public void user_convert_db_data_into_json_when_key_something_is_provided(String key) {
		
		
		String temp="";
		String[] arrKey = key.split(",");
		if(arrKey.length>1) {
			
			for(String aKey: arrKey) {
				temp=temp+"'"+aKey+"'"+",";
			}
			
			/*removing extra comma*/
			temp=temp.substring(0,temp.length()-1);
			
			key=temp;
			
		}else {
			key="'"+key+"'";
		}
		
		List<DBRowTO> data = SQLDriver.getData(key);
		
		JSONObject jsonObject = new JSONObject();
		JSONArray jsonArray = new JSONArray();
		
		for(DBRowTO obj: data) {
			
			JSONObject aJsonObject = new JSONObject();
			aJsonObject.put("key", obj.getKey());
			aJsonObject.put("value", obj.getValue());
			
			jsonArray.put(aJsonObject);
			
		}
		
		jsonObject.put("testData",jsonArray);
		
		String reportDirPath="./src/test/resources/automation-synergy/json";
		String filePath= reportDirPath+"\\"+key.replace(",", "-").replace("'", "")+".json";
		
		File file = new File(filePath);
		try {
			file.createNewFile();
			FileManager.getFileManagerObj().write(filePath, jsonObject.toString());
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		/*
		String query="$.testData[?(@.key==\"Black\")].value";
		
		String dataReadFile = FileManager.getFileManagerObj().readFile("./src/test/resources/automation-synergy/json/data.json");
		
		System.out.println("Desired Data: "+JsonPath.read(dataReadFile, query).toString());
		*/
		
		
		
    }
	
}
