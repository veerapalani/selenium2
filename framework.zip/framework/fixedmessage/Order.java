package qa.framework.fixedmessage;

/**
 * 
 * @author Bathriyo
 *
 */
public enum Order {
	
	NEW_FIRST,OLD_FIRST;
	
}
