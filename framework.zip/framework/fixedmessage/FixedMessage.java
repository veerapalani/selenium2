package qa.framework.fixedmessage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.util.SystemOutLogger;
import org.testng.Assert;

import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.FileManager;

public class FixedMessage {

	private List<Map<String, String>> APIACreated_NewOrder;
	private List<Map<String, String>> APIACreated_CancelReplace;

	private List<Map<String, String>> ReceivedAPPIA_PendingNew;
	private List<Map<String, String>> ReceivedAPPIA_NewOrder;
	private List<Map<String, String>> ReceivedAPPIA_FullFill;
	private List<Map<String, String>> ReceivedAPPIA_PartialFill;
	private List<Map<String, String>> ReceivedAPPIA_TradeCancel;
	private List<Map<String, String>> ReceivedAPPIA_OrderReplace;
	private List<Map<String, String>> ReceivedAPPIA_PendingReplace;
	private List<Map<String, String>> ReceivedAPPIA_OrderCancelReject;
	private List<Map<String, String>> ReceivedAPPIA_PendingOrderCancel;
	private List<Map<String, String>> ReceivedAPPIA_OrderCancel;
	private List<Map<String, String>> ReceivedAPPIA_OrderReject;
	private List<Map<String, String>>ReceivedAPPIA_OrderCancelReplaceReject;
	private List<Map<String, String>> ReceivedAPPIA_TradeModify;

	public FixedMessage() {
		APIACreated_NewOrder = new ArrayList<Map<String, String>>();
		APIACreated_CancelReplace = new ArrayList<Map<String, String>>();

		ReceivedAPPIA_PendingNew = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_NewOrder = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_FullFill = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_PartialFill = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_TradeCancel = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_OrderReplace = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_PendingReplace = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_OrderCancelReject= new ArrayList<Map<String, String>>();
		ReceivedAPPIA_PendingOrderCancel = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_OrderCancel = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_OrderCancelReplaceReject = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_OrderReject = new ArrayList<Map<String, String>>();
		ReceivedAPPIA_TradeModify = new ArrayList<Map<String, String>>();

	}

	/**
	 * Storing tag and value in a map
	 * 
	 * @author BathriYo
	 * @param singleMessage
	 * @return Map<tag,value>
	 */
	private Map<String, String> storeTagAndValues(String singleMessage) {

	Map<String, String> mapTagValues = new HashMap<String, String>();

		if (singleMessage.contains("")) {
			String[] splitMsg = singleMessage.split("");

			for (String str : splitMsg) {
				if (str.contains("=")) {
					String[] splitTagAndValues = str.split("=");
					
					try {
						mapTagValues.put(splitTagAndValues[0], splitTagAndValues[1]);
						
					}catch(Exception e) {
						/*do nothing(not a failure) as it might happen that tag is not associated with any value.*/
						mapTagValues.put(splitTagAndValues[0], "");
					}
					
					
				}
			}
		}

		return mapTagValues;
	}

	/**
	 * Dividing the fixed message based on different criteria
	 * 
	 * @author BathriYo
	 * @param singleMessage
	 */
	private void bifurcateFixedMessage(String singleMessage) {

		if ((singleMessage.contains("Apiamessage created") && singleMessage.contains("35=D"))|| (singleMessage.contains("Received APPIA message")) && singleMessage.contains("35=D")){
			APIACreated_NewOrder.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Apiamessage created") && singleMessage.contains("35=G")))
				  {
			APIACreated_CancelReplace.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Pending New"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=A"))||(singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=A"))) {
			ReceivedAPPIA_PendingNew.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=New Order")&&singleMessage.contains("150=0"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=0"))||(singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
				&& singleMessage.contains("150=0"))) {
			ReceivedAPPIA_NewOrder.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Full Fill"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=2"))|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=2"))) {
			ReceivedAPPIA_FullFill.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Partial Fill"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=1"))|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=1"))) {
			ReceivedAPPIA_PartialFill.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Trade Cancel"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=H"))|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=H"))) {
			ReceivedAPPIA_TradeCancel.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Order Replaced"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=5"))||(singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=5"))) {
			ReceivedAPPIA_OrderReplace.add(storeTagAndValues(singleMessage));

		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Pending Replace"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=E"))|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=E"))) {

			ReceivedAPPIA_PendingReplace.add(storeTagAndValues(singleMessage));

		}
		else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Pending order cancel"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=6"))|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=6"))) {
			ReceivedAPPIA_PendingOrderCancel.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58= order cancelled"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=4"))||(singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=4"))) {
			ReceivedAPPIA_OrderCancel.add(storeTagAndValues(singleMessage));
		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Order Reject"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=8"))|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=8"))) {
			ReceivedAPPIA_OrderReject.add(storeTagAndValues(singleMessage));

		} else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=8")
				&& singleMessage.contains("58=Trade Correction")&& singleMessage.contains("150=G"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=8")
						&& singleMessage.contains("150=G"))|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=8")
								&& singleMessage.contains("150=G"))) {
			ReceivedAPPIA_TradeModify.add(storeTagAndValues(singleMessage));
			
		}else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=9")
					&& singleMessage.contains("58=Order cancel Reject")&& singleMessage.contains("434=1"))
					|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=9")
							&& singleMessage.contains("434=1") )|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=9")
									&& singleMessage.contains("434=1") )) {
			ReceivedAPPIA_OrderCancelReject.add(storeTagAndValues(singleMessage));
		}
		
		else if ((singleMessage.contains("Received APPIA message") && singleMessage.contains("35=9")&& singleMessage.contains("434=2"))
				|| (singleMessage.contains("Apiamessage created") && singleMessage.contains("35=9")
						&& singleMessage.contains("434=2"))|| (singleMessage.contains("TRACE logger") && singleMessage.contains("35=9")
								&& singleMessage.contains("434=2")))
		{
			ReceivedAPPIA_OrderCancelReplaceReject.add(storeTagAndValues(singleMessage));
	}
	}

	/**
	 * Parsing fixed file for different messages
	 * 
	 * @author BathriYo
	 * @param fixedFilePath
	 */
	public void parseFixedFile(String fixedFilePath) {

		BufferedReader bufferedReader = null;
		FileManager fileMng = FileManager.getFileManagerObj();

		if (fileMng.isFileExists(fixedFilePath)) {
			try {
				bufferedReader = new BufferedReader(new FileReader(fixedFilePath));

				String line = null;
				line = bufferedReader.readLine();
				while (line != null) {

					bifurcateFixedMessage(line);
					line = bufferedReader.readLine();
				}
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
				e.printStackTrace();
			} finally {
				try {
					bufferedReader.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}

		} else {
			Assert.fail("!!! File does NOT exists !!!" + fixedFilePath);
		}

	}

	/*------------GETTER---------------*/

	/**
	 * Get parsed new order fixed message
	 * 
	 * @author Bathriyo
	 * @param enumValue
	 * @return List<Map<String:Tag,String:Value>>
	 */
	public List<Map<String, String>> getAPIACreated_NewOrder(Order enumValue) {

		if (APIACreated_NewOrder.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return APIACreated_NewOrder;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(APIACreated_NewOrder);
			}
		}

		return APIACreated_NewOrder;
	}

	/**
	 * 
	 * @return
	 */
	public List<Map<String, String>> getAPIACreated_CancelReplace(Order enumValue) {

		if (APIACreated_CancelReplace.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return APIACreated_CancelReplace;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(APIACreated_CancelReplace);
			}
		}
		return APIACreated_CancelReplace;
	}

	public List<Map<String, String>> getReceivedAPPIA_PendingNew(Order enumValue) {

		if (ReceivedAPPIA_PendingNew.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_PendingNew;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_PendingNew);
			}
		}
		return ReceivedAPPIA_PendingNew;
	}

	public List<Map<String, String>> getReceivedAPPIA_NewOrder(Order enumValue) {

		if (ReceivedAPPIA_NewOrder.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_NewOrder;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_NewOrder);
			}
		}
		return ReceivedAPPIA_NewOrder;
	}

	public List<Map<String, String>> getReceivedAPPIA_FullFill(Order enumValue) {

		if (ReceivedAPPIA_FullFill.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_FullFill;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_FullFill);
			}
		}
		return ReceivedAPPIA_FullFill;
	}

	public List<Map<String, String>> getReceivedAPPIA_PartialFill(Order enumValue) {

		if (ReceivedAPPIA_PartialFill.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_PartialFill;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_PartialFill);
			}
		}
		return ReceivedAPPIA_PartialFill;
	}

	public List<Map<String, String>> getReceivedAPPIA_TradeCancel(Order enumValue) {

		if (ReceivedAPPIA_TradeCancel.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_TradeCancel;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_TradeCancel);
			}
		}

		return ReceivedAPPIA_TradeCancel;
	}

	public List<Map<String, String>> getReceivedAPPIA_TradeModify(Order enumValue) {

		if (ReceivedAPPIA_TradeModify.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_TradeModify;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_TradeModify);
			}
		}

		return ReceivedAPPIA_TradeModify;
	}

	public List<Map<String, String>> getReceivedAPPIA_OrderReplace(Order enumValue) {

		if (ReceivedAPPIA_OrderReplace.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_OrderReplace;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_OrderReplace);
			}
		}

		return ReceivedAPPIA_OrderReplace;
	}

	public List<Map<String, String>> getReceivedAPPIA_PendingReplace(Order enumValue) {

		if (ReceivedAPPIA_PendingReplace.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_PendingReplace;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_PendingReplace);
			}
		}

		return ReceivedAPPIA_PendingReplace;
	}

	public List<Map<String, String>> getReceivedAPPIA_PendingOrderCancel(Order enumValue) {

		if (ReceivedAPPIA_PendingOrderCancel.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_PendingOrderCancel;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_PendingOrderCancel);
			}
		}

		return ReceivedAPPIA_PendingOrderCancel;
	}

	public List<Map<String, String>> getReceivedAPPIA_OrderCancel(Order enumValue) {

		if (ReceivedAPPIA_OrderCancel.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_OrderCancel;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_OrderCancel);
			}
		}

		return ReceivedAPPIA_OrderCancel;
	}

	public List<Map<String, String>> getReceivedAPPIA_OrderCancelReject(Order enumValue) {

		if (ReceivedAPPIA_OrderCancelReject.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_OrderCancelReject;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_OrderCancelReject);
			}
		}

		return ReceivedAPPIA_OrderCancelReject;
	}
	
	
	public List<Map<String, String>> getReceivedAPPIA_OrderCancelReplaceReject(Order enumValue) {

		if (ReceivedAPPIA_OrderCancelReplaceReject.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_OrderCancelReplaceReject;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_OrderCancelReplaceReject);
			}
		}

		return ReceivedAPPIA_OrderCancelReplaceReject;
	}
	
	
	

	
	public List<Map<String, String>> getReceivedAPPIA_OrderReject(Order enumValue) {

		if (ReceivedAPPIA_OrderReject.size() > 0) {

			if (enumValue == Order.NEW_FIRST) {
				return ReceivedAPPIA_OrderReject;
			} else if (enumValue == Order.OLD_FIRST) {
				Collections.reverse(ReceivedAPPIA_OrderReject);
			}
		}

		return ReceivedAPPIA_OrderReject;
	}

	
	
}
