package qa.framework.utils;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.springframework.util.FileCopyUtils;

import com.assertthat.selenium_shutterbug.core.Shutterbug;
import com.assertthat.selenium_shutterbug.utils.web.ScrollStrategy;
import com.google.common.io.Files;

import qa.framework.desktop.DesktopDriverManager;
import qa.framework.webui.browsers.WebDriverManager;

public class CaptureScreenshot {

	static String format = "png";
	public static String imageFolderPath = null;

	private static Logger log = LoggerHelper.getLogger(CaptureScreenshot.class);

	private static int count=0;
	
	/**
	 * Capture's entire screen
	 * 
	 * @author BathriYo
	 * @return byte[]
	 */
	public static synchronized byte[] captureEntireScreen() {

		String dest = imageFolderPath + "/" + "image-" + counter() + "." + format;

		byte[] imgByteArr = null;

		try {

			BufferedImage sourceImg = new Robot()
					.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			log.debug("Screen captured and stored in buffer.");

			/*
			File destImg = new File(dest);
			log.debug("Temp screenshot file created.");

			ImageIO.write(sourceImg, format, destImg);
			log.debug("Buffered screen captured wrote in temp." + format + " file");

			imgByteArr = Files.toByteArray(destImg);
			log.debug("Converting temp." + format + " file to byte array.");

			destImg.delete();
			log.debug("Deleted temp." + format + " file.");
			*/
			
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write( sourceImg, "jpg", baos );
			baos.flush();
			imgByteArr = baos.toByteArray();
			baos.close();

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
		}

		return imgByteArr;
	}

	public static synchronized String captureEntireScreen(String fileName) {

		String dest = imageFolderPath + "/" + fileName + "-" + counter() + "." + format;

		try {

			BufferedImage sourceImg = new Robot()
					.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			log.debug("Screen captured and stored in buffer.");

			File destImg = new File(dest);
			log.debug("Temp screenshot file created.");

			ImageIO.write(sourceImg, format, destImg);
			log.debug("Buffered screen captured wrote in temp." + format + " file");
			

		} catch (Exception e) {

			ExceptionHandler.handleException(e);
		}

		return dest;
	}

	/**
	 * Capture's browser screen (for cucumber only)
	 * 
	 * @author BathriYo
	 * @return byte[]
	 */
	public static synchronized byte[] screenCapture() {

		TakesScreenshot captureScreen = (TakesScreenshot) WebDriverManager.getDriver();

		byte[] screenshotAs = captureScreen.getScreenshotAs(OutputType.BYTES);
		log.debug("Browser screen captured");

		return screenshotAs;
	}

	/**
	 * capture browser screen shot (use in TestNG)
	 * 
	 * @author BathriYo
	 * @param fileName
	 * @return String file path
	 */
	public static synchronized String screenCapture(String fileName) {
		String dest = imageFolderPath + "\\" + fileName + "-" + counter() + "." + format;

		TakesScreenshot captureScreen = (TakesScreenshot) WebDriverManager.getDriver();

		File src = captureScreen.getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(src, new File(dest));
		} catch (IOException e) {
			ExceptionHandler.handleException(e);
		}

		return dest;
	}

	/**
	 * @author bathriyo
	 * @return String 
	 */
	public static synchronized String shutterEntireScreenCapture() {
		String screenshotName = "screenshot" + (++count);

        PropertyFileUtils extentPro = new PropertyFileUtils("./src/test/resources/extent.properties");
        String sparkDirPath = "./" + extentPro.getProperty("extent.reporter.spark.out");

        Shutterbug.shootPage(WebDriverManager.getDriver(), ScrollStrategy.BOTH_DIRECTIONS, true).withName(screenshotName)
                     .save(sparkDirPath);

        /* extension .png is hard coded in Shuttherbug library */
        return screenshotName + ".png";

	}
	
	/**
	 * @author bathriyo
	 * @return String
	 */
	public static synchronized String shutterScreenCapture() {
		String screenshotName = "screenshot" + (++count);

        PropertyFileUtils extentPro = new PropertyFileUtils("./src/test/resources/extent.properties");
        String sparkDirPath = "./" + extentPro.getProperty("extent.reporter.spark.out");

        Shutterbug.shootPage(WebDriverManager.getDriver(), true).withName(screenshotName)
                     .save(sparkDirPath);

        /* extension .png is hard coded in Shuttherbug library */
        return screenshotName + ".png";

	}
	
	public static synchronized String desktopScreenCapture() {
		String screenshotName = "screenshot" + (++count)+".png";
		
		PropertyFileUtils extentPro = new PropertyFileUtils("./src/test/resources/extent.properties");
        String sparkDirPath = "./" + extentPro.getProperty("extent.reporter.spark.out");
        
        String dest = sparkDirPath+"/"+screenshotName;
		
		File src = DesktopDriverManager.getDriver().getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(src, new File(dest));
		} catch (IOException e) {
			log.info("!!! Some problem occured while taking Desktop screenshot !!!");
			log.error(e);
			e.printStackTrace();
		}
		
		return screenshotName;
	}
	
	/**
	 * Caputre browser screenshot in base 64 format
	 * 
	 * @author BathriYo
	 * @return String Base64
	 */
	public static synchronized String screenCaptureBase64() {
		TakesScreenshot captureScreen = (TakesScreenshot) WebDriverManager.getDriver();

		return captureScreen.getScreenshotAs(OutputType.BASE64);
	}

	private static String counter() {
		return CalendarUtils.getCalendarUtilsObject().getTimeStamp("ddmmyyyyHHss");
	}

}
