package qa.framework.utils;

import java.io.File;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;



/**
 * Reference:
 * https://www.tutorialspoint.com/javamail_api/javamail_api_send_email_with_attachment.htm
 * https://www.javatpoint.com/example-of-sending-attachment-with-email-using-java-mail-api
 * 
 * mail-in1.broadridge.com
 * 
 * @author BathriYo
 *
 */
@Deprecated
public class Email {

	static Logger log = LoggerHelper.getLogger(Email.class);

	static MimeMessage message;

	/**
	 * Configuring mail settings
	 * 
	 * @param host
	 * @param port
	 * @param user
	 * @param password
	 * @return
	 */
	public static MimeMessage emailConfig(String host, String port, String user, String password) {

		Properties properties = System.getProperties();
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", port);

		log.info("SMTP host and port are set.");

		Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(user, password);
			}
		});
		log.info("New session created.");

		message = new MimeMessage(session);

		return message;

	}

	/**
	 * Setting from
	 * 
	 * @param from_email
	 */
	public static void setFrom(String from_email) {
		try {

			message.setFrom(new InternetAddress(from_email));
			log.info("From set as: " + from_email);

		} catch (MessagingException e) {

			e.printStackTrace();
			log.error("Exception: " + e);

		}

	}

	/**
	 * Setting To
	 * 
	 * @param tos_email
	 */
	public static void setTos(String tos_email) {

		/* adding recipients */
		for (String to : tos_email.split(";")) {
			try {
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
				log.info("To set as: " + to);
			} catch (MessagingException e) {

				e.printStackTrace();
			}

		}
	}

	/**
	 * Set Subject
	 * 
	 * @param subject
	 */
	public static void setSubject(String subject) {
		try {
			message.setSubject(subject);
			log.info("Subject set as: " + subject);
		} catch (MessagingException e) {

			e.printStackTrace();
		}

	}

	/**
	 * Add Message to the body
	 * 
	 * @param body
	 * @return
	 */
	public static BodyPart setBody(String body, Multipart multipart) {
		BodyPart bodyPart = new MimeBodyPart();
		try {

			bodyPart.setText(body);

			/* adding body message */
			multipart.addBodyPart(bodyPart);
			log.info("Body message set.");
		} catch (MessagingException e) {

			e.printStackTrace();
		}

		return bodyPart;

	}

	/**
	 * Add attachment
	 * 
	 * @param dirPath
	 * @param file_extension
	 * @param multipart
	 * @return
	 */
	public static MimeBodyPart attachFile(String dirPath, String file_extension, Multipart multipart) {
		/* adding all issues zip file */

		// 4) create new MimeBodyPart object and set DataHandler object to this object
		MimeBodyPart mimeBodyPart = new MimeBodyPart();

		File dir = new File(dirPath);

		for (File file : dir.listFiles()) {

			if (file.getName().endsWith(file_extension)) {

				String filename = file.getPath();// change accordingly
				DataSource source = new FileDataSource(filename);

				try {

					mimeBodyPart.setDataHandler(new DataHandler(source));
					mimeBodyPart.setFileName(source.getName());

					/* adding attachment to body */
					multipart.addBodyPart(mimeBodyPart);

				} catch (MessagingException e) {

					e.printStackTrace();
				}

				log.info("File attached: " + filename);
			}
		}

		return mimeBodyPart;

	}

	/**
	 * 
	 * @param multipart
	 */
	public static void sendMail(Multipart multipart) {

		try {

			// 6) set the multiplart object to the message object
			if (multipart.getCount() > 0) {

				message.setContent(multipart);

			}
			// 7) send message
			Transport.send(message);
			log.info("Message Sent....");
		} catch (MessagingException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Send Report
	 */
	public static void sendReport() {

		PropertyFileUtils emailConfigPro = new PropertyFileUtils("./emailconfig.properties");

		String host = emailConfigPro.getProperty("host");
		String port = emailConfigPro.getProperty("port");
		
		String from = emailConfigPro.getProperty("from_id");// change accordingly
		String password = emailConfigPro.getProperty("password");// change accordingly
		String tos = emailConfigPro.getProperty("recipient_ids");// change accordingly
		
		String subject = emailConfigPro.getProperty("subject") + " - "
				+ CalendarUtils.getCalendarUtilsObject().getTimeStamp("MMM dd yyyy");
		
		String body = emailConfigPro.getProperty("body_message");
		
		
		/*1st: email config*/
		emailConfig(host, port, from, password);
		
		/*2nd: Set from*/
		setFrom(from);
		
		/*3rd: Set Tos*/
		setTos(tos);
		
		/*4th: set Subject*/
		setSubject(subject);
		
		Multipart multipart = new MimeMultipart();
		
		/*5th: set Body*/
		setBody(body,multipart);
		
		/*6th: attached File*/
		
		
		
		/* getting all save file path */
		attachFile("<provide dir file path>", ".zip", multipart);
		
		/*7th: Send Mail*/
		sendMail(multipart);
	}

	/**
	 * Send mail in cause of failure
	 * @param message
	 * @param e
	 */
	public static void sendExceptionMail(String message, Exception e) {
		PropertyFileUtils emailConfigPro = new PropertyFileUtils("./emailconfig.properties");

		String host = emailConfigPro.getProperty("host");
		String port = emailConfigPro.getProperty("port");
		
		String from = emailConfigPro.getProperty("from_id");// change accordingly
		String password = emailConfigPro.getProperty("password");// change accordingly
		
		
		String subject = "JIRA Extract Report FAILURE" + " - "
				+ CalendarUtils.getCalendarUtilsObject().getTimeStamp("MMM dd yyyy");
		
		/*1st: email config*/
		emailConfig(host, port, from, password);
		
		/*2nd: Set from*/
		setFrom(from);
		
		
		/*3rd: Set Tos*/
		setTos(from);
		
		/*4th: set Subject*/
		setSubject(subject);
		
		Multipart multipart = new MimeMultipart();
		
		/*5th: set Body*/
		if(e!=null) {
			setBody(message+"\n"+e.getMessage(),multipart);	
		}else {
			setBody(message+"\n",multipart);
		}
		
		
		/*7th: Send Mail*/
		sendMail(multipart);
	}
}
