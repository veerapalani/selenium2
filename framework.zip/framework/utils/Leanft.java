package qa.framework.utils;

import java.net.URI;

import org.apache.log4j.Logger;
import org.junit.Assert;

import com.hp.lft.sdk.ModifiableSDKConfiguration;
import com.hp.lft.sdk.SDK;

public class Leanft {

	static Logger log = LoggerHelper.getLogger(Leanft.class);
	
	/*Staring leanft engine*/
	public static void startEngine() {
		

		try {

			ModifiableSDKConfiguration config = new ModifiableSDKConfiguration();
			config.setServerAddress(new URI("ws://localhost:5095"));
			SDK.init(config);

		} catch (Exception e) {
			log.debug("!!! Leanft Engine not started !!!",e);
			Assert.fail("!!! Leanft Engine not started !!!");
		}

	} 
	
	public static void stopEngine() {
		SDK.cleanup();
	}
	
}
