package qa.framework.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.RichTextString;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;

public class ExcelUtils {

	private String filePath;
	private XSSFWorkbook workbook;
	private XSSFFormulaEvaluator evaluator;

	/*
	 * do NOT create global variable for sheet. otherwise user will be restricted to
	 * work on only one sheet.
	 */

	public ExcelUtils(ExcelOperation operation, String filePath) {
		this.filePath = filePath;

		if (operation.getOperation().equalsIgnoreCase("load")) {
			loadExcel();
		} else if (operation.getOperation().equalsIgnoreCase("create")) {
			createExcel();
		}

		this.evaluator = workbook.getCreationHelper().createFormulaEvaluator();
	}

	/**
	 * Creates a new excel in provided filePath (includes filename with extension)
	 * 
	 * @author Bathriyo
	 * @param filePath
	 */
	private void createExcel() {

		try {

			File newExcel = new File(this.filePath);
			newExcel.createNewFile();

			this.workbook = new XSSFWorkbook();

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * Creates sheet
	 * 
	 * @author Bathriyo
	 * @param sheetName
	 * @return XSSFSheet
	 */
	public XSSFSheet createSheet(String sheetName) {

		XSSFSheet sheet = null;

		try {
			sheet = this.workbook.createSheet(sheetName);
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return sheet;
	}

	/**
	 * Loads existing excel
	 * 
	 * @author Bathriyo
	 * @param filePath
	 */
	private void loadExcel() {

		FileInputStream inpstr = null;

		try {

			inpstr = new FileInputStream(this.filePath);

			this.workbook = new XSSFWorkbook(inpstr);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			try {
				inpstr.close();
			} catch (IOException e) {

				ExceptionHandler.handleException(e);
			}
		}

	}

	/**
	 * Set existing sheet in a excel
	 * 
	 * @param sheetName
	 * @return XSSFSheet
	 */
	public XSSFSheet getSheet(String sheetName) {

		XSSFSheet sheet = null;

		try {
			sheet = this.workbook.getSheet(sheetName);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return sheet;
	}

	/**
	 * Get string cell data from excel sheet
	 * 
	 * @param rowNum
	 * @param cellNum
	 * @return String data
	 * @throws IOException
	 */
	public String getStringCellData(XSSFSheet sheet, int rowNum, int cellNum) throws IOException {
		String cellData = "";
		if (sheet.getRow(rowNum).getCell(cellNum) != null) {
			cellData = sheet.getRow(rowNum).getCell(cellNum).getStringCellValue();
		}
		return cellData;
	}

	/**
	 * Gets value in a cell (String, Numeric, Boolean)
	 * 
	 * @author BathriYo
	 * @param rowNum
	 * @param cellNum
	 * @return Object
	 */
	public Object getCellData(XSSFSheet sheet, int rowNum, int cellNum) {

		Object cellData;
		Cell cell = getCell(sheet, rowNum, cellNum);

		try {

			CellType cellType = cell.getCellType();

			if (cellType == CellType.FORMULA) {

				/* reassigning the cellType value */
				cellType = cell.getCachedFormulaResultType();
			}

			/* do not put else if here */

			if (cellType == CellType.STRING) {

				cellData = sheet.getRow(rowNum).getCell(cellNum).getStringCellValue();

			} else if (cellType == CellType.NUMERIC) {

				Cell currentCell = getCell(sheet, rowNum, cellNum);

				/* checking if cell contians date vlaue */
				if (HSSFDateUtil.isCellDateFormatted(currentCell)) {
					cellData = currentCell.getDateCellValue();
				} else {

					/*
					 * Apache POI does not provide a way to read integer value thus when read always
					 * returns double value for example 123 an int value will read as 123.0
					 */

					String temp = String.valueOf(currentCell.getNumericCellValue());

					/* logic to return int value as int and double value as double */
					/* splitting with dot (.) */
					String[] split = temp.split("\\.");
					String fraction = split[1];
					int lenght = fraction.replace("0", "").length();

					if (lenght > 0) {
						cellData = Double.parseDouble(temp);
					} else {
						cellData = Long.parseLong(split[0]);
					}
				}
			} else if (cellType == CellType.BOOLEAN) {

				cellData = (Boolean) sheet.getRow(rowNum).getCell(cellNum).getBooleanCellValue();

			} else if (cellType == CellType._NONE || cellType == CellType.BLANK) {
				cellData = "";
			} else {
				cellData = null;
			}

		} catch (NullPointerException e) {
			cellData = "";
		}

		return cellData;

	}

	/**
	 * Get Excel Row
	 * 
	 * @author bathriyo
	 * @param sheet  : XSSFSheet
	 * @param rowNum : Integer
	 * @return Row
	 */
	public Row getRow(XSSFSheet sheet, int rowNum) {
		return sheet.getRow(rowNum);
	}

	/**
	 * Create Row
	 * 
	 * @author bathriyo
	 * @param sheet  : XSSFSheet
	 * @param rowNum : Integer
	 * @return Row
	 */
	public Row createRow(XSSFSheet sheet, int rowNum) {
		return sheet.createRow(rowNum);
	}

	/**
	 * Get Excel Cell
	 * 
	 * @author bathriyo
	 * @param sheet   : XSSFSheet
	 * @param rowNum  : Integer
	 * @param cellNum : Integer
	 * @return Cell
	 */
	public Cell getCell(XSSFSheet sheet, int rowNum, int cellNum) {
		return sheet.getRow(rowNum).getCell(cellNum);
	}

	/**
	 * Create Cell
	 * 
	 * @author bathriyo
	 * @param sheet   : XSSFSheet
	 * @param rowNum  : Integer
	 * @param cellNum : Integer
	 * @return Cell
	 */
	public Cell createCell(XSSFSheet sheet, int rowNum, int cellNum) {

		Row newRow = null;
		XSSFRow row = sheet.getRow(rowNum);

		if (row == null) {
			newRow = createRow(sheet, rowNum);

			return newRow.createCell(cellNum);
		}

		return row.createCell(cellNum);
	}

	/**
	 * Returns evaluated the formula value
	 * 
	 * @author bathriyo
	 * @param sheet   : XSSFSheet
	 * @param rowNum  : Integer
	 * @param cellNum : Integer
	 * @return Object
	 */
	public Object evaluateCell(XSSFSheet sheet, int rowNum, int cellNum) {

		Cell cell = getCell(sheet, rowNum, cellNum);

		evaluator.evaluateFormulaCell(cell);

		return getCellData(sheet, rowNum, cellNum);
	}

	/**
	 * Evaluate all formula in Excel File.
	 * 
	 * @author bathriyo
	 *
	 */
	public void evaluateAll() {

		evaluator.evaluateAll();
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(filePath);
			workbook.write(fos);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fos.flush();
				fos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

	/**
	 * Recalculate formulate one user open the file.
	 * 
	 * @author bathriyo
	 */
	public void recalculateFormulaAfterOpen(boolean option) {
		workbook.setForceFormulaRecalculation(option);

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(filePath);
			workbook.write(fos);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fos.flush();
				fos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * Set Cell formulate
	 * 
	 * @author bathriyo
	 * @param sheet   : XSSFSheet
	 * @param rowNum  : Integer
	 * @param cellNum : Integer
	 * @param formula : String
	 */
	public void setCellFormula(XSSFSheet sheet, int rowNum, int cellNum, String formula) {

		Cell cell = getCell(sheet, rowNum, cellNum);

		/* if value of cell in NULL this mean cell does not exists. */
		if (cell == null) {
			cell = createCell(sheet, rowNum, cellNum);
		}

		cell.setCellFormula(formula);

		try {
			FileOutputStream fo = new FileOutputStream(filePath);
			workbook.write(fo);
			fo.flush();
			fo.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Get all the value in a column
	 * 
	 * @param columnName
	 * @return List<Object>
	 */
	public List<Object> getColumnData(XSSFSheet sheet, int headerRowIndex, String columnName) {

		int columnIndex = -1;

		int rowCount = getRowCount(sheet);

		int rowStartIndex = headerRowIndex + 1;

		List<Object> columnValue = new ArrayList<Object>();

		try {

			/* checking if column existing or not . getting column Index */
			columnIndex = getCellIndexByCellValue(sheet, headerRowIndex, columnName);

			if (columnIndex > -1) {

				/* Fetching column data and adding in list */
				for (int rowIndex = rowStartIndex; rowIndex < rowCount; rowIndex++) {
					columnValue.add(getCellData(sheet, rowIndex, columnIndex));
				}

			} else {
				Assert.fail("Column Name is not avaiable in excel sheet: " + columnName);
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return columnValue;
	}

	/**
	 * Setting String cell value
	 * 
	 * @param rowNum
	 * @param cellNum
	 * @param value
	 * @throws IOException
	 */
	public void setCellData(XSSFSheet sheet, int rowNum, int cellNum, Object value) {

		XSSFRow row;

		/* if row does not exists then create the row */
		try {
			row = sheet.getRow(rowNum);

			if (row == null) {
				row = sheet.createRow(rowNum);
			}

		} catch (Exception e) {
			/* create row if does not exist */
			row = sheet.createRow(rowNum);
		}

		/* if cell does not exists then create the cell else setCellValue */
		try {

			if (value instanceof String) {

				row.getCell(cellNum).setCellValue((String) value);

			} else if (value instanceof RichTextString) {

				row.getCell(cellNum).setCellValue((RichTextString) value);

			} else if (value instanceof Integer) {

				row.getCell(cellNum).setCellValue((Integer) value);

			} else if (value instanceof Long) {

				row.getCell(cellNum).setCellValue((Long) value);

			} else if (value instanceof Float) {

				row.getCell(cellNum).setCellValue((Float) value);

			} else if (value instanceof Double) {

				row.getCell(cellNum).setCellValue((Double) value);

			} else if (value instanceof Boolean) {

				row.getCell(cellNum).setCellValue((Boolean) value);

			} else if (value instanceof Date) {

				row.getCell(cellNum).setCellValue((Date) value);

			} else if (value instanceof Calendar) {

				row.getCell(cellNum).setCellValue((Calendar) value);
			}

		} catch (Exception e) {

			/* create cell if does not exist */
			if (value instanceof String) {

				row.createCell(cellNum).setCellValue((String) value);

			} else if (value instanceof RichTextString) {

				row.createCell(cellNum).setCellValue((RichTextString) value);

			} else if (value instanceof Integer) {

				row.createCell(cellNum).setCellValue((Integer) value);

			} else if (value instanceof Long) {

				row.createCell(cellNum).setCellValue((Long) value);

			} else if (value instanceof Float) {

				row.createCell(cellNum).setCellValue((Float) value);

			} else if (value instanceof Double) {

				row.createCell(cellNum).setCellValue((Double) value);

			} else if (value instanceof Boolean) {

				row.createCell(cellNum).setCellValue((Boolean) value);

			} else if (value instanceof Date) {

				row.createCell(cellNum).setCellValue((Date) value);

			} else if (value instanceof Calendar) {

				row.createCell(cellNum).setCellValue((Calendar) value);
			}

		}

		try {

			FileOutputStream fos = new FileOutputStream(this.filePath);
			this.workbook.write(fos);

			fos.flush();

			fos.close();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);

		}

	}

	/**
	 * Get Count of rows in a sheet
	 * 
	 * @return int
	 */
	public int getRowCount(XSSFSheet sheet) {

		int count = 0;

		if (sheet.getPhysicalNumberOfRows() > 0) {
			/* getLastRowNum returns Index not count thus count++ */
			count = sheet.getLastRowNum();
		} else {
			Assert.fail("!!! No Row found !!!");
		}

		return ++count;
	}

	/**
	 * Get Cell count in a given row
	 * 
	 * @param row
	 * @return int
	 */
	public int getCellCount(XSSFSheet sheet, int rowNum) {
		int count = 0;

		XSSFRow row = sheet.getRow(rowNum);

		if (row.getPhysicalNumberOfCells() > 0) {

			/* getLastCellNum returns count */
			count = row.getLastCellNum();

		} else {
			Assert.fail("!!! No Cell found !!!");
		}
		return count;

	}

	/**
	 * Returns row index bases on cell data
	 * 
	 * @author BathriYo
	 * @param columnNum
	 * @param searchValue
	 * @return int row index if search value found else -1.
	 */
	public int getRowIndexByCellValue(XSSFSheet sheet, int columnNum, String searchValue) {

		try {

			int rowCount = getRowCount(sheet);

			for (int index = 0; index < rowCount; index++) {

				if (getStringCellData(sheet, index, columnNum).equals(searchValue)) {

					return index;
				}
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return -1;

	}

	
	/**
	 * Returns row index bases on Multiple cell data
	 * 
	 * @author Firoz Shaikh
	 * @param columnNum
	 * @param searchValue
	 * @return int row index if search value found else -1.
	 */
	public int getRowIndexByCellValue(XSSFSheet sheet, int columnNum1, String searchValue1, int columnNum2, String searchValue2) {

		try {

			int rowCount = getRowCount(sheet);

			for (int index = 0; index < rowCount; index++) {

				if ((getStringCellData(sheet, index, columnNum1).equals(searchValue1)) && (getStringCellData(sheet, index, columnNum2).equals(searchValue2))  ) {

					return index;
				}
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return -1;

	}
	/**
	 * Returns cell number based on row number and search value provided as argument
	 * 
	 * @author BathriYo
	 * @param rowNum
	 * @param searchValue
	 * @return int
	 */
	public int getCellIndexByCellValue(XSSFSheet sheet, int rowNum, String searchValue) {

		try {

			int cellCount = getCellCount(sheet, rowNum);

			for (int index = 0; index < cellCount; index++) {

				if (searchValue.equals(getCellData(sheet, rowNum, index).toString().trim())) {
					return index;
				}
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return -1;
	}

	/**
	 * Get Row data
	 * 
	 * @author BathriYo
	 * @param sheet
	 * @param rowIndex
	 * @return
	 */
	public List<Object> getRowData(XSSFSheet sheet, int rowIndex) {
		List<Object> rowData = new ArrayList<Object>();
		int cellCount = getCellCount(sheet, 0);

		for (int index = 0; index < cellCount; index++) {
			rowData.add(getCellData(sheet, rowIndex, index));
		}

		return rowData;
	}
	
	
	
	
	/**
	 * Get Row data as a String Array
	 * 
	 * @author LiuC
	 * @param sheet
	 * @param rowIndex
	 * @return
	 */
	// Need to be fixed 
	
	public String[] getRowDataArray(XSSFSheet sheet, int rowIndex) {
		//List<Object> rowData = new ArrayList<Object>();
		String[] rowData = new String[3];
		int cellCount = getCellCount(sheet, 0);

		for (int index = 0; index < cellCount; index++) {
			Object val = getCellData(sheet, rowIndex, index);
			rowData[index] = (String) val; 
		}

		return rowData;
	}

	/**
	 * Return one single row as mapped with header
	 * 
	 * @author BathriYo
	 * @param sheet
	 * @param headerIndex
	 * @param rowIndex
	 * @return
	 */
	public Map<String, Object> getMappedRowDate(XSSFSheet sheet, int headerIndex, int rowIndex) {
		Map<String, Object> rowDataMap = new HashMap<String, Object>();

		List<Object> headerList = getRowData(sheet, headerIndex);
		List<Object> dataList = getRowData(sheet, rowIndex);

		for (int index = 0; index < headerList.size(); index++) {
			rowDataMap.put((String) headerList.get(index), dataList.get(index));
		}

		return rowDataMap;
	}

	public List<Map<String, Object>> getMappedExcelData(XSSFSheet sheet, int headerIndex) {

		List<Map<String, Object>> allMappedData = new ArrayList<Map<String, Object>>();

		int rowCount = getRowCount(sheet);

		for (int index = headerIndex + 1; index < rowCount; index++) {
			Map<String, Object> aMappedData = getMappedRowDate(sheet, headerIndex, index);
			allMappedData.add(aMappedData);
		}

		return allMappedData;
	}

	public String getColumnAlphabetByIndex(int cellIndex) {

		Map<Integer, String> indexColumnNameMap = new HashMap<Integer, String>();

		indexColumnNameMap.put(0, "A");
		indexColumnNameMap.put(1, "B");
		indexColumnNameMap.put(2, "C");
		indexColumnNameMap.put(3, "D");
		indexColumnNameMap.put(4, "E");
		indexColumnNameMap.put(5, "F");
		indexColumnNameMap.put(6, "G");
		indexColumnNameMap.put(7, "H");
		indexColumnNameMap.put(8, "I");
		indexColumnNameMap.put(9, "J");
		indexColumnNameMap.put(10, "K");
		indexColumnNameMap.put(11, "L");
		indexColumnNameMap.put(12, "M");
		indexColumnNameMap.put(13, "N");
		indexColumnNameMap.put(14, "O");
		indexColumnNameMap.put(15, "P");
		indexColumnNameMap.put(16, "Q");
		indexColumnNameMap.put(17, "R");
		indexColumnNameMap.put(18, "S");
		indexColumnNameMap.put(19, "T");
		indexColumnNameMap.put(20, "U");
		indexColumnNameMap.put(21, "V");
		indexColumnNameMap.put(22, "W");
		indexColumnNameMap.put(23, "X");
		indexColumnNameMap.put(24, "Y");
		indexColumnNameMap.put(25, "Z");

		return indexColumnNameMap.get(cellIndex);
	}

	/**
	 * Delete rows from row index to row index
	 * 
	 * @author bathriyo
	 * @param sheet
	 * @param fromRow
	 * @param toRow
	 */
	public void removeRow(XSSFSheet sheet, int fromRow, int toRow) {

		while (fromRow <= toRow) {
			try {
				sheet.removeRow(sheet.getRow(fromRow));
			} catch (NullPointerException e) {
				// do nothing
			}
			++fromRow;
		}
	}
	
	public void removeCellData(XSSFSheet sheet, int fromRow, int toRow, int cellnum) {
		while (fromRow <= toRow) {
			try {
				getRow(sheet, fromRow).removeCell(getCell(sheet, fromRow, cellnum));
			} catch (NullPointerException e) {
				// do nothing
			}
			++fromRow;
		}
	}
	
	
	

	/**
	 * Closes workbook
	 */
	public void closeWorkBook() {
		try {

			this.workbook.close();

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

}
