package qa.framework.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class SystemProcess {

	public static synchronized void killProcess(String processName) throws IOException {

		String cmdBrowserVersion = System.getProperty("platform");

		if (cmdBrowserVersion != null) {
			if (cmdBrowserVersion.equalsIgnoreCase("linux")) {
				Process p = Runtime.getRuntime().exec("ps -aux |grep" + processName);
				BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
				String line;
				while ((line = reader.readLine()) != null) {

					if (line.contains(processName)) {

						Runtime.getRuntime().exec("pkill " + processName);
					}
				}
			}
			else {
				Process p = Runtime.getRuntime().exec("tasklist");
				BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
				String line;
				while ((line = reader.readLine()) != null) {

					if (line.contains(processName)) {

						Runtime.getRuntime().exec("taskkill /F /IM " + processName);
					}
				}
			}
		} else {
			/* reading from property file */
			Process p = Runtime.getRuntime().exec("tasklist");
			BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {

				if (line.contains(processName)) {

					Runtime.getRuntime().exec("taskkill /F /IM " + processName);
				}
			}
		}

	}

	/**
	 * @author bathriyo
	 * @throws IOException
	 */
	public static void killJavaProcess(String javaClassName) throws IOException {
		// C:\Program Files\Java\jdk1.8.0_191\bin

		String javaHome = System.getenv("JAVA_HOME");
		String javaBin = javaHome + "\\" + "bin";

		String[] command = { "cmd.exe", "/C", "jps -l" };
		ProcessBuilder pb = new ProcessBuilder(command);
		pb.directory(new File(javaBin));
		Process process = pb.start();
		BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String line;
		while ((line = reader.readLine()) != null) {
			System.out.println(line);

			if (line.contains(javaClassName)) {
				String processId = line.split(" ")[0];
				try {
					Runtime.getRuntime().exec("taskkill /F /PID " + processId);
				} catch (Exception e) {

				}

			}
		}

		process.destroyForcibly();

	}

}
