package qa.framework.utils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.junit.Assert;

/**
 * 
 * @author 10650956
 *
 */
public class PropertyFileUtils {

	Properties properties;
	String filePath;

	/**
	 * This constructor load property file
	 * 
	 * @param propertyFilePath
	 */
	public PropertyFileUtils(String propertyFilePath) {
		BufferedReader reader;
		this.filePath=propertyFilePath;
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();

			properties.load(reader);
			reader.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			Assert.fail();
		} catch (IOException e1) {
			e1.printStackTrace();
			Assert.fail();
		}

	}

	/**
	 *
	 * @return Properties
	 */
	public String getProperty(String propertyName) {
		return properties.getProperty(propertyName);
	}
	
	/**
	 * @author bathriyo
	 * @return
	 */
	public Set<String> getAllKeys(){
		
		Set<String> keySet= new HashSet<String>();
		properties.keySet().forEach(x->{
			keySet.add(String.valueOf(x));
		});
        return keySet;
    }
	
	/**
	 * Set key value in property file
	 * @param propertyName
	 * @param propertyValue
	 */
	public void setProperty(String propertyName, String propertyValue) {
		FileOutputStream fileOut=null;
		try {
			fileOut = new FileOutputStream(this.filePath);
			properties.setProperty(propertyName, propertyValue);
			properties.store(fileOut, "property file updated with Key: "+propertyName+" Value: "+propertyValue);
			
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}finally {
			
			try {
				fileOut.close();
			}catch(Exception e) {
				ExceptionHandler.handleException(e);
			}
			
			
		}
		
	}
}
