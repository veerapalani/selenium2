package qa.framework.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

public class KafkaConsumerUtil {
	
	static Properties properties = new Properties();

    public static void run() {
    	loadProp();
        ConsumerFactory<String, String> consumerFactory = consumerFactory();
        Consumer<String, String> consumer = consumerFactory.createConsumer();
        consumer.subscribe(Collections.singletonList(properties.getProperty("TOPIC_NAME")));


        try {
            while (true) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));
                for (ConsumerRecord<String, String> record : records) {
                    System.out.println(record.key());
                    System.out.println(record.value());
                }
            }
        } finally {
            consumer.close();
        }
    }

    public static ConsumerFactory<String, String> consumerFactory() {
        Map<String, Object> prop = new HashMap<>();
        //BASIC
        prop.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, properties.getProperty("AUTO_OFFSET_RESET_CONFIG"));
        
        prop.put(ConsumerConfig.GROUP_ID_CONFIG, properties.getProperty("GROUP_ID_CONFIG"));
        //SSL
        
        prop.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,properties.getProperty("BOOTSTRAP_SERVERS_CONFIG"));
        
        prop.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,properties.getProperty("KEY_DESERIALIZER_CLASS_CONFIG"));
        
        prop.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,properties.getProperty("VALUE_DESERIALIZER_CLASS_CONFIG"));
        
        prop.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, properties.getProperty("SECURITY_PROTOCOL_CONFIG"));
        
        prop.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,properties.getProperty("SSL_TRUSTSTORE_LOCATION_CONFIG"));
        
        prop.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, properties.getProperty("SSL_TRUSTSTORE_PASSWORD_CONFIG"));
        
        prop.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, properties.getProperty("SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG"));
        
        return new DefaultKafkaConsumerFactory<>(prop);
    }
    public static void loadProp() {
    	try {
    		
    		properties.load(new FileInputStream("C:\\Users\\MoharanaBh\\git\\unicornqa\\unicornqa\\Unicorn\\KafkaProperties"));  		
    	} 
    	catch (IOException ex) {
    	    ex.printStackTrace();
    	}
    	}
}
