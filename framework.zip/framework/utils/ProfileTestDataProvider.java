package qa.framework.utils;

import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.testng.Assert;

/**
 * Utility to load file for profile/env. Refer to Apache Commons Configuration
 * for syntax.
 */
public class ProfileTestDataProvider {

	private static String TEST_DATA_FOLDER = "testdata";

	public static Configuration getConfigForProfile(String profile) {

		URL testDataURL = null;
		try {
			if (profile.equalsIgnoreCase("dev") || profile.equalsIgnoreCase("qa") || profile.equalsIgnoreCase("int")
					|| profile.equalsIgnoreCase("uat")) {
				Path testDataPropertiesPath = Paths.get(TEST_DATA_FOLDER, profile.toLowerCase() + ".properties");
				testDataURL = ProfileTestDataProvider.class.getClassLoader()
						.getResource(testDataPropertiesPath.toString());
				return new PropertiesConfiguration(testDataURL);
			}

		} catch (Exception e) {
			if (testDataURL == null) {
				Assert.fail("Could not read properties file for profile \"" + profile + "\"");
			}
			e.printStackTrace();
			Assert.fail("Unexpected error during reading properties file initialization ", e);
		}
		return null;
	}

}