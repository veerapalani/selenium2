package qa.framework.utils;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import qa.framework.dbutils.DBRowTO;
import qa.framework.report.Report;
import qa.framework.webui.browsers.WebDriverManager;

/**
 * 
 * @author BathriYo
 *
 */

public class WaitManager {

	private static ThreadLocal<String> TValue = new ThreadLocal<String>();
	private static ThreadLocal<String> TValueType = new ThreadLocal<String>();

	static Logger log = LoggerHelper.getLogger(WaitManager.class);

	/**
	 * Get by based on dbkey
	 * 
	 * @author BathriYo
	 * @param dbKey
	 * @return By
	 */
	public static synchronized By getBy(String dbKey, List<DBRowTO> listElement) {

		String value = Action.getValue(dbKey, listElement);
		String valueType = Action.getValueType(dbKey, listElement);

		getTValue().set(value);
		getTValueType().set(valueType);

		switch (valueType.toLowerCase()) {
		case "id":
			return By.id(value);

		case "name":
			return By.name(value);

		case "classname":
			return By.className(value);

		case "linktext":
			return By.linkText(value);

		case "partiallinktext":
			return By.partialLinkText(value);

		case "xpath":
			return By.xpath(value);

		case "tagname":
			return By.tagName(value);

		case "cssselector":
			return By.cssSelector(value);

		default:
			log.debug(" !!! Select by : " + valueType + " is incorrect !!!");
			return null;
		}

	}

	/**
	 * Wait for element to be presence using By
	 * 
	 * @author BathriYo
	 * @param dbKey
	 * @return WebElement
	 */
	public synchronized static WebElement presenceOfElementWaitUsingBy(String dbKey, List<DBRowTO> listElement) {
		String status = "FAIL";
		WebElement element = null;
		try {
			element = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.presenceOfElementLocated(getBy(dbKey, listElement)));
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Presence of Element");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);
		}

		return element;
	}

	/**
	 * Wait for child element to be presence under parent element using By
	 * 
	 * @author BathriYo
	 * @param parentElement
	 * @param dbKey
	 * @return WebElement
	 */
	public synchronized static WebElement presenceOfElementWaitUsingBy(WebElement parentElement, String dbKey,
			List<DBRowTO> listElement) {
		String status = "FAIL";
		WebElement element = null;
		try {
			element = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime).until(
					ExpectedConditions.presenceOfNestedElementLocatedBy(parentElement, getBy(dbKey, listElement)));
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Presence of Element");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);
		}

		return element;

	}

	/**
	 * Wait for all the element to be presence using By
	 * 
	 * @author BathriYo
	 * @param dbKey
	 * @return List<WebElement>
	 */
	public synchronized static List<WebElement> presenceOfElementsWaitUsingBy(String dbKey,
			List<DBRowTO> listDBElement) {
		String status = "FAIL";
		List<WebElement> listElement = null;
		try {
			listElement = (List<WebElement>) new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.presenceOfAllElementsLocatedBy(getBy(dbKey, listDBElement)));

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Presence of Elements");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);
		}
		return listElement;
	}

	/**
	 * Wait for element to be visible. Can be used with Java script elements where
	 * By is not present.
	 * 
	 * @author bathriyo
	 * @param dbKey
	 * @param listElement
	 * @return
	 */
	public synchronized static WebElement visibilityOfElement(WebElement element) {
		String status = "FAIL";

		try {
			element = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.visibilityOf(element));
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Visibility of Elements");
			Report.printStatus(status);
		}
		return element;
	}

	/**
	 * Wait for element to be visible using By
	 * 
	 * @author BathriYo
	 * @param dbKey
	 * @return WebElement
	 */
	public synchronized static WebElement visibilityOfElementWaitUsingBy(String dbKey, List<DBRowTO> listElement) {
		String status = "FAIL";
		WebElement element = null;

		try {
			element = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.visibilityOfElementLocated(getBy(dbKey, listElement)));
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Visibility of Elements");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);
		}
		return element;
	}

	/**
	 * Wait for element to be visible using By under parent element
	 * 
	 * @author BathriYo
	 * @param parentElement
	 * @param dbKey
	 * @return List<WebElement>
	 */
	public synchronized static List<WebElement> visibilityOfElementWaitUsingBy(WebElement parentElement, String dbKey,
			List<DBRowTO> listElement) {
		String status = "FAIL";
		List<WebElement> eList = null;
		try {

			eList = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime).until(
					ExpectedConditions.visibilityOfNestedElementsLocatedBy(parentElement, getBy(dbKey, listElement)));
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Visibility of Elements");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);
		}
		return eList;

	}

	/**
	 * Get List of elements using By
	 * 
	 * @author BathriYo
	 * @param element
	 * @param dbKey
	 * @return List<WebElement>
	 */
	public synchronized static List<WebElement> visibilityOfElementsWaitUsingBy(String dbKey,
			List<DBRowTO> listDBElement) {
		String status = "FAIL";
		List<WebElement> listElement = null;

		try {
			listElement = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(getBy(dbKey, listDBElement)));
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Visibility of Elements");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);
		}
		return listElement;
	}

	/**
	 * Wait for element to be invisible
	 * 
	 * @author BathriYo
	 * @param dbKey
	 * @param listElement
	 * @return boolean
	 */
	public synchronized static boolean elementToBeInvisible(String dbKey, List<DBRowTO> listElement) {

		boolean isInVisible = false;
		String status = "FAIL";

		try {

			isInVisible = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.invisibilityOfElementLocated(getBy(dbKey, listElement)));
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait for Element to be Invisible");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);
		}

		return isInVisible;
	}

	/**
	 * Wait for element to be invisible
	 * 
	 * @author BathriYo
	 * @param element
	 * @return boolean
	 */
	public synchronized static boolean elementToBeInvisible(WebElement element) {

		boolean isInVisible = false;
		String status = "FAIL";

		try {

			isInVisible = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.invisibilityOf(element));
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait for Element to be Invisible");
			Report.printStatus(status);
		}

		return isInVisible;

	}

	/**
	 * Wait for alert to be present
	 * 
	 * @author BathriYo
	 */
	public synchronized static void alertIsPresent() {

		String status = "FAIL";

		try {
			new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.alertIsPresent());
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Alert Is Present");
			Report.printStatus(status);

		}

	}

	/**
	 * Wait for element to be clickable
	 * 
	 * @param dbKey
	 * @return WebElement
	 */
	public synchronized static WebElement elementToBeClickable(String dbKey, List<DBRowTO> listElement) {
		String status = "FAIL";
		WebElement element = null;
		try {
			element = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.elementToBeClickable(getBy(dbKey, listElement)));
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Element to be Clickable");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);

		}
		return element;
	}

	/**
	 * Wait for element to be clickable
	 * 
	 * @author BathriYo
	 * @param Webelement
	 */
	public synchronized static boolean elementToBeClickable(WebElement element) {
		String status = "FAIL";
		boolean isElementClickable=false;
		try {
			new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.elementToBeClickable(element));
			status = "PASS";
			isElementClickable=true;
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Element to be Clickable");
			Report.printStatus(status);
			

		}
		return isElementClickable;

	}

	/**
	 * Wait for element to be selectable
	 * 
	 * @author BathriYo
	 * @param dbKey
	 * @return boolean
	 */
	public synchronized static boolean elementToBeSelected(String dbKey, List<DBRowTO> listElement) {
		String status = "FAIL";
		boolean isSelected = false;
		try {
			isSelected = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.elementToBeSelected(getBy(dbKey, listElement)));
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Element to be Selectable");
			Report.printKey(dbKey);
			Report.printValueType(getTValueType().get());
			Report.printValue(getTValue().get());
			Report.printStatus(status);

		}
		return isSelected;

	}

	/**
	 * Wait for element to be selectable
	 * 
	 * @author BathriYo
	 * @param element
	 * @return
	 */
	public synchronized static boolean elementToBeSelected(WebElement element) {
		String status = "FAIL";
		boolean isSelected = false;

		try {
			isSelected = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.elementToBeSelected(element));
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Element to be Selectable");
			Report.printStatus(status);

		}
		return isSelected;
	}

	/**
	 * Wait till page refreshed.
	 * 
	 * @author BathriYo
	 * @param element
	 * @return boolean isRefreshed
	 */
	public static boolean waitTillPageRefresh(WebElement element) {

		String status = "FAIL";
		boolean isRefreshed = false;

		try {
			isRefreshed = new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.stalenessOf(element));
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait Element to be Selectable");
			Report.printStatus(status);

		}
		return isRefreshed;
	}

	

	public static ThreadLocal<String> getTValueType() {
		return TValueType;
	}

	public static void setTValueType(ThreadLocal<String> tValueType) {
		TValueType = tValueType;
	}

	public static ThreadLocal<String> getTValue() {
		return TValue;
	}

	public static void setTValue(ThreadLocal<String> tValue) {
		TValue = tValue;
	}

}
