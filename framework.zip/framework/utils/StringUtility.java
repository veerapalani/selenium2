package qa.framework.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class StringUtility {
	


	public static String convertToHour(String Time, String timeformate1, String timeformate2) {
		DateFormat f1 = new SimpleDateFormat(timeformate1); // 11:00 pm //hh:mm a
		Date d = null;
		try {
			d = f1.parse(Time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		DateFormat f2 = new SimpleDateFormat(timeformate2); // HH:mm
		String x = f2.format(d); // "23:00"

		return x;
	}

	public static String getDate() {
		Date today = new Date();
		SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yy");
		String date = DATE_FORMAT.format(today);
		return date;
	}

	public static String convertListToString(String delimiter, List<String> list) {

		StringBuilder sb = new StringBuilder();

		int i = 0;
		while (i < list.size() - 1) {
			sb.append(list.get(i));
			sb.append(delimiter);
			i++;
		}
		sb.append(list.get(i));

		String result = sb.toString();
		System.out.println(result);
		return result;
	}

	public static int randomnumbers(int value, int add) {
		Random rand = new Random();
		return rand.nextInt(value) + add;
	}

	public static float floatRandomNumbers(float max, float min, int decimalPlace) {

		Random randomgen = new Random();
		float randomNum = min + randomgen.nextFloat() * (max - min);
		BigDecimal floatDecimal = new BigDecimal(Float.toString(randomNum));
		floatDecimal = floatDecimal.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
		return floatDecimal.floatValue();
	}

	public static long randomnumbers(int min, int max, int numberOfDigits) {
		StringBuilder sb = new StringBuilder();
		for (int index = 0; index < numberOfDigits; index++) {

			if (sb.length() < numberOfDigits) {
				int randomNum = (int) Math.floor(Math.random() * (max - min + 1) + min);
				sb.append(randomNum);
			} else {
				break;
			}

		}

		return Long.parseLong(sb.toString());
	}

	public static String getRequestJsonValue(String requestJson, String objectName)
			throws FileNotFoundException, IOException, org.json.simple.parser.ParseException {
		//Object obj = new JSONParser().parse(new FileReader(requestJson));
		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(requestJson);

		//JSONObject jo = (JSONObject) obj;
		System.out.println(json.toString());
		String messageType = (String) (json.get(objectName));
		return messageType;
	}
	
	public static String removeJsonValue(String requestJson,String...values) {
	
		Object obj = null;
		try {
			obj = new JSONParser().parse(requestJson);
		} catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Obj::"+obj.toString());

		JSONObject jo = (JSONObject) obj;
		for(String val:values) {
		((HashMap) obj).remove(val);
		}
		return jo.toString();
		
	}

}
