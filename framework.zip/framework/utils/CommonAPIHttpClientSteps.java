package qa.framework.utils;

import org.testng.Assert;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import qa.framework.api.HttpClientUtils;
import qa.framework.api.MethodType;
import qa.framework.api.RequestBuilder;
import qa.framework.api.RetriveResponse;

public class CommonAPIHttpClientSteps {

	public static RequestBuilder request;

	public static RetriveResponse response;

	CommonAPISteps common = new CommonAPISteps();

	@Given("^base uri is set for \"([^\"]*)\" endpoint for HTTPClient$")
	public void base_uri_is_set_for_something_endpoint(String baseUriDBKey) throws Throwable {
		String baseUri = Action.getTestData(baseUriDBKey).trim();
		HttpClientUtils.baseUri = baseUri;
		Reporter.addStepLog("<strong>Base URI is set as: </strong>" + baseUri);
	}

	@And("^user set \"([^\"]*)\" for \"([^\"]*)\" endpoint for HTTPClient$")
	public void user_set_something_for_something(String basePathDBKey, String endPointName) throws Throwable {
		String basePath = Action.getTestData(basePathDBKey).trim();
		HttpClientUtils.basePath = basePath;
		request = HttpClientUtils.given();
		Reporter.addStepLog("<strong>Base path is set as: </strong>" + basePath);
	}

	@And("^user execute \"([^\"]*)\" request \"([^\"]*)\" json for HTTPClient$")
	public void user_execute_something_request_something_json(String methodType, String jsonCondition)
			throws Exception {

		methodType = methodType.trim().toLowerCase();
		jsonCondition = jsonCondition.trim().toLowerCase();

		if (jsonCondition.equals("without")) {
			// no code required
		} else if (jsonCondition.equals("with")) {

			request.setContentType("application/json");
			request.setBody(CommonAPISteps.requestJson);

			Reporter.addStepLog("Content Type is set as: " + "application/json");

			// Reporter.addStepLog("<strong>Request JSON: </strong></br>" + requestJson);
			String requestJsonFileName = common.requestFile(CommonAPISteps.requestJson);
			String html = "<lable><font color=#1E90FF>Click on link to see Request</font></lable>" + "<a href=\""
					+ requestJsonFileName
					+ "\" target=\"_blank\" style=\"float:right\"><img src=\"core-image-hyper-link.png\" style=\"background-color:aliceblue\"></a>";

			Reporter.addStepLog(html);

		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>!!! INCORRET JSON CONDITION PROVIDED !!! </font></strong>"
					+ jsonCondition);
			Assert.fail("!!! INCORRET JSON CONDITION PROVIDED !!! " + jsonCondition);
		}

		request.buildUri();

		switch (methodType) {
		case "post": {
			response = request.executeRequest(MethodType.POST);

			break;
		}
		case "put": {
			response = request.executeRequest(MethodType.PUT);
			break;
		}
		case "get": {
			response = request.executeRequest(MethodType.GET);
			break;
		}
		case "delete": {
			response = request.executeRequest(MethodType.DELETE);
			break;
		}
		case "patch":
			// response = RestApiUtils.requestSpecification.patch();
			throw new Exception("PATCH is not implemented !!");

		default: {
			Reporter.addStepLog(
					"<strong><font color=#DC143C>!!! INCORRET HTTP METHOD TYPE PROVIDED !!! </font></strong>"
							+ methodType.toUpperCase());
			Assert.fail("!!! INCORRET HTTP METHOD TYPE PROVIDED !!! " + methodType.toUpperCase());
		}

		}

		Reporter.addStepLog("<strong>HTTP Method Executed: </strong>" + methodType.toUpperCase());

		String responseBody = response.getBody().asString();
		if (responseBody.length() > 0) {

			String fileName = common.responseFile(responseBody);

			String html = "<lable><font color=#1E90FF>Click on link to see Response</font></lable>" + "<a href=\""
					+ fileName
					+ "\" target=\"_blank\" style=\"float:right\"><img src=\"core-image-hyper-link.png\" style=\"background-color:aliceblue\"></a>";

			Reporter.addStepLog(html);

		}

	}

	@And("^user set header (.+) as (.+) for current endpoint for HTTPClient$")
	public void user_set_header_something_as_something_for_current_endpoint(String headerName, String headerValue) {

		headerName = headerName.replace("\"", "");
		headerValue = headerValue.replace("\"", "");

		request.setHeader(headerName, headerValue);

		Reporter.addStepLog("<strong>Header Name: </strong>" + headerName);
		Reporter.addStepLog("<strong>Header Value: </strong>" + headerValue);
	}

	@And("^user set \"([^\"]*)\" parameter (.+) as (.+) for current endpoint for HTTPClient$")
	public void user_set_something_parameter_something_as_something_for_current_endpoint(String parameterType,
			String parameterName, String parameterValue) {

		parameterName = parameterName.replace("\"", "");
		parameterValue = parameterValue.replace("\"", "");

		parameterType = parameterType.trim().toLowerCase();

		switch (parameterType) {
		case "path": {

			request.setPathParameter(parameterName, parameterValue);

			break;
		}
		case "query": {
			request.setQueryParameter(parameterName, parameterValue);
			break;
		}
		case "form": {
			request.setFormParameter(parameterName, parameterValue);
			break;
		}

		default: {
			Reporter.addStepLog("<strong><font color=#DC143C>!!! INCORRET PARAMETER TYPE PROVIDED !!! </font></strong>"
					+ parameterType.toUpperCase());
			Assert.fail("!!! INCORRET PARAMETER TYPE PROVIDED !!! " + parameterType.toUpperCase());
		}

		}

		Reporter.addStepLog("<strong>Parameter Type: </strong>" + parameterType);
		Reporter.addStepLog("<strong>Parameter Name: </strong>" + parameterName);
		Reporter.addStepLog("<strong>Parameter Value: </strong>" + parameterValue);

	}

	@Then("^user verifies the response status code as \"([^\"]*)\" for HTTPClient$")
	public void user_verifies_the_response_status_code_as_something(String expResStatusCode) throws Throwable {

		int actResStatusCode = response.getStatusCode();

		// Reporter.addStepLog("<strong>Expected Response Status Code: </strong>" +
		// expResStatusCode);
		// Reporter.addStepLog("<strong>Actual Response Status Code: </strong>" +
		// actResStatusCode);

		// RestApiHelperMethods.verifyEquals(Integer.parseInt(expResStatusCode),
		// actResStatusCode);

		if (expResStatusCode.contains(String.valueOf(actResStatusCode))) {
			Reporter.addStepLog("Status verification passed !!");
			Reporter.addStepLog("<strong>Expected Status Code: </strong>" + expResStatusCode);
			Reporter.addStepLog("<strong>Actual Status Code: </strong>" + actResStatusCode);
		} else {

			Reporter.addStepLog("Status verification failed !!");
			Reporter.addStepLog("<strong>Expected Status Code: </strong>" + expResStatusCode);
			Reporter.addStepLog("<strong>Actual Status Code: </strong>" + actResStatusCode);

			Assert.fail("Status mismatch");
		}

	}

	@And("^user set pfx certificate \"([^\"]*)\" with password \"([^\"]*)\" for HTTPClient$")
	public void user_set_pfx_certificate_something_with_password_something_for_httpclient(String filename, String pwd) {
		String filePath = qa.framework.utils.FileManager.getFileManagerObj().searchFile("./src/test/resources/",
				filename);

		request.setCetificate(filePath, pwd);
	}

	@And("^user set proxy details \"([^\"]*)\" host name and \"([^\"]*)\" port for HTTPClient$")
	public void user_set_proxy_details_something_host_name_and_something_port(String hostname, String port) {
		request.setProxy(hostname, Integer.parseInt(port));

	}

}
