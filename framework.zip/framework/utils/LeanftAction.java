package qa.framework.utils;

import com.hp.lft.sdk.GeneralLeanFtException;
import com.hp.lft.sdk.TestObject;
import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.Screen;

import qa.framework.report.Report;

public class LeanftAction {

	/**
	 * @author BathriYo
	 * @param field
	 * @param text
	 * @throws GeneralLeanFtException
	 */
	public static void setText(Field field, String text){

		String status = "FAIL";
		try {

			field.setText(text);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Set Text");
			Report.printValue(text);
			Report.printStatus(status);
		}

	} 

	/**
	 * @author BathriYo
	 * @param field
	 * @return String field text
	 */
	public static String getText(Field field) {
		String text = null;
		String status = "FAIL";

		try {

			text = field.getText();
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Text");
			Report.printStatus(status);
		}

		return text;
	}

	/**
	 * Send TE Keys to screen
	 * 
	 * @author BathriYo
	 * @param screen
	 * @param enumKeys
	 */
	public static void sendTeKeys(Screen screen, String enumKeys) {
		String status = "FAIL";

		try {

			screen.sendTEKeys(enumKeys);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Send Te Keys");
			Report.printValue(enumKeys);
			Report.printStatus(status);
		}
	}

	/**
	 * Synchronization 
	 * @author BathriYo
	 * @param testObj
	 */
	public static void sync(TestObject testObj) {

		String status = "FAIL";

		try {

			testObj.waitUntilExists(GlobalVariables.waitTime);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Sync");
			Report.printStatus(status);
		}

	}

	/**
	 * Synchronization
	 * @param testObj
	 * @param millisec
	 */
	public static void sync(TestObject testObj, int millisec) {

		String status = "FAIL";
		try {

			testObj.waitUntilExists(millisec);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Sync");
			Report.printStatus(status);
		}

	}
	
	/**
	 * checking if screen exists or not.
	 * @param screen
	 * @return boolean
	 */
	public static boolean isExists(Screen screen, int timeInSecond) {
		String status = "FAIL";
		boolean flag = false;
		try {

			flag = screen.exists(timeInSecond);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("isExists");
			Report.printStatus(status);
		}
		return flag;
	}
	
	/**
	 * Checking if field exists or not
	 * @param field
	 * @return boolean
	 */
	public static boolean isExists(Field field) {
		String status = "FAIL";
		boolean flag = false;
		try {

			flag = field.exists();
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("isExists");
			Report.printStatus(status);
		}
		return flag;
	}
}
