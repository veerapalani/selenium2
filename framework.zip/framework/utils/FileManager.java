package qa.framework.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;

import qa.framework.report.Report;

/**
 * 
 * @author BathriYo
 *
 */
public class FileManager {

	Logger log = LoggerHelper.getLogger(FileManager.class);

	private static FileManager objFileManager = null;

	private FileManager() {

	}

	/* Singleton */
	public synchronized static FileManager getFileManagerObj() {

		return (objFileManager == null) ? new FileManager() : objFileManager;
	}

	/**
	 * Public util to delete all the files in a folder
	 * 
	 * @author BathriYo
	 * @param folderPath
	 */
	public void deleteAllFilesInFolder(String folderPath) {

		String status = "FAIL";
		try {

			File folder = new File(folderPath);

			for (File file : folder.listFiles()) {
				file.delete();
			}
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Delete All Files");
			Report.printStatus(status);
		}

	}

	/**
	 * Public util to delete file
	 * 
	 * @author BathriYo
	 * @param filePath
	 */
	public void deleteFile(String filePath) {
		String status = "FAIL";
		try {

			File file = new File(filePath);
			file.delete();

			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Delete File");
			Report.printStatus(status);
		}

	}

	/**
	 * Public util to get download folder absolute file path. Path is specified in
	 * config.properties
	 * 
	 * @return
	 */
	public String downloadFolderFilePath() {

		PropertyFileUtils properties = new PropertyFileUtils(System.getProperty("user.dir") + "/config.properties");

		File folder = new File(properties.getProperty("downloadFolder"));

		if (!folder.exists()) {
			folder.mkdir();
		}

		return folder.getAbsolutePath();
	}

	/**
	 * Public util to get download folder absolute file path. user specified path
	 * 
	 * @return String folder path
	 */
	public String downloadFolderFilePath(String folderPath) {

		File folder = new File(folderPath);

		if (!folder.exists()) {
			folder.mkdir();
		}

		return folder.getAbsolutePath();
	}

	/**
	 * Public utils to check if file exists or not
	 * 
	 * @author BathriYo
	 * @param filePath
	 * @return boolean
	 */
	public boolean isFileExists(String filePath) {
		return new File(filePath).exists();
	}

	/**
	 * Public utils to get file path
	 * 
	 * @author BathriYo
	 * @param filePath
	 * @return float
	 */
	public float getFileSize(String filePath) {
		return new File(filePath).length();
	}

	/**
	 * Write to file
	 * 
	 * @param filepath
	 * @param writeStr
	 */
	public void write(String filepath, String writeStr) {

		try {
			FileWriter fw  = new FileWriter(filepath);
			BufferedWriter writer = new BufferedWriter(fw);
			writer.write(writeStr);
			writer.close();
			fw.close();

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * Append Character string in existing file
	 * 
	 * @author Bathriyo
	 * @param filepath
	 * @param writeStr
	 */
	public void append(String filepath, String writeStr) {

		try {
			Files.write(Paths.get(filepath), writeStr.getBytes(), StandardOpenOption.APPEND);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * read file and covert it into string
	 * 
	 * @param filePath
	 * @return String
	 */
	public String readFile(String filePath) {
		StringBuffer content = new StringBuffer();
		BufferedReader bufferedReader = null;

		if (isFileExists(filePath)) {
			try {
				bufferedReader = new BufferedReader(new FileReader(filePath));

				String line = null;

				while ((line = bufferedReader.readLine()) != null) {

					content.append(line).append("\n");
				}
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
				e.printStackTrace();
			} finally {
				try {
					bufferedReader.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}

		}

		return content.toString();

	}

	/**
	 * Creating new File in given format
	 * 
	 * @param filePath
	 * @return boolean
	 */
	public boolean createFile(String filePath) {

		File file = new File(filePath);
		try {
			return file.createNewFile();
		} catch (IOException e) {

			ExceptionHandler.handleException(e);
		}
		return false;
	}

	/**
	 * Creates zip of a directory
	 */
	public void zipDir(String dirPath, String zipFileName) {

		try {

			boolean isZipRequired = false;

			File dir = new File(dirPath);

			/* determining if there are files in the dir provided */
			for (File file : dir.listFiles()) {
				if (!file.getName().endsWith(".zip")) {
					isZipRequired = true;
					break;
				}
			}

			/* Zip will only happen if there are files in the dir */
			if (isZipRequired) {

				FileOutputStream fos = new FileOutputStream(dirPath + "/" + zipFileName + ".zip");

				ZipOutputStream zipOut = new ZipOutputStream(fos);

				File[] allFiles = dir.listFiles();

				byte[] bytes = new byte[1024];

				for (File file : allFiles) {

					if (!file.getName().endsWith(".zip")) {
						FileInputStream fis = new FileInputStream(file);

						ZipEntry zipEntry = new ZipEntry(file.getName());

						zipOut.putNextEntry(zipEntry);

						int length;
						while ((length = fis.read(bytes)) >= 0) {
							zipOut.write(bytes, 0, length);
						}
						fis.close();
					}

				}
				zipOut.closeEntry();
				zipOut.close();
				fos.close();

				log.info("Directory zipped.");

			}

		} catch (Exception e) {

			log.info("Excpetion", ((Throwable) e));

		}

	}

	/**
	 * Create zip of the file
	 * 
	 * @param filePath
	 * @throws FileNotFoundException
	 */
	public void zipFile(String filePath) {

		File file = new File(filePath);

		String path = file.getPath();

		String dirPath = path.substring(0, path.lastIndexOf('\\')).replace("\\", "/");

		String fileName = file.getName();

		try {

			FileOutputStream fos = new FileOutputStream(
					dirPath + "/" + fileName.substring(0, fileName.lastIndexOf(".")) + ".zip");

			ZipOutputStream zipOut = new ZipOutputStream(fos);

			byte[] bytes = new byte[1024];

			if (!file.getName().endsWith(".zip")) {
				FileInputStream fis = new FileInputStream(file);

				ZipEntry zipEntry = new ZipEntry(file.getName());

				zipOut.putNextEntry(zipEntry);

				int length;
				while ((length = fis.read(bytes)) >= 0) {
					zipOut.write(bytes, 0, length);
				}
				fis.close();
			}

			zipOut.closeEntry();
			zipOut.close();
			fos.close();

			log.info("Filed zipped.");

		} catch (Throwable t) {
			log.info("Exception: ", t);
		}

	}

	/**
	 * Search file if exists in specific directory
	 * 
	 * @author bathriyo
	 * @param dirPath  : String
	 * @param fileName : String
	 * @return String
	 * @throws FileNotFoundException
	 */
	public String searchFile(String dirPath, String fileName) {

		File dir = new File(dirPath);

		File[] listFiles = dir.listFiles();

		String filePath = null;

		for (File file : listFiles) {
			if (file.isDirectory()) {

				filePath = searchFile(file.getAbsolutePath(), fileName);

				if (filePath != null) {
					break;
				}
			} else {
				if (file.getName().equalsIgnoreCase(fileName)) {
					filePath = file.getAbsolutePath();
					break;
				}
			}
		}

		return filePath;
	}

	/**
	 * Wait till file is downloaded or wait time out.
	 * 
	 * @author bathriyo
	 * @param dwFileName       : String
	 * @param maxTimeInMinutes : Integer
	 * @param fileExtension    : String (.csv)
	 * @return Boolean
	 */
	public static boolean waitUntilDownloadComplete(String dwFileName, int maxTimeInMinutes, String fileExtension) {

		String dirPath = GlobalVariables.configProp.getProperty("downloadFolder");

		int count = 0;
		int milSec = maxTimeInMinutes * 60 * 1000;

		Reporter.addStepLog("Waiting for file to download.");

		boolean wBreak = false;

		while (count < milSec) {

			wBreak = false;

			File dir = new File(dirPath);
			File[] listFiles = dir.listFiles();
			for (File file : listFiles) {

				if (file.getName().contains(dwFileName) && file.getName().endsWith("fileExtension")) {
					wBreak = true;
					break;
				}
			}

			if (wBreak) {
				break;
			}

			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				/**/
			}

			count += 1000;

		}

		Reporter.addStepLog("Wait finished.");
		return wBreak;

	}
	
	
	/*this function will help to rename the file with dynamic name (eg. employee_12_02_2021 02:48)*/
	public static void renameFile(String dirPath, String startWith, String destPath, String newName, String extension) {

		File src = new File(dirPath);

		File[] listFiles = src.listFiles();

		for (File aFile : listFiles) {
			boolean flag = aFile.getName().startsWith(startWith);

			if (flag) {
				aFile.renameTo(new File(destPath + "/" + newName + extension));
				break;
			}
		}

	}


	/**
	 * Copies a file from destination path to source path
	 * 
	 * @author bathriyo
	 * @param dest
	 * @param src
	 */
	public static void copy(String src, String dest) {

		try {

			com.google.common.io.Files.copy(new File(src), new File(dest));

		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	/**
	 * Convert String in Base64 Code
	 * 
	 * @author bathriyo
	 * @param value
	 * @return String
	 */
	public static String base64Encode(String value) {
		return Base64.getEncoder().encodeToString(value.getBytes());
	}

	public static String base64Decode(String encodedValue) {
		byte[] decodedBytes = Base64.getDecoder().decode(encodedValue);
		return new String(decodedBytes);
	}

	public static void fileUploadUsingAutoIt(String filepath) throws IOException {
		/*
		 * wrapping filePath into double quote to over come space in between directory
		 * and file name
		 */
		File file = new File(filepath);
		File parentFile = file.getParentFile();
		String parent = parentFile.getAbsolutePath();

		parent = "\"" + parent + "\\" + "\"";
		System.out.println(parent);

		String fileName = file.getName();
		fileName = "\"" + fileName + "\"";
		System.out.println(fileName);

		// Runtime.getRuntime().exec("./src/test/resources/exes/FileUpload(x64).exe"+"
		// "+parent+" "+fileName);
		// Runtime.getRuntime().exec("./src/test/resources/exes/FileUpload.exe"+"
		// "+parent+" "+fileName);

		List<String> cmds;
		cmds = Arrays.asList("cmd.exe", "/C", "start", "./src/test/resources/exes/FileUpload(x64).exe", parent,
				fileName);
		ProcessBuilder builder = new ProcessBuilder(cmds);
		Process start = builder.start();
		Action.pause(10000);

		start.destroyForcibly();

	}

	/**
	 * @author bathriyo
	 * @param filepath
	 * @return
	 * @throws IOException
	 */
	public static Date getFileCreatedDate(String filepath) throws IOException {

		Path file = Paths.get(filepath);

		BasicFileAttributes attr = Files.readAttributes(file, BasicFileAttributes.class);

		return CalendarUtils.millisecondToDate(attr.creationTime().to(TimeUnit.MILLISECONDS));

	}

	/**
	 * @author bathriyo
	 * @param filepath
	 * @return
	 * @throws IOException
	 */
	public static Date getFileModifiedDate(String filepath) throws IOException {

		Path file = Paths.get(filepath);

		BasicFileAttributes attr = Files.readAttributes(file, BasicFileAttributes.class);

		return CalendarUtils.millisecondToDate(attr.lastModifiedTime().to(TimeUnit.MILLISECONDS));
	}

}
