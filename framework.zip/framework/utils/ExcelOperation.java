package qa.framework.utils;

public enum ExcelOperation{
	
	LOAD("load"), CREATE("create");
	
	private String operation;
	
	ExcelOperation(String operation){
		this.operation=operation;
	}
	
	public String getOperation() {
		return this.operation;
	}
}