package qa.framework.utils;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.junit.Assert;
import org.openqa.selenium.Cookie;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie.Builder;
import io.restassured.matcher.RestAssuredMatchers;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class RestApiUtils {

	// Global Setup Variables
	public static String path; // Rest request path

	public static RequestSpecification requestSpecification = given();
	public static Logger log = LoggerHelper.getLogger(RestApiUtils.class);

	/**
	 * URI Utilities
	 * 
	 * @param baseURI
	 */

	// Sets Base URI before the test
	public static void setBaseURI(String baseURI) {
		RestAssured.baseURI = baseURI;
	}

	// Sets base path before the test
	public static void setBasePath(String basePathTerm) {
		RestAssured.basePath = basePathTerm;
	}

	// Reset Base URI after the test
	public static void resetBaseURI() {
		RestAssured.baseURI = null;
	}

	// Reset base path after the test
	public static void resetBasePath() {
		RestAssured.basePath = null;
	}

	/*
	 *** search query path of first example*** It is equal to
	 * "barack obama/videos.json?num_of_videos=4"
	 */
	public static void createSearchQueryPath(String searchTerm, String jsonPathTerm, String param, String paramValue) {
		path = searchTerm + "/" + jsonPathTerm + "?" + param + "=" + paramValue;
	}

	/*
	 *** Returns response*** We send "path" as a parameter to the Rest Assured'a "get"
	 * method and "get" method returns response of API
	 */
	public static Response getResponse() {
		return get(path);
	}

	/**
	 * GET Utilities
	 * 
	 * @author ChandregowdaDi
	 * @param URI
	 * @param parametersMap
	 * @return
	 */

	// GET method without Parameters
	public static Response getRequestwithoutParam(String URI) {
		RequestSpecification requestSpecification = RestAssured.given().when();
		Response response = requestSpecification.get(URI);
		return response;
	}

	// GET method with RelaxedHttpsValidation
	public static Response getRequestWithRelaxedHttpsValidation(String URI) {
		RequestSpecification requestSpecification = RestAssured.given().relaxedHTTPSValidation().when();
		Response response = requestSpecification.get(URI);
		return response;
	}

	// GET method with Query Parameters
	public static Response getRequestwithQueryParamRelaxedHttpsValidation(String URI, Map<String, ?> parametersMap) {
		RequestSpecification requestSpecification = RestAssured.given().urlEncodingEnabled(false)
				.queryParams(parametersMap).relaxedHTTPSValidation().when();
		Response response = requestSpecification.get(URI);
		return response;
	}

	// GET method with Query Parameters
	public static Response getRequestwithQueryParam(String URI, Map<String, ?> parametersMap) {
		RequestSpecification requestSpecification = RestAssured.given().urlEncodingEnabled(false)
				.queryParams(parametersMap).relaxedHTTPSValidation().when();
		Response response = requestSpecification.get(URI);
		return response;
	}

	// GET method with Form Parameters
	public static Response GETRequestwithFormParam(String URI, Map<String, ?> parametersMap) {
		RequestSpecification requestSpecification = RestAssured.given().formParams(parametersMap).when();
		Response response = requestSpecification.get(URI);
		return response;
	}

	// GET method with Form Parameters
	public static Response GETRequestwithPathParam(String URI, Map<String, ?> parametersMap) {
		RequestSpecification requestSpecification = RestAssured.given().pathParams(parametersMap).when();
		Response response = requestSpecification.get(URI);
		return response;
	}

	/**
	 * POST Utilities
	 * 
	 * @author ChandregowdaDi
	 * @param URI
	 * @param strJSON
	 * @param parametersMap
	 * @return
	 */

	// POST method without Parameters
	public static Response postRequestwithoutParam(String postServiceURI, String strJSON) {
		RequestSpecification requestSpecification = RestAssured.given().body(strJSON);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.post(postServiceURI);
		return response;
	}

	// POST method without Parameters with relaxed https validation
	public static Response postRequestwithrelaxedhttpvalidation(RequestSpecification request, String postServiceURI) {
		Response rawResponse = request.relaxedHTTPSValidation().post(postServiceURI);
		// log.debug("@Response: " + rawResponse.body().asString());
		return rawResponse;
	}

	// Post method with Query Parameters
	public static Response postRequestwithQueryParam(String postServiceURI, Map<String, ?> parametersMap) {
		RequestSpecification requestSpecification = RestAssured.given().queryParams(parametersMap);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.post(postServiceURI);
		return response;
	}

	// Post method with Form Parameters
	public static Response postRequestwithFormParam(String postServiceURI, Map<String, ?> parametersMap) {
		RequestSpecification requestSpecification = RestAssured.given().formParams(parametersMap);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.post(postServiceURI);
		return response;
	}

	// Post method with Form Parameters
	public static Response postRequestwithPathParam(String postServiceURI, Map<String, ?> parametersMap) {
		RequestSpecification requestSpecification = RestAssured.given().pathParams(parametersMap);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.post(postServiceURI);
		return response;
	}

	public static Response postRequest(RequestSpecification request, String postServiceURI) {
		Response rawResponse = request.post(postServiceURI);
		log.debug("@Response: " + rawResponse.body().asString());
		return rawResponse;
	}

	public static Response postRequest(RequestSpecification request, String postServiceURI, String strJSON) {
		request.body(strJSON);
		Response rawResponse = request.post(postServiceURI);
		log.debug("@Response: " + rawResponse.body().asString());
		return rawResponse;
	}

	/**
	 * PUT Utilies
	 * 
	 * @author Santhosh
	 * @param putServiceURI
	 * @param jsonPath
	 * @return
	 */

	public static Response putRequest(String putServiceURI, String strJSON) {
		RequestSpecification requestSpecification = RestAssured.given().body(strJSON);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.put(putServiceURI);
		log.debug("@Response: " + response.body().asString());
		return response;
	}

	public static Response putRequest(RequestSpecification request, String putServiceURI) {
		Response rawResponse = request.put(putServiceURI);
		log.debug("@Response: " + rawResponse.body().asString());
		return rawResponse;
	}

	public static Response putRequestWithJsonBody(RequestSpecification request, String putServiceURI, String strJSON) {
		request.body(strJSON);
		request.contentType(ContentType.JSON);
		Response rawResponse = request.put(putServiceURI);
		log.debug("@Response: " + rawResponse.body().asString());
		return rawResponse;
	}

	/**
	 * DELETE Utilities
	 * 
	 * @author Santhosh
	 * @param postServiceURI
	 * @param jsonPath
	 * @return
	 */

	public static Response deleteRequest(String deleteServiceURI, String strJSON) {
		RequestSpecification requestSpecification = RestAssured.given().body(strJSON);
		requestSpecification.contentType(ContentType.JSON);
		Response response = requestSpecification.delete(deleteServiceURI);
		log.debug("@Response: " + response.body().asString());
		return response;
	}

	public static Response deleteRequest(RequestSpecification request, String deleteServiceURI) {
		Response rawResponse = request.delete(deleteServiceURI);
		log.debug("@Response: " + rawResponse.body().asString());
		return rawResponse;
	}

	public static Response deleteRequest(RequestSpecification request, String deleteServiceURI, String strJSON) {
		request.body(strJSON);
		request.contentType(ContentType.JSON);
		Response rawResponse = request.delete(deleteServiceURI);
		log.debug("@Response: " + rawResponse.body().asString());
		return rawResponse;
	}

	/**
	 * HEADER Utilities
	 * 
	 * @param request
	 * @param headerName
	 * @param headerValue
	 * @param additionalHeaderValues
	 * @return
	 */

	// Set request headers
	public static RequestSpecification setRequestHeader(RequestSpecification request, String headerName,
			String headerValue) {
		return request.header(headerName, headerValue);
	}

	public static void setRequestHeader(RequestSpecification request, String headerName, String headerValue,
			Object... additionalHeaderValues) {
		request.header(headerName, headerValue, additionalHeaderValues);
	}

	/**
	 * Set Parameter Utilities
	 * 
	 * @author ChandregowdaDi
	 * @param request
	 * @param formParameterName
	 * @param formParameterValue
	 */
	public static void setFormParameter(RequestSpecification request, String formParameterName,
			String formParameterValue) {
		request.formParam(formParameterName, formParameterValue);
	}

	public static void setFormParameter(RequestSpecification request, String formParameterName,
			String formParameterValue, Object... additionalParameterValues) {
		request.formParam(formParameterName, formParameterValue, additionalParameterValues);
	}

	public static void setQueryParameter(RequestSpecification request, String queryParameterName,
			String queryParameterValue) {
		request.queryParam(queryParameterName, queryParameterValue);
	}

	public static void setQueryParameter(RequestSpecification request, String queryParameterName,
			String queryParameterValue, Object... additionalParameterValues) {
		request.queryParam(queryParameterName, queryParameterValue, additionalParameterValues);
	}

	/**
	 * Content Type Utilities
	 * 
	 * @param rawResponse
	 * @return
	 */

	// Get content type from raw response
	public static String getResponseContentType(Response rawResponse) {
		return rawResponse.getContentType();
	}

	// Sets the ContentType*** We should set content type as JSON or XML before
	// starting the test
	public static void setContentType(ContentType Type) {
		given().contentType(Type);
	}

	// Set request content type
	public static void setRequestContentType(RequestSpecification request, String contentType) {
		if (contentType.toUpperCase().contentEquals("XML")) {
			request.contentType("application/xml");
		} else {
			request.contentType("application/json");
		}
	}

	// Get response content encoding type
	public static String getResponseContentEncoding(Response rawResponse) {
		return rawResponse.header("Content-Encoding");
	}

	// Get response server name
	public static String getResponseServer(Response rawResponse) {
		return rawResponse.header("Server");
	}

	/**
	 * Conversion Utilities
	 * 
	 * @param rawResponse
	 * @return
	 */

	// Convert raw response to string
	public static String rawResponseToString(Response rawResponse) {
		String strResponse = rawResponse.asString();
		return strResponse;
	}

	/*
	 *** Returns JsonPath object*** First convert the API's response to String type
	 * with "asString()" method. Then, send this String formatted json response to
	 * the JsonPath class and return the JsonPath
	 */
	public static JsonPath getJsonPath(Response res) {
		String json = res.asString();
		return new JsonPath(json);
	}

	// Convert raw response to XML
	public static XmlPath rawResponseToXML(Response rawResponse) {
		String strResponse = rawResponseToString(rawResponse);
		XmlPath xmlResponse = new XmlPath(strResponse);
		return xmlResponse;
	}

	// Convert raw response to JSON
	public static JsonPath rawResponseToJson(Response rawResponse) {
		String strResponse = rawResponseToString(rawResponse);
		JsonPath x = new JsonPath(strResponse);
		return x;
	}

	/**
	 * 
	 * Public static utility to create a file with value provided in the argument
	 * 
	 * @author BathriYo
	 * @param filePath
	 * @param value
	 * @return File
	 */
	public static File createFile(String filePath, String value) {

		File file = null;
		try {

			file = new File(filePath);

			FileWriter fileWriter = new FileWriter(file);

			fileWriter.write(value);

			fileWriter.flush();

			fileWriter.close();
		} catch (Exception e) {

			ExceptionHandler.handleException(e);

		}

		return file;
	}

	/**
	 * Public static utility to get tag value from xml file using xpath.
	 * 
	 * Reference: //https://howtodoinjava.com/xml/java-xpath-tutorial-example/
	 * 
	 * @author BathriYo
	 * @param file
	 * @param xpathInString
	 * @return List<String>
	 */
	public static List<String> getXMLNodeStringValue(String xmlFilePath, String nodeXpath) {

		List<String> resultList = new ArrayList<String>();

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

			DocumentBuilder builder = factory.newDocumentBuilder();

			Document document = builder.parse(new File(xmlFilePath));

			XPathFactory xpathfactory = XPathFactory.newInstance();
			XPath xpath = xpathfactory.newXPath();

			XPathExpression expr = xpath.compile(nodeXpath);
			Object result = expr.evaluate(document, XPathConstants.NODESET);

			NodeList nodes = (NodeList) result;

			for (int i = 0; i < nodes.getLength(); i++) {

				resultList.add(nodes.item(i).getNodeValue());

			}

		} catch (Exception e) {

			ExceptionHandler.handleException(e);

		}

		return resultList;
	}

	/**
	 * @author BathriYo
	 * 
	 * @param response
	 * @param excelFilePath
	 * @param sheetName
	 * @param rowIndex
	 * @param startCellIndex
	 */
	public static void jsonFieldVerification(Response response, String excelFilePath, String sheetName, int rowIndex,
			int startCellIndex, String jsonKeyColumnName) {

		int keyListLength = -1;

		Map<List<String>, List<String>> jsonKeyValueMap = retriveJsonKeysAndExpectedValue(excelFilePath, sheetName,
				rowIndex, startCellIndex, jsonKeyColumnName);

		// Map.Entry<List<String>, List<String>> entrySet = (Entry<List<String>,
		// List<String>>) jsonKeyValueMap.entrySet();

		List<String> listKey = new ArrayList<String>();
		List<String> listExpectedValue = new ArrayList<String>();

		for (Map.Entry<List<String>, List<String>> entrySet : jsonKeyValueMap.entrySet()) {

			listKey = entrySet.getKey();

			listExpectedValue = entrySet.getValue();
		}

		// Verification
		keyListLength = listKey.size();

		for (int i = 0; i < keyListLength; i++) {

			if (listKey.get(i).length() > 0) {

				Reporter.addStepLog(listKey.get(i));
				RestApiHelperMethods.verifyEquals(listExpectedValue.get(i),
						response.body().jsonPath().get(listKey.get(i)).toString());
			}

		}

	}

	/**
	 * @author BathriYo
	 * @param excelFilePath
	 * @param sheetName
	 * @param rowIndex
	 * @param startCellIndex
	 * @return
	 */
	public static Map<List<String>, List<String>> retriveJsonKeysAndExpectedValue(String excelFilePath,
			String sheetName, int rowIndex, int startCellIndex, String jsonKeyColumnName) {

		List<String> listKey = new ArrayList<String>();
		List<String> listExpectedValue = new ArrayList<String>();

		Map<List<String>, List<String>> jsonKeyValueMap = new HashMap<List<String>, List<String>>();

		// reading keys
		ExcelUtils objExcelUtils = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		try {

			// ExcelUtil.setExcelFile(excelFilePath, "JsonKeys");

			XSSFSheet sheet = objExcelUtils.getSheet("JsonKeys");

			// int rowCount = ExcelUtil.getRowCount();

			// listKey = ExcelUtil.getCellData(jsonKeyColumnName);
			List<Object> columnData = objExcelUtils.getColumnData(sheet, 0, jsonKeyColumnName);

			columnData.forEach(x -> listKey.add((String) x));

			/*
			 * for (int i = 1; i < rowCount; i++) {
			 * 
			 * listKey.add(ExcelUtil.getCellData(i, 0));
			 * 
			 * 
			 * }
			 */

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {

			// ExcelUtil.closeWorkBook();
			objExcelUtils.closeWorkBook();

		}

		// reading expected values
		ExcelUtils objExcelUtils02 = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		try {

			// ExcelUtil.setExcelFile(excelFilePath, sheetName);
			XSSFSheet sheet = objExcelUtils02.getSheet(sheetName);

			// int cellCount = ExcelUtil.getCellCount(rowIndex);
			int cellCount = objExcelUtils02.getCellCount(sheet, rowIndex);

			for (int i = startCellIndex; i < cellCount; i++) {

				listExpectedValue.add(objExcelUtils02.getStringCellData(sheet, rowIndex, i));

			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {

			// ExcelUtil.closeWorkBook();
			objExcelUtils02.closeWorkBook();
		}

		jsonKeyValueMap.put(listKey, listExpectedValue);

		return jsonKeyValueMap;
	}

	/**
	 * Verifying deleted value in json array
	 * 
	 * @author BathriYo
	 * @param response
	 * @param excelFilePath
	 * @param sheetName
	 * @param rowIndex
	 * @param startCellIndex
	 */
	public static void jsonDelArrayObjVerification(Response response, String excelFilePath, String sheetName,
			int rowIndex, int startCellIndex, String jsonKeyColumnName) {

		int keyListLength = -1;
		// List<String>

		Map<List<String>, List<String>> jsonKeyValueMap = retriveJsonKeysAndExpectedValue(excelFilePath, sheetName,
				rowIndex, startCellIndex, jsonKeyColumnName);

		// Map.Entry<List<String>, List<String>> entrySet = (Entry<List<String>,
		// List<String>>) jsonKeyValueMap.entrySet();

		List<String> listKey = new ArrayList<String>();
		List<String> listExpectedValue = new ArrayList<String>();

		for (Map.Entry<List<String>, List<String>> entrySet : jsonKeyValueMap.entrySet()) {

			listKey = entrySet.getKey();

			listExpectedValue = entrySet.getValue();
		}

		keyListLength = listKey.size();

		for (int i = 0; i < keyListLength; i++) {

			if (listKey.get(i).length() > 0) {
				Assert.assertFalse(
						"Expected Value to be deleted: " + listExpectedValue.get(i) + "Actual Value found: "
								+ response.body().jsonPath().get(listKey.get(i)).toString(),
						response.body().jsonPath().get(listKey.get(i)).toString().contains(listExpectedValue.get(i)));

				Reporter.addStepLog(listKey.get(i));
				Reporter.addStepLog("Expected Value to be deleted: " + listExpectedValue.get(i) + "<br>"
						+ "Actual Value found: " + response.body().jsonPath().get(listKey.get(i)).toString());
			}

		}

	}

	/**
	 * Public static util to verified delete value for any attridute in json.
	 * 
	 * @author BathriYo
	 * @param response
	 * @param jsonPathExp
	 */
	public static void jsonDelAttributeVerification(Response response, String jsonPathExp) {

		try {

			String value = response.jsonPath().get(jsonPathExp).toString();
			Reporter.addStepLog(jsonPathExp);
			Assert.fail("Deleted value is avaiable. Value:" + value);

		} catch (NullPointerException e) {

		}
	}

	// Reference Link:
	// https://www.james-willett.com/rest-assured-schema-validation-json-xml
	/**
	 * XML response schema validation.
	 * 
	 * @author BathriYo
	 * @param response
	 * @param xsdFilePath
	 */
	public static void verifyResponseXMLSchema(Response response, String xsdFilePath) {
		try {
			response.then().assertThat().body(RestAssuredMatchers.matchesXsd(new File(xsdFilePath)));
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	// Reference Link:
	// https://www.james-willett.com/rest-assured-schema-validation-json-xml
	/**
	 * Json Schema validation
	 * 
	 * @author BathriYo
	 * @param response
	 * @param jsonSchemaValidationFilePath
	 */
	public static void verifyResponseJsonSchema(Response response, String jsonSchemaValidationFilePath) {

		try {
			response.then().assertThat()
					.body(JsonSchemaValidator.matchesJsonSchema(new File(jsonSchemaValidationFilePath)));
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * This utility will set RequestSpecification.requestSpecification with basic
	 * authentication
	 * 
	 * @param username
	 * @param password
	 */
	public static void basicAuth(String username, String password) {

		try {

			requestSpecification = RestAssured.given().auth().basic(username, password);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * This utility will set RequestSpecification.requestSpecification with
	 * preemptive basic authentication
	 * 
	 * @param username
	 * @param password
	 */
	public static void preemptiveBasicAuth(String username, String password) {

		try {

			requestSpecification = RestAssured.given().auth().preemptive().basic(username, password);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * This utility will set RequestSpecification.requestSpecification with digest
	 * authentication
	 * 
	 * @param username
	 * @param password
	 */
	public static void digestAuth(String username, String password) {

		try {

			requestSpecification = RestAssured.given().auth().digest(username, password);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * Attached file to api request.
	 * 
	 * @author Bathriyo
	 * @param filePath
	 */
	public static void attachFile(String filePath) {
		requestSpecification.contentType("multipart/form-data");
		requestSpecification.multiPart(new File(filePath));

	}

	/**
	 * Resetting Rest Assured parameters
	 */
	public static void reset() {
		RestAssured.reset();

	}

	/**
	 * Set cookie to RestAssured request
	 * 
	 * @author bathriyo
	 * @param name     : String
	 * @param value    : String
	 * @param domain   : String
	 * @param path     : String
	 * @param expiry   : Date
	 * @param isSecure : Boolean
	 */
	public static void setCookie(String name, String value, String domain, String path, Date expiry, boolean isSecure) {

		io.restassured.http.Cookie restCookie;

		Builder builder = new io.restassured.http.Cookie.Builder(name, value).setDomain(domain).setPath(path)
				.setSecured(isSecure);

		if (expiry != null) {
			builder.setExpiryDate(expiry);
		}

		restCookie = builder.build();
		requestSpecification.cookie(restCookie);

		Reporter.addStepLog("<strong>Cookie Name:</strong> " + name);
		Reporter.addStepLog("<strong>Cookie Domain:</strong> " + domain);
	}

	/**
	 * Converts yaml into json. Input to the function is yaml content
	 * 
	 * @author bathriyo
	 * @param filePath : String
	 * @return String
	 * 
	 */
	public static String convertYamlToJson(String yamlContent) {

		String jsonString=null;
		
		try {
			
			ObjectMapper yamlReader = new ObjectMapper(new YAMLFactory());
			Object obj = yamlReader.readValue(yamlContent, Object.class);

			ObjectMapper jsonWriter = new ObjectMapper();
			jsonString=  jsonWriter.writeValueAsString(obj);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonString;
	}
	
	/**
	 * Converts yaml into json. Input of the function in yaml File.
	 * 
	 * @author bathriyo
	 * @param file : File
	 * @return String
	 */
	public static String convertYamlToJson(File file) {

		String jsonString=null;
		
		try {
			
			FileReader fr = new FileReader(file);
			ObjectMapper yamlReader = new ObjectMapper(new YAMLFactory());
			Object obj = yamlReader.readValue(fr, Object.class);

			ObjectMapper jsonWriter = new ObjectMapper();
			jsonString=  jsonWriter.writeValueAsString(obj);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonString;
	}
	

	/**
	 * Set multiple browser cookies
	 * 
	 * @author bathriyo
	 * @param cookies : Set of Cookies
	 */
	public static void setCookies(Set<org.openqa.selenium.Cookie> cookies) {

		Iterator<Cookie> iterator = cookies.iterator();

		while (iterator.hasNext()) {
			Cookie cookie = iterator.next();

			String name = cookie.getName();
			String value = cookie.getValue();
			String domain = cookie.getDomain();
			String path = cookie.getPath();
			Date expiry = cookie.getExpiry();
			boolean isSecure = cookie.isSecure();

			setCookie(name, value, domain, path, expiry, isSecure);

		}
	}

}
