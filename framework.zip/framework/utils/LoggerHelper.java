package qa.framework.utils;

import java.io.File;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.Assert;

public class LoggerHelper {

	private static boolean root = false;

	public static String logPath;

	public synchronized static void createLogFolder() {

		String userDir = System.getProperty("user.dir");
		String folderName = CalendarUtils.getCalendarUtilsObject().getTimeStamp("ddMMyyyy_HHmmss");

		logPath = userDir + "/logs/" + folderName;

		new File(LoggerHelper.logPath).mkdir();

	}

	public synchronized static Logger getLogger(Class cls) {
		if (root) {
			return Logger.getLogger(cls);
		}

		LoggerHelper.createLogFolder();

		String logLevel = System.getProperty("logLevel", GlobalVariables.configProp.getProperty("logLevel"));

		PropertiesConfiguration config;
		try {
			config = new PropertiesConfiguration("log4j.properties");
			config.setProperty("logFolder", LoggerHelper.logPath);
			config.setProperty("logLevel", logLevel);
			config.save();
		} catch (ConfigurationException e) {

			e.printStackTrace();
			Assert.fail();
		}

		PropertyConfigurator.configure("log4j.properties");

		root = true;
		return Logger.getLogger(cls);
	}

}