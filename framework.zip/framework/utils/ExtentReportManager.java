package qa.framework.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportManager {

	String reportPath;
	ExtentHtmlReporter htmlReport;

	ExtentTest test;

	String userDir = System.getProperty("user.dir");
	String extentReportDirPath = userDir + "/test-output/extent-report";
	String screenshotDirPath = extentReportDirPath + "/images";
	

	private static ThreadLocal<ExtentTest> TTest = new ThreadLocal<ExtentTest>();

	private void configExtentReport() {

		/* Configuring Extend report */
		reportPath = extentReportDirPath + "/extent-testng.html";
		htmlReport = new ExtentHtmlReporter(reportPath);

		htmlReport.config().setDocumentTitle("Unicorn");
		htmlReport.config().setReportName("Execution Report");
		htmlReport.config().setTheme(Theme.STANDARD);
		htmlReport.config().enableTimeline(true);
		
		
		GlobalVariables.extentReport = new ExtentReports();
		GlobalVariables.extentReport.attachReporter(htmlReport);

		
		/* End */

	}

	private void configLogger() {
		LoggerHelper.createLogFolder();
	}

	private void configReportFolder() {
		/**************************************************************/
		/* Creating image folder for screenshot */

		File extentReportDir = new File(extentReportDirPath);
		File screenshotDir = new File(screenshotDirPath);

		/* checking if test-output folder exists or not */
		String testOutputFolder = System.getProperty("user.dir") + "/" + "test-output";
		File testOutputDir = new File(testOutputFolder);
		if (!testOutputDir.exists()) {
			testOutputDir.mkdir();
		}

		/* Checking if cucumber-reports directory exists or not */
		if (!extentReportDir.exists()) {

			/*
			 * Note: after Maven clean target directory will not have cucumber-report
			 * directory. Due to which 'image' dir will not get created and screenshot will
			 * not get saved. Thus checking and creating cucumber-reports dir.
			 */
			new File(extentReportDirPath).mkdir();
		}

		/* removing screenshot from previous run by deleting images folder */
		if (screenshotDir.exists()) {

			try {
				FileUtils.deleteDirectory(screenshotDir);
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}

		new File(screenshotDirPath).mkdir();
		
		CaptureScreenshot.imageFolderPath=screenshotDirPath;
		/**************************************************************/
	}

	public void setExtentRport() {

		/* creating logger folder */
		configLogger();

		/* creating image folder */
		configReportFolder();

		/* configuring Extent report */
		configExtentReport();

	}

	/**
	 * updating test method status as PASSED, FAILED or SKIPPED
	 * 
	 * @param result
	 * @return ExtentTest
	 */
	public ExtentTest updateTestStatus(ITestResult result) {

		ExtentTest status = null;
		/* Extent Report Status update */
		try {

			int statusCode = result.getStatus();
			status = TTest.get().createNode("Test Status");

			if (statusCode == ITestResult.SUCCESS) {

				status.log(Status.PASS, "PASSED");

			} else if (statusCode == ITestResult.FAILURE) {

				status.log(Status.FAIL, result.getThrowable());

			} else if (statusCode == ITestResult.SKIP) {

				status.log(Status.SKIP, "SKIPPED");

			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
		return status;
	}

	/**
	 * Crating categories in extent report based on input provided
	 * 
	 * @param listGroupIDs
	 */
	public void createCategories(String[] listGroupIDs) {
		/* Creating Categories based on Groups */
		if (listGroupIDs.length > 0) {
			/* creating categories for test */
			for (String category : listGroupIDs) {
				TTest.get().assignCategory(category);
			}
		}
	}

	/**
	 * 
	 * @param fileName
	 */
	public void attachScreenshot(String fileName) {
		try {
			TTest.get().addScreenCaptureFromPath(CaptureScreenshot.screenCapture(fileName));
		} catch (IOException e) {
			ExceptionHandler.handleException(e);
		}
	}

	/**
	 * Setting Extent report test
	 * 
	 * @author BathriYo
	 * @param test
	 */
	public static void setTest(ExtentTest test) {

		TTest.set(test);

	}

	/**
	 * Get Extent Test based on thread
	 * 
	 * @author BathriYo
	 * @return ExtentTest
	 */
	public static ExtentTest getTest() {
		return TTest.get();
	}

	
	/**
	 * Creates a node with message
	 * @author BathriYo
	 * @param test
	 * @param message
	 * return ExtentTest 
	 */
	public static ExtentTest logNode(String message) {
		ExtentTest node = getTest().createNode(message);
		return node;
	}
	
	/**
	 * Creates node with message and attach screenshot
	 * @author BathriYo
	 * @param test
	 * @param message
	 * @param screenshotPath
	 * @return ExtentTest
	 */
	public static ExtentTest logNode(ExtentTest test, String message, String screenshotPath) {
		try {
			
			ExtentTest node = test.createNode(message);
			node.info("Screenshot:");
			node.addScreenCaptureFromPath(screenshotPath);
			
			return node;
			
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		
		return null;
		
	}
}
