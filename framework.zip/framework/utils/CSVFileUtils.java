package qa.framework.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author bathriyo
 *
 */
public class CSVFileUtils {

	private static CSVFileUtils _obj;

	private CSVFileUtils() {

	}

	public static CSVFileUtils getInstance() {

		return _obj == null ? _obj = new CSVFileUtils() : _obj;
	}

	/**
	 * Reads csv file and store it as List of array
	 * 
	 * @author bathriyo
	 * @param filePath
	 * @param delimiter
	 * @return List<String[]>
	 */
	public List<String[]> readAll(String filePath, String delimiter) {

		BufferedReader bufReader = null;

		List<String[]> readAll = new ArrayList<String[]>();

		try {

			bufReader = new BufferedReader(new FileReader(filePath));

			String line;

			while ((line = bufReader.readLine()) != null) {

				readAll.add(line.split(delimiter));
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {

			try {
				/* Closing buffered reader */
				bufReader.close();

			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}

		return readAll;

	}

	public List<String[]> readAllCommaSeparatedValues(String filePath){
		BufferedReader bufReader = null;

		List<String[]> readAll = new ArrayList<String[]>();

		try {

			bufReader = new BufferedReader(new FileReader(filePath));

			String line;

			while ((line = bufReader.readLine()) != null) {

				readAll.add(split(line));
			}
			
			
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {

			try {
				/* Closing buffered reader */
				bufReader.close();

			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}

		return readAll;

	}
	private String[] split(String line) {

		String newline = "";
		boolean inQuotes = false;

		for (int charIndex = 0; charIndex < line.length(); charIndex++) {

			/* boolean variable to check for quotes start and end */
			if (line.charAt(charIndex) == '\"') {
				inQuotes = !inQuotes;

			}

			/* char is not comma (,) add it in string */
			if (line.charAt(charIndex) != ',') {

				newline = newline + line.charAt(charIndex);

			}
			/* if char is comma (,) but inside quotes then add it in string */
			else if (inQuotes && line.charAt(charIndex) == ',') {

				newline = newline + line.charAt(charIndex);

			}
			/* if char is comma (,) but out side quotes then replace with semi-colon */
			else if (!inQuotes && line.charAt(charIndex) == ',') {

				newline = newline + ";";

			}
		}
		return newline.replace("\"", "").split(";");

	}
	
	
	/**
	 * Return's string cell value in a row
	 * 
	 * @author bathriyo
	 * @param list
	 * @param row
	 * @param column
	 * @return String
	 */
	public String getValue(List<String[]> list, int row, int column) {
		return list.get(row)[column];
	}

	/**
	 * Return's all the values in a column
	 * @author bathriyo 
	 * @param list
	 * @param column
	 * @return List<String>
	 */
	public List<String> getColumnValues(List<String[]> list, int column) {
		
		List<String> columnValues= new ArrayList<String>();

		for(String[] arr: list) {
			columnValues.add(arr[column]);
		}
		
		return columnValues;
	}

}
