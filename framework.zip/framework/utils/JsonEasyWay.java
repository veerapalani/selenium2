package qa.framework.utils;

import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

public class JsonEasyWay {

	String value = "attribute not found";

//	  @Test public void test() {
//	  
//	  String source = FileManager.getFileManagerObj().readFile(
//	  "./src/test/resources/dummy/aPartyJson.json");
//	  
//	  System.out.println(getAttributeValue(source, "fatca.id", -1));
//	  System.out.println(getAttributeValue(source, "approvalActionDate", 2));
//	  
//	  }

	public String getAttributeValue(String json, String attributeName, int index) {

		String[] attributes = attributeName.split("\\.");

		for (int i = 0; i < attributes.length; i++) {

			if (i == 0) {

				if (json.startsWith("{")) {
					JSONObject obj = new JSONObject(json);
					getObjectAttributeValue(obj, attributes[i]);
				} else {
					JSONArray jsonArr = new JSONArray(json);
					getArrayAttributeValue(jsonArr, attributes[i]);
				}

			} else {

				if (value.startsWith("{")) {

					JSONObject objValue = new JSONObject(value);
					value = "attribute not found";
					getObjectAttributeValue(objValue, attributes[i]);

				}

			}

		}

		if (!value.equals("attribute not found") && index > -1) {

			/* in case array value is like this : 00|00|01 */
			if (value.contains("|")) {
				value = value.split("\\|")[index];
			} else
			/* in case array value is like this: ["00","62"] */
			if (value.startsWith("[") && !value.contains("{")) {

				JSONArray jsonArr = new JSONArray(value);
				value = jsonArr.getString(index).toString();
			} else
			/*
			 * in case array value is like this:
			 * [{"apple":"red","orange":"orange"},{"leaf":"green"}]
			 */
			/* can not split directly with comma. */
			/*
			 * also we may have json object inside json object like,
			 * [{"apple":"red","inside":{"seed":"black","flesh":"white"}},{"leaf":"green"}]
			 */
			if (value.startsWith("[") && value.contains("{")) {

				JSONArray jsonArr = new JSONArray(value);
				value = jsonArr.getJSONObject(index).toString();

			}
		}

		return value;
	}

	private void getArrayAttributeValue(JSONArray jsonArr, String attributeName) {

		if (!jsonArr.isEmpty()) {

			Iterator<Object> arrIterator = jsonArr.iterator();

			while (arrIterator.hasNext()) {
				/* "color":["blue","white"], then valueInsideArr="blue","white */
				/* "color":[{"blue"},{"white"}], then valueInsideArr= {"blue"},{"white"} */

				String valueInsideArr = arrIterator.next().toString();

				if (valueInsideArr.startsWith("{")) {

					getObjectAttributeValue(new JSONObject(valueInsideArr), attributeName);
				}
			}

		}
	}

	private void getObjectAttributeValue(JSONObject jsonObj, String attributeName) {

		Iterator<String> keys = jsonObj.keys();

		while (keys.hasNext()) {

			String currentNode = keys.next().toString();

			String isValue = jsonObj.get(currentNode).toString();

			if (currentNode.equals(attributeName)) {

				if (value.equals("attribute not found")) {
					value = isValue;

				} else {
					value = value + "|" + isValue;
				}

			} else if (isValue.startsWith("{")) {

				getObjectAttributeValue(jsonObj.getJSONObject(currentNode), attributeName);

			} else if (isValue.startsWith("[")) {
				JSONArray jsonArray = jsonObj.getJSONArray(currentNode);
				getArrayAttributeValue(jsonArray, attributeName);

			} else {
				// blank
			}

		}

	}

}
