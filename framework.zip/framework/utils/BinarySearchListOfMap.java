package qa.framework.utils;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class BinarySearchListOfMap {

	String mapkey;
	List<Map<String, String>> mapList;

	public BinarySearchListOfMap(List<Map<String, String>> mapList, String mapkey) {
		this.mapkey = mapkey;
		
		Collections.sort(mapList, new SortListOfMap(mapkey)); // sorting the list based on Map key provided
		
		this.mapList = mapList;
	}

	public int binarySearch(int startIndex, int endIndex, String search) {

		if(endIndex>=startIndex) {
			
			int midIndex = startIndex+ (endIndex - startIndex)/2; //get mid index of List
			String value = mapList.get(midIndex).get(mapkey);
			
			
			if (search.compareTo(value) == 0) {
				return midIndex;
			}
			if (search.compareTo(value) < 0) {
				//searched value is smaller than mid value
				return binarySearch(0, midIndex - 1,search);
			}
			
			if(search.compareTo(value)>0)
				//searched value is greater than mid value
				return binarySearch(midIndex+1, endIndex,search); 
		}
		 		
		return -1; //returning -1 if value is not found
	}
	
	

}
