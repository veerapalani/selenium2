package qa.framework.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

/**
 * Helps to query Excel as DataBase
 * <ul>
 * <li>Examples: Select Query : "Select * from Sheet1 where ID=100 and
 * name='John'"
 * 
 * <li>Update Query : "Update Sheet1 Set Country='US' where ID=100 and
 * name='John'"
 * 
 * <li>Insert Query : "INSERT INTO sheet4(Name,Country) VALUES('Peter','UK')"
 * 
 * <li>Multiple Where : "Select * from Sheet1 where column1=value1 and
 * column2=value2 and column3=value3"
 * 
 * <li>Like : "Select * from Sheet1 where Name like 'Cod%'"
 * </ul>
 * Reference: http://codoid.com/fillo/
 * 
 * @author 10650956
 *
 */
public class ExcelFilloUtils {

	private Fillo fillo;
	private Connection connection;
	private Recordset recordSet;

	/**
	 * Set excel
	 * 
	 * @param filePath : String
	 */
	public ExcelFilloUtils(String filePath) {
		this.fillo = new Fillo();
		try {

			connection = fillo.getConnection(filePath);

		} catch (FilloException ex) {
			ex.printStackTrace();
		}

	}

	/**
	 * Execute Query
	 * 
	 * @author 10650956
	 * @param query : String
	 * @return Recordset
	 */
	public Recordset executeQuery(String query) {

		try {

			this.recordSet = connection.executeQuery(query);
			return recordSet;
		} catch (FilloException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public int executeUpdate(String query) {
		try {
			return connection.executeUpdate(query);
		} catch (FilloException e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	public int getRecordCount() {
		try {
			return recordSet.getCount();
		} catch (FilloException e) {

			e.printStackTrace();
		}
		return -1;
	}

	/**
	 * Index start from 0. Return column name
	 * 
	 * @author 10650956
	 * @param index : Integer
	 * @return String
	 */
	public String getColumnName(int index) {

		return getColumnNames().get(index);

	}

	/**
	 * Get list of Columns
	 * 
	 * @author 10650956
	 * @return ArrayList<String>
	 */
	public ArrayList<String> getColumnNames() {
		try {
			return recordSet.getFieldNames();
		} catch (FilloException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Get record count
	 * 
	 * @author 10650956
	 * @return : Integer
	 */
	public int getColumnCount() {
		try {
			return recordSet.getFieldNames().size();
		} catch (FilloException e) {
			e.printStackTrace();
		}
		return -1;
	}

	public List<Map<String, String>> parseRecordSet() {

		List<Map<String, String>> records = new ArrayList<Map<String, String>>();

		int columnCount = getColumnCount();
		ArrayList<String> columnNames = getColumnNames();

		try {
			
			while (recordSet.next()) {
				Map<String, String> map = new HashMap<String, String>();

				for (int index = 0; index < columnCount; index++) {
					String columnName = columnNames.get(index);
					map.put(columnName, recordSet.getField(columnName));
				}
				
				records.add(map);

			}
		} catch (FilloException e) {
			e.printStackTrace();
		}
		
		return records;
	}
	
	public void close() {
		recordSet.close();
		connection.close();
	}

}
