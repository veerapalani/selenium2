package qa.framework.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class CalendarUtils {

	private static CalendarUtils objCalendarUtils;
	
	/**
	 * private constructor for singleton approach
	 */
	private CalendarUtils() {

	}

	/**
	 * to get instance of CalendarUtils class
	 * 
	 * @author BathriYo
	 * @return CalendarUtils
	 */
	public synchronized static CalendarUtils getCalendarUtilsObject() {
		return (objCalendarUtils == null) ? new CalendarUtils() : objCalendarUtils;
	}

	/**
	 * ":" should NOT be given as DataFormat
	 * 
	 * @author BathriYo
	 * @return String
	 */
	public synchronized String getTimeStamp(String dateFormat) {
		Date currentDate = new Date();
		SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);
		return dateFormatter.format(currentDate);

	}

	/**
	 * Function will gettin you future and previous data based on days
	 * 
	 * @author kumarse
	 * @param futureDate
	 * @return futureDate (ex : if you give +2 , then get you future date of 2 days
	 *         from current date and same for previous date but value should -2)
	 */
	public static String getPreviousAndFutureDate(String futureDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yy");
		calendar.add(Calendar.DATE, Integer.parseInt(futureDate));
		return dateFormatter.format(calendar.getTime());

	}
	
	/**
	 * Change the date format based on user input format
	 * 
	 * @author kumarse
	 * @param dateVlaue
	 * @param givenFormat
	 * @param reqformat
	 * @return
	 * @throws ParseException
	 */
	public static String changeDateFormatSelection(String dateVlaue,String givenFormat,String reqformat) throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat(givenFormat);
		Date date = null;
		try {
			date = formatter.parse(dateVlaue);
			System.out.println("data::"+date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SimpleDateFormat formatter1 = new SimpleDateFormat(reqformat);
		String dateString = formatter1.format(date);
		return dateString;
	}
	
	/**
	 * Convert date into given format String
	 * 
	 * @author bathriyo
	 * @param format : String
	 * @param date : Date
	 * @return String
	 */
	public static String dateToString(String format, Date date) {
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		String strDate = dateFormatter.format(date);
		
		return strDate;
	}
	
	public static Date stringToDate(String formate, String strDate) {
		Date date = null;
		try {
			date= new SimpleDateFormat(formate).parse(strDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return date;
	}
	
	
	public static String getTomorrowDate(String format) {
		Date now = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_YEAR, 1);
		Date tomorrow = cal.getTime();
		SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
		return dateFormatter.format(tomorrow);
	}
	
	public static Date millisecondToDate(long millisecond) {

		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(millisecond);
		return cal.getTime();
	}
	public static String selectRandomDates(int startYear, int endYear) {

		GregorianCalendar gc = new GregorianCalendar();

		int year = randBetween(startYear, endYear);

		gc.set(Calendar.YEAR, year);

		int dayOfYear = randBetween(1, gc.getActualMaximum(Calendar.DAY_OF_YEAR));

		gc.set(Calendar.DAY_OF_YEAR, dayOfYear);

		System.out.println(gc.get(Calendar.YEAR) + "-" + (gc.get(Calendar.MONTH) + 1) + "-" + gc.get(Calendar.DAY_OF_MONTH));
        String s1=gc.get(Calendar.YEAR) + "-" + (gc.get(Calendar.MONTH) + 1) + "-" + gc.get(Calendar.DAY_OF_MONTH);
		return s1;
		}

		public static int randBetween(int start, int end) {
		return start + (int)Math.round(Math.random() * (end - start));
		}
		public static String selectRandomDates1(int startYear, int endYear) {

			GregorianCalendar gc = new GregorianCalendar();

			int year = randBetween(startYear, endYear);

			gc.set(Calendar.YEAR, year);

			int dayOfYear = randBetween(1, gc.getActualMaximum(Calendar.DAY_OF_YEAR));

			gc.set(Calendar.DAY_OF_YEAR, dayOfYear);

			System.out.println((gc.get(Calendar.MONTH) + 1) + "/" + gc.get(Calendar.DAY_OF_MONTH) + "/" + gc.get(Calendar.YEAR));
	        String s1=(gc.get(Calendar.MONTH) + 1) + "/" + gc.get(Calendar.DAY_OF_MONTH) + "/" + gc.get(Calendar.YEAR);
			return s1;
			}

			

}
