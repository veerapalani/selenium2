package qa.framework.utils;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.config.SslConfigs;

public class KafkaProducerUtil {
	
	static KafkaProducerUtil prod = new KafkaProducerUtil();
	static Properties prop = new Properties();
    public static Producer<Long, String> createProducer() {
        Properties RunnerClasss = new Properties();
        RunnerClasss.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,prop.getProperty("BOOTSTRAP_SERVERS_CONFIG"));
		RunnerClasss.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,prop.getProperty("KEY_SERIALIZER_CLASS_CONFIG"));
		RunnerClasss.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,prop.getProperty("VALUE_SERIALIZER_CLASS_CONFIG"));
		RunnerClasss.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, prop.getProperty("SECURITY_PROTOCOL_CONFIG"));
		RunnerClasss.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,prop.getProperty("SSL_TRUSTSTORE_LOCATION_CONFIG"));
		RunnerClasss.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, prop.getProperty("SSL_TRUSTSTORE_PASSWORD_CONFIG"));
		RunnerClasss.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, prop.getProperty("SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG"));
        //props.put(ProducerConfig.PARTITIONER_CLASS_CONFIG, CustomPartitioner.class.getName());
        return new KafkaProducer<>(RunnerClasss);
    }
    public static void runProducer(String topic_name,String message) {
    	loadProp();
    	Producer<Long, String> producer = KafkaProducerUtil.createProducer();
    	
    	            ProducerRecord<Long, String> record = new ProducerRecord<Long, String>(topic_name,message);
    	            try {
    	            RecordMetadata metadata = producer.send(record).get();
    	                        //System.out.println("Record sent with key " + "1" + " to partition " + metadata.partition()
    	                        //+ " with offset " + metadata.offset());
    	            System.out.println("Done");
    	                        
    	                 } 
    	            catch (ExecutionException e) {
    	                     System.out.println("Error in sending record");
    	                     System.out.println(e);
    	                  } 
    	             catch (InterruptedException e) {
    	                      System.out.println("Error in sending record");
    	                      System.out.println(e);
    	                  }
    	            producer.close();
    	         }
    static void loadProp() {
    	try {
    		
    		prop.load(new FileInputStream("C:\\Users\\MoharanaBh\\git\\unicornqa\\unicornqa\\Unicorn\\KafkaProperties"));  		
    	} 
    	catch (IOException ex) {
    	    ex.printStackTrace();
    	}
    	}
    	    
}