package qa.framework.utils;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.mail.Multipart;
import javax.mail.internet.MimeMultipart;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import io.cucumber.core.api.Scenario;
import io.cucumber.core.event.Status;
import qa.framework.dbutils.SQLDriver;

public class SIT2Sanity {

	public static boolean reportSwitch = false;
	public static boolean sitEmailSwitch = false;
	private static String dest;

	private static Logger log = LoggerHelper.getLogger(SIT2Sanity.class);

	private static void reportSwitch() {
		/* reading from cmd line */
		String cmdReportSwitch = System.getProperty("sit2_sanity");

		if (cmdReportSwitch != null) {
			reportSwitch = Boolean.parseBoolean(cmdReportSwitch);
		} else {

			/* reading from property file */
			reportSwitch = Boolean.parseBoolean(GlobalVariables.configProp.getProperty("sit2_sanity"));
		}
	}

	private static void emailSwitch() {
		/* reading from cmd line */
		String cmdSITEmailSwitch = System.getProperty("sit2_sanity_email");

		if (cmdSITEmailSwitch != null) {
			sitEmailSwitch = Boolean.parseBoolean(cmdSITEmailSwitch);
		} else {

			/* reading from property file */
			sitEmailSwitch = Boolean.parseBoolean(GlobalVariables.configProp.getProperty("sit2_sanity_email"));
		}
	}

	public static void config() {
		reportSwitch();
		emailSwitch();
	}

	private static Map<String, String> statusMap = new HashMap<String, String>();;
	// private static Map<String,String> descriptionMap;

	public static void updateSITReport(Scenario scenario) {
		// for eg. [UPRS-19805] Verify display and functionality of Calculate Button in
		// Holdings tab
		String scenarioName = scenario.getName();
		String[] split = scenarioName.split("]");

		String testId = split[0].replace("[", "");
		String status = scenario.getStatus().toString();

		status = status.substring(0, 1).toUpperCase() + status.substring(1).toLowerCase();

		statusMap.put(testId, status);

	}

	public static void setStatusMap(String testId, Status status) {

		String strStatus = status.toString();
		strStatus = strStatus.substring(0, 1).toUpperCase() + strStatus.substring(1).toLowerCase();

		statusMap.put(testId, strStatus);
	}

	public static void writeReport(String startTime, String endTime) {

		PropertyFileUtils extentPro = new PropertyFileUtils("./src/test/resources/extent.properties");

		String src = "./src/test/resources/sit-sanity/SIT2_Sanity_Status.xlsx";
//		dest = "./" + extentPro.getProperty("extent.reporter.spark.out") + "/" + "SIT2_Sanity_Status - "
//				+ CalendarUtils.getCalendarUtilsObject().getTimeStamp("MMM dd yyy") + ".xlsx";

		dest = "./" + extentPro.getProperty("extent.reporter.spark.out") + "/" + "SIT2_JAVA_Status_"+SQLDriver.getEnvironment()+".xlsx";

		/* copying template to Spark folder */
		FileManager.copy(src, dest);

		ExcelUtils objExcel = new ExcelUtils(ExcelOperation.LOAD, dest);

		XSSFSheet statusSheet = objExcel.getSheet("Sanity_Status");
		objExcel.setCellData(statusSheet, 1, 2, startTime);
		objExcel.setCellData(statusSheet, 2, 2, endTime);

		XSSFSheet resultSheet = objExcel.getSheet("Run_Results");
		int statusColunIndex = objExcel.getCellIndexByCellValue(resultSheet, 0, "Status");

		List<Object> lstJiraTestIds = objExcel.getColumnData(resultSheet, 0, "JIRA Test ID");

		/* updating SIT Sanity with java project scenario result */
		for (int index = 0; index < lstJiraTestIds.size(); index++) {

			String testId = (String) lstJiraTestIds.get(index);

			/* check for no value */
			if (testId.length() > 0) {
				for (Entry<String, String> entry : statusMap.entrySet()) {

					if (entry.getKey().contains(testId)) {
						objExcel.setCellData(resultSheet, (index + 1), statusColunIndex, entry.getValue().toString());
					}
				}
			}

		}

		/* updating SIT Sanity with UFT project result */

		/*
		 * try {
		 * 
		 * PropertyFileUtils pro = new PropertyFileUtils("config.properties"); String
		 * uftFile = pro.getProperty("sit2_uft_report");
		 * 
		 * File file = new File(uftFile);
		 * 
		 * if (file.exists()) {
		 * 
		 * String uftResultFilePath = "./" +
		 * extentPro.getProperty("extent.reporter.spark.out") + "/SIT_UFT_Results.xlsx";
		 * 
		 * copying UFT result file from remote location to Spark folder //
		 * FileManager.copy("\\\\10.101.0.77\\SIT2_UFT_Sanity\\Automation New set //
		 * Plan.xlsx", uftResultFilePath); FileManager.copy(uftFile, uftResultFilePath);
		 * 
		 * ExcelUtils objUTF = new ExcelUtils(ExcelOperation.LOAD, uftResultFilePath);
		 * XSSFSheet sheet = objUTF.getSheet("ScriptList");
		 * 
		 * List<Object> lstUFTJiraIds = objUTF.getColumnData(sheet, 0, "JIRA_ID");
		 * List<Object> lstUFTStatus = objUTF.getColumnData(sheet, 0, "Status");
		 * 
		 * for (Object jiraId : lstUFTJiraIds) {
		 * 
		 * String strJiraId = jiraId.toString().trim();
		 * 
		 * if (strJiraId.length() > 0) { boolean isJiraIdPresentInSanitySheet =
		 * lstJiraTestIds.contains(strJiraId);
		 * 
		 * if (isJiraIdPresentInSanitySheet) {
		 * 
		 * int index = lstUFTJiraIds.indexOf(strJiraId); String status =
		 * lstUFTStatus.get(index).toString().trim();
		 * 
		 * int rowIndex = lstJiraTestIds.indexOf(strJiraId) + 1;
		 * 
		 * if (status.equalsIgnoreCase("pass") || status.equalsIgnoreCase("passed")) {
		 * 
		 * objExcel.setCellData(resultSheet, rowIndex, statusColunIndex, "Passed");
		 * 
		 * } else if (status.equalsIgnoreCase("fail") ||
		 * status.equalsIgnoreCase("failed")) {
		 * 
		 * objExcel.setCellData(resultSheet, rowIndex, statusColunIndex, "Failed"); }
		 * 
		 * } log.info(strJiraId + " is not available in SIT2_Sanity sheet"); } }
		 * 
		 * objUTF.closeWorkBook();
		 * 
		 * } else { log.info("!!! SIT2 Sanity UFT Report NOT found !!! " + uftFile); }
		 * 
		 * } catch (Exception e) { e.printStackTrace(); }
		 */

		objExcel.evaluateAll();
		objExcel.recalculateFormulaAfterOpen(true);

		objExcel.closeWorkBook();

		FileManager.copy(dest, "\\\\10.101.0.77\\test\\SIT2_JAVA_Sanity\\"+"SIT2_JAVA_Status_"+SQLDriver.getEnvironment()+".xlsx");

	}

	public static void sendReportViaMail() {

		PropertyFileUtils emailPro = new PropertyFileUtils("emailconfig.properties");

		String from = emailPro.getProperty("from_id");
		String tos = emailPro.getProperty("recipient_ids");
		String encodedPwd = emailPro.getProperty("password");
		String subject = emailPro.getProperty("subject");
		String body = emailPro.getProperty("body_message");
		String host = emailPro.getProperty("host");
		int port = Integer.parseInt(emailPro.getProperty("port"));

		qa.framework.emailutils.Email email = new qa.framework.emailutils.Email();

		email.config(host, port, from, encodedPwd);
		email.from(from).tos(tos);
		email.subject(subject + " - " + CalendarUtils.getCalendarUtilsObject().getTimeStamp("MMM dd yyyy"));

		Multipart multipart = new MimeMultipart();

		email.body(multipart, body);
		email.attachment(multipart, dest);

		email.sendMail(multipart);

	}

}
