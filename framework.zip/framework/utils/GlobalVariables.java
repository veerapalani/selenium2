package qa.framework.utils;

import com.aventstack.extentreports.ExtentReports;

import org.apache.commons.configuration.Configuration;
import qa.framework.webui.browsers.Browser;

public class GlobalVariables {
	
	public static String browserName;
	public static String driverName;
	public static Browser browser;
	public static int waitTime = 60;
	public static String applicationName;
	public static PropertyFileUtils configProp = null;
	public static Configuration testData = null;
	public static String applicationURL=null;
	
	public static ExtentReportManager extentReportManagerObj;
	public static ExtentReports extentReport;
	
//	public static ExtentTest test=null;	

}
