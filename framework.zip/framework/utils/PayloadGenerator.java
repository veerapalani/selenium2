package qa.framework.utils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class PayloadGenerator {
	public static String generatePayLoadString(String filename) throws IOException {
		String filePath = System.getProperty("user.dir") + "\\Resource\\" + filename;
		return new String(Files.readAllBytes(Paths.get(filePath)));
	}

}
