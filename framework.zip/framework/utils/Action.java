package qa.framework.utils;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.report.Report;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class Action {

	List<DBRowTO> listElement;
	static boolean srcCapPerAction = false;

	/**
	 * Assigning Action class listElement with argListElment
	 * 
	 * @param listElement
	 */
	public Action(List<DBRowTO> argListElement) {
		this.listElement = argListElement;

	}

	/**
	 * config Screenshot per action
	 * 
	 * @author Bathriyo
	 */
	public static void configScrCapPerAction() {
		/* reading from cmd line */
		String cmdSrcCapPerAction = System.getProperty("srcCapPerAction");

		if (cmdSrcCapPerAction != null) {
			srcCapPerAction = Boolean.parseBoolean(cmdSrcCapPerAction);
		} else {
			/* reading from property file */
			srcCapPerAction = Boolean.parseBoolean(GlobalVariables.configProp.getProperty("srcCapPerAction"));
		}

	}

	/**
	 * @author Bathriyo
	 */

	private void takeScrCapPerAction() {
		if (srcCapPerAction) {

			if (Reporter.TScenario.get() != null) {
				Reporter.addScreenCapture();
			}

		}
	}

	/**
	 * @author BathriYo performs Click
	 * 
	 * @param element
	 */
	public final void click(WebElement element) {

		String status = "FAIL";
		try {
			new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.elementToBeClickable(element));
			element.click();
			status = "PASS";

			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Click");
			Report.printStatus(status);
		}

	}

	/**
	 * Context Click
	 * 
	 * @param element
	 */
	public final void contextClick(WebElement element) {

		String status = "FAIL";
		try {
			new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.elementToBeClickable(element));
			new Actions(WebDriverManager.getDriver()).contextClick(element).perform();
			status = "PASS";
			takeScrCapPerAction();

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Context Click");
			Report.printStatus(status);
		}

	}

	/**
	 * Double Click
	 * 
	 * @param element
	 */
	public final void doubleClick(WebElement element) {
		String status = "FAIL";
		try {
			new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.elementToBeClickable(element));
			new Actions(WebDriverManager.getDriver()).doubleClick(element).perform();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Double Click");
			Report.printStatus(status);
		}
	}

	/**
	 * Clear
	 * 
	 * @param element
	 */
	public final void clear(WebElement element) {
		String status = "FAIL";
		try {
			new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
					.until(ExpectedConditions.visibilityOf(element));
			element.clear();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Clear");
			Report.printStatus(status);
		}
	}

	/**
	 * SendKeys
	 * 
	 * @param element
	 * @param value
	 */
	public final void sendKeys(WebElement element, String value) {
		String status = "FAIL";
		try {
			element.sendKeys(value);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("sendKeys");
			Report.printValue(value);
			Report.printStatus(status);
		}
	}

	/**
	 * Sendkeys takes key as parameter
	 * 
	 * @author bathriyo
	 * @param element
	 * @param keys
	 */
	public final void sendKeys(WebElement element, Keys keys) {
		String status = "FAIL";
		try {
			element.sendKeys(keys);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("sendKeys");
			Report.printValue(keys.toString());
			Report.printStatus(status);
		}
	}

	public final void sendKeys(Keys keys) {
		String status = "FAIL";
		try {
			Actions actions = new Actions(WebDriverManager.getDriver());
			actions.sendKeys(keys).perform();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("sendKeys");
			Report.printValue(keys.toString());
			Report.printStatus(status);
		}
	}

	/**
	 * Send keys char by char
	 * 
	 * @author Bathriyo
	 * @param element
	 * @param input1
	 */
	public final void sendKeyCharterWise(WebElement element, String input1) {
		String status = "FAIL";
		try {

			char[] charArray = input1.toCharArray();
			for (char c : charArray) {
				element.sendKeys(c + "");
				Thread.sleep(500);
			}

			status = "PASS";

			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("sendKeys");
			Report.printValue(input1);
			Report.printStatus(status);
		}
	}

	/**
	 * Javascript to send character to text field.
	 * 
	 * @author bathriyo
	 * @param element
	 * @param value
	 */
	public final void jsSendkeys(WebElement element, String value) {
		String status = "FAIL";
		try {
			JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
			js.executeScript("arguments[0].setAttribute('value','" + value + "');", element);

			status = "PASS";

			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("js sendKeys");
			Report.printValue(value);
			Report.printStatus(status);

		}
	}

	/**
	 * Sendkeys using system clipboard
	 * 
	 * @author Stephen Raj
	 * @param element
	 * @param value
	 */
	public final void sendkeysClipboard(WebElement element, String value) {
		String status = "FAIL";
		try {

			Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
			StringSelection str = new StringSelection(value);
			clipboard.setContents(str, null);
			element.sendKeys(Keys.CONTROL + "v");

			status = "PASS";

			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("js sendKeys");
			Report.printValue(value);
			Report.printStatus(status);
			;
		}
	}

	/**
	 * Close browser
	 */
	public final void closeBrowser() {

		String status = "FAIL";
		try {
			WebDriverManager.getDriver().close();
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Close Browser");
			Report.printStatus(status);
		}
	}

	/**
	 * Quit Browsers
	 */
	public final void quitBrowser() {
		String status = "FAIL";
		try {
			WebDriverManager.getDriver().quit();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Quit Browser");
			Report.printStatus(status);
		}

	}

	/**
	 * is Alert Present
	 * 
	 * @return boolean
	 */
	public final boolean isAlertPresent() {
		boolean isAlertPresent = false;
		String status = "FAIL";

		try {

			ExpectedCondition<Alert> alertIsPresent = ExpectedConditions.alertIsPresent();

			if (alertIsPresent != null)
				isAlertPresent = true;
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("isAlertPresent");
			Report.printStatus(status);
		}

		return isAlertPresent;

	}

	/**
	 * Switch to alert
	 * 
	 * @author BathriYo
	 * @return Alert
	 */
	public final Alert switchToAlert() {
		Alert alert = null;
		String status = "FAIL";
		try {
			alert = WebDriverManager.getDriver().switchTo().alert();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation(" Switch To Alert");
			Report.printStatus(status);
		}

		return alert;
	}

	/**
	 * Accept Alert
	 * 
	 * @param alert
	 */
	public final void acceptAlert(Alert alert) {
		String status = "FAIL";
		try {
			alert.accept();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Accept Alert");
			Report.printStatus(status);
		}

	}

	/**
	 * Dismiss Alert
	 * 
	 * @param alert
	 */
	public final void dismissAlert(Alert alert) {
		String status = "FAIL";
		try {
			alert.dismiss();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Dismiss Alert");
			Report.printStatus(status);
		}

	}

	/**
	 * Get Alert Text
	 * 
	 * @param alert
	 * @return String
	 */
	public final String getAlertText(Alert alert) {
		String alertText = null;

		String status = "FAIL";
		try {
			alertText = alert.getText();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Getting Alert Text");
			Report.printStatus(status);
		}

		return alertText;
	}

	/**
	 * move to element
	 * 
	 * @param element
	 */
	public final void moveToElement(WebElement element) {
		String status = "FAIL";
		try {

			new Actions(WebDriverManager.getDriver()).moveToElement(element).build().perform();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Javascript Click");
			Report.printStatus(status);
		}
	}

	/**
	 * 
	 * @param source      element
	 * @param destination element
	 */
	public final void dragAndDrop(WebElement sourceEle, WebElement destinationEle) {
		String status = "FAIL";
		try {
			new Actions(WebDriverManager.getDriver()).dragAndDrop(sourceEle, destinationEle).perform();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Drag and Drop");
			Report.printStatus(status);
		}
	}

	/**
	 * 
	 * @param WebElement      element
	 * @param Source value
	 * @param destination value
	 */
	public final void dragAndDrop(WebElement element, int x, int y) {
		String status = "FAIL";
		try {
			new Actions(WebDriverManager.getDriver()).dragAndDropBy(element, x, y).perform();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Drag and Drop");
			Report.printStatus(status);
		}
	}
	/**
	 * Get Element text
	 * 
	 * @param element
	 * @return
	 */
	public final String getText(WebElement element) {
		String text = "undefined";

		String status = "FAIL";
		try {
			text = element.getText();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Text");
			Report.printValue(text);
			Report.printStatus(status);
		}
		return text;
	}

	/**
	 * Get Value
	 * 
	 * @param element
	 * @return String
	 */
	public final String getTextboxValue(WebElement element) {
		String text = "undefined";

		String status = "FAIL";
		try {
			text = element.getAttribute("value");
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Value");
			Report.printValue(text);
			Report.printStatus(status);
		}
		return text;
	}

	/**
	 * Public method to get attribute value of any web element passed
	 * 
	 * @author Bathriyo
	 * @param element
	 * @param attributeName
	 * @return String
	 */
	public final String getAttribute(WebElement element, String attributeName) {
		String value = "undefined";

		String status = "FAIL";
		try {
			value = element.getAttribute(attributeName);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Attribute-" + attributeName);
			Report.printValue(value);
			Report.printStatus(status);
		}
		return value;
	}

	/**
	 * Get Page Title
	 * 
	 * @return String
	 */
	public final String getPagetitle() {
		String title = null;
		String status = "FAIL";
		try {
			title = WebDriverManager.getDriver().getTitle();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Getting Page Title");
			Report.printStatus(status);
		}
		return title;
	}

	/**
	 * Expands shadow root element.
	 * 
	 * @author Het Veera
	 * @param element
	 * @return WebElement
	 */
	public final WebElement expandRootElement(WebElement element) {

		WebElement eExpanded = null;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try {
			eExpanded = (WebElement) js.executeScript("return arguments[0].shadowRoot", element);
			System.out.println(".........................................................................." + element);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Expand Shawdowroot");
			Report.printStatus(status);
		}
		return eExpanded;
	}

	/**
	 * Highlight WebElement
	 * 
	 * @param element
	 */
	public final void highligthElement(WebElement element) {

		String status = "FAIL";
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		try {
			js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');",
					element);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Hightlight Element");
			Report.printStatus(status);
		}
	}

	/**
	 * Is Dispalyed
	 * 
	 * @param element
	 * @return boolean
	 */
	public final boolean isDisplayed(WebElement element) {
		boolean isDisplayed = false;
		String status = "FAIL";
		try {
			isDisplayed = element.isDisplayed();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			// ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Is Displayed");
			Report.printStatus(status);
		}
		return isDisplayed;

	}

	/**
	 * Is Enabled
	 * 
	 * @param element
	 * @return boolean
	 */
	public final boolean isEnabled(WebElement element) {
		boolean isEnabled = false;
		String status = "FAIL";
		try {
			isEnabled = element.isEnabled();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Is Enabled");
			Report.printStatus(status);
		}
		return isEnabled;

	}

	/**
	 * Is Selected
	 * 
	 * @param element
	 * @return boolean
	 */
	public final boolean isSelected(WebElement element) {
		boolean isSelected = false;
		String status = "FAIL";
		try {
			isSelected = element.isSelected();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Is Selected");
			Report.printStatus(status);
		}
		return isSelected;
	}

	/**
	 * isBold: based on tag "b" and "strong"
	 * 
	 * @param element
	 * @return
	 */
	public final boolean isBold(WebElement element) {
		boolean flag = false;

		if (element.getTagName().equals("b") || element.getTagName().equals("strong")) {
			flag = true;
		}
		takeScrCapPerAction();
		return flag;
	}

	/**
	 * isBold: base on font-weight css value
	 * 
	 * @author bathriyo
	 * @param element
	 * @param fontWeight
	 * @return boolean
	 */
	public final boolean isBold(WebElement element, int fontWeight) {
		boolean flag = false;
		String value = element.getCssValue("font-weight");
		if (Integer.parseInt(value) >= fontWeight) {
			flag = true;
		}
		takeScrCapPerAction();
		return flag;
	}

	/**
	 * isUnderline: based on css test-decoration
	 * 
	 * @author bathriyo
	 * @param element
	 * @return boolean
	 */
	public final boolean isUnderline(WebElement element) {
		boolean flag = false;

		if (element.getCssValue("text-decoration").equals("underline")) {
			flag = true;
		}
		takeScrCapPerAction();
		return flag;
	}

	/**
	 * Return's css value of an element
	 * 
	 * @param element
	 * @param cssName
	 * @return
	 */
	public final String getCssValue(WebElement element, String cssName) {
		String value = "";
		String status = "FAIL";
		try {
			value = element.getCssValue(cssName);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Getting CSS value");
			Report.printKey(cssName);
			Report.printValue(value);
			Report.printStatus(status);
		}

		return value;
	}

	/**
	 * Returns browser cookies
	 * 
	 * @author bathriyo
	 * @return Set of Cookies
	 */
	public final Set<Cookie> getCookies() {

		Set<Cookie> cookieSet = null;
		String status = "FAIL";
		try {

			cookieSet = WebDriverManager.getDriver().manage().getCookies();
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Browser Cookies");
			Report.printStatus(status);
		}

		return cookieSet;

	}

	/**
	 * Javascript Click
	 * 
	 * @param element
	 */
	public final void jsClick(WebElement element) {

		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		String status = "FAIL";
		try {
//			new WebDriverWait(WebDriverManager.getDriver(), GlobalVariables.waitTime)
//					.until(ExpectedConditions.elementToBeClickable(element));
			js.executeScript("arguments[0].click();", element);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Javascript Click");
			Report.printStatus(status);
		}

	}

	/**
	 * Open application URL from GlobalVariable class
	 */
	public final void openURL() {
		String status = "FAIL";
		try {
			WebDriverManager.getDriver().get(GlobalVariables.applicationURL);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Open URL");
			Report.printValue(GlobalVariables.applicationURL);
			Report.printStatus(status);
		}
	}

	/**
	 * Open application URL passed as parameter
	 * 
	 * @param url
	 */
	public final void openURL(String url) {
		String status = "FAIL";
		try {
			WebDriverManager.getDriver().get(url);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Open URL");
			Report.printValue(url);
			Report.printStatus(status);
		}
	}

	/**
	 * Get current page url
	 * 
	 * @author BathriYo
	 * @return String
	 */
	public final String getCurrentURL() {
		String currentURL = "undefine";
		String status = "FAIL";
		try {
			currentURL = WebDriverManager.getDriver().getCurrentUrl();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Current URL");
			Report.printStatus(status);
		}

		return currentURL;
	}

	/**
	 * Getting page source
	 * 
	 * @author BathriYo
	 * @return String
	 */
	public final String getPageSource() {
		String pageSource = "undefine";
		String status = "FAIL";
		try {
			pageSource = WebDriverManager.getDriver().getPageSource();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Current URL");
			Report.printStatus(status);
		}

		return pageSource;
	}

	/**
	 * 
	 * @param url
	 */
	public final void openNewTab(String url) {

		String status = "FAIL";
		try {
			((JavascriptExecutor) WebDriverManager.getDriver()).executeScript("window.open('" + url + "', '_blank');");
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Open New Tab");
			Report.printValue(url);
			Report.printStatus(status);
		}

	}

	/**
	 * Scroll To Bottom
	 */
	public final static void scrollToBottom() {
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		String status = "FAIL";
		try {
			js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Scroll To Bottom");
			Report.printStatus(status);
		}
	}

	/**
	 * Scroll To up
	 */
	public final static void scrollToUp() {
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		String status = "FAIL";
		try {
			js.executeScript("window.scrollBy(0,-350)", "");
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Scroll To Bottom");
			Report.printStatus(status);
		}
	}

	/**
	 * Scroll By Pixel
	 * 
	 * @param value
	 */
	public final void scrollByPixel(String value) {
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		String status = "FAIL";
		try {
			js.executeScript("window.scrollBy(0," + value + ")");
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Scroll By Pixel");
			Report.printStatus(status);
		}
	}

	/**
	 * Scroll To Element
	 * 
	 * @param element
	 */
	public final void scrollToElement(WebElement element) {

		String status = "FAIL";
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		try {
			js.executeScript("arguments[0].scrollIntoView();", element);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Scroll TO Element");
			Report.printStatus(status);
		}
	}

	/**
	 * Switch Frame By Name
	 * 
	 * @param name
	 */
	public final void switchFrameByName(String name) {
		String status = "FAIL";

		try {

			WebDriverManager.getDriver().switchTo().frame(name);
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Switch Frame By Name");
			Report.printValue(name);
			Report.printStatus(status);
		}
	}

	/**
	 * Switch Frame By Index
	 * 
	 * @param index
	 */
	public final void switchFrameByIndex(int index) {
		String status = "FAIL";
		try {

			WebDriverManager.getDriver().switchTo().frame(index);
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Switch Frame By Index");
			Report.printValue(index + "");
			Report.printStatus(status);
		}

	}

	/**
	 * Switch Frame by Frame WebElement
	 * 
	 * @param frameElement
	 */
	public final void switchFrameByWebElement(WebElement frameElement) {
		String status = "FAIL";
		try {

			WebDriverManager.getDriver().switchTo().frame(frameElement);
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Switch to Frame By using WebElement");
			Report.printStatus(status);
		}

	}

	/**
	 * Switch to default content
	 */
	public final void switchToDefaultContent() {
		String status = "FAIL";
		try {
			WebDriverManager.getDriver().switchTo().defaultContent();
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Switch to Default Content");
			Report.printStatus(status);
		}

	}

	/**
	 * @author Bathriyo Switch to Parent frame
	 */
	public final void switchToParentFrame() {
		String status = "FAIL";
		try {
			WebDriverManager.getDriver().switchTo().parentFrame();
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Switch to Parent Frame");
			Report.printStatus(status);
		}
	}

	/**
	 * 
	 * @param select
	 * @param value
	 */
	public final void selectByValue(Select select, String value) {
		String status = "FAIL";
		try {
			select.selectByValue(value);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Select by Value");
			Report.printValue(value);
			Report.printStatus(status);
		}
	}

	/**
	 * 
	 * @param select
	 * @param index
	 */
	public final void selectByIndex(Select select, int index) {
		String status = "FAIL";
		try {
			select.selectByIndex(index);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Select by Index");
			Report.printValue(index + "");
			Report.printStatus(status);
		}
	}

	/**
	 * 
	 * @param select
	 * @param visibleText
	 */
	public final void selectByVisibleText(Select select, String visibleText) {
		String status = "FAIL";
		try {
			select.selectByVisibleText(visibleText);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Select by Visible Text");
			Report.printValue(visibleText);
			Report.printStatus(status);
		}
	}

	/**
	 * Deselect all the selected options in a select dropdown
	 * 
	 * @author bathriyo
	 * @param select
	 */
	public final void deselectAllOptions(Select select) {
		String status = "FAIL";
		try {
			select.deselectAll();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Deselect All Options");
			Report.printStatus(status);
		}
	}

	/**
	 * Public utils to get all the options available in drop down
	 * 
	 * @author BathriYo
	 * @param select
	 * @return List<WebElement>
	 */
	public final List<WebElement> getSelectOptions(Select select) {

		String status = "FAIL";
		List<WebElement> options = null;

		try {
			options = select.getOptions();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Select options");
			Report.printStatus(status);
		}
		return options;
	}

	/**
	 * Get all the selected options in a drop down.
	 * 
	 * @author bathriyo
	 * @param select : Select
	 * @return List<WebElement>
	 */
	public final List<WebElement> getAllSelecteOptions(Select select) {
		String status = "FAIL";
		List<WebElement> options = null;

		try {
			options = select.getAllSelectedOptions();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get All Select options");
			Report.printStatus(status);
		}
		return options;
	}

	/**
	 * TakeScreenshot
	 * 
	 * @return String file path
	 */
	public final void TakeScreenshot() {

		String status = "FAIL";
		try {

			CaptureScreenshot.screenCapture();
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("TakeScreenshot");
			Report.printStatus(status);
		}

	}

	/**
	 * Takes screen shot of entire window
	 * 
	 * @author BathriYo
	 * @return String file path
	 */
	public final void captureEntireScreen() {

		String status = "FAIL";
		try {

			CaptureScreenshot.captureEntireScreen();
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("TakeScreenshot");
			Report.printStatus(status);
		}

	}

	/**
	 * Wait for page load
	 */
	public final boolean waitForPageLoad() {
		String status = "FAIL";

		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		boolean isPageLoad = false;

		try {
			while (isPageLoad == false) {
				isPageLoad = js.executeScript("return document.readyState").toString().equals("complete");
				status = "PASS";
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Wait For Page Load");
			Report.printStatus(status);
		}

		return isPageLoad;
	}

	/**
	 * Wait for JS element
	 * 
	 * @author Abhijit
	 * @param dbKey
	 * @return
	 */
	public List<WebElement> waitForJSWebElements(String dbkey) {

		int timeLaps = 0;
		String status = "FAIL";
		List<WebElement> jsElements = null;
		while (status.equals("FAIL") && timeLaps < GlobalVariables.waitTime) {
			try {

				// jsElements = (List<WebElement>) getElementByJavascript(dbkey);
				jsElements = (List<WebElement>) getElements(dbkey);

				if (jsElements.size() == 0) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Exception e) {

				status = "FAIL";

			}

			pause(2000);

			++timeLaps;

		}

		Report.printOperation("wait For JS Element");
		Report.printStatus(status);

		return jsElements;

	}

	public WebElement waitForJSWebElement(String dbkey) {

		int timeLaps = 0;
		String status = "FAIL";
		WebElement jsElement = null;
		while (status.equals("FAIL") && timeLaps < GlobalVariables.waitTime) {
			try {

				// jsElement = (WebElement) getElementByJavascript(dbkey);
				jsElement = (WebElement) getElement(dbkey);

				if (jsElement == null) {
					status = "FAIL";
				} else {
					status = "PASS";
				}

			} catch (Exception e) {

				status = "FAIL";

			}

			pause(2000);

			++timeLaps;

		}

		Report.printOperation("wait For JS Element");
		Report.printStatus(status);

		return jsElement;

	}

	/**
	 * Fluent wait for js element
	 * 
	 * @author bathriyo
	 * @param key
	 * @return
	 */
	@Deprecated
	public final Object fluentWaitForJSWebElement(String key) {

		// String valueType = getValueType(key, listElement);
		String value = getValue(key, listElement);

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(WebDriverManager.getDriver())
				.withTimeout(Duration.ofSeconds(90)).pollingEvery(Duration.ofMillis(500)).ignoring(Exception.class);

		return wait.until(new Function<WebDriver, Object>() {

			@Override
			public Object apply(WebDriver driver) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				return js.executeScript(value);

			}

		});

	}

	/**
	 * Fluent wait for Web Element
	 * 
	 * @author bathriyo
	 * @param key
	 * @return
	 */
	public final WebElement fluentWaitWebElement(String key) {

	FluentWait<WebDriver> wait = new FluentWait<WebDriver>(WebDriverManager.getDriver())
			.withTimeout(Duration.ofSeconds(90)).pollingEvery(Duration.ofMillis(500)).ignoring(Exception.class);

	return wait.until(new Function<WebDriver, WebElement>() {

		@Override
		public WebElement apply(WebDriver driver) {
			WebElement element = null;
			getElement(key);

			String valueType = getValueType(key, listElement);
			String value = getValue(key, listElement);

			Element objEle = new Element(driver);
			element = objEle.getElement(valueType, value);

			if (element == null) {

				throw new NullPointerException();
			} else {
				return element;
			}

		}

	});

}
	/**
	 * 
	 * @param key
	 * @param funtion
	 * @return
	 */
	

	public final WebElement fluentWaitOnFunction(String key, Function<WebDriver, WebElement> funtion) {
		return fluentWaitOnFunction(key, funtion, 90, 500);
	}
	
	public final WebElement fluentWaitOnFunction(String key, Function<WebDriver, WebElement> funtion, int seconds, int intervel) {

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(WebDriverManager.getDriver())
				.withTimeout(Duration.ofSeconds(seconds)).pollingEvery(Duration.ofMillis(intervel)).ignoring(Exception.class);
		return wait.until(funtion);
	}

	/**
	 * Fluent wait for Web Elements
	 * 
	 * @author bathriyo
	 * @param key
	 * @return
	 */
	public final List<WebElement> fluentWaitWebElements(String key) {

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(WebDriverManager.getDriver())
				.withTimeout(Duration.ofSeconds(90)).pollingEvery(Duration.ofMillis(500)).ignoring(Exception.class);

		return wait.until(new Function<WebDriver, List<WebElement>>() {

			@Override
			public List<WebElement> apply(WebDriver driver) {
				Element element = new Element(driver);
				String value = getValue(key, listElement);
				String valueType = getValueType(key, listElement);
				return element.getElements(valueType, value);

			}

		});

	}

	
	
	public final List<WebElement> fluentWaitWebElementsByFormatingXpath(String key, Object... args) {
		return fluentWaitWebElementsByFormatingXpathCustomDuration(key, 90, 500, args);
	}
	
	public final List<WebElement> fluentWaitWebElementsByFormatingXpathCustomDuration(String key,int seconds, int intervel, Object... args) {

		Function<WebDriver, List<WebElement>> funtion = waitFunctionForWebElements(key, args);

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(WebDriverManager.getDriver())
				.withTimeout(Duration.ofSeconds(seconds)).pollingEvery(Duration.ofMillis(intervel)).ignoring(Exception.class);

		return wait.until(funtion);

	}

	private Function<WebDriver, List<WebElement>> waitFunctionForWebElements(String key, Object... args) {
		Function<WebDriver, List<WebElement>> funtion = new Function<WebDriver, List<WebElement>>() {

			@Override
			public List<WebElement> apply(WebDriver driver) {
				Element element = new Element(driver);
				String value = getValue(key, listElement);
				value = String.format(value, args);
				String valueType = getValueType(key, listElement);
				return element.getElements(valueType, value);

			}

		};
		return funtion;
	}

	/**
	 * Hard wait
	 * 
	 * @param milisec : long
	 */
	public static void pause(long milisec) {
		try {

			Thread.sleep(milisec);

		} catch (InterruptedException e1) {

			// do nothing
		}
	}

	/**
	 * Return true if element is present in DOM
	 * 
	 * @param dbkey
	 * @return boolean
	 */
	public final boolean isPresent(String dbkey) {
		boolean isPresent = false;
		String valueType = "undefined";
		String value = "undefined";

		String status = "FAIL";
		try {

			valueType = getValueType(dbkey, listElement);
			value = getValue(dbkey, listElement);
			WebDriverManager.getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			Element element = new Element(WebDriverManager.getDriver());
			element.getElement(valueType, value);
			WebDriverManager.getDriver().manage().timeouts().implicitlyWait(GlobalVariables.waitTime, TimeUnit.SECONDS);
			isPresent = true;
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			/* please do not throw any exception here */
			status = "PASS";
		} finally {
			Report.printOperation("is Present");
			Report.printKey(dbkey);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}

		return isPresent;

	}

	/**
	 * Return true if element is present in DOM
	 * 
	 * @param dbkey
	 * @return boolean
	 */
	public final boolean isPresentJavaScript(String dbkey) {
		boolean isPresent = false;
		String valueType = "undefined";
		String value = "undefined";

		String status = "FAIL";
		try {

			valueType = getValueType(dbkey, listElement);
			value = getValue(dbkey, listElement);
			JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
			js.executeScript(value);
			isPresent = true;
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			/* please do not throw any exception here */
			isPresent = false;
		} finally {
			Report.printOperation("is Present");
			Report.printKey(dbkey);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}

		return isPresent;

	}

	/**
	 * isPresent for dynamic xpath
	 * 
	 * @param locator
	 * @param value
	 * @return boolean
	 */
	public final boolean isPresent(String locator, String value) {
		boolean isPresent = false;

		String status = "FAIL";
		try {
			WebDriverManager.getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			Element objElement = new Element(WebDriverManager.getDriver());
			objElement.getElement(locator, value);
			WebDriverManager.getDriver().manage().timeouts().implicitlyWait(GlobalVariables.waitTime, TimeUnit.SECONDS);

			isPresent = true;
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			Report.printData(e.toString());
			/* please do not throw any exception here */
		} finally {
			Report.printOperation("is Present");
			Report.printValue(value);
			Report.printValueType(locator);
			Report.printStatus(status);
		}

		return isPresent;

	}

	/**
	 * get element or list of web element
	 * 
	 * @param javascript
	 * @return Object
	 */
	public final Object getElementByJavascript(String key) {
		Object obj = null;
		String valueType = getValueType(key, listElement);
		String value = getValue(key, listElement);

		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try {
			Thread.sleep(1000);
			obj = js.executeScript(value);
			status = "PASS";
		} catch (Exception e) {
			// ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("JS Get Element");
			Report.printKey(key);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}

		return obj;

	}

	/**
	 * Get WebElement using driver.findElement()
	 * 
	 * @param key
	 * @param condition
	 * @return WebElement
	 */
	public final WebElement getElement(String key) {
		WebElement webElement = null;
		String valueType = "undefined";
		String value = "undefined";

		String status = "FAIL";
		try {

			valueType = getValueType(key, listElement);
			value = getValue(key, listElement);

			Element element = new Element(WebDriverManager.getDriver());
			webElement = element.getElement(valueType, value);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Element");
			Report.printKey(key);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}

		return webElement;

	}

	/**
	 * Get List of web element using parentElement.findElements();
	 * 
	 * @param key
	 * @return List<WebElement>
	 */
	public final List<WebElement> getElements(String key) {
		List<WebElement> listWebElement = null;
		String value = "undefined";
		String valueType = "undefined";
		String status = "FAIL";
		try {
			Element element = new Element(WebDriverManager.getDriver());
			value = getValue(key, listElement);
			valueType = getValueType(key, listElement);
			listWebElement = element.getElements(valueType, value);
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Elements");
			Report.printKey(key);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}

		return listWebElement;
	}

	/**
	 * Get web element using element.findElement();
	 * 
	 * @param parentElement
	 * @param key
	 * @param condition
	 * @return WebElement
	 */
	public final WebElement getElementFromParentElement(WebElement parentElement, String key) {
		WebElement webElement = null;
		String valueType = "undefined";
		String value = "undefined";

		String status = "FAIL";
		try {
			Element element = new Element(WebDriverManager.getDriver());
			value = getValue(key, listElement);
			valueType = getValueType(key, listElement);
			webElement = element.getElement(parentElement, valueType, value);
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Element");
			Report.printKey(key);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}
		return webElement;

	}

	/**
	 * Get list of element using parent.findElements();
	 * 
	 * @param parentElement
	 * @param key
	 * @return List<WebElment>
	 */
	public final List<WebElement> getElementsFromParentElement(WebElement parentElement, String key) {
		List<WebElement> listWebElement = null;
		String valueType = "undefined";
		String value = "undefined";

		String status = "FAIL";
		try {
			Element element = new Element(WebDriverManager.getDriver());
			value = getValue(key, listElement);
			valueType = getValueType(key, listElement);
			listWebElement = element.getElements(parentElement, valueType, value);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Elements");
			Report.printKey(key);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}
		return listWebElement;

	}

	/**
	 * get Element by directly passing locator and locator value
	 * 
	 * @author BathriYo
	 * @param locator
	 * @param locatorValue
	 * @return WebElement
	 */
	public final WebElement getElement(String locator, String locatorValue) {
		WebElement element = null;

		String status = "FAIL";
		try {
			Element objElement = new Element(WebDriverManager.getDriver());

			element = objElement.getElement(locator, locatorValue);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Elements");
			Report.printValue(locatorValue);
			Report.printValueType(locator);
			Report.printStatus(status);
		}
		return element;
	}

	/**
	 * get list of element by directly passing locator and locator value
	 * 
	 * @author BathriYo
	 * @param locator
	 * @param locatorValue
	 * @return List<WebElement>
	 */
	public final List<WebElement> getElements(String locator, String locatorValue) {
		List<WebElement> lstElement = null;

		String status = "FAIL";
		try {
			Element objElement = new Element(WebDriverManager.getDriver());

			lstElement = objElement.getElements(locator, locatorValue);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Elements");
			Report.printValue(locatorValue);
			Report.printValueType(locator);
			Report.printStatus(status);
		}
		return lstElement;
	}

	/**
	 * Checking broken link
	 * 
	 * @return boolean
	 */
	public final boolean checkBrokenLinks() {
		boolean check = false;
		String status = "FAIL";
		try {
			CheckBrokenLinks checkBrokenLinks = new CheckBrokenLinks();
			check = checkBrokenLinks.checkBrokenLinks(WebDriverManager.getDriver(),
					WebDriverManager.getDriver().getCurrentUrl());
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Checking broken link");
			Report.printStatus(status);
		}
		return check;
	}

	/**
	 * This method execute java script (without parameter) and returns Object type
	 * reference variable.
	 * 
	 * @author BathriYo
	 * @param javaScript
	 * @return Object
	 */
	public final Object executeJavaScript(String javaScript) {

		Object scriptReturn = null;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try {
			scriptReturn = js.executeScript(javaScript);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Execute Javascript");
			Report.printValue(javaScript);
			Report.printStatus(status);
		}

		return scriptReturn;
	}

	/**
	 * This method execute java script (with parameter as WebElement) and returns
	 * Object type reference variable.
	 * 
	 * @author BathriYo
	 * @param javaScript
	 * @param element
	 * @return Object
	 */
	public final Object executeJavaScript(String javaScript, WebElement element) {

		Object scriptReturn = null;
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		String status = "FAIL";
		try {
			scriptReturn = js.executeScript(javaScript, element);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Execute Javascript with Argument");
			Report.printValue(javaScript);
			Report.printStatus(status);
		}

		return scriptReturn;
	}

	/**
	 * This is used to get Value based on the key from list
	 * 
	 * @param dbKey
	 * @param data
	 * @return String
	 */
	public synchronized final static String getValue(String dbKey, List<DBRowTO> data) {
		for (DBRowTO temp : data) {
			if (temp.getKey().equalsIgnoreCase(dbKey)) {
				return temp.getValue();
			}
		}
		return "undefined";
	}

	/**
	 * This is used to get ValueType based on the key from list
	 * 
	 * @param dataKey
	 * @param data
	 * @return String
	 */
	public synchronized final static String getValueType(String dataKey, List<DBRowTO> data) {
		for (DBRowTO temp : data) {
			if (temp.getKey().equalsIgnoreCase(dataKey)) {
				return temp.getValueType();
			}
		}
		return "user defined";
	}

	/**
	 * Public final util to navigate forward
	 * 
	 * @author BathriYo
	 */
	public final void navigateTo(String url) {
		String status = "FAIL";
		try {

			WebDriverManager.getDriver().navigate().to(url);
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Navigate To");
			Report.printValue(url);
			Report.printStatus(status);
		}
	}

	/**
	 * Public final util to navigate forward
	 * 
	 * @author BathriYo
	 */
	public final void navigateForward() {
		String status = "FAIL";
		try {

			WebDriverManager.getDriver().navigate().forward();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Navigate Forward");
			Report.printStatus(status);
		}
	}

	/**
	 * Public final util to navigate backward
	 * 
	 * @author BathriYo
	 */
	public final void navigateBackward() {
		String status = "FAIL";
		try {

			WebDriverManager.getDriver().navigate().back();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Navigate Backward");
			Report.printStatus(status);
		}
	}

	/**
	 * Public final utils to refresh browser
	 * 
	 * @author BathriYo
	 */
	public final void refresh() {
		String status = "FAIL";
		try {

			WebDriverManager.getDriver().navigate().refresh();
			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Refresh");
			Report.printStatus(status);
		}
	}

	/**
	 * Copy string to clipboard
	 * 
	 * @author BathriYo
	 * @param str
	 */
	public final void copyStringToClipboard(String str) {
		String status = "FAIL";
		try {

			StringSelection stringSelection = new StringSelection(str);

			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Copy To Clipboard");
			Report.printStatus(status);
		}
	}

	/**
	 * Get window handles
	 * 
	 * @author BathriYo
	 * @return Set<String>
	 */
	public final Set<String> getWindowsHandles() {

		Set<String> handles = null;

		String status = "FAIL";
		try {

			handles = WebDriverManager.getDriver().getWindowHandles();
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Windows Hanbles");
			Report.printStatus(status);
		}

		return handles;
	}

	/**
	 * 
	 * @param windowHandles
	 * @param nthWindow
	 * @return String
	 */
	public final String getWindowHandle(Set<String> windowHandles, int nthWindow) {
		String windowHandle = "undefine";
		String status = "FAIL";

		Iterator<String> iterator = windowHandles.iterator();

		try {

			int i = 1;
			while (iterator.hasNext()) {
				if (i == nthWindow) {
					windowHandle = iterator.next();
					break;
				} else {
					iterator.next();
				}
				i += 1;
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get nthWindow Hanble");
			Report.printStatus(status);
		}

		return windowHandle;
	}

	/**
	 * Switch to window
	 * 
	 * @author BathriYo
	 * @param windowHandle
	 */
	public final void switchToWindow(String windowHandle) {

		String status = "FAIL";

		try {

			// WebDriverManager.setDriver(WebDriverManager.getDriver().switchTo().window(windowHandle));
			WebDriverManager.getDriver().switchTo().window(windowHandle);

			status = "PASS";
			takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Switch To Window");
			Report.printStatus(status);
		}

	}

	/**
	 * Public final utils to get browser local stroage key value pair.
	 * 
	 * @author BathriYo
	 * @return Map<String, String>
	 */
	public final Map<String, String> getBrowserLocalStorage() {

		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();

		long totalKeys = (long) js.executeScript("return window.localStorage.length");

		String key;
		String status = "FAIL";

		Map<String, String> mapKeyValue = new HashMap<String, String>();

		try {

			for (long index = 0; index < totalKeys; index++) {

				key = (String) js.executeScript("return window.localStorage.key(" + index + ")");

				mapKeyValue.put(key, (String) js.executeScript("return window.localStorage.getItem('" + key + "')"));
			}
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Browser Local Storage");
			Report.printStatus(status);
		}

		return mapKeyValue;
	}

	/**
	 * Clears chrome browser lcoal storage caches.
	 */
	public final void clearCacheLocalStorage() {
		JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
		String status = "FAIL";

		try {
			js.executeScript("window.localStorage.clear()");
			status = "PASS";
		} catch (

		Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Clear Cache Chrome Local Storage");
			Report.printStatus(status);
		}
	}

	public final synchronized static String getTestData(String dbKey) {
		return getValue(dbKey, SQLDriver.TTestData.get());
	}

	/**
	 * This method will save/download file in IE
	 */
	public final void downloadFileInIE() {

		String status = "FAIL";
		try {
			Robot robot = new Robot();
			robot.setAutoDelay(250);
			robot.keyPress(KeyEvent.VK_ALT);
			Thread.sleep(1000);
			robot.keyPress(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_ALT);
			robot.keyRelease(KeyEvent.VK_S);
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Download File in IE");
			Report.printStatus(status);
		}

	}

	/**
	 * This method will close the window using robot class
	 */
	public final void closeWindow() {
		String status = "FAIL";
		try {
			Robot robot = new Robot();
			robot.setAutoDelay(250);
			robot.keyPress(KeyEvent.VK_ALT);
			Thread.sleep(1000);
			robot.keyPress(KeyEvent.VK_F4);
			robot.keyRelease(KeyEvent.VK_ALT);
			robot.keyRelease(KeyEvent.VK_F4);
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("pop up window verification");
			Report.printStatus(status);
		}
	}

	public static void waitForDomToComplete(WebDriver driver) {
		@SuppressWarnings("deprecation")
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(700, TimeUnit.MILLISECONDS).withMessage("Time out is reached. Page is not loaded!");

		wait.until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				JavascriptExecutor js = (JavascriptExecutor) driver;
				String domLoadStatus = (String) js.executeScript("return document.readyState");
				if (domLoadStatus.equals("complete")) {
					return true;
				} else {
					return false;
				}
			}
		});
	}

	/**
	 * Gets the web element by formating the xpath from DB xpath should have
	 * standard string formating eg: "//a[@class='ng-binding' and text()='%s']",
	 * "Test" will be formatted to "//a[@class='ng-binding' and text()='Test']"
	 * 
	 * @param key:  DB Key from which xpath is retrived
	 * @param args: values that needs to be replaced in the xpath
	 * @return
	 */
	public final WebElement getElementByFormatingXpath(WebDriver driver, String key, Object... args) {
		WebElement webElement = null;
		String valueType = "undefined";
		String value = "undefined";

		String status = "FAIL";
		try {

			valueType = getValueType(key, listElement);
			value = getValue(key, listElement);
			value = String.format(value, args);

			Element element = new Element(driver);
			webElement = element.getElement(valueType, value);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Element");
			Report.printKey(key);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}

		return webElement;

	}
	
	public final WebElement getElementByFormatingXpath(String key, Object... args) {
		return getElementByFormatingXpath(WebDriverManager.getDriver(), key, args);
	}
	
	
	public final WebElement fluentWaitWebElementByFormatingXpath(String key, Object... args) {
		Function<WebDriver, WebElement> waitFunction = getFluentWaitFormattingXpathFunction(key, args);
		return fluentWaitOnFunction(key, waitFunction);
	}
	
	public final WebElement fluentWaitWebElementByFormatingXpathCustomDuration(String key, int seconds, int intervel,  Object... args) {
		Function<WebDriver, WebElement> waitFunction = getFluentWaitFormattingXpathFunction(key, args);
		return fluentWaitOnFunction(key, waitFunction, seconds, intervel);
	}
	

	private Function<WebDriver, WebElement> getFluentWaitFormattingXpathFunction(String key, Object... args) {
		return new Function<WebDriver, WebElement>() {

			@Override
			public WebElement apply(WebDriver driver) {
				WebElement element = getElementByFormatingXpath(driver, key, args);

				if (element == null) {
					throw new NullPointerException();
				} else {
					return element;
				}

			}

		};
	}

	public String getCurrentWindowHandle() {
		return WebDriverManager.getDriver().getWindowHandle();
	}

	public final void deleteallcookies() {
		WebDriverManager.getDriver().manage().deleteAllCookies();
	}

	public final void focus(WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) WebDriverManager.getDriver();
        js.executeScript("arrgument[0].focus(", element);
    }

	public final WebElement fluentWaitWebElement(String key,int seconds,int interval) {

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(WebDriverManager.getDriver())
				.withTimeout(Duration.ofSeconds(seconds)).pollingEvery(Duration.ofMillis(interval)).ignoring(Exception.class);

		return wait.until(new Function<WebDriver, WebElement>() {

			@Override
			public WebElement apply(WebDriver driver) {
				WebElement element = null;
				getElement(key);

				String valueType = getValueType(key, listElement);
				String value = getValue(key, listElement);

				Element objEle = new Element(driver);
				element = objEle.getElement(valueType, value);

				if (element == null) {

					throw new NullPointerException();
				} else {
					return element;
				}

			}

		});

	}
}

