package qa.framework.utils;

import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.Assert;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.config.DecoderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CommonAPISteps {

	public static Response response;
	public static RequestSpecification request;

	public static String requestJson;

	private static int fileCounter = 0;

	/**
	 * This method will put the response body in a file
	 * 
	 * @author bathriyo
	 * @param response : Response
	 * @return fileName
	 */
	public String responseFile(String response) {

		PropertyFileUtils property = new PropertyFileUtils("./src/test/resources/extent.properties");
		String reportDirPath = property.getProperty("extent.reporter.spark.out");

		String fileName = "file-" + (++fileCounter) + ".json";
		String filePath = reportDirPath + "/" + fileName;

		FileManager.getFileManagerObj().createFile(filePath);

		FileManager.getFileManagerObj().write(filePath, response);

		return fileName;
	}

	/**
	 * This method will put the request body in a file
	 * 
	 * @author bathriyo
	 * @param request : String
	 * @return filePath
	 */
	public String requestFile(String request) {

		PropertyFileUtils property = new PropertyFileUtils("./src/test/resources/extent.properties");
		String reportDirPath = property.getProperty("extent.reporter.spark.out");

		String fileName = "file-" + (++fileCounter) + ".json";
		String filePath = reportDirPath + "/" + fileName;

		FileManager.getFileManagerObj().createFile(filePath);

		FileManager.getFileManagerObj().write(filePath, request);

		return fileName;
	}

	public String putJsonInFile(String json, String fileName) {

		PropertyFileUtils property = new PropertyFileUtils("./src/test/resources/extent.properties");
		String reportDirPath = property.getProperty("extent.reporter.spark.out");

		String uniqueFileName = fileName + "-" + (++fileCounter) + ".json";
		String filePath = reportDirPath + "/" + uniqueFileName;

		FileManager.getFileManagerObj().createFile(filePath);

		FileManager.getFileManagerObj().write(filePath, json);

		return uniqueFileName;
	}

	public void addFileToReport(String message, String fileName) {

		String html = "<lable><font color=#1E90FF>" + message + "</font></lable>" + "<a href=\"" + fileName
				+ "\" target=\"_blank\" style=\"float:right\"><img src=\"core-image-hyper-link.png\" style=\"background-color:aliceblue\"></a>";

		Reporter.addStepLog(html);
	}

	@Given("^base uri is set for \"([^\"]*)\" endpoint$")
	public void base_uri_is_set_for_something_endpoint(String baseUriDBKey) throws Throwable {

		RestAssured.reset();
		String baseUri = Action.getTestData(baseUriDBKey).trim();
		RestApiUtils.setBaseURI(baseUri);

		Reporter.addStepLog("<strong>Base URI is set as: </strong>" + baseUri);
	}

	@And("^user set \"([^\"]*)\" for \"([^\"]*)\" endpoint$")
	public void user_set_something_for_something(String basePathDBKey, String endPointName) throws Throwable {

		String basePath = Action.getTestData(basePathDBKey).trim();
		RestApiUtils.setBasePath(basePath);
		RestApiUtils.requestSpecification = RestAssured.given();
		request = RestApiUtils.requestSpecification;

		Reporter.addStepLog("<strong>Base path is set as: </strong>" + basePath);
	}

	@And("^user execute \"([^\"]*)\" request \"([^\"]*)\" json$")
	public void user_execute_something_request_something_json(String methodType, String jsonCondition) {

		methodType = methodType.trim().toLowerCase();
		jsonCondition = jsonCondition.trim().toLowerCase();

		if (jsonCondition.equals("without")) {
			// no code required
		} else if (jsonCondition.equals("with")) {

			RestApiUtils.requestSpecification.contentType("application/json");
			RestApiUtils.requestSpecification.body(requestJson);

			Reporter.addStepLog("Content Type is set as: " + "application/json");

			// Reporter.addStepLog("<strong>Request JSON: </strong></br>" + requestJson);
			String requestJsonFileName = requestFile(requestJson);
			String html = "<lable><font color=#1E90FF>Click on link to see Request</font></lable>" + "<a href=\""
					+ requestJsonFileName
					+ "\" target=\"_blank\" style=\"float:right\"><img src=\"core-image-hyper-link.png\" style=\"background-color:aliceblue\"></a>";

			Reporter.addStepLog(html);

		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>!!! INCORRET JSON CONDITION PROVIDED !!! </font></strong>"
					+ jsonCondition);
			Assert.fail("!!! INCORRET JSON CONDITION PROVIDED !!! " + jsonCondition);
		}

		switch (methodType) {
		case "post": {
			response = RestApiUtils.requestSpecification.post();

			break;
		}
		case "put": {
			response = RestApiUtils.requestSpecification.put();
			break;
		}
		case "get": {
			response = RestApiUtils.requestSpecification.get();
			break;
		}
		case "delete": {
			response = RestApiUtils.requestSpecification.delete();
			break;
		}
		case "patch":
			response = RestApiUtils.requestSpecification.patch();
			break;

		default: {
			Reporter.addStepLog(
					"<strong><font color=#DC143C>!!! INCORRET HTTP METHOD TYPE PROVIDED !!! </font></strong>"
							+ methodType.toUpperCase());
			Assert.fail("!!! INCORRET HTTP METHOD TYPE PROVIDED !!! " + methodType.toUpperCase());
		}

		}

		Reporter.addStepLog("<strong>HTTP Method Executed: </strong>" + methodType.toUpperCase());

		String responseBody = response.body().asString();
		if (responseBody.length() > 0) {

			String fileName = responseFile(responseBody);

			String html = "<lable><font color=#1E90FF>Click on link to see Response</font></lable>" + "<a href=\""
					+ fileName
					+ "\" target=\"_blank\" style=\"float:right\"><img src=\"core-image-hyper-link.png\" style=\"background-color:aliceblue\"></a>";

			Reporter.addStepLog(html);

		}

		long responseTime = response.getTimeIn(TimeUnit.SECONDS);
		if (responseTime > -1) {
			Reporter.addStepLog("<strong>Response Time: </strong>" + responseTime + "<strong> Sec.</strong>");
		}

	}

	@And("^user set header (.+) as (.+) for current endpoint$")
	public void user_set_header_something_as_something_for_current_endpoint(String headerName, String headerValue) {

		headerName = headerName.replace("\"", "");
		headerValue = headerValue.replace("\"", "");
		;

		RestApiUtils.requestSpecification.header(headerName, headerValue);

		Reporter.addStepLog("<strong>Header Name: </strong>" + headerName);
		Reporter.addStepLog("<strong>Header Value: </strong>" + headerValue);
	}

	@And("^user set \"([^\"]*)\" parameter (.+) as (.+) for current endpoint$")
	public void user_set_something_parameter_something_as_something_for_current_endpoint(String parameterType,
			String parameterName, String parameterValue) {

		parameterName = parameterName.replace("\"", "");
		parameterValue = parameterValue.replace("\"", "");

		parameterType = parameterType.trim().toLowerCase();

		switch (parameterType) {
		case "path": {

			RestApiUtils.requestSpecification.pathParam(parameterName, parameterValue);

			break;
		}
		case "query": {
			RestApiUtils.requestSpecification.queryParam(parameterName, parameterValue);
			break;
		}
		case "form": {
			RestApiUtils.requestSpecification.formParam(parameterName, parameterValue);
			break;
		}

		default: {
			Reporter.addStepLog("<strong><font color=#DC143C>!!! INCORRET PARAMETER TYPE PROVIDED !!! </font></strong>"
					+ parameterType.toUpperCase());
			Assert.fail("!!! INCORRET PARAMETER TYPE PROVIDED !!! " + parameterType.toUpperCase());
		}

		}

		Reporter.addStepLog("<strong>Parameter Type: </strong>" + parameterType);
		Reporter.addStepLog("<strong>Parameter Name: </strong>" + parameterName);
		Reporter.addStepLog("<strong>Parameter Value: </strong>" + parameterValue);

	}

	@Then("^user verifies the response status code as \"([^\"]*)\"$")
	public void user_verifies_the_response_status_code_as_something(String expResStatusCode) throws Throwable {

		int actResStatusCode = response.getStatusCode();

		// Reporter.addStepLog("<strong>Expected Response Status Code: </strong>" +
		// expResStatusCode);
		// Reporter.addStepLog("<strong>Actual Response Status Code: </strong>" +
		// actResStatusCode);

		// RestApiHelperMethods.verifyEquals(Integer.parseInt(expResStatusCode),
		// actResStatusCode);

		if (expResStatusCode.contains(String.valueOf(actResStatusCode))) {
			Reporter.addStepLog("Status verification passed !!");
			Reporter.addStepLog("<strong>Expected Status Code: </strong>" + expResStatusCode);
			Reporter.addStepLog("<strong>Actual Status Code: </strong>" + actResStatusCode);
		} else {

			Reporter.addStepLog("Status verification failed !!");
			Reporter.addStepLog("<strong>Expected Status Code: </strong>" + expResStatusCode);
			Reporter.addStepLog("<strong>Actual Status Code: </strong>" + actResStatusCode);

			Assert.fail("Status mismatch");
		}

	}

	@And("^user set relaxed HTTPS for current endpoint$")
	public void user_set_relaxed_https_for_current_endpoint() {
		RestApiUtils.requestSpecification.relaxedHTTPSValidation();
	}

	@And("^user reset rest assured parameters$")
	public void user_reset_rest_assured_parameters() {
		RestApiUtils.reset();

	}

	@And("^user form a request json using template \"([^\"]*)\" with test data from excel \"([^\"]*)\" and sheet \"([^\"]*)\" for scenario (.+)$")
	public void user_form_a_request_json_using_template_something_with_test_data_from_excel_something_and_sheet_something_for_scenario(
			String jsonFileName, String excelFileName, String sheetName, String scenario) {

		String userDir = System.getProperty("user.dir");

		String jsonFilePath = FileManager.getFileManagerObj().searchFile(userDir, jsonFileName);
		String excelFilePath = FileManager.getFileManagerObj().searchFile(userDir, excelFileName);

		ExcelUtils objExcel = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = objExcel.getSheet(sheetName);

		/* getting row index */
		int scenarioColumnIndex = objExcel.getCellIndexByCellValue(sheet, 0, "Scenario");
		int rowIndex = objExcel.getRowIndexByCellValue(sheet, scenarioColumnIndex, scenario);

		objExcel.closeWorkBook();

		if (rowIndex > 0) {

			CommonAPISteps.requestJson = RestApiHelperMethods.putExcelRowDataToJSONReturnsString(jsonFilePath,
					excelFilePath, sheetName, rowIndex);

		} else {

			Assert.fail("!!! Row not found !!!");

		}

	}

	@And("^user add request json \"([^\"]*)\" to request body$")

	public void user_add_request_json_something_to_request_body(String requestJonFileName) {
		String userDir = System.getProperty("user.dir");
		String filepath = FileManager.getFileManagerObj().searchFile(userDir, requestJonFileName);

		CommonAPISteps.requestJson = FileManager.getFileManagerObj().readFile(filepath);

	}

	@And("^user set proxy details \"([^\"]*)\" host name and \"([^\"]*)\" port$")
	public void user_set_proxy_details_something_host_name_and_something_port(String hostname, String port) {
		RestApiUtils.requestSpecification.proxy(hostname, Integer.parseInt(port));

	}

	@And("^user set decoder configuration for rest assured$")
	public void user_set_decorder_configuraiton_for_rest_assured() throws Throwable {
		// this is to remove Accept-encoding default header
		// https://stackoverflow.com/questions/12823536/how-do-i-get-rest-assured-to-return-the-text-non-encrypted-or-streamed-value-i

		RestAssuredConfig decoderConfig = RestAssured.config()
				.decoderConfig(DecoderConfig.decoderConfig().noContentDecoders());

		RestApiUtils.requestSpecification.config(decoderConfig);

	}

}
