package qa.framework.utils;

import static net.javacrumbs.jsonunit.JsonAssert.assertJsonEquals;
import static org.testng.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import io.restassured.path.json.config.JsonPathConfig;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

public class RestApiHelperMethods {

	static Logger log = LoggerHelper.getLogger(RestApiHelperMethods.class);
	private static int i;
	private static String parentNode = "";

	public static void verifyTrue(boolean flag) {
		Assert.assertTrue(flag);
	}

	public static void verifyFalse(boolean flag) {
		Assert.assertFalse(flag);
	}

	public static int getStatuscode(Response response) {
		int statusCode = response.getStatusCode();
		return statusCode;
	}

	public static void verfiyStatusCode(Response response, long status) {
		log.debug("Verifying status code " + status);
		Assert.assertEquals("Status code verification failed. Received Status code: " + getStatuscode(response), status,
				getStatuscode(response));
	}

	public static String getStatusMessage(Response response) {
		String statusMessage = response.getStatusLine();
		return statusMessage;
	}

	public static void verfiyStatusMessage(Response response, Object status) {
		log.debug("Verifying status message " + response);
		Assert.assertEquals(
				"Status message verification failed. Received Status message: " + getStatusMessage(response), status,
				getStatusMessage(response));
	}

	public static void verifyEquals(Object expectedValue, Object actualValue) {
		log.debug("Expected Value: " + expectedValue + "and Actual Value: " + actualValue);
		
		Reporter.addStepLog("<strong>Expected Value: </strong>" + expectedValue + "</br>" + "<strong>Actual Value: </strong>" + actualValue);
		
		assertEquals(actualValue, expectedValue, "Actual and Expected values are NOT equal");
		

	}

	public static void verifyNotNull(Object obj) {
		log.debug("Verifying not null." + obj);
		Assert.assertNotNull("Provided object is NULL: " + obj, obj);
	}

	public static JSONObject writeOrReturnUpdatedJson(String jsonFilePath, String oldKeyValueWithDoubleCoat,
			String newKeyValueWithDoubleCoat, boolean writeToExistingJsonFile)
			throws ParseException, FileNotFoundException, IOException {

		JSONParser parser = new JSONParser();
		Object object = parser.parse(new FileReader(jsonFilePath));

		// Converting the Object to JSONObject
		JSONObject jsonObject = (JSONObject) object;

		String str = jsonObject.toJSONString().replace(oldKeyValueWithDoubleCoat, newKeyValueWithDoubleCoat);
		JSONObject json = (JSONObject) parser.parse(str);

		// Write into existing json file based on the boolean value
		if (writeToExistingJsonFile == true) {
			File fnew = new File(jsonFilePath);
			try {
				FileWriter f2 = new FileWriter(fnew, false);
				f2.write(json.toJSONString());
				f2.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return null;
		} else {
			return json;
		}
	}

	/**
	 * @author ChandregowdaDi
	 * @param response
	 * @param completeKeyPath  (Complete json path if it is nested, with comma(,)
	 *                         separated)
	 * @param index
	 * @param expectedValueKey
	 * @return String value
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ParseException
	 */
	public static String getExpectedValueFromResponseJson(Response response, String completeKeyPath, int index,
			String expectedValueKey) throws FileNotFoundException, IOException, ParseException {

		String[] completeKeyPathArr = completeKeyPath.split(",");

		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(response.getBody().asString());
		JSONObject tempJsonObject = null;
		JSONArray jsonArray = null;
		String expectedValue = null;

		for (int i = 0; i < completeKeyPathArr.length; i++) {
			if (i != completeKeyPathArr.length - 1) {
				tempJsonObject = (JSONObject) jsonObject.get(completeKeyPathArr[i]);
			} else {
				jsonArray = (JSONArray) tempJsonObject.get(completeKeyPathArr[i]);
				tempJsonObject = (JSONObject) jsonArray.get(index);
				expectedValue = (String) tempJsonObject.get(expectedValueKey);
			}
		}
		return expectedValue;

	}

	/**
	 * This method takes the header of the given excel file and create the map with
	 * the value from row index (valueRowIndex)
	 * 
	 * @author BathriYo
	 * @param excelFilePath
	 * @param sheet
	 * @param valueRowIndex
	 * @return HashMap<String,String>
	 */
	public static HashMap<String, Object> creatMapFromExcelHeaders(String excelFilePath, String sheet,
			int valueRowIndex) {

		HashMap<String, Object> map = null;
		ExcelUtils objExcelUtils = new ExcelUtils(ExcelOperation.LOAD,excelFilePath);

		try {
			//ExcelUtil.setExcelFile(excelFilePath, sheet);
			
			XSSFSheet objSheet = objExcelUtils.getSheet(sheet);

			//int cellCount = ExcelUtil.getCellCount(0);
			int cellCount = objExcelUtils.getCellCount(objSheet,0);

			map = new HashMap<String, Object>();

			/* putting headers in Map with blank value */
			for (int index = 0; index < cellCount; index++) {
				//String header = ExcelUtil.getStringCellData(0, index).trim();
				String header = objExcelUtils.getStringCellData(objSheet,0, index).trim();

				/* adding header only if length is greater than 0 */
				if (header.length() > 0) {

					header = "$" + header;

					//Object value = ExcelUtil.getCellData(valueRowIndex, index);
					Object value = objExcelUtils.getCellData(objSheet,valueRowIndex, index);
					
					map.put(header, value);

				}

			}

		} catch (Exception e) {
			// ExceptionHandler.handleExcpetion(e);
			e.printStackTrace();
		} finally {

			//ExcelUtil.closeWorkBook();
			objExcelUtils.closeWorkBook();

		}

		return map;

	}

	/**
	 * This method takes json file path and returns json in string format.
	 * 
	 * @author BathriYo
	 * @param jsonFilePath
	 * @return String
	 */
	public static String convertJsonToString(String jsonFilePath) {

		String strJson = "undefined";

		try {

			// JSONParser parser = new JSONParser();
			// JSONObject jsonObj = (JSONObject) parser.parse(new FileReader(jsonFilePath));

			// strJson = strJson.replace("undefined", jsonObj.toJSONString());

			BufferedReader bufferedReader = new BufferedReader(new FileReader(jsonFilePath));

			StringBuffer stringBuffer = new StringBuffer();

			String line = null;

			while ((line = bufferedReader.readLine()) != null) {

				// stringBuffer.append(line).append("\n");
				stringBuffer.append(line).append("\n");
			}

			strJson = strJson.replace("undefined", stringBuffer);

			bufferedReader.close();

		} catch (Exception e) {
			// ExceptionHandler.handleExcpetion(e);
			e.printStackTrace();
		}

		return strJson;

	}

	/**
	 * This method create json based on map provided
	 * 
	 * @author BathriYo
	 * @param jsonFilePath
	 * @param map
	 * @return Object
	 * @throws ParseException
	 */
	public static Object createJson(String jsonFilePath, Map<String, Object> map) {

		/* converting json into string */
		String strJson = convertJsonToString(jsonFilePath);

		Set<String> keySet = map.keySet();

		Iterator<String> iterate = keySet.iterator();

		/* creating json with excel value */
		while (iterate.hasNext()) {

			String key = iterate.next();
			Object value = map.get(key);

			if (value instanceof Double || value instanceof Long || value instanceof Integer) {

				/* logic to remove trailing zeros 123.0 t => 123, 123.90 =>123.9 */
				if ((double) value == (long) (double) value)
					value = String.format("%d", (long) (double) value);
				else
					value = String.format("%s", value);

				strJson = strJson.replace("\"" + key + "\"", value + "");

			} else if (key.contains("$int_")) {

				strJson = strJson.replace("\"" + key + "\"", value + "");

			} else {
				strJson = strJson.replace(key, value + "");
			}

		}

		/* converting string null into null null in json string */
		strJson = strJson.replace("\"null\"", "null");

		/* converting string true into boolean true in json string */
		strJson = strJson.replace("\"true\"", "true");

		/* converting string false into boolean false json string */
		strJson = strJson.replace("\"false\"", "false");

		Object jsonObj = null;
		try {

			JSONParser parser = new JSONParser();
			jsonObj = parser.parse(strJson);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return jsonObj;

	}

	/**
	 * Public static method to create a json with values provided in Map.
	 * 
	 * NOTE: It is found that JSONParser while parsing json string changes the order
	 * of nodes which is causing script to fail thus below method is introduce which
	 * returns string as it is(no change of order).
	 * 
	 * @author BathriYo
	 * @param jsonFilePath
	 * @param map
	 * @return String
	 */
	public static String createJsonReturnsString(String jsonFilePath, Map<String, Object> map) {

		/* converting json into string */
		System.out.println("checking");
		String strJson = convertJsonToString(jsonFilePath);

		Set<String> keySet = map.keySet();

		Iterator<String> iterate = keySet.iterator();

		/* creating json with excel value */
		while (iterate.hasNext()) {

			String key = iterate.next();
			Object value = map.get(key);

			if (value instanceof Double || value instanceof Long || value instanceof Integer) {

				/* logic to remove trailing zeros 123.0 t => 123, 123.90 =>123.9 */
				/*if ((double) value == (long) (double) value)
					value = String.format("%d", (long) (double) value);
				else
					value = String.format("%s", value);*/

				strJson = strJson.replace("\"" + key + "\"", (value) + "");

			} else if (key.contains("$int_")) {

				strJson = strJson.replace("\"" + key + "\"", value + "");

			} else {
				strJson = strJson.replace(key, value + "");
			}

		}

		/* converting string null into null null in json string */
		strJson = strJson.replace("\"null\"", "null");

		/* converting string true into boolean true in json string */
		strJson = strJson.replace("\"true\"", "true");

		/* converting string false into boolean false json string */
		strJson = strJson.replace("\"false\"", "false");

		// System.out.println("JSON String"+strJson);

		return strJson;
	}

	/**
	 * Provided single method to put excel row data into given json file.
	 * 
	 * @author BathriYo
	 * @param jsonFilePath
	 * @param excelFilePath
	 * @param excelSheet
	 * @param excelRow
	 * @return Object
	 */
	public static Object putExcelRowDataToJSON(String jsonFilePath, String excelFilePath, String excelSheet,
			int excelRow) {

		return createJson(jsonFilePath, creatMapFromExcelHeaders(excelFilePath, excelSheet, excelRow));
	}

	/**
	 * Provided single method to put excel row data into given json file.
	 * 
	 * @author BathriYo
	 * @param jsonFilePath
	 * @param excelFilePath
	 * @param excelSheet
	 * @param excelRow
	 * @return String
	 */
	public static String putExcelRowDataToJSONReturnsString(String jsonFilePath, String excelFilePath,
			String excelSheet, int excelRow) {

		return createJsonReturnsString(jsonFilePath, creatMapFromExcelHeaders(excelFilePath, excelSheet, excelRow));
	}

	/**
	 * @author NayakAr readJsonfile method will read whole json file as string
	 *         assertJSON method will compare expected json to actual response
	 **/
	public static String readJsonfile(String value) throws FileNotFoundException {
		String currentLine;
		String jsonFile = "";

		try (BufferedReader br = new BufferedReader(new FileReader(value))) {
			while ((currentLine = br.readLine()) != null) {
				jsonFile += currentLine;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return jsonFile;
	}

	public static void assertJSON(Response response, String jsonFile) {

		ValidatableResponse res = response.then();
		res.log();
		// res.statusCode(status);

		try {

			assertJsonEquals(RestApiHelperMethods.readJsonfile(jsonFile), response.asString());
		} catch (Exception e) {
			System.out.println(jsonFile + " is not found  ");
			Assert.fail(e.getMessage());

		}
	}

	/**
	 * Use to generate json array with excel data.
	 * 
	 * @author Bathriyo
	 * @param jsonFilePath
	 * @param excelFilePath
	 * @param sheetName
	 * @param scenario
	 * @param columnName
	 * @return String: json array
	 */
	public static String generateJsonArray(String jsonFilePath, String excelFilePath, String sheetName, String scenario,
			String columnName) {

		int rowIndex = 1;
		String finalJsonArray = "";

		List<Object> listScenarios;

		//ExcelUtil.setExcelFile(excelFilePath, sheetName);
		ExcelUtils objExcelUtils = new ExcelUtils(ExcelOperation.LOAD, excelFilePath);
		XSSFSheet sheet = objExcelUtils.getSheet(sheetName);

		//listScenarios = ExcelUtil.getCellData(columnName);
		listScenarios = objExcelUtils.getColumnData(sheet, 0, columnName);

		for (Object value : listScenarios) {
			
			String svalue = (String)value;			
			
			if (svalue.trim().equalsIgnoreCase(scenario)) {

				String jsonArray = putExcelRowDataToJSONReturnsString(jsonFilePath, excelFilePath, sheetName, rowIndex);
				finalJsonArray = finalJsonArray + jsonArray + ",";
			}
			rowIndex += 1;
		}

		//ExcelUtil.closeWorkBook();
		objExcelUtils.closeWorkBook();

		/* removing extra , from last */
		finalJsonArray = finalJsonArray.substring(0, finalJsonArray.length() - 1);

		return finalJsonArray;
	}

	/**
	 * to verify the input json values with the response json values
	 * 
	 * @author SettyS
	 * @param response
	 * @param inputJsonValuesAsMap
	 * @throws Exception
	 * @throws Exception
	 */
	public static void verifyResponseWithInputJsonValues(Response response, Map<String, Object> inputJsonValuesAsMap)
			throws Exception {

		Set<String> keySet = inputJsonValuesAsMap.keySet();

		Iterator<String> iterater = keySet.iterator();

		while (iterater.hasNext()) {
			String key = iterater.next();
			Object inputValue = inputJsonValuesAsMap.get(key);
			key = key.replace("$", "");
			Object responseValue = response.jsonPath().get(key);

			if (!(key.contains("testScenario") || key.contains("journalCategory") || key.contains("status"))) {
				if (inputValue.equals("null")) {
					Assert.assertTrue((responseValue == null));
				} else {

					if ((key.contains("Date")) && !(key.equals("originalTransactionDate"))
							&& !(key.equals("recordDate"))) {
						DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
						Date result1 = df1.parse(String.valueOf(inputValue));
						inputValue = result1;
						Date result2 = df1.parse(String.valueOf(responseValue));
						responseValue = result2;
					}
					if (key.equals("amount") || key.equals("numberOfShares") || key.equals("withholdingAmount")
							|| key.equals("nraDropThroughAmount") || key.equals("stateWithholdingAmount")
							|| key.equals("fatcaCreditAmount") || key.equals("nraDropThroughRate")
							|| key.equals("itemCost") || key.equals("fatcaWithholdingAmount")
							|| key.equals("stateWithholdingRate") || key.equals("fatcaWithholdingRate")
							|| key.equals("yearlyOidRate") || key.equals("strikePrice")) {
						responseValue = response.body()
								.jsonPath(new JsonPathConfig(JsonPathConfig.NumberReturnType.BIG_DECIMAL)).get(key);

						String s = String.valueOf(responseValue);
						s = s.indexOf(".") < 0 ? s : s.replaceAll("0*$", "").replaceAll("\\.$", "");
						responseValue = s;

						s = String.valueOf(inputValue);
						s = s.indexOf(".") < 0 ? s : s.replaceAll("0*$", "").replaceAll("\\.$", "");
						inputValue = s;

					}

					if (response.jsonPath().get("journalType").equals("FAWKST")
							&& (key.equalsIgnoreCase("numberOfShares") || key.equalsIgnoreCase("amount"))) {
						
						Assert.assertTrue(response.jsonPath().get("category")
								.equals(inputJsonValuesAsMap.get("$journalCategory")));

						if (response.jsonPath().get("category").equals("CASH_JOURNAL")
								&& key.equalsIgnoreCase("numberOfShares")) {
							Assert.assertTrue(responseValue.equals("null"));
						}

						else if (response.jsonPath().get("category").equals("SECURITIES_JOURNAL")
								&& key.equalsIgnoreCase("amount")) {
							Assert.assertTrue(responseValue.equals("null"));
						}
					}

					else {
						//System.out.println("key ="+key+ " ="+(String.valueOf(inputValue)).equalsIgnoreCase(String.valueOf(responseValue)));
						Assert.assertTrue(
								((String.valueOf(inputValue)).equalsIgnoreCase(String.valueOf(responseValue))));
					}

				}
				Assert.assertTrue((response.jsonPath().get("status").equals("PENDING")));
			}

		}
	}

	public static void verifyNewJournalsCreatedByModificationAPI(Response[] responses, String fieldName,
			Map<String, Object> inputJsonValues) throws java.text.ParseException {

		Set<String> keySet = inputJsonValues.keySet();
		Iterator<String> iterater = keySet.iterator();

		while (iterater.hasNext()) {
			String key = iterater.next();
			Object inputValue = inputJsonValues.get(key);
			key = key.replace("$", "");
			
			if (!(key.contains("testScenario") || inputValue.equals("null") || key.contains("status") || key.contains("journalCategory"))) {

				String originalInputValue = responses[0].body().jsonPath().get(key).toString();
				String newJournal1Value = responses[1].body().jsonPath().get(key).toString();
				String newJournal2Value = responses[2].body().jsonPath().get(key).toString();

				if (key.equals("amount") || key.equals("numberOfShares") || key.equals("withholdingAmount")
						|| key.equals("nraDropThroughAmount") || key.equals("stateWithholdingAmount")
						|| key.equals("fatcaCreditAmount") || key.equals("nraDropThroughRate") || key.equals("itemCost")
						|| key.equals("fatcaWithholdingAmount") || key.equals("stateWithholdingRate")
						|| key.equals("fatcaWithholdingRate") || key.equals("yearlyOidRate") || key.equals("strikePrice")) {

					originalInputValue = responses[0].body()
							.jsonPath(new JsonPathConfig(JsonPathConfig.NumberReturnType.BIG_DECIMAL)).get(key)
							.toString();

					String s = String.valueOf(originalInputValue);
					s = s.indexOf(".") < 0 ? s : s.replaceAll("0*$", "").replaceAll("\\.$", "");
					originalInputValue = s;

					newJournal1Value = responses[1].body()
							.jsonPath(new JsonPathConfig(JsonPathConfig.NumberReturnType.BIG_DECIMAL)).get(key)
							.toString();
					s = String.valueOf(newJournal1Value);
					s = s.indexOf(".") < 0 ? s : s.replaceAll("0*$", "").replaceAll("\\.$", "");
					newJournal1Value = s;

					newJournal2Value = responses[2].body()
							.jsonPath(new JsonPathConfig(JsonPathConfig.NumberReturnType.BIG_DECIMAL)).get(key)
							.toString();
					s = String.valueOf(newJournal2Value);
					s = s.indexOf(".") < 0 ? s : s.replaceAll("0*$", "").replaceAll("\\.$", "");
					newJournal2Value = s;

				}

				if (!key.equals(fieldName)) {
					
//					System.out.println(key);
//					System.out.println("Original and New journal 2 values are verified"+originalInputValue.equals(newJournal2Value));
					Assert.assertTrue("Original and New journal 2 values are verified",
							originalInputValue.equals(newJournal2Value));
				}

				if (!key.equals("typeDebitCredit")) {
					Assert.assertTrue("Original and New journal 1 values are verified",
						originalInputValue.equals(newJournal1Value));
				}

			}
		}

		Object changedFieldValue = inputJsonValues.get("$" + fieldName);
		String originalFieldValue = responses[0].body().jsonPath().get(fieldName).toString();
		String newJournal1FieldValue = responses[1].body().jsonPath().get(fieldName).toString();
		String newJournal2FieldValue = responses[2].body().jsonPath().get(fieldName).toString();
		if (fieldName.equals("amount") || fieldName.equals("numberOfShares") || fieldName.equals("withholdingAmount")
				|| fieldName.equals("nraDropThroughAmount") || fieldName.equals("stateWithholdingAmount")
				|| fieldName.equals("fatcaCreditAmount") || fieldName.equals("nraDropThroughRate")
				|| fieldName.equals("itemCost") || fieldName.equals("fatcaWithholdingAmount")
				|| fieldName.equals("stateWithholdingRate") || fieldName.equals("fatcaWithholdingRate")
				|| fieldName.equals("yearlyOidRate") || fieldName.equals("strikePrice")) {

			newJournal2FieldValue = responses[2].body()
					.jsonPath(new JsonPathConfig(JsonPathConfig.NumberReturnType.BIG_DECIMAL)).get(fieldName)
					.toString();

			String s = String.valueOf(newJournal2FieldValue);
			s = s.indexOf(".") < 0 ? s : s.replaceAll("0*$", "").replaceAll("\\.$", "");
			newJournal2FieldValue = s;

			s = String.valueOf(changedFieldValue);
			s = s.indexOf(".") < 0 ? s : s.replaceAll("0*$", "").replaceAll("\\.$", "");
			changedFieldValue = s;

		}
		if ((fieldName.contains("Date")) && !(fieldName.equals("originalTransactionDate"))
				&& !(fieldName.equals("recordDate"))) {
			DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			Date result1 = df1.parse(String.valueOf(changedFieldValue));
			changedFieldValue = result1;
			Date result2 = df1.parse(String.valueOf(newJournal2FieldValue));
			newJournal2FieldValue = String.valueOf(result2);
		}
		
		Assert.assertTrue("original field values are verified",
				String.valueOf(originalFieldValue).equals(String.valueOf(newJournal1FieldValue)));
		
		
		Assert.assertTrue("changed field values are verified",
				((String.valueOf(changedFieldValue)).equals(String.valueOf(newJournal2FieldValue))));

		String originaltypeDCvalue = responses[0].body().jsonPath().get("typeDebitCredit").toString();
		String newJournal1typeDCvalue = responses[1].body().jsonPath().get("typeDebitCredit").toString();

			
		Assert.assertFalse("typeDebitCredit value changed", originaltypeDCvalue.equals(newJournal1typeDCvalue));

	}

}
