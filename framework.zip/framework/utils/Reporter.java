package qa.framework.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.google.common.io.Files;

import io.cucumber.core.api.Scenario;

public class Reporter {

	public static ThreadLocal<Scenario> TScenario = new ThreadLocal<Scenario>();

	public synchronized static void addStepLog(String message) {
		TScenario.get().write(message);
	}

	/**
	 * Takes web application screenshot
	 * @author BathriYo
	 */
	public synchronized static void addScreenCapture() {
        String screenshotName = CaptureScreenshot.shutterScreenCapture();

        String html = "<div style=\"margin-bottom:5px;\">"
        			+ "<label style=\"color: #1E90FF\">Click on image to see Screenshot !!</label>"
                     + "<a href=\"" + screenshotName
                     + "\" target=\"_blank\" style=\"float:right;\"> <img src=\"core-image-screenshot.png\" style=\"background-color:aliceblue;\"/></a>"
                     + "</div>";

        addStepLog(html);

	}
	
	/**
	 * Takes Web application screenshot
	 * @author BathriYo
	 */
	public synchronized static void addCompleteScreenCapture() {
        String screenshotName = CaptureScreenshot.shutterEntireScreenCapture();

        String html = "<div style=\"margin-bottom:5px;\">"
    			+ "<label style=\"color: #1E90FF\">Click on image to see Screenshot !!</label>"
                 + "<a href=\"" + screenshotName
                 + "\" target=\"_blank\" style=\"float:right;\"> <img src=\"core-image-screenshot.png\" style=\"background-color:aliceblue;\"/></a>"
                 + "</div>";

        addStepLog(html);

	}
	
	/**
	 * Takes Desktop application screenshot
	 * 
	 * @author BathriYo
	 */
	public synchronized static void addDesktopScreenshot() {
		String screenshotName = CaptureScreenshot.desktopScreenCapture();
        String html = "<div style=\"margin-bottom:5px;\">"
    			+ "<label style=\"color: #1E90FF\">Click on image to see Screenshot !!</label>"
                 + "<a href=\"" + screenshotName
                 + "\" target=\"_blank\" style=\"float:right;\"> <img src=\"core-image-screenshot.png\" style=\"background-color:aliceblue;\"/></a>"
                 + "</div>";

        addStepLog(html);
	}

	public synchronized static void addEntireScreenCaptured() {
		Scenario scenario = TScenario.get();
		scenario.embed(CaptureScreenshot.captureEntireScreen(), "image/png");
	}

	
	
	private static void copyCoreFile(String toDirPath) {
		String fromDirPath= "./src/test/resources/core-image";
		File fromDir = new File(fromDirPath);
		
		File[] listFiles = fromDir.listFiles();
		
		for(File file: listFiles) {
			
			try {
				Files.copy(file, new File(toDirPath+"/"+file.getName()));
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
	}
	
	public static void updateGenericScrShotPath() {

		PropertyFileUtils property = new PropertyFileUtils("./src/test/resources/extent.properties");

		String sparkDirPath = "./" + property.getProperty("extent.reporter.spark.out");

		
		
		String filePath = sparkDirPath + "/index.html";
		File originalReport = new File(filePath);

		if (originalReport.exists()) {

			String root = System.getProperty("user.dir");

			/*--composing spark parent dir path to replace with '..'*/
			String sparkParentDir = root;

			String[] allSparkParents = sparkDirPath.split("/");
			/* start index is 1 as 0th index contain '.' */
			/*
			 * only need spark parent folder, thus -2 in length. allSparkParent contains
			 * Spark dir as well
			 */
			for (int i = 1; i <= allSparkParents.length - 2; i++) {
				sparkParentDir = sparkParentDir + "\\" + allSparkParents[i];
			}
			/*--*/

			File tempReport = null;

			BufferedReader bufReader = null;
			BufferedWriter bufWriter = null;

			try {

				tempReport = new File(sparkDirPath + "/index-temp.html");
				tempReport.createNewFile();

				FileReader reader = new FileReader(filePath);
				bufReader = new BufferedReader(reader);

				FileWriter writer = new FileWriter(tempReport);
				bufWriter = new BufferedWriter(writer);

				String line;
				while ((line = bufReader.readLine()) != null) {

					if (line.contains(sparkParentDir)) {
						line = line.replace(sparkParentDir, "..");
					}
					bufWriter.append(line);
				}

			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			} finally {

				try {
					bufReader.close();
					bufWriter.close();

					originalReport.delete();
					tempReport.renameTo(new File(sparkDirPath + "/index.html"));
				} catch (Exception e) {
					ExceptionHandler.handleException(e);

				}

			}
			
			/*copying core file to spark folder*/
			copyCoreFile(sparkDirPath);

		} else {
			System.out.println(
					" !!!!!! EXECUTION REPORT IS NOT AVAILABLE !!!!!!! Possible wrong tag or parameters are provided.");
		}
	}

}
