package qa.framework.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;


/**
 * 
 * @author BathriYo
 *
 */
@Deprecated
public class ExcelUtil {
	
	

	private static ThreadLocal<XSSFWorkbook> TExcelWBook = new ThreadLocal<XSSFWorkbook>();
	private static ThreadLocal<XSSFSheet> TExcelSheet = new ThreadLocal<XSSFSheet>();
	private static ThreadLocal<XSSFRow> TExcelRow = new ThreadLocal<XSSFRow>();
	private static ThreadLocal<String> TFilePath = new ThreadLocal<String>();

	/**
	 * Setting excel file for operation like getCellValue, setCellValue etc.
	 * 
	 * Note: use this method if want to work on same sheet.
	 * 
	 * @param excelFilePath
	 * @param sheetName
	 * @throws Exception
	 */
	public synchronized static void setExcelFile(String excelFilePath, String sheetName) {
		try {

			TFilePath.set(excelFilePath);
			FileInputStream excelFileInStr = new FileInputStream(TFilePath.get());

			TExcelWBook.set(new XSSFWorkbook(excelFileInStr));
			TExcelSheet.set(TExcelWBook.get().getSheet(sheetName));

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {

		}
	}

	/**
	 * Setting excel file for operation like getCellValue, setCellValue etc.
	 * 
	 * Note: 1. use this method if want to work on multiple sheet at time. 2. It is
	 * mandatory to setSheet() method after using this method
	 * 
	 * @param excelFilePath
	 * @return XSSFWorkbook
	 * @throws Exception
	 */
	public synchronized static XSSFWorkbook setExcelFile(String excelFilePath) {
		try {

			TFilePath.set(excelFilePath);
			FileInputStream excelFileInStr = new FileInputStream(TFilePath.get());

			TExcelWBook.set(new XSSFWorkbook(excelFileInStr));
			
			excelFileInStr.close();

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return TExcelWBook.get();
	}

	/**
	 * Set excel sheet
	 * 
	 * @param sheet
	 * @return XSSFSheet
	 */
	public synchronized static XSSFSheet setSheet(String sheet) {
		TExcelSheet.set(TExcelWBook.get().getSheet(sheet));
		return TExcelSheet.get();
	}
	
	
	/**
	 * Create a new excel file
	 * 
	 * @param filePath
	 * @param sheetName
	 * @throws Exception
	 */
	public static void createExcel(String argFilePath, String sheetName) {
		try {
			TFilePath.set( argFilePath);

			File newFile = new File(TFilePath.get());

			newFile.createNewFile();

			TExcelWBook.set( new XSSFWorkbook());

			TExcelSheet.set(TExcelWBook.get().createSheet(sheetName));

		} catch (Exception e) {
			
			ExceptionHandler.handleException(e);
		}

	}
	
	

	/**
	 * Get string cell data from excel sheet
	 * 
	 * @param rowNum
	 * @param cellNum
	 * @return String data
	 * @throws IOException
	 */
	public synchronized static String getStringCellData(int rowNum, int cellNum) throws IOException {
		String cellData = "";
		if (TExcelSheet.get().getRow(rowNum).getCell(cellNum) != null) {
			cellData = TExcelSheet.get().getRow(rowNum).getCell(cellNum).getStringCellValue();
		}
		return cellData;
	}

	/**
	 * Reading all type of values from excel file
	 * 
	 * @author BathriYo
	 * @param rowNum
	 * @param cellNum
	 * @return Object
	 */
	public synchronized static Object getCellData(int rowNum, int cellNum) {

		Object cellData;
		try {

			CellType cellType = TExcelSheet.get().getRow(rowNum).getCell(cellNum).getCellType();

			if (cellType == CellType.STRING) {

				cellData = TExcelSheet.get().getRow(rowNum).getCell(cellNum).getStringCellValue();

			} else if (cellType == CellType.NUMERIC) {

				cellData = (Double) TExcelSheet.get().getRow(rowNum).getCell(cellNum).getNumericCellValue();

			} else if (cellType == CellType.BOOLEAN) {

				cellData = (Boolean) TExcelSheet.get().getRow(rowNum).getCell(cellNum).getBooleanCellValue();

			} else if (cellType == CellType._NONE || cellType == CellType.BLANK) {
				cellData = "";
			} else {
				cellData = null;
			}

		} catch (NullPointerException e) {
			cellData = "";
		}

		return cellData;

	}

	/**
	 * Get complete column data
	 * 
	 * @author BathriYo
	 * @param columnName
	 * @return List<String>
	 */
	public synchronized static List<String> getCellData(String columnName) {
		boolean flag = false;
		int columnIndex = 0;
		int cellCount = getCellCount(0);
		int rowCount = getRowCount();

		List<String> columnValue = new ArrayList<String>();

		try {

			/* checking if column existing or not . getting column Index */
			for (int cIndex = 0; cIndex < cellCount; cIndex++) {

				if (getStringCellData(0, cIndex).equals(columnName)) {
					columnIndex = cIndex;
					flag = true;
				}
			}

			if (flag == true) {

				/* Fetching column data and adding in list */
				for (int rowIndex = 1; rowIndex < rowCount; rowIndex++) {
					columnValue.add(getStringCellData(rowIndex, columnIndex));
				}

			} else {
				Assert.fail("Column Name is not avaiable in excel sheet: " + columnName);
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return columnValue;
	}
	
	/**
	 * Get all the value in a column
	 * @param columnName
	 * @return List<Object>
	 */
	public synchronized static List<Object> getColumnData(String columnName) {
		boolean flag = false;
		int columnIndex = 0;
		int cellCount = getCellCount(0);
		int rowCount = getRowCount();

		List<Object> columnValue = new ArrayList<Object>();

		try {

			/* checking if column existing or not . getting column Index */
			for (int cIndex = 0; cIndex < cellCount; cIndex++) {

				if (getCellData(0, cIndex).equals(columnName)) {
					columnIndex = cIndex;
					flag = true;
				}
			}

			if (flag == true) {

				/* Fetching column data and adding in list */
				for (int rowIndex = 1; rowIndex < rowCount; rowIndex++) {
					columnValue.add(getCellData(rowIndex, columnIndex));
				}

			} else {
				Assert.fail("Column Name is not avaiable in excel sheet: " + columnName);
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return columnValue;
	}


	/**
	 * Setting String cell value
	 * 
	 * @param rowNum
	 * @param cellNum
	 * @param value
	 * @throws IOException
	 */
	public synchronized static void setCellData(int rowNum, int cellNum, String value) throws IOException {

		/*if row does not exists then create the row*/
		if (TExcelSheet.get().getRow(rowNum) == null) {
			TExcelRow.set(TExcelSheet.get().createRow(rowNum));
		} else {
			TExcelRow.set(TExcelSheet.get().getRow(rowNum));
		}

		/*if cell does not exists then create the cell else setCellValue*/
		if (TExcelRow.get().getCell(cellNum) == null) {
			TExcelRow.get().createCell(cellNum).setCellValue(value);
		} else {
			TExcelRow.get().getCell(cellNum).setCellValue(value);
		}

		FileOutputStream excelFileOutStr = new FileOutputStream(TFilePath.get());
		TExcelWBook.get().write(excelFileOutStr);

		excelFileOutStr.flush();

		excelFileOutStr.close();

	}

	/**
	 * Get Count of rows in a sheet
	 * 
	 * @return int
	 */
	public synchronized static int getRowCount() {

		int count = 0;

		if (TExcelSheet.get().getPhysicalNumberOfRows() > 0) {
			/* getLastRowNum returns Index not count thus count++ */
			count = TExcelSheet.get().getLastRowNum();
		} else {
			Assert.fail("!!! No Row found !!!");
		}

		return ++count;
	}

	/**
	 * Get Cell count in a given row
	 * 
	 * @param row
	 * @return int
	 */
	public synchronized static int getCellCount(int row) {
		int count = 0;

		TExcelRow.set(TExcelSheet.get().getRow(row));

		if (TExcelRow.get().getPhysicalNumberOfCells() > 0) {

			/* getLastCellNum returns count */
			count = TExcelRow.get().getLastCellNum();

		} else {
			Assert.fail("!!! No Cell found !!!");
		}
		return count;

	}

	/**
	 * Public static utils to get row index bases on cell data
	 * 
	 * @author BathriYo
	 * @param columnNum
	 * @param searchValue
	 * @return int row index if search value found else -1.
	 */
	public synchronized static int getRowIndexByCellValue(int columnNum, String searchValue) {

		try {

			int rowCount = getRowCount();

			for (int index = 0; index < rowCount; index++) {

				if (getStringCellData(index, columnNum).equals(searchValue)) {

					return index;
				}
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return -1;

	}

	/**
	 * This utility returns cell number based on row number and search value
	 * provided as argument
	 * 
	 * @author BathriYo
	 * @param rowNum
	 * @param searchValue
	 * @return int
	 */
	public synchronized static int getCellIndexByCellValue(int rowNum, String searchValue) {

		try {

			int cellCount = getCellCount(rowNum);

			for (int index = 0; index < cellCount; index++) {

				if (searchValue.equals(getCellData(rowNum, index) + "")) {
					return index;
				}
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return -1;
	}

	/**
	 * Closing XSSFWorkbook factory
	 * 
	 * @throws IOException
	 */
	public synchronized static void closeWorkBook() {
		try {
			TExcelWBook.get().close();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}
	
	public static ThreadLocal<XSSFWorkbook> getTExcelWBook() {
		return TExcelWBook;
	}

	public static ThreadLocal<XSSFSheet> getTExcelSheet() {
		return TExcelSheet;
	}

	public static ThreadLocal<XSSFRow> getTExcelRow() {
		return TExcelRow;
	}

	public static ThreadLocal<String> getTFilePath() {
		return TFilePath;
	}


}
