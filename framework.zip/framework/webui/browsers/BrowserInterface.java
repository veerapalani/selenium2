package qa.framework.webui.browsers;

import org.openqa.selenium.WebDriver;

public interface BrowserInterface {
	public WebDriver getDriver();
	
}
