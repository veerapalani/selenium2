package qa.framework.webui.browsers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;

import io.github.bonigarcia.wdm.WebDriverManager;
import qa.framework.utils.FileManager;

public class FirefoxBrowser implements BrowserInterface{

	private WebDriver driver;
	
	@Override
	public WebDriver getDriver() {
		
		String userDir = System.getProperty("user.dir");
		
		System.setProperty("webdriver.gecko.driver",userDir+"/src/test/resources/drivers/geckodriver.exe");
		
		FirefoxProfile profile = new FirefoxProfile();
		
		/*disabling download popup*/
		profile.setPreference("browser.helperApps.neverAsk.saveToDisk","image/jpeg,application/pdf,application/octet-stream,application/zip");
		
		/*user specified download folder config*/
		profile.setPreference("browser.download.folderList", 2);
		
		/*download folder path*/
		profile.setPreference("browser.download.dir", FileManager.getFileManagerObj().downloadFolderFilePath());
		
		profile.setPreference("pdfjs.disabled","true");
		
		/*handling certificate issue*/
		profile.setAcceptUntrustedCertificates(true);
		
		FirefoxOptions option = new FirefoxOptions();
		
		option.setProfile(profile);
		
		//WebDriverManager.firefoxdriver().setup();
		
		driver = new FirefoxDriver(option);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		return driver;		
	}
	
	
	
}	
