package qa.framework.webui.browsers;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import qa.framework.utils.FileManager;
import qa.framework.utils.GlobalVariables;

public class ChromeBrowser implements BrowserInterface {

	private WebDriver driver;

	@Override
	public synchronized WebDriver getDriver() {

		// String userDir = System.getProperty("user.dir");

		// String browserVersion = WebDriverManager.getBrowserVersion();

		// System.setProperty("webdriver.chrome.driver", userDir +
		// "/src/test/resources/drivers/chromedriver_" + browserVersion + ".exe");

		Map<String, Object> preferences = new HashMap<String, Object>();

		/* do not shown any pop up (windows pop up) while downloading any file */
		preferences.put("profile.default_content_settings.popups", 0);

		/* set default download folder */
		preferences.put("download.default_directory", FileManager.getFileManagerObj().downloadFolderFilePath());

		/* disable Keep/discard warning message from chrome */
		preferences.put("safebrowsing.enabled", "true");

		/* Handling certification issue */
		preferences.put("CapabilityType.ACCEPT_SSL_CERTS", "true");

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--ignore-certificate-errors");
		//options.addArguments("--windows-size=1278,630");
		options.setExperimentalOption("prefs", preferences);
		options.setPageLoadStrategy(PageLoadStrategy.EAGER);

		if (System.getProperty("platform") != null) {
			if (System.getProperty("platform").equalsIgnoreCase("linux")) {
				options.addArguments("--no-sandbox");
				options.addArguments("--headless");
				options.addArguments("--disable-dev-shm-usage");
			}
		}
		options.addArguments("--disable-gpu");

		if (WebDriverManager.getBrowserName().contains("incognito")) {
			options.addArguments("--incognito");
		}

		io.github.bonigarcia.wdm.WebDriverManager.chromedriver().proxy("10.98.21.24:8080").setup();

		this.driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(120L, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(90L, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(GlobalVariables.waitTime, TimeUnit.SECONDS);
		return driver;
	}

}