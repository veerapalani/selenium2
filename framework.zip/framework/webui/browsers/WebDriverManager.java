package qa.framework.webui.browsers;

import java.net.URL;

import org.apache.log4j.Logger;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.FileManager;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.LoggerHelper;
import qa.framework.utils.SystemProcess;

/**
 * 
 * @author BathriYo
 *
 */
public class WebDriverManager {

	public static boolean launchNewBrowserPerScenario;
	private static String browser = null;
	private static String browserVersion = null;
	private static String platform = null;
	private static String remote = "false";
	private static String huburl = null;

	public static DesiredCapabilities capabilities;

	private static ThreadLocal<WebDriver> TDriver = new ThreadLocal<WebDriver>();

	private static Logger log = LoggerHelper.getLogger(WebDriverManager.class);
	
	/*configuring 'launchNewBrowserPerScenario' setting*/
	private static synchronized void configBrowserLaunch() {
		/* reading from cmd line */
		String cmdlaunchNewBrowserPerScenario = System.getProperty("launchNewBrowserPerScenario");

		if (cmdlaunchNewBrowserPerScenario!=null) {
			launchNewBrowserPerScenario = Boolean.parseBoolean(cmdlaunchNewBrowserPerScenario);
		} else {
			
			/* reading from property file */
			launchNewBrowserPerScenario = Boolean.parseBoolean(GlobalVariables.configProp.getProperty("launchNewBrowserPerScenario"));
		}
	}

	/* configuring browser */
	private static synchronized void configBrowser() {
		/* reading from cmd line */
		String cmdBrowser = System.getProperty("browser");

		if (cmdBrowser!=null) {
			browser = cmdBrowser;
		} else {
			/* reading from property file */
			browser = GlobalVariables.configProp.getProperty("browser");
		}

	}

	/* configure remote */
	private static synchronized void configRemote() {
		/* reading from cmd line */
		String cmdRemote = System.getProperty("remote");

		if (cmdRemote!=null) {
			remote = cmdRemote;
		} else {
			
			try {
				/* reading from property file */
				remote = GlobalVariables.configProp.getProperty("remote");
			}catch(Exception e) {
				//if remote is not available in property file remote="false";
			}
			
		}
	}

	/* configuring browser version */
	private static synchronized void configBrowserVersion() {
			/* reading from cmd line */
			String cmdBrowserVersion = System.getProperty("browserVersion");

			if (cmdBrowserVersion!=null) {
				browserVersion = cmdBrowserVersion;
			} else {
				/* reading from property file */
				browserVersion = GlobalVariables.configProp.getProperty("browserVersion");
			}

	}

	/* configuring platform */
	private static synchronized void configPlatform() {

		/* these setting is only configured for remote execution */
		if (remote.equals("true")) {

			/* reading from cmd line */
			String cmdPlatform = System.getProperty("platform");

			if (cmdPlatform!=null) {
				platform = cmdPlatform;
			} else {
				/* reading from property file */
				platform = GlobalVariables.configProp.getProperty("platform");
			}

		}

	}

	/* configuring hub url */
	private static synchronized void configHubUrl() {

		/* these setting is only configured for remote execution */
		if (remote.equals("true")) {

			/* reading from cmd line */
			String cmdHubUrl = System.getProperty("huburl");

			if (cmdHubUrl!=null) {
				huburl = cmdHubUrl;
			} else {
				/* reading from property file */
				huburl = GlobalVariables.configProp.getProperty("huburl");
			}

		}

	}

	private static synchronized void setPlatformCapability() {
		switch (platform) {
		case "WINDOWS":
			capabilities.setPlatform(Platform.WINDOWS);
			break;
		case "WIN10":
			capabilities.setPlatform(Platform.WIN10);
			break;
		case "ANY":
			capabilities.setPlatform(Platform.ANY);
			break;
		case "LINUX":
			capabilities.setPlatform(Platform.LINUX);
		default:
			log.debug("!!! INCORRECT PLATFORM PROVIDED !!! " + platform);
		}
	}
	
	/**
	 * 
	 * Setting remote webdriver
	 * 
	 * @author BathriYo
	 * @param browserName
	 */
	private static synchronized void setRemoteWebDriver(String browserName) {

		switch (browserName) {
		case"incognitochrome":
		case "chrome": {

			ChromeOptions options = new ChromeOptions();
			
			capabilities = DesiredCapabilities.chrome();
			capabilities.setVersion(browserVersion);
			setPlatformCapability();
			capabilities.setCapability("profile.default_content_settings.popups", 0);
			capabilities.setCapability("download.default_directory", FileManager.getFileManagerObj().downloadFolderFilePath());
			capabilities.setCapability("safebrowsing.enabled", "true");
			capabilities.acceptInsecureCerts();
			
			if(WebDriverManager.getBrowserName().contains("incognito")) {
				
				options.addArguments("--incognito");
				capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			}
			
			

			break;
		}
		case "ie": {

			capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setVersion(browserVersion);
			setPlatformCapability();

			break;
		}
		case "edge": {

			capabilities = DesiredCapabilities.edge();
			capabilities.setVersion(browserVersion);
			setPlatformCapability();

			break;
		}
		case "firefox": {

			capabilities = DesiredCapabilities.firefox();
			capabilities.setVersion(browserVersion);
			setPlatformCapability();

			/* disabling download popup */
			capabilities.setCapability("browser.helperApps.neverAsk.saveToDisk",
					"image/jpeg,application/pdf,application/octet-stream,application/zip");
			/* user specified download folder config */
			capabilities.setCapability("browser.download.folderList", 2);
			/* download folder path */
			capabilities.setCapability("browser.download.dir", FileManager.getFileManagerObj().downloadFolderFilePath());
			capabilities.setCapability("pdfjs.disabled", "true");
			capabilities.setAcceptInsecureCerts(true);

			break;
		}

		default: {
			Assert.fail("!!! INCORRECT BROWSER NAME PROVIDED !!!" + browserName);
		}

		}

		try {
			TDriver.set(new RemoteWebDriver(new URL(huburl), capabilities));
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/* setting driver */
	private static synchronized void setDriver(String browserName) {

		switch (browserName) {
		case "incognitochrome":
		case "chrome": {

			TDriver.set(new ChromeBrowser().getDriver());
			break;
		}
		case "ie": {
			TDriver.set(new IEBrowser().getDriver());
			break;
		}
		case "edge": {

			TDriver.set(new EdgeBrowser().getDriver());
			break;
		}
		case "firefox": {

			TDriver.set(new FirefoxBrowser().getDriver());
			break;
		}

		default: {
			Assert.fail("!!! INCORRECT BROWSER NAME PROVIDED !!!" + browserName);
		}

		}

	}
	
	
	/* configuring driver */
	public static synchronized void configureDriver() {

		/*configuring browser launch condition*/
		configBrowserLaunch();
		
		/* configuring browser */
		configBrowser();

		/* configuring remote value */
		configRemote();
		
		/* configuring remote value */
		configBrowserVersion();
		
		switch(remote){
		case"true":{
			configHubUrl();
			configPlatform();
			break;
			
		}case"false":{
			/*DOES NOTHIGN*/
			break;
			
		}default:{
			Assert.fail(" !!! INCORRECT REMOTE VALUE PROVIDED !!! "+remote);
		}
		
		}

		
	}

	
	

	/* getting browser */
	public static synchronized String getBrowserName() {
		return browser;
	}
	/**
	 * Browser version
	 * @return : String
	 */
	public static String getBrowserVersion() {
		return browserVersion;
	}

	public static synchronized void setBrowser(String browser) {
		WebDriverManager.browser=browser;
	} 
	
	/* start driver */
	public static synchronized void startDriver() {
		if(remote.equals("true")) {
			setRemoteWebDriver(browser);
		}else if (remote.equals("false")){
			setDriver(browser);
		}
	}

	/* get driver */
	public static synchronized WebDriver getDriver() {
		return TDriver.get();
	}
	
	/* get driver */
	public static synchronized void setDriver(WebDriver driver) {
		TDriver.set(driver);
	}

	/**
	 * close driver
	 * 
	 * @author BathriYo
	 */
	public static synchronized void closeDriver() {
		TDriver.get().close();
	}

	/**
	 * Quit driver
	 * 
	 * @author BathriYo
	 */
	public static synchronized void quitDriver() {
		TDriver.get().quit();
	}
	
	/**
	 * Kills driver processes
	 * 
	 * @author BathriYo
	 */
	public static void killDriverProcess() {

		try {

			switch (browser) {
			case "chrome":
				SystemProcess.killProcess("chromedriver.exe");
				break;

			case "firefox":
				SystemProcess.killProcess("geckodriver.exe");
				break;

			case "ie":
				SystemProcess.killProcess("IEDriverServer.exe");
				break;
			case "edge":
				SystemProcess.killProcess("Microsoft Web Driver.exe");
				break;

			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

}