package qa.framework.webui.browsers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import qa.framework.utils.GlobalVariables;

public class IEBrowser implements BrowserInterface {

	private WebDriver driver;

	@Override
	public WebDriver getDriver() {

		// String userDir = System.getProperty("user.dir");

		// System.setProperty("webdriver.ie.driver",
		// userDir+"/src/test/resources/drivers/IEDriverServer.exe");

		WebDriverManager.iedriver().proxy("10.98.21.24:8080").setup();
		this.driver = new InternetExplorerDriver();
		driver.manage().timeouts().implicitlyWait(GlobalVariables.waitTime, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		return driver;
	}

}
