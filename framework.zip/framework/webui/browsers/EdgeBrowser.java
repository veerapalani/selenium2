package qa.framework.webui.browsers;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import com.microsoft.edge.seleniumtools.EdgeDriver;
import com.microsoft.edge.seleniumtools.EdgeOptions;

import qa.framework.utils.FileManager;
import qa.framework.utils.GlobalVariables;

public class EdgeBrowser implements BrowserInterface {

	private WebDriver driver;

	@Override
	public WebDriver getDriver() {

		String browserVersion = WebDriverManager.getBrowserVersion();

		System.setProperty("webdriver.edge.driver",
				System.getProperty("user.dir") + "/src/test/resources/drivers/msedgedriver_" + browserVersion + ".exe");

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("download.default_directory", FileManager.getFileManagerObj().downloadFolderFilePath());

		EdgeOptions option = new EdgeOptions();
		option.setExperimentalOption("prefs", prefs);

		// commented below due to proxy authentication error fro edge
		// io.github.bonigarcia.wdm.WebDriverManager.edgedriver().operatingSystem(OperatingSystem.WIN).proxy("10.98.21.24:8080").setup();
		this.driver = new EdgeDriver(option);

		driver.manage().timeouts().implicitlyWait(GlobalVariables.waitTime, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		return driver;
	}

}
