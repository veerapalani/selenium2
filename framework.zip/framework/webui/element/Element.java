package qa.framework.webui.element;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.paulhammant.ngwebdriver.ByAngular;

import qa.framework.desktop.DesktopDriverManager;
import qa.framework.utils.LoggerHelper;
import qa.framework.webui.browsers.WebDriverManager;

public class Element {

	WebDriver driver;

	Logger log = LoggerHelper.getLogger(Element.class);

	public Element(WebDriver driver) {
		this.driver = WebDriverManager.getDriver();
	}

	/**
	 * Get Element (driver.findElment())
	 * 
	 * @param valueType
	 * @param value
	 * @return
	 */
	public synchronized WebElement getElement(String valueType, String value) {

		switch (valueType.toLowerCase()) {

		case "js":{
			 
			return (WebElement) ((JavascriptExecutor)driver).executeScript(value);
		}
		case "id":
			return driver.findElement(By.id(value));

		case "name":
			return driver.findElement(By.name(value));

		case "classname":
			return driver.findElement(By.className(value));

		case "linktext":
			return driver.findElement(By.linkText(value));

		case "partiallinktext":
			return driver.findElement(By.partialLinkText(value));

		case "xpath":
			return driver.findElement(By.xpath(value));

		case "tagname":
			return driver.findElement(By.tagName(value));

		case "cssselector":
			return driver.findElement(By.cssSelector(value));

		case "ng-model":
			return driver.findElement(ByAngular.model(value));

		case "ng-bind":
			return driver.findElement(ByAngular.binding(value));

		case "exactbinding":
			return driver.findElement(ByAngular.exactBinding(value));

		case "buttontext":
			return driver.findElement(ByAngular.buttonText(value));

		case "partialbuttontext":
			return driver.findElement(ByAngular.partialButtonText(value));
			
		case "desktop-runtimeId":
			return DesktopDriverManager.getDriver().findElementById(value);
		
		case "desktop-classname":
			return DesktopDriverManager.getDriver().findElementByClassName(value);
		
		case "desktop-automationId":
			return DesktopDriverManager.getDriver().findElementByAccessibilityId(value);
			
		case "desktop-name":
			return DesktopDriverManager.getDriver().findElementByName(value);
			
		case "desktop-localizedControlType":
			return DesktopDriverManager.getDriver().findElementByTagName(value);
			
		case "desktop-xpath":
			return DesktopDriverManager.getDriver().findElementByXPath(value);
			
		default:
			log.debug("Select by : " + valueType + " is incorrect!");
			return null;
		}

	}

	/**
	 * Get Element (element.findElement())
	 * 
	 * @author SinhaRi
	 * @param parentElement
	 * @param valueType
	 * @param value
	 * @return
	 */
	public synchronized WebElement getElement(WebElement parentElement, String valueType, String value) {

		switch (valueType.toLowerCase()) {

		case "id":
			return parentElement.findElement(By.id(value));

		case "name":
			return parentElement.findElement(By.name(value));

		case "classname":
			return parentElement.findElement(By.className(value));

		case "linktext":
			return parentElement.findElement(By.linkText(value));

		case "partiallinktext":
			return parentElement.findElement(By.partialLinkText(value));

		case "xpath":
			return parentElement.findElement(By.xpath(value));

		case "tagname":
			return parentElement.findElement(By.tagName(value));

		case "cssselector":
			return parentElement.findElement(By.cssSelector(value));

		case "cssselector1":
			return parentElement.findElement(By.cssSelector(value));

		case "ng-model":
			return parentElement.findElement(ByAngular.model(value));

		case "ng-bind":
			return parentElement.findElement(ByAngular.binding(value));

		case "exactbinding":
			return parentElement.findElement(ByAngular.exactBinding(value));

		case "buttontext":
			return parentElement.findElement(ByAngular.buttonText(value));

		case "partialbuttontext":
			return parentElement.findElement(ByAngular.partialButtonText(value));

		default:
			log.debug("Select by : " + valueType + " is incorrect!");
			return null;
		}

	}

	/**
	 * Get list of Elements (driver.findElements())
	 * 
	 * @param valueType
	 * @param value
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public synchronized List<WebElement> getElements(String valueType, String value) {

		switch (valueType.toLowerCase()) {

		case "js":{
			 
			return (List<WebElement>) ((JavascriptExecutor)driver).executeScript(value);
		}
		case "id":
			return driver.findElements(By.id(value));

		case "name":
			return driver.findElements(By.name(value));

		case "classname":
			return driver.findElements(By.className(value));

		case "linktext":
			return driver.findElements(By.linkText(value));

		case "partiallinktext":
			return driver.findElements(By.partialLinkText(value));

		case "xpath":
			return driver.findElements(By.xpath(value));

		case "tagname":
			return driver.findElements(By.tagName(value));

		case "cssselector":
			return driver.findElements(By.cssSelector(value));

		case "ng-model":
			return driver.findElements(ByAngular.model(value));

		case "ng-bind":
			return driver.findElements(ByAngular.binding(value));

		case "exactbinding":
			return driver.findElements(ByAngular.exactBinding(value));

		case "buttontext":
			return driver.findElements(ByAngular.buttonText(value));

		case "partialbuttontext":
			return driver.findElements(ByAngular.partialButtonText(value));

		case "repeater":
			return driver.findElements(ByAngular.repeater(value));
			
		case "desktop-runtimeId":
			return (List<WebElement>)DesktopDriverManager.getDriver().findElementsById(value);
		
		case "desktop-classname":
			return (List<WebElement>) DesktopDriverManager.getDriver().findElementsByClassName(value);
		
		case "desktop-automationId":
			return (List<WebElement>) DesktopDriverManager.getDriver().findElementsByAccessibilityId(value);
			
		case "desktop-name":
			return (List<WebElement>) DesktopDriverManager.getDriver().findElementsByName(value);
			
		case "desktop-localizedControlType":
			return (List<WebElement>) DesktopDriverManager.getDriver().findElementsByTagName(value);
			
		case "desktop-xpath":
			return (List<WebElement>) DesktopDriverManager.getDriver().findElementsByXPath(value);
		

		default:
			log.debug("Select by : " + valueType + " is incorrect!");

		}
		return null;
	}

	/**
	 * Get list of Elements (parentElement.findElements())
	 * 
	 * @param parentElement
	 * @param valueType
	 * @param value
	 * @return
	 */
	public synchronized List<WebElement> getElements(WebElement parentElement, String valueType, String value) {

		switch (valueType.toLowerCase()) {

		case "id":
			return parentElement.findElements(By.id(value));

		case "name":
			return parentElement.findElements(By.name(value));

		case "classname":
			return parentElement.findElements(By.className(value));

		case "linktext":
			return parentElement.findElements(By.linkText(value));

		case "partiallinktext":
			return parentElement.findElements(By.partialLinkText(value));

		case "xpath":
			return parentElement.findElements(By.xpath(value));

		case "tagname":
			return parentElement.findElements(By.tagName(value));

		case "cssselector":
			return parentElement.findElements(By.cssSelector(value));

		case "cssselector1":
			return parentElement.findElements(By.cssSelector(value));

		case "ng-model":
			return parentElement.findElements(ByAngular.model(value));

		case "ng-bind":
			return parentElement.findElements(ByAngular.binding(value));

		case "exactbinding":
			return parentElement.findElements(ByAngular.exactBinding(value));

		case "buttontext":
			return parentElement.findElements(ByAngular.buttonText(value));

		case "partialbuttontext":
			return parentElement.findElements(ByAngular.partialButtonText(value));

		case "repeater":
			return parentElement.findElements(ByAngular.repeater(value));

		default:
			log.debug("Select by : " + valueType + " is incorrect!");

		}
		return null;
	}

}
