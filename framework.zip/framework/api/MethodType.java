package qa.framework.api;

public enum MethodType {
	
	POST,GET,PUT,DELETE;
}
