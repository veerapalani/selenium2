package qa.framework.api;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContexts;

import com.google.common.net.HttpHeaders;

import io.restassured.path.json.JsonPath;

public class HttpClientUtils implements RequestBuilder, RetriveResponse, ResponseBody {

	public static String basePath;
	public static String baseUri;

	private URIBuilder uriBuilder;
	private HttpResponse response;
	private StringEntity requestEntity;

	private static List<NameValuePair> formparams;
	private static List<Header> headers;
	private static HttpClientBuilder httpClientBuilder;

	private static HttpClientUtils httpClientUtils;

	private RequestBuilder request;

	private RetriveResponse rResponse;
	private String bodyAsString;

	public static RequestBuilder given() {

		formparams = new ArrayList<NameValuePair>();
		headers = new ArrayList<Header>();
		httpClientBuilder = HttpClients.custom();

		httpClientUtils = new HttpClientUtils();
		return httpClientUtils;

	}

	private void setScheme() {

		if (baseUri.contains("https://")) {

			uriBuilder.setScheme("https");

		} else if (baseUri.contains("http://")) {

			uriBuilder.setScheme("http");
		}
	}

	private void setHost() {
		uriBuilder.setHost(baseUri.split("/")[2]);
	}

	private void setPath() {
		String leftOver = baseUri.split(uriBuilder.getHost())[1];
		if (!basePath.contains(leftOver)) {
			basePath = leftOver + basePath;
		}

		uriBuilder.setPath(basePath);
	}

	public HttpClientUtils buildUri() {

		try {

			uriBuilder = new URIBuilder();
			setScheme();
			setHost();
			setPath();
			return httpClientUtils;
		} catch (Exception e) {

			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public RequestBuilder setContentType(String type) {

		headers.add(new BasicHeader(HttpHeaders.CONTENT_TYPE, type));
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setAcceptType(String type) {
		headers.add(new BasicHeader("Accept", type));
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setHeader(String headerName, String headerValue) {
		headers.add(new BasicHeader(headerName, headerValue));
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setHeader(Map<String, String> headerMap) {
		headerMap.forEach((headerName, headerValue) -> {
			headers.add(new BasicHeader(headerName, headerName));

		});
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setPathParameter(String parameterName, String parameterValue) {
		
		basePath = basePath.replace("{" + parameterName + "}", parameterValue);
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setPathParameter(Map<String, String> pathParameterMap) {

		pathParameterMap.forEach((parameter, value) -> {
			basePath = basePath.replace("{" + parameter + "}", value);
		});
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setQueryParameter(String queryParameterName, String queryParameterValue) {
		uriBuilder.setParameter(queryParameterName, queryParameterValue);
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setQueryParameter(Map<String, String> queryParameterMap) {

		queryParameterMap.forEach((queryParameterName, queryParameterValue) -> {
			uriBuilder.setParameter(queryParameterName, queryParameterValue);
		});
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setFormParameter(String parameterName, String parameterValue) {
		formparams.add(new BasicNameValuePair(parameterName, parameterValue));
		return httpClientUtils;
	}

	@Override
	public RequestBuilder setFormParameter(Map<String, String> formParameterMap) {

		formParameterMap.forEach((parameterName, parameterValue) -> {
			formparams.add(new BasicNameValuePair(parameterName, parameterValue));
		});
		return httpClientUtils;

	}

	@Override
	public RequestBuilder setBody(String body) {
		try {

			requestEntity = new StringEntity(body, "UTF-8");

			// requestEntity = new StringEntity(body, contentType, "UTF-8");

		} catch (Exception e) {

			e.printStackTrace();
		}

		return httpClientUtils;
	}

	@Override
	public RequestBuilder setCetificate(String path, String password) {

		try {

			final KeyStore store = KeyStore.getInstance("PKCS12");

			try (FileInputStream stream = new FileInputStream(new File(path))) {

				store.load(stream, password.toCharArray());
			}
			SSLContext sslContext = SSLContexts.custom().loadKeyMaterial(store, password.toCharArray())
					.loadTrustMaterial(store, TrustAllStrategy.INSTANCE).build();

			final SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext,
					NoopHostnameVerifier.INSTANCE);

			final Registry<ConnectionSocketFactory> registry = RegistryBuilder.<ConnectionSocketFactory>create()
					.register("http", new PlainConnectionSocketFactory()).register("https", sslsf).build();

			final PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager(registry);
			cm.setMaxTotal(100);
			cm.setValidateAfterInactivity(100);

			httpClientBuilder.setSSLSocketFactory(sslsf).setConnectionManager(cm);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return httpClientUtils;

	}

	@Override
	public RequestBuilder setProxy(String host, int port) {

		HttpHost proxy = new HttpHost(host, port);
		/*
		 * DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy)
		 */;
	//	httpClientBuilder.setRoutePlanner(routePlanner);
		 httpClientBuilder.setProxy(proxy);
		
		return httpClientUtils;
	}
	
	
	@Override
	public RetriveResponse executeRequest(MethodType type) {

		try {

			URI uri = uriBuilder.build();

			if (!headers.isEmpty()) {

				httpClientBuilder.setDefaultHeaders(headers);

			}

			HttpClient client = httpClientBuilder.build();

			switch (type) {

			case POST: {

				HttpPost postRequest = new HttpPost(uri);

				if (!formparams.isEmpty()) {

					UrlEncodedFormEntity entity = new UrlEncodedFormEntity(formparams, Consts.UTF_8);
					postRequest.setEntity(entity);

				}
				
				/*throwing NullPointer Exception if user does not set body for post*/
//				if (requestEntity!=null || requestEntity.getContentLength() > 0) {
//					postRequest.setEntity(requestEntity);
//				}
				
				postRequest.setEntity(requestEntity);

				response = client.execute(postRequest);

				break;
			}
			case PUT: {

				HttpPut putRequest = new HttpPut(uri);

				if (requestEntity.getContentLength() > 0) {
					putRequest.setEntity(requestEntity);
				}

				response = client.execute(putRequest);

				break;
			}
			case DELETE: {

				HttpDelete deleteRequest = new HttpDelete(uri);

				response = client.execute(deleteRequest);

				break;
			}
			case GET: {

				HttpGet getRequest = new HttpGet(uri);

				response = client.execute(getRequest);

				break;
			}
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

		return httpClientUtils;
	}

	/*****************************************
	 * Response
	 *****************************************/
	@Override
	public HttpResponse getResponse() {
		return response;
	}

	@Override
	public int getStatusCode() {
		return response.getStatusLine().getStatusCode();
	}

	@Override
	public String getStatusLine() {
		return response.getStatusLine().toString();
	}

	@Override
	public ResponseBody getBody() {

		String line;
		StringBuilder body = new StringBuilder();
		
		InputStreamReader streamReader=null;
		BufferedReader bis=null;
		
		
		try {
			streamReader=new InputStreamReader(response.getEntity().getContent());
			bis = new BufferedReader(streamReader);

			while ((line = bis.readLine()) != null) {
				body.append(line);
			}
			bodyAsString = body.toString();
			
		} catch (IOException e) {
			/*Input stream return by getContent() can be read only once*/
		}catch(Exception e) {
			
		}finally{
			try {
				bis.close();
				streamReader.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		}
		
		
		return httpClientUtils;
	}

	@Override
	public String asString() {
		return bodyAsString;
	}

	@Override
	public Object jsonPath(String path) {
		JsonPath j = new JsonPath(bodyAsString);
		
		return j.get(path);
	}
}
