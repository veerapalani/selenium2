package qa.framework.jsonschemavalidation.stepdefs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.everit.json.schema.ValidationException;
import org.json.JSONObject;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import qa.framework.jsonschemavalidation.SchemaValidationModes;
import qa.framework.utils.CommonAPISteps;
import qa.framework.utils.FileManager;
import qa.framework.utils.Reporter;


public class JsonSchemaValidationStepDefs extends qa.framework.jsonschemavalidation.JsonSchemaValidation {

	String response;
	String swaggerJsonAsString;
	JSONObject definition;

	CommonAPISteps objCommnoAPISteps = new CommonAPISteps();
	private static boolean ignoreNull = false;

	@Given("^user have json response (.*) available$")
	public void user_has_response_json_something_available(String responseJsonFileName) {

		/* generalizing "args" and <args> from feature file */
		responseJsonFileName = responseJsonFileName.replace("\"", "");

		String userDir = System.getProperty("user.dir");

		String filepath = FileManager.getFileManagerObj().searchFile(userDir, responseJsonFileName);
		response = FileManager.getFileManagerObj().readFile(filepath);

		String fileName = objCommnoAPISteps.putJsonInFile(response, "response");
		objCommnoAPISteps.addFileToReport("Click on link to see JSON to be validated !!", fileName);

	}

	@Given("^verifying json schema for (.+) endpoint$")
	public void verifying_json_schema_for_endpoint(String endpoint) {
		// do nothing
	}

	@When("^user set api response as input for json schema validation$")
	public void user_set_api_response_as_input_for_json_schema_validation() {
		response = CommonAPISteps.response.body().asString();
	}

	@And("^user have swagger yaml (.*) available$")
	public void user_have_swagger_yaml_something_available(String swaggerYmlFileName) throws IOException {

		/* generalizing "args" and <args> from feature file */
		swaggerYmlFileName = swaggerYmlFileName.replace("\"", "");

		swaggerJsonAsString = convertSwaggerToString(swaggerYmlFileName);// convertYamlToJson(swaggerYmlFileName);

	}

	@Deprecated
	@When("^user convert swagger yaml to json schema for object to validate (.+) junk value added $")
	public void user_convert_swagger_yaml_to_json_schema_for_object_to_validate(String objectToValidate) {

		objectToValidate = objectToValidate.replace("\"", "");

		/* objectType is now taken directly from swagger json schema */
		String objectTypeQuery = "$.definitions." + objectToValidate + ".type";

		/* "#/components/schemas/orderTraderBlotterResponse" */
		String objetTypeQueryOpenAppi = "$.components.schemas." + objectToValidate + ".type";

		if (swaggerJsonAsString.contains("openapi")) {

			objectType = String.valueOf(getValue(swaggerJsonAsString, objetTypeQueryOpenAppi));
			// objectType="object";

		} else {

			objectType = String.valueOf(getValue(swaggerJsonAsString, objectTypeQuery));

		}

		definition = createJsonSchema(swaggerJsonAsString, objectToValidate, objectType);

	}

	@When("^user convert swagger yaml to json schema for object to validate (.+) and of object type (.+)$")
	public void user_convert_swagger_yaml_to_json_schema_for_object_to_validate_and_of_object_type(
			String objectToValidate, String objectType) {

		objectToValidate = objectToValidate.replace("\"", "");
		objectType = objectType.replace("\"", "");

		qa.framework.jsonschemavalidation.JsonSchemaValidation.objectType = objectType;

		definition = createJsonSchema(swaggerJsonAsString, objectToValidate, objectType);

	}

	@When("^user have json schema \"([^\"]*)\" avaiable$")
	public void user_have_json_schema_something_avaiable(String jsonSchemaFileName) throws IOException {

		String jsonSchema = convertSwaggerToString(jsonSchemaFileName);
		definition = new JSONObject(jsonSchema);

	}

	@And("^user add validation options \"([^\"]*)\" to existing json schema$")
	public void user_add_validation_options_something_to_existing_json_schema(String options) {

		List<String> optionList = Arrays.asList(options.split(","));

		HashSet<SchemaValidationModes> schemaValidationModes = new HashSet<SchemaValidationModes>();

		if (!optionList.isEmpty()) {
			if (options.contains("ALL_PROPERTIES_REQUIRED")) {
				schemaValidationModes.add(SchemaValidationModes.ALL_PROPERTIES_REQUIRED);
			}
			if (options.contains("NO_ADDITIONAL_PROPERTIES")) {
				schemaValidationModes.add(SchemaValidationModes.NO_ADDITIONAL_PROPERTIES);
			}

			if (options.contains("IGNORE_NULL_VALUES")) {
				schemaValidationModes.add(SchemaValidationModes.IGNORE_NULL_VALUES);
				ignoreNull = true;
			}
			
			if (options.contains("FAIL_EMPTY_ARRAYS")) {
				schemaValidationModes.add(SchemaValidationModes.FAIL_EMPTY_ARRAYS);
			}
			
			

		}

		definition = addSchemaValidationOptions(definition, schemaValidationModes);

		/* Reporting step */
		String fileName = objCommnoAPISteps.putJsonInFile(definition.toString(), "jsonschema");
		objCommnoAPISteps.addFileToReport("Clink on link to see JSON schema !!", fileName);

	}

	@Then("^user perform json validation and results are logged$")
	public void user_perform_json_validation_and_results_are_logged() {

		try {

			validateSchema(definition, response);

		} catch (ValidationException validationException) {

			reportJsonSchemaValidationError(validationException);

		} catch (Exception e) {
			throw new AssertionError(e);

		}

		Reporter.addStepLog("<strong>JSON Schema Validation Passed !!</strong>");

	}

	/*
	 * # Missing Required Properties #/1: required key [name] not found ***
	 * 
	 * # Missing Dependencies #/1: property [status] is required ***
	 * 
	 * 
	 * # Found Addition Properties #/1: extraneous key [program-name] is not
	 * permitted ***
	 * 
	 * # Type MisMatch #/1/identifier: expected type: Number, found: Null ***
	 *** 
	 * #/1/feeStructures: expected type: JSONArray, found: Null
	 ****/
	public static void reportJsonSchemaValidationError(ValidationException validationException) {

		List<String> missingRequiredProperties = new ArrayList<String>();
		List<String> missingDependencies = new ArrayList<String>();
		List<String> foundAdditionalProperties = new ArrayList<String>();
		List<String> typeMisMatch = new ArrayList<String>();
		List<String> unknown = new ArrayList<String>();

		List<String> allMessages = validationException.getAllMessages();

		for (String message : allMessages) {

			System.out.println("%%%%" + message);

			if (message.contains("not found")) {

				//String propertyName = message.substring((message.indexOf("[") + 1), message.indexOf("]"));
				missingRequiredProperties.add(message);

			} else if (message.contains("is required")) {

				//String propertyName = message.substring((message.indexOf("[") + 1), message.indexOf("]"));
				missingDependencies.add(message);

			} else if (message.contains("extraneous key")) {

				//String propertyName = message.substring((message.indexOf("[") + 1), message.indexOf("]"));
				foundAdditionalProperties.add(message);

			} else if (message.contains("expected") && !message.contains("expected minimum item count")) {

				if (ignoreNull) {

					/* message will only get added if does not contain 'Null' */
					if (!message.contains("Null")) {
						typeMisMatch.add(message);
					}

				} else {
					typeMisMatch.add(message);
				}

			} else if (ignoreNull && message.contains("null is not a valid enum value")) {
				//skip : need to ignore this error and pass the validation
				

			} else {

				if (message.contains("expected minimum item count: 1, found: 0")) {
					message = message.replace("expected minimum item count: 1, found: 0", "item is an empty Array[]");
					unknown.add(message);
				} else {
					unknown.add(message);
				}

			}

		}

		/* reverting to default ignore status */
		ignoreNull = false;

		/* Logging Missing Required Properties */
		if (missingRequiredProperties.size() > 0) {

			if (missingRequiredProperties.size() > 1) {
				Reporter.addStepLog("<strong>Missing Required Properties:</strong>");

			} else {
				Reporter.addStepLog("<strong>Missing Required Property:</strong>");
			}

			missingRequiredProperties.forEach(property -> Reporter.addStepLog(property));
		}

		/* Logging Missing Dependent Properties */
		if (missingDependencies.size() > 0) {

			if (missingDependencies.size() > 1) {
				Reporter.addStepLog("<strong>Missing Dependent Properties:</strong>");

			} else {
				Reporter.addStepLog("<strong>Missing Dependent Property:</strong>");
			}

			missingDependencies.forEach(property -> Reporter.addStepLog(property));
		}

		/* Logging Found Addition Properties */
		if (foundAdditionalProperties.size() > 0) {

			if (foundAdditionalProperties.size() > 1) {
				Reporter.addStepLog("<strong>Found Additional Properties:</strong>");

			} else {
				Reporter.addStepLog("<strong>Found Additional Property:</strong>");
			}

			foundAdditionalProperties.forEach(property -> Reporter.addStepLog(property));
		}

		/* Logging Type MisMatch */
		if (typeMisMatch.size() > 0) {

			Reporter.addStepLog("<strong>Type MisMatch:</strong>");

			typeMisMatch.forEach(property -> Reporter.addStepLog(property));
		}

		/* Logging unknown message */
		if (unknown.size() > 0) {

			Reporter.addStepLog("<strong>Other Errors:</strong>");
			unknown.forEach(property -> Reporter.addStepLog(property));
		}

		/* marking scenario as failed */
		if (missingRequiredProperties.size() > 0 || missingDependencies.size() > 0
				|| foundAdditionalProperties.size() > 0 || typeMisMatch.size() > 0 || unknown.size() > 0) {

			throw new AssertionError();

		}

	}

	/**************************/
	// @And("^user have response json schema \"([^\"]*)\" available$")
	// public void user_have_response_json_schema_something_available(String
	// jsonSchemaFileName) {
	@And("^user have response json schema \"([^\"]*)\" available for type \"([^\"]*)\"$")
	public void user_have_response_json_schema_something_available_for_type_something(String jsonSchemaFileName,
			String objectType) throws Throwable {

		JsonSchemaValidationStepDefs.objectType = objectType;

		String userDir = System.getProperty("user.dir");

		String filepath = FileManager.getFileManagerObj().searchFile(userDir, jsonSchemaFileName);
		String jsonSchema = FileManager.getFileManagerObj().readFile(filepath);

		definition = new JSONObject(jsonSchema);

	}

	@When("^user perform json validation with \"([^\"]*)\" options$")
	public void user_perform_json_validation_with_something_options(String options) {

		List<String> optionList = Arrays.asList(options.split(","));

		Set<SchemaValidationModes> schemaValidationModes = new HashSet<SchemaValidationModes>();

		if (!optionList.isEmpty()) {
			if (options.contains("ALL_PROPERTIES_REQUIRED")) {
				schemaValidationModes.add(SchemaValidationModes.ALL_PROPERTIES_REQUIRED);
			}
			if (options.contains("NO_ADDITIONAL_PROPERTIES")) {
				schemaValidationModes.add(SchemaValidationModes.NO_ADDITIONAL_PROPERTIES);
			}

			if (options.contains("IGNORE_NULL_VALUES")) {
				schemaValidationModes.add(SchemaValidationModes.IGNORE_NULL_VALUES);
				ignoreNull = true;
			}

		}

		definition = createJsonSchema(definition.toString(), schemaValidationModes);

		String fileName = objCommnoAPISteps.putJsonInFile(definition.toString(), "jsonSchema");
		objCommnoAPISteps.addFileToReport("Click on link to see json schema !!", fileName);
	}

}
