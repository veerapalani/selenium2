package qa.framework.desktop;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.windows.WindowsDriver;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.LoggerHelper;

public class DesktopDriverManager {
	
	private static boolean desktop=false;
	private static String host=null;
	private static String port=null;
	private static WindowsDriver<?> driver;
	
	private static boolean flag=false;
	
	private static Process process = null;
	
	private static Logger log = LoggerHelper.getLogger(DesktopDriverManager.class);
	
	/*configuring switch 'desktop' setting*/
	private static synchronized void configSwitchDesktop() {
		/* reading from cmd line */
		String cmdSwitchDesktop = System.getProperty("desktop");

		if (cmdSwitchDesktop!=null) {
			desktop = Boolean.parseBoolean(cmdSwitchDesktop);
		} else {
			
			/* reading from property file */
			desktop = Boolean.parseBoolean(GlobalVariables.configProp.getProperty("desktop"));
		}
	}

	/*configuring 'host' setting*/
	private static synchronized void configHost() {
		/* reading from cmd line */
		String cmdHostName = System.getProperty("winappdriverHost");

		if (cmdHostName!=null) {
			host = cmdHostName;
		} else {
			
			/* reading from property file */
			host = GlobalVariables.configProp.getProperty("winappdriverHost");
		}
	}

	/*configuring 'port' setting*/
	private static synchronized void configPort() {
		/* reading from cmd line */
		String cmdPort = System.getProperty("winappdriverPort");

		if (cmdPort!=null) {
			port = cmdPort;
		} else {
			
			/* reading from property file */
			port = GlobalVariables.configProp.getProperty("winappdriverPort");
		}
	}

	/**
	 * Configuring all the pre-condition required to start winappdriver
	 * @author BathriYo
	 */
	public static void config() {
		/*1st: configuring switch button for Desktop app*/
		configSwitchDesktop();
		
		/*checking if switch button is enabled or not*/
		if(desktop==true) {
			/*2nd: Config host*/
			configHost();
			/*3rd: Config port*/
			configPort();
			
			/*4th: starting WinAppDriver*/
			startDriver(host, port);
		}
	}
	
	/**
	 * Starts WinAppDriver server
	 * 
	 * @author BathriYo
	 * @param host : restricted to localhost
	 * @param port : default i.e. 4723 or any open port number
	 */
	private static void startDriver(String host, String port) {
		String filePath = "C:\\Program Files (x86)\\Windows Application Driver";
		// List<String> cmds = Arrays.asList("cmd.exe", "/C", "start",
		// "WinAppDriver.exe","10.101.0.84","4724");

		List<String> cmds;
		if (port.equalsIgnoreCase("default")) {
			cmds = Arrays.asList("cmd.exe", "/C", "start", "WinAppDriver.exe", "4723");
			DesktopDriverManager.port="4723";
		} else {
			cmds = Arrays.asList("cmd.exe", "/C", "start", "WinAppDriver.exe", port);
			DesktopDriverManager.port=port;
		}

		ProcessBuilder builder = new ProcessBuilder(cmds);
		builder.directory(new File(filePath));
		try {
			process = builder.start();
		} catch (IOException e) {

			e.printStackTrace();

			log.info("!!! WinAppDrier failed to Start !!!");
			log.error(e);
			Assert.fail("!!! WinAppDrier failed to Start !!!");

		}

	}

	/**
	 * Stops WinAppDriver server
	 * 
	 * @author BathriYo
	 */
	public static void stopDriver() {
		process.destroyForcibly();
		
		try {
			Runtime.getRuntime().exec("taskkill /F /IM WinAppDriver.exe");
		} catch (IOException e) {
			
			e.printStackTrace();
			log.info("!!! WinAppDriver failed to Stop !!!");
			log.error(e);
			
		}
		
	}
	
	/**
	 * Starting Application
	 * 
	 * @author BathirYo
	 * @param exePath
	 */
	public static int startApplication(String exePath) {
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("app", exePath);
		capabilities.setCapability("platformName", "Windows");
		capabilities.setCapability("deviceName", "WindowsPC");

		
		try {
			driver = new WindowsDriver(new URL("http://"+host+":"+port), capabilities);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			return 1;
		} catch (MalformedURLException e) {
			
			log.info("!!! Application failed to Start !!! "+exePath);
			log.error(e);
			e.printStackTrace();
			return 0;
		}

	}
	
	/**
	 * Close Application
	 * 
	 * @author BathriYo
	 */
	public static void stopApplication() {
		try {
			
			driver.closeApp();
			
		}catch(NoSuchWindowException e) {
			log.info("Window seem to be closed already !!");
		}
		
	}
	
	/**
	 * @author BathriYo	
	 * @return WindowsDriver<?>
	 */
	public static WindowsDriver<?> getDriver() {
		return driver;
	}

	public static boolean getFlag() {
		return flag;
	}

	public static void setFlag(boolean flag) {
		DesktopDriverManager.flag = flag;
	}
	
	public static boolean getDesktopSwitch() {
		return desktop;
	}

}
