package qa.framework.desktop;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;



import qa.framework.dbutils.DBRowTO;
import qa.framework.report.Report;
import qa.framework.utils.Action;
import qa.framework.utils.ExceptionHandler;
import qa.framework.webui.browsers.WebDriverManager;
import qa.framework.webui.element.Element;

public class DesktopActions {
	
	List<DBRowTO> lstElement;
	
	public DesktopActions(List<DBRowTO> lstElement) {
		this.lstElement = lstElement;

	}

	public final WebElement getElement(String key) {
		WebElement webElement = null;
		String valueType = "undefined";
		String value = "undefined";

		String status = "FAIL";
		try {

			valueType = Action.getValueType(key, lstElement);
			value = Action.getValue(key, lstElement);

			Element element = new Element(null);
			webElement = element.getElement(valueType, value);
			status = "PASS";

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Element");
			Report.printKey(key);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}

		return webElement;

	}
	
	public final List<WebElement> getElements(String key) {
		List<WebElement> listWebElement = null;
		String value = "undefined";
		String valueType = "undefined";
		String status = "FAIL";
		try {
			Element element = new Element(null);
			value = Action.getValue(key, lstElement);
			valueType = Action.getValueType(key, lstElement);
			listWebElement = element.getElements(valueType, value);
			status = "PASS";
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Get Elements");
			Report.printKey(key);
			Report.printValue(value);
			Report.printValueType(valueType);
			Report.printStatus(status);
		}

		return listWebElement;
	}
	
	
	/**
	 * @author BathriYo performs Click
	 * 
	 * @param element
	 */
	public final void click(WebElement element) {

		String status = "FAIL";
		try {

			element.click();
			status = "PASS";

			//takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Click");
			Report.printStatus(status);
		}

	}

	/**
	 * Clear
	 * 
	 * @param element
	 */
	public final void clear(WebElement element) {
		String status = "FAIL";
		try {
			element.clear();
			status = "PASS";
			//takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("Clear");
			Report.printStatus(status);
		}
	}

	/**
	 * SendKeys
	 * 
	 * @param element
	 * @param value
	 */
	public final void sendKeys(WebElement element, String value) {
		String status = "FAIL";
		try {
			element.sendKeys(value);
			status = "PASS";
			//takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("sendKeys");
			Report.printValue(value);
			Report.printStatus(status);
		}
	}
	
	public final void sendKeys(WebElement element, Keys keys) {
		String status = "FAIL";
		try {
			element.sendKeys(keys);
			status = "PASS";
			//takeScrCapPerAction();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			Report.printOperation("sendKeys");
			Report.printValue(keys.toString());
			Report.printStatus(status);
		}
	}
	

	
}
