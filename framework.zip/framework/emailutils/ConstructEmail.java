package qa.framework.emailutils;

import javax.mail.Multipart;

public interface ConstructEmail {
	
	ConstructEmail config(String host, int port, String from, String encodedPwd);
	ConstructEmail from(String from);
	ConstructEmail tos(String tos);
	ConstructEmail subject(String subject);
	ConstructEmail body(Multipart multipart, String body);
	ConstructEmail attachment(Multipart multipart, String filePath);
	ConstructEmail sendMail(Multipart multipart);
	

}
