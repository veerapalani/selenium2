package qa.framework.common.stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import qa.framework.desktop.DesktopDriverManager;
import qa.framework.utils.PropertyFileUtils;

public class CommonDesktopAppStepDefs {

	@Given("^user start given \"([^\"]*)\" application$")
	public void user_start_given_something_application(String appName) throws Throwable {

		PropertyFileUtils appPro = new PropertyFileUtils("application.properties");
		String exePath = appPro.getProperty(appName);

		int status = DesktopDriverManager.startApplication(exePath);
		if (status == 1) {
			DesktopDriverManager.setFlag(true);
		} else {
			DesktopDriverManager.setFlag(false);
		}

	}

	@And("^user stop given application$")
	public void user_stop_given_application() throws Throwable {

		DesktopDriverManager.stopApplication();

		DesktopDriverManager.setFlag(false);
	}

}
