package qa.framework.common.stepdefs;

import io.cucumber.java.en.And;
import qa.framework.dbutils.SQLDriver;
import qa.framework.mainframe.LaunchMainframeTerminal;
import qa.framework.utils.ExceptionHandler;
import qa.framework.webui.browsers.WebDriverManager;

public class CommonStepDefs {

	public static ThreadLocal<Boolean> threadLocal_flagUI =  new ThreadLocal<Boolean>();
	public static ThreadLocal<Boolean> threadLocal_flagMainframe =  new ThreadLocal<Boolean>();
	
	
	@And("^user launch \"([^\"]*)\" brower$")
    public void user_launch_something_brower(String browser){
        
		threadLocal_flagUI.set(true);
		WebDriverManager.setBrowser(browser.toLowerCase().trim());
		WebDriverManager.startDriver();
		
    }

    @And("^user closes the brower$")
    public void user_closes_the_brower(){
    	
    	threadLocal_flagUI.set(false);
    	WebDriverManager.quitDriver();
    }
    
    
    @And("^user launch mainframe emulator$")
    public void user_launch_mainframe_emulator(){
    	threadLocal_flagMainframe.set(true);
    	LaunchMainframeTerminal.launchTerminalAndSetWindow();
    }

    @And("^user closes the mainframe emulator$")
    public void user_closes_the_mainframe_emulator(){
    	
    	/* closing Mainframe terminal in case of mainframe application */
		if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true") && threadLocal_flagMainframe.get()==true){//flagMainframe == true) {

			/* reverting back flagMainframe value */
			threadLocal_flagMainframe.set(false);//flagMainframe = false;
			try {
				/* Disconnecting Terminal */
				LaunchMainframeTerminal.disconnect();

				/* closing terminal window after disconnect */
				LaunchMainframeTerminal.closeTerminalWindow();

			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}
        
    }
    
    @And("^user load test data for \"([^\"]*)\" feature$")
    public void user_load_test_data_for_something_feature(String featuresNames) throws Throwable {
    	String[] features = featuresNames.split(",");
    	String columns="";
    	
    	for(String feature: features) {
    		
    		columns="'"+feature+"'"+",";
    	}
    	
    	columns = columns.substring(0,columns.length()-1);
    	SQLDriver.TTestData.set(SQLDriver.getData(columns));
    }
	
}
