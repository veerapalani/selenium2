package qa.framework.assertions;

import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import qa.framework.utils.Reporter;

public class AssertLogger {

	private static ThreadLocal<SoftAssert> TsoftAssert = new ThreadLocal<SoftAssert>();

	/**
	 * Assert Equals
	 * 
	 * @author bathriyo
	 * @param actualValue   : Object
	 * @param expectedValue : Object
	 * @param msgOnFailure  : String
	 */
	public static synchronized void assertEquals(Object actualValue, Object expectedValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : Equals</em>");
		Reporter.addStepLog("<strong>Actual Value   : </strong>" + actualValue);
		Reporter.addStepLog("<strong>Expected Value : </strong>" + expectedValue);

		Assert.assertEquals(actualValue, expectedValue, msgOnFailure);

	}

	/**
	 * Assert Not Equals
	 * 
	 * @author bathriyo
	 * @param actualValue   : Object
	 * @param expectedValue : Object
	 * @param msgOnFailure  : String
	 */
	public static synchronized void assertNotEquals(Object actualValue, Object expectedValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : Not Equals</em>");
		Reporter.addStepLog("<strong>Actual Value   : </strong>" + actualValue);
		Reporter.addStepLog("<strong>Expected Value : </strong>" + expectedValue);

		Assert.assertNotEquals(actualValue, expectedValue, msgOnFailure);

	}

	/**
	 * Assert Not Null
	 * 
	 * @author bathriyo
	 * @param actualValue  : Object
	 * @param msgOnFailure : String
	 */
	public static synchronized void assertNotNull(Object actualValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks: Not Null</em>");

		if (actualValue != null) {
			Reporter.addStepLog("<strong><font color=#9ACD32>Value is Not Null: </font></strong>" + actualValue);
		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>Value is Null: </font></strong>" + actualValue);
		}

		Assert.assertNotNull(actualValue, msgOnFailure);

	}

	/**
	 * Assert Null
	 * 
	 * @author bathriyo
	 * @param actualValue  : Object
	 * @param msgOnFailure : String
	 */
	public static synchronized void assertNull(Object actualValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : Null</em>");

		if (actualValue == null) {
			Reporter.addStepLog("<strong><font color=#9ACD32>Value is Null: </font></strong>" + actualValue);
		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>Value is Not Null: </font></strong>" + actualValue);
		}

		Assert.assertNull(actualValue, msgOnFailure);

	}

	/**
	 * Assert True
	 * 
	 * @author bathriyo
	 * @param actualValue  : boolean
	 * @param msgOnFailure : String
	 */
	public static synchronized void assertTrue(boolean actualValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : True</em>");

		if (actualValue == true) {
			Reporter.addStepLog("<strong><font color=#9ACD32>Value is True: </font></strong>" + actualValue);
		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>Value is Not True: </font></strong>" + actualValue);
		}

		Assert.assertTrue(actualValue, msgOnFailure);

	}
	
	/**
	 * Assert False
	 * 
	 * @author bathriyo
	 * @param actualValue  : boolean
	 * @param msgOnFailure : String
	 */
	public static synchronized void assertFalse(boolean actualValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : False</em>");

		if (actualValue == false) {
			Reporter.addStepLog("<strong><font color=#9ACD32>Value is false: </font></strong>" + actualValue);
		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>Value is Not false: </font></strong>" + actualValue);
		}

		Assert.assertFalse(actualValue, msgOnFailure);

	}
	

	/**
	 * Start Soft Assert
	 * 
	 * @author bathriyo
	 */
	public static void multiAssertStart() {

		SoftAssert softAssert = new SoftAssert();

		TsoftAssert.set(softAssert);
	}

	/**
	 * Assert all
	 * 
	 * @author bathriyo
	 */
	public static void multiAssertEnd() {
		TsoftAssert.get().assertAll();
	}

	/**
	 * Soft Assert Equals
	 * 
	 * @author bathriyo
	 * @param actualValue   : Object
	 * @param expectedValue : Object
	 * @param msgOnFailure  : String
	 */
	public static void multiAssertEquals(Object actualValue, Object expectedValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : Equals</em>");
		Reporter.addStepLog("<strong>Actual Value   : </strong>" + actualValue);
		Reporter.addStepLog("<strong>Expected Value : </strong>" + expectedValue);

		TsoftAssert.get().assertEquals(actualValue, expectedValue, msgOnFailure);

	}

	/**
	 * Soft Assert Not Equals
	 * 
	 * @author bathriyo
	 * @param actualValue   : Object
	 * @param expectedValue : Object
	 * @param msgOnFailure  : String
	 */
	public static void multiAssertNotEquals(Object actualValue, Object expectedValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : Not Equals</em>");
		Reporter.addStepLog("<strong>Actual Value   : </strong>" + actualValue);
		Reporter.addStepLog("<strong>Expected Value : </strong>" + expectedValue);

		TsoftAssert.get().assertNotEquals(actualValue, expectedValue, msgOnFailure);

	}

	/**
	 * Soft Assert Not Null
	 * 
	 * @author bathriyo
	 * @param actualValue  : Object
	 * @param msgOnFailure : String
	 */
	public static synchronized void multiAssertNotNull(Object actualValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : Not Null</em>");
		if (actualValue != null) {
			Reporter.addStepLog("<strong><font color=#9ACD32>Value is Not Null: </font></strong>" + actualValue);
		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>Value is Null: </font></strong>" + actualValue);
		}

		TsoftAssert.get().assertNotNull(actualValue, msgOnFailure);

	}

	/**
	 * Soft Assert Null
	 * 
	 * @author bathriyo
	 * @param actualValue  : Object
	 * @param msgOnFailure : String
	 */
	public static synchronized void multiAssertNull(Object actualValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : Null</em>");

		if (actualValue == null) {
			Reporter.addStepLog("<strong><font color=#9ACD32>Value is Null: </font></strong>" + actualValue);
		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>Value is Not Null: </font></strong>" + actualValue);
		}

		TsoftAssert.get().assertNull(actualValue, msgOnFailure);

	}

	
	
	/**
	 * Assert True
	 * 
	 * @author bathriyo
	 * @param actualValue  : boolean
	 * @param msgOnFailure : String
	 */
	public static void multiAssertTrue(boolean actualValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : True</em>");

		if (actualValue == true) {
			Reporter.addStepLog("<strong><font color=#9ACD32>Value is True: </font></strong>" + actualValue);
		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>Value is Not True: </font></strong>" + actualValue);
		}

		TsoftAssert.get().assertTrue(actualValue, msgOnFailure);

	}
	
	/**
	 * Assert False
	 * 
	 * @author bathriyo
	 * @param actualValue  : boolean
	 * @param msgOnFailure : String
	 */
	public static void multiAssertFalse(boolean actualValue, String msgOnFailure) {

		Reporter.addStepLog("<br><em>Checks         : False</em>");

		if (actualValue == false) {
			Reporter.addStepLog("<strong><font color=#9ACD32>Value is false: </font></strong>" + actualValue);
		} else {
			Reporter.addStepLog("<strong><font color=#DC143C>Value is Not false: </font></strong>" + actualValue);
		}

		TsoftAssert.get().assertFalse(actualValue, msgOnFailure);

	}

	
}
