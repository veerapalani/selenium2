package qa.framework.dbutils;

/**
 * 
 * @author BathriYo
 *
 */
public enum DocumentManagerType {
	JSONDocumentManager,XMLDocumentManager;
}
