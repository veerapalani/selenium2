package qa.framework.dbutils;

import static com.mongodb.client.model.Filters.eq;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoIterable;

/**
 * Read Data from MongoDB <br>
 * <b>Example</b> <br>
 * String host="10.101.0.84";//"localhost"; <br> 
 * int port=27018;<br> 
 * String db="pm";<br>
 * String collection="transactions";<br>
 * <br>
 * MongoDBUtils objMongoDB = new MongoDBUtils();<br>
 * 
 * //First: Connect to DB<br> 
 * objMongoDB.connect(host, port, db); <br>
 * //Second: Get Collection<br> 
 * MongoCollection<Document> objCollection =
 * objMongoDB.getCollection(collection);
 * <br>
 * //Third: Apply Filter <br>
 * List<String> records = objMongoDB.getRecord(objCollection, eq("Id.MSD_ID","5CTNJW1"));<br>
 * 
 * System.out.println("Size: "+records);<br>
 * 
 * //Fourth: Disconnect <br>
 * objMongoDB.disconnect();<br>
 * 
 * <b>Reference</b>
 * <br>
 * https://mongodb.github.io/mongo-java-driver/3.4/driver/tutorials/perform-read-operations/
 * 
 * @author bathriyo
 *
 */
public class MongoDBUtils {

	private MongoClient mongoClient;
	private MongoDatabase dataBase;
	// private MongoCollection<Document> collection;

	public void connect(String host, int port, String db) {

		String url = "mongodb://" + host + ":" + port;

		mongoClient = new MongoClient(new MongoClientURI(url));
		dataBase = mongoClient.getDatabase(db);

		MongoIterable<String> lstNames = dataBase.listCollectionNames();
		for (String name : lstNames) {
			System.out.println(name);
		}

	}

	public MongoCollection<Document> getCollection(String collection) {

		return dataBase.getCollection(collection);
	}

	/**
	 * Finds Record in Collection <br>
	 * Bson attribute comes from Filters. Apply filter as describe below
	 * 
	 * <ul>
	 * <li>static import: import static com.mongodb.client.model.Filters.*;</li>
	 * <li>use Filters method as show below:</li>
	 * <li>and(gte("stars", 2), lt("stars", 5), eq("categories", "Bakery"))</li>
	 * <li>gte stands for 'Greater Then Equals TO'</li>
	 * <li>lt stands for 'Less Than' etc.</li>
	 * </ul>
	 * 
	 * @author bathriyo
	 * @param collection : MongoCollection<Document>
	 * @param bson       : Bson
	 * @return List<String>
	 */
	public List<String> getRecord(MongoCollection<Document> collection, Bson bson) {

		List<String> record = new ArrayList<String>();

		MongoCursor<Document> iterator = collection.find(bson).iterator();

		while (iterator.hasNext()) {
			record.add(iterator.next().toJson());
		}

		return record;

	}

	public void disconnect() {
		if (mongoClient != null) {
			mongoClient.close();
		}
	}

//	Block<Document> printBlock = new Block<Document>() {
//    @Override
//    public void apply(final Document document) {
//        System.out.println(document.toJson());
//    }
//};

}
