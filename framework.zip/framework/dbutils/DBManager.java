package qa.framework.dbutils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.marklogic.client.DatabaseClient;
import com.marklogic.client.DatabaseClientFactory;
import com.marklogic.client.DatabaseClientFactory.BasicAuthContext;
import com.marklogic.client.DatabaseClientFactory.DigestAuthContext;
import com.marklogic.client.io.StringHandle;

import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.Reporter;

/**
 * 
 * @author BathriYo
 *
 */
public class DBManager {

	
	/* PostGre DB */
	private static Connection conn;

	/* Mark logic */
	static DatabaseClient client = null;

	/* Relational DB */
	private Connection connection;
	private ResultSet resultSet;

	/**
	 * Public Static utility that returns DatabaseClient based on authentication
	 * 
	 * @author BathriYo
	 * @param host
	 * @param port
	 * @param user
	 * @param password
	 * @param database
	 * @param authContext
	 * @return DatabaseClient
	 */
	public static DatabaseClient configClientBasedOnAuth(String host, int port, String user, String password,
			String database, AuthContext authContext) {

		if (authContext == AuthContext.BasicAuthContext) {

			BasicAuthContext basicAuthContext = new DatabaseClientFactory.BasicAuthContext(user, password);

			client = DatabaseClientFactory.newClient(host, port, database, basicAuthContext);

		} else if (authContext == AuthContext.DigestAuthContext) {

			DigestAuthContext digestAuthContext = new DatabaseClientFactory.DigestAuthContext(user, password);

			client = DatabaseClientFactory.newClient(host, port, database, digestAuthContext);

		} else if (authContext == AuthContext.KerberosAuthContext) {
			/* NOT IMPLEMENT YET */
		}
		return client;
	}

	/**
	 * Public static utility to search the document based on Document type
	 * 
	 * @param docMrgType
	 * @param docPath
	 * @return String
	 */
	public static String searchUsingDocumentManager(DocumentManagerType docMrgType, String docPath) {
		if (docMrgType == DocumentManagerType.JSONDocumentManager) {

			return client.newJSONDocumentManager().read(docPath, new StringHandle()).get();

		} else if (docMrgType == DocumentManagerType.XMLDocumentManager) {

			return client.newXMLDocumentManager().read(docPath, new StringHandle()).get();
		}

		return null;

	}

	/**
	 * Mandatory to use
	 * 
	 * Public static utility to release the client
	 * 
	 * @author BathriYo
	 * 
	 */
	public static void releaseClient() {
		client.release();
	}

	/* Start-PostgreDB */

	/**
	 * Step 1/3: Connect to DB
	 * 
	 * @author BathriYo
	 * @param uri
	 * @param port
	 * @param databaseName
	 * @param username
	 * @param password
	 */
	@Deprecated
	public static void openPostgreDBConnection(String uri, String port, String databaseName, String username,
			String password) {

		String connectionString = "jdbc:postgresql://" + uri + ":" + port + "/" + databaseName;

		try {

			conn = DriverManager.getConnection(connectionString, username, password);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * Step 2/3: Execute Selection Query
	 * 
	 * @author BathriYo
	 * @param sqlQuery
	 * @return ResultSet
	 */
	@Deprecated
	public static ResultSet executeSelectQuery(String sqlQuery) {
		try {

			return conn.createStatement().executeQuery(sqlQuery);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return null;
	}

	/**
	 * Step 2/3: Execute Selection Query To get Scrollable Result Set
	 * 
	 * @author ChandregowdaDi
	 * @param sqlQuery
	 * @return ResultSet
	 */
	@Deprecated
	public static ResultSet executeSelectQueryForScrollableResultSet(String sqlQuery) {
		try {

			return conn.prepareStatement(sqlQuery, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE)
					.executeQuery();

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return null;
	}

	/**
	 * Step 3/3: Close connection created in Step 1
	 * 
	 * @author BathriYo
	 */
	@Deprecated
	public static void closeConnection() {
		try {
			conn.close();
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/* End-PostgreDB */

	/**
	 * Step 1/3: Connection to DB
	 * 
	 * @author bathriyo
	 * @param dbType       : Enum
	 * @param uri          : String
	 * @param port         : Integer
	 * @param databaseName : String
	 * @param username     : String
	 * @param password     : String
	 */
	public void connected(RelationalDBType dbType, String host, int port, String databaseName, String username,
			String password) {

		// "jdbc:sqlserver://WPIDVWFXLDB02\\SQL2016TEST;DatabaseName=7_5_TEST_24TRADING;user=development;password=tradingsa";
		String connectionString = null;
		;

		switch (dbType) {
		case POSTGRE:
		case REDSHIFT: {
			connectionString = "jdbc:postgresql://" + host + ":" + port + "/" + databaseName + "?" + "user=" + username
					+ "&" + "password=" + password;
			break;
		}
		case SQLSERVER: {

			/* notice PORT is not here. sometimes sql server does not need port */
			connectionString = "jdbc:sqlserver://" + host + ";" + "DatabaseName=" + databaseName + ";" + "user="
					+ username + ";" + "password=" + password;
			break;
		}
		case MYSQL: {
			connectionString = "jdbc:mysql://" + host + ":" + port + "/" + databaseName + "?" + "user=" + username + "&"
					+ "password=" + password;
			break;
		}
		case ORACLE_THIN: {

			/* jdbc:oracle:<driver_type>:<user>/<password>@<host>:<port>:<db_name> */
			connectionString = "jdbc:oracle:thin:" + username + "/" + password + "@" + host + ":" + port + ":"
					+ databaseName;
			break;
		}
		case ORACLE_OCI: {

			/* jdbc:oracle:<driver_type>:<user>/<password>@<host>:<port>:<db_name> */
			connectionString = "jdbc:oracle:oci:" + username + "/" + password + "@" + host + ":" + port + ":"
					+ databaseName;
		}
		case DB2: {
			
			/*
			 * "jdbc:db2://<host>:<port>/<database_name>:"
			 * +"user=<username>;password=<password>;"
			 */
			connectionString = "jdbc:db2://" + host + ":" + port + "/" + databaseName + ":" + "user=" + username + ";"
					+ "password=" + password + ";";
			break;
		}
		case IRIS: {
			/*
			 * jdbc:IRIS://<host>:<port>/<namespace>/<options>?username=<string1>&password=<
			 * string2>
			 */
			connectionString = "jdbc:IRIS://" + host + ":" + port + "/" + databaseName + "?" + "username=" + username
					+ "&" + "password=" + password;
			break;
		}
		default: {

			Reporter.addStepLog(
					"<strong><font color=#DC143C>!!! INCORRET DB Type PROVIDED !!! </font></strong>" + dbType);

			Assert.fail("!!! INCORRECT DB TYPE PROVIDED !!!");
		}

		}

		try {

			this.connection = DriverManager.getConnection(connectionString);

		} catch (Exception ex) {
			ExceptionHandler.handleException(ex);
		}

	}

	/**
	 * Step 2/3: execute Select query
	 * 
	 * @author bathriyo
	 * @param sqlQuery : String
	 * @return ResultSet
	 */
	public ResultSet selectQuery(String sqlQuery) {
		try {

			resultSet = this.connection.createStatement().executeQuery(sqlQuery);
			return resultSet;

		} catch (Exception ex) {
			ExceptionHandler.handleException(ex);
		}

		return null;
	}

	/**
	 * Step 2/3: Execute Update query
	 * 
	 * @author Firoz Shaikh
	 * @param sqlQuery : String
	 * @return ResultSet
	 */
	public int executeQuery(String sqlQuery) {
		try {

			int result = this.connection.createStatement().executeUpdate(sqlQuery);
			return result;

		} catch (Exception ex) {
			ExceptionHandler.handleException(ex);
		}

		return 0;
	}

	/**
	 * Step 2/3: Execute Selection Query To get Scrollable Result Set
	 * 
	 * @author ChandregowdaDi
	 * @param sqlQuery
	 * @return ResultSet
	 */
	public ResultSet selectQueryForScrollableResultSet(String sqlQuery) {
		try {

			return this.connection
					.prepareStatement(sqlQuery, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)
					.executeQuery();

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return null;
	}

	/**
	 * Get Column Count
	 * 
	 * @author bathriyo
	 * @return : Integer
	 */
	public int getColumnCount() {
		try {

			return this.resultSet.getMetaData().getColumnCount();

		} catch (SQLException e) {

			ExceptionHandler.handleException(e);
		}

		return -1;
	}

	/**
	 * Get Column names as Set
	 * 
	 * @author bathriyo
	 * @return Set<String>
	 */
	public Set<String> getColumnNames() {

		Set<String> columnName = new HashSet<String>();

		int columnCount = getColumnCount();

		for (int index = 1; index <= columnCount; index++) {

			try {

				columnName.add(resultSet.getMetaData().getColumnName(index));

			} catch (SQLException e) {

				ExceptionHandler.handleException(e);
			}
		}

		return columnName;
	}
	
	public String coulumValue(String columnName) {
		String columnValue=null;
		try {
			columnValue = resultSet.getString(columnName).toString();
		} catch (Exception e) {
			columnValue = null;
		}
		return columnValue;
	}

	/**
	 * Parsing Result Set and putting it into List of Map for ease access
	 * 
	 * @author bathriyo
	 * @return List<Map<String,String>>
	 */
	public List<Map<String, String>> parseResultSet() {

		ResultSet resultSet = this.resultSet;

		int columnCount = getColumnCount();
		List<Map<String, String>> parsedResultSet = new ArrayList<Map<String, String>>();

		try {

			while (resultSet.next()) {

				Map<String, String> map = new HashMap<String, String>();

				for (int index = 1; index <= columnCount; index++) {

					String columnTypeName = resultSet.getMetaData().getColumnTypeName(index).toLowerCase();
					String columnName = resultSet.getMetaData().getColumnName(index);
					String columnValue = null;

					switch (columnTypeName) {

					case "char":
					case "varchar":
					case "nvarchar": {
						/*
						 * toString() is add to handle null value from DB. For null value toString()
						 * will throw NullPointerException
						 */
						try {
							columnValue = resultSet.getString(columnName).toString();
						} catch (Exception e) {
							columnValue = null;
						}


						break;
					}

					case "numeric":
					case "double":
					case "integer":
					case "float": {

						/* 2 is for numeric value from db */
						try {
						columnValue = resultSet.getDouble(columnName) + "";
						} catch (Exception e) {
							columnValue = null;
						}
						break;

					}
					case "serial":
					case "int4":
					case "int8":
					case "int": {
						try {
						columnValue = resultSet.getInt(columnName) + "";
						} catch (Exception e) {
							columnValue = null;
						}
						break;

					}

					case "date": {

						/* 91 is for data value from db */
						try {
						columnValue = resultSet.getDate(columnName).toString();
					} catch (Exception e) {
						columnValue = null;
					}
						break;

					}

					case "time": {

						/* 93 is for time value from db */
						try {
							columnValue = resultSet.getTime(columnName).toString();
						} catch (Exception e) {
							columnValue = null;
						}
						break;

					}
					case "timestamp": {
					
						try {
							columnValue = resultSet.getTimestamp(columnName).toString();
						} catch (Exception e) {
							columnValue = null;
						}
					
						break;

					}
					case "datetime": {
						
						try {
							columnValue = resultSet.getDate(columnName).toString();
						} catch (NullPointerException e) {
							columnValue = null;
						}

		
						break;
					}
					case "tinyint":
					case "bool":
					case "boolean": {

						/* -7 is for time stamp value from db */
						try {
							columnValue = resultSet.getBoolean(columnName) + "";
						} catch (NullPointerException e) {
							columnValue = null;
						}
						break;

					}
					default: {
						Assert.fail("Column Type in NOT available in switch statement: " + columnTypeName);
					}

					}// switch - end

					map.put(columnName, columnValue);

				} // for loop end
				parsedResultSet.add(map);

			} // while loop end
		} catch (Exception ex) {
			ExceptionHandler.handleException(ex);
		}

		return parsedResultSet;

	}

	/**
	 * Step 3/3: close DB connection
	 * 
	 * @author bathriyo
	 */
	public void disconnect() {
		try {
			this.connection.close();
		} catch (Exception ex) {
			ExceptionHandler.handleException(ex);
		}

	}

}

/*
 * @athor: Bathri Yogesh
 *
 * !!! DO NOT DELETE !!!
 * 
 * Raw code for reference purpose.
 * 
 * 
 * @Test public void testMarkLogin() { //
 * https://developer.marklogic.com/try/java/page3 //
 * https://www.thejavaprogrammer.com/convert-json-to-xml-or-xml-to-json-in-java/
 * 
 * DigestAuthContext digestAuthContext = new
 * DatabaseClientFactory.DigestAuthContext("challaa", "F3fkbJPe3Gv8");
 * 
 * DatabaseClient client = DatabaseClientFactory.newClient("10.26.24.112", 8000,
 * "nina-wmp-content", digestAuthContext);
 * 
 * 
 * JSONDocumentManager docMgr = client.newJSONDocumentManager();
 * 
 * 
 * String doc = docMgr .read("/UNICORN/0000000037/ClientInfo/BasicInfo/Latest",
 * new StringHandle().withFormat(Format.XML)) .get();
 * 
 * System.out.println(doc);
 * 
 * client.release(); } }
 * 
 */
