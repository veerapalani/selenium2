package qa.framework.dbutils;

public enum AuthContext {
	BasicAuthContext, DigestAuthContext , KerberosAuthContext;
}
