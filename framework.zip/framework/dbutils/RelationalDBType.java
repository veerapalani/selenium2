package qa.framework.dbutils;

public enum RelationalDBType {
	POSTGRE, SQLSERVER, MYSQL,ORACLE_THIN,ORACLE_OCI,DB2,REDSHIFT,IRIS;
}
