package qa.framework.dbutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.LoggerHelper;

public class SQLDriver {

	private static String client = null;
	private static String environment = null;
	private static String testDataColumn = null;
	private static String language = null;

	private static ThreadLocal<Connection> TConnection = new ThreadLocal<Connection>();

	public static ThreadLocal<List<DBRowTO>> TTestData = new ThreadLocal<List<DBRowTO>>();

	private static int currentOpenConnection = 0;

	private static Logger log = LoggerHelper.getLogger(SQLDriver.class);

	/**
	 * @author Bathriyo
	 * @return
	 */
	public static String getClient() {
		return client;
	}

	public static String getEnvironment() {
		return environment;
	}

	public static String getLanguage() {
		return language;
	}

	private static void configClient() {
		/* reading from cmd line */
		String cmdClient = System.getProperty("client");

		if (cmdClient != null) {
			client = cmdClient;
		} else {
			/* reading from property file */
			client = GlobalVariables.configProp.getProperty("client");
		}

	}

	private static void configEnvironment() {
		/* reading from cmd line */
		String cmdEnvironment = System.getProperty("environment");

		if (cmdEnvironment != null) {
			environment = cmdEnvironment;
		} else {
			/* reading from property file */
			environment = GlobalVariables.configProp.getProperty("environment");
		}
	}

	private static void configLanguage() {
		/* reading from cmd line */
		String cmdLanguage = System.getProperty("language");

		if (cmdLanguage != null) {
			language = cmdLanguage;
		} else {
			/* reading from property file */
			language = GlobalVariables.configProp.getProperty("language");
		}
	}

	public static void conigSQL() {
		configClient();
		configEnvironment();
		configLanguage();
		testDataColumn = client + "_" + environment + "_" + "Testdata_Value";
	}

	/**
	 * Opening QA DB connection
	 */
	private synchronized static void openConnection() {
		try {

			Connection con = DriverManager.getConnection(
					"jdbc:mysql://" + GlobalVariables.configProp.getProperty("db_url") + ":"
							+ GlobalVariables.configProp.getProperty("db_port") + "/"
							+ GlobalVariables.configProp.getProperty("db_name"),
					GlobalVariables.configProp.getProperty("db_username"),
					GlobalVariables.configProp.getProperty("db_password"));

			TConnection.set(con);
			log.debug("Currently Open Connection: " + (++currentOpenConnection));

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}

	/**
	 * Getting Element data from DB
	 * 
	 * @param pageName
	 * @return List<DBRowTO>
	 */
	public synchronized static List<DBRowTO> getEleObjData(String pageName) {

		String finalSQLArg = "";

		List<DBRowTO> eleData = new ArrayList<DBRowTO>();

		String[] pageNameArr = pageName.split(",");

		if (pageNameArr.length > 1) {

			for (String temp : pageNameArr) {
				finalSQLArg = finalSQLArg + "'" + temp + "'" + ",";
			}
			finalSQLArg = finalSQLArg.substring(0, finalSQLArg.length() - 1);

		} else {
			finalSQLArg = "'" + pageName + "'";
		}

		String query;
		/* language configuration in SQL */
		if (language.trim().toLowerCase().equals("english") || language.trim().length() <= 0) {
			query = "Select ELEMENTS.Element_Key,ELEMENTS.Element_Value, VALUE_TYPE.Value_Type from ELEMENTS,VALUE_TYPE Where ELEMENTS.Value_Type_ID=VALUE_TYPE.Value_Type_ID && ELEMENTS.Page_ID in ("
					+ finalSQLArg + ");";
		} else {
			query = "Select ELEMENTS.Element_Key,IFNULL(" + language
					+ ",ELEMENTS.Element_Value) Element_Value, VALUE_TYPE.Value_Type from ELEMENTS,VALUE_TYPE Where ELEMENTS.Value_Type_ID=VALUE_TYPE.Value_Type_ID && ELEMENTS.Page_ID in ("
					+ finalSQLArg + ");";
		}

		ResultSet result;

		SQLDriver.openConnection();

		PreparedStatement prepareStatement = null;

		try {

			prepareStatement = TConnection.get().prepareStatement(query);
			result = prepareStatement.executeQuery();

			while (result.next()) {
				DBRowTO temp = new DBRowTO();
				temp.setKey(result.getString("Element_Key"));
				temp.setValue(result.getString("Element_Value"));
				temp.setValueType(result.getString("Value_Type"));
				eleData.add(temp);
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {

			try {
				prepareStatement.close();
				closeConnection();
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}

		return eleData;

	}

	/**
	 * Getting Test Data from DB
	 * 
	 * @param featureIDs
	 * @return List<DBRowTO>
	 */
	public synchronized static List<DBRowTO> getData(String featureIDs) {

		List<DBRowTO> testData = new ArrayList<DBRowTO>();

		/*
		 * String query =
		 * "SELECT TESTDATA.Testdata_Key, TESTDATA.Testdata_Value FROM TESTDATA WHERE TESTDATA.Feature_ID in ("
		 * + featureIDs + ")";
		 */

		/*
		 * String query2 = "SELECT TESTDATA.Testdata_Key, TESTDATA." + testDataColumn +
		 * " FROM TESTDATA WHERE TESTDATA.Feature_ID in (" + featureIDs + ")";
		 */

		String query = "SELECT TESTDATA.Testdata_Key, IFNULL (TESTDATA." + testDataColumn
				+ ", TESTDATA.UBS_QA_Testdata_Value) testData_alias" + " FROM TESTDATA WHERE TESTDATA.Feature_ID in ("
				+ featureIDs + ")";

		ResultSet result;

		SQLDriver.openConnection();

		PreparedStatement prepareStatement = null;

		try {
			prepareStatement = TConnection.get().prepareStatement(query);

			result = prepareStatement.executeQuery();
			while (result.next()) {
				DBRowTO temp = new DBRowTO();
				temp.setKey(result.getString("Testdata_Key"));
				// temp.setValue(result.getString("Testdata_Value"));
				// temp.setValue(result.getString(testDataColumn));
				temp.setValue(result.getString("testData_alias"));
				testData.add(temp);
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {

			try {
				prepareStatement.close();
				closeConnection();
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}

		return testData;
	}

	/**
	 * Public static method to get switch value against client
	 * 
	 * @author Bathriyo
	 * @param switchName
	 * @return
	 */
	public synchronized static String getSwitchValueAgstClient(String switchName) {
		String value = "undefined";
		String query = "SELECT " + client + " FROM SWITCH_CONFIG WHERE Switch_Name='" + switchName + "';";

		ResultSet result;

		SQLDriver.openConnection();

		PreparedStatement prepareStatement = null;

		try {
			prepareStatement = TConnection.get().prepareStatement(query);

			result = prepareStatement.executeQuery();
			while (result.next()) {
				value = result.getString(client);
			}
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {

			try {
				prepareStatement.close();
				closeConnection();

			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}

		return value;
	}

	private static void closeConnection() {
		try {
			TConnection.get().close();
			log.debug("Currently Open Connection: " + (--currentOpenConnection));
		} catch (SQLException e) {
			ExceptionHandler.handleException(e);

		}
	}

}
