package qa.framework.runner;

import org.apache.log4j.Logger;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

import qa.framework.utils.LoggerHelper;

public class RetryAnalyzer implements IRetryAnalyzer{
	private int retryCount=0;
	private int maxReTryCount=1;
	private Logger log;
	
	@Override
	public boolean retry(ITestResult result) {
		
		log = LoggerHelper.getLogger(result.getClass());
		
		/*Retry code - Start*/
		if(retryCount<maxReTryCount ) {
			
			log.debug("Retrying method: "+result.getName()+" again and the count is "+(retryCount+1));
			++retryCount;
			return true;
			
		}else {
			return false;
		}
		/*Retry code - End*/
	
	}
}
