package qa.framework.runner;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.lang.reflect.Method;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.stdwin.Window;
import com.hp.lft.sdk.stdwin.WindowDescription;

import qa.framework.dbutils.SQLDriver;
import qa.framework.mainframe.LaunchMainframeTerminal;
import qa.framework.utils.CaptureScreenshot;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.ExtentReportManager;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.Leanft;
import qa.framework.utils.LoggerHelper;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.webui.browsers.WebDriverManager;

/**
 * 
 * @author BathriYo
 *
 */
public class TNGBase {

	static boolean flagUI = false;
	static boolean flagMainframe = false;
	static String currentClassName;
	static String currentTestName;
	static String[] listGroupIDs;

	public ExtentTest test = null;
	

	Logger log = LoggerHelper.getLogger(TNGBase.class);;

	@BeforeSuite(alwaysRun=true)
	public void setUpSuit() throws IOException {

		GlobalVariables.extentReportManagerObj = new ExtentReportManager();

		GlobalVariables.extentReportManagerObj.setExtentRport();

		/* Initiating configuration properties file */
		GlobalVariables.configProp = new PropertyFileUtils("config.properties");

		/* config web driver */
		WebDriverManager.configureDriver();

		/* config test data columen as per client and environment */
		SQLDriver.conigSQL();

		/* 1st step: config mainframe */
		LaunchMainframeTerminal.configMainframe();

		if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true")) {
			
			/*This method is called avoid 'Emulator(Keyboard)' popup to appear*/
			LaunchMainframeTerminal.updateDefaultKeyBoard_IBMPCOM_WS();
			
			/* 2nd step: starting LeanFT */
			Leanft.startEngine();

			/* 3rd step: Launch Terminal is in before method */
			/* 4th step: closing of terminal is in after method */
			// LaunchMainframeTerminal.launchTerminalAndSetWindow();

		}

	}

	@AfterSuite(alwaysRun=true)
	public void tearDownSuit() {

		/* final report flush */
		GlobalVariables.extentReport.flush();

		/* killing browser process */
		WebDriverManager.killDriverProcess();

		if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true")) {

			/* stopping leanft */
			Leanft.stopEngine();

		}

	}

	@BeforeMethod(dependsOnMethods = { "getMethodName" },alwaysRun=true)
	public void loadTestData() {
		currentClassName = this.getClass().getSimpleName();

		String primaryKey = "'" + currentClassName + "'";

		for (String str : listGroupIDs) {
			if (str.matches("@td_.*")) {
				String key = str.replace("@td_", "");

				primaryKey = primaryKey +"," +"'" + key + "'";
			}
		}

		/*
		 * Getting Test Data base on Class name . if user want to add more test data,
		 * then respective key should be mention in groups with prefix '@td_'
		 */
		SQLDriver.TTestData.set(SQLDriver.getData(primaryKey));
	}

	/* Getting Test method name */
	@BeforeMethod(alwaysRun=true)
	public void getMethodName(Method method) {

		
		long id = Thread.currentThread().getId();
		
		/* getting current method name */
		currentTestName = method.getName();

		/* getting current method groups name */
		Test currentTest = method.getAnnotation(Test.class);
		listGroupIDs = currentTest.groups();

		ExtentReportManager.setTest(GlobalVariables.extentReport.createTest(currentTest.description()));
	

		/* [mandatory step to perform to generate the report */
		//ExtentReportManager.setTest(test);

		/* login method name */
		log.debug("****** Current Test Running: " + currentTestName + " ******\n");

	}

	/* Setting by Browser */
	@BeforeMethod(dependsOnMethods = { "getMethodName" },alwaysRun=true)
	public void setUpBrowser() {

		if (currentClassName.matches("(.*)UI(.*)")) {

			flagUI = true;

			WebDriverManager.startDriver();

		}

		/* fail safe for mainframe */
		if (currentClassName.matches("(.*)MAN(.*)")) {
			flagMainframe = true;
			if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true")) {

				/* 3rd step: Launch Terminal and login to terminal */
				LaunchMainframeTerminal.launchTerminalAndSetWindow();

			} else {
				Assert.fail("!!! 'mainframe' attribute is 'false' in 'config.properties' file !!!");
			}

		}

	}

	/* Extent report status update */
	@AfterMethod (alwaysRun=true)
	public void extentReportStatusUpdate(ITestResult result) {

		/* creating tags in extent report */
		GlobalVariables.extentReportManagerObj.createCategories(listGroupIDs);

		/* Extent Report Status update */
		ExtentTest test = GlobalVariables.extentReportManagerObj.updateTestStatus(result);

		try {

			/*
			 * Taking screenshot in case of failure. To prevent NullPointerException in case
			 * of API below check is performed
			 */
			if (result.getStatus() == ITestResult.FAILURE) {

				if (flagUI == true) {

					test.addScreenCaptureFromPath(CaptureScreenshot.screenCapture("Failure"));
				}

				/* Mainframe */
				if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true") && flagMainframe == true) {

					test.addScreenCaptureFromPath(CaptureScreenshot.captureEntireScreen("Failure"));

				}

			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		} finally {
			GlobalVariables.extentReport.flush();
		}

	}

	/* killing browser after @Test */
	@AfterMethod(dependsOnMethods = { "extentReportStatusUpdate" },alwaysRun=true)
	public void killProcess() {

		if (flagUI == true) {

			WebDriverManager.quitDriver();
		}

		if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true") && flagMainframe == true) {

			/* reverting back flagMainframe value */
			flagMainframe = false;

			try {
				
				LaunchMainframeTerminal.disconnect();
				
				LaunchMainframeTerminal.closeTerminalWindow();

			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}

	}

}
