package qa.framework.runner;

import java.util.Collection;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.NoSuchWindowException;

import io.cucumber.core.api.Scenario;
import io.cucumber.core.event.Status;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import qa.framework.common.stepdefs.CommonStepDefs;
import qa.framework.dbutils.SQLDriver;
import qa.framework.desktop.DesktopDriverManager;
import qa.framework.mainframe.LaunchMainframeTerminal;
import qa.framework.testexecutionupdate.JiraAPI;
import qa.framework.utils.Action;
import qa.framework.utils.BinarySearchListOfMap;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LoggerHelper;
import qa.framework.utils.Reporter;
import qa.framework.utils.RestApiUtils;
import qa.framework.utils.SIT2Sanity;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.ad.productmaster.webui.pages.SSOLoginPage;
import qa.unicorn.co.opsmfrs.webui.pages.OpsmfrsUiUtils;

public class Hooks {

	private Logger log = LoggerHelper.getLogger(Hooks.class);

	/* do not assign featureDes as Null. will cause issue */
	String featureDes = "";
	boolean flagUI = false;
	boolean flagAPI = false;
	boolean flagMainframe = false;

	@Before(order = 0)
	public void beforeStartDriver(Scenario scenario) {

		/* setting scenario for report purpose */
		Reporter.TScenario.set(scenario);

		Collection<String> sourceTagNames = scenario.getSourceTagNames();

		for (String tagName : sourceTagNames) {

			if (tagName.matches("(.*)UI(.*)")) {
				flagUI = true;

				/* checking browser launch condition */
				if (WebDriverManager.launchNewBrowserPerScenario) {

					WebDriverManager.startDriver();
				}

				break;/* in case of multiple tag have UI browser should open only once */

			}
		}

		for (String tagName : sourceTagNames) {

			if (tagName.matches("(.*)API(.*)")) {
				flagAPI = true;
				break;

			}
		}

		/* fail safe for mainframe */
		for (String tagName : sourceTagNames) {

			if (tagName.matches("(.*)MAN(.*)")) {
				flagMainframe = true;
				if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true")) {

					/* 3rd step: Launch Terminal and login to terminal */
					LaunchMainframeTerminal.launchTerminalAndSetWindow();

				} else {
					Assert.fail("!!! 'mainframe' attribute is 'false' in 'config.properties' file !!!");
				}

				break;
			}
		}

	}

	@Before(order = 1)
	public void beforeLoadTestData(Scenario scenario) {

		String tdTags = "";

		log.info("*************************");
		log.info("Current Scenario Running: " + scenario.getName());
		log.info("*************************");

		Collection<String> sourceTagNames = scenario.getSourceTagNames();
		for (String tagName : sourceTagNames) {
			if (tagName.contains("td_")) {
				// featureName = tagName.substring(4);
				String temp = tagName.substring(4);
				tdTags = tdTags + "'" + temp + "'" + ",";
			}
		}

		/* removing last ',' */
		tdTags = tdTags.substring(0, tdTags.length() - 1);

		SQLDriver.TTestData.set(SQLDriver.getData(tdTags));

	}

	@After(order = 0)
	public void afterDestroy() {

		/* closing webdriver in case web application */
		if (flagUI == true) {
			
			/* Product Master - Release User */
			SSOLoginPage.ReleaseUser();

			/* checking browser launch condition */
			if (WebDriverManager.launchNewBrowserPerScenario) {

				WebDriverManager.quitDriver();
			}

		}

		/* re-setting rest assured request specification */
		if (flagAPI == true) {

			RestApiUtils.reset();
		}

		/* closing Mainframe terminal in case of mainframe application */
		if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true") && flagMainframe == true) {

			/* reverting back flagMainframe value */
			flagMainframe = false;
			try {
				/* Disconnecting Terminal */
				LaunchMainframeTerminal.disconnect();

				/* closing terminal window after disconnect */
				LaunchMainframeTerminal.closeTerminalWindow();

			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

		}

		/* checking if scenario is desktop scenario or not */
		if (DesktopDriverManager.getFlag() == true) {
			try {
				/* on failure taking screenshot */
				Reporter.addDesktopScreenshot();

				/* on failure closing the application */
				DesktopDriverManager.stopApplication();

				/* on failure setting the Desktop flag to False */
				DesktopDriverManager.setFlag(false);

			} catch (NoSuchWindowException e) {
				log.info("!!! Desktop window seem to be closed already !!! On Failure screenshot NOT taken");
			}
		}

	}

	@After(order = 10)
	public void afterOnScenarioFailure(Scenario scenario) {

		if (scenario.isFailed()) {

			/* Web Portal */
			if (flagUI == true) {

				try {

					Action.scrollToUp();
					// Reporter.addScreenCapture();
					Reporter.addCompleteScreenCapture();

				} catch (Exception e) {

					ExceptionHandler.handleException(e);
				}

			}

			/* Mainframe */
			if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true") && flagMainframe == true) {

				Reporter.addEntireScreenCaptured();

			}
		}

	}

	@After("@SIT2_Sanity or @sit2_sanity")
	public void sitSanity(Scenario scenario) {

		if (SIT2Sanity.reportSwitch == true) {
			if (testID == null || testID.length() <= 0) {
				SIT2Sanity.updateSITReport(scenario);
			} else {
				SIT2Sanity.setStatusMap(testID, scenario.getStatus());
				testID = null;
			}
		}

	}

	/****************************************
	 * JIRA UPDATE
	 ****************************************/

	String testID = null;

	/* getting Test ID */
	/* This statement should only run in case of scenario outline */
	@Given("^Scenario Variation: (.+) - (.+)$")
	public void scenario_variation_(String jiratestid, String scenarioname) {
		this.testID = jiratestid.trim();
	}

	public void updateScenarioStatus(String testID, Status status, Scenario scenario) {

		/* searching test id in list */
		BinarySearchListOfMap search = new BinarySearchListOfMap(JiraAPI.lstRunInfo, JiraAPI.strTestID);
		/* got respective index */
		int index = search.binarySearch(0, JiraAPI.lstRunInfo.size() - 1, testID);

		if (index >= 0) {

			/*
			 * Checking if 'CurrentRunStatus' is available in map or not. if NO, it will be
			 * added
			 */

			if (!JiraAPI.lstRunInfo.get(index).containsKey(JiraAPI.strCurrentRunStatus)) {
				/* updating scenario/scenario outline status in list against test id */
				if (status == Status.PASSED) {
					JiraAPI.lstRunInfo.get(index).put(JiraAPI.strCurrentRunStatus, "PASS");
				} else if (status == Status.FAILED) {
					JiraAPI.lstRunInfo.get(index).put(JiraAPI.strCurrentRunStatus, "FAIL");
				} else if (status == Status.SKIPPED) {
					JiraAPI.lstRunInfo.get(index).put(JiraAPI.strCurrentRunStatus, "ABORTED");
				}
			} else {

				/* 'CurrentRunStatus' is only updated if previous run status in not FAIL. */
				if (JiraAPI.lstRunInfo.get(index).get(JiraAPI.strCurrentRunStatus).equals("PASS")) {
					/* updating scenario/scenario outline status in list against test id */
					if (status == Status.PASSED) {
						JiraAPI.lstRunInfo.get(index).put(JiraAPI.strCurrentRunStatus, "PASS");
					} else if (status == Status.FAILED) {
						JiraAPI.lstRunInfo.get(index).put(JiraAPI.strCurrentRunStatus, "FAIL");
					} else if (status == Status.SKIPPED) {
						JiraAPI.lstRunInfo.get(index).put(JiraAPI.strCurrentRunStatus, "ABORTED");
					}
				}

			}

		} else {
			scenario.write("[Alert] Test ID is not provided.");
		}

	}

	@After(order = 1)
	public void updateJiraTestCurrentStatus(Scenario scenario) {

		if (JiraAPI.enableJiraUpdate == true) {

			String scenarioName = scenario.getName().trim();

			/* getting scenario status */
			Status status = scenario.getStatus();

			/* getting Test ID */
			/* this statement will only run in case of scenario. */

			if (scenarioName.startsWith("[")) {

				/* removing square brackets [] */
				String[] testIDs = scenarioName.split("]")[0].replace("[", "").split(",");

				for (String testID : testIDs) {
					/* for scenario having multiple testIds */
					updateScenarioStatus(testID.trim(), status, scenario);

				}

			} else {

				/* for scenario outline */
				updateScenarioStatus(testID, status, scenario);
			}

			testID = null;

		}

	}

	@After(order = 2)
	public void getScenarioFailedTags(Scenario scenario) {
		OpsmfrsUiUtils utils = new OpsmfrsUiUtils();
		utils.getFailedIDs(scenario, testID);
	}

	/* only for SIT Integration testing */
	@After("@SIT2_Regression_New")
	public void onFailure(Scenario secenario) {

		if (secenario.getStatus() == Status.FAILED) {

			/* UI on Failure */
			if (CommonStepDefs.threadLocal_flagUI.get() == true) {
				Reporter.addScreenCapture();

				WebDriverManager.quitDriver();
			}

			/* Mainframe screenshot */
			if (CommonStepDefs.threadLocal_flagMainframe.get() == true) {

				Reporter.addEntireScreenCaptured();

				/* Disconnecting Terminal */
				LaunchMainframeTerminal.disconnect();

				/* closing terminal window after disconnect */
				LaunchMainframeTerminal.closeTerminalWindow();
			}
		}
	}

}
