package qa.framework.runner;

import java.util.Collection;

import org.testng.ITestResult;

import cucumber.api.event.TestCaseFinished;
import io.cucumber.core.api.Scenario;
import io.cucumber.core.event.Status;
import io.cucumber.java.After;
import qa.framework.utils.FileManager;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;

public class HeartBeat {

	private static boolean heartbeatEnabler = false;

	private static StringBuilder heartBeatReportInfo;
	private static boolean isSubCapabilityNameAdded = false;

	private static int totalCount = 0;
	private static int passed = 0;
	private static int failed = 0;
	private static int skipped = 0;

	public static boolean isHeartbeatEnabler() {
		return heartbeatEnabler;
	}

	public static StringBuilder getHeartBeatReportInfo() {
		return heartBeatReportInfo;
	}

	public static int getTotalCount() {
		return totalCount;
	}

	public static int getPassed() {
		return passed;
	}

	public static int getFailed() {
		return failed;
	}

	public static int getSkipped() {
		return skipped;
	}

	public static String createHeartBeatFile() {
		PropertyFileUtils extendPro = new PropertyFileUtils("./src/test/resources/extent.properties");
		String spartReportDirPath = "./" + extendPro.getProperty("extent.reporter.spark.out");
		String heartBeatFileName = "heartbeat.txt";
		String heartBeatFilePath = spartReportDirPath + "/" + heartBeatFileName;

		/* creating csv file */
		FileManager.getFileManagerObj().createFile(heartBeatFilePath);

		return heartBeatFilePath;

	}

	public static void config() {

		heartbeatEnabler = Boolean.parseBoolean(
				System.getProperty("heartbeatEnabler", GlobalVariables.configProp.getProperty("heartbeatEnabler")));

		if (heartbeatEnabler) {
			/* Stringbuilder initialization */
			heartBeatReportInfo = new StringBuilder();
		}
	}

	@After
	public void afterHookHeartBeat(Scenario scenario) {
		if (heartbeatEnabler) {

			/* incrementing total count */
			++totalCount;

			if (!isSubCapabilityNameAdded) {
				Collection<String> sourceTagNames = scenario.getSourceTagNames();
				String heartBeatTag = sourceTagNames.stream().filter(tag -> tag.contains("@HeartBeat_") == true)
						.findAny().get();

				/* adding info to builder */
				heartBeatReportInfo.append("Sub-capability Name: " + heartBeatTag.replace("@HeartBeat_", ""))
						.append("\n");

				/* setting to true */
				isSubCapabilityNameAdded = true;
			}

			String info = scenario.getId();
			String name = scenario.getName();
			Status status = scenario.getStatus();
			
			/*adding Scenario name to info*/
			info=info+": "+name;

			if (status == Status.PASSED) {
				info = info + ": PASS";

				++passed;

			} else if (status == Status.FAILED) {
				//String errorMessage = result.getThrowable().getMessage();
				
				info = info + ": FAILED";
				//info=info+": Error-"+errorMessage;
				
				++failed;
			} else if (status == Status.SKIPPED) {
				info = info + ": SKIPPED";
				++skipped;
			}

			heartBeatReportInfo.append(info);

		}
	}

}
