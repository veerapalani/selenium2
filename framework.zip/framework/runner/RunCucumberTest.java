package qa.framework.runner;

import java.io.IOException;
import java.util.HashSet;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import qa.framework.dbutils.SQLDriver;
import qa.framework.desktop.DesktopDriverManager;
import qa.framework.mainframe.LaunchMainframeTerminal;
import qa.framework.testexecutionupdate.JiraAPI;
import qa.framework.testexecutionupdate.JiraReport;
import qa.framework.utils.Action;
import qa.framework.utils.CalendarUtils;
import qa.framework.utils.FileManager;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.Leanft;
import qa.framework.utils.ProfileTestDataProvider;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.utils.Reporter;
import qa.framework.utils.SIT2Sanity;
import qa.framework.webui.browsers.WebDriverManager;
import qa.unicorn.co.opsmfrs.webui.pages.OpsmfrsUiUtils;

@CucumberOptions(plugin = { "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
		"html:target/cucumber-html-report", "json:target/cucumber.json", "pretty:target/cucumber-pretty.txt",
		"usage:target/cucumber-usage.json",

		"junit:target/cucumber-results.xml" }, features = { "src/test/resources/" }, glue = { "qa/framework/runner",
				"qa.framework.utils", "qa/framework/rnd", "qa/framework/common/stepdefs",
				"qa.framework.jsonschemavalidation.stepdefs", "qa/unicorn/ws/components/webui/stepdefs",
				"qa/unicorn/ws/components/api/stepdefs", "qa/unicorn/ws/framework/webui/stepdefs",
				"qa/unicorn/ws/framework/api/stepdefs", "qa/unicorn/tr/trading/api/stepdefs",
				"qa/unicorn/tr/trading/webui/stepdefs", "qa/unicorn/tr/tcor/webui/stepdefs",
				"qa/unicorn/co/serviceworks/api/stepdefs", "qa/unicorn/co/serviceworks/webui/stepdefs",
				"qa/unicorn/co/opsmfrs/api/stepdefs", "qa/unicorn/co/opsmfrs/webui/stepdefs",
				"qa.unicorn.co.opsmfrs.mainframe.stepdefs", "qa.unicorn.co.opsdashboard.webui.stepdefs",
				"qa.unicorn.co.opsConsole.webui.stepdefs", "qa/unicorn/co/ascendisacats/webui/stepdefs",
				"qa/unicorn/co/ascendisacats/api/stepdefs", "qa/unicorn/co/clientonboarding/api/stepdefs",
				"qa/unicorn/co/clientonboarding/webui/stepdefs", "qa/unicorn/co/relationshipmaster/webui/stepdefs",
				"qa/unicorn/co/jabe/api/stepdefs", "qa/unicorn/co/jabe/webui/stepdefs",
				"qa.unicorn.co.GFWApplications.webui.stepdefs", "qa/unicorn/co/revport/webui/stepdefs",
				"qa.unicorn.co.ascendisSEG.webui.stepdefs", "qa.unicorn.co.taxreporting.stepdefs",
				"qa.unicorn.co.PhaseIV.api.stepdefs", "qa/unicorn/co/accountmaintenance/webui/stepdefs",
				"qa/unicorn/ad/productmaster/api/stepdefs", "qa/unicorn/ad/productmaster/webui/stepdefs",
				"qa/unicorn/ad/securitymaster/api/stepdefs", "qa.unicorn.ad.securitymaster.webui.stepdefs",
				"qa/unicorn/ad/securitymaster/mainframe/stepdefs", "qa/unicorn/legacy/ad/pru/webui/stepdefs",
				"qa/unicorn/df/datafabric/webui/stepdefs", "qa/unicorn/df/datafabric/api/stepdefs",
				"qa/unicorn/al/AggLayer/api/stepdefs", "qa/unicorn/te/carma/api/stepdefs",
				"qa/unicorn/te/eisl/api/stepdefs", "qa/unicorn/te/clientsearch/api/stepdefs",
				"qa/unicorn/eisl/mi/stepdefs", "qa/unicorn/eisl/mi/api/stepdefs",
				"qa/unicorn/co/opsConsoleRegression/webui/stepdefs", "/qa/unicorn/te/e99/api/stepdefs" },

		tags = { "@JABE-6205" })

public class RunCucumberTest extends AbstractTestNGCucumberTests {

	static String startTime = "";

	public static HashSet<String> getFailIDs = new HashSet<String>();

	@Override
	@DataProvider(parallel = false)
	public Object[][] scenarios() {

		return super.scenarios();
	}

	@BeforeSuite
	public void initialSetup() throws IOException {

		System.setProperty("hudson.model.DirectoryBrowserSupport.CSP",
				"sandbox allow-scripts; default-src 'self'; script-src * 'unsafe-eval'; img-src *; style-src * 'unsafe-inline'; font-src *");

		startTime = CalendarUtils.getCalendarUtilsObject().getTimeStamp("MM/dd/yyyy hh:mm:ss aa");

		/* Initiating configuration properties file */
		GlobalVariables.configProp = new PropertyFileUtils("config.properties");

		/* config Screenshot per action */
		Action.configScrCapPerAction();

		/* config web driver */
		WebDriverManager.configureDriver();

		/*
		 * config test data column as per client, environment and language are
		 * configured here
		 */
		String profile = System.getProperty("environment", GlobalVariables.configProp.getProperty("environment"));
		GlobalVariables.testData = ProfileTestDataProvider.getConfigForProfile(profile);
		SQLDriver.conigSQL();

		/* 1st step: config mainframe */
		LaunchMainframeTerminal.configMainframe();

		if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true")) {

			/* This method is called avoid 'Emulator(Keyboard)' popup to appear */
			LaunchMainframeTerminal.updateDefaultKeyBoard_IBMPCOM_WS();

			/* 2nd step: starting LeanFT */
			Leanft.startEngine();

			/* 3rd step: Launch Terminal is in before method */
			/* 4th step: closing of terminal is in after method */

		}

		/* configuring desktop framework settings */
		DesktopDriverManager.config();

		/* configuring jira update */
		JiraAPI.configJiraUpdate();

		/* configuring sit2_sanity properties */
		SIT2Sanity.config();

		/* heartbeat config */
		HeartBeat.config();

	}

	@AfterSuite
	public void destroy() throws IOException {

		/* killing browser process */
		WebDriverManager.killDriverProcess();

		if (LaunchMainframeTerminal.mainframe.trim().equalsIgnoreCase("true")) {

			/* stopping LeanFT */
			Leanft.stopEngine();

		}

		/* Killing WinAppDriver process */
		if (DesktopDriverManager.getDesktopSwitch() == true) {
			DesktopDriverManager.stopDriver();
		}

		/* modifying absolute screen shot path with generic path */
		Reporter.updateGenericScrShotPath();

		/* creating a file to write jira field and values */
		if (JiraAPI.enableJiraUpdate == true) {
			JiraReport.write("ExecutionReport", ".txt");

			if (JiraAPI.autoUpdateJiraRecords == true) {

				JiraAPI.runJiraUpdate(JiraReport.filePath);
			}

			JiraAPI.uploadZipReport();

		}

		/* SIT2_Sanity report */
		if (SIT2Sanity.reportSwitch == true) {
			SIT2Sanity.writeReport(startTime,
					CalendarUtils.getCalendarUtilsObject().getTimeStamp("MM/dd/yyyy hh:mm:ss aa"));

			if (SIT2Sanity.sitEmailSwitch == true) {
				// SIT2Sanity.sendReportViaMail();
			}
		}

		GlobalVariables.configProp = new PropertyFileUtils("config.properties");
		System.out.println("FailedIDs::" + getFailIDs.toString());
		OpsmfrsUiUtils util = new OpsmfrsUiUtils();
		util.writeToExcelForFailedIDs(GlobalVariables.configProp.getProperty("project"),
				"rerun_" + GlobalVariables.configProp.getProperty("project"), ".xlsx", getFailIDs);
		util.writeToProperties(getFailIDs, "failedIDs");

		/* heartbeat */
		boolean isHeartbeatEnabler = HeartBeat.isHeartbeatEnabler();
		if (isHeartbeatEnabler) {
			String heartBeatFilePath = HeartBeat.createHeartBeatFile();

			StringBuilder heartBeatReportInfo = HeartBeat.getHeartBeatReportInfo();

			String endTime = CalendarUtils.getCalendarUtilsObject().getTimeStamp("MM/dd/yyyy hh:mm:ss aa");
			heartBeatReportInfo.append("--------------------------------------------------").append("\n");
			heartBeatReportInfo.append("START TIME  : " + startTime).append("\n");
			heartBeatReportInfo.append("END TIME    : " + endTime).append("\n");
			heartBeatReportInfo.append("PASSED  : " + HeartBeat.getPassed()).append("\n");
			heartBeatReportInfo.append("FAILED  : " + HeartBeat.getFailed()).append("\n");
			heartBeatReportInfo.append("SKIPPED : " + HeartBeat.getSkipped()).append("\n");
			heartBeatReportInfo.append("TOTAL   : " + HeartBeat.getTotalCount()).append("\n");

			FileManager.getFileManagerObj().write(heartBeatFilePath, heartBeatReportInfo.toString());
		}

	}

}
