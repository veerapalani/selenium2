package qa.framework.runner;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import qa.framework.utils.Action;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.PropertyFileUtils;
import qa.framework.webui.browsers.EdgeBrowser;
import qa.framework.webui.browsers.WebDriverManager;

public class ToDelete {

	@Test(enabled = true)
	public void testDriverManager() {

		GlobalVariables.configProp = new PropertyFileUtils("config.properties");
		WebDriverManager.configureDriver();

		// ChromeBrowser browser = new ChromeBrowser();
		// IEBrowser browser = new IEBrowser();
		EdgeBrowser browser = new EdgeBrowser();
		WebDriver driver = browser.getDriver();
		driver.get("https://www.google.com");

		Action.pause(2000);
		
		System.out.println("Test msg for git demo");

		driver.quit();

	}

}
