package qa.framework.rnd;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import qa.framework.assertions.AssertLogger;
import qa.framework.desktop.DesktopDriverManager;
import qa.framework.utils.Reporter;

public class DesktopDemo {

	@When("^user enter text \"([^\"]*)\" in notepad$")
    public void user_enter_text_something_in_notepad(String text){
    	
    	DesktopDriverManager.getDriver().findElementByAccessibilityId("15").sendKeys(text);
       
    }

    @Then("^text \"([^\"]*)\" should get entered in notepad$")
    public void text_something_should_get_entered_in_notepad(String text){
    	String actualText = DesktopDriverManager.getDriver().findElementByAccessibilityId("15").getText();
    	AssertLogger.assertEquals(text, actualText,"Text didn't match");
    }

    @And("^user close the notepad application$")
    public void user_close_the_notepad_application() {
    	DesktopDriverManager.getDriver().findElementByName("Close").click();
    	
    	try {
    		DesktopDriverManager.getDriver().findElementByName("Don't Save").click();	
    	}catch(Exception e) {
    		// do nothing
    	}
    	
    }
    
    @When("^user open 'About Notepad' dialog box$")
    public void user_open_about_notepad_dialog_box(){
    	DesktopDriverManager.getDriver().findElementByName("Help").click();
    	DesktopDriverManager.getDriver().findElementByName("About Notepad").click();
    	
    	
    }

    @When("^user close 'About Notepad' dialog box$")
    public void user_close_about_notepad_dialog_box(){
    	DesktopDriverManager.getDriver().findElementByName("OK").click();
    }

    @Then("^notepad version should be \"([^\"]*)\"$")
    public void notepad_version_should_be_something(String version){
    	String actualVersion = DesktopDriverManager.getDriver().findElementByXPath("//*[contains(@Name,'Version 1607')]").getAttribute("Name");
    	
    	if(actualVersion.contains(version)) {
    		Assert.assertTrue(true);
    		
    	}else {
    		Assert.assertTrue(false);
    	}
    	
    	Reporter.addDesktopScreenshot();
    	
    }
    
    @And("^user intentionally fail this scenario$")
    public void user_intentionally_fail_this_scenario(){
        Assert.fail("Known Reason");
    }

	
}
