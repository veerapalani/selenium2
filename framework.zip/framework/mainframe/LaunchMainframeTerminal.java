package qa.framework.mainframe;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.junit.Assert;

import com.hp.lft.sdk.RegExpProperty;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.FileManager;
import qa.framework.utils.GlobalVariables;
import qa.framework.utils.Leanft;
import qa.framework.utils.LeanftAction;
import qa.framework.utils.LoggerHelper;
import qa.framework.utils.PropertyFileUtils;

public class LaunchMainframeTerminal {

	private final static String TASKLIST = "tasklist";

	public static String mainframe = "false";
	public static String mainframe_ws = "";
	public static String mainframe_kmp = "";
	private static String wsFilePath;
	private static String kmpFilePath;
	

	private static String batchFilePath;

	static Logger log = LoggerHelper.getLogger(Leanft.class);

	
	private static void configMainframeWSFile() {
		/* reading from cmd line */
		String cmdWS = System.getProperty("mainframe_ws");

		if (cmdWS != null) {
			mainframe_ws = cmdWS;
		} else {
			/* reading from property file */
			mainframe_ws = GlobalVariables.configProp.getProperty("mainframe_ws");
		}
	}
	
	private static void configMainframeKMP() {
		/* reading from cmd line */
		String cmdKMP = System.getProperty("mainframe_kmp");

		if (cmdKMP != null) {
			mainframe_kmp = cmdKMP;
		} else {
			/* reading from property file */
			mainframe_kmp = GlobalVariables.configProp.getProperty("mainframe_kmp");
		}
	}
	
	
	public static void configMainframe() {
		/* reading from cmd line */
		String cmdMainframe = System.getProperty("mainframe");

		if (cmdMainframe != null) {
			mainframe = cmdMainframe;
		} else {
			/* reading from property file */
			mainframe = GlobalVariables.configProp.getProperty("mainframe");
		}
		
		if(mainframe.equalsIgnoreCase("true")) {
			/*configuring WS file*/
			configMainframeWSFile();
			/*configuring kmp file*/
			configMainframeKMP();
			
			wsFilePath=FileManager.getFileManagerObj().searchFile(System.getProperty("user.dir"), mainframe_ws);
			kmpFilePath=FileManager.getFileManagerObj().searchFile(System.getProperty("user.dir"), mainframe_kmp);
			
		}
	}

	public static void LaunchTerminal() {

		// Close any existing terminal windows
		String processName = "pcsws.exe";

		try {

			if (isProcessRunning(processName)) {
				killProcess(processName);

			}

			//String terminalFilePath = System.getProperty("user.dir") + "/src/test/resources/mf/launcher/Unicorn_IBM_PCOM_3270.WS";
			ProcessBuilder pb = new ProcessBuilder("cmd", "/K", wsFilePath);
			
			pb.start();
			
			/* creating batch file cmd */
			//createLauncherBatch("LaunchIBMPCOMM_3270.bat");

			Thread.sleep(3000);
			
			// Launch Terminal Emulator and connect
			//Runtime runtime = Runtime.getRuntime();
			//runtime.exec(batchFilePath);

		} catch (Exception e) {
			log.debug("!!! IBP COMM not started !!!", e);
			Assert.fail("!!! IBP COMM not started !!!");
		}
	}

	/**
	 * Updating IBM PCOMM workstation file 'DefaultKeyboard' setting with (.kmp)
	 * file location.
	 * 
	 * To avoid 'Emulator(Keyboard)' popup to appear.
	 * 
	 * Should be called only once before stating execution.
	 */
	public static void updateDefaultKeyBoard_IBMPCOM_WS() {
		
		//String filePath = "./src\\test\\resources\\mf\\launcher\\Unicorn_IBM_PCOM_3270.WS";

		StringBuffer content = new StringBuffer();
		BufferedReader bufferedReader = null;

		boolean isExists = FileManager.getFileManagerObj().isFileExists(kmpFilePath);

		if (isExists) {
			try {
				bufferedReader = new BufferedReader(new FileReader(kmpFilePath));

				String line = null;

				while ((line = bufferedReader.readLine()) != null) {

					if (line.matches("DefaultKeyboard=.*")) {
						content.append("DefaultKeyboard=" + kmpFilePath).append("\n");
					} else {
						content.append(line).append("\n");
					}

				}
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
				e.printStackTrace();
			} finally {
				try {
					bufferedReader.close();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}

		}

		FileManager.getFileManagerObj().write(kmpFilePath, content.toString());
	}

	/* batch file cmd */
	private static void createLauncherBatch(String fileName) {

		String userDir = System.getProperty("user.dir");
		batchFilePath = userDir + "/src/test/resources/mf/launcher/" + fileName;
		String terminalFilePath = userDir + "/src/test/resources/mf/launcher/Unicorn_IBM_PCOM_3270.WS";

		FileManager.getFileManagerObj().write(batchFilePath, terminalFilePath);
	}

	// Check if process is running
	public static boolean isProcessRunning(String serviceName) throws Exception {
		Process p = Runtime.getRuntime().exec(TASKLIST);
		BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		String line;
		while ((line = reader.readLine()) != null) {
			System.out.println(line);
			if (line.contains(serviceName)) {
				return true;
			}
		}
		return false;
	}

	/*----------------------------------------------------------------------*/

	// Kill the specific process with serviceName
	public static void killProcess(String serviceName) throws Exception {
		// Runtime.getRuntime().exec("taskkill /F /IM /T " + serviceName);
		Runtime.getRuntime().exec("taskkill /F /IM " + serviceName);
	}

	/**
	 * Launch Mainframe terminal enter 'netvac'
	 */
	public static void launchTerminalAndSetWindow() {

		if (mainframe.trim().equalsIgnoreCase("true")) {

			try {

				LaunchMainframeTerminal.LaunchTerminal();
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
			}

			/* setting terminal window */
			FR_MF_MainframeWindow.setTeWindow();

		}

	}

	/**
	 * disconnect mainframe
	 */
	public static void disconnect() {
		Screen genericScr;

		try {

			if (mainframe.trim().equalsIgnoreCase("true")) {

				PropertyFileUtils property = new PropertyFileUtils(
						System.getProperty("user.dir") + "/src/test/resources/mf/launcher/mainframe.properties");
				String terminalLoginCmd = property.getProperty("terminalLoginCmd");
				terminalLoginCmd = terminalLoginCmd.toLowerCase().trim();

				genericScr = FR_MF_MainframeWindow.getTeWindow().describe(Screen.class,
						new ScreenDescription.Builder().label(new RegExpProperty(".*")).build());

				switch (terminalLoginCmd) {
				case "netvac":
					disconnectNETVAC(genericScr);
					break;
				case "tsod":
					disconnectTSOD(genericScr);
					break;
				default:
					Assert.fail("!!! Terminal can not be disconnected. Unknow command: !!!" + terminalLoginCmd);
				}
			}

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	public static void disconnectNETVAC(Screen genericScr) {

		try {

			/*
			 * Terminal will get disconnect when pressed F12 if in TerminalScreen or
			 * Terminal Login Screen
			 */
			if (new FR_MF_EMSP01Scr().isEMSP01ScrExists(3)
					|| new FR_MF_MainframeLoginScr().isTerminalLoginScrExists(3)) {
				LeanftAction.sendTeKeys(genericScr, Keys.PF12);
			} else {
				LeanftAction.sendTeKeys(genericScr, Keys.PF12);
				LeanftAction.sendTeKeys(genericScr, Keys.PF12);
			}

			Thread.sleep(5000);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * Disconnecting tsod
	 */
	public static void disconnectTSOD(Screen genericScr) {

		int counter = 0;

		FR_MF_ReadyScr objReadyScr = new FR_MF_ReadyScr();

		try {

			if (mainframe.trim().equalsIgnoreCase("true")) {

				while (counter < 5) {
					if (objReadyScr.isScreenExists()) {
						objReadyScr.setReadyField("logoff", Keys.ENTER);
						Thread.sleep(2000);
						break;
					} else {
						genericScr.sendTEKeys(Keys.PF3);
					}

					counter += 1;
				}

			}

			Thread.sleep(3000);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/**
	 * Closing terminal window
	 * Note: here stdWin.Window is used.
	 * Leanft setting should have 'WinFroms' and 'Terminal Emulators' both checked
	 */
	 
	public static void closeTerminalWindow() {

		try {
			com.hp.lft.sdk.stdwin.Window x80Window = com.hp.lft.sdk.Desktop.describe(com.hp.lft.sdk.stdwin.Window.class,
					new com.hp.lft.sdk.stdwin.WindowDescription.Builder().childWindow(false).ownedWindow(false)
							.windowClassRegExp("PCSWS:Main:00400000").windowTitleRegExp(" [24 x 80]").build());

			x80Window.close();

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
}
