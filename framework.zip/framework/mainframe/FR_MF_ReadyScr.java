package qa.framework.mainframe;

import java.util.List;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;

public class FR_MF_ReadyScr {

	
	private Screen screen;
	private Field fldReady;

	private List<DBRowTO> listEleReadyScr = SQLDriver.getEleObjData("FR_MF_ReadyScr");

	public FR_MF_ReadyScr() {
		try {
			
			screen = FR_MF_MainframeWindow.getTeWindow().describe(Screen.class,
					new ScreenDescription.Builder().id(Integer.parseInt(Action.getValue("idScreen", listEleReadyScr))).build());
			
			fldReady = screen.describe(Field.class, new FieldDescription.Builder().id(Integer.parseInt(Action.getValue("idReady", listEleReadyScr))).build());
		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}
	
	/*---------------------------------Methods---------------------------------------*/
	
	public boolean isScreenExists() {
		try {
			
			return LeanftAction.isExists(screen, 2);
			
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
		return false;
	}
	
	
	public void setReadyField(String text, String keysEnum) {
		try {
			
			LeanftAction.setText(fldReady, text);
			LeanftAction.sendTeKeys(screen, keysEnum);
			
		}catch(Exception e) {
			ExceptionHandler.handleException(e);
		}
	}
	
	
	
}
