package qa.framework.mainframe;

import com.hp.lft.sdk.Desktop;
import com.hp.lft.sdk.te.Window;
import com.hp.lft.sdk.te.WindowDescription;

import qa.framework.utils.ExceptionHandler;

public class FR_MF_MainframeWindow {
	
	
	public static ThreadLocal<Window> TTeWindow = new ThreadLocal<Window>();
	
	//private static List<DBRowTO> listTeWindow = SQLDriver.getEleObjData("CO_LEG_MRG_TeWindow");

	/**
	 * This constructor will initialize terminal window 
	 * @author bathriyo
	 */
	public static void setTeWindow() {

		try {
			
			Window window = Desktop.describe(Window.class,
					new WindowDescription.Builder().protocol(com.hp.lft.sdk.te.Protocol.PR3270).build());
			TTeWindow.set(window);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}
	
	/**
	 * Public method to get terminal window
	 * @author bathriyo
	 * @return TeWindow
	 */
	public static Window getTeWindow() {
		return TTeWindow.get();
	}

}
