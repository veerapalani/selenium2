package qa.framework.mainframe;

import java.util.List;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;
//import qa.unicorn.legacy.co.mainframe.margin.screens.TerminalLoginScr;
import qa.framework.utils.PropertyFileUtils;

public class FR_MF_MainframeWelcomeScr {

	
	private Screen screen;
	private Field fldNetvac;

	List<DBRowTO> listMainframeWelcomeScr = SQLDriver.getEleObjData("FR_MF_MainframeWelcomeScr");

	/**
	 * Using constructor to initialize screen and fields;
	 * 
	 * @param tewindow
	 */
	public FR_MF_MainframeWelcomeScr() {

		try {

			LeanftAction.sync(FR_MF_MainframeWindow.getTeWindow(), 3);

			/* [important] screen should be initialize first then fields in it */
			screen = FR_MF_MainframeWindow.getTeWindow().describe(Screen.class, new ScreenDescription.Builder()
					.id(Integer.parseInt(Action.getValue("idScreen", listMainframeWelcomeScr))).build());

			fldNetvac = screen.describe(Field.class, new FieldDescription.Builder()
					.id(Integer.parseInt(Action.getValue("idNetvac", listMainframeWelcomeScr))).build());

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

	}

	/*----------------------------METHODS-----------------------------------------------*/

	/**
	 * navigate to Terminal Screen
	 * 
	 * @author BathriYo
	 * @param text
	 */
	public FR_MF_MainframeLoginScr navigateToTerminalLoginScr(String text) {

		PropertyFileUtils property = new PropertyFileUtils(System.getProperty("user.dir") + "/src/test/resources/mf/launcher/mainframe.properties");
		property.setProperty("terminalLoginCmd", text);

		try {

			LeanftAction.setText(fldNetvac, text);
			LeanftAction.sendTeKeys(screen, Keys.ENTER);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return new FR_MF_MainframeLoginScr();

	}
	
	public boolean isWelcomeScrExists() {
		return LeanftAction.isExists(screen, 2);
	}

}
