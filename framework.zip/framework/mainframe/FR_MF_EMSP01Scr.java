package qa.framework.mainframe;

import java.util.List;

import com.hp.lft.sdk.te.Field;
import com.hp.lft.sdk.te.FieldDescription;
import com.hp.lft.sdk.te.Keys;
import com.hp.lft.sdk.te.Screen;
import com.hp.lft.sdk.te.ScreenDescription;

import qa.framework.dbutils.DBRowTO;
import qa.framework.dbutils.SQLDriver;
import qa.framework.utils.Action;
import qa.framework.utils.ExceptionHandler;
import qa.framework.utils.LeanftAction;


public class FR_MF_EMSP01Scr {

	private Screen screen;
	private Field commandField;
	
	List<DBRowTO> listEleEMSPScr = SQLDriver.getEleObjData("FR_MF_EMSP01Scr");

	/**
	 * Building terminal Home screen
	 * 
	 * @param tewindow
	 */
	public FR_MF_EMSP01Scr() {

		try {
			screen = FR_MF_MainframeWindow.getTeWindow().describe(Screen.class,
					new ScreenDescription.Builder().label(Action.getValue("lblScreen", listEleEMSPScr)).build());
			
			commandField = screen.describe(Field.class,
					new FieldDescription.Builder().attachedText(Action.getValue("atcTxtCommand", listEleEMSPScr)).id(Integer.parseInt(Action.getValue("idCommand", listEleEMSPScr))).build());

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		
	}

	
	/*----------------------------METHODS-----------------------------------------------*/

	public boolean isEMSP01ScrExists(int timeInSeconds) {
		try {

			return LeanftAction.isExists(screen, timeInSeconds);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return false;
	}

	/**
	 * Selecting application
	 * 
	 * @param option
	 * @return QCICSBTSLoginScr
	 */
	public FR_MF_ApplicationLoginScr selectApplication(String option,String enumKeys) {

		try {

			/* waiting for terminal home screen */
			LeanftAction.sync(screen);

			/* selecting option */
			LeanftAction.setText(commandField, option);

			LeanftAction.sendTeKeys(screen, enumKeys);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return new FR_MF_ApplicationLoginScr();

	}

	/**
	 * Return Log off terminal
	 * 
	 * @return CO_LEG_MRG_TeLoginScr
	 */
	public FR_MF_MainframeLoginScr logoff() {
		try {

			/* waiting for terminal home screen */
			LeanftAction.sync(screen);

			LeanftAction.setText(commandField, "logoff");

			LeanftAction.sendTeKeys(screen, Keys.ENTER);

		} catch (Exception e) {
			ExceptionHandler.handleException(e);
		}

		return new FR_MF_MainframeLoginScr();
	}

}
