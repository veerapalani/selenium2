package qa.framework.flatfile;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class FlatFileRules {

	/**
	 * Converting String into Float with specified digit after decimal count
	 * 
	 * @author Bathriyo
	 * @param value
	 * @param decimal
	 * @return
	 */
	private String floatDecimalFormat(String value, int decimal) {

		/* converting string into float */
		Float parsedFloat = Float.parseFloat(value);

		/* creating DecimalFormat object */
		DecimalFormat df = new DecimalFormat("0.00000");

		/* setting maximum digit after decimal passed as argument */
		df.setMaximumFractionDigits(decimal);

		/* formatting parsed float value */
		return df.format(parsedFloat);
	}

	private String intFormat(String value, int digits) {

		int parseInt = Integer.parseInt(value);

		return String.format("%0" + digits + "d", parseInt);
	}

	public void validateRuleColumns(List<String> lstRuleColumnNames, Map<String, String> mapOut,
			Map<String, String> mapIn, Map<String, String> mapping, SoftAssert softAssert) {
		
		FlatFileRepoter report = new FlatFileRepoter();

		for (String ruleColumn : lstRuleColumnNames) {

			String outColumn = ruleColumn;
			String inColumn = mapping.get(outColumn);

			String actualValue = mapOut.get(outColumn);
			String expectedValue = mapIn.get(inColumn);

			switch (ruleColumn) {

			case "generalPurposeFees.fees.amount.value(0)":
			case "generalPurposeFees.fees.amount.value(1)":
			case "generalPurposeFees.fees.amount.value(2)":
			case "generalPurposeFees.fees.amount.value(3)":
			case "generalPurposeFees.fees.amount.value(4)":
			case "concession.amount.value":
			case "underlyingQuantity":
			case "fees.amount.value(0)":
			case "fees.amount.value(1)":
			case "taxes.rate":
			case "costBasis.amount.value":
			case "price":
			case "taxes.amount.value":
			case "optionDetails.strikePrice":
			case "grossCredit.amount.value":
			case "principal":
			case "quantity":
			case "consideration":

				/*Getting NumberFormate Exception if actualValue and ExpecteValue null/blank*/
				if (actualValue.length() > 0 && expectedValue.length() > 0) {
					actualValue = floatDecimalFormat(actualValue, 2);
					expectedValue = floatDecimalFormat(expectedValue, 2);
				}

				break;

			case "derivativeSequenceIdentifier":
			case "derivativeSequenceType":
				
				/*Getting NumberFormate Exception if actualValue and ExpecteValue null/blank*/
				if (actualValue.length() > 0 && expectedValue.length() > 0) {
					actualValue = intFormat(actualValue, 2);
					expectedValue = intFormat(expectedValue, 2);
				}
				break;

			default:
				Assert.fail(
						"Column mentioned in Rules is not implemented in Switch statement. Column Name: " + ruleColumn);
			}

			/* Asserting actualValue equals expected value */
			softAssert.assertEquals(actualValue, expectedValue,
					"\nValue are not same for - \nIn : " + inColumn + "\nOut : " + outColumn + "\n\n");
			
			report.write(report.getPrimaryKey(), inColumn, expectedValue, outColumn, actualValue);
			System.out.println("IN : "+inColumn+" : "+expectedValue);
			System.out.println("OUT : "+outColumn+" : "+actualValue);

		}

	}

}
