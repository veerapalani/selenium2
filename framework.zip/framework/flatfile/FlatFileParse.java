package qa.framework.flatfile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import qa.framework.utils.ExcelUtil;
import qa.framework.utils.ExceptionHandler;

public class FlatFileParse {

	/**
	 * Parse Out file
	 * 
	 * @author Bathriyo
	 * @return List<Map>
	 */
	public List<Map<String, String>> parseOUTFile(String outFilePath,char delimiter) {

		String colName = null;
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();

		BufferedReader bufferedReader = null;
		if (new File(outFilePath).exists()) {
			try {
				bufferedReader = new BufferedReader(new FileReader(outFilePath));

				String line = null;

				/* '|TEST' is added to avoid blank value at the end of COLUMN name */
				colName = bufferedReader.readLine().concat(delimiter+"TEST").replace(delimiter, ';');

				String[] colArray = colName.split(";");

				while ((line = bufferedReader.readLine()) != null) {

					/*
					 * '|TEST' is added to avoid blank value (ArrayIndexOutOfBound) at the end of
					 * ROW/line
					 */
					line = line.concat(delimiter+"TEST").replace(delimiter, ';');
					String[] lineArray = line.split(";");

					Map<String, String> mapColumn = new HashMap<String, String>();

					/* To avoid entry of TEST as column header/map key colArray.length-1 is used */
					for (int index = 0; index < colArray.length - 1; index++) {

						mapColumn.put(colArray[index].trim(), lineArray[index].trim());

					}

					list.add(mapColumn);
					line = null;
				}
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
				e.printStackTrace();
			} finally {
				try {
					bufferedReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return list;

	}

	/**
	 * Parsing In File
	 * 
	 * @author Bathriyo
	 * @return List<Map>
	 */
	public List<Map<String, String>> parseINFile(String inFilePath,char delimiter) {

		String colName = null;
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();

		BufferedReader bufferedReader = null;
		if (new File(inFilePath).exists()) {
			try {
				bufferedReader = new BufferedReader(new FileReader(inFilePath));

				String line = null;

				colName = bufferedReader.readLine();

				/* ',TEST' is added to avoid blank value at the end of COLUMN name */
				String[] colArray = colName.concat(delimiter+"TEST").split(delimiter+"");//converting char to string

				while ((line = bufferedReader.readLine()) != null) {

					/*
					 * ',TEST' is added to avoid blank value (ArrayIndexOutOfBound) at the end of
					 * ROW/line
					 */
					String[] lineArray = line.concat(",TEST").replace("\"", "").split(",");

					Map<String, String> mapColumn = new HashMap<String, String>();

					/* To avoid entry of TEST as column header/map key colArray.length-1 is used */
					for (int index = 0; index < colArray.length - 1; index++) {

						mapColumn.put(colArray[index].trim(), lineArray[index].trim());
					}

					list.add(mapColumn);
					line = null;
				}
			} catch (Exception e) {
				ExceptionHandler.handleException(e);
				e.printStackTrace();
			} finally {
				try {
					bufferedReader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return list;
	}

	/**
	 * 
	 * @param lstPrimaryKeys
	 * @param mapping
	 * @param outEntry
	 * @param inEntries
	 * @return
	 */
	public int searchInInputFile(List<String> lstPrimaryKeys, Map<String, String> mapping, Map<String, String> outEntry,
			List<Map<String, String>> inEntries) {

		int index = 0;
		List<Integer> listOfIndexes = new ArrayList<Integer>();

		/*
		 * taking a row from In file (List<Map>) at a time and searching for against Out
		 * file row
		 */
		for (Map<String, String> inEntry : inEntries) {

			boolean flag = true;
			
			FlatFileRepoter report = new FlatFileRepoter();
			
			
			/*forming a combine primary key for report*/
			String combinePrimaryKey="";
			for(String key : lstPrimaryKeys) {
				combinePrimaryKey+=outEntry.get(key);
			}
			
			report.setPrimaryKey(combinePrimaryKey);
			
			
			
			/*Searching for record location (index) with primary keys in IN file*/
			for (String primaryKey : lstPrimaryKeys) {

				String inColumnValue = "";
				String outColumnValue = outEntry.get(primaryKey);

				/* Getting the column of In file mapped with Out file */
				String inColumn = mapping.get(primaryKey);

				/* Checking if Out column value is multiple of more then one In column values */
				if (inColumn.contains(",")) {
					String[] columns = inColumn.split(",");

					for (String column : columns) {
						inColumnValue = inColumnValue + inEntry.get(column);
					}

				} else {
					inColumnValue = inEntry.get(mapping.get(primaryKey));
				}

				/* comparing Out value with In value */
				if (outColumnValue.equals(inColumnValue)) {
					/* do not make flag =true here, otherwise false condition will be overridden */

				} else {
					/* if value is mismatched flag status is changed to false */
					flag = false;
					/*
					 * do not put break after flag = false otherwise next entry/row in IN will not
					 * checked
					 */
				}
			}

			if (flag == true) {
				listOfIndexes.add(index);
			}

			index += 1;
		}

		/* Checking if more then one match are found */
		if (listOfIndexes.size() == 1) {
			return listOfIndexes.get(0);
		} else {
			System.out.println(" Multiple entries are avaiable with Primary Key in Input file on Row : ");

			/* Printing Row Index */
			for (int rowIndex : listOfIndexes) {

				/* Adding 1 to row index as header (columns) is not part of it */
				System.out.println(rowIndex + 1);
			}

			/* Printing Column name : Columns values used as Primary key */
			for (String key : lstPrimaryKeys) {
				System.out.println(key + " : " + outEntry.get(key));
			}
		}

		/* in case none of the entries in IN file matches returning -1 */
		return -1;
	}

	
	/**
	 * Provides mapping between out and in files columns
	 * 
	 * @author Bathriyo
	 * @param excelFilePath
	 * @param sheetName
	 * @return Map<String,String>
	 */
	public Map<String, String> getMappedOutInFields(String excelFilePath, String sheetName, String outColumnName,
			String inColumnName) {

		Map<String, String> map = new HashMap<String, String>();

		ExcelUtil.setExcelFile(excelFilePath, sheetName);

		int rowCount = ExcelUtil.getRowCount();

		int outColumnIndex = ExcelUtil.getCellIndexByCellValue(0, outColumnName);
		int inColumnIndex = ExcelUtil.getCellIndexByCellValue(0, inColumnName);

		for (int index = 1; index < rowCount; index++) {

			try {
				String outColumn = ExcelUtil.getStringCellData(index, outColumnIndex);
				String inColumn = ExcelUtil.getStringCellData(index, inColumnIndex);
				
				if(outColumn.length()>0 && inColumn.length()>0) {
					map.put(outColumn,inColumn);
				}else if(outColumn.length()==0 && inColumn.length()==0) {
					/*do nothing as apache POI might read blank row from the excel*/
				}else {
					Assert.fail("!!! Mapping Not availabe. !!!!"+"\nOutColumn : "+inColumn +"\nInColumn : "+inColumn);
				}
				
				
			} catch (Exception e) {

			}

		}

		ExcelUtil.closeWorkBook();

		return map;
	}

	/**
	 * Getting list of Primary keys from excel
	 * 
	 * @param excelFilePath
	 * @param sheetName
	 * @param primaryKeyColumnName
	 * @return
	 */
	public List<String> getPrimaryKeys(String excelFilePath, String sheetName, String primaryKeyColumnName) {

		int index = 0;
		List<String> subList;

		ExcelUtil.setExcelFile(excelFilePath, sheetName);

		List<String> lstPrimaryKeys = ExcelUtil.getCellData(primaryKeyColumnName);

		/* getting the last index of the list with actual value (not blank) */
		for (String str : lstPrimaryKeys) {
			if (str.length() == 0) {
				break;
			} else
				index += 1;
		}

		/*
		 * getting subList from index 0 to last index with actual value (without blank)
		 */
		subList = lstPrimaryKeys.subList(0, index);

		ExcelUtil.closeWorkBook();

		return subList;
	}

	/**
	 * 
	 * @param excelFilePath
	 * @param sheetName
	 * @return
	 */
	public List<String> getIgnoreColumnNames(String excelFilePath, String sheetName, String ignoreColumnName) {

		int index = 0;
		List<String> subList;
		ExcelUtil.setExcelFile(excelFilePath, sheetName);

		List<String> lstIgnoreColumnsNames = ExcelUtil.getCellData(ignoreColumnName);

		/* getting the last index of the list with actual value (not blank) */
		for (String str : lstIgnoreColumnsNames) {
			if (str.length() == 0) {
				break;
			} else {
				index += 1;
			}

		}

		/*
		 * getting subList from index 0 to last index with actual value (without blank)
		 */
		subList = lstIgnoreColumnsNames.subList(0, index);

		/* sorting list so that binary search can be applied */
		Collections.sort(subList);

		ExcelUtil.closeWorkBook();

		return subList;
	}

	public List<String> getRuleColumnNames(String excelFilePath, String sheetName, String ruleColumnName) {

		int index = 0;
		List<String> subList;
		ExcelUtil.setExcelFile(excelFilePath, sheetName);

		List<String> lstRuleColumnsNames = ExcelUtil.getCellData(ruleColumnName);

		/* getting the last index of the list with actual value (not blank) */
		for (String str : lstRuleColumnsNames) {
			if (str.length() == 0) {
				break;
			} else {
				index += 1;
			}

		}

		/*
		 * getting subList from index 0 to last index with actual value (without blank)
		 */
		subList = lstRuleColumnsNames.subList(0, index);

		/* sorting list so that binary search can be applied */
		Collections.sort(subList);

		ExcelUtil.closeWorkBook();

		return subList;

	}

	/**
	 * 
	 * @param excelFilePath
	 * @param sheetName
	 * @param mapOut
	 * @param mapIn
	 */
	public void compareOutFileValueWithInFileValue(Map<String, String> mapOut, Map<String, String> mapIn,
			Map<String, String> mapping, List<String> lstIgnoreColumnNames, List<String> lstRuleColumnNames,
			SoftAssert softAssert) {

		FlatFileRepoter report = new FlatFileRepoter();
		
		for (Map.Entry<String, String> entry : mapping.entrySet()) {

			int ignoreSearchIndex = Collections.binarySearch(lstIgnoreColumnNames, entry.getValue());
			int ruleSearchIndex = Collections.binarySearch(lstRuleColumnNames, entry.getKey());

			/*
			 * Validation for OUT column value with IN column value will only happen if IN
			 * column does not exists in Ignore list and OUT column does not exists in Rule
			 * list
			 */
			if (ignoreSearchIndex < 0 && ruleSearchIndex < 0) {

				String outColumn = entry.getKey();
				String inColumn = entry.getValue();

				String expectedValue = "";
				String actualValue = mapOut.get(outColumn);

				/* if the expected value is combination of multiple IN column values */
				if (inColumn.contains(",")) {
					String[] mulColumns = inColumn.split(",");

					for (String column : mulColumns) {
						expectedValue += mapIn.get(column.trim());
					}
				} else {
					expectedValue = mapIn.get(inColumn);
				}

				/* Asserting actualValue equals expected value */
				softAssert.assertEquals(actualValue, expectedValue,
						"\nValue are not same for - \nIn : " + entry.getValue() + "\nOut : " + entry.getKey() + "\n\n");
				
				
				report.write(report.getPrimaryKey()+"", inColumn, expectedValue, outColumn, actualValue);
				System.out.println("IN : "+inColumn+" : "+expectedValue);
				System.out.println("OUT : "+outColumn+" : "+actualValue);
				

			} else {
				// System.out.println("Ignored: "+entry.getValue());
			}

		}

	}

}
