package qa.framework.flatfile;

import org.testng.AssertJUnit;

import qa.framework.utils.CalendarUtils;
import qa.framework.utils.FileManager;

public class FlatFileRepoter {

	public static int recordCouter=0;
	public static int splitRecordCount = 2000;
	
	
	private static int partFileCounter = 2;
	private static String uniqueFileName="";
	private static String format=".txt";
	
	private static ThreadLocal<String> TFilePath = new ThreadLocal<String>();
	
	private static ThreadLocal<String> TPrimaryKey = new ThreadLocal<String>();

	private static String counter() {
		return CalendarUtils.getCalendarUtilsObject().getTimeStamp("ddMMyyyyHHmmss");
	}

	private void setFilePath(String filePath) {
		TFilePath.set(filePath);
	}

	public String getFilePath() {
		return TFilePath.get();
	}

	public String getPrimaryKey() {
		return TPrimaryKey.get();
	}

	public void setPrimaryKey(String primaryKey) {
		TPrimaryKey.set(primaryKey);
	}
	
	public String createFile(String fileName, String format) {

		String userDir = System.getProperty("user.dir");
		uniqueFileName = fileName + counter();
		this.format =format;
		String writeStr = "Primary Key|In Column|In Column Value|Out Column|Out Column Value|Status";
		String filePath = userDir + "/src/test/resources/te/fileinterface/etl/reports/" + uniqueFileName + format;

		setFilePath(filePath);

		FileManager fileMng = FileManager.getFileManagerObj();

		boolean status = fileMng.createFile(filePath);

		if (!status) {
			AssertJUnit.fail(" !!! Given file didn't got created !!! " + filePath);
		}

		/* writing header to newly created file */
		fileMng.write(filePath, writeStr + "\n");

		return filePath;

	}

	/**
	 * If records exceed splitRecordCount report file will be split
	 * @return
	 */
	private String createPartFile() {
		
		String writeStr = "Primary Key|In Column|In Column Value|Out Column|Out Column Value|Status";
		String filePath = getFilePath();
		
		FileManager fileMng = FileManager.getFileManagerObj();
		
		filePath = filePath.subSequence(0, filePath.indexOf(uniqueFileName)+uniqueFileName.length())+"-Part(" + partFileCounter + ")"+format;
		

		/*set new file path*/
		setFilePath(filePath);

		
		/*creating new file*/
		boolean status = fileMng.createFile(filePath);

		if (!status) {
			AssertJUnit.fail(" !!! Given file didn't got created !!! " + filePath);
		}

		/* writing header to newly created file */
		fileMng.write(filePath, writeStr + "\n");

		partFileCounter += 1;
		
		/*setting record count/no to 0*/
		recordCouter=0	;
		
		return filePath;
	}

	/**
	 * Writes record in file
	 * 
	 * @author Bathriyo
	 * @param primaryKey
	 * @param inColumn
	 * @param inColumnValue
	 * @param outColumn
	 * @param outColumnValue
	 */
	public void write(String primaryKey, String inColumn, String inColumnValue, String outColumn,
			String outColumnValue) {

		FileManager fileMng = FileManager.getFileManagerObj();

		String status = "FAIL";
		String writeStr;

		if (outColumnValue != null && inColumnValue != null) {

			/* Checking if both the values are equal in case both the values are not null */
			if (outColumnValue.equals(inColumnValue)) {
				status = "PASS";
			} else {
				status = "FAIL";
			}

		} else if (outColumnValue == null && inColumnValue == null) {
			/* if both the values are null status will be PASS */
			status = "PASS";
		} else {
			/* if any of the value is null i.e. actual or expected status will be FAIL */
			status = "FAIL";
		}

		
		if(recordCouter>splitRecordCount) {
			createPartFile();	
		}
		
		writeStr = primaryKey + "|" + inColumn + "|" + inColumnValue + "|" + outColumn + "|" + outColumnValue + "|"
				+ status;

		fileMng.append(getFilePath(), writeStr + "\n");

		
		
		
	}

}
