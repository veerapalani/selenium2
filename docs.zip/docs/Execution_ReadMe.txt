**************************************
Pre-requisites:
**************************************
1. Install Java JDK 1.8 and configure JAVA_HOME environment variable 
2. Install GIT Bash in default location: C:\Program Files\Git\bin\git.exe
3. Install Maven and configure MAVEN_HOME environment variable
4. Navigate to C:\<user>\.m2 folder and update settings.xml to point to "\\10.101.0.77\m2Repo" repository



**************************************
Steps to run:
**************************************
1. Clone the project from Unicorn QA Automation GIT Repository
2. Checkout Dev branch
3. Launch command and change directory to project folder: e.g. D:\workspace\unicornqa\Unicorn [where you have the pom.xml]
4. Run the test execution with following command: mvn test -Dcucumber.options="--tags @DF_Smoke"
   Note: change the tag (@DF_Smoke)as per project execution need. Tags have to be setup in feature files as per the framework guidelines
5. Report will be generated under: <project folder>\target\cucumber-reports\report.html



**************************************
Cucumber Execution Commands:
**************************************
Sequential Execution:
Local:
Syntax:
mvn test -Dcucumber.options="src/test/resources/<stream dir name> --tags <anytag>" -Pagile -Dbrowser=<browserName>

Example: 
mvn test -Dcucumber.options="src/test/resources/ws --tags @Parallel" -Pagile -Dbrowser=ie 

Remote:
Syntax:
mvn test -Dcucumber.options="src/test/resources/<stream dir name> --tags <anytag>" -Pagile -Dbrowser=<browserName> -Dremote=true -DbrowserVersion="<browserVersion>" -Dplatform="<operatingSystem>" -Dhuburl="<huburl>"

Example:
mvn test -Dcucumber.options=" src/test/resources/ws--tags @Parallel" -Pagile -Dbrowser=ie -Dremote=true -DbrowserVersion="ANY" -Dplatform="ANY" -Dhuburl="http://10.101.0.77:5555/wd/hub"

**************************************
Parallel Execution:
Local:
Syntax:
mvn test -Dcucumber.options="src/test/resources/<stream dir name> --tags <anytag>" -Pagile -Dbrowser=<browserName> -DthreadCount=<number  of scenarios to execution parallelly>

Example: 
mvn test -Dcucumber.options="src/test/resources/ws --tags @Parallel" -Pagile -Dbrowser=ie  -DthreadCount=3 

Remote:
Syntax:
mvn test -Dcucumber.options="src/test/resources/<stream dir name> --tags <anytag>" -Pagile -Dbrowser=<browserName> -Dremote=true -DbrowserVersion="<browserVersion>" -Dplatform="<operatingSystem>" -Dhuburl="<huburl>" -DthreadCount=<number  of scenarios to execution parallelly>

Example:
mvn test -Dcucumber.options="src/test/resources/ws --tags @Parallel" -Pagile -Dbrowser=ie -Dremote=true -DbrowserVersion="ANY" -Dplatform="ANY" -Dthreadcount=3 -Dhuburl="http://10.101.0.77:5555/wd/hub"

**************************************
**************************************
**************************************
TestNG Execution Commands:
**************************************
Sequential Execution:
Local:
Syntax:
mvn test -DtestNG.options="<includeGroupName>,<~excludeGroupName>" -Pwaterfall -Dbrowser=<browserName>

Example: 
mvn test -DtestNG.options="Parallel" -Pwaterfall -Dbrowser=ie 

Remote:
Syntax:
mvn test -DtestNG.options="<includeGroupName>,<~excludeGroupName>" -Pwaterfall -Dbrowser=<browserName> -Dremote=true -DbrowserVersion="<browserVersion>" -Dplatform="<operatingSystem>" -Dhuburl="<huburl>"

Example:
mvn test -DtestNG.options="Parallel" -Pwaterfall -Dbrowser=ie -Dremote=true -DbrowserVersion="ANY" -Dplatform="ANY" -Dhuburl="http://10.101.0.77:5555/wd/hub"

**************************************
Parallel Execution:
Local:
Syntax:
mvn test -DtestNG.options="<includeGroupName>,<~excludeGroupName>" -Pwaterfall -Dbrowser=<browserName> -DthreadCount=<number  of scenarios to execution parallelly>

Example: 
mvn test -DtestNG.options="Parallel" -Pwaterfall -Dbrowser=ie -DthreadCount=3 

Remote:
Syntax:
mvn test -DtestNG.options="<includeGroupName>,<~excludeGroupName>" -Pwaterfall -Dbrowser=<browserName> -Dremote=true -DbrowserVersion="<browserVersion>" -Dplatform="<operatingSystem>" -Dhuburl="<huburl>" -DthreadCount=<number  of scenarios to execution parallelly>

Example:
mvn test -DtestNG.options="Parallel" -Pwaterfall -Dbrowser=ie -Dremote=true -DbrowserVersion="ANY" -Dplatform="ANY" -Dthreadcount=3 -Dhuburl="http://10.101.0.77:5555/wd/hub"

**************************************



Note: One execution is recommended per node i.e. when any execution is in-progress in a node, do not trigger another execution on the same node.
*-P: Profile
**-D: and variable may be used in pom.xml or in script.

**************************************
